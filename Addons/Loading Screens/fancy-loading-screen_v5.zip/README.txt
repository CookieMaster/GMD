To view the manual, please visit the link below.
https://docs.google.com/document/d/1hlBDnSm7XaZ_ZoDp7akjzlAG7fPcHucYFTBHG-bSU8M/edit?usp=sharing