Hello and thank you for purchase my product.

Background is just example.
Source:
http://www.wallsave.com/wallpapers/1920x1080/trouble-in-terrorist-town/270978/trouble-in-terrorist-town-profile-270978.jpg
I just made a modification of it for coderhire.com to show as example.

Modules:
https://github.com/MattRyder/SteamAPI
Thank to him for the great work.

For more settings look into config.php (NOT MORE index.php) like changing rules or even disable it.


------HOW TO SETUP LOADINGSCREEN (it's for Version 1)
1. ---

Upload everything into your webspace but not THIS FILE("readme.txt") 
After upload it should look like so

"loadingscreenfolder"
"loadingscreenfolder/index.php"
"loadingscreenfolder/img"
"loadingscreenfolder/module"


2. ---

just put in your .cfg
Example
sv_loadingurl "http://yourdomain.com/loadingscreenfolder/?steamid=%s"

in my case it would be.
sv_loadingurl "http://garrysmod.zulu907.server4you.de/s/ch/loadingscreen/?steamid=%s"


3. ---
open index.php and write your description, server name and co. :)


have fun :)