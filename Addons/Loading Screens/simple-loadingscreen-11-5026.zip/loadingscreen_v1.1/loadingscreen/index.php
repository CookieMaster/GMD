<?
include("config.php");

// DON'T CHANGE THIS.
if(isset($_GET["steamid"])) {
	$User = new SteamUser($_GET["steamid"]);
}
?>
<html>
	<head>
		<script type="text/javascript">

			
			var bCanChangeStatus = true;
			
			var iFilesLeft = 0;
			var iFilesLeftTotal = 0;
			var bDownloadingFile = false;
			
			function timeget() {
				var d = new Date();
				var text = d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds(); 
				return text;
			}
			timeget();
			
			function SetFilesNeeded(downloadCount) {
				iFilesLeft = downloadCount;
			}
			
			function SetFilesTotal(maxFiles) {
				iFilesLeftTotal = maxFiles;
			}
			
			function DownloadingFile(filename) {
				
				iFilesLeft = iFilesLeft + 1;

				document.getElementById( "left" ).innerHTML = "You need " + iFilesLeft;
				document.getElementById( "right" ).innerHTML = "of " + iFilesLeftTotal;
				document.getElementById("bar").style.width = (100*iFilesLeft/iFilesLeftTotal) + "%";

				document.getElementById( "console" ).innerHTML = document.getElementById( "console" ).innerHTML + "<" + timeget() + "> Downloading " + filename + "<br>"
				var handle = document.getElementById( "console" );
				handle.scrollTop = handle.scrollHeight;
			}
			
			function SetStatusChanged(strStatus) {
				
				if (strStatus.search("completed")) {
					document.getElementById( "left" ).innerHTML = "";
					document.getElementById( "right" ).innerHTML = "";
					document.getElementById("bar").style.width = 100 + "%";
				} else {
					document.getElementById("bar").style.width = (100*iFilesLeft/iFilesLeftTotal) + "%";
				}

				document.getElementById( "console" ).innerHTML = document.getElementById( "console" ).innerHTML + "<" + timeget() + "> " + strStatus + "<br>";
				var handle = document.getElementById( "console" );
				handle.scrollTop = handle.scrollHeight;
			}
			
			function GameDetails( servername, serverurl, mapname, maxplayers, steamid, gamemode )
			{
				// Do with these what you will :)
				// this function gets called only when joining a multiplayer server

				//$("#spambox").append("serverurl: " + serverurl + "<br>");
				$("body").append("You are joining: " + servername + "<br>");
				$("#spambox").append("Gamemode is: " + gamemode + "<br>");
				//$("#spambox").append("maxplayers: " + maxplayers + "<br>");
				//$("#spambox").append("steamid: " + steamid + "<br>");
				//$("#spambox").append("mapname: " + mapname + "<br>");
			}

		</script>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
	<div id="mainbox"> 
		<div id="header">
			<div class="right">
				<div><? echo isset($User) ? $TEXT["topright"] : "&nbsp;"; ?></div>
				<div><? echo isset($User) ? $User->steamID : ""; ?></div>
				<div><? echo isset($User) ? "<img src=\"$User->avatarMedium\"></img>" : ""; ?></div>
			</div>
			<div class="middle">
				<div><? echo $TEXT["top"]; ?></div>
				
			</div>
		</div>
		
		<?	if ($TEXT["show_leftright"]) { ?>
		
				<div id="infobox_left">
					<? echo $TEXT["leftbox"] ?>
				</div>
				<div id="infobox_right">
					<? echo $TEXT["rightbox"] ?>
				</div>
		<?  } ?>
		<div style="clear:right;"></div>
		<div style="clear:left;"></div>
		<div id="content">
			<div id="titlefirst"><? echo $TEXT["titlefirst"]; ?><br></div>
			<div id="titlesecond"><? echo $TEXT["titlesecond"]; ?></div>

			<div id="untertitle"><? echo $TEXT["undertitle"]; ?></div>
			
			<div id="progress-bar-wrap">
				<div id="left"></div>
				<div id="progress-bar" style="float:left;">
					<div id="bar"></div>
				</div>
				<div id="right"></div>
				<br style="clear:left;" />
				
			</div>
			<div id="console">_ Console log > ON _<hr></div>
			
			<div id="footer-content"><? echo $TEXT["bottom"]; ?></div>
		</div>

	</div>
	</body>
</html>

