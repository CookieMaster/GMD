<?
/*
Hello and thank you for purchase.
There are some variables to rewrite the description and co.
Example $TEXT["bottom"] = "";

Don't forget to add ";"  at the end of a string. It should looks like so
$TEXT["bottom"] = "This is a string";

Html needs for newline a tag. You can use <br> or </br>.
Example
$TEXT["undertitle"] = "We are glad to see you on our server.<br>Don't forget to follow the rules :)";
It would outprint:
"We are glad to see you on our server.
Don't forget to follow the rules :)"

If you don't get it just look some example of me and try out :)


BACKGROUND
Look for this:
-------
<style type="text/css">
		html {
			background: #333 url("img/bg_texture.jpg");
			// background: #333 url("img/bg.jpg");
			// background-repeat:no-repeat;
			// background-position: center;
			// background-attachment: fixed;
			// background-size: cover;
			// background-color:#2A2A2A;
			// -webkit-background-size: cover;
			// -moz-background-size: cover;
			// -o-background-size: cover;
		}
-------
If you want background just add "//" to the first line
and remove all other "//".
your wallpaper should be renamed to bg.jpg or just  replace "img/bg.jpg" with path to your background image.
If you want remove background then just inverse it.
*/
require_once("module/SteamUser.php");

//middle top
$TEXT["top"]			= "";

/*
It will be "You are logged in as NICKNAME",
Changing to example "You are" would be "You are NICKNAME"
*/
$TEXT["topright"]		= "You are logged in as"; 
$TEXT["bottom"]			= "";

//big size in the middle
$TEXT["titlefirst"]		= "Spacebuild 3";
$TEXT["titlesecond"]	= "A Sandbox Server";

//title under the bigsize title
$TEXT["undertitle"]		= "\"Glad to see your young pilot :)\"";

//Do you want show left or right infobox.
$TEXT["show_leftright"] = false;

/* 
-$TEXT["leftbox"]--------------------------
Starts with "<<<TEXT" and ends with "TEXT"

you can also rename it like so:
$TEXT["leftbox"] = <<<TEXTWRITE
	I am will write here my text.
TEXTWRITE
-------------------------------------------
*/
$TEXT["leftbox"] = <<<TEXT
<h1>Gamemode</h1>

<div style="text-align:left">
<p style="text-align:justify">
	Read it carefully!<br>
	A small number of players is selected as Traitors, who have to kill all the Innocent players. Innocents do not know who is Traitor and who is not.<br>
</p>
	<h2>Short:</h2>
	<dt>Innocents</dt>
	<dl>
		<dd>If you see a Traitor (which kills or tried to kill someone) kill him!</dd>
	</dl>
	
	<dt>Traitor</dt>
	<dl>
		<dd>Your task is just to eliminate all other player (Detectives, Innocents)!</dd>
	</dl>
	
	<dt>Traitor</dt>
	<dl>
		<dd>Your task is just to eliminate all other player (Detectives, Innocents)!</dd>
	</dl>
	
	<dt>Detective</dt>
	<dl>
		<dd>Your mates are Innocents. You have to help him with your Detective skills!</dd>
	</dl>
</div>
TEXT;

/* 
-$TEXT["rightbox"]--------------------------
same like leftbox (above)
-------------------------------------------
*/
$TEXT["rightbox"] = <<<TEXT
<h1>RULES</h1>
<ol>
	<li>LISTEN TO ADMINS</li>
	<li>DO NOT ABUSE AND HACKS</li>
	<li>DO NOT RDM</li>
	<li>DO NOT SKYWALKING</li>
</ol>
<br>
<hr>
<br>
<h1>News</h1>
<h3>New items and modification 02.02.2022</h3>
<dt>Knife</dt>
<dl>
	<dd>Knife makes onehit now!</dd>
</dl>
<dt>Nightvision added!</dt>
<dl>
	<dd>Detective and Traitor can buy nightvision for darkmaps now!</dd>
</dl>
<dt>Healstation has new model</dt>
<dl>
	<dd>Healstation has new model and looks better now!</dd>
</dl>
TEXT;
?>