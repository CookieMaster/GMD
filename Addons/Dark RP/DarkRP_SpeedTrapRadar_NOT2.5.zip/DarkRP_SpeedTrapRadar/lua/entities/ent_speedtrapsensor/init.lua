AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )

include( 'shared.lua' )

function ENT:Initialize( )
	self:SetModel("models/props_combine/combine_emitter01.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
end

function ENT:OnTakeDamage( dmg ) 
	return false
end

function ENT:AcceptInput( name, activator, caller )
    if ( name == "Use" && activator:IsPlayer( ) ) then
		GAMEMODE:Notify(activator, 0, 4, "That sensor belongs to: "..self.SpeedSenoOwner:Nick())
	end
end

function ENT:StartTouch( ent )
end
