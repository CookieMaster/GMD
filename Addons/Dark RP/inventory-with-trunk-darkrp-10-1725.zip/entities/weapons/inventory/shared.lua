if SERVER then
	AddCSLuaFile("shared.lua")
end

if CLIENT then
	SWEP.PrintName = "Inventory"
	SWEP.Slot = 1
	SWEP.SlotPos = 1
	SWEP.DrawAmmo = false
	SWEP.DrawCrosshair = true
end
 
SWEP.Base = "weapon_cs_base2"

SWEP.Author = "Thomas C Williamson"
SWEP.Instructions = "Left-click to pick up, Right-click for menu"
SWEP.Contact = ""
SWEP.Purpose = "Inventory"
SWEP.IconLetter = ""

SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.AnimPrefix	 = "rpg"

SWEP.Spawnable = true
SWEP.AdminSpawnable = true
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

if CLIENT then
	SWEP.FrameVisible = false
end

function SWEP:Initialize()
	self:SetWeaponHoldType("normal")
end

function SWEP:Deploy()
	if not SERVER then return end

	self.Owner:DrawViewModel(false)
	self.Owner:DrawWorldModel(false)
end

function SWEP:Equip(newOwner)
	if not SERVER then return end
end

function SWEP:PrimaryAttack()
	self.Weapon:SetNextPrimaryFire(CurTime() + 0.3)
	if SERVER then
		local trace = util.GetPlayerTrace( self.Owner )
		local traceRes = util.TraceLine( trace )
		if traceRes.HitNonWorld then
			if IsValid(traceRes.Entity) then
				self.Owner:Pickup(traceRes.Entity)
			end
		end
	end
end

function SWEP:SecondaryAttack()
	self.Weapon:SetNextSecondaryFire(CurTime() + 0.4)
	if SERVER then
		self.Owner:OpenInventory()
	end
end

function SWEP:Reload()
	if SERVER then
		self.Weapon.ReloadTime = self.Weapon.ReloadTime or CurTime()
		if self.Weapon.ReloadTime > CurTime() then return end
		self.Weapon.ReloadTime = CurTime() + 0.4
		local trace = util.GetPlayerTrace( self.Owner )
		local traceRes = util.TraceLine( trace )
		if traceRes.HitNonWorld then
			if IsValid(traceRes.Entity) and traceRes.Entity:IsVehicle() then
				traceRes.Entity:OpenBoot(self.Owner)
			end
		end
	end
end

