--SV
util.AddNetworkString("Open_Boot")
util.AddNetworkString("Handle_Boot")


local meta = FindMetaTable("Entity")

function meta:OpenBoot(ply)
	if !self:IsVehicle() then return false end
	if self.ToggleBoot then return false end
	if self.Locked then return false end
	self.ToggleBoot = true
	self.Boot = self.Boot or {}
	net.Start("Open_Boot")
		net.WriteTable(self.Boot)
	net.Send(ply)
	ply.EntOpened = self
end

hook.Add("PlayerDisconnected", "BootDisconnect", function(ply)
	if(ply.EntOpened) then
		ply.EntOpened.ToggleBoot = false
		ply.EntOpened = nil
	end
end)

function meta:AddItem(tab)
	if !self:IsVehicle() then return false end
	if self.Locked then return false end
	self.Boot = self.Boot or {}
	if #self.Boot >= 5 then return false end
	self.Boot = self.Boot or {}
	table.insert(self.Boot, tab)
	return true
end


function meta:RemoveItem(itemnum) 
	if !self:IsVehicle() then return false end
	if self.Locked then return false end
	self.Boot = self.Boot or {}
	if !self.Boot[itemnum] then return false end
	local itemtable = self.Boot[itemnum]
	table.remove(self.Boot, itemnum)
	return true
end

net.Receive("Handle_Boot", function(ln, ply)
	local id = net.ReadInt(32)
	local ty = net.ReadString()
	if !ply.EntOpened then return end
	if ply.EntOpened.Locked then
		ply.EntOpened.ToggleBoot = false
		ply.EntOpened = nil
		return
	end
	if ty == "Close" then
		ply.EntOpened.ToggleBoot = false
		ply.EntOpened = nil
	elseif ty == "TakeItem" then
		if (#ply.Inventory.Items >= ply.Inventory.size) then
			ply:ChatPrint("Your inventory is full.")
			ply.EntOpened.ToggleBoot = false
			ply.EntOpened = nil
			return
		end
		ply:AddItem(ply.EntOpened.Boot[id])
		ply.EntOpened:RemoveItem(id)
		ply.EntOpened.ToggleBoot = false
		ply.EntOpened = nil
	elseif ty == "EquipItem" then
		if(ply.EntOpened.Boot[id].class == "spawned_weapon") then
			ply:Give(ply.EntOpened.Boot[id].weaponclass)
			ply:ChatPrint("Your have equipped this weapon.")
			ply.EntOpened:RemoveItem(id)
			ply.EntOpened.ToggleBoot = false
			ply.EntOpened = nil
		end
	end
end)




// overwrite darkrp funcs
timer.Simple(0.25, function()
	function meta:KeysLock()
		self:Fire("lock", "", 0)

		if(self:IsVehicle()) then
			self.Locked = true
		end
		-- VUMod compatibility
		-- Locks passenger seats when the vehicle is locked.
		if self:IsVehicle() and self.VehicleTable and self.VehicleTable.Passengers then
			for k,v in pairs(self.VehicleTable.Passengers) do
				v.Ent:Fire("lock", "", 0)
				
			end
		end

		-- Locks the vehicle if you're unlocking a passenger seat:
		if IsValid(self:GetParent()) and self:GetParent():IsVehicle() then
			self:GetParent():KeysLock()
		end
	end

	function meta:KeysUnLock()
		self:Fire("unlock", "", 0)
		if(self:IsVehicle()) then
			self.Locked = false
		end
		-- VUMod
		if self:IsVehicle() and self.VehicleTable and self.VehicleTable.Passengers then
			for k,v in pairs(self.VehicleTable.Passengers) do
				v.Ent:Fire("unlock", "", 0)
			end
		end

		-- Unlocks the vehicle if you're unlocking a passenger seat:
		if IsValid(self:GetParent()) and self:GetParent():IsVehicle() then
			self:GetParent():KeysUnLock()
		end
	end
end)