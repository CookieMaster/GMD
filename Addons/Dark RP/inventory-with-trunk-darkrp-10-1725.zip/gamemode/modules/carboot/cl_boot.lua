--CL
local bgcolor =           Color(0, 0, 0, 255)         // Color of inventory background
local buttoncolor =       Color(200, 200, 200, 255)   // Color of buttons
local buttoncolordis =    Color(50, 50, 50, 255)      // Color of disabled buttons
local buttontextcolor =   Color(0, 0, 0, 255)         // color of button text

local infotextcolor =     Color(255, 255, 255, 255)   // color of information text (slots used ect)
local itemcolor =         Color(100, 100, 100, 255)   // color of the item 'card'
local itemringcolor =     Color(0, 0, 0, 255)         // color of the ring around the image
local itembgcolor =       Color(155, 155, 155, 255)   // color of the background of the image
local itemtextcolor =     Color(0, 0, 0, 255)         // color of the item's text


function OpenBoot()
	local Tab = net.ReadTable()
	local Items = Tab or {}
	for k,v in pairs(Items) do
		Items[k].co = k
	end
	local Boot = vgui.Create( "DFrame" )
		Boot:SetSize( 1000, 300 )
		Boot:SetTitle("")
		Boot:SetVisible( true )
		Boot:SetDraggable( false )
		Boot:ShowCloseButton( true ) 
		Boot:Center()
		Boot:MakePopup()
		Boot.Paint = function()
			draw.RoundedBox( 8, 0, 0, Boot:GetWide(), Boot:GetTall(), bgcolor)
			draw.DrawText(#Items.."/5 Slots Used", "Default", 992, 25, infotextcolor, TEXT_ALIGN_RIGHT )
		end
		Boot.btnClose.DoClick = function ( button )
			net.Start("Handle_Boot")
				net.WriteInt( "4", 32 )
				net.WriteString( "Close" )
			net.SendToServer()
			Boot:Close()
		end
		
		Boot.Page = {}
		
		local ItemsOnPage = table.Copy(Items)
		for i=1, #ItemsOnPage do
			Boot.Page[i] = {}
			Boot.Page[i].Item = table.Copy(ItemsOnPage[i])
			Boot.Page[i].Panel = vgui.Create("DPanel", Boot)
			Boot.Page[i].Panel:SetSize( 175, 290 )
			Boot.Page[i].Panel:SetPos(180*(i-1) + 5, 5 )
			Boot.Page[i].Panel.Paint = function()
				draw.RoundedBox( 8, 0, 0, 175, 290, itemcolor)
				draw.RoundedBox( 8, 2.5, 2.5, 169, 169, itemringcolor)
				draw.RoundedBox( 8, 5, 5, 165, 165, itembgcolor)
				
				if(Boot.Page[i].Item.class == "spawned_shipment") then
					draw.DrawText( "Name: " .. Boot.Page[i].Item.name .. " Shipment", "Default", 5, 175, itemtextcolor, TEXT_ALIGN_LEFT )
					draw.DrawText( "Contains: " .. Boot.Page[i].Item.count .. " Items", "Default", 5, 190, itemtextcolor, TEXT_ALIGN_LEFT )
				else
					draw.DrawText( "Name: " .. Boot.Page[i].Item.name, "Default", 5, 175, itemtextcolor, TEXT_ALIGN_LEFT )
				end
				
			end	
			
			Boot.Page[i].Icon = vgui.Create( "DModelPanel", Boot.Page[i].Panel )
			Boot.Page[i].Icon:SetPos( 5, 5 )
			Boot.Page[i].Icon:SetSize( 165, 165 )
			Boot.Page[i].Icon:SetLookAt(Vector(0,0,0))
			
			local model = Boot.Page[i].Item.model
			local class = Boot.Page[i].Item.class
			
			if(class == "spawned_shipment") then
				Boot.Page[i].Icon:SetModel("models/Items/item_item_crate_dynamic.mdl")
				Boot.Page[i].Icon:SetFOV(40)
				Boot.Page[i].Icon:SetLookAt(Vector(0,0,10))
			elseif(class == "spawned_weapon") then
				Boot.Page[i].Icon:SetModel(model or "models/Items/item_item_crate_chunk06.mdl")
				Boot.Page[i].Icon:SetFOV(30)
			else
				Boot.Page[i].Icon:SetModel(model or "models/Items/item_item_crate_chunk06.mdl")
				Boot.Page[i].Icon:SetFOV(40)
			end
			
			Boot.Page[i].Drop = vgui.Create( "DButton", Boot.Page[i].Panel )
			Boot.Page[i].Drop:SetPos( 5, 260 )
			Boot.Page[i].Drop:SetSize( 165, 25 )
			Boot.Page[i].Drop:SetText( "Take Item" )
			Boot.Page[i].Drop.Paint = function()
				draw.RoundedBox( 0, 0, 0, Boot.Page[i].Drop:GetWide(), Boot.Page[i].Drop:GetTall(), buttoncolor)
			end
			
			Boot.Page[i].Drop:SetTextColor(buttontextcolor)
			Boot.Page[i].Drop.DoClick = function()
				net.Start( "Handle_Boot" )
				net.WriteInt( Boot.Page[i].Item.co, 32 )
				net.WriteString("TakeItem")
				net.SendToServer()
				Boot:Remove()
			end

			Boot.Page[i].Equip = vgui.Create( "DButton", Boot.Page[i].Panel )
			Boot.Page[i].Equip:SetPos( 5, 230 )
			Boot.Page[i].Equip:SetSize( 165, 25 )
			Boot.Page[i].Equip:SetText( "Equip Item" )	
			Boot.Page[i].Equip:SetTextColor(buttontextcolor)				
			if(class == "spawned_weapon") then
				Boot.Page[i].Equip.Paint = function()
					draw.RoundedBox( 0, 0, 0, Boot.Page[i].Equip:GetWide(), Boot.Page[i].Equip:GetTall(), buttoncolor)
				end
				Boot.Page[i].Equip.DoClick = function()
					net.Start( "Handle_Boot" )
					net.WriteInt( Boot.Page[i].Item.co, 32 )
						net.WriteString("EquipItem")
					net.SendToServer()
					Boot:Remove()
				end
			else
				Boot.Page[i].Equip.Paint = function()
					draw.RoundedBox( 0, 0, 0, Boot.Page[i].Equip:GetWide(), Boot.Page[i].Equip:GetTall(), buttoncolordis)
				end
			end
		end
end
net.Receive("Open_Boot", OpenBoot)


