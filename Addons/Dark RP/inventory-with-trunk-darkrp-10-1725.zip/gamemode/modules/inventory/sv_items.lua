MAXINVENTORYSIZE = 20

Items = {}
Items.spawned_shipment = {}
Items.spawned_weapon = {}
Items.spawned_food = {}
Items.money_printer = {name = "Money Printer"}
Items.gunlab = {name = "Gun Lab"}
Items.drug_lab = {name = "Drug Lab"}
