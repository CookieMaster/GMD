--Inventory Saving

function DB.PlayerInvInit( ply )
	local steamid = string.gsub(string.sub(ply:SteamID(), 7), ":", "_")
	
	if (file.Exists("inventory/" .. steamid .. ".txt", "DATA")) then
		DB.LoadInventory( ply )
	else
		local inventory = {}
		inventory.Items = {}
		inventory.size = 20
		ply.Inventory = table.Copy(inventory)
	end
end
hook.Add("PlayerInitialSpawn", "InvInitSpawn", function( ply ) DB.PlayerInvInit( ply ) end)

function DB.SaveInventory( ply )

	local steamid = string.gsub(string.sub(ply:SteamID(), 7), ":", "_")
	local inventory = Serialize(ply.Inventory)
	file.Write("inventory/" .. steamid .. ".txt", inventory)
end

function DB.LoadInventory( ply )
	local steamid = string.gsub(string.sub(ply:SteamID(), 7), ":", "_")
	local inventory = Deserialize(file.Read("inventory/" .. steamid .. ".txt", "DATA"))
	ply.OpenInvEnt = nil
	ply.Inventory = {}
	ply.Inventory = table.Copy(inventory)
	ply.Inventory.size = MAXINVENTORYSIZE or 20
end


hook.Add("InitPostEntity", "InvInitPostEntity", function()
	if (!file.IsDir("inventory", "DATA")) then
		file.CreateDir("inventory")
	end
end)




























local allowedtypes = {}
allowedtypes["string"] = true
allowedtypes["number"] = true
allowedtypes["table"] = true
allowedtypes["Vector"] = true
allowedtypes["Angle"] = true
allowedtypes["boolean"] = true

local function MakeTable(tab, done)
	local str = ""
	local done = done or {}

	local sequential = table.IsSequential(tab)

	for key, value in pairs(tab) do
		local keytype = type(key)
		local valuetype = type(value)

		if allowedtypes[keytype] and allowedtypes[valuetype] then
			if sequential then
				key = ""
			else
				if keytype == "number" or keytype == "boolean" then 
					key ="["..tostring(key).."]="
				else
					key = "["..string.format("%q", tostring(key)).."]="
				end
			end

			if valuetype == "table" and not done[value] then
				done[value] = true
				if type(value._serialize) == "function" then
					str = str..key..value:_serialize()..","
				else
					str = str..key.."{"..MakeTable(value, done).."},"
				end
			else
				if valuetype == "string" then 
					value = string.format("%q", value)
				elseif valuetype == "Vector" then
					value = "Vector("..value.x..","..value.y..","..value.z..")"
				elseif valuetype == "Angle" then
					value = "Angle("..value.pitch..","..value.yaw..","..value.roll..")"
				else
					value = tostring(value)
				end

				str = str .. key .. value .. ","
			end
		end
	end

	if string.sub(str, -1) == "," then
		return string.sub(str, 1, #str - 1)
	else
		return str
	end
end

function Serialize(tIn, bRaw)
	if bRaw then
		return "{"..MakeTable(tIn).."}"
	end

	return "SRL={"..MakeTable(tIn).."}"
end

function Deserialize(sIn)
	SRL = nil

	RunString(sIn)

	return SRL
end