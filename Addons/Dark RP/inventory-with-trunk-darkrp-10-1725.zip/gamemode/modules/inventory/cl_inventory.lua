local bgcolor =           Color(0, 0, 0, 255)         // Color of inventory background
local buttoncolor =       Color(200, 200, 200, 255)   // Color of buttons
local buttoncolordis =    Color(50, 50, 50, 255)      // Color of disabled buttons
local buttontextcolor =   Color(0, 0, 0, 255)         // color of button text

local infotextcolor =     Color(255, 255, 255, 255)   // color of information text (slots used ect)
local itemcolor =         Color(100, 100, 100, 255)   // color of the item 'card'
local itemringcolor =     Color(0, 0, 0, 255)         // color of the ring around the image
local itembgcolor =       Color(155, 155, 155, 255)   // color of the background of the image
local itemtextcolor =     Color(0, 0, 0, 255)         // color of the item's text


--CL
function OpenInventory()
	local Tab = net.ReadTable()
	local Items = Tab.Items
	local Sets = {}
	Sets[0] = {}
	local pages = 0
	for k,v in pairs(Items) do
		if(#Sets[pages] == 5 ) then
			pages = pages + 1
			Sets[pages] = Sets[pages] or {}
		end
		v.co = k
		table.insert(Sets[pages], v)
	end
	local page = 0
	local Inventory = vgui.Create( "DFrame" )
		Inventory:SetSize( 1000, 300 )
		Inventory:SetTitle("")
		Inventory:SetVisible( true )
		Inventory:SetDraggable( false )
		Inventory:ShowCloseButton( true ) 
		Inventory:Center()
		Inventory:MakePopup()
		Inventory.Paint = function()
			draw.RoundedBox( 8, 0, 0, Inventory:GetWide(), Inventory:GetTall(), bgcolor)
			draw.DrawText(#Items.."/"..Tab.size .. " Slots Used", "Default", 992, 25, infotextcolor, TEXT_ALIGN_RIGHT )
			draw.DrawText("Page: " .. page .. "/" .. pages , "Default", 990, 50, infotextcolor, TEXT_ALIGN_RIGHT )
		end
		Inventory.Page = {}
		Inventory.LoadPage = function()
		
			for k,v in pairs(Inventory.Page) do
				if(Inventory.Page[k].Panel) then
					Inventory.Page[k].Panel:Remove()
					Inventory.Page[k].Panel = nil
				end
			end
			
			local ItemsOnPage = table.Copy(Sets[page])

			for i=1, #ItemsOnPage do
				Inventory.Page[i] = {}
				Inventory.Page[i].Item = table.Copy(ItemsOnPage[i])
				Inventory.Page[i].Panel = vgui.Create("DPanel", Inventory)
				Inventory.Page[i].Panel:SetSize( 175, 290 )
				Inventory.Page[i].Panel:SetPos(180*(i-1) + 5, 5 )
				Inventory.Page[i].Panel.Paint = function()
				draw.RoundedBox( 8, 0, 0, 175, 290, itemcolor)
				draw.RoundedBox( 8, 2.5, 2.5, 169, 169, itemringcolor)
				draw.RoundedBox( 8, 5, 5, 165, 165, itembgcolor)
					if(Inventory.Page[i].Item.class == "spawned_shipment") then
						draw.DrawText( "Name: " .. Inventory.Page[i].Item.name .. " Shipment", "Default", 5, 175, itemtextcolor, TEXT_ALIGN_LEFT )
						draw.DrawText( "Contains: " .. Inventory.Page[i].Item.count .. " Items", "Default", 5, 190, itemtextcolor, TEXT_ALIGN_LEFT )
					elseif(Inventory.Page[i].Item.class == "spawned_weapon") then
						draw.DrawText( "Name: " .. Inventory.Page[i].Item.name .. " Shipment", "Default", 5, 175, itemtextcolor, TEXT_ALIGN_LEFT )
						if Inventory.Page[i].Item.amount then
							draw.DrawText( "Amount: " .. Inventory.Page[i].Item.amount .. " Guns", "Default", 5, 190, itemtextcolor, TEXT_ALIGN_LEFT )
						end
					else
						draw.DrawText( "Name: " .. Inventory.Page[i].Item.name, "Default", 5, 175, itemtextcolor, TEXT_ALIGN_LEFT )
					end
					
				end	

				Inventory.Page[i].Icon = vgui.Create( "DModelPanel", Inventory.Page[i].Panel )
				Inventory.Page[i].Icon:SetPos( 5, 5 )
				Inventory.Page[i].Icon:SetSize( 165, 165 )
				Inventory.Page[i].Icon:SetLookAt(Vector(0,0,0))
				local model = Inventory.Page[i].Item.model
				local class = Inventory.Page[i].Item.class
				if(class == "spawned_shipment") then
					Inventory.Page[i].Icon:SetModel("models/Items/item_item_crate_dynamic.mdl")
					Inventory.Page[i].Icon:SetFOV(40)
					Inventory.Page[i].Icon:SetLookAt(Vector(0,0,10))
				elseif(class == "spawned_weapon") then
					Inventory.Page[i].Icon:SetModel(model or "models/Items/item_item_crate_chunk06.mdl")
					Inventory.Page[i].Icon:SetFOV(30)
				else
					Inventory.Page[i].Icon:SetModel(model or "models/Items/item_item_crate_chunk06.mdl")
					Inventory.Page[i].Icon:SetFOV(40)
				end
				
				Inventory.Page[i].Drop = vgui.Create( "DButton", Inventory.Page[i].Panel )
				Inventory.Page[i].Drop:SetPos( 5, 260 )
				Inventory.Page[i].Drop:SetSize( 165, 25 )
					local pos = LocalPlayer():GetShootPos()
					local ang = LocalPlayer():GetAimVector()
					local tracedata = {}
					tracedata.start = pos
					tracedata.endpos = pos + (ang * 100)
					tracedata.filter = LocalPlayer()
					local trace = util.TraceLine(tracedata)
				if (trace.HitNonWorld and trace.Entity:IsVehicle()) then
					Inventory.Page[i].Drop:SetText( "Place In Boot" )
				else
					Inventory.Page[i].Drop:SetText( "Drop Item" )
				end
				Inventory.Page[i].Drop.Paint = function()
					draw.RoundedBox( 4, 0, 0, Inventory.Page[i].Drop:GetWide(), Inventory.Page[i].Drop:GetTall(), buttoncolor)
				end
				Inventory.Page[i].Drop:SetTextColor(buttontextcolor)
				Inventory.Page[i].Drop.DoClick = function()
					net.Start( "Handle_Item" )
					net.WriteInt( Inventory.Page[i].Item.co, 32 )
					net.WriteString("Drop")
					net.SendToServer()
					Inventory:Remove()
				end
				 
				Inventory.Page[i].Equip = vgui.Create( "DButton", Inventory.Page[i].Panel )
				Inventory.Page[i].Equip:SetPos( 5, 230 )
				Inventory.Page[i].Equip:SetSize( 165, 25 )
				Inventory.Page[i].Equip:SetText( "Equip Item" )	
				Inventory.Page[i].Equip:SetTextColor(buttontextcolor)				
				if(class == "spawned_weapon") then
					Inventory.Page[i].Equip.Paint = function()
						draw.RoundedBox( 4, 0, 0, Inventory.Page[i].Equip:GetWide(), Inventory.Page[i].Equip:GetTall(), buttoncolor)
					end
					Inventory.Page[i].Equip.DoClick = function()
						net.Start( "Handle_Item" )
						net.WriteInt( Inventory.Page[i].Item.co, 32 )
						net.WriteString("Equip")
						net.SendToServer()
						Inventory:Remove()
					end
				else
					Inventory.Page[i].Equip.Paint = function()
						draw.RoundedBox( 4, 0, 0, Inventory.Page[i].Equip:GetWide(), Inventory.Page[i].Equip:GetTall(), buttoncolordis)
					end
				end
			end
		end
		Inventory:LoadPage()
		

		
	local NextPage = vgui.Create( "DButton", Inventory)
		NextPage:SetPos( 905, 240 )
		NextPage:SetSize( 90, 25 )
		NextPage:SetText("Next Page")
		NextPage:SetTextColor(buttontextcolor)
		NextPage.Paint = function()
			draw.RoundedBox( 4, 0, 0, NextPage:GetWide(), NextPage:GetTall(), buttoncolor)
		end
		NextPage.DoClick = function()
			if(page < pages) then
				page = page + 1
				Inventory.LoadPage(page)
			end
		end
		
	local LastPage = vgui.Create( "DButton", Inventory)
		LastPage:SetPos( 905, 270 )
		LastPage:SetSize( 90, 25 )
		LastPage:SetText("Last Page")
		LastPage:SetTextColor(buttontextcolor)
		LastPage.Paint = function()
			draw.RoundedBox( 4, 0, 0, LastPage:GetWide(), LastPage:GetTall(), buttoncolor)
		end
		LastPage.DoClick = function()
			if(page > 0) then
				page = page - 1
				Inventory.LoadPage()
			end
		end

end
net.Receive("Open_Inventory", OpenInventory)