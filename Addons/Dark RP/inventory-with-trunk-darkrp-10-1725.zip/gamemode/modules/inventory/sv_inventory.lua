--SV
util.AddNetworkString("Open_Inventory")
util.AddNetworkString("Handle_Item")


local meta = FindMetaTable("Player")

function meta:OpenInventory()
	net.Start("Open_Inventory")
	net.WriteTable(self.Inventory)
	net.Send(self)
end

hook.Add("PlayerSpawn", "GiveInventorySwep", function(ply)
	ply:Give("inventory")
end)

hook.Add("OnPlayerChangedTeam", "GiveInventorysw", function(ply)
	timer.Simple(0.25, function() ply:Give("inventory") end)
end)

function meta:Pickup(ent)
	local ply = self
	if (!Items[ent:GetClass()]) then return false end
	if (ply.NextPickup and ply.NextPickup > CurTime()) then return end
		ply.NextPickup = CurTime() + 0.2
	
	if (#ply.Inventory.Items >= ply.Inventory.size) then
		ply:ChatPrint("Your inventory is full.")
		return
	end
	
	if (ent:GetClass() == "spawned_shipment") then
		local id = ent:Getcontents()
		local shipment = CustomShipments[id]
	
		ply:AddItem({
			class = "spawned_shipment",
			name = shipment.name,
			count = ent:Getcount(),
			id = ent:Getcontents()
		})
	elseif (ent:GetClass() == "spawned_weapon") then
		local class = ent.weaponclass
		local weapon = {}
			for _, v in pairs (CustomShipments) do
			if (v.entity == class) then
				weapon = v
				break
			end
		end
		if (ent.PlayerUse) then return false end
		local theamount = weapon.dt.amount or 1
		ply:AddItem({
			class = "spawned_weapon",
			amount =  theamount,
			name = weapon.name,
			model = weapon.model,
			weaponclass = class
		})
	elseif (ent:GetClass() == "spawned_food") then
		ply:AddItem({
			class = "spawned_food",
			name = "Food",
			model = ent:GetModel(),
			foodenergy = ent.FoodEnergy
		})
	else		
		ply:AddItem({ 
			class = ent:GetClass(),
			name = Items[ent:GetClass()].name,
			model = ent:GetModel()
		})
	end
	ply:EmitSound(Sound("weapons/zoom.wav"))
	ent:Remove()
	return false
end

function meta:AddItem(tab)
	self.Inventory.Items = self.Inventory.Items or {}
	table.insert(self.Inventory.Items, tab)
	DB.SaveInventory( self )
end

concommand.Add("ClearInv", function(ply) 
	ply.Inventory.Items = {}
end)

function meta:DropItem(itemnum) 
	local itemtable = self.Inventory.Items[itemnum]
	local class = itemtable.class
	local spawned = ents.Create(class)
	if(class == "spawned_shipment") then
		spawned:SetModel("models/Items/item_item_crate.mdl")
		spawned:Setcount(itemtable.count)
		spawned:Setcontents(itemtable.id)
	elseif(class == "spawned_weapon") then
		spawned.weaponclass = itemtable.weaponclass
		spawned.dt.amount = itemtable.amount or 1
		spawned:SetModel(itemtable.model)
	elseif(class == "spawned_food") then
		spawned.FoodEnergy = itemtable.foodenergy	
		spawned:SetModel(itemtable.model)
	else
		spawned.dt.owning_ent = self
		spawned:SetModel(itemtable.model)
	end
	local pos = self:GetShootPos()
	local ang = self:GetAimVector()
	local tracedata = {}
	tracedata.start = pos
	tracedata.endpos = pos + (ang * 100)
	tracedata.filter = self
	local trace = util.TraceLine(tracedata)
	spawned:SetPos(trace.HitPos)
	spawned:Spawn()
	table.remove(self.Inventory.Items, itemnum)
	DB.SaveInventory( self )
end

net.Receive("Handle_Item", function(ln, ply)
	local id = net.ReadInt(32)
	local ty = net.ReadString()
	
	if(ty == "Drop") then
		local trace = util.GetPlayerTrace( ply )
		local traceRes = util.TraceLine( trace )
		if traceRes.HitNonWorld then
			if IsValid(traceRes.Entity) and traceRes.Entity:IsVehicle() and !traceRes.Entity.Locked then
				if( traceRes.Entity:AddItem(ply.Inventory.Items[id]) ) then
					table.remove(ply.Inventory.Items, id)
				end
			else
				ply:DropItem(id)
			end
		else
			ply:DropItem(id)
		end
		
	elseif(ty == "Equip") then
		if(ply.Inventory.Items[id].class == "spawned_weapon") then
			ply:Give(ply.Inventory.Items[id].weaponclass)
			ply:ChatPrint("Your have equipped this weapon.")
			table.remove(ply.Inventory.Items, id)
			
		end
	end
	DB.SaveInventory( ply )
end)