Description

Searchable dumpsters is a DarkRP entity that will allow any classes that you want to be able to use a dumpster and search it for goods. The amount of items that come out of the dumpster can all be set by you. After a player searches the dumpster there will then be a cooldown time that is placed above the dumpster, during this time the dumpster will be unable to be used.

Installation

Simply put the entire "dumpster" folder into "garrysmod/gamemodes/darkrp/entities/entities" and you are done!

Configuration

You can edit many features of the dumpster at the top of the "dumpsters/init.lua" file. Each thing that you can edit will have a comment explaining what it does. Here are some things you can easily edit

-Time of cooldown on dumpster
-Minimum amount of items that can shoot out of dumpster
-Maximum amount of items that can shoot out of dumpster
-Chances that a Prop/Weapon/Entity will shoout out of dumpster
-Teams allowed to use dumpster
-Contents of dumpster
-Placement/Addition of dumpster spawns(All you need to find out is the position and angles of where you want it to be, type "getpos" in console
Contact

If there are any problems feel free to add me on steam/pm me on here or whatever. I will be more than glad to help!