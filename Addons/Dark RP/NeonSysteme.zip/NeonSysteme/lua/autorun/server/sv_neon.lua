/*---------------------------------------------------------
   Neon Systeme By Malboro for CoderHire
---------------------------------------------------------*/

AddCSLuaFile("autorun/client/cl_neon.lua")
require("glon")

/*---------------------------------------------------------
   Declaration Net
---------------------------------------------------------*/

util.AddNetworkString("NeonMenu")
util.AddNetworkString("BuyNeon")

/*---------------------------------------------------------
   Config !
---------------------------------------------------------*/

neon_darkrp = false
neon_darkrp_price = 100
neon_db_name = "NeonShopSave"

/*---------------------------------------------------------
   Install Sql
---------------------------------------------------------*/

sql.Query("CREATE TABLE IF NOT EXISTS ".. sql.SQLStr(neon_db_name) .."('id' INTEGER NOT NULL, 'Map' TEXT NOT NULL, 'Content' TEXT NOT NULL, PRIMARY KEY('id'));")

/*---------------------------------------------------------
   Save/Remove/Spawn Systeme
---------------------------------------------------------*/

local function SaveNeonShop( ply )

	if not ply:IsSuperAdmin() then ply:ChatPrint("You don't have acces on this command !") return end
	
	local ent = ply:GetEyeTrace().Entity

	if not ent:IsValid() or ent:GetClass() != "neonshop" then ply:ChatPrint("This is not a NeonShop !") return end

	if ent.NeonShopID then ply:ChatPrint("Already saved !") return end

	local content = {}
	content.Pos = ent:GetPos()
	content.Ang = ent:GetAngles()
	content.Color = ent:GetColor()
	content.Model = ent:GetModel()
	content.Material = ent:GetMaterial()

	sql.Query("INSERT INTO ".. sql.SQLStr(neon_db_name) .." (id, Map, Content) VALUES(NULL ,".. sql.SQLStr(game.GetMap()) ..", ".. sql.SQLStr(glon.encode(content)) ..");")

	ent:Remove()

	ReloadNeonShop()

end
concommand.Add("SaveNeonShop", SaveNeonShop)

local function RemoveNeonShop( ply )

	if not ply:IsSuperAdmin() then ply:ChatPrint("You don't have acces on this command !") return end
	
	local ent = ply:GetEyeTrace().Entity

	if not ent:IsValid() or ent:GetClass() != "neonshop" then ply:ChatPrint("This is not a NeonShop !") return end

	if not ent.NeonShopID then ply:ChatPrint("Not saved !") return end

	sql.Query("DELETE FROM ".. sql.SQLStr(neon_db_name) .." WHERE id = ".. sql.SQLStr(ent.NeonShopID) ..";")

	ReloadNeonShop()

end
concommand.Add("RemoveNeonShop", RemoveNeonShop)

local function SpawnNeonShop( ply, cmd, arg )

	if not ply:IsSuperAdmin() then ply:ChatPrint("You don't have acces on this command !") return end

	if not arg[1] then ply:ChatPrint("Syntax: SpawnNeonShop \"MODEL\"") return end

	local ent = ents.Create("NeonShop")
	ent:SetPos(ply:GetEyeTrace().HitPos)
	ent:SetModel(arg[1])
	ent:Spawn()

end
concommand.Add("SpawnNeonShop", SpawnNeonShop)

function ReloadNeonShop()

	for k, v in pairs(ents.GetAll()) do
		
		if v.NeonShopID then
			
			v:Remove()

		end

	end

	local content = sql.Query( "SELECT * FROM ".. sql.SQLStr(neon_db_name) .." WHERE Map = ".. sql.SQLStr(game.GetMap()) ..";" )

	if not content then return end
	
	for k, v in pairs(content) do

		local data = glon.decode(v.Content)
		
		local ent = ents.Create("NeonShop")
		ent:SetPos(data.Pos)
		ent:SetAngles(data.Ang)
		ent:SetColor(data.Color)
		ent:SetModel(data.Model)
		ent:SetMaterial(data.Material)
		ent.NeonShopID = v.id
		ent:Spawn()
		ent:SetMoveType(0)

	end

end

timer.Simple(1, function()

	ReloadNeonShop()

end)

/*---------------------------------------------------------
   Neon Buy/Spawn Systeme
---------------------------------------------------------*/

local function BuyNeon( um, ply )

	local color = net.ReadTable()
	local ent = ply:GetVehicle()

	if not ent:IsValid() or not ent:IsVehicle() then return end

	if neon_darkrp and neon_darkrp_price then
		
		if ply:CanAfford(neon_darkrp_price) then
			
			ply:AddMoney(-neon_darkrp_price)

		else

			ply:ChatPrint("You can't buy this !")

			return

		end

	end
	
	if ent.NeonA and ent.NeonB then
		
		ent.NeonA.dt.neonr = color.r
		ent.NeonA.dt.neong = color.g
		ent.NeonA.dt.neonb = color.b

		ent.NeonB.dt.neonr = color.r
		ent.NeonB.dt.neong = color.g
		ent.NeonB.dt.neonb = color.b


	else

		local Neon1 = ents.Create( "neon_light" )
		Neon1:SetPos( ent:LocalToWorld( Vector( 0, 20, 22 ) ) )
		Neon1:SetAngles( ent:GetAngles() + Angle( 0, 90, 0 ) )
		Neon1:DeleteOnRemove( ent )	
		Neon1:SetParent( ent )
		Neon1:Spawn()
		ent.NeonA = Neon1
		Neon1.dt.neonr = color.r
		Neon1.dt.neong = color.g
		Neon1.dt.neonb = color.b

		local Neon2 = ents.Create( "neon_light" )
		Neon2:SetPos( ent:LocalToWorld( Vector( 0, -20, 30 ) ) )
		Neon2:SetAngles( ent:GetAngles() + Angle( 0, 90, 0 ) )
		Neon2:DeleteOnRemove( ent )	
		Neon2:SetParent( ent )
		Neon2:Spawn()
		ent.NeonB = Neon2
		Neon2.dt.neonr = color.r
		Neon2.dt.neong = color.g
		Neon2.dt.neonb = color.b

	end

	ply:EmitSound("ambient/machines/pneumatic_drill_4.wav", 100, 100)

end
net.Receive("BuyNeon", BuyNeon)