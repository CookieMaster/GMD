/*---------------------------------------------------------
   Neon Systeme By Malboro for CoderHire
---------------------------------------------------------*/

local function NeonMenu()

	local DFrame1 = vgui.Create( "DFrame" ) 
	DFrame1:SetSize( 300, 300 ) 
	DFrame1:SetTitle( "Neon Shop" ) 
	DFrame1:SetVisible( true )
	DFrame1:ShowCloseButton( false ) 
	DFrame1:MakePopup() 
	DFrame1:Center()
	DFrame1.Paint = function()
		draw.RoundedBox(0, 0, 0, DFrame1:GetWide(), DFrame1:GetTall(), Color(0,0,0,220))
		surface.SetDrawColor(0, 0, 0)
		surface.DrawOutlinedRect(0, 0, DFrame1:GetWide(), DFrame1:GetTall())	

		draw.RoundedBox(0, 0, 0, DFrame1:GetWide(), 25, Color(0, 0, 0, 200))
		surface.SetDrawColor(0, 0, 0)
		surface.DrawOutlinedRect(0, 0, DFrame1:GetWide(), 25)
	end
		
	local color = vgui.Create( "DColorMixer", DFrame1)
	color:SetSize( 260, 200)
	color:SetPos( 25, 30 )
	color:SetColor(Color(255,0,255,255))

	local DButton1 = vgui.Create("DButton", DFrame1)
	DButton1:SetSize(93, 20)
	DButton1:SetPos(200, 256)
	DButton1:SetText("Cancel !")
	DButton1.DoClick = function()

		DFrame1:Close()

	end

	local DButton2 = vgui.Create("DButton", DFrame1)
	DButton2:SetSize(140, 20)
	DButton2:SetPos(29, 256)
	DButton2:SetText("Install Neon !")
	DButton2.DoClick = function()

		net.Start("BuyNeon")
		net.WriteTable(color:GetColor())
		net.SendToServer()

		DFrame1:Close()
	end

end
net.Receive( "NeonMenu", NeonMenu )