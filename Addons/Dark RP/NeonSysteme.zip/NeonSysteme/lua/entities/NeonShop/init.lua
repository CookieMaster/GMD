AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()

	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)

end

function ENT:StartTouch( ent )

	if not ent:IsVehicle() or not ent:GetDriver() then return end
	
	local ply = ent:GetDriver()

	net.Start("NeonMenu")
	net.Send(ply)

end
