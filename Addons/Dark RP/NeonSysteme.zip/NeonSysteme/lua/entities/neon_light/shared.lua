ENT.Type = "anim"
ENT.PrintName = "Neon Light"
ENT.Author = "Malboro"
ENT.Spawnable = false
ENT.AdminSpawnable = false

function ENT:SetupDataTables()
	self:DTVar("Int",0,"neonr")
	self:DTVar("Int",1,"neong")
	self:DTVar("Int",2,"neonb")
end