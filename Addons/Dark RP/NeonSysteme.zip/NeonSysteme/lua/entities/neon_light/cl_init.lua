include("shared.lua")

function ENT:Think()
    local neonlight = DynamicLight( self:EntIndex() )
	if ( neonlight ) then
		neonlight.Pos = self:GetPos()
		neonlight.r = self.dt.neonr
		neonlight.g = self.dt.neong
		neonlight.b = self.dt.neonb
		neonlight.Brightness = 1.5
		neonlight.Size = 136
		neonlight.Decay = 5
		neonlight.DieTime = CurTime() + 1
	end   
end