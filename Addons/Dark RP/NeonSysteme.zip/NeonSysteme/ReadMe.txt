How To Use
1. Unzip the .zip into your Addons Folder
2. Connect to your server
3. Type SpawnNeonShop "models/hunter/plates/plate2x2.mdl" ( or other ) in your console
4. Place your entity shop who you want
5. Look at your entity and type SaveNeonShop in your console for save your entity
6. If you want remove your entity you can, look at your entity and type RemoveNeonShop
7. Take a vehicle and running into the entity for open the Shop
8. You can config for darkrp server in (Addons/NeonSysteme/lua/autorun/server/sv_neon.lua) line 18 - 20

Malboro ;)