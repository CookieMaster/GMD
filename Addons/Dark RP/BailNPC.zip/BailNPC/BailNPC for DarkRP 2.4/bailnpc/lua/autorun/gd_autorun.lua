MsgN("Initializing Bail NPC by Wolf Haley")

if SERVER then
	include("npcspawns.lua" )
end