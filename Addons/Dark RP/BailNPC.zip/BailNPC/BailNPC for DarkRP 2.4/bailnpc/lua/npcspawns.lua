

local function Init_TriggerLogic()
	local map = game.GetMap()
	local ent = ents.Create("npc_bail")
	ent:SetPos( BAIL.PositionNPC or Vector( 0, 0, 0 ) )
	ent:SetAngles( BAIL.AngleNPC or Angle(0, 0, 0.000000) )
	ent:Spawn()
	ent:DropToFloor()
end
hook.Add( "InitPostEntity", "MapStartTrigger", Init_TriggerLogic )

print( "NPC Bail Init" )