include('shared.lua')

surface.CreateFont( "BailTitleFont", {
 font = "Bebas Neue",
 size = 30
} )

surface.CreateFont( "BailNameFont", {
 font = "Bebas Neue",
 size = 46,
 weight = 0
} )

surface.CreateFont( "BailNameFontSmall", {
 font = "Bebas Neue",
 size = 34,
 weight = 0
} )

surface.CreateFont( "BailJobFont", {
 font = "Bebas Neue",
 size = 22,
 weight = 0
} )

surface.CreateFont( "BailOverheadFont", {
 font = "Bebas Neue",
 size = 80
} )

function ENT:Initialize()
	
	self.Color = Color( 255, 255, 255, 255 )
	
end

function ENT:Draw()
	self.Entity:DrawModel()
	
	  //The amount to display
	local amount = 10
	
	local Pos = self:GetPos()
	local Ang1 = Angle( 0, 0, 90 )
	local Ang2 = Angle( 0, 0, 90 )
	
	Ang1:RotateAroundAxis( Ang1:Right(), self.rotate )
	Ang2:RotateAroundAxis( Ang2:Right(), self.rotate + 180 )

	//Draws front
	cam.Start3D2D( Pos, Ang1, 0.2 )
		draw.DrawText( "$ "..amount, "BailOverheadFont", 0, -50, Color( 0, 255, 0, 255 ),TEXT_ALIGN_CENTER )
	cam.End3D2D()
	
	//Draws back
	cam.Start3D2D( Pos + Ang2:Up() * 0, Ang2, 0.2 )
		draw.DrawText( "$ "..amount, "BailOverheadFont", 0, -50, Color( 0, 255, 0, 255 ),TEXT_ALIGN_CENTER )
	cam.End3D2D()
	
	//Resets the rotation
	if( self.rotate > 359 ) then self.rotate = 0 end
	
	//Rotates
	self.rotate = self.rotate - ( 100*( self.lasttime-SysTime() ) )
	self.lasttime = SysTime()
end

local function OpenBailMenu()
	local BailMain = vgui.Create( "DFrame" )
	BailMain:SetSize( 610, 450 )
	BailMain:Center()
	BailMain:SetDraggable( false )
	BailMain:MakePopup()
	BailMain:SetTitle( "" )
	BailMain:ShowCloseButton( false )
	BailMain.Paint = function( self, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color( 150, 150, 150 ) )
		draw.RoundedBox( 0, 1, 1, w - 2, h - 2, Color( 252, 252, 252 ) )
		
		surface.SetDrawColor( Color( 224, 224, 224, 255 ) )
			surface.DrawLine( 0, 20, w, 50 )
			
			draw.RoundedBox( 0, 0, 0, w, 50, Color( 51, 54, 58, 255 ) )
			
			draw.RoundedBox( 0, 1, 1, w - 2, 50 - 2, Color( 62, 67, 77 ) )
			
			surface.SetDrawColor( Color( 84, 89, 100, 255 ) )
			surface.DrawLine( 1, 1, w - 1, 1 )
			surface.DrawLine( 1, 1, 1, 50 )
			surface.DrawLine( 1, 48, w - 1, 48 )
			surface.DrawLine( w - 2, 1, w - 2, 50 )
	end
	
	local Title = vgui.Create( "DLabel", BailMain )
	Title:SetPos( 16, 12 )
	Title:SetTextColor( Color( 252, 252, 252 ) )
	Title:SetFont( "BailTitleFont" )
	Title:SetText( BAIL.WindowTitle or "Bail Bondsman" )
	Title:SizeToContents()
	
	local cl = vgui.Create( "DButton", BailMain )
	cl:SetSize( 50, 20 )
	cl:SetPos( BailMain:GetWide() - 60, 0 )
	cl:SetText( "X" )
	cl:SetFont( "fontclose" )
	cl:SetTextColor( Color( 255, 255, 255, 255 ) )
	cl.Paint = function( self, w, h )
		local kcol
		if self.hover then
			kcol = Color( 255, 150, 150, 255 )
		else
			kcol = Color( 175, 100, 100 )
		end
		draw.RoundedBoxEx( 0, 0, 0, w, h, Color( 255, 150, 150, 255 ), false, false, true, true )
		draw.RoundedBoxEx( 0, 1, 0, w - 2, h - 1, kcol, false, false, true, true )
	end
	cl.DoClick = function()
		BailMain:Close()
		textOpen = false
		net.Start( "Close" )
		net.SendToServer()
	end
	cl.OnCursorEntered = function( self )
		self.hover = true
	end
	cl.OnCursorExited = function( self )
		self.hover = false
	end
	
	local noPlayers = false
	
	local function NoArrestedPlayers()
		noPlayers = true
		local NoPlayers = vgui.Create( "DLabel", BailMain )
		NoPlayers:SetText( "The jail is currently empty!" )
		NoPlayers:SetFont( "BailNameFont" )
		NoPlayers:SetTextColor( Color( 200, 200, 200 ) )
		NoPlayers:SizeToContents()
		NoPlayers:Center()
	end
	
	local BailList = vgui.Create( "DPanelList", BailMain )
	BailList:SetPos( 10, 60 )
	BailList:SetSize( BailMain:GetWide() - 20, BailMain:GetTall() - 80 )
	BailList:SetSpacing( 2 )
	BailList:EnableVerticalScrollbar( true )
	BailList.VBar.Paint = function( s, w, h )
		draw.RoundedBox( 4, 3, 13, 8, h-24, Color(0,0,0,70))
	end
	BailList.VBar.btnUp.Paint = function( s, w, h ) end
	BailList.VBar.btnDown.Paint = function( s, w, h ) end
	BailList.VBar.btnGrip.Paint = function( s, w, h )
		draw.RoundedBox( 4, 5, 0, 4, h+22, Color(0,0,0,70))
	end
	
	local ArrestFee
	local arrestedplayers = {}
	
	for key, value in pairs( player.GetAll() ) do
		if value:getDarkRPVar( "Arrested" ) then
			table.insert( arrestedplayers, value )
		end
	end
	
	if table.Count( arrestedplayers ) != 0 then
	for k, v in pairs( arrestedplayers ) do
		local PlayerMain = vgui.Create( "DFrame" )
		PlayerMain:SetSize( BailList:GetWide(), 100 )
		PlayerMain:ShowCloseButton( false )
		PlayerMain:SetTitle( "" )
		PlayerMain.Paint = function( self, w, h )
		
			local nameFont
			local nameOffset
		
			surface.SetFont( "BailNameFont" )
			local BailName = v:Name()
			local Width, Height = surface.GetTextSize(v:Name())
			if Width > 100 then
				nameFont = "BailNameFontSmall"
				nameOffset = 8
			else
				nameFont = "BailNameFont"
				nameOffset = 0
			end
			
			if nameFont == "BailNameFontSmall" and Width > 100 then
				BailName = string.sub( v:Name(), 1, 18 )..".."
			end
		
			local timeLeft = math.Round(v:GetNWFloat( "ArrestLength" ) - (math.abs(v:GetNWFloat( "TimeArrested" ) - CurTime())))
			ArrestFee = timeLeft * BAIL.DollarsPerSecond
			draw.RoundedBox( 0, 0, 0, w, h, Color( 231, 232, 234 ) )
			draw.RoundedBox( 0, 1, 1, w - 2, h - 2, Color( 252, 252, 252 ) )
			draw.RoundedBox( 4, 14, 14, 66, 66, Color( 140, 140, 140, 255 ) )
			draw.SimpleText( BailName, nameFont, 84, 8 + nameOffset, Color( 0, 0, 0 ) )
			draw.SimpleText( "Job: "..team.GetName(v:Team()), "BailJobFont", 84, 44, Color( 0, 0, 0, 200 ) )
			draw.SimpleText( "Arrested by: "..v:GetNWEntity( "Arrester" ):Name(), "BailJobFont", 84, 62, Color( 0, 0, 0, 200 ) )
			draw.SimpleText( "Time Remaining: "..tostring(timeLeft).." seconds", "BailJobFont", w - 140, 14, Color( 0, 0, 0, 255 ), TEXT_ALIGN_RIGHT )
			draw.SimpleText( "Fee: $"..tostring(ArrestFee), "BailJobFont", w - 140, 30, Color( 0, 0, 0, 200 ), TEXT_ALIGN_RIGHT )
		end
		
		local ava = vgui.Create( "AvatarImage", PlayerMain )
		ava:SetPos( 15, 15 )
		ava:SetSize( 64, 64 )
		ava:SetPlayer( v, 64 )
		
		local icon = vgui.Create("DModelPanel", PlayerMain)
			icon:SetPos( PlayerMain:GetWide() - 128, 4 )
			local IconModel = v:GetModel()
			icon:SetModel(IconModel)
			icon:SetSize( 100, 80 )
			local ent = icon:GetEntity()
            local headPos = ent:GetBonePosition(ent:LookupBone("ValveBiped.Bip01_Head1"))
            ent:SetEyeTarget(Vector(20, 00, 65)) -- otherwise the model will have its eyes pointing down
            icon:SetCamPos(Vector(16, 10, 65))
            icon:SetLookAt(headPos) -- look at the head of the model
			
			icon:SetAnimated(false)
            function icon:LayoutEntity() end --disable rotation
			local oldpaint = icon.Paint
			function icon:Paint()
				
				local x2, y2 = BailList:LocalToScreen( 0, 0 )
				local w2, h2 = BailList:GetSize()
				render.SetScissorRect( x2, y2, x2 + w2, y2 + h2, true )

				oldpaint( self )
		
				render.SetScissorRect( 0, 0, 0, 0, false )
			end
			
		local BailButton = vgui.Create( "DButton", PlayerMain )
		BailButton:SetPos( PlayerMain:GetWide() - 114, PlayerMain:GetTall() - 26 )
		BailButton:SetSize( 80, 20 )
		BailButton:SetDrawOnTop( true )
		BailButton:SetTextColor( Color( 255, 255, 255 ) )
		BailButton:SetText( "Bail Out" )
		BailButton.Paint = function( self, w, h )
				local gcol
				if self.hover then
					gcol = Color( 36, 190, 255 )
				else
					gcol = Color( 26, 160, 212 )
				end
				draw.RoundedBox( 0, 0, 0, w, h, Color( 22, 131, 173 ) )
				draw.RoundedBox( 0, 1, 1, w - 2, h - 2, gcol )
				
				surface.SetDrawColor( Color( 31, 191, 255, 255 ) )
				surface.DrawLine( 1, 1, w - 1, 1 )
				surface.DrawLine( 1, 1, 1, 20 )
				surface.DrawLine( 1, 18, w - 1, 18 )
				surface.DrawLine( w - 2, 1, w - 2, 20 )
			end
		BailButton.DoClick = function()
			if LocalPlayer():getDarkRPVar( "money" ) > ArrestFee then
			net.Start( "BailOut" )
				net.WriteEntity( v )
				net.WriteEntity( LocalPlayer() )
				net.WriteFloat( ArrestFee )
			net.SendToServer()
			BailMain:Close()
			if BAIL.PlayBailSound then
				surface.PlaySound(BAIL.BailSound)
			end
			else
				chat.AddText( Color( 255, 255, 255 ), "You cannot afford this!" )
			end
		end
			
			
		BailList:AddItem( PlayerMain )			
	end
	else
		NoArrestedPlayers()
	end
end
usermessage.Hook( "OpenBailMenu", OpenBailMenu )

local function DrawNPCText()
	for k, v in pairs( ents.FindByClass( "npc_bail" ) ) do
		
		local p
		
		if BAIL.BounceOverheadText then
			p = v:GetPos() + Vector(0,0,90 + math.sin(CurTime()*3)*5)
		else
			p = v:GetPos() + Vector(0,0,90)
		end
		
	
		for _,yaw in pairs({0, 180}) do
	
			local a = Angle(0, 0, 0)
			a:RotateAroundAxis(a:Forward(), 90)
			a:RotateAroundAxis(a:Right(), yaw)
			if BAIL.RotateOverheadText then
				a:RotateAroundAxis(a:Right(), CurTime() * BAIL.RotateOverheadSpeed)
			else
				a:RotateAroundAxis(a:Right(), 90)
			end
		
			render.PushFilterMag(TEXFILTER.ANISOTROPIC)
			render.PushFilterMin(TEXFILTER.ANISOTROPIC)
			cam.Start3D2D(p, a, 0.1)
				draw.DrawText(BAIL.OverheadText or "Bail Bondsman", "BailOverheadFont", 0, 0, BAIL.OverheadTextColor or Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			cam.End3D2D()
			render.PopFilterMag()
			render.PopFilterMin()
		end
	end
end
hook.Add( "PostDrawOpaqueRenderables", "Draw NPC Title", DrawNPCText )