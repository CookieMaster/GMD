ENT.Base = "base_ai" -- This entity is based on "base_ai"
ENT.Type = "ai" -- What type of entity is it, in this case, it's an AI.
ENT.AutomaticFrameAdvance = true -- This entity will animate itself.
 
function ENT:SetAutomaticFrameAdvance( bUsingAnim ) -- This is called by the game to tell the entity if it should animate itself.
	self.AutomaticFrameAdvance = bUsingAnim
end

--Do not change this
isOpen = false

BAIL = {}

BAIL.PositionNPC = Vector( -1422.53, 175.93, -131.97 ) --This is for rp_downtown_v4c_v2
BAIL.AngleNPC = Angle( 0, 0, 0 ) --This is for rp_downtown_v4c_v2

--Title text of menu that appears when pressing E
BAIL.WindowTitle = "Bail Bondsman"

--How much money to charge for each second left for the player ( Example: $2/second, 200 seconds left, $400 )
BAIL.DollarsPerSecond = 2

--Settings for the text above the NPC's head
BAIL.OverheadTextColor = Color( 255, 255, 255, 255 ) //Color
BAIL.OverheadText = "Bail Bondsman" //Text
BAIL.RotateOverheadSpeed = 15 //How fast rotation spins
BAIL.RotateOverheadText = true //Make false if you want no rotation
BAIL.BounceOverheadText = true //Make false if you dont want it to bounce

BAIL.NPCModel = "models/Humans/Group03/male_06.mdl" //Model of the NPC

BAIL.PlayBailSound = true //Whether or not play the sound when bailing a player
BAIL.BailSound = "vo/k_lab/ba_geethanks.wav" // Sound to play
