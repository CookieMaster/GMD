-------------------------------
AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )
-------------------------------

util.AddNetworkString( "Close" )
util.AddNetworkString( "BailOut" )

----------------
-- Initialize --
----------------
function ENT:Initialize()
	
	self:SetModel( BAIL.NPCModel or "models/Humans/Group03/male_06.mdl" )
	self:SetHullType( HULL_HUMAN )
	self:SetHullSizeNormal( )
	self:SetNPCState( NPC_STATE_SCRIPT )
	self:SetSolid( SOLID_VPHYSICS )
	self:CapabilitiesAdd( bit.bor(CAP_ANIMATEDFACE, CAP_TURN_HEAD) )
	self:SetUseType( SIMPLE_USE )
	self:DropToFloor()
 
	--self:SetMaxYawSpeed( 90 )
end

-----------------
-- Take Damage -- 
-----------------
function ENT:OnTakeDamage( dmginfo )
	return false
end

------------
-- On use --
------------
function ENT:AcceptInput( Name, Activator, Caller )	
	if Name == "Use" and Caller:IsPlayer() then
		umsg.Start("OpenBailMenu", Caller)
		umsg.End()
	end
end

net.Receive( "Close", function()
	isOpen = false
end )

net.Receive( "BailOut", function()
	local Target = net.ReadEntity()
	local Unarrester = net.ReadEntity()
	local BailFee = net.ReadFloat()
	Target:unArrest( Target )
	Unarrester:AddMoney( -tonumber( BailFee ) )
end )
