/*
Autowanted system for DarkRP
Created by Donkie (http://steamcommunity.com/id/Donkie/)
2013-08-02
*/

surface.CreateFont("AVTrebuchet20", {font = "Trebuchet MS",
                                   size = 20,
                                   weight = 900})
																	 
local info
local barstart
local font = "AVTrebuchet20"

local text
local textw
local text2 = "Press F2 to report this."
local text2w = 163
local text3 = "Reporting crime..."
local text3w = 131

local canaccept = false
net.Receive("startwantedtimer", function()
	local criminal = net.ReadEntity()
	local reason = net.ReadString()
	
	barstart = nil
	info = {cr = criminal, re = reason}
	
	text = string.format("You witnessed %s committing the crime %q.",info.cr:Nick(),info.re)
	surface.SetFont(font)
	textw = surface.GetTextSize(text)
	
	canaccept = true
	
	timer.Create("AutoWanted", AUTOWANTED_REACTTIME, 1, function()
		info = nil
		canaccept = false
	end)
end)

net.Receive("abortwantedtimer", function()
	info = nil
	timer.Destroy("AutoWanted")
	canaccept = false
end)

function AcceptAutoWanted()
	canaccept = false
	timer.Destroy("AutoWanted")
	barstart = CurTime()
	RunConsoleCommand("_acceptautowanted")
	
	surface.PlaySound("npc/metropolice/vo/reportsightingsaccomplices.wav")
	timer.Simple(2, function()
		if not LocalPlayer():Alive() then return end
		surface.PlaySound("npc/metropolice/vo/quick.wav")
		timer.Simple(1, function()
			if not LocalPlayer():Alive() then return end
			surface.PlaySound("npc/metropolice/vo/prosecute.wav")
			timer.Simple(1.5, function()
				if not LocalPlayer():Alive() then return end
				surface.PlaySound("npc/metropolice/vo/rodgerthat.wav")
			end)
		end)
	end)
end

hook.Add("Think", "AutoWanted", function()
	if gui.IsGameUIVisible() then return end
	if LocalPlayer():IsTyping() then return end
	
	if input.IsKeyDown(KEY_F2) then
		if canaccept then
			AcceptAutoWanted()
		end
	end
end)


//hue, sat, val
local c1 = HSVToColor(80, 0.5, 0.4)
local c2 = HSVToColor(80, 0.5, 0.7)
local c3 = HSVToColor(80, 0.5, 0.2)

local w,h = ScrW(), ScrH()
hook.Add("HUDPaint", "AutoWanted", function()
	if not info then return end
	if not IsValid(info.cr) then info = nil return end //Criminal disconnected.
	if not LocalPlayer():Alive() then info = nil return end //If the guy died, he shouldn't be able to report the crime.
	
	local boxw = textw + 8
	local boxh = 4+20+4+20+2+6+2
	
	draw.RoundedBox(4, w - boxw - 40, h/2, boxw, boxh, c1)
	
	surface.SetTextColor(c2)
	surface.SetFont(font)
	
	surface.SetTextPos(w - boxw - 36, h/2 + 4)
	surface.DrawText(text)
	
	draw.RoundedBox(2, w - boxw - 36, h/2 + 50, boxw-8, 6, c3)
	if barstart then
		local barw = math.Clamp(((CurTime() - barstart) / AUTOWANTED_RESPONSETIME) * (boxw-8), 4, boxw-8)
		draw.RoundedBox(2, w - boxw - 36, h/2 + 50, barw, 6, c2)
		
		if not LocalPlayer():Alive() or CurTime()>barstart+AUTOWANTED_RESPONSETIME then
			info = nil
		end
		
		surface.SetTextPos(w - boxw/2 - 40 - text3w/2, h/2 + 28)
		surface.DrawText(text3)
	else
		surface.SetTextPos(w - boxw/2 - 40 - text2w/2, h/2 + 28)
		surface.DrawText(text2)
	end
end)
