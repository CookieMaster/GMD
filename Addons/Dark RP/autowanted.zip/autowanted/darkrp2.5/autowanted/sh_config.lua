/*
Autowanted system for DarkRP
Created by Donkie (http://steamcommunity.com/id/Donkie/)
2013-07-29
*/

AUTOWANTED_REACTTIME = 10		//How many seconds you have before the message dissapears.
AUTOWANTED_RESPONSETIME = 5	//How many seconds it takes for the wanted to go through.
