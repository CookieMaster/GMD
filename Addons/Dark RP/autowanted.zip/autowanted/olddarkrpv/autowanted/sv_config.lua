/*
Autowanted system for DarkRP
Created by Donkie (http://steamcommunity.com/id/Donkie/)
2013-08-02
*/

AUTOWANTED_MAXRANGE = 2000	// Maximum range a police can "see" a crime
AUTOWANTED_AIMLIMIT = 0.5		// Basically a variable that lets you change how much a policeman can see. Value of 1 means the ->
//CP needs to look exactly at the position of the crime. Value of -1 means he can look even in the opposite direction and still ->
//technically "see" the crime. 0.5 means a FOV of 90, which should be set as default. If you feel that you saw a crime, but it didn't ->
//get noticed, try lowering this value.
AUTOWANTED_BLOCKEDCHECK = true // Enables/Disables the walls check. If this is disabled, the police can wanted people through walls.


//Reasons to check for. Set any of these to false instead of true to disable it.
AUTOWANTED_REASONS = {}
AUTOWANTED_REASONS["Contraband"] = true		//Put people as wanted if they're holding any item marked as contraband.
AUTOWANTED_REASONS["Murder"] = true				//Put people as wanted if they murdered someone
AUTOWANTED_REASONS["Harm"] = true					//Put people as wanted if they harm (but not kill) someone
AUTOWANTED_REASONS["Unauthguns"] = true		//Put people as wanted if they're holding a weapon they're not authorized to use. ->
//This only works if GAMEMODE.Config.license is set to true. Make sure that weapons such as keys and pocket is added to
//GAMEMODE.NoLicense table, or they'll get detected as Unauthorized weapons.

AUTOWANTED_REASONS["Jailbailing"] = true	//Put people as wanted if a non-CP unarrest someones.
AUTOWANTED_REASONS["ArrestOnSight"] = true	//Put people as wanted if they're having an AoS job.
AUTOWANTED_REASONS["IllegalActivity"] = true	//Wants people for lockpick, keypad cracking, pickpocketing.


/*
Illegal Activity
*/
function playerCommitingIllegalActivity(ply)
	local wep = ply:GetActiveWeapon()
	if not IsValid(wep) then return false end
	
	if (wep.IsLockPicking) or (wep.IsCracking) or (wep.GetPickpocketing and wep:GetPickpocketing()) then return true end
	return false
end

/*
ArrestOnSight
*/
local arrestonsightjobs = {}
//arrestonsightjobs[TEAM_GUN] = true // Example. Will make the gundealer be wanted as soon as a police sees one.

function playerHasIllegalJob(ply)
	return arrestonsightjobs[ply:Team()]
end

/*
Ignorelist

Make this return false if you don't want the player to be autowanted. Put for example "return not ply:IsCP()" to prevent all cops from being
wanted (by autowanted)

Default: "return true" will make everybody eligible for autowanted.
*/
function playerCanBeAutowanted(ply)
	return not ply:IsCP()
end

/*
Unauthorized weapons
*/
local allowedteams = {}
allowedteams[TEAM_GUN] = true // Gundealers can hold guns without being criminals.

function playerAllowedToHoldGuns(ply)
	return ply:IsCP() or allowedteams[ply:Team()] //If the player is a police, or he exists in one of the allowedteams, he can carry guns.
end

//List of weapons thats legal.
aw_legalweapons = {}
aw_legalweapons["weapon_physcannon"] = true
aw_legalweapons["weapon_physgun"] = true
aw_legalweapons["weapon_bugbait"] = true
aw_legalweapons["gmod_tool"] = true
aw_legalweapons["gmod_camera"] = true
aw_legalweapons["keys"] = true
aw_legalweapons["pocket"] = true
aw_legalweapons["med_kit"] = true

/*
Contraband checking

ADVANCED USERS
This function is used to check if an entity is illegal. Add specific classes to the contraclasses table. Or do as I did and ->
make a string.find if you want regex.
*/
local contraclasses = {}
contraclasses["drug"] = true
contraclasses["drug_lab"] = true
function isContraband(ent)
	if string.find(ent:GetClass(), "money.*print") then return true end // Should get all the moneyprinter cases.
	if contraclasses[ent:GetClass()] then return true end
	
	return false
end
