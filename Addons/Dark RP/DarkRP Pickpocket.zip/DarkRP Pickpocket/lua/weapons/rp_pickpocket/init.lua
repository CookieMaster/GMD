AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "cl_init.lua" )
include( "shared.lua" )
SWEP.lastpick = 0
SWEP.ispicking = false
SWEP.pickent = nil
SWEP.picksleft = 0
SWEP.lastpicktimer = 0
SWEP.picktimer = 2.5

function SWEP:Deploy()
	self.Owner:DrawWorldModel(false)
end

function SWEP:PrimaryAttack()	
	if( self.ispicking ) then
		if( self.picksleft > 1 ) then
			if( self.lastpicktimer < CurTime() ) then
				self.picksleft = self.picksleft - 1
				self.Owner:SetNWInt( "picksleft", self.picksleft )
				self.Owner:SetNWBool( "canpick", false )
				self.Owner:EmitSound( "ambient/machines/keyboard" .. tostring( math.random( 1, 6 ) ) .. "_clicks.wav", 70, 40 )
				self.lastpicktimer = CurTime() + math.random( 1, 3 )
			else
				self.ispicking = false
				self.pickent = nil			
				self.Owner:SetNWInt( "picksleft", 0 )
				self.Owner:SetNWBool( "canpick", false )
				self:NewSetWeaponHoldType( "normal" )
				GAMEMODE:Notify( self.Owner, 1, 4, "Pickpocket failed" )
				return
			end
		else
			local amount = math.random( GetConVarNumber( "rp_pickpocket_minimumamt" ), GetConVarNumber( "rp_pickpocket_maximumamt" ) )
			if( IsValid( self.pickent ) ) then
				if( self.pickent:CanAfford( amount ) ) then
					self.pickent:AddMoney( -amount )
					self.Owner:AddMoney( amount )
				else
					amount = self.pickent.DarkRPVars.money
					self.pickent:AddMoney( -amount )
					self.Owner:AddMoney( amount )
				end
				GAMEMODE:Notify( self.pickent, 1, 4, "$" .. amount .. " has been pickpocketed from you!" )
				GAMEMODE:Notify( self.Owner, 1, 4, "You have pickpocketed $" .. amount .. "!" )			
			end
			self:NewSetWeaponHoldType( "normal" )
			self.ispicking = false
			self.lastpick = CurTime() + 3
		end
	end
	
	if CurTime() >= self.lastpick and not self.ispicking then
		if not( IsValid( self.Owner ) and IsValid( self.Owner:GetEyeTrace().Entity ) and self.Owner:GetEyeTrace().Entity:IsPlayer() ) then return end
		local Ent = self.Owner:GetEyeTrace().Entity
		if not( Ent:GetPos():Distance( self.Owner:GetPos() ) < 300 ) then return end
		local PickMiddle = GetConVarNumber( "rp_pickpocket_pickcount" )
		local PickVariation = GetConVarNumber( "rp_pickpocket_pickvariation" )
		self.picksleft = math.random( PickMiddle - PickVariation, PickMiddle + PickVariation )
		self.pickent = Ent
		self.ispicking = true
		self.lastpick = CurTime() + 3
		self:NewSetWeaponHoldType( "pistol" )
		self.Owner:SetNWInt( "picksleft", self.picksleft )

	end
end	

function SWEP:Holster()
	self.ispicking = false
	self.Owner:DrawWorldModel(false)
	return true
end

function SWEP:Think()
	self.Owner:SetNWBool( "picking", self.ispicking )
	if( self.ispicking ) then
		if( not( IsValid( self.pickent ) and IsValid( self.Owner ) and IsValid( self.Owner:GetEyeTrace().Entity ) and self.Owner:GetEyeTrace().Entity == self.pickent and self.Owner:GetEyeTrace().Entity:GetPos():Distance( self.Owner:GetPos() ) < 300 ) ) then
			self:NewSetWeaponHoldType( "normal" )
			self.ispicking = false
			self.pickent = nil
			self.lastpick = CurTime() + 3
			GAMEMODE:Notify( self.Owner, 1, 4, "Pickpocket failed" )
		end
		
		if( self.picksleft > 0 and self.lastpicktimer < CurTime() ) then
			self.Owner:SetNWBool( "canpick", true )
		else
			self.Owner:SetNWBool( "canpick", false )
		end
	else
		if( self.Owner:GetNWBool( "canpick" ) ) then
			self.Owner:SetNWBool( "canpick", false )
		end
	end
end