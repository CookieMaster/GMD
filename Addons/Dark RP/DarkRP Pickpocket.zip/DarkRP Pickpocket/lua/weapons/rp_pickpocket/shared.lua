SWEP.Author = "Ownage"
SWEP.Instructions = "Left click on a player to pickpocket them"
SWEP.Purpose = "Steal money"

SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.ViewModel = "models/weapons/v_crowbar.mdl"
SWEP.WorldModel = "models/weapons/w_crowbar.mdl"
SWEP.AnimPrefix	 = "rpg"

SWEP.Spawnable = false
SWEP.AdminSpawnable = false

SWEP.Primary.ClipSize = -1      
SWEP.Primary.DefaultClip = 0        
SWEP.Primary.Automatic = false      
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

CreateConVar( "rp_pickpocket_minimumamt", 50, { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )
CreateConVar( "rp_pickpocket_maximumamt", 150, { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )
CreateConVar( "rp_pickpocket_pickcount", 10, { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )
CreateConVar( "rp_pickpocket_pickvariation", 2, { FCVAR_REPLICATED, FCVAR_ARCHIVE, FCVAR_SERVER_CAN_EXECUTE } )

function SWEP:Initialize()
	self:SetWeaponHoldType("normal")
	nextFire = CurTime()
end

function SWEP:NewSetWeaponHoldType(holdtype)
	if SERVER then
		umsg.Start("DRP_HoldType")
			umsg.Entity(self)
			umsg.String(holdtype)
		umsg.End()
	end
	self:SetWeaponHoldType(holdtype)
end