AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )

include( 'shared.lua' )

function ENT:Initialize( )
	self:SetModel("models/props_phx/gears/rack18.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
end

function ENT:OnTakeDamage( dmg ) 
	return false
end

function ENT:AcceptInput( name, activator, caller )
    if ( name == "Use" && activator:IsPlayer( ) ) then
		GAMEMODE:Notify(activator, 0, 4, "That trap belongs to: "..self.TrapOwner:Nick())
	end
end

function ENT:StartTouch( ent )
	if(ent:IsVehicle()) then
		if(ent:GetDriver():IsValid()) then
			ent:EmitSound("physics/rubber/rubber_tire_impact_hard3.wav")
			ent.PoppedTire = 1
			ent:GetDriver():ExitVehicle()
			ent:Fire("TurnOff")
		end
	end
end

function Kun_CanPlayerEnterVehicle( player, vehicle, role )
	if(vehicle.PoppedTire != nil and vehicle.PoppedTire == 1) then GAMEMODE:Notify(player, 0, 4, "That vehicle has a slashed tire!") vehicle:Fire("TurnOff") return false else vehicle:Fire("TurnOn") return true end
end
 hook.Add("CanPlayerEnterVehicle","Kun_CanPlayerEnterVehicle",Kun_CanPlayerEnterVehicle)