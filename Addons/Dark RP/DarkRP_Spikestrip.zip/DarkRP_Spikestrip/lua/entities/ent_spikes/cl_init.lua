include( 'shared.lua' )
 
ENT.RenderGroup = RENDERGROUP_BOTH
 ROCKAMT = 0
 
function ENT:Draw( )
    self.Entity:DrawModel( )
end
