if SERVER then
	AddCSLuaFile("shared.lua")
	AddCSLuaFile( "cl_init.lua" )
end

Kun_RepairCost = 50

SWEP.ViewModel = Model("models/weapons/v_hands.mdl")

SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.AnimPrefix	 = "rpg"

SWEP.Spawnable = false
SWEP.AdminSpawnable = true
SWEP.Sound = ""
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

function SWEP:Initialize()
	self:SetWeaponHoldType("normal")
end

function SWEP:Deploy()
	if SERVER then
		self.Owner:DrawWorldModel(false)
	end
end

function SWEP:PrimaryAttack()
	if SERVER then
		local ply = self.Owner
		local ent = ply:GetEyeTrace().Entity
		DarkRP_SpikeStrip(ply,ent)
	end
end

function SWEP:SecondaryAttack()
	if SERVER then
		local ply = self.Owner
		local ent = ply:GetEyeTrace().Entity
		if(ent:GetClass() == "ent_spikes" and ent.TrapOwner == ply) then
			ent:Remove()
			ply.HasSpikes = 0
		end
	end
end

function DarkRP_SpikeStrip(ply,ent)
	if(ply.FireTime != nil and (CurTime() - ply.FireTime) < 2) then return end
	ply.FireTime = CurTime()
	local pos = ply:GetEyeTrace().HitPos
	if(pos:Distance(ply:GetPos()) > 200) then return end
	local entsz = ents.FindInSphere(pos,100)
	for k,v in pairs(entsz) do
		if(string.find(v:GetClass(),"_door") != nil) then
			GAMEMODE:Notify(ply, 0, 4, "Do not place this near a door.")
			return
		end
	end
	
	if(ply.HasSpikes == nil or ply.HasSpikes == 0) then
		local angs = ply:GetAngles()
		local ent = ents.Create("ent_spikes")
		ent:SetPos(pos)
		ent:SetAngles(Angle(0,angs.y,0)) 
		ent:Spawn()
		ent.TrapOwner = ply
		ply.HasSpikes = ent
		ent:GetPhysicsObject():EnableMotion(false)
	else
		if(ply.HasSpikes != 0 and ply.HasSpikes:IsValid()) then
			GAMEMODE:Notify(ply, 0, 4, "You already have a trap out somewhere.")
		end
	end
end

