
if(CLIENT) then
	SWEP.PrintName = "Spike Trap"
	SWEP.Slot = 1
	SWEP.SlotPos = 3
	SWEP.DrawAmmo = false
	SWEP.DrawCrosshair = false
	SWEP.Author = "Kunit"
	SWEP.Instructions = "Left click to spawn spikes, right click to pick them up."
end
