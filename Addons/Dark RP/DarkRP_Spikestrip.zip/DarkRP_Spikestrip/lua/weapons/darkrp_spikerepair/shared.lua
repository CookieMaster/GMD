Kun_RepairCost = 50

if SERVER then
	AddCSLuaFile("shared.lua")
	AddCSLuaFile( "cl_init.lua" )
end

SWEP.ViewModel = Model("models/weapons/v_hands.mdl")

SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.AnimPrefix	 = "rpg"

SWEP.Spawnable = false
SWEP.AdminSpawnable = true
SWEP.Sound = ""
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

function SWEP:Initialize()
	self:SetWeaponHoldType("normal")
end

function SWEP:Deploy()
	if SERVER then
		self.Owner:DrawWorldModel(false)
	end
end

function SWEP:PrimaryAttack()
	if SERVER then
		local ply = self.Owner
		if(ply.FireTime != nil and (CurTime() - ply.FireTime) < 2) then return end
		ply.FireTime = CurTime()
		local ent = ply:GetEyeTrace().Entity
		if(ent != nil and ent:GetClass() == "prop_vehicle_jeep") then
			if(ent.PoppedTire == nil or ent.PoppedTire == 0) then GAMEMODE:Notify(ply, 0, 4, "That Vehicle does not need repair.") return end
			if(ply:CanAfford(Kun_RepairCost)) then
				GAMEMODE:Notify(ply, 0, 4, "You repaired the vehicle for $"..Kun_RepairCost..".")
				ent.PoppedTire = 0
				ply:AddMoney(-Kun_RepairCost)
			else
				GAMEMODE:Notify(ply, 0, 4, "You need $"..Kun_RepairCost.." to repair the Vehicle.")
			end
		end
	end
end

function SWEP:SecondaryAttack()
end
