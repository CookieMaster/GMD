
if(CLIENT) then
	SWEP.PrintName = "Vehicle Repair"
	SWEP.Slot = 1
	SWEP.SlotPos = 3
	SWEP.DrawAmmo = false
	SWEP.DrawCrosshair = false
	SWEP.Author = "Kunit"
	SWEP.Instructions = "Left click on a Vehicle to repair it!"
	SWEP.Contact = ""
	SWEP.Purpose = ""
end
