local meta = FindMetaTable("Player");
PartyList = PartyList or {}


	function meta:IsSameParty(target)
		local mynum = self:GetCurrentPartyNumber()
		local tanum = target:GetCurrentPartyNumber()
		
		if mynum == tanum and mynum != 0 then
			return true
		else
			return false
		end
	end

	function meta:IsPartyMaster()
		for num,DB in pairs(PartyList) do
			if DB.Master == self then
				return true
			end
		end
		return false
	end
	
	function meta:HasParty()
		for num,DB in pairs(PartyList) do
			for k,v in pairs(DB.Players) do
				if v == self then
					return true
				end
			end
		end
		return false
	end
	
	function meta:GetCurrentPartyNumber()
		for num,DB in pairs(PartyList) do
			for k,v in pairs(DB.Players) do
				if v == self then
					return num
				end
			end
		end
		return 0
	end


if SERVER then
hook.Add("PlayerDisconnected", "ExitParty", function( ply )
	ply:ExitParty();
end);


	util.AddNetworkString( "partylist" )
	
		
	
		concommand.Add("DismissPartyT",function(ply,cmd,args)
			local Target = ents.GetByIndex(args[1])
			if tostring(args[2]) != "p" then return end

			if !ply:HasParty() then return end
			if !Target:IsValid() then return end
			if !Target:HasParty() then return end
			if !ply:IsPartyMaster() then return end
			if Target:IsPartyMaster() then return end
			if !ply:IsSameParty(Target) then return end
			
			Target:ExitParty()

			for k,v in pairs(player.GetAll()) do
				if v:IsSameParty(ply) then
					v:ChatSystem(Target:Nick() .. " was banned from party")
				end
			end
		end)
		
		concommand.Add("ChangePartyMaster",function(ply,cmd,args)
			local Target = ents.GetByIndex(args[1])
			if tostring(args[2]) != "p" then return end

			if !ply:HasParty() then return end
			if !Target:IsValid() then return end
			if !Target:HasParty() then return end
			if !ply:IsPartyMaster() then return end
			if Target:IsPartyMaster() then return end
			if !ply:IsSameParty(Target) then return end

				for num,DB in pairs(PartyList) do
					if DB.Master == ply then
						DB.Master = Target
						continue
					end
				end
				
			BroadCastPartyList()

			for k,v in pairs(player.GetAll()) do
				if v:IsSameParty(ply) then
					v:ChatSystem(Target:Nick() .. " was given Party Master access!")
				end
			end
		end)
	
		concommand.Add("WJP2Member_C2S",function(ply,cmd,args)
			local Member = ents.GetByIndex(args[1])
			if tostring(args[2]) != "p" then return end

			if ply:HasParty() == true then return end
			if !Member:IsValid() then return end
			if !Member:HasParty() then return end
			
			local PartyNum = Member:GetCurrentPartyNumber()
			
			if !PartyList[PartyNum] then return end
			local PartyMaster = PartyList[PartyNum].Master
			
			
			if PartyMaster and PartyMaster:IsValid() then
				PartyMaster:ConCommand("WannaJoinParty " .. ply:EntIndex())
				ply:ChatSystem("Sending Request to invite me to Party Master")
			end
		end)
		
		
		
		concommand.Add("JoinParty",function(ply,cmd,args)
			local PartyNum = tonumber(args[1])
			if tostring(args[2]) != "p" then return end
			if ply:HasParty() == true then return end
			if !PartyList[PartyNum] then return end
			local PartyMaster = PartyList[PartyNum].Master
			
			
			if PartyMaster and PartyMaster:IsValid() then
				PartyMaster:ConCommand("WannaJoinParty " .. ply:EntIndex())
				ply:ChatSystem("Sending Request to join the Party")
			end
		end)
	
		concommand.Add("AcceptJoin",function(ply,cmd,args)
			local Target = ents.GetByIndex(args[1])
			if tostring(args[2]) != "p" then return end
			if Target:HasParty() == true then return end
			
			if ply:HasParty() == false then return end
			
			for k,v in pairs(player.GetAll()) do
				if ply:IsSameParty(v) then
					v:ChatSystem(Target:Nick() .." joined to party")
				end
			end
			
			Target:JoinParty(ply:GetCurrentPartyNumber())
		end)
		
		concommand.Add("AcceptInviteJoin",function(ply,cmd,args)
			local Target = ents.GetByIndex(args[1])
			if tostring(args[2]) != "p" then MsgN("A") return end
			if Target:HasParty() == false then MsgN("B") return end
			
			if ply:HasParty() == true then MsgN("C") return end
			

			
			ply:JoinParty(Target:GetCurrentPartyNumber())
			
			for k,v in pairs(player.GetAll()) do
				if v:IsSameParty(ply) and v != ply then
					v:ChatSystem(Target:Nick() .." joined to party")
				end
			end
			
			ply:ChatSystem("you joined party")
		end)
		
	
	concommand.Add("CreateParty",function(ply,cmd,args)
		local Name = tostring(args[1])
		if tostring(args[2]) != "p" then return end
		if ply:HasParty() == true then return end
		
		CreateParty(Name,ply)
		ply:ChatSystem("Party Creating Success")
	end)
	
	concommand.Add("EditParty",function(ply,cmd,args)
		local Name = tostring(args[1])
		if tostring(args[2]) != "p" then return end
		if ply:HasParty() == false then return end
		
		local CurrentPartyNum = ply:GetCurrentPartyNumber()
		local PartyData = PartyList[CurrentPartyNum]
		if !PartyData then return end
		
		if PartyData.Master == ply then
			PartyData.PrintName = Name
			BroadCastPartyList()
		end
	end)
	
	concommand.Add("DestoryParty",function(ply,cmd,args)
		local Num = tonumber(args[1])
		if tostring(args[2]) != "p" then return end
		
		local CurrentPartyNum = Num
		local PartyData = PartyList[CurrentPartyNum]
		if !PartyData then return end
		
		PartyData.Master:ExitParty()
	end)
	
	concommand.Add("partyout",function(ply,cmd,args)
		if ply:HasParty() == false then return end
		
		ply:ExitParty()
		ply:ChatSystem("you exited party")
	end)
	
	function UpdatePartyList( ply )
		net.Start( "partylist" )
		net.WriteTable( PartyList )
		net.Send(ply)
	end
	hook.Add( "PlayerInitialSpawn", "UpdatePartyList", UpdatePartyList )
	
	function BroadCastPartyList()
		net.Start( "partylist" )
		net.WriteTable( PartyList )
		net.Broadcast()
	end
		
	function CreateParty(printname,partymaster)
		if partymaster:HasParty() == true then return end
		local Party = {}
			Party.PrintName = printname
			Party.Master = partymaster
			Party.Players = {}
			table.insert(Party.Players,partymaster)
		table.insert(PartyList,Party)
		
		BroadCastPartyList()
	end

	function meta:JoinParty(partynumber)
		local PartyData = PartyList[partynumber]
			if !PartyData then return end
			
			if #PartyData.Players >= RXPartySys.MaxPartyPlayerAmount then return end
		
			table.insert(PartyData.Players,self)
			self:ChatSystem("you joined party")
			BroadCastPartyList()
	end
	
	
	
	function meta:ExitParty()
		if self:HasParty() == false then return end
		local CurrentPartyNum = self:GetCurrentPartyNumber()
		
		local PartyData = PartyList[CurrentPartyNum]
		if !PartyData then return end

		if PartyData.Master == self then
			table.remove(PartyList,CurrentPartyNum)
		else
			for k,v in pairs(PartyData.Players) do
				if v == self then
					table.remove(PartyData.Players,k)
				end
			end
		end
			BroadCastPartyList()
	end
	
end

if SERVER then
	hook.Add( "PlayerSay", "Party Chat Command", function(ply,text,public)
		if text == RXPartySys.ChatCommand then
			ply:ConCommand("Party_openwindow")
			return false
		end
	end)
end


if CLIENT then
local PartyPanel = nil


	concommand.Add("Party_openwindow",function(ply,cmd,args)
		OpenPartyList()
	end)

	function OpenPartyList()
		if PartyPanel then
			PartyPanel:Remove()
		end
			PartyPanel = vgui.Create("PartyPanel")
			PartyPanel:SetSize(ScrW()*0.8,ScrH()*0.7)
			PartyPanel:Install()
			PartyPanel:Center()
			PartyPanel:MakePopup()
	end

	concommand.Add("WannaJoinParty",function(ply,cmd,args)
		local WhoWannajoin = ents.GetByIndex(args[1])
		local P = CreateRequestPanel()
			P:SetText(WhoWannajoin:Nick() .. " wants to join to your party" )
			P.AcceptFunction = function() RunConsoleCommand("AcceptJoin",WhoWannajoin:EntIndex(),"p") end
	end)
	concommand.Add("InvitePtyRequest",function(ply,cmd,args)
		local Sender = ents.GetByIndex(args[1])
		local P = CreateRequestPanel()
			P:SetText(Sender:Nick() .. " invites you to he(she)'s party " )
			P.AcceptFunction = function() RunConsoleCommand("AcceptInviteJoin",Sender:EntIndex(),"p") end
	end)
	

	net.Receive( "partylist", function( len )
		PartyList = net.ReadTable()
		if PartyPanel then
			PartyPanel:UpdatePartyList()
			if PartyPanel.CurPartyInfoMode and PartyPanel.CurPartyInfoMode == "partyinfo" then
				PartyPanel:UpdatePartyInfo(PartyPanel.CurPartyInfoMode,PartyPanel.CurPartyNum)
			end
		end
	end)


local PANEL = {}

function PANEL:Paint()
		draw.RoundedBox(4, 0, 0, self:GetWide(), self:GetTall(), RXPartySys.Color.M.Boarder)
		draw.RoundedBox(4, 2, 2, self:GetWide()-4, self:GetTall()-4, RXPartySys.Color.M.BG)
		draw.RoundedBox(4, 2, 2, self:GetWide()-4, 30, RXPartySys.Color.M.TopBar)
		draw.SimpleText("Party" , "RXF_Treb_S25", 30, 17 , RXPartySys.Color.M.TopText, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		
		draw.RoundedBox(4, 10, 40, self:GetWide()*0.4, 30, RXPartySys.Color.M.PL.TopBGBoarder)
		draw.RoundedBox(4, 11, 41, self:GetWide()*0.4-2, 30-2, RXPartySys.Color.M.PL.TopBG)
		draw.SimpleText("Party List" , "RXF_Treb_S20", 10+self:GetWide()*0.2, 55 ,RXPartySys.Color.M.PL.TopBGText, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		
		draw.RoundedBox(4, self:GetWide()*0.4+20,40, self:GetWide() - (self:GetWide()*0.4 + 30), self:GetTall() - 90, RXPartySys.Color.M.InfoBoxBoarder)

		draw.RoundedBox(4, 2, self:GetTall()-37, self:GetWide()-4,35, RXPartySys.Color.M.ButtomBar)
end

function PANEL:Init()
	self:SetTitle(" ")
	self:ShowCloseButton(false)
	self:SetDraggable(false)
end

function PANEL:Install()


	
	local Exit = vgui.Create( "Party_DSWButton", self)
		Exit:SetPos(self:GetWide() - 100, 5);
		Exit:SetSize(80, 24);
		Exit:SetTexts("Close")
		
		Exit.Click = function()
			PartyPanel:Remove()
			PartyPanel = nil
			
	--		OpenPartyList()
		end
		
		
	local CreateParty = vgui.Create( "Party_DSWButton", self)
		CreateParty:SetPos(20, self:GetTall()-30);
		CreateParty:SetSize(150, 24);
		CreateParty:SetTexts("Create Party")
		CreateParty.Click = function()
			self:UpdatePartyInfo("createparty")
		end
		
		
		
	local ExitParty = vgui.Create( "Party_DSWButton", self)
		ExitParty:SetPos(200, self:GetTall()-30);
		ExitParty:SetSize(150, 24);
		ExitParty:SetTexts("Exit Party")
		ExitParty.Click = function()
			if LocalPlayer():HasParty() == true then
				RunConsoleCommand("partyout")
				self:UpdatePartyInfo(" ")
			end
		end
		
		
		
		
	local MyParty = vgui.Create( "Party_DSWButton", self)
		MyParty:SetPos(380, self:GetTall()-30);
		MyParty:SetSize(150, 24);
		MyParty:SetTexts("My Party")
		MyParty.Click = function()
			if LocalPlayer():HasParty() == true then
				self:UpdatePartyInfo("partyinfo",LocalPlayer():GetCurrentPartyNumber())
			end
		end
		
	
	self.PartyList = vgui.Create("DPanelList", self)
	self.PartyList:SetPos(10, 80);
	self.PartyList:SetSize(self:GetWide()*0.4, self:GetTall() - 130);
	self.PartyList:SetSpacing(2);
	self.PartyList:SetPadding(2);
	self.PartyList:EnableVerticalScrollbar(true);
	self.PartyList:EnableHorizontal(false);
	

	self.PartyInfoPanel = vgui.Create("DPanelList", self)
		self.PartyInfoPanel:SetPos(10 + self.PartyList:GetWide() + 15,45)
		self.PartyInfoPanel:SetSize(self:GetWide() - (self.PartyList:GetWide() + 40),self:GetTall() - 100 )
		self.PartyInfoPanel:SetSpacing(2);
		self.PartyInfoPanel:SetPadding(2);
		self.PartyInfoPanel:EnableVerticalScrollbar(true);
		self.PartyInfoPanel:EnableHorizontal(false);
		
		self.PartyInfoPanel.Paint = function(slf)
			draw.RoundedBox(4, 0, 0, slf:GetWide(), slf:GetTall(), RXPartySys.Color.M.InfoBoxInner)
		end
		

		
	self:UpdatePartyList()
end

vgui.Register("PartyPanel",PANEL,"DFrame")


function PANEL:UpdatePartyList()
	self.PartyList:Clear()
	

	for partynumber,DB in pairs(PartyList or {} ) do
		local SButton = vgui.Create( "Party_DSWButton" )
			SButton:SetSize( self.PartyList:GetWide(), 44 )
			SButton.BoarderCol = Color(0,0,0,0)
			SButton:SetTexts( " " )
			SButton.FXCol = RXPartySys.Color.M.PL.ItemBGHoverFX
			SButton.PaintBackGround = function(slf)
				draw.RoundedBox(0, 0, 0, slf:GetWide(), slf:GetTall(), RXPartySys.Color.M.PL.ItemBGBoarder)
				draw.RoundedBox(0, 1, 1, slf:GetWide()-2, slf:GetTall()-2, RXPartySys.Color.M.PL.ItemBG)
				draw.SimpleText("No." .. partynumber .. " -  " .. DB.PrintName, "RXF_Treb_S20", 20, 2 , RXPartySys.Color.M.PL.TEXT_Title, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
				draw.SimpleText("Player : " .. #DB.Players .. " / " .. RXPartySys.MaxPartyPlayerAmount, "RXF_Treb_S20", 30, 22 , RXPartySys.Color.M.PL.TEXT_Players, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
			end
		
		SButton.Click = function()
			self:UpdatePartyInfo("partyinfo",partynumber)
		end
		
		self.PartyList:AddItem(SButton)
	end
	
end

function PANEL:UpdatePartyInfo(mode,num)
	self.CurPartyInfoMode = mode
	self.CurPartyNum = num
	
	self.PartyInfoPanel:Clear()
	if mode == "partyinfo" then
		local PartyData = PartyList[num]
		
		local Head = vgui.Create( "DPanel" )
			Head:SetSize( self.PartyInfoPanel:GetWide(), 65 )
			Head:SetText( " " )
			Head.Paint = function(slf)
				draw.RoundedBox(0, 0, 0, slf:GetWide(), 50, RXPartySys.Color.M.PI.TopBG)
				draw.SimpleText("Party Number . " .. num .. "  -  " .. PartyData.PrintName, "RXF_Treb_S20", 20, 2 , RXPartySys.Color.M.PI.TEXT_TopBGTitle, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
				draw.SimpleText("Player : " .. #PartyData.Players .. " / " .. RXPartySys.MaxPartyPlayerAmount, "RXF_Treb_S20", 30, 30 , RXPartySys.Color.M.PI.TEXT_TopBGPlayers, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
			
				local PartyMaster = PartyData.Master
				if PartyMaster and PartyMaster:IsValid() and PartyMaster:IsPlayer() then
				draw.SimpleText("Master : " .. PartyMaster:Nick(), "RXF_Treb_S20", slf:GetWide() - 30, 30 , RXPartySys.Color.M.PI.TEXT_TopBGMaster, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
				end
			end
		self.PartyInfoPanel:AddItem(Head)
		
		if LocalPlayer():HasParty() == false then
		local Join = vgui.Create( "Party_DSWButton" )
			Join:SetSize( self.PartyInfoPanel:GetWide(), 60 )
			Join:SetTexts( "Join to the Party" )
			Join.BoarderCol = Color(0,0,0,0)
			Join.FXCol = RXPartySys.Color.M.PI.SettingFX
			Join.TextCol = RXPartySys.Color.M.PI.SettingText
			Join.PaintBackGround = function(slf)
				draw.RoundedBox(0, 0, 0, slf:GetWide(), slf:GetTall(), RXPartySys.Color.M.PI.SettingBG)
			end
			Join.Click = function()
				if LocalPlayer():HasParty() == true then return end
				RunConsoleCommand("JoinParty",num,"p")
				self:UpdatePartyInfo(" ")
			end
		self.PartyInfoPanel:AddItem(Join)
		end
		
		if PartyData.Master == LocalPlayer() then
		local NameEdit = vgui.Create( "Party_DSWButton" )
			NameEdit:SetSize( self.PartyInfoPanel:GetWide(), 60 )
			NameEdit:SetTexts("Edit Party Name")
			NameEdit.BoarderCol = Color(0,0,0,0)
			NameEdit.FXCol = RXPartySys.Color.M.PI.SettingFX
			NameEdit.TextCol = RXPartySys.Color.M.PI.SettingText
			NameEdit.PaintBackGround = function(slf)
				draw.RoundedBox(0, 0, 0, slf:GetWide(), slf:GetTall(), RXPartySys.Color.M.PI.SettingBG)
			end
			NameEdit.Click = function()
				if LocalPlayer():HasParty() == false then return end
				self:UpdatePartyInfo("nameedit")
			end
		self.PartyInfoPanel:AddItem(NameEdit)
		end
		
		if LocalPlayer():IsUserGroup("owner") then
		local NameEdit = vgui.Create( "Party_DSWButton" )
			NameEdit:SetSize( self.PartyInfoPanel:GetWide(), 40 )
			NameEdit:SetTexts("Destroy Party")
			NameEdit.BoarderCol = Color(0,0,0,0)
			NameEdit.FXCol = RXPartySys.Color.M.PI.SettingFX
			NameEdit.TextCol = RXPartySys.Color.M.PI.SettingText
			NameEdit.PaintBackGround = function(slf)
				draw.RoundedBox(0, 0, 0, slf:GetWide(), slf:GetTall(), RXPartySys.Color.M.PI.SettingBG)
			end
			NameEdit.Click = function()
				RunConsoleCommand("DestoryParty",num,"p")
				self.PartyInfoPanel:Clear()
			end
		self.PartyInfoPanel:AddItem(NameEdit)
		end
		
		for k,v in pairs(PartyData.Players) do
			if v:IsValid() then
				local Players = vgui.Create( "DButton" )
					Players:SetSize( self.PartyInfoPanel:GetWide(), 40 )
					Players:SetText( " " )
					Players.Paint = function(slf)
						draw.RoundedBox(0, 0, 0, slf:GetWide(), 50, RXPartySys.Color.M.PI.PlayersBG)
						if v == PartyData.Master then
							draw.SimpleText("Master     " .. v:Nick(), "RXF_Treb_S20", 30, 20 , RXPartySys.Color.M.PI.PlayersNameMaster, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						else
							draw.SimpleText("PartyPlayer " .. v:Nick(), "RXF_Treb_S20", 30, 20 , RXPartySys.Color.M.PI.PlayersName, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
						end
					end
					Players.DoClick = function(slf)
						local menu = DermaMenu()
						if LocalPlayer() == PartyData.Master and v != PartyData.Master then
							menu:AddOption("Dismiss!",function()
								RunConsoleCommand("DismissPartyT",v:EntIndex(),"p")
							end)
							menu:AddOption("Give Master Access!",function()
								RunConsoleCommand("ChangePartyMaster",v:EntIndex(),"p")
							end)
						else

						end
							menu:Open()
						
					end
				self.PartyInfoPanel:AddItem(Players)
			end
		end
		
	end
	if mode == "nameedit" then
		local Head = vgui.Create( "DPanel" )
			Head:SetSize( self.PartyInfoPanel:GetWide(), 50 )
			Head:SetText( " " )
			Head.Paint = function(slf)
				draw.RoundedBox(0, 0, 0, slf:GetWide(), slf:GetTall(), RXPartySys.Color.IE.TopBG)
				draw.SimpleText("Edit Party name", "RXF_Treb_S20", 20, 2 , RXPartySys.Color.IE.TopText, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)

			end
		self.PartyInfoPanel:AddItem(Head)
		
		local Body = vgui.Create( "DPanel" )
			Body:SetSize( self.PartyInfoPanel:GetWide(), 250 )
			Body:SetText( " " )
			Body.CanCreate = false
			Body.Paint = function(slf)
				draw.RoundedBox(0, 0, 0, slf:GetWide(), slf:GetTall(), Color(0,0,0,255))
				draw.SimpleText("Edit Party information", "RXF_Treb_S20", 20, 2 , RXPartySys.Color.IE.Texts, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
			
				draw.SimpleText(" - Party Name : ", "RXF_Treb_S20", 40, 70 , RXPartySys.Color.IE.Texts, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
				draw.RoundedBox(0, 100, 120, 350, 1, RXPartySys.Color.IE.TextEntryLines)
				
				if slf.PartyName then
					local length = string.len(tostring(slf.PartyName:GetText()))
					if length < RXPartySys.MinPartyNameLength then
						draw.SimpleText("Name is so short", "RXF_Treb_S20", 100, 125 , Color(255,50,0,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
						slf.CanCreate = false
					elseif length > RXPartySys.MaxPartyNameLength then
						draw.SimpleText("Name is so long", "RXF_Treb_S20", 100, 125 , Color(255,50,0,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
						slf.CanCreate = false
					else
						slf.CanCreate = true
					end
				end
			
			end
			
			Body.PartyName = vgui.Create("DTextEntry", Body)
			Body.PartyName:SetText("")
			Body.PartyName:SetPos(100,90)
			Body.PartyName:SetSize(350,30)
			Body.PartyName:SetAllowNonAsciiCharacters(true)
			Body.PartyName:SetTextColor(RXPartySys.Color.IE.TextEntryText)

			Body.PartyName:SetDrawBackground(false)
			Body.PartyName:SetEnterAllowed( false )
			Body.PartyName:SetCursorColor(Color(255,255,255,255))
			Body.PartyName:RequestFocus()
			
			
			Body.CreateButton = vgui.Create( "Party_DSWButton",Body )
				Body.CreateButton:SetSize( 200, 50 )
				Body.CreateButton:SetPos( Body:GetWide() - 230,Body:GetTall()-65 )
				Body.CreateButton:SetTexts("Finish")
				
				Body.CreateButton.Click = function()
					if Body.CanCreate == true then
						RunConsoleCommand("EditParty",tostring(Body.PartyName:GetText()),"p")
						self:UpdatePartyInfo(" ")
					end
				end

			
		self.PartyInfoPanel:AddItem(Body)
	end
	
	if mode == "createparty" then
		local Head = vgui.Create( "DPanel" )
			Head:SetSize( self.PartyInfoPanel:GetWide(), 50 )
			Head:SetText( " " )
			Head.Paint = function(slf)
				draw.RoundedBox(0, 0, 0, slf:GetWide(), slf:GetTall(), RXPartySys.Color.IE.TopBG)
				draw.SimpleText("Create Party", "RXF_Treb_S20", 20, 2 , RXPartySys.Color.IE.Texts, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)

			end
		self.PartyInfoPanel:AddItem(Head)
		
		local Body = vgui.Create( "DPanel" )
			Body:SetSize( self.PartyInfoPanel:GetWide(), 250 )
			Body:SetText( " " )
			Body.CanCreate = false
			Body.Paint = function(slf)
				draw.RoundedBox(0, 0, 0, slf:GetWide(), slf:GetTall(), Color(0,0,0,255))
				draw.SimpleText("Setup Party Information", "RXF_Treb_S20", 20, 2 , RXPartySys.Color.IE.Texts, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
			
				draw.SimpleText(" - Party Name : ", "RXF_Treb_S20", 40, 70 , RXPartySys.Color.IE.Texts, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
				draw.RoundedBox(0, 100, 120, 350, 1, RXPartySys.Color.IE.TextEntryText)
				
				if slf.PartyName then
					local length = string.len(tostring(slf.PartyName:GetText()))
					if length < 7 then
						draw.SimpleText("Name is so short", "RXF_Treb_S20", 100, 125 , Color(255,50,0,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
						slf.CanCreate = false
					elseif length > 25 then
						draw.SimpleText("Name is so long", "RXF_Treb_S20", 100, 125 , Color(255,50,0,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
						slf.CanCreate = false
					else
						slf.CanCreate = true
					end
				end
			
			end
			
			Body.PartyName = vgui.Create("DTextEntry", Body)
			Body.PartyName:SetText("")
			Body.PartyName:SetPos(100,90)
			Body.PartyName:SetSize(350,30)
			Body.PartyName:SetAllowNonAsciiCharacters(true)
			Body.PartyName:SetTextColor(RXPartySys.Color.IE.TextEntryText)

			Body.PartyName:SetDrawBackground(false)
			Body.PartyName:SetEnterAllowed( false )
			Body.PartyName:SetCursorColor(Color(255,255,255,255))
			Body.PartyName:RequestFocus()
			
			
			Body.CreateButton = vgui.Create( "Party_DSWButton",Body )
				Body.CreateButton:SetSize( 200, 50 )
				Body.CreateButton:SetPos( Body:GetWide() - 230,Body:GetTall()-65 )
				Body.CreateButton:SetTexts( "Finish" )
				
				Body.CreateButton.Click = function()
					if Body.CanCreate == true then
						RunConsoleCommand("CreateParty",tostring(Body.PartyName:GetText()),"p")
						self:UpdatePartyInfo(" ")
					end
				end

			
		self.PartyInfoPanel:AddItem(Body)
	end
end

end

