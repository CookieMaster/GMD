local meta = FindMetaTable("Player")

/* ──────────────────────────────────────────────
	Party Chat System
────────────────────────────────────────────── */
if SERVER then

	util.AddNetworkString( "PartyChat_S2C" )
	timer.Simple(1,function() 
		hook.Add( "PlayerSay", "Party Player Chat", function(ply,text)
			if string.Left(text,(string.len(RXPartySys.WhipserCommand)+1)) == (RXPartySys.WhipserCommand .. " ") then
				local Text = string.sub(text,(string.len(RXPartySys.WhipserCommand)+2))
				ply:BroadCastPartyChat(Text)
				return ""
			end
			if string.Left(text,(string.len(RXPartySys.InviteCommand)+1)) == (RXPartySys.InviteCommand .. " ") then
				
				local Text = string.sub(text,(string.len(RXPartySys.InviteCommand)+2))
				ply:InvitePlayerK(Text)
				
				return ""
			end
		end)
	end)
	
	function meta:InvitePlayerK(NickPart)
			
			
		if !self:IsPartyMaster() then
			self:ChatSystem("[Party Invite] You are not party master!")
			return
		end
		
		local Target = nil
		for k,v in pairs(player.GetAll()) do
			if string.find(string.lower(v:Nick()),tostring(NickPart)) then
				Target = v
			end
		end
		
				if !Target then
					self:ChatSystem("[Party Invite] Unable to find Target")
					return
				end
				
				self:ChatSystem("[Party Invite] inviting " .. Target:Nick())
				
				if self:IsSameParty(Target) then
					self:ChatSystem("[Party Invite] Target is already belongs to your party!")
					return
				end
				if Target:HasParty() then
					self:ChatSystem("[Party Invite] Target is already belongs to another party!")
					return
				end

					Target:ConCommand("InvitePtyRequest " .. self:EntIndex())
					self:ChatSystem("[Party Invite] Invitation was sent to Target")

			
	end
	
	function meta:BroadCastPartyChat(text)
		local PartyNum = self:GetCurrentPartyNumber()
		if PartyNum == 0 then self:ChatSystem("You are not belongs to any party!") return end
		
		for k,v in pairs(PartyList[PartyNum].Players or {}) do
			local DB = {}
			DB.Sender = self
			DB.Text = text
			v:SendPartyChat(DB)
		end
	end
	function meta:SendPartyChat(DB)
		net.Start( "PartyChat_S2C" )
		net.WriteTable( DB )
		net.Send(self)
	end
end
if CLIENT then
	net.Receive( "PartyChat_S2C", function( len )
		local DB = net.ReadTable()
			local Sender = DB.Sender
			local Text = DB.Text
			if !Sender or !Sender:IsValid() then return end
			
		chat.AddText(
			Color(0,63,255), "(Party) ",
			Color(127,159,255), Sender:Nick() .. " : ",
			Color(255,255,255), Text
		)
	end)
end







/* ──────────────────────────────────────────────
	STUFF
────────────────────────────────────────────── */
if CLIENT then
local Fonts = {}
	Fonts["RXF_CoolV"] = "coolvetica"
	Fonts["RXF_Treb"] = "Trebuchet MS"
	
	
for a,b in pairs(Fonts) do
	for k=10,40 do
		surface.CreateFont( a .. "_S"..k,{font = b,size = k,weight = 700})
		surface.CreateFont( a .. "Out_S"..k,{font = b,size = k,weight = 700,outline = true})
	end
end
end
	
	function meta:ChatSystem(text)
		self:ChatPrint(text)
	end
if SERVER then
	hook.Add( "PlayerShouldTakeDamage", "PartyPPL Can't Fight", function(victim,attacker)
		if RXPartySys.EnableNoDamageBetweenPartyPlayer then
			if victim:IsPlayer() and attacker:IsPlayer() then
				if victim:IsSameParty(attacker) then 
					return false 
				end
			end
		end
	end)
end

	
/* ──────────────────────────────────────────────
	Party Player Mark
────────────────────────────────────────────── */
if CLIENT then
	local CirMat = Material("particle/Particle_Ring_Wave_Additive")
	hook.Add("PostDrawTranslucentRenderables", "Party Player Mark", function()
		for k,v in pairs(player.GetAll()) do
			local ColorK = RXPartySys.Color.Ring
				if LocalPlayer():IsSameParty(v) and v != LocalPlayer() then
					if v:IsPartyMaster() then ColorK = RXPartySys.Color.RingMaster end
					cam.Start3D2D( v:GetPos() + Vector(0,0,5),Angle(0,CurTime()*120,0), 0.25 )
						local Size = 100
						surface.SetMaterial(CirMat)
						surface.SetDrawColor(ColorK) 
						surface.DrawTexturedRect( -Size,-Size,Size*2, Size*2 )
					cam.End3D2D()
				end
		end
	end)
end
	
/* ──────────────────────────────────────────────
	Party Player HUD
────────────────────────────────────────────── */
if CLIENT then
	hook.Add("HUDPaint","PartyPlayer HUD",function()
		local CurPartyDB = nil
		for num,DB in pairs(PartyList) do
			for k,v in pairs(DB.Players) do
				if v == LocalPlayer() then
					CurPartyDB = DB
					continue
				end
			end
		end
		
		if CurPartyDB then
			local PosX,PosY = RXPartySys.PPH.Position[1],RXPartySys.PPH.Position[2]
			local SizeX = RXPartySys.PPH.SizeX
			local SizeY = 50
			local Spacing = RXPartySys.PPH.SpacingY
			
			if !RXPartySys.PPH.EnableArmorDisplayOnHUD then
				SizeY = 35
			end
			local PlayerCount = 0
			local function DrawPlayerInfo(target,IsMaster)
				if !target:IsValid() then return end
				
				-- BG
				draw.RoundedBox(6, PosX, PosY + (PlayerCount*(SizeY+Spacing)),SizeX, SizeY, Color(0,0,0,150))
				
				-- Nick
				local Nick = target:Nick()
				if IsMaster then
					Nick = "★ " .. Nick
				end
				draw.SimpleText(Nick , "RXF_TrebOut_S17", PosX+SizeX/2, PosY+10  + (PlayerCount*(SizeY+Spacing)), Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				
				-- HP
				local BCol = Color(125,0,0,255) -- Bar Color
				local BCol2 = Color(255,0,0,255) -- Bar Color 2
				local TCol = Color(255,170,0,255) -- Text Color
				local Percent = (target:Health()/100)
					Percent = math.min(Percent,1)
					Percent = math.max(0,Percent)
				
				draw.RoundedBox(0, PosX+10, PosY + (PlayerCount*(SizeY+Spacing)) + 20,(SizeX-20), 8, Color(0,0,0,200))
				if Percent > 0 then
					draw.RoundedBox(0, PosX+10, PosY + (PlayerCount*(SizeY+Spacing)) + 20,(SizeX-20)*Percent, 8, BCol)
					draw.RoundedBox(0, PosX+12, PosY + (PlayerCount*(SizeY+Spacing)) + 22,(SizeX-24)*Percent, 4, BCol2)
				end
					draw.SimpleText("HP: " .. target:Health() .. " / 100" , "RXF_TrebOut_S17", PosX+SizeX/2, PosY+25  + (PlayerCount*(SizeY+Spacing)), TCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

				if RXPartySys.PPH.EnableArmorDisplayOnHUD then
					-- ARMOR
					local BCol = Color(0,0,255,255) -- Bar Color
					local BCol2 = Color(0,170,255,255) -- Bar Color 2
					local TCol = Color(0,220,255,255) -- Text Color
					local Percent = (target:Armor()/100)
						Percent = math.min(Percent,1)
						Percent = math.max(0,Percent)
						
					draw.RoundedBox(0, PosX+10, PosY + (PlayerCount*(SizeY+Spacing)) + 33,(SizeX-20), 8, Color(0,0,0,200))
					if Percent > 0 then
						draw.RoundedBox(0, PosX+10, PosY + (PlayerCount*(SizeY+Spacing)) + 33,(SizeX-20)*Percent, 8, BCol)
						draw.RoundedBox(0, PosX+12, PosY + (PlayerCount*(SizeY+Spacing)) + 35,(SizeX-24)*Percent, 4, BCol2)
					end
						draw.SimpleText("Armor: " .. target:Armor() .. " / 100" , "RXF_TrebOut_S17", PosX+SizeX/2, PosY+38  + (PlayerCount*(SizeY+Spacing)), TCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				end
				
				PlayerCount = PlayerCount + 1
			end
			
			
			
			DrawPlayerInfo(CurPartyDB.Master,true)
			for k,v in pairs(CurPartyDB.Players or {}) do
				if v != CurPartyDB.Master then
					DrawPlayerInfo(v,false)
				end
			end
		
		end
		
	
	end)
end



/* ──────────────────────────────────────────────
	String
────────────────────────────────────────────── */
if CLIENT then
	function String_Wrap(str,sizeX,font,data)
		if string.Right(str,2) == "!n" then str = str .. " " end
		local Result = data or {}
		surface.SetFont(font)
		-- 길이 체크
		local EntireWidth, Height = surface.GetTextSize(str)
		local EntireLength = string.len(str)
		

			for LengthCheck1 = 1, EntireLength do
				local ScanStr = string.Left(str,LengthCheck1)
				local ScanWidth,_ = surface.GetTextSize(ScanStr)
				if ScanWidth >= sizeX then
					local PreviousWord = string.Left(str,LengthCheck1 -1)
					local LastWord = string.Right(str,EntireLength - LengthCheck1+1)
					table.insert(Result,PreviousWord)
					return String_Wrap(LastWord,sizeX,font,Result)
				end
				if string.find(ScanStr,"!n") then
					local PreviousWord = string.Left(str,LengthCheck1)
					PreviousWord = string.gsub(PreviousWord,"!n","")
					local LastWord = string.Right(str,EntireLength - LengthCheck1)
					table.insert(Result,PreviousWord)
					return String_Wrap(LastWord,sizeX,font,Result)
				end
				
			end
			
			table.insert(Result,str)
			return Result
		
	end
end


/* ──────────────────────────────────────────────
	Request Panel
────────────────────────────────────────────── */
if CLIENT then
	function CreateRequestPanel()
			local P = vgui.Create("RequestPanel")
			P:SetPos(ScrW()-300,ScrH())
			P.CreatedTime = CurTime()
			return P
	end



	local PANEL = {}

	function PANEL:Think()
		if !self.CreatedTime then return end

		local Delta = CurTime() - self.CreatedTime
		self:SetPos(ScrW()-350,ScrH() - math.min(Delta,0.2)*1100)
		
		if Delta > 10 then
			self:Remove()
			return
		end
	end
	function PANEL:Init()
		self:SetSize(300,200)
		self.AcceptFunction = function() end
		
		local AcceptButton = vgui.Create("Party_DSWButton",self)
			AcceptButton:SetSize(100,20)
			AcceptButton:SetPos(30,175)
			AcceptButton:SetTexts("Accept")
			AcceptButton.Click = function(slf)
				self:AcceptFunction()
				self:Remove()
			end
		
		local CloseButton = vgui.Create("Party_DSWButton",self)
			CloseButton:SetSize(100,20)
			CloseButton:SetPos(160,175)
			CloseButton:SetTexts("Cancel")
			CloseButton.Click = function(slf)
				self:Remove()
			end
	end
	function PANEL:SetText(text)
		self.TextData = String_Wrap(text,270,"RXF_Treb_S18")
	end

	function PANEL:Paint()
			draw.RoundedBox(1, 0, 0, self:GetWide(), self:GetTall(), RXPartySys.Color.RP.MainBG)
			draw.RoundedBox(0, 0, 0, self:GetWide(), 1, RXPartySys.Color.RP.Boarder)
			draw.RoundedBox(0, 0, 0, 1, self:GetTall(), RXPartySys.Color.RP.Boarder)
			
			draw.RoundedBox(0, self:GetWide()-1, 0, 1, self:GetTall(), RXPartySys.Color.RP.Boarder)
			draw.RoundedBox(0, 0, self:GetTall()-1, self:GetWide(), 1, RXPartySys.Color.RP.Boarder)
			
					draw.RoundedBox(4, 1, 0, self:GetWide()-2, 20, RXPartySys.Color.RP.TitleBG)
					draw.RoundedBox(2, 1, 0, self:GetWide()-2, 1, RXPartySys.Color.RP.Boarder)
					draw.RoundedBox(2, 1, 19, self:GetWide()-2, 1, RXPartySys.Color.RP.Boarder)
					draw.SimpleText("Message", "RXF_Treb_S20", 10, 10, RXPartySys.Color.RP.TitleText, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

					
			for k,v in pairs(self.TextData or {}) do
				draw.SimpleText(v, "RXF_Treb_S18", 150, 20+k*15 , RXPartySys.Color.RP.Messages, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			
		if !self.CreatedTime then return end

		local Delta = CurTime() - self.CreatedTime
			draw.SimpleText("This window will dissapear after " .. math.Round(10-Delta) .. " Sec", "RXF_Treb_S20", 150, 165 , RXPartySys.Color.RP.RemoveTimeMessage, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end


	vgui.Register("RequestPanel", PANEL, "Panel")
end