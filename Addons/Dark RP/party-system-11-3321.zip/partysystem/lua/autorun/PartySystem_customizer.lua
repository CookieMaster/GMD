RXPartySys = {}

RXPartySys.ChatCommand = "!party"
RXPartySys.InviteCommand = "!invite"
RXPartySys.WhipserCommand = "/p" -- Party chat.

RXPartySys.MaxPartyPlayerAmount = 7
RXPartySys.EnableNoDamageBetweenPartyPlayer = true -- set this to false if you want to make player damage same party player

RXPartySys.MaxPartyNameLength = 25
RXPartySys.MinPartyNameLength = 3

	-- Party Players HUD
	RXPartySys.PPH = {}
	RXPartySys.PPH.Position = {10,10} -- x,y
	RXPartySys.PPH.SizeX = 200
	RXPartySys.PPH.SpacingY = 10
	RXPartySys.PPH.EnableArmorDisplayOnHUD = false

	
/* ─────────────────────────────────────────────────────────────
	Color Part -    < BLUE LINE THEME >
───────────────────────────────────────────────────────────── */
	RXPartySys.Color = {}

		-- Player Ring ( on foot )
		RXPartySys.Color.Ring = Color(0,150,255,255)
		RXPartySys.Color.RingMaster = Color(0,255,255,255)
		
		-- Every Buttons
		RXPartySys.Color.EB = {}
		RXPartySys.Color.EB.Boarder = Color(0,150,255,255)
		RXPartySys.Color.EB.Text = Color(0,150,255,255)
		RXPartySys.Color.EB.FX = Color(0,150,255,255)
		
		-- Request Panel
		RXPartySys.Color.RP = {}
		RXPartySys.Color.RP.Boarder = Color(0,120,255,255)
		RXPartySys.Color.RP.MainBG = Color(0,20,50,240)
		RXPartySys.Color.RP.TitleBG = Color(0,120,255,20)
		RXPartySys.Color.RP.TitleText = Color(0,255,255,200)
		RXPartySys.Color.RP.Messages = Color(0,255,255,200)
		RXPartySys.Color.RP.RemoveTimeMessage = Color(0,255,255,200)
		
		
		-- Main Party GUI
		RXPartySys.Color.M = {}
		RXPartySys.Color.M.BG = Color(0,0,0,255)
		RXPartySys.Color.M.Boarder = Color(0,50,255,255)
		RXPartySys.Color.M.TopBar = Color(30,30,30,255)
		RXPartySys.Color.M.TopText = Color(0,125,255,255)
		RXPartySys.Color.M.ButtomBar = Color(30,30,30,255)
		
		RXPartySys.Color.M.InfoBoxBoarder = Color(0,50,255,100)
		RXPartySys.Color.M.InfoBoxInner = Color(0,0,0,255)
		
		
		-- Party Info Editing
		RXPartySys.Color.IE = {}
		RXPartySys.Color.IE.TopBG = Color(0,80,255,50)
		RXPartySys.Color.IE.TopText = Color(0,255,255,255)
		RXPartySys.Color.IE.Texts = Color(0,120,255,255)
		
		RXPartySys.Color.IE.TextEntryLines = Color(0,255,255,255)
		RXPartySys.Color.IE.TextEntryText = Color(0,255,255,255)
		
		
			-- Party List
			RXPartySys.Color.M.PL = {}
			
				-- Title
				RXPartySys.Color.M.PL.TopBGBoarder = Color(0,50,255,255)
				RXPartySys.Color.M.PL.TopBG = Color(0,0,0,255)
				RXPartySys.Color.M.PL.TopBGText = Color(0,150,255,255)
			
				-- Items
				RXPartySys.Color.M.PL.ItemBGBoarder = Color(0,50,150,255)
				RXPartySys.Color.M.PL.ItemBG = Color(0,0,0,255)
				RXPartySys.Color.M.PL.ItemBGHoverFX = Color(0,0,180,255)
				RXPartySys.Color.M.PL.TEXT_Title = Color(0,120,255,255)
				RXPartySys.Color.M.PL.TEXT_Players = Color(0,255,255,150)
				
			-- Party Info
			RXPartySys.Color.M.PI = {}
			
				-- Title
				RXPartySys.Color.M.PI.TopBG = Color(0,40,80,255)
				RXPartySys.Color.M.PI.TEXT_TopBGTitle = Color(0,255,255,255)
				RXPartySys.Color.M.PI.TEXT_TopBGPlayers = Color(0,150,255,120)
				RXPartySys.Color.M.PI.TEXT_TopBGMaster = Color(0,50,255,255)
				
				-- Setting Buttons
				RXPartySys.Color.M.PI.SettingBG = Color(0,25,80,255)
				RXPartySys.Color.M.PI.SettingFX = Color(0,0,50,255)
				RXPartySys.Color.M.PI.SettingText = Color(0,255,255,255)
				
				-- Players Button
				RXPartySys.Color.M.PI.PlayersBG = Color(0,40,80,255)
				RXPartySys.Color.M.PI.PlayersName = Color(0,150,255,255)
				RXPartySys.Color.M.PI.PlayersNameMaster = Color(0,255,255,255)