if SERVER then
	include("bank_server.lua")
	AddCSLuaFile("bank_client.lua")
	
	AddCSLuaFile("autorun/bank_load.lua")
elseif CLIENT then
	include("bank_client.lua")
end