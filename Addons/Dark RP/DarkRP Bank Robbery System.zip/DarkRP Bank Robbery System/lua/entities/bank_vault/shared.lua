ENT.Type = "anim"
ENT.PrintName = "The Bank"
ENT.Author = "Crap-Head"