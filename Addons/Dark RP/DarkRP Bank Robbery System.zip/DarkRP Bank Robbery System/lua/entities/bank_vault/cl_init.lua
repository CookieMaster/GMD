include("shared.lua")

function BANK_RestartCooldown( um )
	LocalPlayer().RobberyCooldown = CurTime() + um:ReadLong()
end
usermessage.Hook("BANK_RestartCooldown", BANK_RestartCooldown)

function BANK_KillCooldown() 
	LocalPlayer().RobberyCooldown = 0
end
usermessage.Hook("BANK_KillCooldown", BANK_KillCooldown)

function BANK_RestartCountdown( um )
	LocalPlayer().RobberyCountdown = CurTime() + um:ReadLong()
end
usermessage.Hook("BANK_RestartTimer", BANK_RestartCountdown)

function BANK_KillCountdown() 
	LocalPlayer().RobberyCountdown = 0
end
usermessage.Hook("BANK_KillTimer", BANK_KillCountdown)

function ENT:Initialize()
end

function ENT:Draw()
	self:DrawModel()
	
	local pos = self:GetPos() + Vector(0, 0, 1) * math.sin(CurTime() * 2) * 2
	local PlayersAngle = LocalPlayer():GetAngles()
	local ang = Angle( 0, PlayersAngle.y - 180, 0 )
	
	ang:RotateAroundAxis(ang:Right(), -90)
	ang:RotateAroundAxis(ang:Up(), 90)
	
	local BankAmount = GetGlobalInt( "BANK_VaultAmount" )
	
	cam.Start3D2D(pos, ang, 1)
		if LocalPlayer().RobberyCooldown and LocalPlayer().RobberyCooldown > CurTime() then
			draw.SimpleTextOutlined("Robbery Cooldown", "UiBold", 0, -130, Color(150, 150, 150, 255), 1, 1, 1.5, Color(0, 0, 0, 255))
			draw.SimpleTextOutlined(string.ToMinutesSeconds(math.Round(LocalPlayer().RobberyCooldown - CurTime())), "UiSmallerThanBold", 0, -115, Color(150, 150, 150, 255), 1, 1, 1.5, Color(0, 0, 0, 255))
		end
		if LocalPlayer().RobberyCountdown and LocalPlayer().RobberyCountdown > CurTime() then
			draw.SimpleTextOutlined("Robbery Countdown", "UiBold", 0, -130, Color(150, 150, 150, 255), 1, 1, 1.5, Color(0, 0, 0, 255))
			draw.SimpleTextOutlined(string.ToMinutesSeconds(math.Round(LocalPlayer().RobberyCountdown - CurTime())), "UiSmallerThanBold", 0, -115, Color(150, 150, 150, 255), 1, 1, 1.5, Color(0, 0, 0, 255))
		end
		draw.SimpleTextOutlined("Bank Vault", "UiBold", 0, -95, Color(153, 0, 0, 255), 1, 1, 1.5, Color(0, 0, 0, 255))
		draw.SimpleTextOutlined("$".. util.RobberyFormatNumber(BankAmount), "UiBold", 0, -78, Color(0, 153, 0, 255), 1, 1, 1.5, Color(0, 0, 0, 255))
    cam.End3D2D()
end