include("bank_shared.lua")
AddCSLuaFile("bank_shared.lua")

local BANK_CUSTOM_MoneyTimer = 60 -- This is the time that defines when money is added to the bank. In seconds! [Default = 60]
local BANK_CUSTOM_MoneyOnTime = 500 -- This is the amount of money to be added to the bank every x minutes/seconds. Defined by the setting above. [Default = 500]
local BANK_Custom_Max = 30000 -- The maximum the bank can have. Set to 0 for no limit. [Default = 30000]
local BANK_Custom_AliveTime = 5 -- The amount of MINUTES the player must stay alive before he will receive what the bank has. IN MINUTES! [Default = 5]
local BANK_Custom_CooldownTime = 20 -- The amount of MINUTES the bank is on a cooldown after a robbery! (Doesn't matter if the robbery failed or not) [Default = 20]
local BANK_Custom_RobberyDistance = 500 -- The amount of space the player can move away from the bank entity, before the bank robbery fails. [Default = 500]
local BANK_Custom_PlayerLimit = 1 -- The amount of players there must be on the server before you can rob the bank. [Default = 5]
local BANK_Custom_KillReward = 1000 -- The amount of money a person is rewarded for killing the bank robber. [Default = 1000]
local BANK_Custom_PoliceRequired = 3 -- The amount of police officers there must be before a person can rob the bank. [Default = 3] 

local RequiredTeams = { -- These are the names of the jobs that counts with the option above, the police required. The amount of players on these teams are calcuated together in the count.
	"Civil Protection",
	"Civil Protection Chief" -- THE LAST LINE SHOULD NOT HAVE A COMMA AT THE END. BE AWARE OF THIS WHEN EDITING THIS!
}

local GovernmentTeams = { -- These are the teams that will receive a notify when a player is trying to rob a bank. Use the actual team name, as shown below.
	"Civil Protection",
	"Civil Protection Chief",
	"Mayor" -- THE LAST LINE SHOULD NOT HAVE A COMMA AT THE END. BE AWARE OF THIS WHEN EDITING THIS!
}

local AllowedTeams = { -- These are the teams that are allowed to rob the bank.
	"Citizen",
	"Gangster",
	"Mob boss",
	"Gun Dealer",
	"Medic",
	"Hobo" -- THE LAST LINE SHOULD NOT HAVE A COMMA AT THE END. BE AWARE OF THIS WHEN EDITING THIS!
}

function MapInit()
	BANK_AddMoneyTimer()
	SetGlobalInt( "BANK_VaultAmount", 0 )
	BankIsBeingRobbed = false
end
timer.Simple(1, function() MapInit() end)

function BANK_PlayerDeath( ply, inflictor, attacker )
	if ply.IsRobbingBank then
		GAMEMODE:Notify(ply, 1, 5,  "You have failed to rob the bank!")
		ply:SetDarkRPVar("wanted", false)
		attacker:AddMoney(BANK_Custom_KillReward)
		
		for k, v in pairs(player.GetAll()) do
			if table.HasValue( GovernmentTeams, team.GetName(v:Team()) ) then
				GAMEMODE:Notify(v, 1, 7,  "The bank robbery has failed!")
			end
		end
		
		umsg.Start("BANK_KillTimer")
		umsg.End()
						
		BANK_StartCooldown()
						
		ply.IsRobbingBank = false
		BankIsBeingRobbed = false
	end
end
hook.Add("PlayerDeath", "BANK_PlayerDeath", BANK_PlayerDeath)

function BANK_RobberyFailCheck()
	for k, v in pairs(player.GetAll()) do
		if v.IsRobbingBank then
			BankRobber = v
			break
		end
	end
	
	if IsValid(BankRobber) then
		for _, ent in pairs(ents.FindByClass("bank_vault")) do
			if ent:IsValid() && BankRobber:GetPos():Distance(ent:GetPos()) >= BANK_Custom_RobberyDistance then
				if BankIsBeingRobbed then
					GAMEMODE:Notify(BankRobber, 1, 5,  "You have moved to far away from the bank vault, and the robbery has failed!")
					BankRobber:SetDarkRPVar("wanted", false)
					
					for k, v in pairs(player.GetAll()) do
						if table.HasValue( GovernmentTeams, team.GetName(v:Team()) ) then
							GAMEMODE:Notify(v, 1, 7,  "The bank robbery has failed!")
						end
					end
			
					umsg.Start("BANK_KillTimer")
					umsg.End()
									
					BANK_StartCooldown()
									
					BankRobber.IsRobbingBank = false
					BankIsBeingRobbed = false
					BankRobber = nil
				end
			end
		end
	end
end
hook.Add("Tick", "BANK_RobberyFailCheck", BANK_RobberyFailCheck)

function BANK_BeginRobbery( ply )
	local RequiredTeamsCount = 0
	local RequiredPlayersCounted = 0
	
	for k, v in pairs(player.GetAll()) do
		RequiredPlayersCounted = RequiredPlayersCounted + 1
		
		if table.HasValue( RequiredTeams, team.GetName(v:Team()) ) then
			RequiredTeamsCount = RequiredTeamsCount + 1
		end
		
		if RequiredPlayersCounted == #player.GetAll() then
			if RequiredTeamsCount < BANK_Custom_PoliceRequired then
				GAMEMODE:Notify(ply, 1, 5, "There has to be "..BANK_Custom_PoliceRequired.." police officers before you can rob the bank.")
				return
			end
		end
	end
	
	if BankCooldown then
		GAMEMODE:Notify(ply, 1, 5,  "You cannot rob the bank yet!")
		return
	end
	if GetGlobalInt( "BANK_VaultAmount" ) <= 0 then
		GAMEMODE:Notify(ply, 1, 5, "There are no money in the bank!")
		return
	end
	if BankIsBeingRobbed then
		GAMEMODE:Notify(ply, 1, 5, "The bank is already being robbed!")
		return
	end
	if #player.GetAll() < BANK_Custom_PlayerLimit then
		GAMEMODE:Notify(ply, 1, 5, "There must be "..BANK_Custom_PlayerLimit.." players before you can rob the bank.")
		return
	end
	if not table.HasValue( AllowedTeams, team.GetName(ply:Team()) ) then
		GAMEMODE:Notify(ply, 1, 5, "You are not allowed to rob the bank with your current team!")
		return
	end
	
	
	for k, v in pairs(player.GetAll()) do
		if table.HasValue( GovernmentTeams, team.GetName(v:Team()) ) then
			GAMEMODE:Notify(v, 1, 7,  "The bank is being robbed!")
		end
	end
	
	BankIsBeingRobbed = true
	GAMEMODE:Notify(ply, 1, 5, "You have began a robbery on the bank!")
	GAMEMODE:Notify(ply, 1, 10, "You must stay alive for ".. BANK_Custom_AliveTime .." minutes to receive the banks money.")
	GAMEMODE:Notify(ply, 1, 13, "If you go to far away from the bank vault, the robbery will also fail!")
	ply.IsRobbingBank = true
	ply:SetDarkRPVar("wanted", true)
	ply:SetDarkRPVar("wantedReason", "Bank Robbery")
				
	umsg.Start("BANK_RestartTimer")
		umsg.Long(BANK_Custom_AliveTime * 60)
	umsg.End()
				
	timer.Simple( BANK_Custom_AliveTime * 60, function()
		if ply.IsRobbingBank then
			GAMEMODE:Notify(ply, 1, 5,  "You have succesfully robbed the bank!")
			GAMEMODE:Notify(ply, 1, 5,  "You have been given $"..util.RobberyFormatNumber(GetGlobalInt( "BANK_VaultAmount" )).." for succesfully robbing the bank.")
			for k, v in pairs(player.GetAll()) do
				if table.HasValue( GovernmentTeams, team.GetName(v:Team()) ) then
					GAMEMODE:Notify(v, 1, 7,  "The bank robbery has succeseded and the money is now long gone!")
				end
			end
						
			ply:SetDarkRPVar("wanted", false)
			umsg.Start("BANK_KillTimer")
			umsg.End()
						
			BANK_StartCooldown()
						
			ply.IsRobbingBank = false
			ply:AddMoney( GetGlobalInt( "BANK_VaultAmount" ) )
						
			SetGlobalInt( "BANK_VaultAmount", 0 )
			BankIsBeingRobbed = false
		end
	end)
end

function BANK_StartCooldown()
	BankCooldown = true
	umsg.Start("BANK_RestartCooldown")
		umsg.Long(BANK_Custom_CooldownTime * 60)
	umsg.End()
	
	timer.Simple( BANK_Custom_CooldownTime * 60, function()
		BankCooldown = false
		umsg.Start("BANK_KillCooldown")
		umsg.End()
	end)
end

function BANK_AddMoneyTimer()
	timer.Create("BANK_MoneyTimer", BANK_CUSTOM_MoneyTimer, 0, function()
		if not BankIsBeingRobbed then
			if BANK_Custom_Max > 0 then
				SetGlobalInt( "BANK_VaultAmount", math.Clamp( (GetGlobalInt( "BANK_VaultAmount" ) + BANK_CUSTOM_MoneyOnTime), 0, BANK_Custom_Max) )
			else
				SetGlobalInt( "BANK_VaultAmount", (GetGlobalInt( "BANK_VaultAmount" ) + BANK_CUSTOM_MoneyOnTime) )
			end
		end
	end)
end

function BANK_Disconnect( ply )
	if ply.IsRobbingBank then
		ply:SetDarkRPVar("wanted", false)
			
		for k, v in pairs(player.GetAll()) do
			if table.HasValue( GovernmentTeams, team.GetName(v:Team()) ) then
				GAMEMODE:Notify(v, 1, 7,  "The bank robbery has failed!")
			end
		end
			
		umsg.Start("BANK_KillTimer")
		umsg.End()
							
		BANK_StartCooldown()
							
		ply.IsRobbingBank = false
		BankIsBeingRobbed = false
	end
end
hook.Add( "PlayerDisconnected", "BANK_Disconnect", BANK_Disconnect )