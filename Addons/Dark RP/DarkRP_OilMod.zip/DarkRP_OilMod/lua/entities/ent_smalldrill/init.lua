AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )

include( 'shared.lua' )

function ENT:Initialize( )
	self:SetModel("models/props/de_nuke/smokestack01.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self.MaxOil = KunzOilMod.Drills[self:GetClass()]
	timer.Simple(KunzOilMod.Drills[self:GetClass()].Speed, function() Kun_OilPop(self) end )
	self:GetPhysicsObject():SetMass(1)
end

function ENT:OnTakeDamage( dmg ) 
	return false
end

function ENT:AcceptInput( name, activator, caller )
    if ( name == "Use" && activator:IsPlayer( ) ) then
		net.Start("Kun_OilWell_Menu")
			net.WriteString(self.Entity:GetClass())
		net.Send(activator)
	end
end
