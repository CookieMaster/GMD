include( 'shared.lua' )
 
ENT.RenderGroup = RENDERGROUP_BOTH

function ENT:Draw( )
    self.Entity:DrawModel( )
	local angz = self.Entity:GetAngles()
	local ang = Angle(angz.p,angz.y + 90,angz.r + 90)
	local pos = self.Entity:GetPos()
	pos:Add(self.Entity:GetForward() * 50)
	pos:Add(Vector(0,0,50))
	cam.Start3D2D(pos, ang, 0.2)
			draw.SimpleText("Oil: "..self.Entity:GetNWInt("StoredOil"), "TargetID", 0, 0, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
end
