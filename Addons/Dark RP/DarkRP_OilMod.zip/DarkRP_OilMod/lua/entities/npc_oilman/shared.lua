ENT.Base = "base_ai" 
ENT.Type = "ai"
ENT.PrintName		= "Oil Man"
ENT.Author			= "Kunit"
ENT.AutomaticFrameAdvance = true

function ENT:SetAutomaticFrameAdvance( bUsingAnim )
	self.AutomaticFrameAdvance = bUsingAnim
end
