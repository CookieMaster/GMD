AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )

include( 'shared.lua' )

function ENT:Initialize( )
	self:SetModel("models/props_c17/canister_propane01a.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self.MaxOil = KunzOilMod.TankStorage
	self:GetPhysicsObject():SetMass(1)
end

function ENT:OnTakeDamage( dmg ) 
	return false
end

function ENT:AcceptInput( name, activator, caller )
    if ( name == "Use" && activator:IsPlayer( ) ) then
		net.Start("Kun_OilTank_Menu")
			net.WriteInt(self.Entity:GetNWInt("StoredOil"),32)
		net.Send(activator)
	end
end
