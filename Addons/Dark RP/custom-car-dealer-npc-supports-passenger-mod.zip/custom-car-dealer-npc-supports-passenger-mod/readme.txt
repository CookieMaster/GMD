If you have darkrp2.4.3 then use " cardealer for darkrp2.4.3 "
If you have darkrp2.5 then use " cardealer for darkrp2.5 "

1.Paste boonpc in addons.
2.Don't resell or post the car dealer anywhere else or I will find you ban(kill) you



