
/*------------------------------------*\
	Create the Fonts and add the Images
\*------------------------------------*/
surface.CreateFont("InfoCarH2", {
		font = "Arial",
		size = 25,
		weight = 700,
		antialias = true,
		italic = true
})

surface.CreateFont("InfoCarH4", {
		font = "Arial",
		size = 15,
		weight = 550,
		antialias = true,
		shadow = true

})

surface.CreateFont("Buttons", {
		font = "DermaDefault",
		size = 18,
		weight = 600,
})

surface.CreateFont( "Names", {
	font = "Arial Narrow",
	size = 22,
	weight = 700,
	shadow = true
} )

local background = Material("boowman/bg5.png","noclamp")

/*-------------------*\
	Format the number
\*-------------------*/
local function formatNumber(n)
	if not n then return "" end
	if n >= 1e14 then return tostring(n) end
    n = tostring(n)
    local sep = sep or "."
    local dp = string.find(n, "%.") or #n+1
	for i=dp-4, 1, -3 do
		n = n:sub(1, i) .. sep .. n:sub(i+1)
    end
    return n
end

/*-------------------*\
	Create the cars
\*-------------------*/

function AddCar(id,cname,cscript,cmake,ctype,cicon,cprice,cmodel,cspeed,cpower,crmp,cclass)
	local money = formatNumber(cprice)
	local sid = LocalPlayer():SteamID()

	carbg = vgui.Create("DPanel")
		carbg:SetTall(70)
		carbg:SetVisible(false)
		carbg.Paint = function(self)	
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(255,75,75,50))		
			surface.SetMaterial(background)
			surface.SetDrawColor(255,255,255,50)
			surface.DrawTexturedRectUV( 0, 0, self:GetWide(), self:GetTall(), 0, 0, self:GetWide()/32, self:GetTall()/32 )
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(0,0,0,120))	
			surface.SetDrawColor(0,0,0)
			surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())
		end
		carbg.items = {}		
		carbg.vehiclename = cname
		carbg.carprice = cprice	
		carbg.items.carbg = carbg
if cicon == 0 then icon = "vgui/entities/question" else icon = cicon end
	local caricon = vgui.Create("DImage",carbg)
		caricon:SetSize(62,62)
		caricon:SetPos(4,4)
		caricon:SetImage(icon)	

	local name = vgui.Create("DLabel",carbg)
		name:SetPos(72,5)
		name:SetFont("InfoCarH2")
		name:SetTextColor(color_white)
		name:SetText(cname)
		name:SizeToContents()

if not LocalPlayer():canAfford(cprice) then
	pricecolor = Color(200,0,0)
else
	pricecolor = Color(255,255,255)
end

if string.len(cprice) == 2 then 
	x = 375
elseif string.len(cprice) == 3 then
	x = 365
elseif string.len(cprice) == 4 then
	x = 348
elseif string.len(cprice) == 5 then
	x = 335
elseif string.len(cprice) == 6 then
	x = 325
elseif string.len(cprice) == 7 then
	x = 305
elseif string.len(cprice) == 8 then
	x = 290
end
	local price = vgui.Create("DLabel",carbg)
		price:SetPos(carbg:GetWide()+x,5)
		price:SetFont("InfoCarH2")
		price:SetTextColor(pricecolor)
		price:SetText("$"..money)
		price:SizeToContents()
	carbg.items.price = price		
	
	local company = vgui.Create("DLabel",carbg)
		company:SetPos(72,32)
		company:SetFont("InfoCarH4")
		company:SetTextColor(color_white)
		company:SetText("Company: "..cmake)
		company:SizeToContents()	

	local model = vgui.Create("DLabel",carbg)
		model:SetPos(72,50)
		model:SetFont("InfoCarH4")
		model:SetTextColor(color_white)
		model:SetText("Model: "..ctype)
		model:SizeToContents()		
		
local buyover = Color(65,65,65,0)	
	local buy = vgui.Create("DButton", carbg)
		buy:SetPos(400,carbg:GetTall()-30)
		buy:SetSize(80, 25)
		buy:SetFont("Buttons")
		buy:SetText("Purchase")
		buy:SetVisible(false)
		buy:SetTextColor(Color(255,255,255))
		buy.Paint = function(self)
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(65,65,65,255))
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),buyover)
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())
		end
		buy.DoClick = function(self)
			surface.PlaySound("buttons/button9.wav")
			if LocalPlayer():canAfford(cprice) then
				Derma_Query("Are you sure that you want to buy "..cname.."?".."\nIf you sell your car you will get only a half.", "Buy "..cname,
				"No", function() end,
				"Yes", function()
					net.Start('BuyCar')
						net.WriteFloat(cprice)
						net.WriteEntity(LocalPlayer())
						net.WriteString(cscript)
						net.WriteString(cmodel)
						net.WriteString(cname)
					net.SendToServer()
			if IsValid(talkbg) then
				talkbg:Close()
			end
			if IsValid(carsbg) then
				carsbg:Close()
			end
			if IsValid(carpreview) then
				carpreview:Close()
			end
				end)
			else
				net.Start('Cannot')
					net.WriteFloat(cprice)
					net.WriteEntity(LocalPlayer())
					net.WriteString(cname)
				net.SendToServer()
			end
		end
		buy.OnCursorEntered = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			buyover = Color(255,255,255,50)
		end		
		buy.OnCursorExited = function()
			buyover = Color(65,65,65,0)
		end
	carbg.items.buy = buy	
	
local sellover = Color(65,65,65,0)	
	local sell = vgui.Create("DButton", carbg)
		sell:SetPos(400,carbg:GetTall()-30)
		sell:SetSize(80, 25)
		sell:SetFont("Buttons")
		sell:SetText("Sell")
		sell:SetVisible(false)
		sell:SetTextColor(Color(255,255,255))
		sell.Paint = function(self)
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(65,65,65,255))
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),sellover)
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())
		end
		sell.DoClick = function(self)
			surface.PlaySound("buttons/button9.wav")	
			Derma_Query("Are you sure that you want to sell "..cname.."?".."\nThis action can't be undone.", "Sell "..cname,
				"No", function() end,
				"Yes", function()
					net.Start('Sell')
						net.WriteFloat(cprice)
						net.WriteEntity(LocalPlayer())
						net.WriteString(cname)
					net.SendToServer()
					if IsValid(talkbg) then
						talkbg:Close()
					end
					if IsValid(carsbg) then
						carsbg:Close()
					end
					if IsValid(carpreview) then
						carpreview:Close()
					end
			end)
		end
		sell.OnCursorEntered = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			sellover = Color(255,255,255,50)
		end		
		sell.OnCursorExited = function()
			sellover = Color(65,65,65,0)
		end
	carbg.items.sell = sell
	

local prevover = Color(65,65,65,0)	
	preview = vgui.Create("DButton", carbg)
		preview:SetPos(310,carbg:GetTall()-30)
		preview:SetSize(80, 25)
		preview:SetFont("Buttons")
		preview:SetText("Preview")
		preview:SetVisible(false)
		preview:SetTextColor(Color(255,255,255))
		preview.Paint = function(self)
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(65,65,65,255))
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),prevover)
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())
		end
		preview.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			if IsValid(carmodel) then
				carmodel:SetVisible(false)
			end			
			if IsValid(speed) then
				speed:SetVisible(false)
			end
			if IsValid(carpreview) then
				carpreview:SetVisible(true)
			end
			carmodel = vgui.Create("DModelPanel", carpreview)
				carmodel:SetSize(350, 300)
				carmodel:SetPos(0,25)
				carmodel:SetModel(cmodel)
				carmodel:SetCamPos(Vector( 100, 150, 80))
				carmodel:SetLookAt(Vector( -20, 0, 15))
				carmodel.hover = false
				carmodel.speed = 0
				carmodel.OnCursorEntered = function(self) self.hover = true end
				carmodel.OnCursorExited = function(self) self.hover = false end
				carmodel.LayoutEntity = function(self, ent)
					if self.hover then
						self.speed = math.min(self.speed + 0.05, 1)
					else
						self.speed = math.max(self.speed - 0.01, 0)
					end
					ent:SetAngles( ent:GetAngles() + Angle(0, self.speed, 0) )
				end -- Close Layout	
				
			speed = vgui.Create("DLabel",carpreview)
				speed:SetPos(10,30)
				speed:SetFont("InfoCarH4")
				speed:SetTextColor(color_white)
				speed:SetText("HorsePower: "..cpower.."\nMaxRPM: "..crmp.."\nSpeed: "..cspeed.." Mph")
				speed:SizeToContents()	
		end
		preview.OnCursorEntered = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			prevover = Color(255,255,255,50)
		end		
		preview.OnCursorExited = function()
			prevover = Color(65,65,65,0)
		end
	carbg.items.preview = preview
	
local spawnover = Color(65,65,65,0)	
	spawn = vgui.Create("DButton", carbg)
		spawn:SetPos(310,carbg:GetTall()-30)
		spawn:SetSize(80, 25)
		spawn:SetFont("Buttons")
		spawn:SetText("Spawn")
		spawn:SetVisible(false)
		spawn:SetTextColor(Color(255,255,255))
		spawn.Paint = function(self)
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(65,65,65,255))
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),spawnover)
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())
		end
		spawn.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			if IsValid(talkbg) then
				talkbg:Close()
			end
			if IsValid(carsbg) then
				carsbg:Close()
			end
			if IsValid(carpreview) then
				carpreview:Close()
			end
			net.Start('SpawnCar')
				net.WriteEntity(LocalPlayer())
				net.WriteString(cscript)
				net.WriteString(cmodel)
				net.WriteString(cname)
				net.WriteString(cclass)
			net.SendToServer()
		end -- Close DoClick
		spawn.OnCursorEntered = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			spawnover = Color(255,255,255,50)
		end		
		spawn.OnCursorExited = function()
			spawnover = Color(65,65,65,0)
		end
	carbg.items.spawn = spawn
	
	carslist:AddItem(carbg)
end

/*---------------------------------*\
	Create the car dealer dialog
\*----------------------------------*/

function options(id,parent,y,text,com,cscript,cmodel,cname)
local hover = Color(0,0,0,0)
	local option = vgui.Create("DButton",parent)
		option:SetPos(160,y)
		option:SetSize(talkbg:GetWide()-165,25)
		option:SetFont("DermaDefault")
		option:SetTextColor(Color(255,255,255,255))
		option:SetText(text)
		option.Paint = function(self)
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),hover)
			draw.RoundedBox(0,2,2,self:GetWide()-4,self:GetTall()-4,Color(50,50,50,200))
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())
		end
		option.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			if id == 1 then
			net.Start('car_away')
				net.WriteEntity(LocalPlayer())
				net.WriteString(cscript)
				net.WriteString(cmodel)
				net.WriteString(cname)
			net.SendToServer()
				if IsValid(talkbg) then
					talkbg:SetVisible(false)
				end		
				if IsValid(carsbg) then
					carsbg:SetVisible(false)
				end			
				if IsValid(carpreview) then
					carpreview:SetVisible(false)
				end
			elseif id == 2 then
				dialog = com
				if IsValid(carsbg) then
					carsbg:SetVisible(true)
				end
			elseif id == 3 then
				if IsValid(talkbg) then
				talkbg:Close()
				end
				if IsValid(carsbg) then
					carsbg:Close()
				end
				if IsValid(carpreview) then
					carpreview:Close()
				end
			end
		end
		option.OnCursorEntered = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			hover = Color(37,104,134,255)
		end		
		option.OnCursorExited = function()
			hover = Color(0,0,0,0)
		end
end

/*-------------------*\
	Create the Menus
\*-------------------*/

net.Receive("open_car_shop", function()
local mon = formatNumber(LocalPlayer():getDarkRPVar("money") or 0)

	local sid = LocalPlayer():SteamID()  
	vehicle = {}
	vehicle.PlyCars = {}
	vehicle.PlyCars[sid] = net.ReadTable()
	
	talkbg = vgui.Create("DFrame")
		talkbg:SetPos(ScrW()/2-250,ScrH()/2+155)
		talkbg:SetSize(510,200)
		talkbg:SetTitle("")
		talkbg:SetDraggable(false)
		talkbg:ShowCloseButton(false)
		talkbg:MakePopup()
		talkbg.Paint = function(self)		
			-- Background
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(19,26,26,220))
			surface.SetDrawColor(0,0,0)
			surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())	
			
			-- Top
			draw.RoundedBox(0,0,0,self:GetWide(),25,Color(37,104,134,200))
			surface.SetDrawColor(0,0,0)
			surface.DrawOutlinedRect(0,0,self:GetWide(),25)
			draw.DrawText(NPCSHOP.Name.."'s Car Dealer","Names",10,1,Color(255,255,255,255),TEXT_ALIGN_LEFT)
		end
		
	local plmodel = vgui.Create("DPanel",talkbg)
		plmodel:SetPos(5,27)
		plmodel:SetSize(150,talkbg:GetTall()-32)
		plmodel.Paint = function(self)
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(0,0,0,200))
			
			surface.SetMaterial(background)
			surface.SetDrawColor(255,255,255,200)
			surface.DrawTexturedRectUV( 0, 0, self:GetWide(), self:GetTall(), 0, 0, self:GetWide()/32, self:GetTall()/32 )
	
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(0,0,0,200))			
			
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())
		end	
		
	local model = vgui.Create("DModelPanel",plmodel)
		model:SetModel(LocalPlayer():GetModel())
function model:LayoutEntity( Entity ) return end
		model:SetPos(0,plmodel:GetTall()-171)
		model:SetAnimated(false)
		model:SetSize(170,170)
		model:SetCamPos( Vector( 20, -5, 60))
		model:SetLookAt( Vector( 0, 0, 62) )
	
dialog = "Welcome to "..NPCSHOP.Name.."'s Car Dealer.\nI'm the one in charge of cars, how can I help you?"
	local npctalk = vgui.Create("DPanel",talkbg)
		npctalk:SetPos(160,27)
		npctalk:SetSize(talkbg:GetWide()-165,80)
		npctalk.Paint = function(self)
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(0,0,0,200))
			
			surface.SetMaterial(background)
			surface.SetDrawColor(255,255,255,200)
			surface.DrawTexturedRectUV( 0, 0, self:GetWide(), self:GetTall(), 0, 0, self:GetWide()/32, self:GetTall()/32 )
	
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(0,0,0,200))			
			
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())		
			draw.DrawText(dialog,"DermaDefault",8,5,Color(255,255,255,255),TEXT_ALIGN_LEFT)
		end
		
// Options
for unique, v in pairs(GetTheStoredTable()) do
	options(1,talkbg,110,NPCSHOP.Question_1,NPCSHOP.Answer_1,v.Script,v.Model,v.Name)
	options(2,talkbg,140,NPCSHOP.Question_2,NPCSHOP.Answer_2,v.Script,v.Model,v.Name)
	options(3,talkbg,170,NPCSHOP.Question_3,NPCSHOP.Answer_3,v.Script,v.Model,v.Name)
end
// Options		
	
	carsbg = vgui.Create("DFrame")
		carsbg:SetPos(ScrW()/2-250,ScrH()/2-350)
		carsbg:SetSize(510,500)
		carsbg:SetTitle("")
		carsbg:SetDraggable(false)
		carsbg:ShowCloseButton(false)
		carsbg:SetVisible(false)
		carsbg:MakePopup()
		carsbg.Paint = function(self)
			-- Background
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(19,26,26,220))
			surface.SetDrawColor(0,0,0)
			surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())	
			
			-- Top
			draw.RoundedBox(0,0,0,self:GetWide(),25,Color(37,104,134,200))
			surface.SetDrawColor(0,0,0)
			surface.DrawOutlinedRect(0,0,self:GetWide(),25)
			draw.DrawText("Balance: $"..mon,"Names",10,1,Color(255,255,255,255),TEXT_ALIGN_LEFT)
		end
	
	carslist = vgui.Create("DPanelList",carsbg)
		carslist:Dock(FILL)
		carslist:EnableVerticalScrollbar(true)
		carslist:SetSpacing(4)


for unique, data in pairs(GetTheStoredTable()) do
	AddCar(unique,data.Name,data.Script,data.Make,data.Type,data.Icon,data.Price,data.Model,data.Speed,data.Power,data.RMP,data.Class)
end	
	
	carpreview = vgui.Create("DFrame")
		carpreview:SetPos(ScrW()/2+270,ScrH()/2-350)
		carpreview:SetSize(350,350)
		carpreview:SetTitle("")
		carpreview:SetDraggable(false)
		carpreview:ShowCloseButton(false)
		carpreview:SetVisible(false)
		carpreview:MakePopup()
		carpreview.Paint = function(self)
			-- Background
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(19,26,26,220))
			surface.SetDrawColor(0,0,0)
			surface.DrawOutlinedRect(0,0,self:GetWide(),self:GetTall())	
			-- Top
			draw.RoundedBox(0,0,0,self:GetWide(),25,Color(37,104,134,200))
			surface.SetDrawColor(0,0,0)
			surface.DrawOutlinedRect(0,0,self:GetWide(),25)
			draw.DrawText(NPCSHOP.Name.."'s Car Dealer","Names",10,1,Color(255,255,255,255),TEXT_ALIGN_LEFT)
			-- Bottom					
			draw.RoundedBox(0,0,self:GetTall()-25,self:GetWide(),25,Color(37,104,134,200))
			surface.SetDrawColor(0,0,0)
			surface.DrawOutlinedRect(0,self:GetTall()-25,self:GetWide(),25)
			draw.DrawText("Go with the cursor over the vehicle to rotate it.","Names",20,self:GetTall()-23,color_white,TEXT_ALIGN_LEFT)	
		end
		
	for k,v in pairs(carslist:GetItems()) do	
		if vehicle.PlyCars[sid][v.vehiclename] then
			v.items.sell:SetVisible(true)
			v.items.spawn:SetVisible(true)
			v.items.price:SetTextColor(Color(40,200,0))
			v.items.price:SetText("$"..formatNumber(v.carprice/2))
		else
			v.items.buy:SetVisible(true)
			v.items.preview:SetVisible(true)
		end
	end		
end)