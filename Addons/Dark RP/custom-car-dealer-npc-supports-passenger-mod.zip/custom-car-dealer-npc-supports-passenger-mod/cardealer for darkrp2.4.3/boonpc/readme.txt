/*-----------------------------------------*\
	How To Create a Car
\*-----------------------------------------*/

VEHICLE = {}
VEHICLE.CarSpawn = {}

VEHICLE.Name = "Jeep" 	-- Set the vehicle a name which player will see when they open the menu.
VEHICLE.Make = "Valve" 	-- Set a company name that made the car ex: BMW,Mercedes,Volvo...
VEHICLE.Type = "1.00" 	-- Set the type of the car ex: GT500,TT,ZL1
VEHICLE.ID = "J" 		-- Set an UNIQUE ID from A to Z you also can use [,/
VEHICLE.Script = "scripts/vehicles/sentry/zr1.txt" -- Set the vehicle script. When you open a pack with vehicles you will find it the scripts the same folder where is materials,lua,models...
VEHICLE.Class = "zr1tdm"							-- This is the entity name that will be used for passenger mod. Type in console rp_getvehicles and that is the list with all your vehicles installed.
VEHICLE.Model = "models/sentry/zr1.mdl" -- Set the car model.
VEHICLE.Icon = "entities/jeep.png" -- Set the car icon that people will see when they open the menu
								   -- it should be located in materials/ but when you type the location 
								   -- you don't need to add materials
								   -- If you set there a 0 there will be an automatically icon set.
VEHICLE.Price = 5000 	-- Set the vehicle price

-- You can find this details in "scrips/<foldername>/<filename>.txt"
VEHICLE.Speed = 34 		-- Set the Speed the player will see when he clicks on the preview button
VEHICLE.Power = 450		-- Set the HorsePower the player will see when he clicks on the preview button
VEHICLE.RMP = 15000		-- Set the RPM the player will see when he clicks on the preview button

/*-----------------------------------------*\
	How to setup the NPC
\*-----------------------------------------*/

1. Go lua/shop/ and open setup.lua
2. Line 8 Set the NPC Name use normal name like : Mike, Duncan, Batman, because the rest will be there automatically "<Name you set>'s Car Dealer"
3. There can be set multiple spawn points
Example: 
NPCSHOP.SpawnPoint["map name with out .bsp"] = {
	{
		Pos = Vector(0,0,0),
		Ang = Angle(0, 90, 0)
	},	

	{
		Pos = Vector(0,200,0),
		Ang = Angle(0, 90, 0)
	},
}

4. Type in console "getpos". You should see something like this in red: setpos 1203.085205 143.346237 -79.968750;setang 2.686207 -82.182213 0.000000

5 There are also multiple spawn points for the car
Example: 
NPCSHOP.CasSpawn["rp_downtown_v4c_v2"] = {
	{
		Pos = Vector(1200.521973, -981.646912, -139.968750),
		Ang = Angle(0,90,0)	
	},
	
	{
		Pos = Vector(954.576599, -976.011536, -139.968750),
		Ang = Angle(0,90,0)	
	},
}
6. Type in console "getpos". You should see something like this in red: setpos 1203.085205 143.346237 -79.968750;setang 2.686207 -82.182213 0.000000
/*-----------------------------------------*\
	Force Player to download 
\*-----------------------------------------*/

1. Paste download.lua in garrysmod/lua/autorun/server this has to be in on your server not your gmod.
2. Paste the materials folder in garrysmod and  " overwrite it or Replace the destination directory. " you will get different message depengind on what windows you have.