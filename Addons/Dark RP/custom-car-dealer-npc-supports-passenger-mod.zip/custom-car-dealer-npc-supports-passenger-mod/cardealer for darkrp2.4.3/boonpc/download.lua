
resource.AddFile("materials/boowman/bg5.png")