/*-----------------------------------------*\
        Here are the NPC Details
\*-----------------------------------------*/
 
NPCSHOP = NPCSHOP or {}
NPCSHOP.CarSpawn = {}
NPCSHOP.SpawnPoint = {}
 
NPCSHOP.Name = "Car Name here"
NPCSHOP.ID = 2
NPCSHOP.Model = "models/Humans/Group01/Male_04.mdl"
 
NPCSHOP.SpawnPoint["gm_construct"] = {  
		{
                Pos = Vector(885.276367, -56.722973, -79.968750),
                Ang = Angle(0,-90,0)
        },
}

// Player Question
NPCSHOP.Question_1 = "Can you please take my car away."
NPCSHOP.Question_2 = "Hey! I'm looking for a new car."
NPCSHOP.Question_3 = "You can't help me. Nobody can help me."
 
// NPC Answers
NPCSHOP.Answer_1 = "Yeah sure. It should be away now."
NPCSHOP.Answer_2 = "Here are all the cars we currently have."
NPCSHOP.Answer_3 = ""
 
NPCSHOP.CarSpawn["gm_construct"] = {
        {
                Pos = Vector(712.632751, -324.536713, -79.968750),
                Ang = Angle(0,-90,0)
        },
}