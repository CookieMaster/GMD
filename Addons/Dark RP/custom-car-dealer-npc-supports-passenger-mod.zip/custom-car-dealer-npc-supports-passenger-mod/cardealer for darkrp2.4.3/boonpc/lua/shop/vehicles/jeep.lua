/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Jeep"
VEHICLE.Make = "Valve"
VEHICLE.Type = "Jeep MS5"
VEHICLE.ID = 4
VEHICLE.Script = "scripts/vehicles/jeep_test.txt"
VEHICLE.Class = "Jeep"

VEHICLE.Model = "models/buggy.mdl"
VEHICLE.Icon = "entities/jeep.png"

VEHICLE.Price = 25000

VEHICLE.Speed = 35
VEHICLE.Power = 350
VEHICLE.RMP = 4200