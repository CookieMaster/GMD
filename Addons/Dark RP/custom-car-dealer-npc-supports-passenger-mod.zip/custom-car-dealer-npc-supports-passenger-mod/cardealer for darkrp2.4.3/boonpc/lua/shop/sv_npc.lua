
util.AddNetworkString( 'cars_senddata' )
util.AddNetworkString( 'BuyCar' )
util.AddNetworkString( 'Sell' )
util.AddNetworkString( 'Cannot' )
util.AddNetworkString( 'SpawnCar' )
util.AddNetworkString( 'open_car_shop' )
util.AddNetworkString( 'car_away' )

function CarShop()
		
for _,v in pairs(NPCSHOP.SpawnPoint[game.GetMap()]) do
	local npc = ents.Create("npc_car")
		npc:SetModel(NPCSHOP.Model)
		npc:SetPos(v.Pos)
		npc:SetAngles(v.Ang)
		npc:DropToFloor()
		npc:Spawn()	
		
	local bubble = ents.Create("npc_bubble")
		bubble:SetPos(npc:GetPos() + Vector(0,0,90))
		bubble:Spawn()
end	


end
hook.Add("InitPostEntity","CarShop",CarShop)

//Utilizes darkrp's notify
local function Notify(ply, text)
	if not IsValid(ply) then return end
	umsg.Start("_Notify", ply)
		umsg.String(text)
		umsg.Short(0)
		umsg.Long(4)
	umsg.End()
end

hook.Add("EntityTakeDamage","NPCisInvincible",function(target,dmg)
	if target:IsNPC() and target:GetClass() == "npc_car" then
		dmg:ScaleDamage(0)
	end
end)

local function SaveCar()
	local str = util.TableToJSON(vehicle.PlyCars)
	file.Write( "boowman_cardealer.txt",str)
end

local function LoadCar()
	local str = file.Read( "boowman_cardealer.txt", "DATA") or "[]"
	vehicle.PlyCars = util.JSONToTable(str)
end

LoadCar()
function SendCar(ply)
	local sid = ply:SteamID()
	local cars = vehicle.PlyCars[sid] or {}
	
	net.Start("cars_senddata")
		net.WriteTable(cars)
	net.Send(ply)
end

hook.Add("PlayerInitialSpawn","SpawnCarFirstWhenJoin", function(ply)
	timer.Simple(2, function()
		SendCar(ply)
	end)
end)

local meta = FindMetaTable("Player")
function meta:AddCar( cname )
	
	local sid = self:SteamID()
	if not vehicle.PlyCars[sid] then vehicle.PlyCars[sid] = {} end
	
	vehicle.PlyCars[sid][cname] = true
	SaveCar()
	SendCar(self)
end

net.Receive('BuyCar', function()
       
local price = net.ReadFloat()
local ply = net.ReadEntity()
local keyvalue = net.ReadString()
local model = net.ReadString()
local vehiclename = net.ReadString()
 
	local sid = ply:SteamID()
	if vehicle.PlyCars[sid] then
		if vehicle.PlyCars[sid][cname] then return end
	end
		   
	ply:AddMoney(-price)
		Notify(ply, "You've bought the '" .. vehiclename .. "' for "..(CUR or "$")..(price).."!")
	ply:AddCar(vehiclename)
		   
end)

net.Receive('Sell', function() 

local price = net.ReadFloat()
local ply = net.ReadEntity()
local carname = net.ReadString()
local sellprice = price / 2

	local sid = ply:SteamID()
	vehicle.PlyCars[sid][carname]  = nil
	
	if IsValid(ply.SpawnedCar) then
		ply.SpawnedCar:Remove()
	end
	
	ply:AddMoney(sellprice)
		Notify(ply, "You just sold " .. carname .. "' for "..(CUR or "$")..(sellprice).."!")
	SaveCar()
end)

net.Receive('SpawnCar', function(cclass) 

local ply = net.ReadEntity()
local keyvalue = net.ReadString()
local model = net.ReadString()
local vehiclename = net.ReadString()
local carclass = net.ReadString()

	if IsValid(ply.SpawnedCar) then
		ply.SpawnedCar:Remove()
	end
	
local vehicle = list.Get("Vehicles")[carclass]
if not vehicle then print("No vehicle returns this entity!") return end

local rdm = table.Random(NPCSHOP.CarSpawn[game.GetMap()])
	car = ents.Create(vehicle.Class)
		car:SetModel(model)
	if vehicle.KeyValues then
		for k, v in pairs(vehicle.KeyValues) do
			car:SetKeyValue(k, v)
		end
	end
		car:SetPos(rdm.Pos)
		car:SetAngles(rdm.Ang)
		car:Spawn()
		car:Activate()
		
		car.VehicleName = class
		car.VehicleTable = vehicle
		car.ClassOverride = vehicle.Class

	if vehicle.Members then
		table.Merge(car, vehicle.Members)
	end

		ply.SpawnedCar = car
		
	SendCar(ply)
	Notify(ply, "You spawned the "..vehiclename..".")
	
	gamemode.Call("PlayerSpawnedVehicle", ply, car)
end)

net.Receive('Cannot', function()
local price = net.ReadFloat()
local ply = net.ReadEntity()
local vehiclename = net.ReadString()

	Notify(ply, "You don't have enought money to buy "..vehiclename..".")		
end)

net.Receive('car_away', function() 
local ply = net.ReadEntity()
local keyvalue = net.ReadString()
local model = net.ReadString()
local vehiclename = net.ReadString()
local carclass = net.ReadString()
	
	if IsValid(ply.SpawnedCar) then
		ply.SpawnedCar:Remove()
	end
	
	Notify(ply, "You're car has been taken away.")
end)