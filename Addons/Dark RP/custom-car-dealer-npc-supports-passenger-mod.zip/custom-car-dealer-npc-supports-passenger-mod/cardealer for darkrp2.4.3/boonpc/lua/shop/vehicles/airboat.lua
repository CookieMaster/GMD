/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Airboat"
VEHICLE.Make = "Valve"
VEHICLE.Type = "Airboat GT500"
VEHICLE.ID = 1
VEHICLE.Script = "scripts/vehicles/airboat.txt"
VEHICLE.Class = "Airboat"

VEHICLE.Model = "models/airboat.mdl"
VEHICLE.Icon = "entities/airboat.png"

VEHICLE.Price = 15000

VEHICLE.Speed = 34
VEHICLE.Power = 450
VEHICLE.RMP = 15000