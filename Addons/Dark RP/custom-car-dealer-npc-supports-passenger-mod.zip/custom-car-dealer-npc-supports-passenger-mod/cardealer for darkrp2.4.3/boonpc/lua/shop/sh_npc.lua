
vehicle = vehicle or {}
vehicle.Car = {}
vehicle.CheckVehicles = {}
vehicle.PlyCars = {}

function vehicle.AddCar(id,cname,cscript,cmake,ctype,cicon,cprice,cmodel)
	if not id or not cname or not cscript or not cmake or not ctype or not cicon or not cprice or not cmodel then
		local warning = "Invalid Vehicle! ( "..(cname or "Unknown").." )"
		MsgN(warning)
	hook.Add("PlayerInitialSpawn","CarWrong", function(ply)
		if ply:IsAdmin() then
			ply:PrintMessage(HUD_PRINTTALK, warning)
		end
	end)
	return
	end
	
	if vehicle.CheckVehicles[cname] then
		MsgN("Invalid Vehicle! Duplicated car ! Name: "..cname..".")
	end
	
	vehicle.CheckVehicles[cname] = table.insert(vehicle.Car, {id = id, cname = cname,cscript = cscript, cmake = cmake, ctype = ctype, cicon = cicon, cprice = cprice, cmodel = cmodel, cclass = cclass})
		
end

local meta = FindMetaTable("Player")
function meta:OwnCar(cname)
if SERVER then
	local sid = self:SteamID()
	
	if not vehicle.PlyCars[sid] then
		return false
	end
	
	if vehicle.PlyCars[sid][cname] then
		return true
	end
else
	if not self.Car then
		return false
	end
	
	if self.Car[cname] then
		return true
	end
end
	return false
end