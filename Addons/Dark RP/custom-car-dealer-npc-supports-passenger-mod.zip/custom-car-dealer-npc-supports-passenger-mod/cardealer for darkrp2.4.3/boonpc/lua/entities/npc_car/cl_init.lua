include('shared.lua')

function ENT:Initialize ( )	
	self:InitializeAnimation()
end