AddCSLuaFile('cl_init.lua')
AddCSLuaFile('shared.lua')

include('shared.lua')

function ENT:Initialize()
	self:SetHullType(HULL_HUMAN)
	self:SetHullSizeNormal()
	self:SetNPCState(NPC_STATE_SCRIPT)
	self:SetSolid(SOLID_BBOX)
	self:CapabilitiesAdd(bit.bor(CAP_ANIMATEDFACE,CAP_TURN_HEAD))
	self:SetUseType(SIMPLE_USE)
	self:DropToFloor()
	
	self:SetMaxYawSpeed(90)
end

function ENT:AcceptInput(name, activator, call, data)
	local sid = call:SteamID()
	if name == "Use" and IsValid(call) and call:IsPlayer() then
		net.Start("open_car_shop")
			net.WriteTable(vehicle.PlyCars[sid] or {})
		net.Send(call)
	end
end

function ENT:ChatBubble()
	self.Bubble = ents.Create("npc_bubble")
	self.Bubble:SetPos(self:GetPos() + Vector(0, 0, 90))
	self.Bubble:Spawn()
end

--[[
hook.Add("PlayerInitialSpawn", "DrawTextAbove", function(ply)
	for _,v in pairs(ents.FindByClass("npc_base")) do
		net.Start("show_text")
			net.WriteEntity(v)
		net.Send(ply)
	end
end)]]

