
local stored = {}

function GetTheStoredTable()
	return stored
end

function GetTheVehicle(ID)
        return stored[ID]
end
 
	include("shop/gui.lua")
	include("shop/setup.lua")
	include("shop/sh_npc.lua")
       
local files = file.Find("shop/vehicles/*.lua","LUA")
for k,v in pairs(files) do
        include("shop/vehicles/"..v)
 
        stored[VEHICLE.ID] = VEHICLE
		VEHICLE = nil
end

print("									  ")
print("***** Client Side Initialized *****")
print("  Boowman's Car Dealer Initialized ")
print("									  ")