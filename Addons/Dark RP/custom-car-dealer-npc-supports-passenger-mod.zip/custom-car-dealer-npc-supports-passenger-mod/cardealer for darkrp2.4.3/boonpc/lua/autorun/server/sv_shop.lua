
local stored = {}

function GetTheStoredTable()
	return stored
end

function GetTheVehicle(ID)
        return stored[ID]
end

	AddCSLuaFile("autorun/client/cl_shop.lua")     
	AddCSLuaFile("shop/setup.lua")
	AddCSLuaFile("shop/gui.lua")
	AddCSLuaFile("shop/sh_npc.lua")
	
	include("shop/sh_npc.lua")
	include("shop/setup.lua")
	include("shop/sv_npc.lua")   
	
local files = file.Find("addons/boonpc/lua/shop/vehicles/*.lua","GAME")
for k,v in pairs(files) do
        AddCSLuaFile("shop/vehicles/"..v)
        include("shop/vehicles/"..v)
		
        stored[VEHICLE.ID] = VEHICLE
		VEHICLE = nil
end