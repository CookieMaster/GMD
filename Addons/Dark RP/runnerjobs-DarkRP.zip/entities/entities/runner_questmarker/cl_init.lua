include('shared.lua')

-- Called when the entity is drawn.
function ENT:Draw()
	self:SetModelScale(0.6, 0);
	self:DrawModel();
end;

-- Called every frame.
function ENT:Think()
	if (!self.SpawnPos) then
		self.SpawnPos = self:GetPos();
	end;
	
	self:SetPos(self.SpawnPos + Vector(0, 0, math.sin(UnPredictedCurTime()) * 2.5));
	self:SetAngles(self:GetAngles() + Angle(0, 0.2, 0));
end;