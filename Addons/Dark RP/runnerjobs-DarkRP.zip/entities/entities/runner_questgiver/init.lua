AddCSLuaFile( "cl_init.lua" ) -- This means the client will download these files
AddCSLuaFile( "shared.lua" )

include('shared.lua') -- At this point the contents of shared.lua are ran on the server only.

ENT.Models =  {
		"models/humans/Group03/Female_01.mdl",
		"models/humans/Group03/Female_02.mdl",
		"models/humans/Group03/Female_03.mdl",
		"models/humans/Group03/Female_04.mdl",
		"models/humans/Group03/Female_06.mdl",
		"models/humans/group03/male_01.mdl",
		"models/humans/Group03/Male_02.mdl",
		"models/humans/Group03/male_03.mdl",
		"models/humans/Group03/Male_04.mdl",
		"models/humans/Group03/Male_05.mdl",
		"models/humans/Group03/Male_06.mdl",
		"models/humans/Group03/Male_07.mdl",
		"models/humans/Group03/Male_08.mdl",
		"models/humans/Group03/Male_09.mdl"}
function ENT:Initialize( ) --This function is run when the entity is created so it's a good place to setup our entity.
	
	self:SetModel( table.Random(self.Models) ) -- Sets the model of the NPC.
	self:SetHullType( HULL_HUMAN ) -- Sets the hull type, used for movement calculations amongst other things.
	self:SetHullSizeNormal( )
	//self:SetNPCState( NPC_STATE_SCRIPT )
	self:SetSolid(  SOLID_BBOX ) -- This entity uses a solid bounding box for collisions.
	self:CapabilitiesAdd( bit.bor(CAP_ANIMATEDFACE , CAP_TURN_HEAD) ) -- Adds what the NPC is allowed to do ( It cannot move in this case ).
	self:SetUseType( SIMPLE_USE ) -- Makes the ENT.Use hook only get called once at every use.
	self:DropToFloor()
	
	self:SetMaxYawSpeed( 90 ) --Sets the angle by which an NPC can rotate at once.
	
	self.bubble = ents.Create("runner_questmarker");
	self.bubble:SetParent(self);
	self.bubble:SetPos(self:GetPos() + Vector(0, 0, 85));
	self.bubble:Spawn();
end

function ENT:OnTakeDamage()
	return false -- This NPC won't take damage from anything.
end 

function ENT:OnRemove()
	RUNNERS[runner] = nil
	SaveRunners()
end
function ENT:GetQuest()
	local target = table.Random(RUNNERS)[1]
	if target != self then
		return target
	else
		return self:GetQuest()
	end
end
function ENT:AcceptInput( Name, Activator, Caller )	
	if Name == "Use" and Caller:IsPlayer() then

		if Caller:GetNetworkedEntity("quest_target") == self and RPExtraTeams[Caller:Team()].runner then
			GAMEMODE:Notify(Caller, 3, 4, "Finished quest! Reward: "..Caller.questmoney)
			Caller:AddMoney(Caller.questmoney)
			Caller:SetNetworkedEntity("quest_target", NULL)
		elseif (!Caller.lastQuest or Caller.lastQuest<CurTime()) and RPExtraTeams[Caller:Team()].runner then
			local target = self:GetQuest()
			if target then
				Caller.quest = target
				Caller.questmoney = math.floor(target:GetPos():Distance(self:GetPos())*DISTANCEMULT)
				net.Start( "Runner_AcceptQuest" )
				net.Send( Caller )
			else
				GAMEMODE:Notify(Caller, 1, 4, "There is no possible target, add more questgivers!")
			end
			
		elseif RPExtraTeams[Caller:Team()].runner then
			GAMEMODE:Notify(Caller, 1, 4, "You need to wait before being able to get a new quest!")
		else
			GAMEMODE:Notify(Caller, 1, 4, "You need to be runner to accept quests!")
		end
		
	end
	
end
