-- determines how much money the player get's depening on how far away the target was.
DISTANCEMULT = 0.01
-- how long does a player need to wait until he can get a new quest in seconds.
RUNNERWAIT = 10
-- can other runners see runners on a mission?
RUNNERSEE = true
-- does the runner get money for killing another runner?
RUNNERLOOT = true

TEAM_RUNNER = AddExtraTeam("Runner", {
	color = Color(75, 75, 75, 255),
	model = {
		"models/player/Group03/Female_01.mdl",
		"models/player/Group03/Female_02.mdl",
		"models/player/Group03/Female_03.mdl",
		"models/player/Group03/Female_04.mdl",
		"models/player/Group03/Female_06.mdl",
		"models/player/group03/male_01.mdl",
		"models/player/Group03/Male_02.mdl",
		"models/player/Group03/male_03.mdl",
		"models/player/Group03/Male_04.mdl",
		"models/player/Group03/Male_05.mdl",
		"models/player/Group03/Male_06.mdl",
		"models/player/Group03/Male_07.mdl",
		"models/player/Group03/Male_08.mdl",
		"models/player/Group03/Male_09.mdl"}, 
	description = [[As a runner you carry around items for other people.]],
	weapons = {},
	command = "runner",
	max = 5,
	salary = 0,
	admin = 0,
	vote = false,
	hasLicense = false,
	runner = true,
	mayorCanSetSalary = true
})