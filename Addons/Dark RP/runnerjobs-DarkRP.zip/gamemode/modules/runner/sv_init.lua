RUNNERS = RUNNERS or {}
function SaveRunners()
	local save = {}
	for k,v in pairs(RUNNERS) do
		if v != nil then
			save[#save+1] = {k:GetPos(),k:GetAngles(),k:GetModel()}
		end
	end
	//file.Open("runners","w","DATA")
	file.Write("runners.txt",util.TableToJSON(save))
end
local function init()
	local load = util.JSONToTable(file.Read("runners.txt","DATA"))
	for k,v in pairs(load) do
		local runner = ents.Create("runner_questgiver");
		if !IsValid(runner) then break end
		runner:SetPos(v[1])
		runner:SetAngles(v[2])
		runner:Spawn()
		runner:SetModel(v[3])
		RUNNERS[runner] = {runner}
	end
end
hook.Add( "InitPostEntity", "Runners Load", init )
function death( ply, inflictor, attacker )
    if ( RPExtraTeams[ply:Team()].runner and RPExtraTeams[attacker:Team()].runner) then
		if RUNNERLOOT and attacker != ply then
			attacker:AddMoney(ply.questmoney)
			GAMEMODE:Notify(attacker, 3, 4, "Disrupted quest of target! Reward: "..ply.questmoney)
		end
		FAdmin.Log(attacker:Nick().." ("..attacker:SteamID()..") Killed another runner: "..ply:Nick().." ("..ply:SteamID()..")" )
	
    end
	ply:SetNetworkedEntity("quest_target", NULL)
	GAMEMODE:Notify(ply, 1, 4, "You lost the quest!")
end
hook.Add( "PlayerDeath", "Runners Death", death )
function PlayerAccepted(len, client)
	if client.quest then
		client:SetNetworkedEntity( "quest_target", client.quest )
		client.lastQuest = CurTime() + RUNNERWAIT;
		GAMEMODE:Notify(client, 2, 4, "You accepted the quest!")
	end
end

net.Receive("Runner_AcceptedQuest", PlayerAccepted) --Hook to messages from the server so we know when to 

local function spawn_runner(ply, cmd, args)
	if ply:EntIndex() ~= 0 and not ply:IsSuperAdmin() then
		ply:PrintMessage(2, "You need to be admin for this action!")
		return
	end
	local runner = ents.Create("runner_questgiver");
	local hit = ply:GetEyeTraceNoCursor().HitPos + Vector(0,0,16);
	local angles = ply:GetAngles();
		
	angles.pitch = 0; angles.roll = 0;
	angles.yaw = angles.yaw + 180;
	
	if !IsValid(runner) then return end
	runner:SetPos(hit);
	runner:SetAngles(angles);
	runner:Spawn();
	RUNNERS[runner] = {runner}
	SaveRunners()
end
concommand.Add("spawn_runner", spawn_runner)

util.AddNetworkString( "Runner_AcceptQuest" )
util.AddNetworkString( "Runner_AcceptedQuest" )