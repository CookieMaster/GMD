// test

local matFill = CreateMaterial( "WhiteFill", "UnlitGeneric", { [ "$basetexture" ] = "vgui/white" } )
 
hook.Add( "PostDrawOpaqueRenderables", "PostDrawing", function()
	for k,v in pairs(ents.FindByClass("runner_questmarker")) do
		if v:GetParent() == LocalPlayer():GetNetworkedEntity("quest_target") then
			v:SetNoDraw(false)
		else
			v:SetNoDraw(true)
		end
	end
	if RPExtraTeams[LocalPlayer():Team()].runner and RUNNERSEE then
		for k, v in pairs(player.GetAll()) do
			if IsValid(v:GetNetworkedEntity("quest_target")) then
				cam.Start3D( EyePos(), RenderAngles() )
				
					render.ClearStencil()
					render.SetStencilEnable( true )
					render.SetStencilTestMask(1)
					render.SetStencilWriteMask(1)
					
					render.SetStencilFailOperation( STENCILOPERATION_KEEP )
					render.SetStencilZFailOperation( STENCILOPERATION_REPLACE )
					render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
					render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )
					render.SetStencilReferenceValue( 1 )
				 
					v:DrawModel()
				 
					render.SetStencilReferenceValue( 2 )
					
					render.SetStencilZFailOperation( STENCILOPERATION_KEEP )
					
					v:DrawModel()
				 
					render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )
					render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
					render.SetStencilReferenceValue( 1 )

					render.SetMaterial( matFill )
					render.DrawScreenQuad()
				 
					render.SetStencilEnable( false )
				cam.End3D()
			end
		end
	end
	if IsValid(LocalPlayer():GetNetworkedEntity("quest_target")) then
		cam.Start3D( EyePos(), EyeAngles() )
	 
			render.ClearStencil()
			render.SetStencilEnable( true )
			render.SetStencilTestMask(1)
			render.SetStencilWriteMask(1)

			render.SetStencilFailOperation( STENCILOPERATION_KEEP )
			render.SetStencilZFailOperation( STENCILOPERATION_REPLACE )
			render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
			render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS )
			render.SetStencilReferenceValue( 1 )
		 
			LocalPlayer():GetNetworkedEntity("quest_target"):DrawModel()
		 
			render.SetStencilReferenceValue( 2 )
			
			render.SetStencilZFailOperation( STENCILOPERATION_KEEP )
			
			LocalPlayer():GetNetworkedEntity("quest_target"):DrawModel()
		 
			render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL )
			render.SetStencilPassOperation( STENCILOPERATION_REPLACE )
			render.SetStencilReferenceValue( 1 )

			render.SetMaterial( matFill )
			render.DrawScreenQuad()
		 
			render.SetStencilEnable( false )
	 
		cam.End3D()
	end
end )