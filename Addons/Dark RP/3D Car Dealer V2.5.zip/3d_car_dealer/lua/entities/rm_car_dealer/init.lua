AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )

function ENT:Initialize()
	self:SetModel( "models/Humans/Group02/male_09.mdl" )
	self:SetHullType( HULL_HUMAN )
	self:SetHullSizeNormal( )
	self:SetNPCState( NPC_STATE_SCRIPT )
	self:SetSolid( SOLID_BBOX )
	self:CapabilitiesAdd( CAP_ANIMATEDFACE )
	self:SetUseType( SIMPLE_USE )
	self:DropToFloor()
 
	self:SetMaxYawSpeed( 180 )
end

function ENT:SpawnFunction( ply, tr )
    if ( !tr.Hit ) then return end
    local ent = ents.Create( "rm_car_dealer" )
    ent:SetPos( tr.HitPos + tr.HitNormal * 16 ) 
    ent:Spawn()
    ent:Activate()
 
    return ent
end
function ENT:AcceptInput( Name, Activator, Caller )
	if Name == "Use" and Caller:IsPlayer() then
		RXCAR_SendInventory(Caller)
		RXCAR_OpenShop(Caller,self)
	end
end

function ENT:BuyCar(ply,CData,TuneData)

	local Cars = {}
	for k,v in pairs(RX3DCar_Cars) do
		if v and v:IsValid() and v.IsCar and v.OwnerID == ply:SteamID() then
			table.insert(Cars,v)
		end
	end
		if (#Cars+1) > D3DCarConfig.PlayerMaxCarAmount then
			local Amount2Remove = (#Cars+1) - D3DCarConfig.PlayerMaxCarAmount
			local Amount2RemoveD = Amount2Remove
			for k,v in pairs(Cars) do
				if Amount2Remove > 0 then
					Amount2Remove = Amount2Remove - 1
					RX3DCar_StoreCar(ply,v)
				end
			end
			
			ply:Send3DShopNotice(Amount2RemoveD .. " Car(s) has been saved")
		end

		local Vehicle = list.Get('Vehicles')[CData.VehicleName]

		local SpawnPos = self:GetPos() + self:GetForward()*150
		local CarEnt = ents.Create(Vehicle.Class)
		CarEnt:SetModel(Vehicle.Model)
		CarEnt:SetPos(SpawnPos)
		for k, v in pairs (Vehicle.KeyValues) do
			CarEnt:SetKeyValue(k, v)
		end
		CarEnt:Spawn()
		CarEnt:Activate()
		CarEnt:SetCollisionGroup( COLLISION_GROUP_VEHICLE )
		
		CarEnt.Owner = ply
		CarEnt.OwnerID = ply:SteamID()
		CarEnt.SID = ply.SID
		CarEnt.RX3DCar = true
		CarEnt.IsCar = true
		CarEnt.SpawnTime = CurTime()
		CarEnt.TuneData = TuneData
		CarEnt.CData = CData
		D3DCar_Meta:OwnCar(ply,CarEnt)
		
		if CarEnt.KeysLock then 
			CarEnt:KeysLock()
		elseif CarEnt.keysLock then
			CarEnt:keysLock()
		end
		
		local TuneSys = ents.Create("rm_car_tune_sys")
		TuneSys:SetPos(CarEnt:GetPos())
		TuneSys:SetAngles(CarEnt:GetAngles())
		TuneSys:Spawn()
		TuneSys:SetTuneData(TuneData)
		TuneSys.Mother = CarEnt
		TuneSys:SetParent(CarEnt)
		


		-- for Passenger Mod. Maybe
		CarEnt.VehicleName = CData.VehicleName
		CarEnt.VehicleTable = Vehicle
		-- for Passenger Mod. Maybe
		
		
		CarEnt:SetColor(TuneData.Color or Color(255,255,255,255))
		
		D3DCarCrashSaver:AddCar(ply,CarEnt)
		RX3DCar_AddCar(CarEnt)
		
		timer.Simple(0.1,function()
		ply:UpdateNearCar(self)
		end)
		
		hook.Call("PlayerSpawnedVehicle", GAMEMODE, ply, CarEnt)
		hook.Call("playerBoughtVehicle", nil, ply, Vehicle, CarEnt)
end




----------- DarkRP function
function ENT:PhysgunPickup(ply) -- for DarkRP : Allows Owner can move ATM
	if ply:GetNWString("usergroup") == "owner" or ply:GetNWString("usergroup") == "superadmin" then 
		return true
	else
		return false
	end
end

function ENT:CanTool(ply, trace, mode) -- for DarkRP : Allows Only Owner to remove ATM. 
	if ply:GetNWString("usergroup") == "owner" or ply:GetNWString("usergroup") == "superadmin" then 
		return true 
	else
		return false
	end
end