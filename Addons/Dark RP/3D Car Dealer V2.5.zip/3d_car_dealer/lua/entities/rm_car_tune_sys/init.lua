AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )

function ENT:Initialize()
	self:SetModel( "models/props_junk/PopCan01a.mdl" )
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	self.Entity:DrawShadow(false)
	self.Entity:SetCollisionGroup( COLLISION_GROUP_DEBRIS )
	
end

function ENT:SetTuneData(TuneData)
	self.TuneData = TuneData
end

function ENT:Think()
	if self.Mother and self.Mother:IsValid() then
		local Driver = self.Mother:GetDriver( )
		if Driver and Driver:IsValid() and Driver:IsPlayer() then
		
			-- Brake
			if (Driver:KeyDown(IN_BACK) or Driver:KeyDown(IN_JUMP)) then
				self:SetDTInt(1,1)
			else
				self:SetDTInt(1,0)
			end
			
			
			
			self:NextThink(CurTime())
			return true
		end
	end
end


util.AddNetworkString( "RXCAR_RequestTuneData_C2S" )
util.AddNetworkString( "RXCAR_TuneData_S2C" )


	net.Receive( "RXCAR_RequestTuneData_C2S", function( len,ply )
		local TB = net.ReadTable()
		local Ent = TB.Ent
		if Ent and Ent:IsValid() and Ent:GetClass() == "rm_car_tune_sys" then
			net.Start( "RXCAR_TuneData_S2C" )
				net.WriteTable( {Ent = Ent,TuneData = Ent.TuneData} )
			net.Send(ply)
		else
			MsgN("PROBLEM")
		end
	end)