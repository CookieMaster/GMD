include('shared.lua')

	net.Receive( "RXCAR_TuneData_S2C", function( len,ply )
		local TB = net.ReadTable()
		local Ent = TB.Ent
		local TuneData = TB.TuneData
		if Ent and Ent:IsValid() and Ent:GetClass() == "rm_car_tune_sys" then
			Ent:SetTuneData(TuneData)
		end
	end)

	
function ENT:Initialize()
	self:SetRenderBounds( Vector(-300,-300,-300),Vector(300,300,300) )
end

function ENT:Draw()
	if !self.TuneData then
		self.TuneData = {}
		net.Start( "RXCAR_RequestTuneData_C2S" )
			net.WriteTable( {Ent = self} )
		net.SendToServer()
	end
end

hook.Add("PostDrawTranslucentRenderables", "RM CAR Tune System Drawing", function( )
	for k,v in pairs(ents.FindByClass("rm_car_tune_sys")) do
		v:DrawElements(v.TuneData or {})
	end
end)

function ENT:SetTuneData(Data)
	self.TuneData = Data
end

local MAT_BEAM = Material("sprites/physgbeamb")
local MAT_LIGHT = Material("particle/Particle_Glow_05")

function ENT:DrawElements(TuneData)
	cam.Start3D(EyePos(), EyeAngles())
	
	local IsBraking = false
	if self:GetDTInt(1) == 1 then
		IsBraking = true
	end
	
	for k,v in pairs(TuneData.Elements or {}) do
		if v.Type == "LEDStrip" then
			render.SetMaterial( MAT_BEAM )
				
			local Pos1 = self:LocalToWorld(v.Pos1)
			local Pos2 = self:LocalToWorld(v.Pos2)
			render.DrawBeam( Pos1,Pos2, v.Width, 1, 1, v.Color ) 
		end
			if v.Type == "RearLight" then
				local Pos1 = self:LocalToWorld(v.Pos1)
				local Size = v.Size
				local ColorK = v.Color
				if IsBraking then 
					Size = Size * 1.3 
					ColorK.a = 255
				else
					ColorK.a = 100
				end
				
				render.SetMaterial( MAT_LIGHT )
				render.DrawQuadEasy( Pos1,    --position of the rect
				EyeAngles():Forward() * -1,        --direction to face in
				Size, Size,              --size of the rect
				ColorK,  --color
				90                     --rotate 90 degrees
				) 
			end
	end
	cam.End3D()
end