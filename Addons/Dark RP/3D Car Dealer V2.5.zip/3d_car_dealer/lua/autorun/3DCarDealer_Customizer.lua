D3DCarConfig = {}

D3DCarConfig.DarkRPIs2_5_0 = false
-- if u using DarkRP 2.5.0 set this to ' true '
-- if not, Set this to 'false' 

D3DCarConfig.PlayerMaxCarAmount = 1 -- if you break this, your car will be removed and saved into inventory
D3DCarConfig.Car = {}

	//===========================================
	local TB2Insert = {}
		TB2Insert.VehicleName = "Jeep" -- This is unique name.
		TB2Insert.CarName = "Jeep!" -- The car name. will be displayed at shop
		TB2Insert.CarPrice = 100 -- price
		TB2Insert.CarRefund = 100 -- refund
		TB2Insert.MaxAmount = 1 -- max amount of this car.
		TB2Insert.Description = [[Normal Jeep
								lol ddddddddddddddddddddddddddddddddddddddddddddddddddddddd]]
	table.insert(D3DCarConfig.Car,TB2Insert)
	//===========================================
	
	
	
	local TB2Insert = {}
		TB2Insert.VehicleName = "sparktdm"
		TB2Insert.CarName = "TDM - Spark"
		TB2Insert.CarPrice = 100
		TB2Insert.CarRefund = 100
		TB2Insert.Description = "Basic Car."
	table.insert(D3DCarConfig.Car,TB2Insert)
	
	local TB2Insert = {}
		TB2Insert.VehicleName = "reventonrtdm"
		TB2Insert.CarName = "TDM - Reventon RoadSter"
		TB2Insert.CarPrice = 100
		TB2Insert.CarRefund = 100
		TB2Insert.MaxAmount = 1
		TB2Insert.AvaliableGroup = {"superadmin","admin"}
	--	TB2Insert.AvaliableTeam = {"Civil Protection","Mob boss"}
		TB2Insert.Description = "Basic Car."
	table.insert(D3DCarConfig.Car,TB2Insert)
	
	
if CLIENT then
	surface.CreateFont( "CenterCarName",{
		font = "Sansation",
		size = 40,
		weight = 700,
		outline = true
	})

	surface.CreateFont( "CenterCarPrice",{
		font = "Sansation",
		size = 25,
		weight = 700,
		outline = true
	})

	surface.CreateFont( "SansationOut_S20",{
		font = "Sansation",
		size = 20,
		weight = 700,
		outline = true
	})
	
	surface.CreateFont( "SansationOut_S30",{
		font = "Sansation",
		size = 30,
		weight = 700,
		outline = true
	})
	
end

