local meta = FindMetaTable("Player");
function meta:GetJobName()
	local JOB = team.GetName(self:Team())
	
	return JOB
end


if CLIENT then
	net.Receive( "RXCAR_OpenShop_S2C", function( len,ply )
		local DATA = net.ReadTable()
		D3DCarDealer_Open(DATA.Ent,DATA.NC)
	end)
	net.Receive( "RXCAR_UpdateNearCar_S2C", function( len,ply )
		local DATA = net.ReadTable()
		if D3DCarShopPanel and D3DCarShopPanel.SellerNPC == DATA.Ent then
			D3DCarShopPanel.NearMyCars = DATA.NC
		end
	end)
	
	net.Receive( "RXCAR_Notice_S2C", function( len,ply )
		local DATA = net.ReadTable()
		if D3DCarShopPanel and D3DCarShopPanel:IsValid() then
			D3DCarShopPanel:Notice(DATA.T)
			if DATA.RF then
				D3DCarShopPanel:RefreshCurrentMode()
			end
		end
	end)
	
	function RXCAR_BuyCar(uniquename,sellernpc,PANEL,ToInv)
		net.Start( "RXCAR_Shop_Buy_C2S" )
			net.WriteTable({UN=uniquename,SE=sellernpc,TuneData=PANEL.TuneData,ToInv=ToInv})
		net.SendToServer()
	end
	function RXCAR_SellCar(CarENT,CData)
		net.Start( "RXCAR_Shop_Sell_C2S" )
			net.WriteTable({E=CarENT,CD=CData})
		net.SendToServer()
	end
	function RXCAR_StoreCar(CarENT)
		net.Start( "RXCAR_Shop_Store_C2S" )
			net.WriteTable({E=CarENT})
		net.SendToServer()
	end
	
	
	function RXCAR_RespawnINVCar(UniqueID,sellernpc)
		net.Start( "RXCAR_RespawnINV_C2S" )
			net.WriteTable({UN=UniqueID,SE=sellernpc})
		net.SendToServer()
	end
	
	function RXCAR_UpdateINVCar(UniqueID,TuneData)
		net.Start( "RXCAR_UpdateINVCar_C2S" )
			net.WriteTable({UniqueID=UniqueID,TuneData=TuneData})
		net.SendToServer()
	end
	
	function RXCAR_SellINVCar(UniqueID,sellernpc)
		net.Start( "RXCAR_SellINVCar_C2S" )
			net.WriteTable({UN=UniqueID,SE=sellernpc})
		net.SendToServer()
	end
	
end
if SERVER then
	util.AddNetworkString( "RXCAR_OpenShop_S2C" )
	util.AddNetworkString( "RXCAR_UpdateNearCar_S2C" )
	util.AddNetworkString( "RXCAR_Notice_S2C" )
	util.AddNetworkString( "RXCAR_Shop_Buy_C2S" )
	util.AddNetworkString( "RXCAR_Shop_Store_C2S" )
	util.AddNetworkString( "RXCAR_Shop_Sell_C2S" )
	
	util.AddNetworkString( "RXCAR_RespawnINV_C2S" )
	util.AddNetworkString( "RXCAR_UpdateINVCar_C2S" )
	util.AddNetworkString( "RXCAR_SellINVCar_C2S" )
	
	
	function meta:Send3DShopNotice(txt,refresh)
		net.Start( "RXCAR_Notice_S2C" )
			net.WriteTable({T=txt,RF=refresh})
		net.Send(self)
	end
	function meta:UpdateNearCar(shopent)
		local NearCar = {}
			for k,v in pairs(ents.FindInSphere(shopent:GetPos(),300)) do
				if v.VehicleName and v.OwnerID == self:SteamID() then
					table.insert(NearCar,{Ent=v,VN=v.VehicleName})
				end
			end
			
		net.Start( "RXCAR_UpdateNearCar_S2C" )
			net.WriteTable({Ent=shopent,NC=NearCar})
		net.Send(self)
	end
	
	
	function RXCAR_OpenShop(ply,ent)
		local NearCar = {}
			for k,v in pairs(ents.FindInSphere(ent:GetPos(),300)) do
				if v.VehicleName and v.OwnerID == ply:SteamID() then
					table.insert(NearCar,{Ent=v,VN=v.VehicleName})
				end
			end
			
		net.Start( "RXCAR_OpenShop_S2C" )
			net.WriteTable({Ent=ent,NC=NearCar})
		net.Send(ply)
	end

	net.Receive( "RXCAR_UpdateINVCar_C2S", function( len,ply )
		local DATA = net.ReadTable()
		local UniqueID = DATA.UniqueID
		local TuneData = DATA.TuneData
		
		RX3DCar_UpdateINVCarData(ply,UniqueID,TuneData)

		ply:Send3DShopNotice("New Tuning Data has been updated")
	end)
	
	net.Receive( "RXCAR_Shop_Store_C2S", function( len,ply )
		local DATA = net.ReadTable()
		local Ent = DATA.E
		RX3DCar_StoreCar(ply,Ent)

		ply:Send3DShopNotice("You Stored the car")
	end)
	
	net.Receive( "RXCAR_Shop_Sell_C2S", function( len,ply )
		local DATA = net.ReadTable()
		
		local Ent = DATA.E
		local CData = DATA.CD
		
		if !Ent or !Ent:IsValid() then return end
		Ent.IgnoreRemoveHookTime = CurTime() + 999
		D3DCarCrashSaver:RemoveCar(ply,Ent)
		Ent:Remove()
		D3DCar_Meta:AddMoney(ply,CData.CarRefund or CData.CarPrice/2)
		ply:Send3DShopNotice("You sold a car for " .. CData.CarRefund or CData.CarPrice/2,true)
	end)
	
	net.Receive( "RXCAR_RespawnINV_C2S", function( len,ply )
		local DATA = net.ReadTable()
		if !DATA.SE or !DATA.SE:IsValid() then return end
		if DATA.SE:GetClass() != "rm_car_dealer" then return end
		RX3DCar_SpawnStoredCar(ply,DATA.SE,DATA.UN)
	end)
	
	net.Receive( "RXCAR_SellINVCar_C2S", function( len,ply )
		local DATA = net.ReadTable()
		if !DATA.SE or !DATA.SE:IsValid() then return end
		if DATA.SE:GetClass() != "rm_car_dealer" then return end
		RX3DCar_SellStoredCar(ply,DATA.SE,DATA.UN)
	end)
	
	net.Receive( "RXCAR_Shop_Buy_C2S", function( len,ply )
		local DATA = net.ReadTable()
		if !DATA.SE or !DATA.SE:IsValid() then return end
		if DATA.SE:GetClass() != "rm_car_dealer" then return end
		
			local ToInv = DATA.ToInv
			
			local CData = nil
			for k,v in pairs(D3DCarConfig.Car) do
				if v.VehicleName == DATA.UN then
					CData = v
					continue
				end
			end
			if !CData then return end
			
			if !ToInv and CData.MaxAmount then
				local Count = 0
				for k,v in pairs(ents.GetAll()) do
					if v.VehicleName and v.OwnerID == ply:SteamID() and v.VehicleName == CData.VehicleName then
						Count = Count + 1
						if Count >= CData.MaxAmount then
							ply:Send3DShopNotice("Car amount limit!")
							return 
						end
					end
				end
			end
			
			if CData.AvaliableGroup then
				local GroupCheck = false
				for k,v in pairs(CData.AvaliableGroup) do
					if ply:GetNWString("usergroup") == v then
						GroupCheck = true
					end
				end
				if !GroupCheck then 
					ply:Send3DShopNotice("You need Group that can buy this car")
					return 
				end
			end
			
			if CData.AvaliableTeam then
				local GroupCheck = false
				for k,v in pairs(CData.AvaliableTeam) do
					if ply:GetJobName() == v then
						GroupCheck = true
					end
				end
				if !GroupCheck then 
					ply:Send3DShopNotice("You need to be job that can buy this car")
					return 
				end
			end
			
			
			if ply:getDarkRPVar("money") < CData.CarPrice then return end
			
			
			
			if ToInv then
				
				D3DCar_Meta:Notify( ply, 1, 3, "You bought a car for $"..CData.CarPrice.."! and your car was stored in inventory.")
				D3DCar_Meta:AddMoney(ply,-CData.CarPrice)
				ply:Send3DShopNotice("You bought a car for " .. CData.CarPrice,true)	
			
				RX3DCar_AddCarToInv(ply,CData,DATA.TuneData)
			else
			
				D3DCar_Meta:Notify( ply, 1, 3, "You bought a car for $"..CData.CarPrice.."! and your car was stored in inventory.")
				D3DCar_Meta:AddMoney(ply,-CData.CarPrice)
				ply:Send3DShopNotice("You bought a car for " .. CData.CarPrice,true)
				DATA.SE:BuyCar(ply,CData,DATA.TuneData)
			
			end
	end)
end

if CLIENT then

	function D3DCarDealer_Open(SellerNPC,NearMyCars)
		if D3DCarShopPanel and D3DCarShopPanel:IsValid() then
			D3DCarShopPanel:Remove()
			D3DCarShopPanel = nil
		end
			D3DCarShopPanel = vgui.Create("D3D_CarShop")
			D3DCarShopPanel:SetPos(0,0)
			D3DCarShopPanel:SetSize(ScrW(),ScrH())
			D3DCarShopPanel.SellerNPC = SellerNPC
			D3DCarShopPanel:Install()
			D3DCarShopPanel:MakePopup()
			D3DCarShopPanel.NearMyCars = NearMyCars or {}
			
			return D3DCarShopPanel
	end
end

if CLIENT then

local PANEL = {}
RXCarPanel_Tuner = PANEL
function PANEL:Init()
	self:ShowCloseButton(true)
	self:SetTitle(" ")
	self:SetDraggable(false)
	
	self.CarList = {}
	
	self.CarColor = Color(255,255,255,255)
	
	self.SelectedINVCarID = nil
	
	self.TuneData = {}
end
function PANEL:RefreshCurrentMode()
	if D3DCarShopPanel.CurMode == "shop" then
		D3DCarShopPanel:BuildShop()
	end
	if D3DCarShopPanel.CurMode == "freecam" then
		D3DCarShopPanel:FreeCamMode()
	end
	if D3DCarShopPanel.CurMode == "tuner" then
		D3DCarShopPanel:BuildTuner()
	end
	if D3DCarShopPanel.CurMode == "Inventory" then
		D3DCarShopPanel:BuildInventory()
	end
end
function PANEL:Notice(txt)
	timer.Simple(0.1,function()
		self:RefreshCurrentMode()
		timer.Simple(0.1,function()
			local NoticePanel = vgui.Create("DPanel",self)
			NoticePanel:SetSize(self:GetWide(),self:GetTall())
			NoticePanel.Paint = function(slf)
				surface.SetDrawColor( Color(0,0,0,200) )
				surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
				
				draw.SimpleText(txt, "CenterCarName", self:GetWide()/2,self:GetTall()/2, Color(0,255,255,255), TEXT_ALIGN_CENTER)
			end

				local Button_FreeCam = vgui.Create("RXCAR_DSWButton",NoticePanel)
				Button_FreeCam:SetPos(NoticePanel:GetWide()/2-100,NoticePanel:GetTall()/3*2)
				Button_FreeCam:SetSize(200,30)
				Button_FreeCam:SetTexts("Okay")
				Button_FreeCam.Click = function(slf)
					NoticePanel:Remove()
					NoticePanel = nil
				end
		end)
	end)
end

function PANEL:Paint()
		surface.SetDrawColor( Color(0,150,255,255) )
		surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
		
		surface.SetDrawColor( Color(0,0,0,255) )
		surface.DrawRect( 2, 2, self:GetWide()-4, self:GetTall()-4 )
		
		if input.IsKeyDown( KEY_ESCAPE ) then
			self:Remove()
			return
		end
		
end

function PANEL:BuyCurrentCar(ToInv)
	if !self.SelectedCar then return end
	
	local CarDB = self.CarList[self.SelectedCar]
	
	if !CarDB then return end
	
	local CData = CarDB.CData
	if CData.AvaliableGroup then
		local GroupCheck = false
		for k,v in pairs(CData.AvaliableGroup) do
			if LocalPlayer():GetNWString("usergroup") == v then
				GroupCheck = true
			end
		end
		if !GroupCheck then 
			self:Notice("You need group that can buy this car")
			return 
		end
	end
	
			if CData.AvaliableTeam then
				local GroupCheck = false
				for k,v in pairs(CData.AvaliableTeam) do
					MsgN(LocalPlayer():GetJobName())
					if LocalPlayer():GetJobName() == v then
						GroupCheck = true
					end
				end
				if !GroupCheck then 
					
					self:Notice("You need to be job that can buy this car")
					return  
				end
			end
	
	if LocalPlayer():getDarkRPVar("money") < CData.CarPrice then 
		self:Notice("Not Enough Money")
		return 
	end
	
	RXCAR_BuyCar(CData.VehicleName,self.SellerNPC,self,ToInv)
end
function PANEL:SellCurrentCar()
	if !self.SelectedCar then return end
	local CarDB = self.CarList[self.SelectedCar]
	
	if !CarDB then return end
	local NearCar = self:IsNearMyCar(CarDB.CData.VehicleName)
	
	if !NearCar then return end
	RXCAR_SellCar(NearCar,CarDB.CData)
end

function PANEL:StoreCurrentCar()
	if !self.SelectedCar then return end
	local CarDB = self.CarList[self.SelectedCar]
	
	if !CarDB then return end
	local NearCar = self:IsNearMyCar(CarDB.CData.VehicleName)
	
	if !NearCar then return end
	RXCAR_StoreCar(NearCar,CarDB.CData)
end

function PANEL:SelectNextCar()
	local CurNum = self.SelectedCar or 1
	
	local NextNum = CurNum + 1
	if NextNum > table.Count(self.CarList) then
		NextNum = 1
	end
	self:SelectCar(NextNum)
end

function PANEL:SelectPreviousCar()
	local CurNum = self.SelectedCar or 1
	
	local NextNum = CurNum - 1
	if NextNum <= 0 then
		NextNum = table.Count(self.CarList)
	end
	self:SelectCar(NextNum)
end

function PANEL:SelectCar(indexnum)
	if !indexnum then return end
	self.TuneData = {}
	if !self.CarList[indexnum] then
		indexnum = 1
		self.SelectedCar = 1
	end
	self.SelectedCar = indexnum

	local DB = self.CarList[indexnum]
	self.BGBackGroundPanel:SetTuneData(self.TuneData)
	self.BGBackGroundPanel:SetCarModel(DB.ScriptData.Model)
	
	if self.DescriptionLabel and self.DescriptionLabel:IsValid() then
		self.DescriptionLabel:Remove()
	end
	
	self.DescriptionLabel = vgui.Create("DLabel")
	self.DescriptionLabel:SetWrap(true)
	self.DescriptionLabel:SetAutoStretchVertical(true)
	self.CarInfoLister:AddItem(self.DescriptionLabel)
	
	self.DescriptionLabel:SetText(DB.CData.Description)
	self.DescriptionLabel:SetWrap(true)

	if self:IsNearMyCar(DB.CData.VehicleName) then
		self.SellButton:SetVisible(true)
		self.StoreButton:SetVisible(true)
	else
		self.SellButton:SetVisible(false)
		self.StoreButton:SetVisible(false)
	end
	
	surface.PlaySound("ui/buttonrollover.wav")
	
end

function PANEL:FreeCamMode()
	self.CurMode = "freecam"
	if self.ShopBGPanel then self.ShopBGPanel:SetVisible(false) end
	if self.BuilderBGPanel then self.BuilderBGPanel:SetVisible(false) end
	if self.FreeCamBGPanel then self.FreeCamBGPanel:SetVisible(true) return end
	
	self.FreeCamBGPanel = vgui.Create("DPanel",self)
	self.FreeCamBGPanel:SetSize(self:GetWide(),self:GetTall())
	self.FreeCamBGPanel.Paint = function(slf)
		local Speed = 1
		
		if input.IsKeyDown(KEY_LSHIFT) then
			Speed = Speed * 2
		end
		if input.IsKeyDown(KEY_W) then
			self.BGBackGroundPanel.CamPos = self.BGBackGroundPanel.CamPos + self.BGBackGroundPanel.CamAngle:Forward() *Speed
		end
		if input.IsKeyDown(KEY_S) then
			self.BGBackGroundPanel.CamPos = self.BGBackGroundPanel.CamPos - self.BGBackGroundPanel.CamAngle:Forward() *Speed
		end
		if input.IsKeyDown(KEY_A) then
			self.BGBackGroundPanel.CamPos = self.BGBackGroundPanel.CamPos - self.BGBackGroundPanel.CamAngle:Right() *Speed
		end
		if input.IsKeyDown(KEY_D) then
			self.BGBackGroundPanel.CamPos = self.BGBackGroundPanel.CamPos + self.BGBackGroundPanel.CamAngle:Right() *Speed
		end
		if input.IsKeyDown(KEY_SPACE) then
			self.BGBackGroundPanel.CamPos = self.BGBackGroundPanel.CamPos + self.BGBackGroundPanel.CamAngle:Up() *Speed
		end

		if input.IsMouseDown(MOUSE_LEFT) then
			if !self.LM then
				self.LM = true
				local MX,MY = gui.MousePos()
				self.LastMousePos_X = MX
				self.LastMousePos_Y = MY
			else
				local CX,CY = gui.MousePos()
				local DX,DY = self.LastMousePos_X-CX,self.LastMousePos_Y-CY
				
				self.BGBackGroundPanel.CamAngle.p = self.BGBackGroundPanel.CamAngle.p - DY/3
				
				if self.BGBackGroundPanel.CamAngle.p > 90 then
					self.BGBackGroundPanel.CamAngle.p = 90
				end
				if self.BGBackGroundPanel.CamAngle.p < -90 then
					self.BGBackGroundPanel.CamAngle.p = -90
				end
				
				
				self.BGBackGroundPanel.CamAngle.y = self.BGBackGroundPanel.CamAngle.y + DX/6
				
				self.LastMousePos_X = CX
				self.LastMousePos_Y = CY
			end
		else
			if self.LM then
				self.LM = false
			end
		end
	end
	
	local Button_FreeCam = vgui.Create("RXCAR_DSWButton",self.FreeCamBGPanel)
	Button_FreeCam:SetPos(20,self.FreeCamBGPanel:GetTall()-40)
	Button_FreeCam:SetSize(200,30)
	Button_FreeCam:SetTexts("Goto Shop")
	Button_FreeCam.Click = function(slf)
		self:BuildShop()
	end
end

function PANEL:IsNearMyCar(VehicleName)
	local FindedMyCar = false
	for a,b in pairs(self.NearMyCars or {}) do
		if b.Ent and b.Ent:IsValid() and b.VN == VehicleName then
			return b.Ent
		end
	end
	return false
end

function PANEL:BuildShop()
	self.CurMode = "shop"
	self:SelectCar(self.SelectedCar)
	if self.BuilderBGPanel then self.BuilderBGPanel:SetVisible(false) end
	if self.FreeCamBGPanel then self.FreeCamBGPanel:SetVisible(false) end
	if self.InventoryBGPanel then self.InventoryBGPanel:SetVisible(false) end
	if self.ShopBGPanel then self.ShopBGPanel:SetVisible(true) return end
	
	self.ShopBGPanel = vgui.Create("DPanel",self)
	self.ShopBGPanel:SetSize(self:GetWide(),self:GetTall())
	self.ShopBGPanel.OnMouseWheeled = function(slf,mc)
		if mc == 1 then
			self:SelectNextCar()
		end
		if mc == -1 then
			self:SelectPreviousCar()
		end
	end
	self.ShopBGPanel.Paint = function(slf)
		local CurCarDB = self.CarList[self.SelectedCar or 1]
		local CData = CurCarDB.CData
		local TuneData = CurCarDB.TuneData
		-- Car Name
		draw.SimpleText(CData.CarName, "CenterCarName", self:GetWide()/2,self:GetTall()/5*4.3, Color(0,255,255,255), TEXT_ALIGN_CENTER)
		
		if CData.AvaliableGroup then
			local Groups = ""
			for k,v in pairs(CData.AvaliableGroup) do
				Groups = Groups .. v .. ", "
			end
			draw.SimpleText("Rank Require : " .. Groups, "SansationOut_S20", self:GetWide()/2,self:GetTall()/5*4.3+45, Color(0,150,255,255), TEXT_ALIGN_CENTER)
		end
		
		if CData.AvaliableTeam then
			local Groups = ""
			for k,v in pairs(CData.AvaliableTeam) do
				Groups = Groups .. v .. ", "
			end
			draw.SimpleText("Job Require : " .. Groups, "SansationOut_S20", self:GetWide()/2,self:GetTall()/5*4.3+45+25, Color(0,150,255,255), TEXT_ALIGN_CENTER)
		end
		
		-- CarList Boxes --
		local StartX = self:GetWide()/7*2
		local FullX = self:GetWide()/7*3
		local Count = table.Count(self.CarList)
		local BSX =  FullX/Count

		for k,v in pairs(self.CarList) do
			if self.SelectedCar == k then
				surface.SetDrawColor( Color(0,255,255,255) )
			else
				if !self:IsNearMyCar(v.CData.VehicleName) then
					surface.SetDrawColor( Color(0,255,255,50) )
				else
					surface.SetDrawColor( Color(0,255,0,50) )
				end
				
			end
			
			surface.DrawRect( StartX + (k-1)*BSX, self:GetTall()*0.8,BSX-5, 20 )
		end
	end

	
	self.CarInfoLister = vgui.Create("DPanelList",self.ShopBGPanel)
	self.CarInfoLister:SetPos(10,50)
	self.CarInfoLister:SetSize(290,self.ShopBGPanel:GetTall()/2)
	self.CarInfoLister:EnableHorizontal( false )
	self.CarInfoLister:EnableVerticalScrollbar( true )
	self.CarInfoLister:RXCAR_PaintListBarC()
	
	local Panel = vgui.Create("DPanel")
	Panel:SetSize(self.CarInfoLister:GetWide(),30)
	Panel.Paint = function(slf)
		local CurCarDB = self.CarList[self.SelectedCar or 1]
		local CData = CurCarDB.CData
		
		surface.SetDrawColor( Color(0,0,0,100) )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		draw.SimpleText(CData.CarName, "SansationOut_S30", 0,0, Color(0,200,255,255))
	end
	self.CarInfoLister:AddItem(Panel)
	
	local Panel = vgui.Create("DPanel")
	Panel:SetSize(self.CarInfoLister:GetWide(),20)
	Panel.Paint = function(slf)
		local CurCarDB = self.CarList[self.SelectedCar or 1]
		local CData = CurCarDB.CData
		
		surface.SetDrawColor( Color(0,0,0,100) )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		draw.SimpleText("Amount Limit : " .. (CData.MaxAmount or " Unlimited"), "SansationOut_S20", 0,0, Color(0,150,255,255))
	end	
	self.CarInfoLister:AddItem(Panel)
	
	local Panel = vgui.Create("DPanel")
	Panel:SetSize(self.CarInfoLister:GetWide(),20)
	Panel.Paint = function(slf)
		local CurCarDB = self.CarList[self.SelectedCar or 1]
		local CData = CurCarDB.CData
		
		surface.SetDrawColor( Color(0,0,0,100) )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		if CData.CarPrice > LocalPlayer():getDarkRPVar("money") then
			draw.SimpleText("Price : " .. CData.CarPrice, "SansationOut_S20", 0,0, Color(255,0,0,255))
		else
			draw.SimpleText("Price : " .. CData.CarPrice, "SansationOut_S20", 0,0, Color(0,150,255,255))
		end
	end	
	self.CarInfoLister:AddItem(Panel)
	
	local Panel = vgui.Create("DPanel")
	Panel:SetSize(self.CarInfoLister:GetWide(),20)
	Panel.Paint = function(slf)
		local CurCarDB = self.CarList[self.SelectedCar or 1]
		local CData = CurCarDB.CData
		
		surface.SetDrawColor( Color(0,0,0,100) )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		if CData.CarPrice > LocalPlayer():getDarkRPVar("money") then
			draw.SimpleText("Refund : " .. CData.CarRefund or CData.CarPrice/2, "SansationOut_S20", 0,0, Color(255,0,0,255))
		else
			draw.SimpleText("Refund : " .. CData.CarRefund or CData.CarPrice/2, "SansationOut_S20", 0,0, Color(0,150,255,255))
		end
	end	
	self.CarInfoLister:AddItem(Panel)
	
	local Panel = vgui.Create("DPanel")
	Panel:SetSize(self.CarInfoLister:GetWide(),20)
	Panel.Paint = function(slf)
		local CurCarDB = self.CarList[self.SelectedCar or 1]
		local CData = CurCarDB.CData
		
		surface.SetDrawColor( Color(0,0,0,100) )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		draw.SimpleText("Cur Money : " .. string.Comma(LocalPlayer():getDarkRPVar("money")), "SansationOut_S20", 0,0, Color(0,150,255,255))
	end	
	self.CarInfoLister:AddItem(Panel)
	
	self.CarLister = vgui.Create("DPanelList",self.ShopBGPanel)
	self.CarLister:SetPos(self.ShopBGPanel:GetWide()-300,50)
	self.CarLister:SetSize(290,self.ShopBGPanel:GetTall()/2)
	self.CarLister:EnableHorizontal( false )
	self.CarLister:EnableVerticalScrollbar( true )
	self.CarLister:RXCAR_PaintListBarC()
	
	
	local Button_Left = vgui.Create("RXCAR_DSWButton",self.ShopBGPanel)
	Button_Left:SetPos(self.ShopBGPanel:GetWide()/5-20,self.ShopBGPanel:GetTall()/5*3-20)
	Button_Left:SetSize(40,40)
	Button_Left:SetTexts("<")
	Button_Left.Click = function(slf)
		self:SelectPreviousCar()
	end
	
	local Button_Right = vgui.Create("RXCAR_DSWButton",self.ShopBGPanel)
	Button_Right:SetPos(self.ShopBGPanel:GetWide()/5*4-20,self.ShopBGPanel:GetTall()/5*3-20)
	Button_Right:SetSize(40,40)
	Button_Right:SetTexts(">")
	Button_Right.Click = function(slf)
		self:SelectNextCar()
	end
	
	
	local Button_Tuner = vgui.Create("RXCAR_DSWButton",self.ShopBGPanel)
	Button_Tuner:SetPos(20,self.ShopBGPanel:GetTall()-120)
	Button_Tuner:SetSize(200,30)
	Button_Tuner:SetTexts("Inventory")
	Button_Tuner.Click = function(slf)
		self:BuildInventory()
	end
	
	local Button_Tuner = vgui.Create("RXCAR_DSWButton",self.ShopBGPanel)
	Button_Tuner:SetPos(20,self.ShopBGPanel:GetTall()-80)
	Button_Tuner:SetSize(200,30)
	Button_Tuner:SetTexts("Tuner")
	Button_Tuner.Click = function(slf)
		local PackData = {}
			PackData.Mode = "shoptuner"
			PackData.TuneData = self.TuneData
		self:BuildTuner(PackData)
	end
	
	local Button_FreeCam = vgui.Create("RXCAR_DSWButton",self.ShopBGPanel)
	Button_FreeCam:SetPos(20,self.ShopBGPanel:GetTall()-40)
	Button_FreeCam:SetSize(200,30)
	Button_FreeCam:SetTexts("FreeCam")
	Button_FreeCam.Click = function(slf)
		self:FreeCamMode()
	end

	local Button_Store = vgui.Create("RXCAR_DSWButton",self.ShopBGPanel)
	Button_Store:SetPos(self.ShopBGPanel:GetWide()-220,self.ShopBGPanel:GetTall()-200)
	Button_Store:SetSize(200,30)
	Button_Store:SetTexts("Store")
	Button_Store.ClickSound = "buttons/blip1.wav"
	Button_Store.Click = function(slf)
		self:StoreCurrentCar()
	end
	self.StoreButton = Button_Store
	
	local Button_Sell = vgui.Create("RXCAR_DSWButton",self.ShopBGPanel)
	Button_Sell:SetPos(self.ShopBGPanel:GetWide()-220,self.ShopBGPanel:GetTall()-160)
	Button_Sell:SetSize(200,30)
	Button_Sell:SetTexts("Sell!")
	Button_Sell.ClickSound = "buttons/blip1.wav"
	Button_Sell.Click = function(slf)
		self:SellCurrentCar()
	end
	self.SellButton = Button_Sell
	
	local Button_BuyToINV = vgui.Create("RXCAR_DSWButton",self.ShopBGPanel)
	Button_BuyToINV:SetPos(self.ShopBGPanel:GetWide()-220,self.ShopBGPanel:GetTall()-120)
	Button_BuyToINV:SetSize(200,30)
	Button_BuyToINV:SetTexts("Buy & store to inv")
	Button_BuyToINV.ClickSound = "buttons/blip1.wav"
	Button_BuyToINV.Click = function(slf)
		self:BuyCurrentCar(true)
	end
	
	
	local Button_Buy = vgui.Create("RXCAR_DSWButton",self.ShopBGPanel)
	Button_Buy:SetPos(self.ShopBGPanel:GetWide()-220,self.ShopBGPanel:GetTall()-80)
	Button_Buy:SetSize(200,30)
	Button_Buy:SetTexts("Buy!")
	Button_Buy.ClickSound = "buttons/blip1.wav"
	Button_Buy.Click = function(slf)
		self:BuyCurrentCar(false)
	end
	
	local CloseButton = vgui.Create("RXCAR_DSWButton",self.ShopBGPanel)
	CloseButton:SetPos(self.ShopBGPanel:GetWide()-220,self.ShopBGPanel:GetTall()-40)
	CloseButton:SetSize(200,30)
	CloseButton:SetTexts("Close")
	CloseButton.Click = function(slf)
		self.BGBackGroundPanel:RemoveProp()
		self:Remove()
	end
	
	self.BGBackGroundPanel:SetTuneData({})
end


function PANEL:SelectNextCarINV()
	local List = self.MyInventoryCarLists 
	if !List then return end
	self.SelectedMyInventoryCarNum = self.SelectedMyInventoryCarNum or 1
	
	if self.SelectedMyInventoryCarNum > 1 then
		self.SelectedMyInventoryCarNum = self.SelectedMyInventoryCarNum - 1
	else
		self.SelectedMyInventoryCarNum = #List
	end
	
	self:SelectCarINV(List[self.SelectedMyInventoryCarNum])
end

function PANEL:SelectPreviousCarINV()
	local List = self.MyInventoryCarLists 
	if !List then return end
	self.SelectedMyInventoryCarNum = self.SelectedMyInventoryCarNum or 1
	
	if self.SelectedMyInventoryCarNum < #List then
		self.SelectedMyInventoryCarNum = self.SelectedMyInventoryCarNum + 1
	else
		self.SelectedMyInventoryCarNum = 1
	end
	
	self:SelectCarINV(List[self.SelectedMyInventoryCarNum])
end


function PANEL:SelectCarINV(UniqueID)
	self.SelectedINVCarID = UniqueID
	if !RX3DCar_Inventory[UniqueID] then return end
	
	local DB = RX3DCar_Inventory[UniqueID]
	local TuneData = DB.TuneData
	local VehicleName = DB.VehicleName
	
	local CData = list.Get('Vehicles')[VehicleName]
	
	if !CData then return end
	
	
	self.BGBackGroundPanel:SetTuneData(TuneData)
	self.BGBackGroundPanel:SetCarModel(CData.Model)
	
	surface.PlaySound("ui/buttonrollover.wav")
	
end

function PANEL:SellCarFromINV()
	if !RX3DCar_Inventory[self.SelectedINVCarID] then return end
	
	RXCAR_SellINVCar( self.SelectedINVCarID , self.SellerNPC)
end

function PANEL:RespawnCarFromINV()
	if !RX3DCar_Inventory[self.SelectedINVCarID] then return end
	
	RXCAR_RespawnINVCar( self.SelectedINVCarID , self.SellerNPC)
end


function PANEL:BuildInventory()

	self.BGBackGroundPanel:RemoveCarModel()

	self.CurMode = "Inventory"
	if self.BuilderBGPanel then self.BuilderBGPanel:SetVisible(false) end
	if self.FreeCamBGPanel then self.FreeCamBGPanel:SetVisible(false) end
	if self.ShopBGPanel then self.ShopBGPanel:SetVisible(false) end
	if self.InventoryBGPanel then self.InventoryBGPanel:Remove() end
	
	self.InventoryBGPanel = vgui.Create("DPanel",self)
	self.InventoryBGPanel:SetSize(self:GetWide(),self:GetTall())
	self.InventoryBGPanel.OnMouseWheeled = function(slf,mc)
		if mc == 1 then
			self:SelectNextCarINV()
		end
		if mc == -1 then
			self:SelectPreviousCarINV()
		end
	end
	self.InventoryBGPanel.Paint = function(slf)
		local CurCarDB = RX3DCar_Inventory[self.SelectedINVCarID or 1]
		if !CurCarDB then return end
		
		local TuneData = CurCarDB.TuneData
		local CData = nil
		for k,v in pairs(D3DCarConfig.Car) do
			if v.VehicleName == CurCarDB.VehicleName then
				CData = v
				continue
			end
		end
		if !CData then return end
		
		-- Car Name
		draw.SimpleText(CData.CarName, "CenterCarName", self:GetWide()/2,self:GetTall()/5*4.3, Color(0,255,255,255), TEXT_ALIGN_CENTER)
		
		if CData.AvaliableGroup then
			local Groups = ""
			for k,v in pairs(CData.AvaliableGroup) do
				Groups = Groups .. v .. ", "
			end
			draw.SimpleText("Rank Require : " .. Groups, "SansationOut_S20", self:GetWide()/2,self:GetTall()/5*4.3+45, Color(0,150,255,255), TEXT_ALIGN_CENTER)
		end
		
		if CData.AvaliableTeam then
			local Groups = ""
			for k,v in pairs(CData.AvaliableTeam) do
				Groups = Groups .. v .. ", "
			end
			draw.SimpleText("Job Require : " .. Groups, "SansationOut_S20", self:GetWide()/2,self:GetTall()/5*4.3+45+25, Color(0,150,255,255), TEXT_ALIGN_CENTER)
		end
		
		-- CarList Boxes --
		local StartX = self:GetWide()/7*2
		local FullX = self:GetWide()/7*3
		local Count = table.Count(RX3DCar_Inventory)
		local BSX =  FullX/Count

		local k = 0
		for UniqueID,v in pairs(RX3DCar_Inventory) do
			k = k + 1
			if self.SelectedINVCarID == UniqueID then
				surface.SetDrawColor( Color(0,255,255,255) )
			else
				surface.SetDrawColor( Color(0,255,255,50) )
			end
			
			surface.DrawRect( StartX + (k-1)*BSX, self:GetTall()*0.8,BSX-5, 20 )
		end
	end
	
	
	self.CarLister = vgui.Create("DPanelList",self.InventoryBGPanel)
	self.CarLister:SetPos(self.InventoryBGPanel:GetWide()-300,50)
	self.CarLister:SetSize(290,self.InventoryBGPanel:GetTall()/2)
	self.CarLister:EnableHorizontal( false )
	self.CarLister:EnableVerticalScrollbar( true )
	self.CarLister:RXCAR_PaintListBarC()
	
	
	local Button_Left = vgui.Create("RXCAR_DSWButton",self.InventoryBGPanel)
	Button_Left:SetPos(self.InventoryBGPanel:GetWide()/5-20,self.InventoryBGPanel:GetTall()/5*3-20)
	Button_Left:SetSize(40,40)
	Button_Left:SetTexts("<")
	Button_Left:SetVisible(false)
	Button_Left.Click = function(slf)
		self:SelectPreviousCarINV()
	end
	
	local Button_Right = vgui.Create("RXCAR_DSWButton",self.InventoryBGPanel)
	Button_Right:SetPos(self.InventoryBGPanel:GetWide()/5*4-20,self.InventoryBGPanel:GetTall()/5*3-20)
	Button_Right:SetSize(40,40)
	Button_Right:SetTexts(">")
	Button_Right:SetVisible(false)
	Button_Right.Click = function(slf)
		self:SelectNextCarINV()
	end
	
	
	local Button_Tuner = vgui.Create("RXCAR_DSWButton",self.InventoryBGPanel)
	Button_Tuner:SetPos(20,self.InventoryBGPanel:GetTall()-80)
	Button_Tuner:SetSize(200,30)
	Button_Tuner:SetTexts("Tuner")
	Button_Tuner:SetVisible(false)
	Button_Tuner.Click = function(slf)
	
		local DB = RX3DCar_Inventory[self.SelectedINVCarID]
		local PackData = {}
			PackData.Mode = "invtuner"
			PackData.TuneData = DB.TuneData
			PackData.UniqueID = self.SelectedINVCarID
		self:BuildTuner(PackData)
	end
	
	local Button_GoBack = vgui.Create("RXCAR_DSWButton",self.InventoryBGPanel)
	Button_GoBack:SetPos(20,self.InventoryBGPanel:GetTall()-40)
	Button_GoBack:SetSize(200,30)
	Button_GoBack:SetTexts("Go Back")
	Button_GoBack.Click = function(slf)
		self:BuildShop()
	end
	
	local Button_Sell = vgui.Create("RXCAR_DSWButton",self.InventoryBGPanel)
	Button_Sell:SetPos(self.InventoryBGPanel:GetWide()-220,self.InventoryBGPanel:GetTall()-80)
	Button_Sell:SetSize(200,30)
	Button_Sell:SetTexts("Sell")
	Button_Sell:SetVisible(false)
	Button_Sell.Click = function(slf)
		self:SellCarFromINV()
	end
	
	local Button_Respawn = vgui.Create("RXCAR_DSWButton",self.InventoryBGPanel)
	Button_Respawn:SetPos(self.InventoryBGPanel:GetWide()-220,self.InventoryBGPanel:GetTall()-40)
	Button_Respawn:SetSize(200,30)
	Button_Respawn:SetTexts("Respawn")
	Button_Respawn:SetVisible(false)
	Button_Respawn.Click = function(slf)
		self:RespawnCarFromINV()
	end
	
	
	self.CarLister:Clear()
		-- Car List
		
		self.MyInventoryCarLists = {}
		for UniqueID,Data in pairs(RX3DCar_Inventory) do
			Button_Tuner:SetVisible(true)
			Button_Sell:SetVisible(true)
			Button_Respawn:SetVisible(true)
			Button_Right:SetVisible(true)
			Button_Left:SetVisible(true)
			table.insert(self.MyInventoryCarLists,UniqueID)
			if !self.BGBackGroundPanel:GetCarEnt() then
				self:SelectCarINV(UniqueID)
			end
			local CarMain = vgui.Create("RXCAR_DSWButton")
			CarMain:SetSize(self.CarLister:GetWide(),20)
			
			
			local CData = nil
			for k,v in pairs(D3DCarConfig.Car) do
				if v.VehicleName == Data.VehicleName then
					CData = v
					continue
				end
			end
			if CData then
				CarMain:SetTexts(CData.CarName)
				CarMain:SetBoarderColor(Color(0,150,255,50))
				CarMain.Click = function(slf)
					self:SelectCarINV(UniqueID)
				end
				CarMain.PaintBackGround = function(slf)
					if UniqueID == self.SelectedINVCarID then
						surface.SetDrawColor( Color(0,150,255,255) )
						surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
					end
				end
				self.CarLister:AddItem(CarMain)
			end
		end
		
end

function PANEL:Install()
	self.BGBackGroundPanel = vgui.Create("D3D_CarShop_BGBackGround",self)
	self.BGBackGroundPanel:SetSize(self:GetWide()-4,self:GetTall()-4)
	self.BGBackGroundPanel.Mother = self
	self.BGBackGroundPanel:Center()
	self.BGBackGroundPanel:Install()
	
	self:BuildShop()
	self:InitializeCar()
end

function PANEL:InitializeCar()
	self.CarList = {}
	for k,v in pairs(D3DCarConfig.Car) do
		if list.Get('Vehicles')[v.VehicleName] then
			table.insert(self.CarList,{LuaName=v.VehicleName,CData = v,ScriptData = list.Get('Vehicles')[v.VehicleName]})
			if !self.SelectedCar then
				timer.Simple(0.1,function()
					self:SelectCar(1)
				end)
			end
		end
	end
	self.CarLister:Clear()
		
		
		-- Car List
		for k = 1,#self.CarList do
			k = #self.CarList-k+1
			local CarMain = vgui.Create("RXCAR_DSWButton")
			CarMain:SetSize(self.CarLister:GetWide(),20)
			CarMain:SetTexts(self.CarList[k].CData.CarName)
			CarMain:SetBoarderColor(Color(0,150,255,50))
			CarMain.Click = function(slf)
				self:SelectCar(k)
			end
			CarMain.PaintBackGround = function(slf)
				if k == self.SelectedCar then
					surface.SetDrawColor( Color(0,150,255,255) )
					surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
				end
			end
			self.CarLister:AddItem(CarMain)
		end
end

function PANEL:Think()
end

vgui.Register("D3D_CarShop",PANEL,"DFrame")



end






if CLIENT then
local StationBGModel = {
	GroundBasic = { Model = "models/props_trainstation/trainstation_clock001.mdl", Material = "models/props_combine/CombineThumper002",Size = Vector(0.1875,50,50),Color = Color(0,150,255,255),Angle = Angle(270,0,0),RTAngle = Angle(0,0,0),Pos = Vector(0,0,0) },
	ShowCaseGroundOL = { Model = "models/hunter/tubes/circle2x2.mdl", Material = "models/debug/debugwhite",Size = Vector(4,4,0.1),Color = Color(0,150,510,255),Angle = Angle(0,0,0),RTAngle = Angle(0,0,0),Pos = Vector(0,0,10) },
	ShowCaseGround = { Model = "models/hunter/tubes/circle2x2.mdl", Material = "",Size = Vector(3.7,3.7,1),Color = Color(0,45,62,255),Angle = Angle(0,0,0),RTAngle = Angle(0,0,0),Pos = Vector(0,0,11) },
}

local PANEL = {}
function PANEL:Init()
	self.StationModelEnts = {}
	self.CarEnts = nil
	self.CarHoloEnts = nil
	
	self.CAngle = 0
	
	self.CamPos = Vector(0,300,150)
	self.CamAngle = (Vector(0,0,30)-Vector(0,450,200)):Angle()
	
	self.TuneData = {}
end
function PANEL:SetTuneData(TuneData)
	self.TuneData = TuneData
end
function PANEL:RemoveProp()
	for k,v in pairs(self.StationModelEnts) do
		v:Remove()
	end
	if self.CarEnts and self.CarEnts:IsValid() then
		self.CarEnts:Remove()
	end
	if self.CarHoloEnts and self.CarHoloEnts:IsValid() then
		self.CarHoloEnts:Remove()
	end
end
function PANEL:Paint()
	if self.Mother.CurMode and self.Mother.CurMode != "freecam" and self.Mother.CurMode != "tuner" then
		self.CAngle = CurTime()*10
	end
	
	if self.CamPos.z < 20 then self.CamPos.z = 20 end
	if self.CamPos.z > 400 then self.CamPos.z = 400 end
	
	if self.CamPos.x < -300 then self.CamPos.x = -300 end
	if self.CamPos.x > 300 then self.CamPos.x = 300 end
	
	if self.CamPos.y < -300 then self.CamPos.y = -300 end
	if self.CamPos.y > 300 then self.CamPos.y = 300 end
	
	local x, y = self:LocalToScreen( 0, 0 )
	local w, h = self:GetSize()
		cam.Start3D( self.CamPos, self.CamAngle, 70, x, y, w, h, 5, 4096 )
		
		render.SuppressEngineLighting( true )
		for k,v in pairs(self.StationModelEnts) do
			render.SetColorModulation( v.Col.r/255,v.Col.g/255,v.Col.b/255 )
			v:DrawModel()
		end
		
		local CarColor = self.TuneData.Color or Color(255,255,255,255)
		
		if self.Mother and self.Mother.CarColor then
			render.SetColorModulation( CarColor.r/255,CarColor.g/255,CarColor.b/255 )
		else
			render.SetColorModulation( 1,1,1 )
		end
		
		if self.CarEnts and self.CarEnts:IsValid() then
			self.CarEnts:SetAngles(Angle(0,self.CAngle,0))
			self.CarEnts:DrawModel()
		end
		
		-- 
		
		render.SetColorModulation( 0,0.5,1 )
		render.SetBlend(0.1)
		if self.CarHoloEnts and self.CarHoloEnts:IsValid() then
			self.CarHoloEnts:SetAngles(Angle(0,self.CAngle,0))
			self.CarHoloEnts:DrawModel()
		end
		render.SetBlend(1)
		render.SuppressEngineLighting( false )
		
		self:DrawElements(self.TuneData.Elements or {})
		

		cam.End3D()
end

local MAT_BEAM = Material("sprites/physgbeamb")
local MAT_LIGHT = Material("particle/Particle_Glow_05")

function PANEL:DrawElements(TuneData)
	if !self.CarEnts or !self.CarEnts:IsValid() then return end
	
		for k,v in pairs(TuneData) do
			if v.Type == "LEDStrip" then
				render.SetMaterial( MAT_BEAM )
				
				local Pos1 = self.CarEnts:LocalToWorld(v.Pos1)
				local Pos2 = self.CarEnts:LocalToWorld(v.Pos2)
				
				render.DrawBeam( Pos1,Pos2, v.Width, 1, 1, v.Color ) 
			end
			if v.Type == "RearLight" then
				local Pos1 = self.CarEnts:LocalToWorld(v.Pos1)
				
				render.SetMaterial( MAT_LIGHT )
				render.DrawQuadEasy( Pos1,    --position of the rect
				self.CamAngle:Forward() * -1,        --direction to face in
				v.Size, v.Size,              --size of the rect
				v.Color,  --color
				90                     --rotate 90 degrees
				) 
			end
			
		end
end

function PANEL:GetCarEnt()
	if self.CarEnts and self.CarEnts:IsValid() then
		return self.CarEnts
	else
		return false
	end
end

function PANEL:RemoveCarModel()
	if self.CarEnts and self.CarEnts:IsValid() then
		self.CarEnts:Remove()
		self.CarEnts = nil
	end
	if self.CarHoloEnts and self.CarHoloEnts:IsValid() then
		self.CarHoloEnts:Remove()
		self.CarHoloEnts = nil
	end
	
end

function PANEL:SetCarModel(mdl)
	if !self.CarEnts or !self.CarEnts:IsValid() then
		self.CarEnts = ClientsideModel( mdl, RENDER_GROUP_VIEW_MODEL_OPAQUE )
		self.CarEnts:SetPos(Vector(0,0,15))
		self.CarEnts:SetNoDraw( true )
	else
		self.CarEnts:SetModel(mdl)
	end
	
	if !self.CarHoloEnts or !self.CarHoloEnts:IsValid() then
		self.CarHoloEnts = ClientsideModel( mdl, RENDER_GROUP_VIEW_MODEL_OPAQUE )
		self.CarHoloEnts:SetPos(Vector(0,0,15))
		self.CarHoloEnts:SetNoDraw( true )
		self.CarHoloEnts:SetMaterial("models/wireframe")
			local mat = Matrix()
			mat:Scale(Vector(1.0001,1.0001,1.0001))
		self.CarHoloEnts:EnableMatrix("RenderMultiply", mat)
	else
		self.CarHoloEnts:SetModel(mdl)
	end
	
end

function PANEL:Install()
	for k,v in pairs(StationBGModel) do
		local Models = ClientsideModel( v.Model, RENDER_GROUP_VIEW_MODEL_OPAQUE )
		Models:SetPos(v.Pos)
		Models:SetAngles(v.Angle)
		if v.Material then
			Models:SetMaterial(v.Material)
		end
		Models:SetNoDraw( true )
		Models.Col = v.Color
		
		local mat = Matrix()
		mat:Scale(v.Size)
		Models:EnableMatrix("RenderMultiply", mat)
		table.insert(self.StationModelEnts,Models)
	end
end

vgui.Register("D3D_CarShop_BGBackGround",PANEL,"DPanel")
end


if CLIENT then
	if LoadRXTuner then
		LoadRXTuner()
	end
end