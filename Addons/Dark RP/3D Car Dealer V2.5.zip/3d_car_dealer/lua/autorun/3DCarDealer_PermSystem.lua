if SERVER then
	util.AddNetworkString( "RX3DCar_SendInventory_S2C" )
	function RXCAR_SendInventory(ply)
		local SteamIDG = string.gsub(ply:SteamID(),":","_")
		
		local Data = {}
		if file.Exists( "rm_car_dealer/inventory/" .. SteamIDG .. ".txt" ,"DATA") then
			Data = util.JSONToTable(file.Read( "rm_car_dealer/inventory/" .. SteamIDG .. ".txt" ))
		end
		
		net.Start( "RX3DCar_SendInventory_S2C" )
			net.WriteTable(Data)
		net.Send(ply)
	end
end
if CLIENT then
	RX3DCar_Inventory = RX3DCar_Inventory or {}
	net.Receive( "RX3DCar_SendInventory_S2C", function( len,ply ) --
		local DATA = net.ReadTable()
		RX3DCar_Inventory = DATA
		
		if D3DCarShopPanel and D3DCarShopPanel:IsValid() then
			if D3DCarShopPanel.CurMode == "shop" then
				D3DCarShopPanel:BuildInventory()
			else
				D3DCarShopPanel:BuildShop()
			end
		end
	end)
	
	
end
if SERVER then
	RX3DCar_Cars = RX3DCar_Cars or {}
	function RX3DCar_AddCar(ent)
		RX3DCar_Cars[ent] = ent
	end
	function RX3DCar_UpdateINVCarData(ply,UniqueID,TuneData)
		local SteamIDG = string.gsub(ply:SteamID(),":","_")
		local Data = {}
		if file.Exists( "rm_car_dealer/inventory/" .. SteamIDG .. ".txt" ,"DATA") then
			Data = util.JSONToTable(file.Read( "rm_car_dealer/inventory/" .. SteamIDG .. ".txt" ))
		end
			if Data[UniqueID] then
				Data[UniqueID].TuneData = TuneData
			end
			
			MsgN("Write " .. 5 )
			file.Write("rm_car_dealer/inventory/" .. SteamIDG .. ".txt", util.TableToJSON(Data))
			
			-- Update
				net.Start( "RX3DCar_SendInventory_S2C" )
					net.WriteTable(Data)
				net.Send(ply)
	end
	

	function RX3DCar_AddCarToInv(ply,CData,TuneData)
		local SteamIDG = string.gsub(ply:SteamID(),":","_")
		
		local Data = {}
		if file.Exists( "rm_car_dealer/inventory/" .. SteamIDG .. ".txt" ,"DATA") then
			Data = util.JSONToTable(file.Read( "rm_car_dealer/inventory/" .. SteamIDG .. ".txt" ))
		end
			
				local TB2Insert = {}
				TB2Insert.TuneData = TuneData
				TB2Insert.VehicleName = CData.VehicleName
				
				local function GenUniqueID()
					local Num = math.random(100000,999999)
					if Data[Num] then
						return GenUniqueID()
					else
						return Num
					end
				end
				local UID = GenUniqueID()
				TB2Insert.UniqueID = UID
				Data[UID] = TB2Insert
				
				MsgN("Write " .. 4 )
				file.Write("rm_car_dealer/inventory/" .. SteamIDG .. ".txt", util.TableToJSON(Data))
			

				-- Update
				net.Start( "RX3DCar_SendInventory_S2C" )
					net.WriteTable(Data)
				net.Send(ply)

	end
	
	
	function RX3DCar_StoreCar(ply,ent)
		local SteamIDG = string.gsub(ply:SteamID(),":","_")
		
		local Data = {}
		if file.Exists( "rm_car_dealer/inventory/" .. SteamIDG .. ".txt" ,"DATA") then
			Data = util.JSONToTable(file.Read( "rm_car_dealer/inventory/" .. SteamIDG .. ".txt" ))
		end
			if ent and ent:IsValid() and ent.OwnerID == ply:SteamID() then
				local TB2Insert = {}
				TB2Insert.TuneData = ent.TuneData
				TB2Insert.VehicleName = ent.VehicleName or "nil"
				
				local function GenUniqueID()
					local Num = math.random(100000,999999)
					if Data[Num] then
						return GenUniqueID()
					else
						return Num
					end
				end
				local UID = GenUniqueID()
				TB2Insert.UniqueID = UID
				Data[UID] = TB2Insert
				
				if RX3DCar_Cars[ent] then
					RX3DCar_Cars[ent] = nil
				end
				D3DCarCrashSaver:RemoveCar(ply,ent)
				ent.IgnoreRemoveHookTime = CurTime() + 999
				ent:Remove()
				
				MsgN("Write " .. 3 )
				file.Write("rm_car_dealer/inventory/" .. SteamIDG .. ".txt", util.TableToJSON(Data))
			

				-- Update
				net.Start( "RX3DCar_SendInventory_S2C" )
					net.WriteTable(Data)
				net.Send(ply)
			end
	end
	
	
	hook.Add( "PlayerDisconnected", "RX3DCar Save", function(ply)
		local SteamIDG = string.gsub(ply:SteamID(),":","_")
		local TB2Insert = {}
		for k,v in pairs(RX3DCar_Cars) do
			if v and v:IsValid() and v.OwnerID == ply:SteamID() then
				RX3DCar_StoreCar(ply,v)
			end
		end
	end)
	
	hook.Add( "EntityRemoved", "RX3DCar Removed Save", function(ent)
		if ent.IsCar and ent.RX3DCar then
			if ent.IgnoreRemoveHookTime then
				if CurTime() < ent.IgnoreRemoveHookTime then
					return true
				end
			end
			if ent and ent:IsValid() and ent.IsCar and ent.RX3DCar and ent.Owner and ent.Owner:IsValid() and ent.SpawnTime and (CurTime() - ent.SpawnTime) > 1 then
				RX3DCar_StoreCar(ent.Owner,ent)
			end
		end
	end)
	
	
	
	function RX3DCar_SpawnStoredCar(ply,ShopEnt,UniqueID)
		local SteamIDG = string.gsub(ply:SteamID(),":","_")
		
		local Data = {}
		if file.Exists( "rm_car_dealer/inventory/" .. SteamIDG .. ".txt" ,"DATA") then
			Data = util.JSONToTable(file.Read( "rm_car_dealer/inventory/" .. SteamIDG .. ".txt" ))
		end
		if !Data[UniqueID] then return end
		
		local DataD = Data[UniqueID]
		
		
			local CData = nil
			for k,v in pairs(D3DCarConfig.Car) do
				if v.VehicleName == DataD.VehicleName then
					CData = v
					continue
				end
			end
			if !CData then return end
			if CData.MaxAmount then
				local Count = 0
				for k,v in pairs(ents.GetAll()) do
					if v.VehicleName and v.OwnerID == ply:SteamID() and v.VehicleName == CData.VehicleName then
						Count = Count + 1
						if Count >= CData.MaxAmount then
							ply:Send3DShopNotice("Car amount limit!")
							return 
						end
					end
				end
			end
			
			if CData.AvaliableGroup then
				local GroupCheck = false
				for k,v in pairs(CData.AvaliableGroup) do
					if ply:GetNWString("usergroup") == v then
						GroupCheck = true
					end
				end
				if !GroupCheck then 
					ply:Send3DShopNotice("You need Group that can buy this car")
					return 
				end
			end
			
			if CData.AvaliableTeam then
				local GroupCheck = false
				for k,v in pairs(CData.AvaliableTeam) do
					if ply:GetJobName() == v then
						GroupCheck = true
					end
				end
				if !GroupCheck then 
					ply:Send3DShopNotice("You need to be job that can buy this car")
					return 
				end
			end
			
			Data[UniqueID] = nil
			ply:Send3DShopNotice("Respawn Complete")
			
			MsgN("Write " .. 1 )
			file.Write("rm_car_dealer/inventory/" .. SteamIDG .. ".txt", util.TableToJSON(Data))

			
			-- Update
			net.Start( "RX3DCar_SendInventory_S2C" )
				net.WriteTable(Data)
			net.Send(ply)
			
			ShopEnt:BuyCar(ply,CData,DataD.TuneData)
			
	end
	
	
	function RX3DCar_SellStoredCar(ply,ShopEnt,UniqueID)
		
		local SteamIDG = string.gsub(ply:SteamID(),":","_")
		
		local Data = {}
		if file.Exists( "rm_car_dealer/inventory/" .. SteamIDG .. ".txt" ,"DATA") then
			Data = util.JSONToTable(file.Read( "rm_car_dealer/inventory/" .. SteamIDG .. ".txt" ))
		end
		if !Data[UniqueID] then return end
		
		local DataD = Data[UniqueID]
		
		
			local CData = nil
			for k,v in pairs(D3DCarConfig.Car) do
				if v.VehicleName == DataD.VehicleName then
					CData = v
					continue
				end
			end
			if !CData then return end

			Data[UniqueID] = nil
			
			MsgN("Write " .. 2 )
			file.Write("rm_car_dealer/inventory/" .. SteamIDG .. ".txt", util.TableToJSON(Data))

			-- Update
			net.Start( "RX3DCar_SendInventory_S2C" )
				net.WriteTable(Data)
			net.Send(ply)
			D3DCar_Meta:AddMoney(ply,CData.CarRefund or CData.CarPrice/2)
			
			ply:Send3DShopNotice("You sold a stored car for " .. (CData.CarRefund or CData.CarPrice/2),true)
	end
end

if CLIENT then

end