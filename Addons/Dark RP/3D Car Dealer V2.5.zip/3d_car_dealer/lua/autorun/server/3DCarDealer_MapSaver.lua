hook.Add("Initialize", "3DCarDealer Dir Check", function()
	file.CreateDir("rm_car_dealer")
	file.CreateDir("rm_car_dealer/inventory")
	file.CreateDir("rm_car_dealer/crashsaver")
	file.CreateDir("rm_car_dealer/mapsave")
end)

concommand.Add("D3DCarDealer_Save",function(ply,cmd,args)
	if ply:GetNWString("usergroup") != "superadmin" then return end
		
		MsgN("3DCarDealer - Saving all")
		local TB2Save = {}
		for k,v in pairs(ents.FindByClass("rm_car_dealer")) do
			local TB2Insert = {}
			TB2Insert.Pos = v:GetPos()
			TB2Insert.Angle = v:GetAngles()
			table.insert(TB2Save,TB2Insert)
		end
		
		local Map = string.lower(game.GetMap())
		file.Write("rm_car_dealer/mapsave/" .. Map .. ".txt", util.TableToJSON(TB2Save))
		
		
		D3DCar_Meta:Notify( ply, 1, 3, "Car dealer has been saved")
end)
	
	hook.Add( "InitPostEntity", "3DCarDealer Entity Post", function()
	local Map = string.lower(game.GetMap())
		local Data = {}
		if file.Exists( "rm_car_dealer/mapsave/" .. Map .. ".txt" ,"DATA") then
			Data = util.JSONToTable(file.Read( "rm_car_dealer/mapsave/" .. Map .. ".txt" ))
		end
		MsgN("3DCarDealer - Spawning all")
		for k,v in pairs(Data) do
			local ATM = ents.Create("rm_car_dealer")
			ATM:SetPos(v.Pos)
			ATM:SetAngles(v.Angle)
			ATM:Spawn()
		end
		MsgN("3DCarDealer - Spawning Complete. [ " .. #Data .. " ] ")
	end )