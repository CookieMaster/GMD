D3DCar_Meta = {}

if SERVER then
	function D3DCar_Meta:Notify(ply,a,b,text)
		if D3DCarConfig.DarkRPIs2_5_0 then
			DarkRP.notify( ply, a, b, text)
		else
			GAMEMODE:Notify( ply, a, b, text)
		end
	end
	function D3DCar_Meta:AddMoney(ply,amount)
		if D3DCarConfig.DarkRPIs2_5_0 then
			ply:addMoney(amount)
		else
			ply:AddMoney(amount)
		end
	end
	function D3DCar_Meta:OwnCar(ply,carent)
		if D3DCarConfig.DarkRPIs2_5_0 then
			carent:CPPISetOwner(ply)
			carent:keysOwn(ply)
		else
			carent:Own(ply)
		end
	end
end