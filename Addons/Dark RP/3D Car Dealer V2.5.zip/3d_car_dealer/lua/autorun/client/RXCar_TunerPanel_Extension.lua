timer.Simple(1,function()
	LoadRXTuner()
end)

function LoadRXTuner()
	local ElementsK = {}
	
	local function DuplicateElements(self,UniqueID)
		local MotherData = self.TuneData.Elements[UniqueID]
		if !MotherData then return end
		
		for k,v in pairs(ElementsK) do
			if v.Type == MotherData.Type then
				local NewData = table.Copy(MotherData)
				
				v.Func(self,nil,NewData)
				return
			end
		end
	end
	
	function RXCarPanel_Tuner:AddElem_Car() -- Main
		local TuneData = self.TuneData
		
		local BG = vgui.Create("RXCAR_DSWButton")
		BG:SetSize(100,60)
		BG:SetTexts("Car Main")
		BG.PaintBackGround = function(slf)
			if self.SelectedButton == slf then
				surface.SetDrawColor( Color(0,50,150,100) )
				surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
			end
		end
		
		self.ElementList:AddItem(BG)
		
		BG.Click = function(slf)
			self.SelectedButton = BG
			local List = self.ToolList
			List:Clear()
			
			List:AddSubTitle("Car Main")
			List:AddText("Color Customizer")
			local color = vgui.Create( "DColorMixer");
			color:SetSize( List:GetWide(), 200);
			color:SetColor(Color(255,255,255,255))
			color.ValueChanged = function(slf,color)
				TuneData.Color = color
			end
			color:SetColor(TuneData.Color or Color(255,255,255,255))
			
			List:AddItem(color)
		end
	end

	//====================================================== LED STRIP
	function AddElem_LEDStrip(self,UniqueID,DupeDATA)
		DupeDATA = DupeDATA or {}
		local TuneData = self.TuneData
		local RTuneData = self.TuneData
		TuneData.Elements = TuneData.Elements or {}
		
		if !UniqueID then
			local function GenUniqueID()
				local Num = math.random(100000,999999)
				if TuneData.Elements[Num] then
					return GenUniqueID()
				else
					return Num
				end
			end
			local UID = GenUniqueID()
			local Format = {}
			Format.Type = "LEDStrip"
			
			local Pos1 = Vector(0,0,0) if DupeDATA.Pos1 then Pos1 = Vector(DupeDATA.Pos1.x,DupeDATA.Pos1.y,DupeDATA.Pos1.z) end
			local Pos2 = Vector(0,0,0) if DupeDATA.Pos2 then Pos2 = Vector(DupeDATA.Pos2.x,DupeDATA.Pos2.y,DupeDATA.Pos2.z) end
			local ColorK = Color(255,255,255,255) if DupeDATA.Color then ColorK = Color(DupeDATA.Color.r,DupeDATA.Color.g,DupeDATA.Color.b,DupeDATA.Color.a) end
			
			Format.Pos1 = Pos1
			Format.Pos2 = Pos2
			Format.Color = ColorK
			Format.Width = DupeDATA.Width or 5
			Format.UniqueID = UID
			TuneData.Elements[UID] = Format
			
			UniqueID = UID
		end
		
		TuneData = TuneData.Elements[UniqueID]
		local BG = vgui.Create("RXCAR_DSWButton")
		BG:SetSize(100,60)
		BG:SetTexts("LED Strip")
		BG.PaintBackGround = function(slf)
			if self.SelectedButton == slf then
				surface.SetDrawColor( Color(0,50,150,100) )
				surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
			end
		end
		self.ElementList:AddItem(BG)
		
		BG.OnMousePressed = function(slf,MC)
			if MC == MOUSE_LEFT then
				self.SelectedButton = BG
				local List = self.ToolList
				List:Clear()
				
				List:AddSubTitle("LED Strip")
				List:AddText("Color Customizer")
				local color = vgui.Create( "DColorMixer");
				color:SetSize( List:GetWide(), 200);
				color:SetColor(Color(255,255,255,255))
				color.ValueChanged = function(slf,color)
					TuneData.Color = color
				end
				color:SetColor(TuneData.Color or Color(255,255,255,255))
				List:AddItem(color)
				
				List:AddSubTitle("Width Editor")
				local Slider = List:CreateSlider("Width",1,20,1)
				Slider:SetValue(TuneData.Width)
				Slider.OnValueChanged = function(slf,val)
					TuneData.Width = val
				end
				
				List:AddSubTitle("Position Editor")
				List:AddText("Position 1")
				local Slider = List:CreateSlider("Pos1 - X",-300,300,0)
				Slider:SetValue(TuneData.Pos1.x)
				Slider.OnValueChanged = function(slf,val)
					TuneData.Pos1.x = val
				end
				local Slider = List:CreateSlider("Pos1 - Y",-300,300,0)
				Slider:SetValue(TuneData.Pos1.y)
				Slider.OnValueChanged = function(slf,val)
					TuneData.Pos1.y = val
				end
				local Slider = List:CreateSlider("Pos1 - Z",-300,300,0)
				Slider:SetValue(TuneData.Pos1.z)
				Slider.OnValueChanged = function(slf,val)
					TuneData.Pos1.z = val
				end
				
				List:AddText("Position 2")
				local Slider = List:CreateSlider("Pos2 - X",-300,300,0)
				Slider:SetValue(TuneData.Pos2.x)
				Slider.OnValueChanged = function(slf,val)
					TuneData.Pos2.x = val
				end
				local Slider = List:CreateSlider("Pos2 - Y",-300,300,0)
				Slider:SetValue(TuneData.Pos2.y)
				Slider.OnValueChanged = function(slf,val)
					TuneData.Pos2.y = val
				end
				local Slider = List:CreateSlider("Pos2 - Z",-300,300,0)
				Slider:SetValue(TuneData.Pos2.z)
				Slider.OnValueChanged = function(slf,val)
					TuneData.Pos2.z = val
				end
			end
		
			if MC == MOUSE_RIGHT then
				local menu = DermaMenu()
				menu:AddOption("Duplicate",function()
					DuplicateElements(self,UniqueID)
				end)				
				menu:AddOption("Remove",function()
					RTuneData.Elements[UniqueID] = nil
					BG:Remove()
				end)
				menu:Open()
			end
		
		end
		return UniqueID
	end
	local Regist = {}
	Regist.Name = "LED Strip"
	Regist.Type = "LEDStrip"
	Regist.Func = AddElem_LEDStrip
	table.insert(ElementsK,Regist)
	//====================================================== LED STRIP


	//====================================================== Rear Lamp Light
	function AddElem_RearLight(self,UniqueID,DupeDATA)
		DupeDATA = DupeDATA or {}
		local TuneData = self.TuneData
		local RTuneData = self.TuneData
		TuneData.Elements = TuneData.Elements or {}
		
		if !UniqueID then
			local function GenUniqueID()
				local Num = math.random(100000,999999)
				if TuneData.Elements[Num] then
					return GenUniqueID()
				else
					return Num
				end
			end
			local UID = GenUniqueID()
			local Format = {}
			
			local Pos1 = Vector(0,0,0) if DupeDATA.Pos1 then Pos1 = Vector(DupeDATA.Pos1.x,DupeDATA.Pos1.y,DupeDATA.Pos1.z) end
			local ColorK = Color(255,255,255,255) if DupeDATA.Color then ColorK = Color(DupeDATA.Color.r,DupeDATA.Color.g,DupeDATA.Color.b,DupeDATA.Color.a) end
			
			
			Format.Type = "RearLight"
			Format.Pos1 = Pos1
			Format.Color = ColorK
			Format.Size = DupeDATA.Size or 50
			Format.UniqueID = UID
			TuneData.Elements[UID] = Format
			
			UniqueID = UID
		end
		
		TuneData = TuneData.Elements[UniqueID]
		local BG = vgui.Create("RXCAR_DSWButton")
		BG:SetSize(100,60)
		BG:SetTexts("Rear Light")
		BG.PaintBackGround = function(slf)
			if self.SelectedButton == slf then
				surface.SetDrawColor( Color(0,50,150,100) )
				surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
			end
		end
		self.ElementList:AddItem(BG)
		
		BG.OnMousePressed = function(slf,MC)
			if MC == MOUSE_LEFT then
				self.SelectedButton = BG
				local List = self.ToolList
				List:Clear()
				
				List:AddSubTitle("Rear Light")
				List:AddText("Color Customizer")
				local color = vgui.Create( "DColorMixer");
				color:SetSize( List:GetWide(), 200);
				color:SetColor(Color(255,255,255,255))
				color.ValueChanged = function(slf,color)
					TuneData.Color = color
				end
				color:SetColor(TuneData.Color or Color(255,255,255,255))
				List:AddItem(color)
				
				List:AddSubTitle("Size Editor")
				local Slider = List:CreateSlider("Size",1,150,1)
				Slider:SetValue(TuneData.Size)
				Slider.OnValueChanged = function(slf,val)
					TuneData.Size = val
				end
				
				List:AddSubTitle("Position Editor")
				List:AddText("Position")
				local Slider = List:CreateSlider("Pos1 - X",-300,300,0)
				Slider:SetValue(TuneData.Pos1.x)
				Slider.OnValueChanged = function(slf,val)
					TuneData.Pos1.x = val
				end
				local Slider = List:CreateSlider("Pos1 - Y",-300,300,0)
				Slider:SetValue(TuneData.Pos1.y)
				Slider.OnValueChanged = function(slf,val)
					TuneData.Pos1.y = val
				end
				local Slider = List:CreateSlider("Pos1 - Z",-300,300,0)
				Slider:SetValue(TuneData.Pos1.z)
				Slider.OnValueChanged = function(slf,val)
					TuneData.Pos1.z = val
				end
			end
		
			if MC == MOUSE_RIGHT then
				local menu = DermaMenu()
				menu:AddOption("Duplicate",function()
					DuplicateElements(self,UniqueID)
				end)			
				menu:AddOption("Remove",function()
					RTuneData.Elements[UniqueID] = nil
					BG:Remove()
				end)
				menu:Open()
			end
		
		end
		return UniqueID
	end
	local Regist = {}
	Regist.Name = "Rear Light"
	Regist.Type = "RearLight"
	Regist.Func = AddElem_RearLight
	table.insert(ElementsK,Regist)
	//====================================================== Rear Lamp Light

	
	function RXCarPanel_Tuner:BuildTuner(PackData)
		self.LastPackData = PackData
		self.CurMode = "tuner"
		
		PackData = PackData or self.LastPackData
		-- PackData.Mode == "shoptuner" or "invtuner"
		
		local TuneData = PackData.TuneData
		self.TuneData = TuneData
		
		if self.ShopBGPanel then self.ShopBGPanel:SetVisible(false) end
		if self.FreeCamBGPanel then self.FreeCamBGPanel:SetVisible(false) end
		if self.InventoryBGPanel then self.InventoryBGPanel:SetVisible(false) end
		if self.BuilderBGPanel then self.BuilderBGPanel:Remove() end
		
		self.BuilderBGPanel = vgui.Create("DPanel",self)
		self.BuilderBGPanel:SetSize(self:GetWide(),self:GetTall())
		self.BuilderBGPanel.Paint = function(slf)
		end
		
		self.ElementList = vgui.Create("DPanelList",self.BuilderBGPanel)
		self.ElementList:SetPos(5,5)
		self.ElementList:SetSize(self.BuilderBGPanel:GetWide()-305,120)
		self.ElementList:EnableHorizontal( true )
		self.ElementList:EnableVerticalScrollbar( true )
		self.ElementList:RXCAR_PaintListBarC()
		self.ElementList.Paint = function(slf)
			slf:DrawBoarder()
			surface.SetDrawColor( Color(0,0,20,100) )
			surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		end
		
		self.AddElementList = vgui.Create("DPanelList",self.BuilderBGPanel)
		self.AddElementList:SetPos(5,125)
		self.AddElementList:SetSize(100,self.BuilderBGPanel:GetTall()-130)
		self.AddElementList:EnableHorizontal( false )
		self.AddElementList:EnableVerticalScrollbar( true )
		self.AddElementList:RXCAR_PaintListBarC()
		self.AddElementList.Paint = function(slf)
			slf:DrawBoarder()
			surface.SetDrawColor( Color(0,0,20,100) )
			surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		end
		
		for k,v in pairs(ElementsK) do
			local EB = vgui.Create("RXCAR_DSWButton")
			EB:SetSize(100,50)
			EB:SetTexts(v.Name)
			EB.Click = function(slf)
				v.Func(self)
			end
			self.AddElementList:AddItem(EB)
		end
		
		self.ToolList = vgui.Create("DPanelList",self.BuilderBGPanel)
		self.ToolList:SetPos(self.BuilderBGPanel:GetWide()-300,5)
		self.ToolList:SetSize(295,self.BuilderBGPanel:GetTall()-10)
		self.ToolList:EnableHorizontal( false )
		self.ToolList:EnableVerticalScrollbar( true )
		self.ToolList:RXCAR_PaintListBarC()
		self.ToolList.Paint = function(slf)
			slf:DrawBoarder()
			surface.SetDrawColor( Color(0,0,20,100) )
			surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		end
		
		function self.ToolList:AddSubTitle(text)
			local Wrapp = String_Wrap(text,self:GetWide()-20,"SansationOut_S20")
			local Labels = vgui.Create("DPanel")
				Labels:SetSize(self:GetWide()-20,#Wrapp*20)
				Labels.Paint = function(slf)
					draw.RoundedBox(0, 2, slf:GetTall()-1, slf:GetWide()-4, 1, Color(0,255,255,20))
					for k,v in pairs(Wrapp) do
						draw.SimpleText(v, "SansationOut_S20", 10, -10 + 20*k, Color(0,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					end
				end
			self:AddItem(Labels)
			return Labels
		end
		
		function self.ToolList:AddText(text)
			local Wrapp = String_Wrap(text,self:GetWide()-20,"SansationOut_S15")
			local Labels = vgui.Create("DPanel")
				Labels:SetSize(self:GetWide()-20,#Wrapp*20)
				Labels.Paint = function(slf)
					draw.RoundedBox(0, 2, slf:GetTall()-1, slf:GetWide()-4, 1, Color(255,255,255,100))
					for k,v in pairs(Wrapp) do
						draw.SimpleText(v, "SansationOut_S15", 10, -10 + 20*k, Color(150,150,150,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
					end
				end
				self:AddItem(Labels)
			return Labels
		end
		
		function self.ToolList:CreateSlider(text,min,max,demical)
			local BG = vgui.Create("DPanel")
			BG:SetSize(self:GetWide(),45)
			BG.Paint = function(slf)
					draw.RoundedBox(0, 2, slf:GetTall()-1, slf:GetWide()-4, 1, Color(255,255,255,100))
			end
			
				local Slider = vgui.Create("RXCAR_Sliders",BG) Slider.Mother = BG
					Slider:SetSize(self:GetWide(),35)
					Slider:SetMax(max)
					Slider:SetMin(min)
					
					Slider.Last = min
					Slider:SetName(text)
					Slider:SetUp()
					Slider:SetValue(min)
					Slider:SetDemical(demical)
				self:AddItem(BG)
			return Slider
		end
			
		local Button_FreeCam = vgui.Create("RXCAR_DSWButton",self.BuilderBGPanel)
		Button_FreeCam:SetPos(self.BuilderBGPanel:GetWide()/2 - 100,self.BuilderBGPanel:GetTall()-40)
		Button_FreeCam:SetSize(200,30)
		if PackData.Mode == "invtuner" then
			Button_FreeCam:SetTexts("Goto Inventory")
		else
			Button_FreeCam:SetTexts("Goto Shop")
		end
		Button_FreeCam.Click = function(slf)
			if PackData.Mode == "invtuner" then
				RXCAR_UpdateINVCar(PackData.UniqueID,TuneData)
			end
			self:BuildShop()
		end
		
		self.CamControler = vgui.Create("DPanel",self.BuilderBGPanel)
		self.CamControler:SetPos(1,1)
		self.CamControler:SetSize(1,1)

		self.CamControler.Paint = function(slf)
		end
		self.CamControler.Think = function(slf)
			if !input.IsMouseDown(MOUSE_RIGHT) then 
					local MX,MY = gui.MousePos()
					self.LastMousePos_X = MX
					self.LastMousePos_Y = MY
			return end
			
			local Speed = 1
			
			if input.IsKeyDown(KEY_LSHIFT) then
				Speed = Speed * 2
			end
			if input.IsKeyDown(KEY_W) then
				self.BGBackGroundPanel.CamPos = self.BGBackGroundPanel.CamPos + self.BGBackGroundPanel.CamAngle:Forward() *Speed
			end
			if input.IsKeyDown(KEY_S) then
				self.BGBackGroundPanel.CamPos = self.BGBackGroundPanel.CamPos - self.BGBackGroundPanel.CamAngle:Forward() *Speed
			end
			if input.IsKeyDown(KEY_A) then
				self.BGBackGroundPanel.CamPos = self.BGBackGroundPanel.CamPos - self.BGBackGroundPanel.CamAngle:Right() *Speed
			end
			if input.IsKeyDown(KEY_D) then
				self.BGBackGroundPanel.CamPos = self.BGBackGroundPanel.CamPos + self.BGBackGroundPanel.CamAngle:Right() *Speed
			end
			if input.IsKeyDown(KEY_SPACE) then
				self.BGBackGroundPanel.CamPos = self.BGBackGroundPanel.CamPos + self.BGBackGroundPanel.CamAngle:Up() *Speed
			end

			if input.IsMouseDown(MOUSE_RIGHT) then
				if !slf.LM then
					slf.LM = true
					local MX,MY = gui.MousePos()
					self.LastMousePos_X = MX
					self.LastMousePos_Y = MY
				else
					local CX,CY = gui.MousePos()
					local DX,DY = self.LastMousePos_X-CX,self.LastMousePos_Y-CY
					
					self.BGBackGroundPanel.CamAngle.p = self.BGBackGroundPanel.CamAngle.p - DY/3
					
					if self.BGBackGroundPanel.CamAngle.p > 90 then
						self.BGBackGroundPanel.CamAngle.p = 90
					end
					if self.BGBackGroundPanel.CamAngle.p < -90 then
						self.BGBackGroundPanel.CamAngle.p = -90
					end
					
					
					self.BGBackGroundPanel.CamAngle.y = self.BGBackGroundPanel.CamAngle.y + DX/6
					
					self.LastMousePos_X = CX
					self.LastMousePos_Y = CY
				end
			else
				if slf.LM then
					slf.LM = false
				end
			end
		end
		
		
		self:AddElem_Car()
		
		for k,v in pairs(TuneData.Elements or {}) do
			for _,b in pairs(ElementsK) do
				if v.Type == b.Type then
					b.Func(self,v.UniqueID)
					continue
				end
			end
		end
	end
	
end
