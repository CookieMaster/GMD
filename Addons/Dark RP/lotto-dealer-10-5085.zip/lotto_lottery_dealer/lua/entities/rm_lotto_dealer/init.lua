AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )

function ENT:Initialize()
	self:SetModel( "models/Humans/Group02/male_09.mdl" )
	self:SetHullType( HULL_HUMAN )
	self:SetHullSizeNormal( )
	self:SetNPCState( NPC_STATE_SCRIPT )
	self:SetSolid( SOLID_BBOX )
	self:CapabilitiesAdd( CAP_ANIMATEDFACE )
	self:SetUseType( SIMPLE_USE )
	self:DropToFloor()
 
	self:SetMaxYawSpeed( 180 )
end

function ENT:SpawnFunction( ply, tr )
    if ( !tr.Hit ) then return end
    local ent = ents.Create( "rm_lotto_dealer" )
    ent:SetPos( tr.HitPos + tr.HitNormal * 16 ) 
    ent:Spawn()
    ent:Activate()
 
    return ent
end
function ENT:AcceptInput( Name, Activator, Caller )
	if Name == "Use" and Caller:IsPlayer() then
		Lotto_OpenShop(Caller)
	end
end

----------- DarkRP function
function ENT:PhysgunPickup(ply) -- for DarkRP : Allows Owner can move
	if ply:GetNWString("usergroup") == "owner" or ply:GetNWString("usergroup") == "superadmin" then 
		return true
	else
		return false
	end
end

function ENT:CanTool(ply, trace, mode) -- for DarkRP : Allows Only Owner to remove
	if ply:GetNWString("usergroup") == "owner" or ply:GetNWString("usergroup") == "superadmin" then 
		return true 
	else
		return false
	end
end