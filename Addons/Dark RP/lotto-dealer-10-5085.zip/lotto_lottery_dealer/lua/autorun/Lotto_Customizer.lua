LottoDealerConfig = {}


/* ──────────────────────────────────────────────────────────────────────────────────
	System
────────────────────────────────────────────────────────────────────────────────── */
LottoDealerConfig.GameModeCode = 1
-- 1 : DarkRP 2.4.3 or Lower
-- 2 : DarkRP 2.5.0 or Higher

LottoDealerConfig.DealerSaveableGroup = {"superadmin","owner","admin"} -- <KEEP THESE LOWERCASE> Its ULX Group. these rank can save car dealer position into map
	-- Plus, saving command is ' LottoDealer_Save '


/* ──────────────────────────────────────────────────────────────────────────────────
	LOTTO Setting
────────────────────────────────────────────────────────────────────────────────── */
LottoDealerConfig.LS = {}

LottoDealerConfig.LS.LottoTime = 600 -- 600 second for each round.

LottoDealerConfig.LS.LottoPrice = 100 -- price.

LottoDealerConfig.LS.MaxLottoPerRound = 10 -- player can buy 10 different ( or same ) lotto per 1 round.

LottoDealerConfig.LS.MaxNumberCount = 7 -- player must select 7 different number. if not, player can't buy lotto

LottoDealerConfig.LS.NumberAmount = 45 -- there are 1 ~ 45 numbers player must choose numbers between 1 ~ 45. ( many value makes lotto getting hard to win )

-- PAD Size ( for advanced user )
	LottoDealerConfig.LS.MainPadSize = {150,270} -- do not make pad much bigger. ( or smaller )
	LottoDealerConfig.LS.PadAmountPerAxis = {5,9}

	-- MainPadSize is size of Number pad.
	-- PadAmountPerAxis is amount of Single Key. per Axis ( X , Y )
	
	-- okay. i set MainPadSize to 150,270 and padamount 5,9
	-- 5x9 pad will be created. and each size of pad will be 30,30 ( 150/5 , 270/9 )
	
	
	
/* ──────────────────────────────────────────────────────────────────────────────────
	LOTTO Winning Reward
────────────────────────────────────────────────────────────────────────────────── */

function Lotto_GetWinningReward(SameValueAmount,WinnersAmount)
	if SameValueAmount == 3 then -- 3 same values.
		return 100 -- static reward money. ( 100 )
	end
	
	if SameValueAmount == 4 then -- 4 same values.
		return 1000 -- static reward money. ( 1000 )
	end
	
	if SameValueAmount == 5 then -- 5 same values.
		return 20000/WinnersAmount -- ( static 25000 / winner amount )  if there are 5 winners, winner gets 4000 $ ( 2000 / 5 )
	end
	
	if SameValueAmount == 6 then -- 6 same values.
		return 55000/WinnersAmount -- ( static 55000 / winner amount )  if there are 5 winners, winner gets 11000 $ ( 55000 / 5 )
	end
	
	if SameValueAmount == 7 then -- 7 same values.
		return 300000/WinnersAmount -- ( static 300000 / winner amount )  if there are 5 winners, winner gets 60000 $ ( 300000 / 5 )
	end
end