LottoDealer_Meta = {}

local GMD = LottoDealerConfig.GameModeCode

if SERVER then
	function LottoDealer_Meta:Notify(ply,a,b,text)
		if GMD == 1 then -- 1 for DarkRP
			GAMEMODE:Notify( ply, a, b, text)
		end
		if GMD == 2 then -- 2 for DarkRP2.5.0
			DarkRP.notify( ply, a, b, text)
		end
	end
	function LottoDealer_Meta:AddMoney(ply,amount)
		if GMD == 1 then -- 1 for DarkRP
			ply:AddMoney(amount)
		end
		if GMD == 2 then -- 2 for DarkRP2.5.0
			ply:addMoney(amount)
		end
	end
end

	function LottoDealer_Meta:GetPlayerMoney(ply)
		if GMD == 1 then -- 1 for DarkRP
			return ply:getDarkRPVar("money")
		end
		if GMD == 2 then -- 2 for DarkRP2.5.0
			return ply:getDarkRPVar("money")
		end
	end