function Lotto_GetCurrentRoundTimeLeft()
	local Time = LottoDealerConfig.LS.LottoTime
	local DeltaTime = CurTime() - Lotto_Timer
	local FinalTime = Time - DeltaTime
		FinalTime = math.Round(FinalTime)
		
	return FinalTime
end

	function Lotto_GetCurrentRoundNum()
		local files, directories = file.Find("rm_lotto_dealer/history/*", "DATA")
		local Highest = 0
		for _,FileName in pairs(files) do
			local FileNameNum = string.Left(FileName,string.len(FileName)-4)
			FileNameNum = tonumber(FileNameNum)
			if FileNameNum > Highest then
				Highest = FileNameNum
			end
		end
		
		if Highest == 0 then
			return 1
		else
			local Data = util.JSONToTable(file.Read( "rm_lotto_dealer/history/" .. Highest .. ".txt" ))
			local Amount = table.Count(Data)
			return Amount + Highest-100 +1
		end
			
	end
	
function Lotto_GenNumbers(amount)
	local AT = LottoDealerConfig.LS.NumberAmount
	
	local Set = {}
	
	local function Gen()
		local RV = math.random(1,AT)
		if Set[RV] then
			Gen()
		else
			Set[RV] = true
		end
	end
	
	for k = 1,amount do
		Gen()
	end
	
	return Set
end

function Lotto_FindSameValueAmount(Set1,Set2)
	local Count = 0
	for k,v in pairs(Set1) do
		if Set2[k] then
			Count = Count + 1
		end
	end
	return Count
end

function Lotto_GetRoundFileName(CurRound)
	local function Check(h)
		if CurRound <= h then
			return h
		else
			return Check(h+100)
		end
	end
	return Check(100)
end

function Lotto_EndCurrentRound()
	Lotto_Timer = CurTime()
	
	local ResultNumberSet = Lotto_GenNumbers(LottoDealerConfig.LS.MaxNumberCount)
	
	local RoundData = {}
	RoundData.Round = Lotto_GetCurrentRoundNum()
	RoundData.Winners = {}
	
	for k,v in pairs(player.GetAll()) do
		LottoDealer_Meta:Notify(v,2,2,"Round " .. RoundData.Round .. " LOTTO has been finished!")
	end
	
	MsgN("[LOTTO] Round ," .. RoundData.Round .. " Finished")
	
	local files, directories = file.Find("rm_lotto_dealer/inventory/*", "DATA")
	
	local LottosAllCount = 0
	
	for _,FileName in pairs(files) do
		local Data = util.JSONToTable(file.Read( "rm_lotto_dealer/inventory/" .. FileName ))
		for k,v in pairs(Data) do
			if v.RoundNumber == RoundData.Round then
				LottosAllCount = LottosAllCount + 1
				
				-- win
				local SameV = Lotto_FindSameValueAmount(table.Copy(ResultNumberSet),v.LottoNumber)
				v.SameAmount = SameV
				v.ResultNumberSet = table.Copy(ResultNumberSet)
				if Lotto_GetWinningReward(SameV,1) then
					RoundData.Winners[SameV] = RoundData.Winners[SameV] or 0
					RoundData.Winners[SameV] = RoundData.Winners[SameV] + 1
					
					v.Win = SameV
				end
			end
		end
		file.Write("rm_lotto_dealer/inventory/" .. FileName, util.TableToJSON(Data));
	end
	
	RoundData.LottosAllCount = LottosAllCount
	
	local FileName = Lotto_GetRoundFileName(RoundData.Round)
	
	local Data = {}
	if file.Exists( "rm_lotto_dealer/history/" .. FileName .. ".txt" ,"DATA") then
		Data = util.JSONToTable(file.Read( "rm_lotto_dealer/history/" .. FileName .. ".txt" ))
	end
	
	Data[RoundData.Round] = RoundData
	file.Write("rm_lotto_dealer/history/" .. FileName .. ".txt", util.TableToJSON(Data));
end

hook.Add("Think","LottoSystem - THINK",function()
	Lotto_Timer = Lotto_Timer or CurTime()
	
	local TimeLeft = Lotto_GetCurrentRoundTimeLeft()
	if TimeLeft <= 0 then
		Lotto_EndCurrentRound()
	end
end)

