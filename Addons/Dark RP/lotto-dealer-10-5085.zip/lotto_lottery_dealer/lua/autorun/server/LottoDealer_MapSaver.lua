hook.Add("Initialize", "Lotto Dealer Dir Check", function()
	file.CreateDir("rm_lotto_dealer")
	file.CreateDir("rm_lotto_dealer/inventory")
	file.CreateDir("rm_lotto_dealer/history")
	file.CreateDir("rm_lotto_dealer/mapsave")
end)

concommand.Add("LottoDealer_Save",function(ply,cmd,args)

	local UG = ply:GetNWString("usergroup")
	UG = string.lower(UG)
	if !table.HasValue(LottoDealerConfig.DealerSaveableGroup,UG) then return end
		
		MsgN("Lotto Dealer - Saving all")
		local TB2Save = {}
		for k,v in pairs(ents.FindByClass("rm_lotto_dealer")) do
			local TB2Insert = {}
			TB2Insert.Pos = v:GetPos()
			TB2Insert.Angle = v:GetAngles()
			table.insert(TB2Save,TB2Insert)
		end
		
		local Map = string.lower(game.GetMap())
		file.Write("rm_lotto_dealer/mapsave/" .. Map .. ".txt", util.TableToJSON(TB2Save))
		
		
		LottoDealer_Meta:Notify( ply, 1, 3, "Lotto dealer has been saved")
end)
	
	hook.Add( "InitPostEntity", "3SpawnDealer - LOTTO", function()
	local Map = string.lower(game.GetMap())
		local Data = {}
		if file.Exists( "rm_lotto_dealer/mapsave/" .. Map .. ".txt" ,"DATA") then
			Data = util.JSONToTable(file.Read( "rm_lotto_dealer/mapsave/" .. Map .. ".txt" ))
		end
		MsgN("Lotto Dealer - Spawning all")
		for k,v in pairs(Data) do
			local ATM = ents.Create("rm_lotto_dealer")
			ATM:SetPos(v.Pos)
			ATM:SetAngles(v.Angle)
			ATM:Spawn()
		end
		MsgN("Lotto Dealer - Spawning Complete. [ " .. #Data .. " ] ")
	end )