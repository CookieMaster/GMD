local PLAYER = FindMetaTable("Player");

	function Lotto_GetMyInventoryCount(ply)
		local SteamIDG = string.gsub(ply:SteamID(),":","_")
		if file.Exists( "rm_lotto_dealer/inventory/" .. SteamIDG .. ".txt" ,"DATA") then
			local Data = util.JSONToTable(file.Read( "rm_lotto_dealer/inventory/" .. SteamIDG .. ".txt" ))
			return #Data or 0
		else
			return 0
		end
	end

function PLAYER:PurchaseLotto(RoundNumber,LottoNumber)
	if LottoDealerConfig.LS.LottoPrice > LottoDealer_Meta:GetPlayerMoney(self) then
		ply:SendLottoDealerNotify("SV Error : Not Enough Money")
		return
	end
	
	LottoDealer_Meta:AddMoney(self,-LottoDealerConfig.LS.LottoPrice)
	
	Lotto_GiveLotto2PlayerInventory(self,RoundNumber,LottoNumber)
	
	self:SendLottoDealerSystemFeedBack("Reload_Purchase")
	
	timer.Simple(0.1,function()
		self:SendLottoDealerNotify("You purchased Lotto. good luck!")
	end)
	
end

function Lotto_GiveLotto2PlayerInventory(ply,RoundNumber,LottoNumber)
	local SteamIDG = string.gsub(ply:SteamID(),":","_")
		
	local Data = {}
	if file.Exists( "rm_lotto_dealer/inventory/" .. SteamIDG .. ".txt" ,"DATA") then
		Data = util.JSONToTable(file.Read( "rm_lotto_dealer/inventory/" .. SteamIDG .. ".txt" ))
	end
	
		
	
		local DB2Write = { UniqueID = math.random(10000000,99999999),RoundNumber=RoundNumber,LottoNumber=LottoNumber }
		
	table.insert(Data, DB2Write)
	file.Write("rm_lotto_dealer/inventory/" .. SteamIDG .. ".txt", util.TableToJSON(Data));
end

function Lotto_RemoveLotto2PlayerInventory(ply,UID)
	local SteamIDG = string.gsub(ply:SteamID(),":","_")
		
	local Data = {}
	if file.Exists( "rm_lotto_dealer/inventory/" .. SteamIDG .. ".txt" ,"DATA") then
		Data = util.JSONToTable(file.Read( "rm_lotto_dealer/inventory/" .. SteamIDG .. ".txt" ))
	end
	
		for k,v in pairs(Data) do
			if v.UniqueID == UID then
				Data[k] = nil
			end
		end
	file.Write("rm_lotto_dealer/inventory/" .. SteamIDG .. ".txt", util.TableToJSON(Data));
end

