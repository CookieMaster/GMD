local PLAYER = FindMetaTable("Player");


if CLIENT then
	net.Receive( "LOTTO_OpenShop_S2C", function( len,ply )
		local DATA = net.ReadTable()
		Lotto_OpenShopC()
	end)
	net.Receive( "LOTTO_Notify_S2C", function( len,ply )
		local DATA = net.ReadTable()
		if LottoShopPanel and LottoShopPanel:IsValid() then
			LottoShopPanel:Notify(DATA.T)
		end
	end)
	
	net.Receive( "LOTTO_SystemFeedBack_S2C", function( len,ply )
		local DATA = net.ReadTable()
		if LottoShopPanel and LottoShopPanel:IsValid() then
			LottoShopPanel:SystemFeedBack(DATA.M,DATA.AG)
		end
	end)
	
	
	
	function Lotto_RequestMyLottoData()
		net.Start( "LOTTO_RQMyLottoData_C2S" )
		net.SendToServer()
	end
	
	net.Receive( "LOTTO_RQMyLottoData_S2C", function( len,ply )
		local DATA = net.ReadTable()
		if LottoShopPanel and LottoShopPanel:IsValid() and LottoShopPanel.Canvas and LottoShopPanel.Canvas.Mode == "Purchase" then
			LottoShopPanel.Canvas:VerifyMyLottoData(DATA)
		end
	end)
	

	
	function Lotto_RequestMyInventoryData()
		net.Start( "LOTTO_RQMyInventoryData_C2S" )
		net.SendToServer()
	end

	net.Receive( "LOTTO_RQMyInventoryData_S2C", function( len,ply )
		local DATA = net.ReadTable()
		if LottoShopPanel and LottoShopPanel:IsValid() and LottoShopPanel.Canvas and LottoShopPanel.Canvas.Mode == "Inventory" then
			LottoShopPanel.Canvas:UpdateMyInventory(DATA)
		end
	end)	
	
	function Lotto_PurchaseC(LottoData)
		net.Start( "LOTTO_Purchase_C2S" )
			net.WriteTable(LottoData)
		net.SendToServer()
	end
end

if SERVER then
	util.AddNetworkString( "LOTTO_OpenShop_S2C" )
	util.AddNetworkString( "LOTTO_Notify_S2C" )
	util.AddNetworkString( "LOTTO_SystemFeedBack_S2C" )
	util.AddNetworkString( "LOTTO_Purchase_C2S" )
	
	util.AddNetworkString( "LOTTO_CheckLotto_C2S" )
	
	util.AddNetworkString( "LOTTO_RQMyLottoData_C2S" )
	util.AddNetworkString( "LOTTO_RQMyLottoData_S2C" )
	
	util.AddNetworkString( "LOTTO_RQMyInventoryData_C2S" )
	util.AddNetworkString( "LOTTO_RQMyInventoryData_S2C" )
	
	net.Receive( "LOTTO_RQMyLottoData_C2S", function( len,ply )
		local TB2Send = {}
		TB2Send.CurrentRound = Lotto_GetCurrentRoundNum()
		TB2Send.MyLottoAmount = Lotto_GetMyInventoryCount(ply)
		TB2Send.TimeLeft = Lotto_GetCurrentRoundTimeLeft()
		
		net.Start( "LOTTO_RQMyLottoData_S2C" )
			net.WriteTable(TB2Send)
		net.Send(ply)
	end)
	
	
	net.Receive( "LOTTO_CheckLotto_C2S", function( len,ply )
		local DATA = net.ReadTable()
		local UID = DATA.UniqueID
		local RoundNumber = DATA.RoundNumber
		if RoundNumber == Lotto_GetCurrentRoundNum() then -- 진행중임

		else -- 라운드 종료
			if DATA.Win then -- 승리시 상금 지급
				local RoundFile = Lotto_GetRoundFileName(RoundNumber)
				
				local Data = {}
				if file.Exists( "rm_lotto_dealer/history/" .. RoundFile .. ".txt" ,"DATA") then
					Data = util.JSONToTable(file.Read( "rm_lotto_dealer/history/" .. RoundFile .. ".txt" ))
					if Data[RoundNumber] then
						local RoundData = Data[RoundNumber]
						local Winners = RoundData.Winners[DATA.Win]
						
						local Reward = Lotto_GetWinningReward(DATA.Win,Winners)
					
						LottoDealer_Meta:AddMoney(ply,Reward)
						local ARGS = {}
						ARGS.RoundData = RoundData
						ARGS.Winners = Winners
						ARGS.Reward = Reward
						ARGS.SameAmount = DATA.Win
						
						ply:SendLottoDealerSystemFeedBack("WinRewardResultPanel",ARGS)
					end
				end
			end
			Lotto_RemoveLotto2PlayerInventory(ply,UID)
			ply:SendLottoDealerSystemFeedBack("RemoveLottoFromINV",{UID=UID})
		end
	end)
	
	net.Receive( "LOTTO_RQMyInventoryData_C2S", function( len,ply )
		local SteamIDG = string.gsub(ply:SteamID(),":","_")
		local Data = {}
		if file.Exists( "rm_lotto_dealer/inventory/" .. SteamIDG .. ".txt" ,"DATA") then
			Data = util.JSONToTable(file.Read( "rm_lotto_dealer/inventory/" .. SteamIDG .. ".txt" ))
		end
	
		net.Start( "LOTTO_RQMyInventoryData_S2C" )
			net.WriteTable(Data)
		net.Send(ply)
	end)

	
	
	net.Receive( "LOTTO_Purchase_C2S", function( len,ply )
		local DATA = net.ReadTable()
			local RoundNumber = DATA.Round
			local LottoNumber = DATA.LottoNumber
			
			if RoundNumber < Lotto_GetCurrentRoundNum() then
				ply:SendLottoDealerNotify("Sorry. that round is already over.")
				return
			end
			
			ply:PurchaseLotto(RoundNumber,LottoNumber)
	end)
	
	function Lotto_OpenShop(ply)
		net.Start( "LOTTO_OpenShop_S2C" )
		net.Send(ply)
	end
	
	function PLAYER:SendLottoDealerNotify(text)
		net.Start( "LOTTO_Notify_S2C" )
			net.WriteTable({T=text})
		net.Send(self)
	end
	function PLAYER:SendLottoDealerSystemFeedBack(mode,args)
		net.Start( "LOTTO_SystemFeedBack_S2C" )
			net.WriteTable({M=mode,AG=args})
		net.Send(self)
	end
	
end


if CLIENT then

	function Lotto_CloseShopC()
		if LottoShopPanel and LottoShopPanel:IsValid() then
			LottoShopPanel:Remove()
		end
	end

	function Lotto_OpenShopC()
		Lotto_CloseShopC()
		
		LottoShopPanel = vgui.Create("LottopShopVGUI")
		LottoShopPanel:SetSize(math.max(ScrW()*0.6,850),math.max(ScrH()*0.6,500))
		LottoShopPanel:Center()
		LottoShopPanel:Install()
		LottoShopPanel:MakePopup()
			
		return LottoShopPanel
	end
end




if CLIENT then

	local PANEL = {}
	function PANEL:Init()
		self:ShowCloseButton(false)
		self:SetTitle(" ")
		self:SetDraggable(false)
	end
	function PANEL:Paint()
		surface.SetDrawColor( Color(0,150,255,255) )
		surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
		surface.SetDrawColor( Color(0,0,0,255) )
		surface.DrawRect( 2, 2, self:GetWide()-4, self:GetTall()-4 )
	end
	function PANEL:SystemFeedBack(mode,args)
		if mode == "Reload_Purchase" then
			self:BuildPurchaseMenu()
		end
		if mode == "RemoveLottoFromINV" then
			if self.Canvas and self.Canvas:IsValid() and self.Canvas.Mode == "Inventory" then
				self.Canvas:RemoveLottoItem(args.UID)
			end
		end
		if mode == "WinRewardResultPanel" then
		
			local RoundData = args.RoundData
			local Winners = args.Winners
			local Reward = args.Reward
			local SameAmount = args.SameAmount
		
			local NotifyP = vgui.Create("DPanel",self)
			NotifyP:SetSize(self:GetSize())
			NotifyP:Center()
			NotifyP.Paint = function(slf)
				surface.SetDrawColor( Color(0,0,0,250) )
				surface.DrawRect( 2, 2, slf:GetWide()-4, slf:GetTall()-4 )
				
				surface.SetDrawColor( Color(0,255,255,255) )
				surface.DrawRect( 20, 60, slf:GetWide()-40, 2 )
				draw.SimpleText("LOTTO REWARD", "RXF2_TrebOut_S40", slf:GetWide()/2,40, Color(0,255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
				draw.SimpleText("Congratulations! you won the lotto! you got price!", "RXF2_TrebOut_S27", slf:GetWide()/2,75, Color(0,255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
				
				draw.SimpleText(SameAmount .. " Same Numbers", "RXF2_TrebOut_S30", 50,125, Color(0,255,255,255))
				draw.SimpleText("$" .. Lotto_GetWinningReward(SameAmount,1) .. " max", "RXF2_TrebOut_S30", slf:GetWide()-50,125, Color(0,255,255,255),TEXT_ALIGN_RIGHT)
				surface.SetDrawColor( Color(0,255,255,100) )
				surface.DrawRect( 50, 155, slf:GetWide()-100, 1 )
				
				
				draw.SimpleText(Winners .. " Winners", "RXF2_TrebOut_S30", 50,185, Color(0,255,255,255))
				draw.SimpleText("$" .. Reward .. " per person", "RXF2_TrebOut_S30", slf:GetWide()-50,185, Color(0,255,255,255),TEXT_ALIGN_RIGHT)
				surface.SetDrawColor( Color(0,255,255,100) )
				surface.DrawRect( 50, 215, slf:GetWide()-100, 1 )
				
				draw.SimpleText("You got $ " .. Reward, "RXF2_TrebOut_S40", slf:GetWide()/2,slf:GetTall()-100, Color(0,255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
			end
			
			local BTT = vgui.Create("LOTTO_DSWButton",NotifyP)
			BTT:SetTexts("Cheers!")
			BTT:SetSize(150,40)
			BTT:SetPos(NotifyP:GetWide()/2-BTT:GetWide()/2,NotifyP:GetTall()-30-BTT:GetTall())
			BTT.Click = function(slf)
				NotifyP:Remove()
			end
		end
	end
	function PANEL:Notify(text)
		local NotifyP = vgui.Create("DPanel",self)
		NotifyP:SetSize(self:GetSize())
		NotifyP:Center()
		NotifyP.Paint = function(slf)
			surface.SetDrawColor( Color(0,0,0,240) )
			surface.DrawRect( 2, 2, slf:GetWide()-4, slf:GetTall()-4 )
			draw.SimpleText(text, "RXF2_TrebOut_S40", slf:GetWide()/2,slf:GetTall()/2, Color(0,200,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
		end
		
		local BTT = vgui.Create("LOTTO_DSWButton",NotifyP)
		BTT:SetTexts("Okay")
		BTT:SetSize(100,30)
		BTT:SetPos(NotifyP:GetWide()/2-BTT:GetWide()/2,NotifyP:GetTall()-30-BTT:GetTall())
		BTT.Click = function(slf)
			NotifyP:Remove()
		end
		
	end
	function PANEL:Install()
	
		self.TopPanel = vgui.Create("DPanel",self)
		self.TopPanel:SetPos(2,2)
		self.TopPanel:SetSize(self:GetWide()-4,48)
		self.TopPanel.Paint = function(slf)
			surface.SetDrawColor( Color(0,150,255,255) )
			surface.DrawRect( 0, slf:GetTall()-2, slf:GetWide(), 2 )
			
			draw.SimpleText("LOTTO Dealer", "RXF2_Treb_S40", 20,5, Color(0,200,255,255))
		end
		
		self.Canvas = vgui.Create("DPanel",self)
		self.Canvas:SetPos(2,50)
		self.Canvas:SetSize(self:GetWide()-4,self:GetTall()-52)
		self.Canvas.Paint = function(slf) end
		
		local CloseButton = vgui.Create("LOTTO_DSWButton",self.TopPanel)
		CloseButton:SetTexts("Close")
		CloseButton:SetPos(self.TopPanel:GetWide()-120,0)
		CloseButton:SetSize(120,self.TopPanel:GetTall()-2)
		CloseButton.BoarderCol = Color(0,0,0,0)
		CloseButton.Click = function(slf)
			Lotto_CloseShopC()
		--	Lotto_OpenShopC()
		end
		
		local BTT = vgui.Create("LOTTO_DSWButton",self.TopPanel)
		BTT:SetTexts("Purchase")
		BTT:SetPos(self.TopPanel:GetWide()-220,0)
		BTT:SetSize(100,self.TopPanel:GetTall()-2)
		BTT.BoarderCol = Color(0,0,0,0)
		BTT.Click = function(slf)
			self:BuildPurchaseMenu()
		end
		
		local BTT = vgui.Create("LOTTO_DSWButton",self.TopPanel)
		BTT:SetTexts("Inventory")
		BTT:SetPos(self.TopPanel:GetWide()-320,0)
		BTT:SetSize(100,self.TopPanel:GetTall()-2)
		BTT.BoarderCol = Color(0,0,0,0)
		BTT.Click = function(slf)
			self:BuildInventory()
		end
		self:BuildPurchaseMenu()
	end
	function PANEL:ReBulidCanvas()
		local NewPanel = vgui.Create("DPanel",self)
		NewPanel:SetPos(self.Canvas:GetPos())
		NewPanel:SetSize(self.Canvas:GetSize())
		self.Canvas:Remove()
		self.Canvas = NewPanel
		self.Canvas.Paint = function(slf) end
	end
	
	function PANEL:BuildInventory()
		self:ReBulidCanvas()
		local Canvas = self.Canvas
		self.Canvas.Mode = "Inventory"
		self.Canvas.VerifiedLottos = {}
		self.Canvas.CreatedTime = CurTime()
		
		local INVLister = vgui.Create("DPanelList",Canvas)
		INVLister:SetPos(0,0)
		INVLister:SetSize(Canvas:GetWide(),Canvas:GetTall())
		INVLister:EnableHorizontal( false )
		INVLister:EnableVerticalScrollbar( true )
		INVLister:Lotto_PaintListBarC()
		
		function Canvas:RemoveLottoItem(UID)
			for k,v in pairs(INVLister:GetItems()) do
				if v.UID == UID then
					v:Remove()
				end
			end
		end
		
		function Canvas:UpdateMyInventory(DATA)
			INVLister:Clear()
			
			
			table.SortByMember(DATA, "RoundNumber", function(a, b) return a > b end)
			
			for _,DB in pairs(DATA) do
				local BG = vgui.Create("DPanel")
				BG.UID = DB.UniqueID
				BG:SetSize(INVLister:GetWide(),100)
				BG.Paint = function(slf)
					surface.SetDrawColor( Color(0,150,255,100) )
					surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
					
					local Count = 0
					for Num,_ in pairs(DB.LottoNumber or {}) do
						Count = Count + 1
						draw.SimpleText("Lotto >>", "RXF2_Treb_S30", 20,5, Color(200,200,255,255))
						
						if DB.ResultNumberSet and DB.ResultNumberSet[Num] then
							draw.SimpleText(Num, "RXF2_Treb_S30", 110+Count*35,5, Color(0,255,0,255))
						else
							draw.SimpleText(Num, "RXF2_Treb_S30", 110+Count*35,5, Color(0,200,255,255))
						end
						draw.SimpleText("Unique ID : " .. DB.UniqueID, "RXF2_Treb_S25", 50,35, Color(0,200,200,255))
						draw.SimpleText("Round : " .. DB.RoundNumber, "RXF2_Treb_S25", 270,35, Color(0,200,200,255))
						
						if DB.SameAmount then
							if DB.Win then
								draw.SimpleText("Win", "RXF2_Treb_S40", slf:GetWide()-20,8, Color(0,255,0,255),TEXT_ALIGN_RIGHT)
							else
								draw.SimpleText("Lose", "RXF2_Treb_S40", slf:GetWide()-20,8, Color(255,0,0,255),TEXT_ALIGN_RIGHT)
							end
						else
							draw.SimpleText("Pending", "RXF2_Treb_S40", slf:GetWide()-20,8, Color(0,200,255,255),TEXT_ALIGN_RIGHT)
						end
						
						draw.SimpleText("Result >> ", "RXF2_Treb_S30", 20,70, Color(200,200,255,255))
						
						if DB.SameAmount then
							draw.SimpleText(DB.SameAmount .. " Same", "RXF2_Treb_S30", 150,70, Color(0,200,255,255))
						end
						if DB.ResultNumberSet then
							local RST = ""
							for a,b in pairs(DB.ResultNumberSet) do
								RST = RST .. a .. " "
							end
							draw.SimpleText("< " .. RST .. " > ", "RXF2_Treb_S30", 270,70, Color(255,200,100,255))
						end
					end
					
				end
				
				if DB.SameAmount then
						
					local Check = vgui.Create("LOTTO_DSWButton",BG)
						Check:SetPos(BG:GetWide()-170,BG:GetTall()-30)
						Check:SetSize(160,28)
						if DB.Win then
							Check:SetTexts("Get Reward")
						else
							Check:SetTexts("Throw into trashbin")
						end
						
						Check.Click = function(slf)
							net.Start( "LOTTO_CheckLotto_C2S" )
								net.WriteTable(DB)
							net.SendToServer()
						end
						
				end
						
				INVLister:AddItem(BG)
			end
		end
		
		
		Lotto_RequestMyInventoryData()
	end
	
	function PANEL:BuildPurchaseMenu()
		self:ReBulidCanvas()
		local Canvas = self.Canvas
		self.Canvas.Mode = "Purchase"
		self.Canvas.LottoData = {}
		self.Canvas.CreatedTime = CurTime()
		
		function Canvas:VerifyMyLottoData(DATA)
			local CurRound = DATA.CurrentRound
			local MyLottoAmount = DATA.MyLottoAmount
			self.LottoData.Round = CurRound
			self.MyLottoAmount = MyLottoAmount
			self.TimeLeft = DATA.TimeLeft
		end
		
		local Main = vgui.Create("DPanel",Canvas)
		Main:SetPos(0,0)
		Main:SetSize(Canvas:GetWide(),Canvas:GetTall())
		Main.Paint = function(slf) 
			
		end
		
			local GenPAD = vgui.Create("LottoNumberPad",Main)
			GenPAD:SetSize(LottoDealerConfig.LS.MainPadSize[1],LottoDealerConfig.LS.MainPadSize[2])
			GenPAD:SetPos(25,Main:GetTall()/2-GenPAD:GetTall()/2)
			GenPAD:Install()
			
			local BuyLister = vgui.Create("DPanelList",Main)
			BuyLister:SetPos(50+GenPAD:GetWide(),20)
			BuyLister:SetSize(Main:GetWide()-(50+GenPAD:GetWide())-20,Main:GetTall()-40)
			BuyLister:EnableHorizontal( false )
			BuyLister:EnableVerticalScrollbar( true )
			BuyLister:Lotto_PaintListBarC()
			
			local BuyPanelBG = vgui.Create("DPanel")
			BuyPanelBG:SetSize(BuyLister:GetWide(),350)
			BuyPanelBG.Paint = function(slf)
				surface.SetDrawColor( Color(0,150,255,255) )
				surface.DrawRect( 0, slf:GetTall()-2, slf:GetWide(), 2 )
				surface.DrawRect( 0, 0, slf:GetWide(), 2 )
				draw.SimpleText("Purchase Lottto", "RXF2_Treb_S30", slf:GetWide()/2,10, Color(0,200,255,255),TEXT_ALIGN_CENTER)
				
				local TimeLeft = Canvas.TimeLeft or 0
					TimeLeft = TimeLeft - (CurTime() - Canvas.CreatedTime)
					TimeLeft = math.Round(TimeLeft)
					TimeLeft = math.max(TimeLeft,0)
					
				local STR = math.floor(TimeLeft/3600) .. " hr " .. math.floor(TimeLeft/60) .. " m " .. (TimeLeft%60) .. " s"
				
				if TimeLeft > 0 then
					draw.SimpleText("TimeLeft : " .. STR, "RXF2_Treb_S25", slf:GetWide() - 20,50, Color(0,255,0,255),TEXT_ALIGN_RIGHT)
				else
					draw.SimpleText("TimeLeft : " .. STR, "RXF2_Treb_S25", slf:GetWide() - 20,50, Color(255,0,0,255),TEXT_ALIGN_RIGHT)
				end
				
				draw.SimpleText("Number : ", "RXF2_Treb_S30", 10,80, Color(0,200,255,255))
				draw.SimpleText("Lotto Price : $" .. string.Comma(LottoDealerConfig.LS.LottoPrice), "RXF2_Treb_S25", 10,150, Color(0,200,255,255))
				draw.SimpleText("My Wallet : $" .. string.Comma(LottoDealer_Meta:GetPlayerMoney(LocalPlayer())), "RXF2_Treb_S25", 10,180, Color(0,200,255,255))
				
				draw.SimpleText("Current Round : " .. (self.Canvas.LottoData.Round or " No Data " ), "RXF2_Treb_S25", 10,240, Color(0,200,255,255))
				draw.SimpleText("My Lotto Amount : " .. ((self.Canvas.MyLottoAmount or " No Data ") .. " / " .. LottoDealerConfig.LS.MaxLottoPerRound), "RXF2_Treb_S25", 10,270, Color(0,200,255,255))
				
				
				
				for k = 1,LottoDealerConfig.LS.MaxNumberCount do
					surface.SetDrawColor( Color(0,150,255,255) )
					surface.DrawRect( k*40+90, 115, 30, 2 )
				end
			
				local Count = 0
				for Num,_ in pairs(GenPAD.SelectedNum or {}) do
					Count = Count + 1
					draw.SimpleText(Num, "RXF2_Treb_S30", Count*40+105,110, Color(0,255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_TOP)
				end
			end -- paint end
			BuyLister:AddItem(BuyPanelBG)
			
				local GEN_RANDOM = vgui.Create("LOTTO_DSWButton",BuyPanelBG)
				GEN_RANDOM:SetTexts("Generate Number")
				GEN_RANDOM:SetPos(BuyPanelBG:GetWide()-300,BuyPanelBG:GetTall()-40)
				GEN_RANDOM:SetSize(180,38)
				GEN_RANDOM.BoarderCol = Color(0,0,0,0)
				GEN_RANDOM.Click = function(slf)
					local function Lotto_GenNumbers(amount)
						GenPAD.SelectedNum = {}
						local AT = LottoDealerConfig.LS.NumberAmount
						
						local function Gen()
							local RV = math.random(1,AT)
							if GenPAD.SelectedNum[RV] then
								Gen()
							else
								GenPAD.SelectedNum[RV] = true
							end
						end
						
						for k = 1,amount do
							Gen()
						end
					end
					Lotto_GenNumbers(LottoDealerConfig.LS.MaxNumberCount)
				end
				
				local PURCHASE = vgui.Create("LOTTO_DSWButton",BuyPanelBG)
				PURCHASE:SetTexts("Purchase")
				PURCHASE:SetPos(BuyPanelBG:GetWide()-120,BuyPanelBG:GetTall()-40)
				PURCHASE:SetSize(120,38)
				PURCHASE.BoarderCol = Color(0,0,0,0)
				PURCHASE.Click = function(slf)
					if table.Count(GenPAD.SelectedNum or {}) < LottoDealerConfig.LS.MaxNumberCount then
						self:Notify("Select " .. LottoDealerConfig.LS.MaxNumberCount .. " Number!")
						return
					end
					if !self.Canvas.LottoData.Round then
						self:Notify("ERROR. No Round Data")
						return
					end
					if !self.Canvas.MyLottoAmount then
						self:Notify("ERROR. No MyLottoAmount Data")
						return
					end
					if LottoDealerConfig.LS.LottoPrice > LottoDealer_Meta:GetPlayerMoney(LocalPlayer()) then
						self:Notify("Not Enough money")
						return
					end
					
					if self.Canvas.MyLottoAmount >= LottoDealerConfig.LS.MaxLottoPerRound then
						self:Notify("you have reached lotto limit!")
						return
					end
					
					
					
					local TimeLeft = Canvas.TimeLeft or 0
						TimeLeft = TimeLeft - (CurTime() - Canvas.CreatedTime)
						TimeLeft = math.Round(TimeLeft)
						TimeLeft = math.max(TimeLeft,0)
					
					if TimeLeft == 0 then
						self:Notify("Round is Over. you can't purchase")
						return	
					end
					
					local TB2Send = {}
					TB2Send.LottoNumber = GenPAD.SelectedNum
					TB2Send.Round = self.Canvas.LottoData.Round
					Lotto_PurchaseC(TB2Send)
				end
				
				
			-- Winning Reward?
			local WinReward = vgui.Create("DPanel")
			WinReward:SetSize(BuyLister:GetWide(),30)
			WinReward.Paint = function(slf)
				draw.SimpleText("Win Reward >>", "RXF2_Treb_S30", 10,0, Color(110,100,255,255))
				surface.SetDrawColor( Color(0,150,255,255) )
				surface.DrawRect( 0, slf:GetTall()-2, slf:GetWide(), 2 )
			end
			BuyLister:AddItem(WinReward)
			
			for k = 1,LottoDealerConfig.LS.MaxNumberCount do
				if Lotto_GetWinningReward(k,1) then
					local WinReward = vgui.Create("DPanel")
					WinReward:SetSize(BuyLister:GetWide(),50)
					WinReward.Paint = function(slf)
						draw.SimpleText(k .. " Same Value", "RXF2_Treb_S20", 10,0, Color(100,100,255,255))
						draw.SimpleText("> $" .. string.Comma(Lotto_GetWinningReward(k,1)) .. " max", "RXF2_Treb_S20", 50,20, Color(50,100,255,255))
					end
					BuyLister:AddItem(WinReward)
				end
			end
			
			Lotto_RequestMyLottoData()
	end

	
	
vgui.Register("LottopShopVGUI",PANEL,"DFrame")
end




if CLIENT then
	local PANEL = {}
	
	function PANEL:Install()
		self.SelectedNum = {}
		
		local function CreateButton(num)
			local Button = vgui.Create("DButton",self)
			Button:SetText("")
			Button.Paint = function(slf)
				surface.SetDrawColor( Color(0,0,0,255) )
				surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
				
				surface.SetDrawColor( Color(0,150,255,255) )
				surface.DrawRect( 0, 0, slf:GetWide(), 1 )
				surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
				
				if self.SelectedNum[num] then
					draw.SimpleText(num, "RXF2_Treb_S20", slf:GetWide()/2,slf:GetTall()/2, Color(255,0,0,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
				else
					draw.SimpleText(num, "RXF2_Treb_S20", slf:GetWide()/2,slf:GetTall()/2, Color(255,255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
				end
			end
			Button.DoClick = function(slf)
				if self.SelectedNum[num] then
					self.SelectedNum[num] = nil
					return
				else
					if table.Count(self.SelectedNum) >= LottoDealerConfig.LS.MaxNumberCount then return end
					
					self.SelectedNum[num] = true
				end
			end
			return Button
		end
		
		local XCount = LottoDealerConfig.LS.PadAmountPerAxis[1]
		local YCount = LottoDealerConfig.LS.PadAmountPerAxis[2]
		
		for k=1,LottoDealerConfig.LS.NumberAmount do
			local Button = CreateButton(k)
			Button:SetPos((self:GetWide()/XCount)*((k-1)%XCount),(self:GetTall()/YCount)*math.floor((k-1)/XCount))
			Button:SetSize(self:GetWide()/XCount,self:GetTall()/YCount)
		end
	end
	
	function PANEL:Paint()
	
	end
	
	vgui.Register("LottoNumberPad",PANEL,"DPanel")
end