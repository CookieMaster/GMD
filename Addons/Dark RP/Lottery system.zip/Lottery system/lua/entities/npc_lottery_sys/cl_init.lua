// Made by Tomasas http://steamcommunity.com/id/tomasas/
include('shared.lua')


local BetMenu
local function OpenLotteryMenu(umg)
	if BetMenu and BetMenu:IsValid() then BetMenu:Remove() end

	surface.SetFont("TargetIDSmall")
	local x1, y1 = surface.GetTextSize("Current pot size: ")
	local x2, y2, timestring, nextlottery
	local x3, y3 = surface.GetTextSize("Last lottery winner was ")
	local x4, y4 = surface.GetTextSize("Current ticket cost: ")
	local NextLottery, TicketCost, CurrentPot, LastWinner, LastWinnerCash, CanBuy, TicketNumber = umg:ReadLong(), umg:ReadShort(), umg:ReadLong(), umg:ReadString(), umg:ReadLong(), umg:ReadBool(), umg:ReadShort()

	local BarCode = {}
	if CanBuy then
		math.randomseed(TicketNumber)
		for i=1, 60 do
			if math.random(1, 2) == 2 then
				BarCode[i] = i
			end
		end
		math.randomseed(os.time())
	end

	BetMenu = vgui.Create("DFrame")
	BetMenu:SetSize(700, 325)
	BetMenu:SetTitle("")
	BetMenu:Center()
	BetMenu.Paint = function(self)

		//surface.SetDrawColor(70, 70, 70, 255)
		//surface.DrawRect(0, 0, self:GetWide(), self:GetTall())
		DisableClipping(true)
		draw.RoundedBox(6, -2, -2, self:GetWide()+4, self:GetTall()+4, Color(40, 40, 40, 255))
		DisableClipping(false)
		draw.RoundedBox(6, 0, 0, self:GetWide(), self:GetTall(), Color(50, 50, 50, 255))
		//surface.SetDrawColor(0,0,0,255)
		//surface.DrawOutlinedRect(0, 0, self:GetWide(), self:GetTall())


		draw.SimpleText("Welcome to the Lottery", "TargetID", BetMenu:GetWide()*0.5, 10, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
		draw.SimpleText("Buy a lottery ticket for a chance to win big cash!", "TargetID", BetMenu:GetWide()*0.5, 40, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
		
		draw.SimpleText("Last lottery", "TargetID", BetMenu:GetWide()*0.175, 120, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
		
		draw.SimpleText("Winner:", "TargetIDSmall", BetMenu:GetWide()*0.2-100, 150, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
		draw.SimpleTextOutlined(LastWinner, "TargetIDSmall", BetMenu:GetWide()*0.2-42, 150, Color(240, 125, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0, 0, 0, 255))
		draw.SimpleText("Won: $"..LastWinnerCash, "TargetIDSmall", BetMenu:GetWide()*0.2-100, 170, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
		
		draw.SimpleText("Next lottery in", "TargetID", BetMenu:GetWide()*0.5, 100, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
		nextlottery = string.FormattedTime(NextLottery-os.time())
		timestring = math.abs(math.floor(nextlottery.h)).." Hours "..math.floor((NextLottery-os.time())/60 - math.floor(nextlottery.h)*60).." Minutes "..nextlottery.s.." Seconds"
		x2, y2 = surface.GetTextSize(timestring)
		draw.SimpleText(timestring, "TargetIDSmall", BetMenu:GetWide()*0.5, 122, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
		surface.SetDrawColor(240, 240, 240, 255)
		surface.DrawOutlinedRect(BetMenu:GetWide()*0.5-x2*0.5-3, 120, x2+6, y2+3)
		
		draw.SimpleText("Current pot size: ", "TargetIDSmall", BetMenu:GetWide()*0.5-75, 150, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
		draw.SimpleText("$"..CurrentPot, "TargetIDSmall", BetMenu:GetWide()*0.5+x1-75, 150, Color(255, 255, 0, 255), TEXT_ALIGN_LEFT)
		draw.SimpleText("Current ticket cost: ", "TargetIDSmall", BetMenu:GetWide()*0.5-75, 175, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
		draw.SimpleText("$"..TicketCost, "TargetIDSmall", BetMenu:GetWide()*0.5-75+x4, 175, (LocalPlayer().DarkRPVars.money and (TicketCost > LocalPlayer().DarkRPVars.money)) and Color(235, 0, 0, 255) or Color(0, 235, 0, 255), TEXT_ALIGN_LEFT)
		
		
		draw.SimpleText("Your ticket", "TargetID", BetMenu:GetWide()*0.835, 120, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
		
		if CanBuy then
			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawRect(self:GetWide()*0.7325, 140, self:GetWide()*0.2, 135)
			surface.SetDrawColor(255, 255, 255, 255)
			surface.DrawOutlinedRect(self:GetWide()*0.7325, 140, self:GetWide()*0.2, 135)
			draw.SimpleText("Ticket Number", "TargetIDSmall", self:GetWide()*0.7325+67, 145, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
			draw.SimpleText(TicketNumber, "TargetIDSmall", self:GetWide()*0.7325+67, 160, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
			surface.SetDrawColor(255, 255, 255, 255)
			for i=1, 60 do
				if BarCode[i] then
					//surface.DrawLine(self:GetWide()*0.5-120, 152+i, self:GetWide()*0.5-80, 152+i)
					surface.DrawLine(self:GetWide()*0.7325+i+40, 270, self:GetWide()*0.7325+i+40, 240)
				end
			end
		else
			draw.SimpleText("Buy a ticket first", "TargetIDSmall", BetMenu:GetWide()*0.835, 175, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
		end
		
	end

	BetMenu.Close = function(self)
		RunConsoleCommand("closedlotterymenu")
		BetMenu:Remove()
	end
	BetMenu:ShowCloseButton(false)
	BetMenu:MakePopup()

	local BetButton = vgui.Create("DButton", BetMenu)
	BetButton:SetPos(BetMenu:GetWide()*0.5-60, BetMenu:GetTall()-50)
	BetButton:SetSize(120, 25)
	BetButton:SetText("")
	BetButton:SetDisabled((LocalPlayer().DarkRPVars.money and (TicketCost <= LocalPlayer().DarkRPVars.money)) and true or false)
	BetButton:SetDisabled(CanBuy)
	BetButton.Paint = function(self)
		draw.RoundedBox(4,0,0,self:GetWide(),self:GetTall(),Color(60, 60, 60, 155))
		draw.RoundedBox(4,1,1,self:GetWide()-2,self:GetTall()-2,!self:GetDisabled() and Color(120, 120, 120, 255) or Color(60, 60, 60,155))
		draw.SimpleText("Buy a ticket", "TargetIDSmall", self:GetWide()*0.5, 2.5,!self:GetDisabled() and Color(255, 255, 255, 255) or Color(0, 0, 0, 255), TEXT_ALIGN_CENTER)
	end

	BetButton.DoClick = function(self)
		RunConsoleCommand("buylotteryticket")
		BetMenu:Remove()
	end

	local GUI_Main_Exit = vgui.Create("DButton")
	GUI_Main_Exit:SetParent(BetMenu)
	GUI_Main_Exit:SetSize(16,16)
	GUI_Main_Exit:SetPos(BetMenu:GetWide()-20,5)
	GUI_Main_Exit:SetText("")
	GUI_Main_Exit.Paint = function()
		surface.SetMaterial(Material("icon16/cross.png"))
		surface.SetDrawColor(200,200,0,200)
		surface.DrawTexturedRect(0,0,GUI_Main_Exit:GetWide(),GUI_Main_Exit:GetTall())
	end
	GUI_Main_Exit.DoClick = function()
		BetMenu:Close()
	end

end
//OpenLotteryMenu()
usermessage.Hook("LotteryMenu", OpenLotteryMenu)
//�Tomasas 2013