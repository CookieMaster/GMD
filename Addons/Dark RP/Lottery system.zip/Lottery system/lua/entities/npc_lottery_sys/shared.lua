// Made by Tomasas http://steamcommunity.com/id/tomasas/
ENT.Base = "base_ai" 
ENT.Type = "ai"
ENT.PrintName = "Lottery NPC"
ENT.Author = "Tomasas"
//�Tomasas 2013