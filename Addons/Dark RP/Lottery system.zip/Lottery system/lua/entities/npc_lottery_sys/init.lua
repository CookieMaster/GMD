// Made by Tomasas http://steamcommunity.com/id/tomasas/

	// Run lottery_setpos in console(admin only) to set the sNPC position and angle
local Model = "models/Humans/Group02/male_02.mdl" // This is the model the NPC will be using
local TicketPrice = {950, 1050} // Ticket price, first number is the start of the random number point and the second is the second point
local TicketTime = {86400, 129600} // The time for the next lottery, a random number in SECONDS in between both of the numbers

/*----------------------------------------------------------------------------------------------------------------*/
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include('shared.lua')

/*local LotteryNPC*/
local Position, Angles
function SpawnLotteryNPC()
	if IsValid(LotteryNPC) then LotteryNPC:Remove() end
	LotteryNPC = ents.Create("npc_lottery_sys")
	LotteryNPC:SetModel(Model)
	LotteryNPC:SetPos(Position)
	LotteryNPC:SetAngles(Angle(0, Angles, 0))
	LotteryNPC:Spawn()
	LotteryNPC:SetMoveType(MOVETYPE_NONE)
	LotteryNPC:SetSolid(SOLID_BBOX)
	//LotteryNPC:SetCollisionGroup(COLLISION_GROUP_PLAYER)
	
	
end

local posFile = file.Read("lotteryData/position.txt", "DATA")
if posFile and posFile != "" then
	posFile = string.Explode(";", posFile)
	Position, Angles = Vector(tonumber(posFile[1]), tonumber(posFile[2]), tonumber(posFile[3])), tonumber(posFile[4])
	timer.Simple(1, SpawnLotteryNPC)
end
concommand.Add("lottery_setpos", function(ply)
	if !ply:IsAdmin() then return end
	Position, Angles = ply:GetPos(), ply:GetAngles().y
	file.Write("lotteryData/position.txt", table.concat({Position.x, Position.y, Position.z, Angles}, ";"))
	ply:ChatPrint("MOVE OUT OF THE WAY!")
	timer.Simple(1.75, SpawnLotteryNPC)
end)


//timer.Simple(1, SpawnLotteryNPC)

umsg.PoolString("LotteryMenu")
file.CreateDir("lotteryData")
local PlayersWithOpenMenu = {} 

local LotteryPlayerData = {}
local PlayerMoneyQueue = {}
local NextLotteryTime, TicketCost, LastWinner, LastWinnerCash, CurrentPot = os.time()+math.random(TicketTime[1],TicketTime[2]), math.random(TicketPrice[1], TicketPrice[2]), "No last winner", 0, 5000
if file.Exists("lotteryData/lotteryinfo.txt", "DATA") then // Read info if we have it
	local info = string.Explode(";", file.Read("lotteryData/lotteryinfo.txt", "DATA"))
	NextLotteryTime, LastWinner, LastWinnerCash, CurrentPot = tonumber(info[1]), info[2], tonumber(info[3]), tonumber(info[4])
	info = file.Read("lotteryData/lotteryplayerdata.txt", "DATA")
	if info and info != "" then
		info = string.Explode(";", info)
		for i=1, #info do
			local info2 = string.Explode("&", info[i])
			LotteryPlayerData[info2[1]] = {tonumber(info2[2]), info2[3]} // steamid, ticketid, name
		end
	end
	info = file.Read("lotteryData/playermoneyqueue.txt", "DATA")// read player money queue data
	if info and info != "" then
		info = string.Explode(";", info)
		for i=1, #info do
			local info2 = string.Explode("&", info[i])
			PlayerMoneyQueue[info2[1]] = tonumber(info2[2])
		end
	end
end
local function AddToMoneyQueue(steamid, num)
	PlayerMoneyQueue[steamid] = num
	local tbl = {}
	for k,v in pairs(PlayerMoneyQueue) do
		table.insert(tbl, table.concat({k, v}, "&"))
	end
	file.Write("lotteryData/playermoneyqueue.txt", table.concat(tbl, ";"))
end
local function UpdateData()
	file.Write("lotteryData/lotteryinfo.txt", table.concat({NextLotteryTime, LastWinner, LastWinnerCash, CurrentPot}, ";"))
end
local function UpdatePlayerData()
	local tbl = {}
	for k,v in pairs(LotteryPlayerData) do
		table.insert(tbl, table.concat({k, v[1], v[2]}, "&"))
	end
	file.Write("lotteryData/lotteryplayerdata.txt", table.concat(tbl, ";"))
end
local function escapeStr(str)
	if not DB.CONNECTED_TO_MYSQL then
		return string.gsub(sql.SQLStr(str), '[;&"]?', "")
	end
	return DB.MySQLDB:escape(string.gsub(str, '[;&"]?', ""))
end
local function RefreshAllMenus()
	local TicketNumb, SteamID = 0// refresh other players menus
	for k,v in pairs(PlayersWithOpenMenu) do
		if v:IsValid() then
			if v != ply then
				SteamID, TicketNumb = v:SteamID(), nil
				for a,b in pairs(LotteryPlayerData) do
					if a == SteamID then
						TicketNumb = b[1]
						break
					end
				end
				umsg.Start("LotteryMenu", v)
					umsg.Long(NextLotteryTime)
					umsg.Short(TicketCost)
					umsg.Long(CurrentPot)
					umsg.String(LastWinner)
					umsg.Long(LastWinnerCash)
					umsg.Bool(util.tobool(TicketNumb))
					umsg.Short(TicketNumb)
				umsg.End()
			end
		else
			PlayersWithOpenMenu[k] = nil
		end
	end
end


function NextLottery()
	LastWinnerCash = CurrentPot
	NextLotteryTime, TicketCost, CurrentPot = os.time()+math.random(TicketTime[1], TicketTime[2]), math.random(TicketPrice[1], TicketPrice[2]), 5000
	//UpdateData()
	
	local pnumber = table.Count(LotteryPlayerData)
	if pnumber == 0 then
		NextLotteryTime, TicketCost, LastWinner, LastWinnerCash = os.time()+math.random(TicketTime[1],TicketTime[2]), math.random(TicketPrice[1], TicketPrice[2]), "No last winner", 0
		RefreshAllMenus()
		return
	end
	local Winner, SteamID = math.random(1, pnumber)
	for k,v in pairs(LotteryPlayerData) do
		if v[1] == Winner then
			LastWinner = escapeStr(v[2])
			SteamID = k
			break
		end
	end

	if !SteamID then return end
	
	for k,v in pairs(player.GetAll()) do
		if v:SteamID() == SteamID then
			if v.DarkRPVars then
				v:AddMoney(LastWinnerCash)
				v:ChatPrint("You have received $"..LastWinnerCash.." for winning the lottery!")
			else
				AddToMoneyQueue(SteamID, LastWinnerCash)
			end
			Winner = nil
		else
			v:ChatPrint(LastWinner.." won the lottery, winning $"..LastWinnerCash.."!")
		end
	end
	if Winner then
		AddToMoneyQueue(SteamID, LastWinnerCash)
	end

	UpdateData()
	LotteryPlayerData = {} //clear player data
	UpdatePlayerData()
	RefreshAllMenus()
	AddToMoneyQueue(0, nil) //create money queue file if it's not there

end

local nextMoneyQueueCheck = 0
hook.Add("Think", "LotteryLogic", function()
	if NextLotteryTime <= os.time() then
		NextLottery()
	end
	if nextMoneyQueueCheck < CurTime() then // take care of money queue
		nextMoneyQueueCheck = CurTime() + 1
		local tbl, needSave = player.GetAll()
		for k,v in pairs(PlayerMoneyQueue) do
			for i=1, #tbl do
				if tbl[i]:SteamID() == k and tbl[i].DarkRPVars and tbl[i].DarkRPVars.money then
					tbl[i]:AddMoney(v)
					tbl[i]:ChatPrint("You have received $"..v.." for winning the lottery!")
					PlayerMoneyQueue[k] = nil
					needSave = true
					break
				end
			end
		end
		if needSave then
			AddToMoneyQueue(0, nil) //slightly hacky but alright
		end
	end
end)
	
function BuyTicket(ply)
	if LotteryNPC:GetPos():Distance(ply:GetPos()) > 185 then return end
	local SteamID, TicketNumb = ply:SteamID()

	for k,v in pairs(LotteryPlayerData) do
		if k == SteamID then
			TicketNumb = k
			break
		end
	end
	if !TicketNumb and ply:CanAfford(TicketCost) then
		CurrentPot = CurrentPot + TicketCost
		ply:AddMoney(-TicketCost)
		local lastTicket = 0
		for k,v in pairs(LotteryPlayerData) do
			if v[1] > lastTicket then
				lastTicket = v[1]
			end
		end
		LotteryPlayerData[SteamID] = {lastTicket+1, escapeStr(ply:SteamName())}
		UpdatePlayerData()
		UpdateData()
		RefreshAllMenus()
	end
end
concommand.Add("buylotteryticket", BuyTicket)
	
concommand.Add("closedlotterymenu", function(ply)
	PlayersWithOpenMenu[ply] = nil
end)


local schdStay = ai_schedule.New("Lottery NPC Stay")
local NewTask = ai_task.New()
NewTask:InitEngine("TASK_WAIT_INDEFINITE", 0) NewTask.TaskID = 1
schdStay.TaskCount = table.insert(schdStay.Tasks, NewTask)
	
function ENT:Initialize()
	self.LastUse = CurTime()

	self:SetHullType(HULL_HUMAN);
	self:SetHullSizeNormal();
 
	self:SetSolid(SOLID_BBOX) 
	self:SetMoveType(MOVETYPE_STEP)
 
	self:CapabilitiesAdd(bit.bor(CAP_MOVE_GROUND, CAP_OPEN_DOORS, CAP_ANIMATEDFACE, CAP_TURN_HEAD, CAP_USE_SHOT_REGULATOR, CAP_AIM_GUN))
 
	self:SetMaxYawSpeed(5000)

	self:SetUseType(SIMPLE_USE)
end
	
function ENT:SelectSchedule()
	self:StartSchedule(schdStay)
end
	
function ENT:AcceptInput(name, activator, caller)
	if( !caller:IsValid() || !caller:IsPlayer() || name != "Use" ) or self.LastUse > CurTime() then return end	
	self.LastUse = CurTime() + 0.5
	
	local SteamID, TicketNumb = caller:SteamID()
	for k,v in pairs(LotteryPlayerData) do
		if k == SteamID then
			TicketNumb = v[1]
			break
		end
	end
	umsg.Start("LotteryMenu", caller)
		umsg.Long(NextLotteryTime)
		umsg.Short(TicketCost)
		umsg.Long(CurrentPot)
		umsg.String(LastWinner)
		umsg.Long(LastWinnerCash)
		umsg.Bool(util.tobool(TicketNumb))
		umsg.Short(TicketNumb)
	umsg.End()
	PlayersWithOpenMenu[caller] = caller
end

function ENT:OnRemove() // So it can revive again, comment out if you don't want the npc to respawn after being deleted
	timer.Simple(2.5, function() if !IsValid(LotteryNPC) then SpawnLotteryNPC() end end)
end
//�Tomasas 2013