if(SERVER) then

	util.AddNetworkString( "DarkRP_SS_Gamble" )
	util.AddNetworkString( "DarkRP_CS_Casino" )
	util.AddNetworkString( "DarkRP_SS_PayIn" )
	util.AddNetworkString( "DarkRP_SS_Raise" )
	util.AddNetworkString( "DarkRP_SS_Texas" )

	resource.AddFile( "materials/DarkRPCasino/rheart.png")
	resource.AddFile( "materials/DarkRPCasino/rspade.png")
	resource.AddFile( "materials/DarkRPCasino/rdia.png")
	resource.AddFile( "materials/DarkRPCasino/rclub.png")

	resource.AddFile( "materials/DarkRPCasino/bheart.png")
	resource.AddFile( "materials/DarkRPCasino/bspade.png")
	resource.AddFile( "materials/DarkRPCasino/bdia.png")
	resource.AddFile( "materials/DarkRPCasino/bclub.png")
end

GambleDelay = 1 --Delay between play can play again in seconds

NPCSpawnVec = Vector(919, 318, -195)
NPCSpawnAng = Angle(0,-180,0)


HeadCards = {}
HeadCards["J"] = "models/eli.mdl"
HeadCards["Q"] = "models/alyx.mdl"
HeadCards["K"] = "models/gman_high.mdl"
HeadCards["A"] = "models/odessa.mdl"

Suit = {}
Suit[1] = {Path = "materials/DarkRPCasino/rheart.png"}
Suit[2] = {Path = "materials/DarkRPCasino/bspade.png"}
Suit[3] = {Path = "materials/DarkRPCasino/rdia.png"}
Suit[4] = {Path = "materials/DarkRPCasino/bclub.png"}

BetVals = { --These are the values players may Raise / Pay-In at
	50,
	100,
	150,
	200,
	500,
	1000,
	2500,
}

function DarkRP_Casino_Spawn()
	if(SERVER) then
		local ent = ents.Create("npc_casino")
		ent:SetPos(NPCSpawnVec)
		ent:SetAngles(NPCSpawnAng)
		ent:Spawn()
	end
end
hook.Add( "InitPostEntity", "DarkRP_Casino_Spawn", DarkRP_Casino_Spawn)

net.Receive( "DarkRP_SS_PayIn", function( length, ply )
	local amt = net.ReadInt(32)
	if(ply:CanAfford(amt)) then
		ply:AddMoney(-amt)
		GAMEMODE:Notify(ply, 0, 4, "You paid in $"..amt..".")
		ply.Payin = amt
	end
end )

net.Receive( "DarkRP_SS_Raise", function( length, ply )
	local amt = net.ReadInt(32)
	local dd = net.ReadInt(32)
	if(ply:CanAfford(amt)) then
		ply:AddMoney(-amt)
		ply.Payin = ply.Payin + amt
		if(dd == nil or dd == 0) then
			GAMEMODE:Notify(ply, 0, 4, "You raised the stakes by $"..amt..".")
		else
			GAMEMODE:Notify(ply, 0, 4, "You double-downed, pot stands at $"..amt..".")
		end
	end
end )

function DarkRP_CasinoAfford(ply,cmd,arg)
	GAMEMODE:Notify(ply, 0, 4, "You don't have the $"..arg[1].." Pay-In.")
end
concommand.Add("DarkRP_CasinoAfford",DarkRP_CasinoAfford)

net.Receive( "DarkRP_SS_Gamble", function( length, ply )
	local amt = net.ReadInt(32)
	local win = net.ReadInt(32)
	local push = net.ReadInt(32)
	local lose = net.ReadInt(32)
	local dbust = net.ReadInt(32)
	
	if(win == 1 or (dbust != nil and dbust == 1)) then
		ply:AddMoney(amt)
		GAMEMODE:Notify(ply, 0, 4, "+$"..amt)
	end
	if(push == 1) then
		ply:AddMoney(math.ceil(amt / 2))
		GAMEMODE:Notify(ply, 0, 4, "+$"..(amt / 2))
	end
end )
