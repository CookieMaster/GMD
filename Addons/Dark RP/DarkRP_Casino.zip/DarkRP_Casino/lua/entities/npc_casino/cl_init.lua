include( 'shared.lua' )
 
ENT.RenderGroup = RENDERGROUP_BOTH
 
function ENT:Draw( )
    self.Entity:DrawModel( )
end

function DarkRP_CS_Casino()
	local ply = LocalPlayer()
	local maxbet = BetVals[table.Count(BetVals)]
	
	BETAMT = BetVals[1]
	
	local frame = vgui.Create("DFrame")
	frame:SetSize( 300, 150)
	frame:Center()
	frame:SetDraggable( false )
	frame:SetVisible( true )
	frame:ShowCloseButton( true )
	frame:MakePopup()
	frame:SetTitle("")
	frame.Paint = function(frame)
		surface.SetDrawColor( 250, 250, 250, 255) 
		surface.DrawRect(0 , 0, frame:GetWide(), frame:GetTall() )
		
		surface.SetDrawColor( 50, 50, 50, 255) 
		surface.DrawRect(2 , 2, frame:GetWide()-4, frame:GetTall()-4 )
		
		surface.SetDrawColor( 240, 240,240, 255) 
		surface.DrawRect(10 , 100, frame:GetWide() - 20, 5 )

		draw.SimpleText( "Casino", "DermaLarge", frame:GetWide() / 2, 60, Color(250,250,250,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText( "Pay-In: $"..BETAMT, "TargetID", 10, 80, Color(250,250,250,255))
	end
	
	local Games = vgui.Create("DButton", frame)
	Games:SetSize( 100, 20)
	Games:SetPos(10,frame:GetTall() - 30)
	Games:SetText("Games")	
	Games.DoClick = function()
		if(!ply:CanAfford(BETAMT)) then RunConsoleCommand("DarkRP_CasinoAfford",BETAMT) frame:Close() end
		local Opmen = DermaMenu()
		Opmen:AddOption("Blackjack", function() BlackjackHand() frame:Close() end ) 
		Opmen:AddOption("Texas Hold Em", function() TexasHand() frame:Close() end ) 
		Opmen:AddOption("Five Card Draw", function() FivecardHand() frame:Close() end ) 
		Opmen:Open()
	end
	
	local Bet = vgui.Create("DButton", frame)
	Bet:SetSize( 100, 20)
	Bet:SetPos(frame:GetWide() - 120,frame:GetTall() - 30)
	Bet:SetText("Bet")	
	Bet.DoClick = function()
		local Opmen = DermaMenu()
		for k,v in pairs(BetVals) do
			if(ply:CanAfford(v)) then
			Opmen:AddOption("$"..v, function() BETAMT = v end ) 
			end
		end
		Opmen:Open()
	end
end
net.Receive( "DarkRP_CS_Casino", DarkRP_CS_Casino)

CardTypes = {}
CardTypes[1] = {Add = 1, Name = "A"}
for i=2,10 do
	CardTypes[i] = {Add = i}
end
CardTypes[11] = {Add = 10, Name = "J"}
CardTypes[12] = {Add = 10, Name = "Q"}
CardTypes[13] = {Add = 10, Name = "K"}

--PLYHAND[1-5] = 1-52, NewDeck[PLYHAND[id]]

function DeckSetup()
	local ply = LocalPlayer()
	PLYHAND = {}
	DEALHAND = {}
	DCARDBG = {}
	CARDBG = {}
	CARDTAKEID = 0
	TCARDBG = {}
	DIT = {}
	
	SHOWDCARD = {}
	SHOWCARD = {}
	for i=1,5 do
		SHOWDCARD[i] = 1
		SHOWCARD[i] = 1
	end	
	
	DECKAMT = 0
	Deck = {}
	for i=1,52 do
		Deck[i] = {Name = "", Add = 0, Display = "", Suit = 0}
	end

	for k,v in pairs(CardTypes) do
		for i=1,4 do
			DeckInsert(k,i)
		end
	end
	DeckRandomize()
end

function DeckInsert(card,suit)
	DECKAMT = DECKAMT + 1
	nam = card
	if(CardTypes[card] != nil and CardTypes[card].Name != nil) then
		nam = CardTypes[card].Name
	end
	if(CardTypes[card] != nil and CardTypes[card].Display != nil) then
		disp = CardTypes[card].Display
	end
	Deck[DECKAMT] = {Name = nam, Add = CardTypes[card].Add, Display = disp, Suit = suit, Val = card}
end

function DeckRandomize()
	placedcards = 0
	NewDeck = {}
	CARDBG = {}
	for i=1,52 do
		while(placedcards < 52) do
			local newid = math.random(1,52)
			if(NewDeck[newid] == nil) then
				placedcards = placedcards + 1
				NewDeck[newid] = Deck[placedcards]
			end
		end
	end
end

function CardTake(tbl,forceid) --USE THIS FUNCTION TO DRAW A CARD
	local id = (table.Count(tbl) + 1)
	if(forceid != nil) then id = forceid end
	if(id <= 5 or forceid != nil) then
		CARDTAKEID = CARDTAKEID + 1
		tbl[id] = CARDTAKEID
		RenderCards(CASINOMENU,1)
	end
end

function GetCardVals(game,plytbl,dealtbl,tbltbl)
	if(game == "Blackjack") then
		PLYCARDVAL = 0
		for k,v in pairs(plytbl) do
			local card = NewDeck[v]
			if(card.Add == 1) then
				if(PLYCARDVAL <= 10) then card.Add = 11 else card.Add = 1 end
			end
			PLYCARDVAL = PLYCARDVAL + card.Add
		end
		DEALCARDVAL = 0
		for k,v in pairs(dealtbl) do
			local card = NewDeck[v]
			if(card.Add == 1) then
				if(DEALCARDVAL <= 10) then card.Add = 11 else card.Add = 1 end
			end
			DEALCARDVAL = DEALCARDVAL + card.Add
		end
	end
end

function RenderCards(pan)
	for k,v in pairs(CARDBG) do CARDBG[k]:Remove() CARDBG[k] = nil end
	for k,v in pairs(DCARDBG) do DCARDBG[k]:Remove() DCARDBG[k] = nil end


	for i=1,table.Count(PLYHAND) do
		CARDBG[i] = vgui.Create( "DPanel", pan )
		CARDBG[i]:SetSize( 50, 100)
		CARDBG[i]:SetPos(i * 80 - 70, 260)
		CARDBG[i].Paint = function()
			surface.SetDrawColor( 250, 250, 250, 255) 
			surface.DrawRect(0 , 0, CARDBG[i]:GetWide(), CARDBG[i]:GetTall() )		
			local tbl = NewDeck[PLYHAND[i]]
			local num = NewDeck[PLYHAND[i]].Add
			local nam = NewDeck[PLYHAND[i]].Name
			if(nam != nil) then
				local num = tonumber(nam)
				draw.SimpleText( nam, "TargetID", 0, 0, Color(0,0,0,255))
				if(num == 0 or num == 10) then
					draw.SimpleText( nam, "TargetID", CARDBG[i]:GetWide() - 20, CARDBG[i]:GetTall() - 15, Color(0,0,0,255))
				else
					draw.SimpleText( nam, "TargetID", CARDBG[i]:GetWide() - 10, CARDBG[i]:GetTall() - 15, Color(0,0,0,255))
				end
			end
			
			surface.SetDrawColor( 255, 255, 255, 255 )
			local mat = Material(Suit[tbl.Suit].Path)
			surface.SetMaterial( mat )
			surface.DrawTexturedRect( 30, 0, 20, 20 )
			surface.DrawTexturedRect( 0, 80, 20, 20 )
		end		
		
		local tbl = NewDeck[PLYHAND[i]]
		if(HeadCards[tbl.Name] != nil) then
			local icon = vgui.Create( "SpawnIcon", CARDBG[i] ) 
			icon:SetModel( HeadCards[tbl.Name] )
			icon:SetSize(50,50)
			icon:SetPos(0,25)
			icon:SetToolTip(nil)
			icon.DoClick = function( icon ) end 
			icon.Paint = function()
			end
		end

	end

	for i=1,table.Count(DEALHAND) do
		
			DCARDBG[i] = vgui.Create( "DPanel", pan )
			DCARDBG[i]:SetSize( 50, 100)
			DCARDBG[i]:SetPos(i * 80 - 70, 130)
			DCARDBG[i].Paint = function()
				if(SHOWDCARD[i] == 1) then
					surface.SetDrawColor( 250, 250, 250, 255) 
					surface.DrawRect(0 , 0, DCARDBG[i]:GetWide(), DCARDBG[i]:GetTall() )
					
					local tbl = NewDeck[DEALHAND[i]]
					local num = NewDeck[DEALHAND[i]].Add
					local nam = NewDeck[DEALHAND[i]].Name
					if(nam != nil) then
						local num = tonumber(nam)
						draw.SimpleText( nam, "TargetID", 0, 0, Color(0,0,0,255))
						if(num == 0 or num == 10) then
							draw.SimpleText( nam, "TargetID", DCARDBG[i]:GetWide() - 20, DCARDBG[i]:GetTall() - 15, Color(0,0,0,255))
						else
							draw.SimpleText( nam, "TargetID", DCARDBG[i]:GetWide() - 10, DCARDBG[i]:GetTall() - 15, Color(0,0,0,255))
						end
					end
				
					surface.SetDrawColor( 255, 255, 255, 255 )
					local mat = Material(Suit[tbl.Suit].Path)
					surface.SetMaterial( mat )
					surface.DrawTexturedRect( 30, 0, 20, 20 )
					surface.DrawTexturedRect( 0, 80, 20, 20 )
					if(DIT != nil and DIT[i] != nil and DIT[i]:IsValid()) then
						DIT[i]:SetVisible(true)
					end
				else
					if(DIT != nil and DIT[i] != nil and DIT[i]:IsValid()) then
						DIT[i]:SetVisible(false)
					end
				end
			end		
			
			local tbl = NewDeck[DEALHAND[i]]

			if(HeadCards[tbl.Name] != nil) then
				DIT[i] = vgui.Create( "SpawnIcon", DCARDBG[i] ) 
				DIT[i]:SetModel( HeadCards[tbl.Name] )
				DIT[i]:SetSize(50,50)
				DIT[i]:SetPos(0,25)
				DIT[i]:SetToolTip(nil)
			end
	end

	if(SETGAME == "Texas") then
		if(TCARDBG != nil) then for k,v in pairs(TCARDBG) do TCARDBG[k]:Remove() TCARDBG[k] = nil end end
		
		for i=1,table.Count(TEXTBL) do
			TCARDBG[i] = vgui.Create( "DPanel", pan )
			TCARDBG[i]:SetSize( 50, 100)
			TCARDBG[i]:SetPos(120 + i * 80, 200)
			TCARDBG[i].Paint = function()
				surface.SetDrawColor( 250, 250, 250, 255) 
				surface.DrawRect(0 , 0, TCARDBG[i]:GetWide(), TCARDBG[i]:GetTall() )
				
				local tbl = NewDeck[TEXTBL[i]]
				local num = NewDeck[TEXTBL[i]].Add
				local nam = NewDeck[TEXTBL[i]].Name
				if(nam != nil) then
					local num = tonumber(nam)
					draw.SimpleText( nam, "TargetID", 0, 0, Color(0,0,0,255))
					if(num == 0 or num == 10) then
						draw.SimpleText( nam, "TargetID", TCARDBG[i]:GetWide() - 20, TCARDBG[i]:GetTall() - 15, Color(0,0,0,255))
					else
						draw.SimpleText( nam, "TargetID", TCARDBG[i]:GetWide() - 10, TCARDBG[i]:GetTall() - 15, Color(0,0,0,255))
					end
				end
			
				surface.SetDrawColor( 255, 255, 255, 255 )
				local mat = Material(Suit[tbl.Suit].Path)
				surface.SetMaterial( mat )
				surface.DrawTexturedRect( 30, 0, 20, 20 )
				surface.DrawTexturedRect( 0, 80, 20, 20 )
			end		
			
			local tbl = NewDeck[TEXTBL[i]]

			if(HeadCards[tbl.Name] != nil) then
				local icon = vgui.Create( "SpawnIcon", TCARDBG[i] ) 
				icon:SetModel( HeadCards[tbl.Name] )
				icon:SetSize(50,50)
				icon:SetPos(0,25)
				icon:SetToolTip(nil)
				icon.DoClick = function( icon ) end 
				icon.Paint = function()
				end
			end
		end
	end
end

function ShowAllCards()
	for i=1,5 do
		SHOWCARD[i] = 1
		SHOWDCARD[i] = 1
	end
end
-- BLACKJACK

function BlackjackHand()
	local ply = LocalPlayer()
	net.Start("DarkRP_SS_PayIn") net.WriteInt(BETAMT,32) net.SendToServer()
	BUST = 0
	DBUST = 0
	ORGINBET = BETAMT
	WIN = 0
	PUSH = 0
	LOSE = 0
	PLYCARDVAL = 0
	DEALCARDVAL = 0
	
	SETGAME = "Blackjack"
	local frame = vgui.Create("DFrame")
	frame:SetSize( 400, 400)
	frame:Center()
	frame:SetDraggable( false )
	frame:SetVisible( true )
	frame:ShowCloseButton( true )
	frame:MakePopup()
	frame:SetTitle("")
	frame.Paint = function(frame)
		surface.SetDrawColor( 250, 250, 250, 255) 
		surface.DrawRect(0 , 0, frame:GetWide(), frame:GetTall() )
		
		surface.SetDrawColor( 50, 50, 50, 255) 
		surface.DrawRect(2 , 2, frame:GetWide()-4, frame:GetTall()-4 )
		
		surface.SetDrawColor( 240, 240,240, 255) 
		surface.DrawRect(10 , 100, frame:GetWide() - 20, 5 )

		surface.DrawRect(10 , 242, frame:GetWide() - 20, 5 )	
		surface.DrawRect(72 , 130, 5, 230 )
		surface.DrawRect(152 , 130, 5, 230 )
		surface.DrawRect(232 , 130, 5, 230 )
		surface.DrawRect(312 , 130, 5, 230 )
		
		draw.SimpleText( "Blackjack", "DermaLarge", frame:GetWide() / 2, 60, Color(250,250,250,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText( "Bet: $"..BETAMT, "TargetID", 10, 80, Color(250,250,250,255))
		draw.SimpleText( "Card Value: "..PLYCARDVAL.."/21", "Default", 10, frame:GetTall() - 40, Color(250,250,250,255))
		
		if(BUST == 1 and DBUST == 0) then
			draw.SimpleText( "You bust!", "TargetID", 10, frame:GetTall() - 20, Color(250,250,250,255))
		end
		if(DBUST == 1 and BUST == 0) then
				draw.SimpleText( "The dealer bust!", "TargetID", 10, frame:GetTall() - 20, Color(250,250,250,255))
		end
		if(PUSH == 1) then
				draw.SimpleText( "Push!", "TargetID", 10, frame:GetTall() - 20, Color(250,250,250,255))
		end
		if(WIN == 1) then
				draw.SimpleText( "You won $"..(BETAMT * 2).."!", "TargetID", 10, frame:GetTall() - 20, Color(250,250,250,255))
		end
		if(LOSE == 1) then
				draw.SimpleText( "You lost!", "TargetID", 10, frame:GetTall() - 20, Color(250,250,250,255))
		end
	end
	CASINOMENU = frame

	DeckSetup()
	for i=1,2 do
		CardTake(PLYHAND)
	end
	for i=1,2 do
		CardTake(DEALHAND)
	end
	
	SHOWDCARD[2] = 0
	SHOWDCARD[3] = 0
	SHOWDCARD[4] = 0
	SHOWDCARD[5] = 0
	GetCardVals("Blackjack",PLYHAND,DEALHAND)
	
	BJDD = vgui.Create( "DButton", frame )
	BJDD:SetPos(120, 110)
	BJDD:SetSize(100, 15)
	BJDD:SetText("Double-Down")
	BJDD.DoClick = function()	
		if(ply:CanAfford(BETAMT)) then
			BETAMT = BETAMT + BETAMT
			net.Start("DarkRP_SS_Raise")
				net.WriteInt(BETAMT,32)
				net.WriteInt(1,32)
			net.SendToServer()
			BJDD:Remove()
			Blackjack_Hit()
			BJhit:Remove()
			BlackjackBustCheck()
			if(BUST == 0) then
				Blackjack_HandleDealer(1)	
			end
		end
	end
	
	BJhit = vgui.Create( "DButton", frame )
	BJhit:SetPos(10, 110)
	BJhit:SetSize(100, 15)
	BJhit:SetText("Hit")
	BJhit.DoClick = function()
		Blackjack_Hit()
		BJDD:Remove()
	end

	BJfold = vgui.Create( "DButton", frame )
	BJfold:SetPos(frame:GetWide() - 120, 110)
	BJfold:SetSize(50, 15)
	BJfold:SetText("Fold")
	BJfold.DoClick = function()
		Blackjack_RemoveButs()
	end
	
	BJstay = vgui.Create( "DButton", frame )
	BJstay:SetPos(frame:GetWide() - 60, 110)
	BJstay:SetSize(50, 15)
	BJstay:SetText("Stay")
	BJstay.DoClick = function()
		BJhit:Remove()
		Blackjack_HandleDealer()
		Blackjack_RemoveButs()
	end
end

function Blackjack_HandleDealer(sa)
	GetCardVals("Blackjack",PLYHAND,DEALHAND)
	while(DEALCARDVAL <= 16 and DEALCARDVAL <= PLYCARDVAL) do
		CardTake(DEALHAND)
		GetCardVals("Blackjack",PLYHAND,DEALHAND)
	end
	if(sa == nil) then
		while(DEALCARDVAL < PLYCARDVAL) do
			if(table.Count(DEALHAND) == 5) then break end
			CardTake(DEALHAND)
			GetCardVals("Blackjack",PLYHAND,DEALHAND)	
		end
	end
	BlackjackBustCheck()
	Blackjack_FinishGame()
end

function Blackjack_Hit()
	if(table.Count(PLYHAND) <= 5) then
		CardTake(PLYHAND)
		GetCardVals("Blackjack",PLYHAND,DEALHAND)
		BlackjackBustCheck()
		if(table.Count(PLYHAND) == 5) then Blackjack_FinishGame() end
	end
end

function BlackjackBustCheck()
	BUST = 0
	DBUST = 0

	if(PLYCARDVAL > 21) then
		BUST = 1
		Blackjack_RemoveButs()
	end
	if(DEALCARDVAL > 21) then
		DBUST = 1
		Blackjack_RemoveButs()
	end
end

function Blackjack_RemoveButs()
	
	local ply = LocalPlayer()
	if(BJhit != nil and BJhit:IsValid()) then
		BJhit:Remove()
	end
	if(BJstay != nil and BJstay:IsValid()) then
		BJstay:Remove()
	end
	if(BJfold != nil and BJfold:IsValid()) then
		BJfold:Remove()
	end
	
	if(ply:CanAfford(ORGINBET)) then
		local Deal = vgui.Create( "DButton", CASINOMENU )
		Deal:SetPos(10, 110)
		Deal:SetSize(100, 15)
		Deal:SetText("Deal Again")
		Deal.DoClick = function()
			CASINOMENU:Close()
			BETAMT = ORGINBET 
			BlackjackHand()
		end
		local EndPoker = vgui.Create( "DButton", CASINOMENU )
		EndPoker:SetPos(120, 110)
		EndPoker:SetSize(100, 15)
		EndPoker:SetText("Stop Playing")
		EndPoker.DoClick = function()
			CASINOMENU:Close()
		end
		
	end
end

function Blackjack_FinishGame()
	local ply = LocalPlayer()
	GetCardVals("Blackjack",PLYHAND,DEALHAND)
	
	--print("PLY VAL: "..PLYCARDVAL)
	--print("DEAL VAL: "..DEALCARDVAL)
	
	if(PLYCARDVAL > DEALCARDVAL) then
		WIN = 1
	end
	if(PLYCARDVAL == DEALCARDVAL) then
		PUSH = 1
	end
	if(PLYCARDVAL < DEALCARDVAL and DBUST == 0) then
		LOSE = 1
	end
	net.Start("DarkRP_SS_Gamble")
		net.WriteInt(BETAMT * 2,32)
		net.WriteInt(WIN,32)
		net.WriteInt(PUSH,32)
		net.WriteInt(LOSE,32)
		net.WriteInt(DBUST,32)
	net.SendToServer()
	Blackjack_RemoveButs()
	ShowAllCards()
end



--TEXAS HOLD EM

function TexasHand()
	local ply = LocalPlayer()
	net.Start("DarkRP_SS_PayIn") net.WriteInt(BETAMT,32) net.SendToServer()
	SETGAME = "Texas"
	ORGINBET = BETAMT
	WIN = 0
	PUSH = 0
	LOSE = 0
	
	local frame = vgui.Create("DFrame")
	frame:SetSize( 600, 450)
	frame:Center()
	frame:SetDraggable( false )
	frame:SetVisible( true )
	frame:ShowCloseButton( true )
	frame:MakePopup()
	frame:SetTitle("")
	frame.Paint = function(frame)
		surface.SetDrawColor( 250, 250, 250, 255) 
		surface.DrawRect(0 , 0, frame:GetWide(), frame:GetTall() )
		
		surface.SetDrawColor( 50, 50, 50, 255) 
		surface.DrawRect(2 , 2, frame:GetWide()-4, frame:GetTall()-4 )
		
		surface.SetDrawColor( 240, 240,240, 255) 
		surface.DrawRect(10 , 100, frame:GetWide() - 20, 5 )
		
		surface.DrawRect(10 , 242, 145, 5 )	
		surface.DrawRect(72 , 130, 5, 230 )
		surface.DrawRect(152 , 130, 5, 230 )
				
		draw.SimpleText( "Texas Hold Em", "DermaLarge", frame:GetWide() / 2, 60, Color(250,250,250,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		draw.SimpleText( "Bet: $"..BETAMT, "TargetID", 10, 80, Color(250,250,250,255))
		if(WIN == 1) then
				draw.SimpleText( "You won $"..(BETAMT * 2).."!", "TargetID", 10, frame:GetTall() - 20, Color(250,250,250,255))
		end
		if(PUSH == 1) then
				draw.SimpleText( "Push!", "TargetID", 10, frame:GetTall() - 20, Color(250,250,250,255))
		end
		if(LOSE == 1) then
				draw.SimpleText( "You lost!", "TargetID", 10, frame:GetTall() - 20, Color(250,250,250,255))
		end
	end
	CASINOMENU = frame

	DeckSetup()
	TEXTBL = {}
	for i=1,3 do
		CardTake(TEXTBL)
	end
	for i=1,2 do
		CardTake(PLYHAND)
	end
	for i=1,2 do
		CardTake(DEALHAND)
	end
		
	SHOWDCARD[1] = 0
	SHOWDCARD[2] = 0
	
	TERaise = vgui.Create("DButton", frame)
	TERaise:SetSize( 100, 20)
	TERaise:SetPos(10,frame:GetTall() - 25)
	TERaise:SetText("Raise")
	TERaise.DoClick = function()
		local Opmen = DermaMenu()
		for k,v in pairs(BetVals) do
			if(ply:CanAfford(v)) then
				Opmen:AddOption("$"..v, function() Tex_NextCard(v) end ) 
			end
		end
		Opmen:Open()		
	end
	
	TEStand = vgui.Create("DButton", frame)
	TEStand:SetSize( 100, 20)
	TEStand:SetPos(120,frame:GetTall() - 25)
	TEStand:SetText("Stand")
	TEStand.DoClick = function()
		Tex_NextCard(0)
	end
	
	TEFold = vgui.Create("DButton", frame)
	TEFold:SetSize( 100, 20)
	TEFold:SetPos(230,frame:GetTall() - 25)
	TEFold:SetText("Fold")
	TEFold.DoClick = function()
		TexRemoveButs()
	end
end

function TexRemoveButs()
	local ply = LocalPlayer()
	if(TERaise != nil and TERaise:IsValid()) then
		TERaise:Remove()
	end
	if(TEStand != nil and TEStand:IsValid()) then
		TEStand:Remove()
	end
	if(TEFold != nil and TEFold:IsValid()) then
		TEFold:Remove()
	end
	
	if(ply:CanAfford(ORGINBET)) then
		local Deal = vgui.Create( "DButton", CASINOMENU )
		Deal:SetPos(10, 110)
		Deal:SetSize(100, 15)
		Deal:SetText("Deal Again")
		Deal.DoClick = function()
			CASINOMENU:Close()
			BETAMT = ORGINBET 
			TexasHand()
		end
		local EndPoker = vgui.Create( "DButton", CASINOMENU )
		EndPoker:SetPos(120, 110)
		EndPoker:SetSize(100, 15)
		EndPoker:SetText("Stop Playing")
		EndPoker.DoClick = function()
			CASINOMENU:Close()
		end
	end
end

function Tex_NextCard(v)
	if(v != nil and v > 0) then
		BETAMT = BETAMT + v 
		net.Start("DarkRP_SS_Raise") net.WriteInt(v,32) net.WriteInt(0,32) net.SendToServer() 
	end
	CardTake(TEXTBL)
	if(table.Count(TEXTBL) == 5) then
		TexRemoveButs()
		Tex_FindWinner()
	end
end

function Tex_FindWinner()
	ShowAllCards()
	--Find what the player has
	--Pairs
	--Straight
	--Flush
	
	CardPairs = {}
	Flushes = {}
	DCardPairs = {}
	DFLUSHes = {}	
	for i=1,4 do
		Flushes[i] = 0
		DFLUSHes[i] = 0
	end
	STRAIGHT = 0
	FLUSH = 0
	DSTRAIGHT = 0
	DFLUSH = 0	
	
	--Pairs
	for k,v in pairs(PLYHAND) do
		local tbl = NewDeck[v]
		for a,b in pairs(TEXTBL) do
			local tbl2 = NewDeck[b]
			if(tbl2.Name == tbl.Name) then
				CardPairs[table.Count(CardPairs) + 1] = tbl
			end
		end
	end
	
	for k,v in pairs(DEALHAND) do
		local tbl = NewDeck[v]
		for a,b in pairs(TEXTBL) do
			local tbl2 = NewDeck[b]
			if(tbl2.Name == tbl.Name) then
				DCardPairs[table.Count(DCardPairs) + 1] = tbl
			end
		end
	end
	
	--Flushes
	for k,v in pairs(TEXTBL) do
		local tbl = NewDeck[v]
		for a,b in pairs(PLYHAND) do
			local tbl2 = NewDeck[b]
			if(tbl.Suit == tbl2.Suit) then
				Flushes[tbl.Suit] = Flushes[tbl.Suit] + 1
			end
		end
	end
	
	for k,v in pairs(Flushes) do
		if(v >= 5) then
			FLUSH = 1
		end
	end
	
	for k,v in pairs(TEXTBL) do
		local tbl = NewDeck[v]
		for a,b in pairs(DEALHAND) do
			local tbl2 = NewDeck[b]
			if(tbl.Suit == tbl2.Suit) then
				DFLUSHes[tbl.Suit] = DFLUSHes[tbl.Suit] + 1
			end
		end
	end
	
	for k,v in pairs(DFLUSHes) do
		if(v >= 5) then
			DFLUSH = 1
		end
	end	
	
	--Straights
	highval = 0
	lowval = 13
	
	for k,v in pairs(TEXTBL) do
		local tbl = NewDeck[v]
		if(tbl.Val > highval) then 
			highval = tbl.Val
			highvaltbl = tbl
		end

		if(tbl.Val < lowval) then 
			lowval = tbl.Val
			lowvaltbl = tbl
		end
		for a,b in pairs(PLYHAND) do
			local tbl2 = NewDeck[b]
			if(tbl2.Val > highval) then 
				highval = tbl2.Val
				highvaltbl = tbl2
			end

			if(tbl2.Val < lowval) then 
				lowval = tbl2.Val
				lowvaltbl = tbl2
			end			
		end
	end
	
	CAT = {}
	for i=1,13 do
		CAT[i] = 0
	end
	BROKESEQ = 0
	
	for k,v in pairs(TEXTBL) do
		local tbl = NewDeck[v]
		CAT[tbl.Val] = CAT[tbl.Val] + 1
	end
	for k,v in pairs(PLYHAND) do
		local tbl = NewDeck[v]
		CAT[tbl.Val] = CAT[tbl.Val] + 1
	end
	
	for k,v in pairs(CAT) do
		if(v == 1) then
			BROKESEQ = BROKESEQ + 1
		else
			BROKESEQ = 0
		end
		if(BROKESEQ == 5) then
			STRAIGHT = 1
		end
	end
	
	CAT = {}
	for i=1,13 do
		CAT[i] = 0
	end
	BROKESEQ = 0
	for k,v in pairs(TEXTBL) do
		local tbl = NewDeck[v]
		CAT[tbl.Val] = CAT[tbl.Val] + 1
	end
	for k,v in pairs(DEALHAND) do
		local tbl = NewDeck[v]
		CAT[tbl.Val] = CAT[tbl.Val] + 1
	end
	
	for k,v in pairs(CAT) do
		if(v == 1) then
			BROKESEQ = BROKESEQ + 1
		else
			BROKESEQ = 0
		end
		if(BROKESEQ == 5) then
			DSTRAIGHT = 1
		end
	end

	------------------------------------------
	
	local pair = table.Count(CardPairs)
	local dpair = table.Count(DCardPairs)
	WIN = 0
	LOSE = 0
	PUSH = 0

	--Pairs
	if(STRAIGHT == 0 and DSTRAIGHT == 0 and DFLUSH == 0 and FLUSH == 0) then
		if(pair > 0 or dpair > 0) then
			if(pair > dpair) then WIN = 1 LOSE = 0 PUSH = 0 end
			if(pair < dpair) then LOSE = 1 WIN = 0 PUSH = 0 end
			if(pair == dpair) then 
				if(CardPairs[1].Val > DCardPairs[1].Val) then WIN = 1 LOSE = 0 PUSH = 0 end
				if(DCardPairs[1].Val > CardPairs[1].Val) then LOSE = 1 WIN = 0 PUSH = 0 end
				if(DCardPairs[1].Val == CardPairs[1].Val) then PUSH = 1 WIN = 0 LOSE = 0 end
			end
		end
	end
	
	if(STRAIGHT == 0 and DSTRAIGHT == 0) then
	--FLUSH
		if( FLUSH == 1 and DFLUSH == 0 and dpair < 4) then WIN = 1 LOSE = 0 end	
		if( DFLUSH == 1 and FLUSH == 0 and pair < 4) then LOSE = 1 WIN = 0 end
		if( FLUSH == 1 and DFLUSH == 1) then PUSH = 1 LOSE = 0 WIN = 0 end
	end
	
	--STRAIGHT
	if(DSTRAIGHT == 0 and STRAIGHT == 1) then WIN = 1 LOSE = 0 PUSH = 0 end	
	if(DSTRAIGHT == 1 and STRAIGHT == 0) then LOSE = 1 WIN = 0 PUSH = 0 end
	if(DSTRAIGHT == 1 and STRAIGHT == 1) then PUSH = 1 WIN = 0 PUSH = 0 end
	
	--4Pairs
	if(pair == 4 and dpair < 4) then WIN = 1 LOSE = 0 end
	if(dpair == 4 and pair < 4) then LOSE = 1 WIN = 0 end
	if(dpair == 4 and pair == 4) then PUSH = 1 LOSE = 0 WIN = 0 end
	
	--STRAIGHTFLUSH
	if(STRAIGHT == 1 and FLUSH == 1) then WIN = 1 LOSE = 0 PUSH = 0 end
	if(DSTRAIGHT == 1 and DFLUSH == 1) then LOSE = 1 WIN = 0 PUSH = 0 end
	if(DSTRAIGHT == 1 and DFLUSH == 1 and FLUSH == 1 and STRAIGHT == 1) then PUSH = 1 LOSE = 0 WIN = 0 end
	
	--print("Pairs: "..table.Count(CardPairs))
--	print("Flush: "..FLUSH)
--	print("DPairs: "..table.Count(DCardPairs))
	--print("DFLUSH: "..DFLUSH)
		if(WIN == 0 and LOSE == 0) then PUSH = 1 end
	--print(WIN)
	--print(LOSE)
	--print(PUSH)
	net.Start("DarkRP_SS_Gamble")
		net.WriteInt(BETAMT * 2,32)
		net.WriteInt(WIN,32)
		net.WriteInt(PUSH,32)
		net.WriteInt(LOSE,32)
		net.WriteInt(0,32)
	net.SendToServer()
end

function FivecardHand()
	local ply = LocalPlayer()
	net.Start("DarkRP_SS_PayIn") net.WriteInt(BETAMT,32) net.SendToServer()
	ORGINBET = BETAMT
	WIN = 0
	PUSH = 0
	LOSE = 0
	NEWCARDS = 0
	
	SETGAME = "Fivecard"
	local frame = vgui.Create("DFrame")
	frame:SetSize( 400, 400)
	frame:Center()
	frame:SetDraggable( false )
	frame:SetVisible( true )
	frame:ShowCloseButton( true )
	frame:MakePopup()
	frame:SetTitle("")
	frame.Paint = function(frame)
		surface.SetDrawColor( 250, 250, 250, 255) 
		surface.DrawRect(0 , 0, frame:GetWide(), frame:GetTall() )
		
		surface.SetDrawColor( 50, 50, 50, 255) 
		surface.DrawRect(2 , 2, frame:GetWide()-4, frame:GetTall()-4 )
		
		surface.SetDrawColor( 240, 240,240, 255) 
		surface.DrawRect(10 , 100, frame:GetWide() - 20, 5 )

		surface.DrawRect(10 , 242, frame:GetWide() - 20, 5 )	
		surface.DrawRect(72 , 130, 5, 230 )
		surface.DrawRect(152 , 130, 5, 230 )
		surface.DrawRect(232 , 130, 5, 230 )
		surface.DrawRect(312 , 130, 5, 230 )
		
		draw.SimpleText( "Five Card Draw", "DermaLarge", frame:GetWide() / 2, 60, Color(250,250,250,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText( "Bet: $"..BETAMT, "TargetID", 10, 80, Color(250,250,250,255))
		if(PUSH == 1) then
				draw.SimpleText( "Push!", "TargetID", 10, frame:GetTall() - 20, Color(250,250,250,255))
		end
		if(WIN == 1) then
				draw.SimpleText( "You won $"..(BETAMT * 2).."!", "TargetID", 10, frame:GetTall() - 20, Color(250,250,250,255))
		end
		if(LOSE == 1) then
				draw.SimpleText( "You lost!", "TargetID", 10, frame:GetTall() - 20, Color(250,250,250,255))
		end
	end
	CASINOMENU = frame

	DeckSetup()
	for i=1,5 do
		CardTake(PLYHAND)
	end
	for i=1,5 do
		CardTake(DEALHAND)
	end
	
	SHOWDCARD[1] = 0
	SHOWDCARD[2] = 0
	SHOWDCARD[3] = 0
	SHOWDCARD[4] = 0
	SHOWDCARD[5] = 0

	FCfold = vgui.Create( "DButton", frame )
	FCfold:SetPos(frame:GetWide() - 120, 110)
	FCfold:SetSize(50, 15)
	FCfold:SetText("Fold")
	FCfold.DoClick = function()
		FivecardRemoveButs()
	end
	
	FCstay = vgui.Create( "DButton", frame )
	FCstay:SetPos(frame:GetWide() - 60, 110)
	FCstay:SetSize(50, 15)
	FCstay:SetText("Stay")
	FCstay.DoClick = function()
		FCstay:Remove()
		FivecardFinishGame()
	end
	
	FCRE = {}
	for i=1,5 do
		FCRE[i] = vgui.Create( "DButton", frame )
		FCRE[i]:SetPos(80 * i - 70, frame:GetTall() - 40)
		FCRE[i]:SetSize(50, 15)
		FCRE[i]:SetText("New")
		FCRE[i].DoClick = function()
			if(NEWCARDS < 2) then
				PLYHAND[i] = nil
				CardTake(PLYHAND,i)
				FCRE[i]:Remove()
				NEWCARDS = NEWCARDS + 1
				if(NEWCARDS >= 2) then
					FivecardFinishGame()
				end
			end
		end
	end
end

function FivecardFinishGame()
	FivecardRemoveButs()
	for i=1,5 do
		SHOWDCARD[i] = 1
	end
	
	--Handle Dealer Cards
	lowval = 13
	lowval2 = 13
	highval = 0
	for k,v in pairs(DEALHAND) do
		if(NewDeck[v].Val < lowval) then
			lowval = k
		end
	end
	for k,v in pairs(DEALHAND) do
		if(NewDeck[v].Val < lowval2 and NewDeck[v].Val != lowval) then
			lowval2 = k
		end
	end
	FivercardGetWinner()
	if(DFLUSH != 1 and DSTRAIGHT != 1 and table.Count(DCardPairs) == 0) then
		CardTake(DEALHAND,lowval)
		CardTake(DEALHAND,lowval2)
	end
end

function FivercardGetWinner()
	CardPairs = {}
	Flushes = {}
	DCardPairs = {}
	DFLUSHes = {}	
	for i=1,4 do
		Flushes[i] = 0
		DFLUSHes[i] = 0
	end
	STRAIGHT = 0
	FLUSH = 0
	DSTRAIGHT = 0
	DFLUSH = 0	
	
	--Pairs
	for k,v in pairs(PLYHAND) do
		local tbl = NewDeck[v]
		for a,b in pairs(PLYHAND) do
			local tbl2 = NewDeck[b]
			if(tbl2.Val == tbl.Val and k != a) then
				CardPairs[table.Count(CardPairs) + 1] = tbl
			end
		end
	end
	
	for k,v in pairs(DEALHAND) do
		local tbl = NewDeck[v]
		for a,b in pairs(DEALHAND) do
			local tbl2 = NewDeck[b]
			if(tbl2.Val == tbl.Val and k != a) then
				DCardPairs[table.Count(DCardPairs) + 1] = tbl
			end
		end
	end
	
	--Flushes
	FLUSH = 1
	ORSU = 0
	for k,v in pairs(PLYHAND) do
		if(ORSU == 0) then
			ORSU = NewDeck[v].Suit
		else
			if(NewDeck[v].Suit != ORSU) then FLUSH = 0 end
		end
	end
	
	DFLUSH = 1
	ORSU = 0
	for k,v in pairs(DEALHAND) do
		if(ORSU == 0) then
			ORSU = NewDeck[v].Suit
		else
			if(NewDeck[v].Suit != ORSU) then DFLUSH = 0 end
		end
	end
	
	--Straights	
	CAT = {}
	for i=1,13 do
		CAT[i] = 0
	end
	BROKESEQ = 0
	
	for k,v in pairs(PLYHAND) do
		local tbl = NewDeck[v]
		CAT[tbl.Val] = CAT[tbl.Val] + 1
	end
	
	for k,v in pairs(CAT) do
		if(v == 1) then
			BROKESEQ = BROKESEQ + 1
		else
			BROKESEQ = 0
		end
		if(BROKESEQ == 5) then
			STRAIGHT = 1
		end
	end

	CAT = {}
	for i=1,13 do
		CAT[i] = 0
	end
	BROKESEQ = 0
	for k,v in pairs(DEALHAND) do
		local tbl = NewDeck[v]
		CAT[tbl.Val] = CAT[tbl.Val] + 1
	end
	
	for k,v in pairs(CAT) do
		if(v == 1) then
			BROKESEQ = BROKESEQ + 1
		else
			BROKESEQ = 0
		end
		if(BROKESEQ == 5) then
			DSTRAIGHT = 1
		end
	end
	------------------------------------------
	if( table.Count(CardPairs) == 0) then
		pair = table.Count(CardPairs) 
	else
		pair = table.Count(CardPairs) - 1
	end
	
	if( table.Count(DCardPairs) == 0) then
		dpair = table.Count(DCardPairs) 
	else
		dpair = table.Count(DCardPairs) - 1
	end
	
	WIN = 0
	LOSE = 0
	PUSH = 0

	--Pairs
	if(STRAIGHT == 0 and DSTRAIGHT == 0 and DFLUSH == 0 and FLUSH == 0) then
		if(pair > 0 or dpair > 0) then
			if(pair > dpair) then WIN = 1 LOSE = 0 PUSH = 0 end
			if(pair < dpair) then LOSE = 1 WIN = 0 PUSH = 0 end
			if(pair == dpair) then 
				if(CardPairs[1].Val > DCardPairs[1].Val) then WIN = 1 LOSE = 0 PUSH = 0 end
				if(DCardPairs[1].Val > CardPairs[1].Val) then LOSE = 1 WIN = 0 PUSH = 0 end
				if(DCardPairs[1].Val == CardPairs[1].Val) then PUSH = 1 WIN = 0 LOSE = 0 end
			end
		end
	end
	
	if(STRAIGHT == 0 and DSTRAIGHT == 0) then
	--FLUSH
		if( FLUSH == 1 and DFLUSH == 0 and dpair < 4) then WIN = 1 LOSE = 0 end	
		if( DFLUSH == 1 and FLUSH == 0 and pair < 4) then LOSE = 1 WIN = 0 end
		if( FLUSH == 1 and DFLUSH == 1) then PUSH = 1 LOSE = 0 WIN = 0 end
	end
	
	--STRAIGHT
	if(DSTRAIGHT == 0 and STRAIGHT == 1) then WIN = 1 LOSE = 0 PUSH = 0 end	
	if(DSTRAIGHT == 1 and STRAIGHT == 0) then LOSE = 1 WIN = 0 PUSH = 0 end
	if(DSTRAIGHT == 1 and STRAIGHT == 1) then PUSH = 1 WIN = 0 PUSH = 0 end
	
	--4Pairs
	if(pair == 4 and dpair < 4) then WIN = 1 LOSE = 0 end
	if(dpair == 4 and pair < 4) then LOSE = 1 WIN = 0 end
	if(dpair == 4 and pair == 4) then PUSH = 1 LOSE = 0 WIN = 0 end
	
	--STRAIGHTFLUSH
	if(STRAIGHT == 1 and FLUSH == 1) then WIN = 1 LOSE = 0 PUSH = 0 end
	if(DSTRAIGHT == 1 and DFLUSH == 1) then LOSE = 1 WIN = 0 PUSH = 0 end
	if(DSTRAIGHT == 1 and DFLUSH == 1 and FLUSH == 1 and STRAIGHT == 1) then PUSH = 1 LOSE = 0 WIN = 0 end
	
	--print("Pairs: "..pair)
	--print("Flush: "..FLUSH)
	--print("DPairs: "..dpair)
	--print("DFLUSH: "..DFLUSH)
	if(WIN == 0 and LOSE == 0) then PUSH = 1 end
	net.Start("DarkRP_SS_Gamble")
		net.WriteInt(BETAMT * 2,32)
		net.WriteInt(WIN,32)
		net.WriteInt(PUSH,32)
		net.WriteInt(LOSE,32)
		net.WriteInt(0,32)
	net.SendToServer()
end

function FivecardRemoveButs()
	local ply = LocalPlayer()
	if(FCRaise != nil and FCRaise:IsValid()) then
		FCRaise:Remove()
	end
	if(FCStand != nil and FCStand:IsValid()) then
		FCStand:Remove()
	end
	if(FCfold != nil and FCfold:IsValid()) then
		FCfold:Remove()
	end
	if(FCstay != nil and FCstay:IsValid()) then
		FCstay:Remove()
	end
	
	for k,v in pairs(FCRE) do
		v:Remove()
	end
	
	if(ply:CanAfford(ORGINBET)) then
		local Deal = vgui.Create( "DButton", CASINOMENU )
		Deal:SetPos(10, 110)
		Deal:SetSize(100, 15)
		Deal:SetText("Deal Again")
		Deal.DoClick = function()
			CASINOMENU:Close()
			BETAMT = ORGINBET 
			FivecardHand()
		end
		local EndPoker = vgui.Create( "DButton", CASINOMENU )
		EndPoker:SetPos(120, 110)
		EndPoker:SetSize(100, 15)
		EndPoker:SetText("Stop Playing")
		EndPoker.DoClick = function()
			CASINOMENU:Close()
		end
	end
end