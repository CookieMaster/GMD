ENT.Base = "base_ai" 
ENT.Type = "ai"
ENT.PrintName		= "OreNPC"
ENT.Author			= "Kunit"
ENT.AutomaticFrameAdvance = true

function ENT:SetAutomaticFrameAdvance( bUsingAnim )
	self.AutomaticFrameAdvance = bUsingAnim
end
