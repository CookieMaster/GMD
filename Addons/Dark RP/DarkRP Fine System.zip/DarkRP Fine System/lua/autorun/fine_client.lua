if CLIENT then

surface.CreateFont("UiBold", {
	font = "Tahoma", 
	size = 20, 
	weight = 600
})

surface.CreateFont("Trebuchet20", {
	font = "Trebuchet MS", 
	size = 18, 
	weight = 900
})

function GUI_FineMenu( um )
if !LocalPlayer():Alive() then return end
gui.EnableScreenClicker(false)
local Offender = um:ReadString()

if GUI_Trade_Frame then if GUI_Trade_Frame:IsValid() then return false end end
GUI_Fine_Frame = vgui.Create("DFrame")
GUI_Fine_Frame:SetTitle("")
GUI_Fine_Frame:SetSize(320,215)
GUI_Fine_Frame:Center()
GUI_Fine_Frame.Paint = function(CHPaint)
-- Draw the menu background color.
				
draw.RoundedBox( 6, 0, 0, CHPaint:GetWide(), CHPaint:GetTall(), Color( 255, 255, 255, 150 ) )

-- Draw the outline of the menu.
surface.SetDrawColor(0,0,0,255)
surface.DrawOutlinedRect(0, 0, CHPaint:GetWide(), CHPaint:GetTall())

surface.SetDrawColor(0,0,0,255)
surface.DrawOutlinedRect(0, 0, CHPaint:GetWide(), 25)

-- Draw the top title.
draw.SimpleText("Fine Player", "UiBold", 53,12, Color(70,70,70,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
GUI_Fine_Frame:MakePopup()
GUI_Fine_Frame:ShowCloseButton(false)

local GUI_Main_Exit = vgui.Create("DButton")
GUI_Main_Exit:SetParent(GUI_Fine_Frame)
GUI_Main_Exit:SetSize(16,16)
GUI_Main_Exit:SetPos(300,5)
GUI_Main_Exit:SetText("")
GUI_Main_Exit.Paint = function()
surface.SetMaterial(Material("icon16/cross.png"))
surface.SetDrawColor(200,200,0,200)
surface.DrawTexturedRect(0,0,GUI_Main_Exit:GetWide(),GUI_Main_Exit:GetTall())
end
GUI_Main_Exit.DoClick = function()
	GUI_Fine_Frame:Remove()
end

local GUI_Player_Label = vgui.Create("DLabel")
GUI_Player_Label:SetText("The Offender:")
GUI_Player_Label:SetFont("UiBold")
GUI_Player_Label:SetColor(Color(70,70,70,255))
GUI_Player_Label:SetParent(GUI_Fine_Frame)
GUI_Player_Label:SetPos(10,25)
GUI_Player_Label:SizeToContents()

local GUI_Player_Entry = vgui.Create("DTextEntry", GUI_Fine_Frame)
GUI_Player_Entry:SetFont("Trebuchet18")
GUI_Player_Entry:SetSize(300,25)
GUI_Player_Entry:SetPos(10,45)
GUI_Player_Entry:SetEditable(false)
GUI_Player_Entry:SetText(Offender)

local GUI_Price_Label = vgui.Create("DLabel")
GUI_Price_Label:SetText("Price:")
GUI_Price_Label:SetFont("UiBold")
GUI_Price_Label:SetColor(Color(70,70,70,255))
GUI_Price_Label:SetParent(GUI_Fine_Frame)
GUI_Price_Label:SetPos(10,70)
GUI_Price_Label:SizeToContents()

local GUI_Price_Entry = vgui.Create("DTextEntry", GUI_Fine_Frame)
GUI_Price_Entry:SetFont("Trebuchet18")
GUI_Price_Entry:SetSize(300,25)
GUI_Price_Entry:SetPos(10,90)
GUI_Price_Entry:SetNumeric( true )
GUI_Price_Entry:SetEditable(true)
GUI_Price_Entry:SetUpdateOnType(true)

local GUI_Reason_Label = vgui.Create("DLabel")
GUI_Reason_Label:SetText("Reason:")
GUI_Reason_Label:SetFont("UiBold")
GUI_Reason_Label:SetColor(Color(70,70,70,255))
GUI_Reason_Label:SetParent(GUI_Fine_Frame)
GUI_Reason_Label:SetPos(10,115)
GUI_Reason_Label:SizeToContents()

local GUI_Reason_Entry = vgui.Create("DTextEntry")
GUI_Reason_Entry:SetFont("Trebuchet18")
GUI_Reason_Entry:SetSize(300,50)
GUI_Reason_Entry:SetPos(10,135)
GUI_Reason_Entry:SetEditable(true)
GUI_Reason_Entry:SetMultiline(true)
GUI_Reason_Entry:SetUpdateOnType(true)
GUI_Reason_Entry:SetParent(GUI_Fine_Frame)

local GUI_FineButton = vgui.Create("DButton")
GUI_FineButton:SetParent(GUI_Fine_Frame)
GUI_FineButton:SetSize(200,25)
GUI_FineButton:SetPos(60,183)
GUI_FineButton:SetText("")
GUI_FineButton.DoClick = function()
	if tonumber(GUI_Price_Entry:GetValue()) <= 0 then
		LocalPlayer():ChatPrint("Please enter positive value!")
		return
	end
	
	if GUI_Price_Entry:GetValue() == "" then
		LocalPlayer():ChatPrint("Please enter a price for the fine!")
		return
	end
	
	if GUI_Reason_Entry:GetValue() == "" then
		LocalPlayer():ChatPrint("Please enter a reason for the fine!")
		return
	end
	
	if tonumber(GUI_Price_Entry:GetValue()) > FINE_MaxFine then
		LocalPlayer():ChatPrint("You can only fine up to "..FINE_MaxFine.." dollars! The fine has been set to this amount.")
	end

	net.Start("RP_Fine_Player")
		net.WriteString(LocalPlayer():Nick())
		net.WriteString(GUI_Player_Entry:GetValue())
		net.WriteDouble(math.Clamp(tonumber(GUI_Price_Entry:GetValue()),0,FINE_MaxFine))
		net.WriteString(GUI_Reason_Entry:GetValue())
	net.SendToServer()

	GUI_Fine_Frame:Remove()
end
GUI_FineButton.Paint = function(CHPaint)
draw.RoundedBoxEx(8,1,1,CHPaint:GetWide()-2,CHPaint:GetTall()-2,Color(0, 0, 0, 130), false, false, true, true)

local struc = {}
struc.pos = {}
struc.pos[1] = 100 -- x pos
struc.pos[2] = 12 -- y pos
struc.color = Color(255,255,255,255) -- Red
struc.text = "Fine Player" -- Text
struc.font = "UiBold" -- Font
struc.xalign = TEXT_ALIGN_CENTER-- Horizontal Alignment
struc.yalign = TEXT_ALIGN_CENTER -- Vertical Alignment
draw.Text( struc )
end

end
usermessage.Hook("RP_FineMenu", GUI_FineMenu)

function GUI_FinedMenu(um)
local TheOfficer = um:ReadString()
local ThePrice = um:ReadLong()
local TheReason = um:ReadString()

if !LocalPlayer():Alive() then return end
if GUI_Trade_Frame then if GUI_Trade_Frame:IsValid() then return false end end
GUI_Fined_Frame = vgui.Create("DFrame")
GUI_Fined_Frame:SetTitle("")
GUI_Fined_Frame:SetSize(320,215)
GUI_Fined_Frame:Center()
GUI_Fined_Frame.Paint = function(CHPaint)
-- Draw the menu background color.		
draw.RoundedBox( 6, 0, 0, CHPaint:GetWide(), CHPaint:GetTall(), Color( 255, 255, 255, 150 ) )

-- Draw the outline of the menu.
surface.SetDrawColor(0,0,0,255)
surface.DrawOutlinedRect(0, 0, CHPaint:GetWide(), CHPaint:GetTall())

surface.SetDrawColor(0,0,0,255)
surface.DrawOutlinedRect(0, 0, CHPaint:GetWide(), 25)

-- Draw the top title.
draw.SimpleText("Fine Received", "UiBold", 60,12, Color(70,70,70,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end
GUI_Fined_Frame:MakePopup()
GUI_Fined_Frame:ShowCloseButton(false)

local GUI_Officer_Label = vgui.Create("DLabel")
GUI_Officer_Label:SetText("The Officer:")
GUI_Officer_Label:SetFont("UiBold")
GUI_Officer_Label:SetColor(Color(70,70,70,255))
GUI_Officer_Label:SetParent(GUI_Fined_Frame)
GUI_Officer_Label:SetPos(10,25)
GUI_Officer_Label:SizeToContents()

local GUI_Officer_Entry = vgui.Create("DTextEntry", GUI_Fined_Frame)
GUI_Officer_Entry:SetFont("Trebuchet18")
GUI_Officer_Entry:SetSize(300,25)
GUI_Officer_Entry:SetPos(10,45)
GUI_Officer_Entry:SetEditable(false)
GUI_Officer_Entry:SetText(TheOfficer)

local GUI_Price_Label = vgui.Create("DLabel")
GUI_Price_Label:SetText("Price:")
GUI_Price_Label:SetFont("UiBold")
GUI_Price_Label:SetColor(Color(70,70,70,255))
GUI_Price_Label:SetParent(GUI_Fined_Frame)
GUI_Price_Label:SetPos(10,70)
GUI_Price_Label:SizeToContents()

local GUI_Price_Entry = vgui.Create("DTextEntry", GUI_Fined_Frame)
GUI_Price_Entry:SetFont("Trebuchet18")
GUI_Price_Entry:SetSize(300,25)
GUI_Price_Entry:SetPos(10,90)
GUI_Price_Entry:SetEditable(false)
GUI_Price_Entry:SetText(ThePrice)

local GUI_Reason_Label = vgui.Create("DLabel")
GUI_Reason_Label:SetText("Reason:")
GUI_Reason_Label:SetFont("UiBold")
GUI_Reason_Label:SetColor(Color(70,70,70,255))
GUI_Reason_Label:SetParent(GUI_Fined_Frame)
GUI_Reason_Label:SetPos(10,115)
GUI_Reason_Label:SizeToContents()

local GUI_Reason_Entry = vgui.Create("DTextEntry", GUI_Fined_Frame)
GUI_Reason_Entry:SetFont("Trebuchet18")
GUI_Reason_Entry:SetSize(300,50)
GUI_Reason_Entry:SetPos(10,135)
GUI_Reason_Entry:SetText(TheReason)
GUI_Reason_Entry:SetMultiline(true)
GUI_Reason_Entry:SetEditable(false)

local GUI_AcceptButton = vgui.Create("DButton")
GUI_AcceptButton:SetParent(GUI_Fined_Frame)
GUI_AcceptButton:SetSize(145,25)
GUI_AcceptButton:SetPos(10,183)
GUI_AcceptButton:SetText("")
GUI_AcceptButton.DoClick = function()

net.Start("RP_Accept_Fine")
	net.WriteString(TheOfficer)
	net.WriteDouble(ThePrice)
net.SendToServer()

GUI_Fined_Frame:Remove()
end
GUI_AcceptButton.Paint = function(CHPaint)
draw.RoundedBoxEx(8,1,1,CHPaint:GetWide()-2,CHPaint:GetTall()-2,Color(0, 0, 0, 130), false, false, true, true)

local struc = {}
struc.pos = {}
struc.pos[1] = 72.5 -- x pos
struc.pos[2] = 12 -- y pos
struc.color = Color(70,70,70,255) -- Red
struc.text = "Accept Fine" -- Text
struc.font = "UiBold" -- Font
struc.xalign = TEXT_ALIGN_CENTER-- Horizontal Alignment
struc.yalign = TEXT_ALIGN_CENTER -- Vertical Alignment
draw.Text( struc )
end

local GUI_DenyButton = vgui.Create("DButton")
GUI_DenyButton:SetParent(GUI_Fined_Frame)
GUI_DenyButton:SetSize(145,25)
GUI_DenyButton:SetPos(165,183)
GUI_DenyButton:SetText("")
GUI_DenyButton.DoClick = function()

net.Start("RP_Decline_Fine")
	net.WriteString(TheOfficer)
	net.WriteDouble(ThePrice)
net.SendToServer()

GUI_Fined_Frame:Remove()
end
GUI_DenyButton.Paint = function(CHPaint)
draw.RoundedBoxEx(8,1,1,CHPaint:GetWide()-2,CHPaint:GetTall()-2,Color(0, 0, 0, 130), false, false, true, true)

local struc = {}
struc.pos = {}
struc.pos[1] = 72.5 -- x pos
struc.pos[2] = 12 -- y pos
struc.color = Color(70,70,70,255) -- Red
struc.text = "Decline Fine" -- Text
struc.font = "UiBold" -- Font
struc.xalign = TEXT_ALIGN_CENTER-- Horizontal Alignment
struc.yalign = TEXT_ALIGN_CENTER -- Vertical Alignment
draw.Text( struc )
end

end
usermessage.Hook("RP_FinedMenu", GUI_FinedMenu)

end