FINE_AllowedTeams = { -- These are the names of the jobs that are allowed to fine players.
	"Civil Protection",
	"Civil Protection Chief" -- THE LAST LINE SHOULD NOT HAVE A COMMA AT THE END. BE AWARE OF THIS WHEN EDITING THIS!
}

FINE_MayorTeam = "Mayor" -- The name of the mayor team on your server.

FINE_MaxFine = 500 -- The maximum amount an officer can fine a player. [Default = 500]
FINE_FineDistance = 80 -- The distance between the officer and the player before he/she can fine them. [Default = 80] (RECOMMENDED)
FINE_MoneyDisturbance = 1 -- The player the money from a fine should go to. This setting has 3 stages. 1, 2 and 3. 1 = The person who is fining. 2 = The mayor (if there is one). 3 = Money disappears, and is removed forever. [Default = 1]
FINE_AutoWanted = true -- true/false option whether to automatically make a player wanted a player if he declines a fine.  