if SERVER then

function FINE_ControlButton( ply )
	if ply.CantUse then 
		return 
	end
	local tr = ply:GetEyeTrace()
	
	if tr.HitNonWorld then
		if table.HasValue( FINE_AllowedTeams, team.GetName(ply:Team()) ) then
			if tr.Entity:IsPlayer() and tr.Entity:GetPos():Distance(ply:GetPos()) < FINE_FineDistance then
			
				if tr.Entity.IsBeingFined then
					ply:ChatPrint("The player is currently paying a fine!")
					return
				end
				
				if table.HasValue( FINE_AllowedTeams, team.GetName(tr.Entity:Team()) ) then
					ply:ChatPrint("The player you are trying to fine is a police officer!")
					return
				end
				
				umsg.Start("RP_FineMenu", ply)
					umsg.String(tr.Entity:Nick())
				umsg.End()
				
				ply.CantUse = true
				timer.Simple(0.5, function() 
					if ply:IsValid() then 
						ply.CantUse = false 
					end
				end)
				return
			elseif tr.Entity:IsVehicle() and tr.Entity:GetDriver():IsValid() and tr.Entity:GetPos():Distance(ply:GetPos()) < FINE_FineDistance then
				local TheDriver = tr.Entity:GetDriver()
				
				if TheDriver.IsBeingFined then
					ply:ChatPrint("The player is currently paying a fine!")
					return
				end
				
				if table.HasValue( FINE_AllowedTeams, team.GetName(TheDriver:Team()) ) then
					ply:ChatPrint("The player you are trying to fine is a police officer!")
					return
				end
				
				umsg.Start("RP_FineMenu", ply)
					umsg.String(TheDriver:Nick())
				umsg.End()
				
				ply.CantUse = true
				timer.Simple(0.5, function() 
					if ply:IsValid() then 
						ply.CantUse = false 
					end
				end)
				return
			end
		end
	end
end
hook.Add("ShowSpare1", "FINE_ControlButton", FINE_ControlButton)

util.AddNetworkString("RP_Fine_Player")
net.Receive("RP_Fine_Player", function(length, ply)
	local SenderName = net.ReadString()
	local RecieverName = net.ReadString()
	local ThePrice = net.ReadDouble()
	local TheReason = net.ReadString()

	local PlayerFound = false
	local PlayersChecked = 0

	for k, v in pairs(player.GetAll()) do
		PlayersChecked = PlayersChecked + 1
			
		if v:Nick() == RecieverName then
			PlayerFound = true
				
			umsg.Start("RP_FinedMenu", v)
				umsg.String(SenderName)
				umsg.Long(ThePrice)
				umsg.String(TheReason)
			umsg.End()
			
			v.IsBeingFined = true
					
			GAMEMODE:Notify(ply, 1, 5, "Your fine request has been send to ".. RecieverName ..".")
			break
		end
			
		if PlayersChecked == #player.GetAll() then
			if not PlayerFound then
				GAMEMODE:Notify(ply, 1, 5, "Invalid name!")
			end
		end
	end
end)

util.AddNetworkString("RP_Accept_Fine")
net.Receive("RP_Accept_Fine", function(length, ply)
	local OfficerName = net.ReadString()
	local ThePrice = net.ReadDouble()

	local OfficerFound = false
	local PlayersChecked = 0

	for k, v in pairs(player.GetAll()) do
		PlayersChecked = PlayersChecked + 1
			
		if v:Nick() == OfficerName then
			OfficerFound = true
				
			ply.IsBeingFined = false
			if ply:getDarkRPVar("money") >= ThePrice then
				ply:AddMoney( ThePrice * -1 )
			else
				GAMEMODE:Notify(ply, 1, 5, "You cannot afford to pay your $"..ThePrice.." fine.")
				GAMEMODE:Notify(v, 1, 5, ply:Nick().." could not afford to pay their fine.")
				break
			end
			GAMEMODE:Notify(ply, 1, 5, "You have paid your fine of $"..ThePrice..".")

			-- Give the money to whoever.
			if FINE_MoneyDisturbance == 1 then -- Give them to the person fining.
				v:AddMoney(ThePrice)
				GAMEMODE:Notify(v, 1, 5, ply:Nick().." has paid their $"..ThePrice.." fine. The money has been added to your wallet.")
			elseif FINE_MoneyDisturbance == 2 then -- Give them to the mayor, if there is one.
				for _, mayor in pairs(player.GetAll()) do
					if team.GetName(mayor:Team()) == FINE_MayorTeam then
						mayor:AddMoney(ThePrice)
						break
					end
				end
				GAMEMODE:Notify(v, 1, 5, ply:Nick().." has paid their $"..ThePrice.." fine. The money has been added to the mayors wallet.")
			elseif FINE_MoneyDisturbance == 3 then -- Remove them.
				GAMEMODE:Notify(v, 1, 5, ply:Nick().." has paid their $"..ThePrice.." fine. The money has been destroyed.")
			end
			
			break
		end
			
		if PlayersChecked == #player.GetAll() then
			if not OfficerFound then
				GAMEMODE:Notify(ply, 1, 5, "The officer is no longer valid!")
			end
		end
	end
end)

util.AddNetworkString("RP_Decline_Fine")
net.Receive("RP_Decline_Fine", function(length, ply)
	local OfficerName = net.ReadString()
	local ThePrice = net.ReadDouble()

	local OfficerFound = false
	local PlayersChecked = 0

	for k, v in pairs(player.GetAll()) do
		PlayersChecked = PlayersChecked + 1
			
		if v:Nick() == OfficerName then
			OfficerFound = true
			
			ply.IsBeingFined = false
			
			GAMEMODE:Notify(ply, 1, 5, "You have refused to pay your $"..ThePrice.." fine.")
			GAMEMODE:Notify(v, 1, 5, ply:Nick().." refuses to pay their $"..ThePrice.." fine.")
			
			if FINE_AutoWanted then
				ply:SetDarkRPVar("wanted", true)
				ply:SetDarkRPVar("wantedReason", "Fine Denial")
			end
			break
		end
			
		if PlayersChecked == #player.GetAll() then
			if not OfficerFound then
				GAMEMODE:Notify(ply, 1, 5, "The officer is no longer valid!")
			end
		end
	end
end)

end