RXF4_Adjust = {} RuleDB = {} function RXF4_Rule_AddTitle(Text) table.insert(RuleDB,{Type="Title",Text=Text}) end function RXF4_Rule_AddText(Text) table.insert(RuleDB,{Type="Text",Text=Text}) end
-- ^ Dont Touch
			
	-- VIPs
		-- VIP Group. ( I think  you need ULX anyway. these group are able to access VIP Shop or VIP Job )
			RXF4_Adjust.VIPGroup = {"owner","superadmin","admin","jawesome","headadmin"}

		-- VIP Shop ( if you dont want to make VIP shop, set ' true ' to ' false ' )
			RXF4_Adjust.Main_EnableVIPShop = true 
			
		-- VIP Job ( if you dont want to make VIP Job, set ' true ' to ' false ' )
			RXF4_Adjust.Main_EnableVIPJob = true
			
		
	
	-- Appearance
		-- Main Screen Size
			RXF4_Adjust.Main_Size_X = 0.8 -- 1 Mean 100% fit to your screen. screen will cover your screen. if you want half size. set this to 0.5
			RXF4_Adjust.Main_Size_Y = 0.8 -- 1 Mean 100% fit to your screen. screen will cover your screen. if you want half size. set this to 0.5
		-- Main Screen Main Text.
			RXF4_Adjust.Main_MainText = "Main Menu"
			
			
	-- Menu Panel
		-- HTML Panel
			-- Set home url
				RXF4_Adjust.HTML_URL = "http://xterriorgaming.net/"





	-- Custom Rule ( You may know what ' RXFR_Rule_AddTitle ' and ' RXF4_Rule_AddText '  thing does )
		RXF4_Rule_AddTitle("Rule")
		RXF4_Rule_AddText[[ Server Rules
The MOTD is your warning!

Key Rules

RDM= This is when you kill someone or attempt to start a fight/deathmatch with someone for no valid RP reason (E.G "He has an annoying voice lets kill him")

NLR= This is when you are killed, you may NOT return to the spot you died in for atleast 5mins and everything that happened before you died you must forget. (Pretend to forget)

Fear RP = This is when there is a gun pointed towards you, you must roleplay as if you are scared for your life and that this person might actually kill me (E.G "Cops pull a gun to you, you are scared they may do something to you, better listen")

Meta Gaming = Using In-Character information, obtained via Out Of Character means, to gain an advantage in a roleplay scenario. Including but not limited to:
- Using non-coded advertisements to communicate with other players, eg: Bill: "/advert Bob come to your shop!" Bob: "/advert Okay!"
- Non-rp eavesdropping such as hearing through multiple walls where no windows or doors are nearby to those talking.
- Using ooc discusions about bases and crimes and the like, to generate IC suspicions or entice IC actions of any other kind unless a specific event is being organized in which all involved parties agree on OOC organization.
- Identifying rp names and building/prop/vehicle owners by the floating text that would otherwise not be there in a strict rp sense, without properly roleplaying some form of investigation or inquiry with persons nearby to or using the property in question.

Power Gaming =Forcing roleplay upon a person that unfairly strips away any chance of them roleplaying a defense or attempt to converse their way out of a potentially negative situation, including but not limited to:
- Rushing a slow typer/talker or person who is lagging during a mugging, police confrontation, etc, in such a manner that you do not give them time to respond before harming/killing them.
- As a police officer, making up false reasons to tail someone or making accusations of illegal goods being on a person/property without having any actual in-character reason for suspicion or without planting illegal items as a corrupt officer, PRIOR to making such accusations - then forcing this false roleplay in a way that leads to arrests, wanted status or warrants, knowing that it was entirely fabricated. (note that this scenario would also be a breach of metagaming)
- etc.

Please read the rest of the rules



General
* No Custom/Black/Neon Phys gun colours.(Custom is to have a different colour to the range of colours provided with "c" menu, this includes it being Brighter or Dimmer)
* Do not pickpocket without roleplaying with the victim! This means instead of just using the swep on someone who is busy roleplaying, actually interact with them or set them up in a way that gives valid opportunity for roleplayed defense.
* Do not pickpocket an AFK player!
* Do pickpocket the same player more than once every 5 minutes.
* Do not RDM(Random Death match). For example; Do not kill someone with out a valid RP reason.
* Do not break NLR(New Life Rule). If you die, you are to consider it as being taken to hospital and waking up with total amnesia regarding the events of your admittance to hospital. {Wait a minimum of FIVE(5) minutes before returning to the scene}
* Do not prop spam!
* Do not prop climb! Except in the case of properly constructed ladders no longer than the visible ladder prop used(can explain and demonstrate in-game to those not sure how this is done)
* Do not prop fly/surf/kill!
* Do not fist whore!
* Do not Discriminate against Age, Gender or Race!
* All demotes must be discussed in OOC and you must provide ample time for the user getting demoted to provide an argument to defend himself.
* No revenge demotes, If someone demotes you, you do not demote him back, if it is an unjust demote against you, report it to an admin!
* Do not Hack/Exploit/Cheat/DOS/DDOS!
* Do not 'minge' or Troll or negatively impersonate other persons in any way(including racial stereotyping)! This counts as Fail RP.
* Do not disrespect the admins, they are here to keep the server running properly.
* Admin's decision is final, do not complain about the final decision! If you disagree with an admin's decision, you have the right to appeal it calmly on the forums, wait 5 minutes to cool down if need be.
* Strictly no black or neon physguns!
* No camera spam.
* No microphone spamming! This can include playing music with out having the Entertainer job and being obnoxiously loud or idiotic on mic.
* No neon player colors.
* You must have a realistic RP name. E.G (Type: /rpname "First name" "Last name", e.g /rpname John Smith.)(Titles such as Dr for doctor or police ranks for example, are okay.)
* Do not sell off your donator privileges, for example; selling printers to people that aren't donators!
* Do not sell your job to someone for money, if you are not using your job and someone asks for it, you give it to them! However, serious roleplayers with a business operation will be given preference over people demanding that they raid excessively as a gang/mafia leader.
* Do not prop block valuables or yourself or other players!
* If there is no mayor or there is a mayor without laws, then Australian laws are in effect! E.G Strict gun laws.
* No stealing unless your job is thief! E.G if you're a citizen and you see an unlocked car then you can not get in it and drive away.
* You cannot use drugs to unrealistically evade police/robbers or break into another person's property. Some 'stunts' may be permitted but be sensible.

Building/Construction
* Only one Keypad activated fading door per base!
* Only one button activated fading door per base!
* You CAN shoot a keypad cracker or person lockpicking a door, chair(why would you even?) or vehicle you own!* As this, in any sane person's mind, would be considered a hostile action towards them and/or their property.
* No fading door activated shooting windows!
* You may propblock your base WHILE you are building and as long as there are NO valuables inside the base. E.G Printers, shipments, guns, etc...
* No building on the road, however, you may use the sidewalk, except for police performing non-frozen roadblocks(Max total weight of all props used in a block = 4000)
* No "KOS" signs! For example; No signs saying that if you enter a certain room or cross a certain line, you die!
* Do not tamper with other peoples buildings or props!
* Do not break breakable props that are not yours!
* Do not spawn props in other people's bases with out their consent!
* Custom walls/fences can not be bigger than the 4x4 physics prop.* Unless otherwise rp friendly, subject to admin discretion.
* All fading doors must be crackable and all basses must have at least 1 entrance!
* All fading doors must be 4 seconds in length!
* All buildings must be realistic! For example; A floating base with out any support is unrealistic, so are obnoxious deathforts and traps.
* You are not aloud to have props that are no-collided so that you can get the upper hand with raids!
* No invisible props!* Sometimes props like chairs or lights or wire gizmos or support platforms(for entities, not climbing-except with ladders mentioned above) need to be invisible to maintain realistic themes and afford functionality to a set-up.
* Tunneling is not allowed! E.G Forcing someone to crouch to get into a base or crack a keypad/pick a door.
* No wire keypads for fading doors!
* No wire buttons for fading doors!
* All shooting windows must be as thick as a 1x1 block!
* All buttons/keypads must be next to the prop it fades and clearly visible!
* Do not printer bomb! E.G putting a printer on fire and putting it inside someones base or next to someone!
* Do not change the material of the camera!

Combat Rules
* No bunny hopping when in combat!
* You must role play as if you were afraid of any weapons! E.G If someone has a gun to your head, then you would do what he says because you're afraid that he will shoot you. HOWEVER, if you are the person pointing a gun at someone and they have a clear window where you are not focusing on them - they MAY attempt to escape or defend themselves - fair is fair do not abuse fearRP to powergame if you couldn't focus on your victim.
* When raiding, do not harm anyone that is unarmed or that is not deemed as a threat/participating.
* Medics can not heal while in combat unless the injury is properly roleplayed by both patient and doctor.
* You can't buy armor or health at any time during combat.

Vehicles
* Drive slowly when on the streets!
* If you run someone over, get out the car and RP it! E.G Try and help them or call a doctor!
* When driving on the street, drive on the left side of the road!
* If making a custom car, make sure that it is realistic! E.G The car seat must be in a realistic position.
* Do not phys gun your car unless you're customizing it!
* Do freeze or trap your vehicle, especially when a thief is stealing it. (Cars specific to a players job are OFF LIMITS to potential thieves of any kind.)

Job and Demotion Rules:

* Do as your job title says, do not abuse it or become something that you aren't even using. You also can't use the custom job (/job) to become another class, e.g. a Citizen pretending to be a Police Officer.
* If you choose a job you must RP that job. E.g. a car dealer not selling cars, a gun dealer not selling guns.
* Don't abuse jobs just to get their benefits. E.g. a gangster going gun dealer, buying a gun/shipment and then going back to gangster.
* You must discuss all demotions for at least 1 minute, and ask if anyone wants to object. If there are valid objections from people other than the person being demoted, then you must drop the demotion.
* Do not demote someone just because you dislike them or you want their job. The demotion system is designed to remove people from jobs they are abusing (or demoting corrupt police/mayor when they are arrested with evidence of being corrupt).
* Do NOT sell/buy any jobs

Assassin
* Assassin is a class for donators only.
* If you kill a person without a valid RP reason, that's RDM and you will be punished for doing so.
* If you don't know why the client wanted the person dead, then it means you're not doing your job properly.
* Assassin is to be paid half when they accept the hit, and half when the target has been killed.
* The client should have a clear sight of the target being killed, so they know they aren't being @#$%ed over.
* If the Assassin is arrested during the job, the hit is failed and the contract is terminated.
* Minimum price for a hit is $250.
* You may only place 1 hit every 5 minutes with a very solid reason.
* If you are caught abusing the class it will result in a permanent ban from hitman or demotion.
* Your grapple gun is ONLY to be used in life-threatening situations, such as when you¡¯re being shot at. Using at any other time is grounds for demotion.
* The grapple gun is a 2-handed crossbow, hence it's illegal. If you have it out in public you will most likely be arrested!

Cook
* Make a public microwave before making a store but move it in to your shop and roleplay the sale of food properly as soon as you finish building, will be enforced heavily once hungermod is fixed.
* Do not spawn a microwave then not sell food to the public.
* No stealing microwaves - period. It's a @#$%ing microwave, who steals... a goddamn microwave? Buy one of a cook IF THEY CHOOSE TO SELL ONE. It's considered failRP to steal a microwave.
* You can change the price of a microwave with /setprice followed by the amount, be reasonable, you're not selling bananas made out of mono-atomic gold.

Thief
* Do not pickpocket without roleplaying with the victim! This means instead of just using the swep on someone who is busy roleplaying, actually interact with them or set them up in a way that gives valid opportunity for roleplayed defense.
* Do not pickpocket an AFK players!
* Do pickpocket the same player more than once every 5 minutes.
* You are not allowed to mug in public, and you can only mug with a pistol or melee weapon.
* You can only mug once every 10 minutes max aloud to take is $300 (and you can't kill someone if they have no money). * You must be fair with your demands and patient with the occasional player who may be slow to type or roleplay, rushing a victim with mic domination then killing them for "not doing what I said" and demanding obscene amounts of cash that would never realistically be in somebody's wallet are forms of powergaming and a morbidly severe breach of fair-chance sportsmanship in a roleplay environment. Bans WILL be given for unfair use of the thief class, ignorance to these rules is no excuse.
* Make yourself useful (make a carnival and scam people, etc).
* You are NOT allowed to work with any group, such as the Mafia, the Gang or the Police.
* Thieves are only allowed to be in a pair of 2 only. All other 2 thieves are considered enemies, and you are to treat them as such.

Gun Dealer/Military Arms Dealer
* You CAN work as a private supplier, so long as there is at least one PUBLIC Gun Dealer and you do not participate in any group activities (e.g. raiding with the Mafia).

Police, Police Chief
* Cops do not make the laws, they enforce them.
* Corruption is allowed, but you must announce this in your job title, e.g. "Corrupt Police Chief"
* The arresting officer must offer bail, no one else may offer bail. Bail must be appropriate to the list of charges.
* Police have the right to refuse bail if you've committed a violent offence.
* Do not random wanted/warrant/weapon check or you will be punished.
* Cops/SWAT are not allowed to charge with an arrest baton at a person if people have guns out. This is called ¡®Baton Rushing¡¯, it is a very severe breach of the rules and will be dealt with swiftly. If someone has a gun out and is breaking the law, you can shoot to warn or wound them, you CANNOT arrest them until they cease being an immediate threat to the lives of others, in which case it'se likely that you will need to put them down anyway.

Prime Minister
* The laws are those of Australia today if there is no Prime Minister.
* Corruption is allowed, but you must announce it in your job title (i.e. "Corrupt Prime Minister")
* Your job is to keep the city under control, enact an agenda and administrate vendor licensing in the town, etc.
* You must approve/deny warrants for valid reasons.
* You may own a pistol, but no other gun.
* You must never participate in police raids. EVER!
* Use the lockdown function only when necessary, and you must give a reason before starting the lockdown.
* You MUST use /broadcast to transmit a 'live' in-character message feed to the city, NOT /ADVERT OR OOC!

S.W.A.T.
* This is a donator only class.
* Only go to this job when there is already at least one Police Officer.
* S.W.A.T. are only for providing backup on police raids and to support police in a dangerous situation? they DO NOT enforce the law on the streets, that is the job of the Police.
* Only use your grenade launcher when absolutely necessary, it¡¯s a dangerous weapon.
* SWAT may not base(Make a base and defend it as swat.)

S.W.A.T Medic
* Only heal police,prime minister or police no one else.
* Make sure you roleplay each heal.

Hobo
* You can only buy melee weapons or pistols, if you find a larger weapon on the street that is acceptable.
* Bugbait is only to decorate your own place. Spamming it will result in a ban.
* You can sing for money on the side of the street, but this is at the Police¡¯s discretion. (Or an admin if they deem it undesirable)
* Hobos cannot buy weapons and act as gangsters, e.g. hobos pretending to be terrorists, running around shooting people.* Unless a well-thought scenario is presented to an admin prior to anything being enacted.

Drug Dealer
* You sell and manufacture drugs.
* Drug dealers who set their job to 'Chemist' may legally supply reasonable drugs to a Doctor for him to prescribe to patients in roleplay scenarios, to free up room for better laws and promote more realistic roleplay for Doctors.

Mafia/Gangster
* You can only raid someone with the Mafia Leader/Gang Leader present, if the Mafia/Gang Leader dies the raid is automatically over and all members still alive must submit to arrest or retreat IMMEDIATELY.
* You CANNOT mug players.

Doctor
* You can work as a Private Doctor, but only on the condition that there is at least one other Public Doctor.
* Do NOT 'heal' people for free.
* Do NOT 'heal' a person or yourself during combat.
* Do NOT 'heal' on the streets, roleplay your job properly and charge appropriately according to the service provided respectively to each patient.

Security Guard
* You are hired by shopkeepers to watch over their property.
* You cannot work for free and you cannot work for Mafia, Gang, Police or Thieves either.

Car Dealer
* You sell cars/airboats to players.
* Do NOT switch to this class just to buy yourself a car/airboat.
* Do NOT just drive around the map. Set up a car dealership or offer a taxi service.

Banker
* You store other peoples¡¯ items in a secure location.
* Don't go banker just to farm money printers.
* Don't steal other peoples' items, you're not a thief.
* You should generally hire security guards to help defend them.
* You can store items which are deemed illegal, so long as the police say so.

Mafia Leader/Gang leader
* Do NOT choose this job because thief is full and you want to rob places
* You can request shop owners to buy protection money from you
* You can bribe the police to avoid any crimes you have/will commit
* You MUST have at least one member of your group with you while raiding, if you die the whole group must submit to arrest or retreat.

This is your Only warning if these rules are broken expect consensuses.]]
		