
wyozite.COLOR_WHITE = Color(255, 255, 255)

function wyozite.OverrideVGUI()
	local oldrow = vgui.GetControlTable("TTTScorePlayerRow")

	local oldinit = oldrow.Init
	function oldrow:Init()
		oldinit(self)

		self.cols[5] = vgui.Create("DLabel", self)
		self.cols[5]:SetText("")
	end

	if not wyozite.DontUseContextMenu then
		function oldrow:DoRightClick()
			local menu = DermaMenu()
			if hook.Call("WTEHasPermission", gmod.GetGamemode(), LocalPlayer(), "setsbcolor", self.Player) then
				menu:AddOption("Modify name color", function()

					local Frame = vgui.Create( "DFrame" ) 
					Frame:SetSize( 267,186 )
					Frame:Center()
					Frame:MakePopup()
					Frame:SetTitle("Select name color")

					local Mixer = vgui.Create( "DColorMixer", Frame )
					Mixer:Dock( FILL )		
					Mixer:SetPalette( true ) 
					Mixer:SetAlphaBar( false )
					Mixer:SetWangs( true )	

					local v = self.Player:GetNWVector("wte_sbclr")
					Mixer:SetColor( (v and (v.x ~= 0 or v.y ~= 0 or v.z ~= 0)) and Color(v.x,v.y,v.z) or Color(255, 255, 255) )

					Frame.OnClose = function()
						if not IsValid(self.Player) then return end
						local clr = Mixer:GetColor()
						hook.Call("WTESetNameColor", gmod.GetGamemode(), self.Player, clr)
						--RunConsoleCommand("ulx", "setsbcolor", "$" .. tostring(self.Player:UniqueID()), tostring(clr.r), tostring(clr.g), tostring(clr.b))
					end
				end):SetIcon("icon16/color_wheel.png")
			end
			if hook.Call("WTEHasPermission", gmod.GetGamemode(), LocalPlayer(), "setsbtagcolor", self.Player) then
				menu:AddOption("Modify tag color", function()

					local Frame = vgui.Create( "DFrame" )
					Frame:SetSize( 270, 166*2 + 45 )
					Frame:Center()
					Frame:MakePopup()
					Frame:SetTitle("Select tag color")

					local Mixer = vgui.Create( "DColorMixer", Frame )
					Mixer:SetPos(0, 22)
					Mixer:SetSize( 267, 166)
					Mixer:SetPalette( true ) 
					Mixer:SetAlphaBar( false )
					Mixer:SetWangs( true )	

					local lbl = vgui.Create("DLabel", Frame)
					lbl:SetText("Glow color (set to solid black to disable):")
					lbl:SetPos(10, 187)
					lbl:SetSize(200, 20)

					local Mixer2 = vgui.Create( "DColorMixer", Frame )
					Mixer2:SetPos(0, 207)
					Mixer2:SetSize( 267, 166)
					Mixer2:SetPalette( true ) 
					Mixer2:SetAlphaBar( false )
					Mixer2:SetWangs( true )

					local v = self.Player:GetNWVector("wte_sbtclr")
					Mixer:SetColor( (v and (v.x ~= 0 or v.y ~= 0 or v.z ~= 0)) and Color(v.x,v.y,v.z) or Color(255, 255, 255) )
					local v = self.Player:GetNWVector("wte_sbtclr2")
					Mixer2:SetColor( (v and (v.x ~= 0 or v.y ~= 0 or v.z ~= 0)) and Color(v.x,v.y,v.z) or Color(0, 0, 0) )

					Frame.OnClose = function()
						if not IsValid(self.Player) then return end
						local clr, clr2 = Mixer:GetColor(), Mixer2:GetColor()
						hook.Call("WTESetTagColor", gmod.GetGamemode(), self.Player, clr, clr2)
						--RunConsoleCommand("ulx", "setsbtagcolor", "$" .. tostring(self.Player:UniqueID()), tostring(clr.r), tostring(clr.g), tostring(clr.b))
					end
				end):SetIcon("icon16/tag_blue.png")
			end
			if hook.Call("WTEHasPermission", gmod.GetGamemode(), LocalPlayer(), "setsbtagtext", self.Player) then
				menu:AddOption("Modify tag text", function()

					local Frame = vgui.Create( "DFrame" )
					Frame:SetSize( 267, 60 )
					Frame:Center()
					Frame:MakePopup()
					Frame:SetTitle("Select tag text")

					local Mixer = vgui.Create( "DTextEntry", Frame )
					Mixer:Dock( FILL )
					Mixer:SetText(self.Player:GetNWString("wte_sbtstr") or "")

					Mixer:RequestFocus()

					local function WeBeDone()
						if not IsValid(self.Player) then return end
						hook.Call("WTESetTagText", gmod.GetGamemode(), self.Player, Mixer:GetText())
						--RunConsoleCommand("ulx", "setsbtagtext", "$" .. tostring(self.Player:UniqueID()), Mixer:GetText())
					end

					Frame.OnClose = WeBeDone
					Mixer.OnEnter = function() Frame:Close() end
				end):SetIcon("icon16/tag_blue_edit.png")
			end
			menu:Open()
		end
	end

	--local oldupd = oldrow.UpdatePlayerData
	function oldrow:Think()
		if not IsValid(self.Player) then return end

		local v, v2 = self.Player:GetNWVector("wte_sbtclr"), self.Player:GetNWVector("wte_sbtclr2")
		local clr = wyozite.COLOR_WHITE
		if v and (v.x ~= 0 or v.y ~= 0 or v.z ~= 0) then
			if v2 and (v2.x ~= 0 or v2.y ~= 0 or v2.z ~= 0) then
				local v3 = LerpVector((math.sin( CurTime()*2 )+1)/2, v, v2)
				clr = Color(v3.x, v3.y, v3.z)
			else
				clr = Color(v.x, v.y, v.z)
			end
		end

		local txt = self.Player:GetNWString("wte_sbtstr") or ""

		local usergroup
		if self.Player.GetUserGroup then
			usergroup = self.Player:GetUserGroup()
		elseif self.Player:IsAdmin() then
			usergroup = "admin"
		elseif self.Player:IsSuperAdmin() then
			usergroup = "superadmin"
		end

		if wyozite.MakeRanksDefaultTags and txt == "" and (not wyozite.DontShowUserRank or usergroup ~= "user" ) then
			txt = usergroup
			if wyozite.RankColors then
				clr = wyozite.RankColors[txt] or wyozite.COLOR_WHITE
			end
			txt = txt == "vip" and "VIP" or (txt:gsub("^%l", string.upper))
		end

		self.cols[5]:SetText(txt)
		self.cols[5]:SetColor(clr)

	end

	local oldpl = oldrow.PerformLayout
	function oldrow:PerformLayout()
		oldpl(self)

		if self.cols and self.cols[5] then
			self.cols[5]:SetWide(250)
			local x,y = self.cols[5]:GetPos()
			self.cols[5]:SetPos(x-150, y)
		end
	end

	vgui.Register("TTTScorePlayerRow", oldrow, "Button")

	local oldmain = vgui.GetControlTable("TTTScoreboard")

	local oldinit = oldmain.Init
	function oldmain:Init()
		oldinit(self)

		self.cols[5] = vgui.Create("DLabel", self)
		self.cols[5]:SetText("Tag")

	end

	local oldpl = oldmain.PerformLayout
	function oldmain:PerformLayout()
		oldpl(self)

		if self.cols and self.cols[5] then
			self.cols[5]:SetWide(250)
			local x,y = self.cols[5]:GetPos()
			self.cols[5]:SetPos(x-150, y)
		end
	end

	vgui.Register("TTTScoreboard", oldmain, "Panel")
end

hook.Add("Initialize", "WyoziTEOverrideScoreboardGuis", wyozite.OverrideVGUI)

concommand.Add("wyozite_reloadscoreboard", function()
	GAMEMODE:ScoreboardCreate()
	wyozite.OverrideVGUI()
end)
