ENT.Type 				= "anim";
ENT.Base 				= "base_anim";
ENT.PrintName			= "Mayor Voting NPC";
ENT.Author				= "Chuteuk";
ENT.Purpose				= "Used for mayor election system.";

ENT.Spawnable			= false;
ENT.AdminSpawnable		= false;

function ENT:OnRemove()
end