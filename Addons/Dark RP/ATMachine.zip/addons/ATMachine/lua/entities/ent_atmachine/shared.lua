ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "ATMachine"
ENT.Author = "Barel"