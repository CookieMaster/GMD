AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "config.lua" )

include('shared.lua')
include('config.lua')

function ENT:Initialize( )
	self:SetModel( atmModel )
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_NONE)
	self:SetSolid(SOLID_VPHYSICS)
end

util.AddNetworkString("ATMScreen")

function ENT:Use( Activator, Caller )	
	if !Activator.cantUse and Activator:IsPlayer() then
		Activator.cantUse = true
		net.Start( "ATMScreen" )
		net.Send( Activator )
		timer.Simple(1.5, function()
			Activator.cantUse = false
		end)
	end
end