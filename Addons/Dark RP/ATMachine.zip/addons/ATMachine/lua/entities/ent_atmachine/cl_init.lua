include('shared.lua')
include('config.lua')


function ENT:Draw()
	self:DrawModel()
	local atmPos = self:GetPos()
	cam.Start3D2D( Vector(atmPos.x, atmPos.y - 15, atmPos.z + 25) , Angle(0,0,90), 0.3 )
			draw.SimpleTextOutlined( atmText, "Trebuchet22", 0, 0, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,50) )
	cam.End3D2D()
end

function ATMachine()
	local selectAmountMod
	local atmAmountEntry
	local atmAmountEntryButton
	local atmFrame = vgui.Create( "DFrame" )
	atmFrame:SetSize(643, 505)
	atmFrame:SetPos(ScrW() / 2 - (640 / 2), ScrH() / 2 - (480 / 2))
	atmFrame:SetDraggable( true )
	atmFrame:MakePopup()
	atmFrame:SetTitle("ATM Machine")

	local atmBackground = vgui.Create( "DImage", atmFrame )
	atmBackground:SetImage("atmbg.png")
	atmBackground:SetSize(640,480)
	atmBackground:SetPos(1,23)

	local atmScreen = vgui.Create( "DPanel", atmFrame )
	atmScreen:SetPos(100,85)
	atmScreen:SetSize(447,351)
	atmScreen.Paint = function()

	end

	local atmScreenLabel1 = vgui.Create( "DLabel", atmScreen )
	atmScreenLabel1:SetText("SELECT AMOUNT TO WITHDRAW\n\nYOUR BALANCE: " ..LocalPlayer():GetNWInt("moneyBank").. " $")
	atmScreenLabel1:SizeToContents()
	atmScreenLabel1:SetPos( atmScreen:GetWide() / 2 - (atmScreenLabel1:GetWide() / 2), 15 )

	surface.CreateFont( "atmNumbers", {
		font = "Arial",
		size = 31,
		weight = 500,
		blursize = 0,
		scanlines = 0,
		antialias = true
	} )

	local atmScreenLabel2 = vgui.Create( "DLabel", atmScreen )
	atmScreenLabel2:SetText("<  $ " .. atmAmounts[1] .. "\n\n<  $ " ..atmAmounts[2].. "\n\n<  $ " .. atmAmounts[3] .. "\n\n<  $ " ..atmAmounts[4].. "")
	atmScreenLabel2:SetFont("atmNumbers")
	atmScreenLabel2:SizeToContents()
	atmScreenLabel2:SetPos( 10, 95 )

	local atmScreenLabel3 = vgui.Create( "DLabel", atmScreen )
	atmScreenLabel3:SetText("     " .. atmAmounts[5] .. " $ >\n\n     " .. atmAmounts[6] .. " $ >\n\n   OTHER >\n\nDEPOSIT >")
	atmScreenLabel3:SetFont("atmNumbers")
	atmScreenLabel3:SizeToContents()
	atmScreenLabel3:SetPos( 305, 95 )

	local atmButton1 = vgui.Create( "DButton", atmFrame )
	atmButton1:SetText(" ")
	atmButton1:SetSize(36,36)
	atmButton1:SetPos(15,180)
	atmButton1.DoClick = function()
		LocalPlayer():ConCommand("ATM_withdrawMoney " .. atmAmounts[1])
		updateStatus(3)
	end
	local atmButton2 = vgui.Create( "DButton", atmFrame )
	atmButton2:SetText(" ")
	atmButton2:SetSize(36,36)
	atmButton2:SetPos(15,242)
	atmButton2.DoClick = function()
		LocalPlayer():ConCommand("ATM_withdrawMoney " .. atmAmounts[2])
		updateStatus(3)
	end
	local atmButton3 = vgui.Create( "DButton", atmFrame )
	atmButton3:SetText(" ")
	atmButton3:SetSize(36,36)
	atmButton3:SetPos(15,303)
	atmButton3.DoClick = function()
		LocalPlayer():ConCommand("ATM_withdrawMoney " .. atmAmounts[3])
		updateStatus(3)
	end
	local atmButton4 = vgui.Create( "DButton", atmFrame )
	atmButton4:SetText(" ")
	atmButton4:SetSize(36,36)
	atmButton4:SetPos(15,365)
	atmButton4.DoClick = function()
		if selectAmountMod == true then
			customAmountMod(2, 2)
		else
			LocalPlayer():ConCommand("ATM_withdrawMoney " .. atmAmounts[4])
			updateStatus(3)
		end
	end
	local atmButton5 = vgui.Create( "DButton", atmFrame )
	atmButton5:SetText(" ")
	atmButton5:SetSize(36,36)
	atmButton5:SetPos(592,180)
	atmButton5.DoClick = function()
		LocalPlayer():ConCommand("ATM_withdrawMoney " .. atmAmounts[5])
		updateStatus(3)
	end

	local atmButton6 = vgui.Create( "DButton", atmFrame )
	atmButton6:SetText(" ")
	atmButton6:SetSize(36,36)
	atmButton6:SetPos(592,242)
	atmButton6.DoClick = function()
		LocalPlayer():ConCommand("ATM_withdrawMoney " .. atmAmounts[6])
		updateStatus(3)
	end
	local atmButton7 = vgui.Create( "DButton", atmFrame )
	atmButton7:SetText(" ")
	atmButton7:SetSize(36,36)
	atmButton7:SetPos(592,301)
	atmButton7.DoClick = function()
		customAmountMod(1, 1)
	end 

	local atmButton8 = vgui.Create( "DButton", atmFrame )
	atmButton8:SetText(" ")
	atmButton8:SetSize(36,36)
	atmButton8:SetPos(592,365)
	atmButton8.DoClick = function()
		customAmountMod(1, 2)
	end

	function customAmountMod(option, mod)
		if option == 1 then
			atmButton1:SetDisabled( true )
			atmButton2:SetDisabled( true )
			atmButton3:SetDisabled( true )
			atmButton5:SetDisabled( true )
			atmButton6:SetDisabled( true )
			atmButton7:SetDisabled( true )
			atmButton8:SetDisabled( true )
			atmScreenLabel2:SetText("\n\n\n\n\n\n< BACK")
			atmScreenLabel3:SetText("")
			atmAmountEntry = vgui.Create( "DTextEntry", atmScreen )
			atmAmountEntry:SetWide(150)
			atmAmountEntry:SetPos(atmScreen:GetWide() / 2 - (atmAmountEntry:GetWide() / 2), atmScreen:GetTall() / 2 - (atmAmountEntry:GetTall() / 2))
			atmAmountEntryButton = vgui.Create( "DButton", atmScreen )
			if mod == 1 then
				atmScreenLabel1:SetText("ENTER AMOUNT TO WITHDRAW\n\nYOUR BALANCE: " ..LocalPlayer():GetNWInt("moneyBank").. " $")
				atmAmountEntryButton:SetText("Withdraw")
			elseif mod == 2 then
				atmScreenLabel1:SetText("ENTER AMOUNT TO DEPOSIT\n\nYOUR BALANCE: " ..LocalPlayer():GetNWInt("moneyBank").. " $")
				atmAmountEntryButton:SetText("Deposit")
			end
			atmAmountEntryButton:SetPos(atmScreen:GetWide() / 2 - (atmAmountEntryButton:GetWide() / 2), atmScreen:GetTall() / 2 - (atmAmountEntryButton:GetTall() / 2) + 25)
			atmAmountEntryButton.DoClick = function()
				if mod == 1 then
					LocalPlayer():ConCommand("ATM_withdrawMoney " .. atmAmountEntry:GetValue())
					updateStatus(1)
				elseif mod == 2 then
					LocalPlayer():ConCommand("ATM_depositMoney " .. atmAmountEntry:GetValue())
					updateStatus(2)
				end
			end
			selectAmountMod = true
		elseif option == 2 then
			atmButton1:SetDisabled( false )
			atmButton2:SetDisabled( false )
			atmButton3:SetDisabled( false )
			atmButton5:SetDisabled( false )
			atmButton6:SetDisabled( false )
			atmButton7:SetDisabled( false )
			atmButton8:SetDisabled( false )
			atmScreenLabel3:SetText("     " .. atmAmounts[5] .. " $ >\n\n     " .. atmAmounts[6] .. " $ >\n\n   OTHER >\n\nDEPOSIT >")
			atmScreenLabel2:SetText("<  $ " .. atmAmounts[1] .. "\n\n<  $ " ..atmAmounts[2].. "\n\n<  $ " .. atmAmounts[3] .. "\n\n<  $ " ..atmAmounts[4].. "")
			atmScreenLabel1:SetText("SELECT AMOUNT TO WITHDRAW\n\nYOUR BALANCE: " ..LocalPlayer():GetNWInt("moneyBank").. " $")
			atmAmountEntryButton:Remove()
			atmAmountEntry:Remove()
			selectAmountMod = false
		end
	end

	function updateStatus(mod)
		timer.Simple(0.5, function()
			if mod == 1 then
				atmScreenLabel1:SetText("ENTER AMOUNT TO WITHDRAW\n\nYOUR BALANCE: " ..LocalPlayer():GetNWInt("moneyBank").. " $")
			elseif mod == 2 then
				atmScreenLabel1:SetText("ENTER AMOUNT TO DEPOSIT\n\nYOUR BALANCE: " ..LocalPlayer():GetNWInt("moneyBank").. " $")
			elseif mod == 3 then
				atmScreenLabel1:SetText("SELECT AMOUNT TO WITHDRAW\n\nYOUR BALANCE: " ..LocalPlayer():GetNWInt("moneyBank").. " $")
			end
		end)
	end
end
net.Receive( "ATMScreen", ATMachine )