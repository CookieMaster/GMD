--Position of the ATM
local spawnPosition = { 
					Vector(-71, -33, -12287)
				}
local spawnAngle = { 
					Angle(0, 270, 0)
				}
--Option to increase the money
local enableIncreaseMoney = false -- If you want to enable the option change it to true. if you don't want, change it to false.
local increaseTime = 1800 -- In seconds
local increaseRate = 2 -- Percents

resource.AddFile("materials/atmbg.png")

function createATM()
	for k,v in pairs(spawnPosition) do
		local ent = ents.Create("ent_atmachine")
		ent:SetPos(spawnPosition[k])
		ent:SetAngles(spawnAngle[k])
		ent:Spawn()
	end
end
hook.Add( "Initialize", "crateATM", createATM)

function loadPlayer( pl )
	local userDataFile = "atmachine/" .. string.Replace(pl:SteamID(),":","_") .. ".txt"
	if file.Exists(userDataFile, "DATA" ) then
		local playerData = file.Read(userDataFile, "DATA")
		pl:SetNWInt("moneyBank", tonumber(playerData))
	else
		file.Write(userDataFile, 0)
		pl:SetNWInt("moneyBank", 0)
	end
end
hook.Add( "PlayerInitialSpawn", "loadPlayer", loadPlayer )

function depositMoney(pl, cmd, arg)
	if pl:CanAfford(tonumber(arg[1])) then
		pl:SetNWInt("moneyBank", pl:GetNWInt("moneyBank") + tonumber(arg[1]))
		saveData(pl)
		pl:AddMoney(-tonumber(arg[1]))
		pl:ChatPrint("You have been deposited " ..arg[1].. " $")
	else
		pl:ChatPrint("You don't have enough money")
	end
end
concommand.Add("ATM_depositMoney", depositMoney)

function withdrawMoney(pl, cmd, arg)
	if pl:GetNWInt("moneyBank") >= tonumber(arg[1]) then
		pl:SetNWInt("moneyBank", pl:GetNWInt("moneyBank") - tonumber(arg[1]))
		saveData(pl)
		pl:AddMoney(tonumber(arg[1]))
		pl:ChatPrint("You have been withdrawn " ..arg[1].. " $")
	elseif pl:GetNWInt("moneyBank") < tonumber(arg[1]) then
		pl:ChatPrint("You don't have enough money in the bank")
	end
end
concommand.Add("ATM_withdrawMoney", withdrawMoney)

function saveData(pl)
	local userDataFile = "atmachine/" .. string.Replace(pl:SteamID(),":","_") .. ".txt"
	file.Write(userDataFile, pl:GetNWInt("moneyBank"))
	print("Data Saved!")
end

local nextTime = increaseTime
function increaseMoney()
	if enableIncreaseMoney == true then
		if nextTime <= math.Round(CurTime()) then
			nextTime = math.Round(CurTime()) + increaseTime
			for k,v in pairs(player.GetAll()) do
				v:SetNWInt("moneyBank", math.Round(v:GetNWInt("moneyBank") + (v:GetNWInt("moneyBank") * (increaseRate / 100))))
				saveData(v)
				v:ChatPrint("Your Money in the bank increased by "..increaseRate.." percent")
			end
		end
	end
end
hook.Add("Think", "increaseMoney", increaseMoney)