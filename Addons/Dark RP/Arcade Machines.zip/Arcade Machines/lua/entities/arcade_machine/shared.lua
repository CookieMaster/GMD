ENT.Base = "base_ai" 
ENT.Type = "anim"
 
ENT.PrintName		= "Arcade Machine"
ENT.Author			= "Crap-Head"
ENT.Contact			= ""
ENT.Purpose			= ""
ENT.Instructions	= ""