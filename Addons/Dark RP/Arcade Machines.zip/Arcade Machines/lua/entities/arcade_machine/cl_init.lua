include("shared.lua")

surface.CreateFont("ArcadeDefault", {
	font = "Tahoma", 
	size = 14, 
	weight = 600
})

surface.CreateFont("ArcadeSmall", {
	font = "Tahoma", 
	size = 13, 
	weight = 600
})

surface.CreateFont("Arcade20", {
	font = "Trebuchet MS", 
	size = 20, 
	weight = 900
})


function AM_Settings( um )
	Ent = um:ReadEntity()
	Ent.ArcadeName = um:ReadString()
	Ent.ArcadePrice = um:ReadLong()
end
usermessage.Hook("ARCADE_Settings", AM_Settings)

function ENT:Draw()
	self.Entity:DrawModel()
	local pos = self:GetPos() + Vector(0, 0, 1) * math.sin(CurTime() * 2) * 2
	local PlayersAngle = LocalPlayer():GetAngles()
	local ang = Angle( 0, PlayersAngle.y - 180, 0 )
	
	ang:RotateAroundAxis(ang:Right(), -90)
	ang:RotateAroundAxis(ang:Up(), 90)
	
	cam.Start3D2D(pos, ang, 1)
		if self.Entity.ArcadeName then
            draw.SimpleTextOutlined(self.Entity.ArcadeName, "Arcade20", 0, -105, Color(60, 60, 60, 255), 1, 1, 1.5, Color(0, 0, 0, 255))
		end
		if self.Entity.ArcadePrice then
			if self.Entity.ArcadePrice > 0 then
				draw.SimpleTextOutlined("$"..self.Entity.ArcadePrice, "ArcadeSmall", 0, -90, Color(60, 100, 0, 200), 1, 1, 1.5, Color(0, 0, 0, 255))
			else
				draw.SimpleTextOutlined("Free", "ArcadeSmall", 0, -90, Color(60, 100, 0, 200), 1, 1, 1.5, Color(0, 0, 0, 255))
			end
		end
		
    cam.End3D2D()
end

function ENT:DrawTranslucent()
	self:Draw()
end

function ArcadeMenu( um )
local Gamename = um:ReadString()
local Game = um:ReadString()

local ArcadeFrame = vgui.Create( "DFrame" )
ArcadeFrame:SetSize( 625, 445 )
ArcadeFrame:Center()
ArcadeFrame:SetTitle( "" ) 
ArcadeFrame:SetDraggable( true ) 
ArcadeFrame:ShowCloseButton( false )
ArcadeFrame:MakePopup()
ArcadeFrame.Paint = function(CHPaint)
	-- Draw the menu background color.		
	draw.RoundedBox( 0, 0, 25, CHPaint:GetWide(), CHPaint:GetTall(), Color( 255, 255, 255, 150 ) )

	-- Draw the outline of the menu.
	surface.SetDrawColor(0,0,0,255)
	surface.DrawOutlinedRect(0, 0, CHPaint:GetWide(), CHPaint:GetTall())
	 
	draw.RoundedBox( 0, 0, 0, CHPaint:GetWide(), 25, Color( 255, 255, 255, 200 ) )
		
	surface.SetDrawColor(0,0,0,255)
	surface.DrawOutlinedRect(0, 0, CHPaint:GetWide(), 25)
end

local MenuTitle = vgui.Create( "DLabel", ArcadeFrame )
MenuTitle:SetText( "Arcade Game: "..Gamename )
MenuTitle:SetPos( 10, 5  )
MenuTitle:SetFont( "ArcadeDefault" )
MenuTitle:SetTextColor( Color( 70,70,70,255 ) )
MenuTitle:SizeToContents()

local GUI_Main_Exit = vgui.Create("DButton", ArcadeFrame)
GUI_Main_Exit:SetSize(16,16)
GUI_Main_Exit:SetPos(605,5)
GUI_Main_Exit:SetText("")
GUI_Main_Exit.Paint = function()
	surface.SetMaterial(Material("icon16/cross.png"))
	surface.SetDrawColor(200,200,0,200)
	surface.DrawTexturedRect(0,0,GUI_Main_Exit:GetWide(),GUI_Main_Exit:GetTall())
end
GUI_Main_Exit.DoClick = function()
	ArcadeFrame:Remove()
	net.Start("CH_CloseArcadeMenu")
	net.SendToServer()
end

local TheGame = vgui.Create( "HTML", ArcadeFrame )
TheGame:SetPos( 5, 25 )
TheGame:SetSize( 620, 450 )
TheGame:SetHTML([[<embed src=']].. Game ..[[' type='application/x-shockwave-flash' width='600' height='400'></embed>]])
end
usermessage.Hook("CH_ArcadeMenu", ArcadeMenu)