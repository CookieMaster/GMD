/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Evo Lancer"
VEHICLE.Make = "Mitsubishi"
VEHICLE.Type = "X"
VEHICLE.ID = "]"
VEHICLE.Script = "scripts/vehicles/tdmcars/mitsu_evox.txt"
VEHICLE.Class = "mitsu_evoxtdm"

VEHICLE.Model = "models/tdmcars/mitsu_evox.mdl"
VEHICLE.Icon = "vgui/entities/mitsu_evoxtdm.vtf"

VEHICLE.Price = 85000

VEHICLE.Speed = 85
VEHICLE.Power = 300
VEHICLE.RMP = 5000