/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "SLS"
VEHICLE.Make = "Mercedes"
VEHICLE.Type = "AMG"
VEHICLE.ID = "h"
VEHICLE.Script = "scripts/vehicles/tdmcars/slsamg.txt"
VEHICLE.Class = "slsamgtdm"

VEHICLE.Model = "models/tdmcars/mer_slsamg.mdl"
VEHICLE.Icon = "vgui/entities/slsamgtdm.vtf"

VEHICLE.Price = 150000

VEHICLE.Speed = 145
VEHICLE.Power = 670
VEHICLE.RMP = 5000