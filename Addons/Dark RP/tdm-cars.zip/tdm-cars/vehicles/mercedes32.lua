/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Mercedes C32"
VEHICLE.Make = "Mercedes"
VEHICLE.Type = "C"
VEHICLE.ID = "q"
VEHICLE.Script = "scripts/vehicles/tdmcars/c32.txt"
VEHICLE.Class = "c32amgtdm"

VEHICLE.Model = "models/tdmcars/mercedes_c32.mdl"
VEHICLE.Icon = "vgui/entities/c32amgtdm.vtf"

VEHICLE.Price = 120000

VEHICLE.Speed = 89
VEHICLE.Power = 640
VEHICLE.RMP = 5000