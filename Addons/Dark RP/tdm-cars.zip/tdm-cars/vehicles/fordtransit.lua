/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Ford Transit"
VEHICLE.Make = "Ford"
VEHICLE.Type = ""
VEHICLE.ID = "y"
VEHICLE.Script = "scripts/vehicles/tdmcars/transit.txt"
VEHICLE.Class = "transittdm"

VEHICLE.Model = "models/tdmcars/ford_transit.mdl"
VEHICLE.Icon = "vgui/entities/transittdm.vtf"

VEHICLE.Price = 200000

VEHICLE.Speed = 140
VEHICLE.Power = 500
VEHICLE.RMP = 4700