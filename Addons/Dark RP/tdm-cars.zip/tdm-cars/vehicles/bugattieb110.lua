/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Bugatti Eb110"
VEHICLE.Make = "Bugatti"
VEHICLE.Type = "Eb110"
VEHICLE.ID = "+"
VEHICLE.Script = "scripts/vehicles/tdmcars/eb110.txt"
VEHICLE.Class = "eb110tdm"

VEHICLE.Model = "models/tdmcars/bug_eb110.mdl"
VEHICLE.Icon = "vgui/entities/eb110tdm.vtf"

VEHICLE.Price = 130000

VEHICLE.Speed = 124
VEHICLE.Power = 536
VEHICLE.RMP = 4800