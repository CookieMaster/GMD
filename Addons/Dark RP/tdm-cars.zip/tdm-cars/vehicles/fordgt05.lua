/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Ford GT"
VEHICLE.Make = "Ford"
VEHICLE.Type = "05"
VEHICLE.ID = "t"
VEHICLE.Script = "scripts/vehicles/tdmcars/gt05.txt"
VEHICLE.Class = "gt05tdm"

VEHICLE.Model = "models/tdmcars/gt05.mdl"
VEHICLE.Icon = "vgui/entities/gt05tdm.vtf"

VEHICLE.Price = 245000

VEHICLE.Speed = 212
VEHICLE.Power = 500
VEHICLE.RMP = 5000