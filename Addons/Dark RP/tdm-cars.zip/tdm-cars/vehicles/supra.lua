/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Supra"
VEHICLE.Make = "Toyota"
VEHICLE.Type = ""
VEHICLE.ID = "l"
VEHICLE.Script = "scripts/vehicles/tdmcars/supra.txt"
VEHICLE.Class = "supratdm"

VEHICLE.Model = "models/tdmcars/supra.mdl"
VEHICLE.Icon = "vgui/entities/supratdm.vtf"

VEHICLE.Price = 85000

VEHICLE.Speed = 150
VEHICLE.Power = 322
VEHICLE.RMP = 4500