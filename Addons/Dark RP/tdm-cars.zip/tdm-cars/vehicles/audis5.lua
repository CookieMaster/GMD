/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Audi S5"
VEHICLE.Make = "Audi"
VEHICLE.Type = "S5"
VEHICLE.ID = "8"
VEHICLE.Script = "scripts/vehicles/tdmcars/s5.txt"
VEHICLE.Class = "s5tdm"

VEHICLE.Model = "models/tdmcars/s5.mdl"
VEHICLE.Icon = "vgui/entities/s5tdm.vtf"

VEHICLE.Price = 95000

VEHICLE.Speed = 150
VEHICLE.Power = 450
VEHICLE.RMP = 5000