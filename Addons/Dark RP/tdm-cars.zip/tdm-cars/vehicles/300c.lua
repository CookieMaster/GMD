/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "300c"
VEHICLE.Make = "Chrysler"
VEHICLE.Type = ""
VEHICLE.ID = "3"
VEHICLE.Script = "scripts/vehicles/tdmcars/300c.txt"
VEHICLE.Class = "300ctdm"

VEHICLE.Model = "models/tdmcars/chr_300c.mdl"
VEHICLE.Icon = "vgui/entities/300ctdm.vtf"

VEHICLE.Price = 500000

VEHICLE.Speed = 73
VEHICLE.Power = 420
VEHICLE.RMP = 5000