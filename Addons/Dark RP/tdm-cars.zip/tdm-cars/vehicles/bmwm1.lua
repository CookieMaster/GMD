/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Bmw M1"
VEHICLE.Make = "Bmw"
VEHICLE.Type = "M1"
VEHICLE.ID = "-"
VEHICLE.Script = "scripts/vehicles/tdmcars/m1.txt"
VEHICLE.Class = "m1tdm"

VEHICLE.Model = "models/tdmcars/bmwm1.mdl"
VEHICLE.Icon = "vgui/entities/m1tdm.vtf"

VEHICLE.Price = 125000

VEHICLE.Speed = 93
VEHICLE.Power = 280
VEHICLE.RMP = 4200