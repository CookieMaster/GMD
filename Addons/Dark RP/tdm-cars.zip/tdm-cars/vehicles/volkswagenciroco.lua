/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Volkswagen Scirocco"
VEHICLE.Make = "Volkswagen"
VEHICLE.Type = ""
VEHICLE.ID = "@"
VEHICLE.Script = "scripts/vehicles/tdmcars/audir8.txt"
VEHICLE.Class = "sciroccotdm"

VEHICLE.Model = "models/tdmcars/scirocco.mdl"
VEHICLE.Icon = "vgui/entities/sciroccotdm.vtf"

VEHICLE.Price = 150000

VEHICLE.Speed = 140
VEHICLE.Power = 261
VEHICLE.RMP = 8000