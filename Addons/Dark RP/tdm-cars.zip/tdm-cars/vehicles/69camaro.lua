/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "69Camaro"
VEHICLE.Make = "Chevrolet"
VEHICLE.Type = "SS"
VEHICLE.ID = "1"
VEHICLE.Script = "scripts/vehicles/tdmcars/69camaro.txt"
VEHICLE.Class = "69camarotdm"

VEHICLE.Model = "models/tdmcars/69camaro.mdl"
VEHICLE.Icon = "vgui/entities/69camarotdm.vtf"

VEHICLE.Price = 85000

VEHICLE.Speed = 100
VEHICLE.Power = 475
VEHICLE.RMP = 4000