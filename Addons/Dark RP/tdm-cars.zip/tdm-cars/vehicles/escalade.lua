/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Escalade"
VEHICLE.Make = "Cadillac"
VEHICLE.Type = ""
VEHICLE.ID = "("
VEHICLE.Script = "scripts/vehicles/tdmcars/escalade.txt"
VEHICLE.Class = "escaladetdm"

VEHICLE.Model = "models/tdmcars/cad_escalade.mdl"
VEHICLE.Icon = "vgui/entities/escaladetdm.vtf"

VEHICLE.Price = 85000

VEHICLE.Speed = 79
VEHICLE.Power = 160
VEHICLE.RMP = 5000