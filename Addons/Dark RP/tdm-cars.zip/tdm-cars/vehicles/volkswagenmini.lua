/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Beetle67"
VEHICLE.Make = "Volkswagen"
VEHICLE.Type = ""
VEHICLE.ID = "'"
VEHICLE.Script = "scripts/vehicles/tdmcars/beetle67.txt"
VEHICLE.Class = "beetle67tdm"

VEHICLE.Model = "models/tdmcars/beetle.mdl"
VEHICLE.Icon = "vgui/entities/beetle67tdm.vtf"

VEHICLE.Price = 75000

VEHICLE.Speed = 50
VEHICLE.Power = 200
VEHICLE.RMP = 4200