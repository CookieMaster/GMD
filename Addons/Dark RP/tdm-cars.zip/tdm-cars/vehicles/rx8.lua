/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "RX-8"
VEHICLE.Make = "Mazda"
VEHICLE.Type = ""
VEHICLE.ID = "g"
VEHICLE.Script = "scripts/vehicles/tdmcars/rx8.txt"
VEHICLE.Class = "rx8tdm"

VEHICLE.Model = "models/tdmcars/rx8.mdl"
VEHICLE.Icon = "vgui/entities/rx8tdm.vtf"

VEHICLE.Price = 85000

VEHICLE.Speed = 145
VEHICLE.Power = 332
VEHICLE.RMP = 60000