/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "1965"
VEHICLE.Make = "Mini Cooper"
VEHICLE.Type = ""
VEHICLE.ID = "%"
VEHICLE.Script = "scripts/vehicles/tdmcars/cooper65.txt"
VEHICLE.Class = "cooper65tdm"

VEHICLE.Model = "models/tdmcars/cooper65.mdl"
VEHICLE.Icon = "vgui/entities/cooper65tdm.vtf"

VEHICLE.Price = 85000

VEHICLE.Speed = 60
VEHICLE.Power = 180
VEHICLE.RMP = 4200