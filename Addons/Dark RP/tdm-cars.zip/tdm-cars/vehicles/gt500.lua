/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "500"
VEHICLE.Make = "Ford"
VEHICLE.Type = "GT"
VEHICLE.ID = "o"
VEHICLE.Script = "scripts/vehicles/tdmcars/gt500.txt"
VEHICLE.Class = "gt500tdm"

VEHICLE.Model = "models/tdmcars/gt500.mdl"
VEHICLE.Icon = "vgui/entities/gt500tdm.vtf"

VEHICLE.Price = 85000

VEHICLE.Speed = 155
VEHICLE.Power = 540
VEHICLE.RMP = 4500