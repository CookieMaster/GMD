/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Nissan GTR"
VEHICLE.Make = "Nissan"
VEHICLE.Type = ""
VEHICLE.ID = "a"
VEHICLE.Script = "scripts/vehicles/tdmcars/gtr.txt"
VEHICLE.Class = "gtrtdm"

VEHICLE.Model = "models/tdmcars/nissan_gtr.mdl"
VEHICLE.Icon = "vgui/entities/gtrtdm.vtf"

VEHICLE.Price = 280000

VEHICLE.Speed = 150
VEHICLE.Power = 550
VEHICLE.RMP = 5000