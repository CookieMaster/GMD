/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Ferrari 512"
VEHICLE.Make = "Ferrari"
VEHICLE.Type = "TR"
VEHICLE.ID = "w"
VEHICLE.Script = "scripts/vehicles/tdmcars/ferrari512tr.txt"
VEHICLE.Class = "ferrari512trtdm"

VEHICLE.Model = "models/tdmcars/ferrari512tr.mdl"
VEHICLE.Icon = "vgui/entities/ferrari512trtdm.vtf"

VEHICLE.Price = 260000

VEHICLE.Speed = 195
VEHICLE.Power = 428
VEHICLE.RMP = 4500