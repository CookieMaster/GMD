/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Syclone"
VEHICLE.Make = "GMC"
VEHICLE.Type = ""
VEHICLE.ID = ";"
VEHICLE.Script = "scripts/vehicles/tdmcars/syclone.txt"
VEHICLE.Class = "syclonetdm"

VEHICLE.Model = "models/tdmcars/gmc_syclone.mdl"
VEHICLE.Icon = "vgui/entities/syclonetdm.vtf"

VEHICLE.Price = 85000

VEHICLE.Speed = 155
VEHICLE.Power = 400
VEHICLE.RMP = 6000