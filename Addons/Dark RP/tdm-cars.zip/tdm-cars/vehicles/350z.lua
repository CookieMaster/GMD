/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "350z"
VEHICLE.Make = "Nissan"
VEHICLE.Type = ""
VEHICLE.ID = "4"
VEHICLE.Script = "scripts/vehicles/tdmcars/350z.txt"
VEHICLE.Class = "350ztdm"

VEHICLE.Model = "models/tdmcars/350z.mdl"
VEHICLE.Icon = "vgui/entities/350ztdm.vtf"

VEHICLE.Price = 75000

VEHICLE.Speed = 450
VEHICLE.Power = 550
VEHICLE.RMP = 4300