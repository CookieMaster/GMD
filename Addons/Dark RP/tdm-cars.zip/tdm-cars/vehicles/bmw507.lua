/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "507"
VEHICLE.Make = "BMW"
VEHICLE.Type = ""
VEHICLE.ID = "0"
VEHICLE.Script = "scripts/vehicles/tdmcars/507.txt"
VEHICLE.Class = "507tdm"

VEHICLE.Model = "models/tdmcars/bmw507.mdl"
VEHICLE.Icon = "vgui/entities/507tdm.vtf"

VEHICLE.Price = 85000

VEHICLE.Speed = 71
VEHICLE.Power = 350
VEHICLE.RMP = 4200