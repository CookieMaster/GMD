/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Bugatti Veyron"
VEHICLE.Make = "Bugatti"
VEHICLE.Type = "SS"
VEHICLE.ID = "!"
VEHICLE.Script = "scripts/vehicles/tdmcars/veyronss.txt"
VEHICLE.Class = "veyronsstdm"

VEHICLE.Model = "models/tdmcars/bug_veyronss.mdl"
VEHICLE.Icon = "vgui/entities/veyronsstdm.vtf"

VEHICLE.Price = 1200000

VEHICLE.Speed = 150
VEHICLE.Power = 1200
VEHICLE.RMP = 5000