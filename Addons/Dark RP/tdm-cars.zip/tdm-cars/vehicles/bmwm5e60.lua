/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "M5"
VEHICLE.Make = "BMW"
VEHICLE.Type = "e60"
VEHICLE.ID = "2"
VEHICLE.Script = "scripts/vehicles/tdmcars/bmwm5e60.txt"
VEHICLE.Class = "bmwm5e60tdm"

VEHICLE.Model = "models/tdmcars/bmwm5e60.mdl"
VEHICLE.Icon = "vgui/entities/bmwm5e60tdm.vtf"

VEHICLE.Price = 85000

VEHICLE.Speed = 87
VEHICLE.Power = 270
VEHICLE.RMP = 5000