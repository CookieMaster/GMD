/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Dodge Ram"
VEHICLE.Make = "Dodge"
VEHICLE.Type = "SRT10"
VEHICLE.ID = ")"
VEHICLE.Script = "scripts/vehicles/tdmcars/dodgeram.txt"
VEHICLE.Class = "dodgeramtdm"

VEHICLE.Model = "models/tdmcars/dodgeram.mdl"
VEHICLE.Icon = 0

VEHICLE.Price = 95000

VEHICLE.Speed = 146
VEHICLE.Power = 510
VEHICLE.RMP = 5600