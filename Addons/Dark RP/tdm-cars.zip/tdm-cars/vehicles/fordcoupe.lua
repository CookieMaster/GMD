/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Ford Coupe"
VEHICLE.Make = "Ford"
VEHICLE.Type = "40"
VEHICLE.ID = "e"
VEHICLE.Script = "scripts/vehicles/tdmcars/coupe40.txt"
VEHICLE.Class = "coupe40tdm"

VEHICLE.Model = "models/tdmcars/ford_coupe_40.mdl"
VEHICLE.Icon = "vgui/entities/coupe40tdm.vtf"

VEHICLE.Price = 120000

VEHICLE.Speed = 90
VEHICLE.Power = 190
VEHICLE.RMP = 5000