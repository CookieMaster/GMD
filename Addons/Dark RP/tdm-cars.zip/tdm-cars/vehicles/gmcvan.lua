/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "GMC Vandura"
VEHICLE.Make = "GMC"
VEHICLE.Type = ""
VEHICLE.ID = "i"
VEHICLE.Script = "scripts/vehicles/tdmcars/audir8.txt"
VEHICLE.Class = "gmcvantdm"

VEHICLE.Model = "models/tdmcars/gmcvan.mdl"
VEHICLE.Icon = "vgui/entities/gmcvantdm.vtf"

VEHICLE.Price = 150000

VEHICLE.Speed = 65
VEHICLE.Power = 250
VEHICLE.RMP = 4200