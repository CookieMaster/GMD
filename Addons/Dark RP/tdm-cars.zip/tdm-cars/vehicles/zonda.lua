/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Pagani"
VEHICLE.Make = "Zonda"
VEHICLE.Type = "C12"
VEHICLE.ID = ":"
VEHICLE.Script = "scripts/vehicles/tdmcars/c12.txt"
VEHICLE.Class = "c12tdm"

VEHICLE.Model = "models/tdmcars/zondac12.mdl"
VEHICLE.Icon = "vgui/entities/c12tdm.vtf"

VEHICLE.Price = 1000000

VEHICLE.Speed = 208
VEHICLE.Power = 550
VEHICLE.RMP = 5000