/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Colt Raliart"
VEHICLE.Make = "Mitsubishi"
VEHICLE.Type = "0"
VEHICLE.ID = "*"
VEHICLE.Script = "scripts/vehicles/tdmcars/colt.txt"
VEHICLE.Class = "colttdm"

VEHICLE.Model = "models/tdmcars/coltralliart.mdl"
VEHICLE.Icon = "vgui/entities/colttdm.vtf"

VEHICLE.Price = 85000

VEHICLE.Speed = 120
VEHICLE.Power = 250
VEHICLE.RMP = 4200