/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Revento"
VEHICLE.Make = "Lamborghini"
VEHICLE.Type = ""
VEHICLE.ID = "["
VEHICLE.Script = "scripts/vehicles/tdmcars/reventonr.txt"
VEHICLE.Class = "reventonrtdm"

VEHICLE.Model = "models/tdmcars/reventon_roadster.mdl"
VEHICLE.Icon = "vgui/entities/reventonrtdm.vtf"

VEHICLE.Price = 600000

VEHICLE.Speed = 168
VEHICLE.Power = 650
VEHICLE.RMP = 6000