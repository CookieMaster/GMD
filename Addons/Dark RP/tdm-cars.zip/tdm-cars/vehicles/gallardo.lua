/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Gallardo"
VEHICLE.Make = "Lamborghini"
VEHICLE.Type = ""
VEHICLE.ID = "u"
VEHICLE.Script = "scripts/vehicles/tdmcars/gallardo.txt"
VEHICLE.Class = "gallardotdm"

VEHICLE.Model = "models/tdmcars/gallardo.mdl"
VEHICLE.Icon = "vgui/entities/gallardotdm.vtf"

VEHICLE.Price = 320000

VEHICLE.Speed = 160
VEHICLE.Power = 480
VEHICLE.RMP = 6000