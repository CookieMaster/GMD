/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Prius"
VEHICLE.Make = "Toyota"
VEHICLE.Type = ""
VEHICLE.ID = "s"
VEHICLE.Script = "scripts/vehicles/tdmcars/prius.txt"
VEHICLE.Class = "priustdm"

VEHICLE.Model = "models/tdmcars/prius.mdl"
VEHICLE.Icon = "vgui/entities/priustdm.vtf"

VEHICLE.Price = 85000

VEHICLE.Speed = 112
VEHICLE.Power = 250
VEHICLE.RMP = 5000