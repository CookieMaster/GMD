/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Audi TT"
VEHICLE.Make = "Audi"
VEHICLE.Type = "TT"
VEHICLE.ID = "9"
VEHICLE.Script = "scripts/vehicles/tdmcars/auditt.txt"
VEHICLE.Class = "auditttdm"

VEHICLE.Model = "models/tdmcars/auditt.mdl"
VEHICLE.Icon = "vgui/entities/auditttdm.vtf"

VEHICLE.Price = 55000

VEHICLE.Speed = 89
VEHICLE.Power = 650
VEHICLE.RMP = 4300