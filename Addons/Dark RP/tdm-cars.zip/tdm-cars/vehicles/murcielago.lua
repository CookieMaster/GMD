/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Murcielago"
VEHICLE.Make = "Lamborghini"
VEHICLE.Type = ""
VEHICLE.ID = "}"
VEHICLE.Script = "scripts/vehicles/tdmcars/murcielago.txt"
VEHICLE.Class = "murcielagotdm"

VEHICLE.Model = "models/tdmcars/murcielago.mdl"
VEHICLE.Icon = "vgui/entities/murcielagotdm.vtf"

VEHICLE.Price = 450000

VEHICLE.Speed = 205
VEHICLE.Power = 580
VEHICLE.RMP = 4500