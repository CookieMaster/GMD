/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Ferrari 250"
VEHICLE.Make = "Ferrari"
VEHICLE.Type = "GT"
VEHICLE.ID = "="
VEHICLE.Script = "scripts/vehicles/tdmcars/ferrari250gt.txt"
VEHICLE.Class = "ferrari250gttdm"

VEHICLE.Model = "models/tdmcars/ferrari250gt.mdl"
VEHICLE.Icon = "vgui/entities/ferrari250gttdm.vtf"

VEHICLE.Price = 85000

VEHICLE.Speed = 120
VEHICLE.Power = 260
VEHICLE.RMP = 4500