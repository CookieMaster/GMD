/*-----------------------------------------*\
	Here are the Car Details
\*-----------------------------------------*/

VEHICLE = {}

VEHICLE.Name = "Cayenne Turbo"
VEHICLE.Make = "Porsche"
VEHICLE.Type = "s"
VEHICLE.ID = "d"
VEHICLE.Script = "scripts/vehicles/tdmcars/cayenne.txt"
VEHICLE.Class = "cayennetdm"

VEHICLE.Model = "models/tdmcars/cayenne.mdl"
VEHICLE.Icon = "vgui/entities/cayennetdm.vtf"

VEHICLE.Price = 500500

VEHICLE.Speed = 146
VEHICLE.Power = 460
VEHICLE.RMP = 8000