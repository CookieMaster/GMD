ENT.Base = "base_ai"
ENT.Type = "ai"

ENT.Spawnable = false
ENT.AdminSpawnable = false
