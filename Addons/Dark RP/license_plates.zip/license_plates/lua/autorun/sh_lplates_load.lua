
include( "lplates/sh_lplates.lua" )
include( "lplates/sh_config.lua" )
include( "lplates/sh_vehicledef.lua" )

if SERVER then
	AddCSLuaFile()

	AddCSLuaFile( "lplates/sh_lplates.lua" )
	AddCSLuaFile( "lplates/sh_config.lua" )
	AddCSLuaFile( "lplates/sh_vehicledef.lua" )
	AddCSLuaFile( "lplates/client/cl_lplates.lua" )

	include( "lplates/server/sv_lplates.lua" )

	resource.AddFile( "materials/dan/plate.png" )
else
	include( "lplates/client/cl_lplates.lua" )
end

