include('shared.lua')

local function CH_ScratchCard(umg)

-- Win numbers are 2,5 and 9

local ScratchNumber = umg:ReadShort()

local BlockThem1Up, BlockThem2Up, BlockThem3Up, BlockThem1Down, BlockThem2Down, AmountToBet
local x, y, ShouldDrawBar = 5, 25, false
local ScratchMenu = vgui.Create( "DFrame" ) -- Center
ScratchMenu:SetSize(470,310)
ScratchMenu:SetTitle( "" )  
ScratchMenu:SetVisible( true )
ScratchMenu:SetDraggable( false ) 
ScratchMenu:SetBackgroundBlur( true )
ScratchMenu:ShowCloseButton( false )
ScratchMenu:Center()
ScratchMenu.Paint = function(CHPaint)
	-- Draw the menu background color.
		
	draw.RoundedBox( 6, 0, 0, CHPaint:GetWide(), CHPaint:GetTall(), Color( 255, 255, 255, 150 ) )

	-- Draw the outline of the menu.
	surface.SetDrawColor(0,0,0,255)
	surface.DrawOutlinedRect(0, 0, CHPaint:GetWide(), CHPaint:GetTall())

	surface.SetDrawColor(0,0,0,255)
	surface.DrawOutlinedRect(0, 0, CHPaint:GetWide(), 25)
	--surface.DrawOutlinedRect(1, 1, CHPaint:GetWide(), 25)

	-- Draw the top title.
	draw.SimpleText("Scratch Cards", "UiBold", 55,12.5, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	if ShouldDrawBar then
		DisableClipping(true)
		draw.RoundedBox(0,ScratchMenu:GetWide()*0.5-200,275,400,25,Color(60, 60, 60, 255))
		draw.RoundedBox(0,ScratchMenu:GetWide()*0.5-200,275,x,y,Color(255, 255, 255, 255))
		draw.SimpleTextOutlined("Scratching...", "Trebuchet19", ScratchMenu:GetWide()*0.5, 287.2, Color(0, 0, 0, 255), 1, 1, 1.5, Color(255, 255, 255, 255))
		DisableClipping(false)
		
		x = x + 1

		if x == 50 then
			BlockThem1Up:Remove()
		end
		if x == 120 then
			BlockThem2Up:Remove()
		end
		if x == 200 then
			BlockThem3Up:Remove()
		end
		if x == 270 then
			BlockThem1Down:Remove()
		end
		if x == 340 then
			BlockThem2Down:Remove()
		end

		if x == 400 then
			ShouldDrawBar = false
			BlockThem3Down:Remove()
			
			net.Start("CH_ScratchFinal")
				net.WriteDouble(tonumber( LocalPlayer().AmountToBet ))
			net.SendToServer()
			
			timer.Simple(2, function()
				ScratchMenu:Remove()
				net.Start("CH_ScratchRestart")
				net.SendToServer()
			end)
		end
	end
end
ScratchMenu:MakePopup()
ScratchMenu:SizeToContents()   

LocalPlayer().AmountToBet = 0

local GUI_Main_Exit = vgui.Create("DButton")
GUI_Main_Exit:SetParent(ScratchMenu)
GUI_Main_Exit:SetSize(16,16)
GUI_Main_Exit:SetPos(450,5)
GUI_Main_Exit:SetText("")
GUI_Main_Exit.Paint = function()
surface.SetMaterial(Material("gui/silkicons/check_off.vtf"))
surface.SetDrawColor(200,200,0,200)
surface.DrawTexturedRect(0,0,GUI_Main_Exit:GetWide(),GUI_Main_Exit:GetTall())
end
GUI_Main_Exit.DoClick = function()
ScratchMenu:Remove()
net.Start("CH_CloseSMenu")
net.SendToServer()
end

local ScratchBG = vgui.Create( "DPanel", ScratchMenu )
ScratchBG:SetPos( 10, 35 )
ScratchBG:SetSize( 450, 200 )
ScratchBG.Paint = function() -- Paint function
    draw.RoundedBox(8,1,1,ScratchBG:GetWide()-2,ScratchBG:GetTall()-2,Color(50, 50, 50, 150))
end
timer.Simple(0.1, function()
FirstPictureUp = vgui.Create( "DImage", ScratchBG )
FirstPictureUp:SetPos( 40, 20 )
if ScratchNumber == 1 then
FirstPictureUp:SetImage( "cg_ocrp/scratch/scratch_bomb" )
elseif ScratchNumber == 2 then
FirstPictureUp:SetImage( "cg_ocrp/scratch/scratch_danger" )
elseif ScratchNumber == 3 then
FirstPictureUp:SetImage( "cg_ocrp/scratch/scratch_bus" )
elseif ScratchNumber == 4 then
FirstPictureUp:SetImage( "cg_ocrp/scratch/scratch_warning" )
elseif ScratchNumber == 5 then
FirstPictureUp:SetImage( "cg_ocrp/scratch/scratch_bomb" )
elseif ScratchNumber == 6 then
FirstPictureUp:SetImage( "cg_ocrp/scratch/scratch_plane" )
elseif ScratchNumber == 7 then
FirstPictureUp:SetImage( "cg_ocrp/scratch/scratch_bomb" )
elseif ScratchNumber == 8 then
FirstPictureUp:SetImage( "cg_ocrp/scratch/scratch_bus" )
elseif ScratchNumber == 9 then
FirstPictureUp:SetImage( "cg_ocrp/scratch/scratch_plane" )
elseif ScratchNumber == 10 then
FirstPictureUp:SetImage( "cg_ocrp/scratch/scratch_warning" )
end
FirstPictureUp:SizeToContents()

FirstPictureDown = vgui.Create( "DImage", ScratchBG )
FirstPictureDown:SetPos( 40, 115 )
if ScratchNumber == 1 then
FirstPictureDown:SetImage( "cg_ocrp/scratch/scratch_bomb" )
elseif ScratchNumber == 2 then
FirstPictureDown:SetImage( "cg_ocrp/scratch/scratch_plane" )
elseif ScratchNumber == 3 then
FirstPictureDown:SetImage( "cg_ocrp/scratch/scratch_bomb" )
elseif ScratchNumber == 4 then
FirstPictureDown:SetImage( "cg_ocrp/scratch/scratch_mail" )
elseif ScratchNumber == 5 then
FirstPictureDown:SetImage( "cg_ocrp/scratch/scratch_bomb" )
elseif ScratchNumber == 6 then
FirstPictureDown:SetImage( "cg_ocrp/scratch/scratch_mail" )
elseif ScratchNumber == 7 then
FirstPictureDown:SetImage( "cg_ocrp/scratch/scratch_bomb" )
elseif ScratchNumber == 8 then
FirstPictureDown:SetImage( "cg_ocrp/scratch/scratch_plane" )
elseif ScratchNumber == 9 then
FirstPictureDown:SetImage( "cg_ocrp/scratch/scratch_bomb" )
elseif ScratchNumber == 10 then
FirstPictureDown:SetImage( "cg_ocrp/scratch/scratch_bomb" )
end
FirstPictureDown:SizeToContents()

MidPictureUp = vgui.Create( "DImage", ScratchBG )
MidPictureUp:SetPos( 190, 20 )
if ScratchNumber == 1 then
MidPictureUp:SetImage( "cg_ocrp/scratch/scratch_plane" )
elseif ScratchNumber == 2 then
MidPictureUp:SetImage( "cg_ocrp/scratch/scratch_danger" )
elseif ScratchNumber == 3 then
MidPictureUp:SetImage( "cg_ocrp/scratch/scratch_bus" )
elseif ScratchNumber == 4 then
MidPictureUp:SetImage( "cg_ocrp/scratch/scratch_danger" )
elseif ScratchNumber == 5 then
MidPictureUp:SetImage( "cg_ocrp/scratch/scratch_warning" )
elseif ScratchNumber == 6 then
MidPictureUp:SetImage( "cg_ocrp/scratch/scratch_bus" )
elseif ScratchNumber == 7 then
MidPictureUp:SetImage( "cg_ocrp/scratch/scratch_bus" )
elseif ScratchNumber == 8 then
MidPictureUp:SetImage( "cg_ocrp/scratch/scratch_warning" )
elseif ScratchNumber == 9 then
MidPictureUp:SetImage( "cg_ocrp/scratch/scratch_bomb" )
elseif ScratchNumber == 10 then
MidPictureUp:SetImage( "cg_ocrp/scratch/scratch_danger" )
end
MidPictureUp:SizeToContents()

MidPictureDown = vgui.Create( "DImage", ScratchBG )
MidPictureDown:SetPos( 190, 115 )
if ScratchNumber == 1 then
MidPictureDown:SetImage( "cg_ocrp/scratch/scratch_warning" )
elseif ScratchNumber == 2 then
MidPictureDown:SetImage( "cg_ocrp/scratch/scratch_mail" )
elseif ScratchNumber == 3 then
MidPictureDown:SetImage( "cg_ocrp/scratch/scratch_bomb" )
elseif ScratchNumber == 4 then
MidPictureDown:SetImage( "cg_ocrp/scratch/scratch_warning" )
elseif ScratchNumber == 5 then
MidPictureDown:SetImage( "cg_ocrp/scratch/scratch_mail" )
elseif ScratchNumber == 6 then
MidPictureDown:SetImage( "cg_ocrp/scratch/scratch_danger" )
elseif ScratchNumber == 7 then
MidPictureDown:SetImage( "cg_ocrp/scratch/scratch_bus" )
elseif ScratchNumber == 8 then
MidPictureDown:SetImage( "cg_ocrp/scratch/scratch_danger" )
elseif ScratchNumber == 9 then
MidPictureDown:SetImage( "cg_ocrp/scratch/scratch_plane" )
elseif ScratchNumber == 10 then
MidPictureDown:SetImage( "cg_ocrp/scratch/scratch_bus" )
end
MidPictureDown:SizeToContents()

LastPictureUp = vgui.Create( "DImage", ScratchBG )
LastPictureUp:SetPos( 350, 20 )
if ScratchNumber == 1 then
LastPictureUp:SetImage( "cg_ocrp/scratch/scratch_warning" )
elseif ScratchNumber == 2 then
LastPictureUp:SetImage( "cg_ocrp/scratch/scratch_warning" )
elseif ScratchNumber == 3 then
LastPictureUp:SetImage( "cg_ocrp/scratch/scratch_plane" )
elseif ScratchNumber == 4 then
LastPictureUp:SetImage( "cg_ocrp/scratch/scratch_plane" )
elseif ScratchNumber == 5 then
LastPictureUp:SetImage( "cg_ocrp/scratch/scratch_mail" )
elseif ScratchNumber == 6 then
LastPictureUp:SetImage( "cg_ocrp/scratch/scratch_warning" )
elseif ScratchNumber == 7 then
LastPictureUp:SetImage( "cg_ocrp/scratch/scratch_danger" )
elseif ScratchNumber == 8 then
LastPictureUp:SetImage( "cg_ocrp/scratch/scratch_warning" )
elseif ScratchNumber == 9 then
LastPictureUp:SetImage( "cg_ocrp/scratch/scratch_danger" )
elseif ScratchNumber == 10 then
LastPictureUp:SetImage( "cg_ocrp/scratch/scratch_mail" )
end
LastPictureUp:SizeToContents()

LastPictureDown = vgui.Create( "DImage", ScratchBG )
LastPictureDown:SetPos( 350, 115 )
if ScratchNumber == 1 then
LastPictureDown:SetImage( "cg_ocrp/scratch/scratch_bus" )
elseif ScratchNumber == 2 then
LastPictureDown:SetImage( "cg_ocrp/scratch/scratch_danger" )
elseif ScratchNumber == 3 then
LastPictureDown:SetImage( "cg_ocrp/scratch/scratch_warning" )
elseif ScratchNumber == 4 then
LastPictureDown:SetImage( "cg_ocrp/scratch/scratch_plane" )
elseif ScratchNumber == 5 then
LastPictureDown:SetImage( "cg_ocrp/scratch/scratch_bomb" )
elseif ScratchNumber == 6 then
LastPictureDown:SetImage( "cg_ocrp/scratch/scratch_bus" )
elseif ScratchNumber == 7 then
LastPictureDown:SetImage( "cg_ocrp/scratch/scratch_danger" )
elseif ScratchNumber == 8 then
LastPictureDown:SetImage( "cg_ocrp/scratch/scratch_danger" )
elseif ScratchNumber == 9 then
LastPictureDown:SetImage( "cg_ocrp/scratch/scratch_plane" )
elseif ScratchNumber == 10 then
LastPictureDown:SetImage( "cg_ocrp/scratch/scratch_mail" )
end
LastPictureDown:SizeToContents()
end)


BlockThem1Up = vgui.Create( "DPanel", ScratchMenu )
BlockThem1Up:SetPos( 10, 35 )
BlockThem1Up:SetSize( 150, 100 )
BlockThem1Up.Paint = function()
	draw.RoundedBoxEx( 16, 0, 0, BlockThem1Up:GetWide(), BlockThem1Up:GetTall(), Color(50,50,50,255), true, false, false, false )
end
BlockThem2Up = vgui.Create( "DPanel", ScratchMenu )
BlockThem2Up:SetPos( 160, 35 )
BlockThem2Up:SetSize( 150, 100 )
BlockThem2Up.Paint = function()
    surface.SetDrawColor(50, 50, 50, 255)
    surface.DrawRect(0, 0, BlockThem2Up:GetWide(), BlockThem2Up:GetTall())
end
BlockThem3Up = vgui.Create( "DPanel", ScratchMenu )
BlockThem3Up:SetPos( 310, 35 )
BlockThem3Up:SetSize( 150, 100 )
BlockThem3Up.Paint = function()
    draw.RoundedBoxEx( 16, 0, 0, BlockThem3Up:GetWide(), BlockThem3Up:GetTall(), Color(50,50,50,255), false, true, false, false )
end

BlockThem1Down = vgui.Create( "DPanel", ScratchMenu )
BlockThem1Down:SetPos( 10, 135 )
BlockThem1Down:SetSize( 150, 100 )
BlockThem1Down.Paint = function()
    surface.SetDrawColor(50, 50, 50, 255)
    draw.RoundedBoxEx( 16, 0, 0, BlockThem1Down:GetWide(), BlockThem1Down:GetTall(), Color(50,50,50,255), false, false, true, false )
end
BlockThem2Down = vgui.Create( "DPanel", ScratchMenu )
BlockThem2Down:SetPos( 160, 135 )
BlockThem2Down:SetSize( 150, 100 )
BlockThem2Down.Paint = function()
    surface.SetDrawColor(50, 50, 50, 255)
    surface.DrawRect(0, 0, BlockThem2Down:GetWide(), BlockThem2Down:GetTall())
end
BlockThem3Down = vgui.Create( "DPanel", ScratchMenu )
BlockThem3Down:SetPos( 310, 135 )
BlockThem3Down:SetSize( 150, 100 )
BlockThem3Down.Paint = function()
    surface.SetDrawColor(50, 50, 50, 255)
    draw.RoundedBoxEx( 16, 0, 0, BlockThem3Down:GetWide(), BlockThem3Down:GetTall(), Color(50,50,50,255), false, false, false, true )
end

AmountToBet = vgui.Create( "DTextEntry", ScratchMenu )
AmountToBet:SetPos( 35,245 )
AmountToBet:SetTall( 20 )
AmountToBet:SetWide( 400 )
AmountToBet:SetText( "100" )
AmountToBet:SetEnterAllowed( true )
AmountToBet:SetNumeric(true)

local ScratchButton = vgui.Create("DButton",ScratchMenu)
ScratchButton:SetSize( 200, 30 )
ScratchButton:SetPos( 130, 265 )
ScratchButton:SetDrawBackground(true)
ScratchButton:SetText("")
ScratchButton.Paint = function(CHPaint)

draw.RoundedBoxEx( 16, 0, 0, ScratchButton:GetWide(), ScratchButton:GetTall(), Color(50,50,50,255), false, false, true, true )

local struc = {}
struc.pos = {}
struc.pos[1] = 100 -- x pos
struc.pos[2] = 15 -- y pos
struc.color = Color(255,255,255,255) -- Red
struc.text = "Start Scratching" -- Text
struc.font = "Trebuchet22" -- Font
struc.xalign = TEXT_ALIGN_CENTER-- Horizontal Alignment
struc.yalign = TEXT_ALIGN_CENTER -- Vertical Alignment
draw.Text( struc )
end
ScratchButton.DoClick = function()

LocalPlayer().AmountToBet = AmountToBet:GetValue()

net.Start("CH_ScratchPay")
	net.WriteDouble(tonumber( LocalPlayer().AmountToBet ))
	if tonumber(LocalPlayer().DarkRPVars.money) < tonumber(LocalPlayer().AmountToBet) then
		ScratchMenu:Remove()
		net.Start("CH_CloseSMenu")
		net.SendToServer()
	end
net.SendToServer()

AmountToBet:Remove()
GUI_Main_Exit:Remove()
ShouldDrawBar = true
-- When you click on the button it starts scratching!
ScratchButton:Remove()
end -- Here we end the button code :c

end
usermessage.Hook( "ScratchPool", CH_ScratchCard )