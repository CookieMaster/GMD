AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include('shared.lua')

local ScratchNPC
function SpawnScratchNPC()	
	if not file.IsDir("craphead_scripts", "DATA") then
		file.CreateDir("craphead_scripts", "DATA")
	end
	
	if not file.IsDir("craphead_scripts/scratch_cards/".. string.lower(game.GetMap()) .."", "DATA") then
		file.CreateDir("craphead_scripts/scratch_cards/".. string.lower(game.GetMap()) .."", "DATA")
	end
	
	if not file.Exists( "craphead_scripts/scratch_cards/".. string.lower(game.GetMap()) .."/scratchnpc_location_default.txt", "DATA" ) then
		file.Write("craphead_scripts/scratch_cards/".. string.lower(game.GetMap()) .."/scratchnpc_location_default.txt", "0;-0;-0;0;0;0", "DATA")
	end
	
	
	for k, v in pairs(file.Find("craphead_scripts/scratch_cards/".. string.lower(game.GetMap()) .."/*.txt", "DATA")) do
		local PositionFile = file.Read("craphead_scripts/scratch_cards/".. string.lower(game.GetMap()) .."/".. v, "DATA")
	 
		local ThePosition = string.Explode( ";", PositionFile )
		
		local TheVector = Vector(ThePosition[1], ThePosition[2], ThePosition[3])
		local TheAngle = Angle(tonumber(ThePosition[4]), ThePosition[5], ThePosition[6])
		
		ScratchNPC = ents.Create("npc_scratch")
		ScratchNPC:SetModel("models/breen.mdl")
		ScratchNPC:SetPos(TheVector)
		ScratchNPC:SetAngles(TheAngle)

		ScratchNPC:Spawn()
		ScratchNPC:SetMoveType(MOVETYPE_NONE)
		ScratchNPC:SetSolid( SOLID_BBOX )
		ScratchNPC:SetCollisionGroup(COLLISION_GROUP_PLAYER)
		
		local Indicator = ents.Create("npc_indicator")
		Indicator:SetPos( ScratchNPC:GetPos() + (ScratchNPC:GetUp() * 90) )
		Indicator:SetParent( ScratchNPC )
		Indicator:SetAngles( ScratchNPC:GetAngles() )
		Indicator:Spawn()
		Indicator:SetCollisionGroup(COLLISION_GROUP_WORLD)
	end
end
timer.Simple(1, SpawnScratchNPC)

function CH_Scratch_Position( ply, cmd, args )
	if ply:IsAdmin() then
		local FileName = args[1]
		
		if not FileName then
			ply:ChatPrint("Please choose a UNIQUE name for the NPC!") 
			return
		end
		
		if file.Exists( "craphead_scripts/scratch_cards/".. string.lower(game.GetMap()) .."/scratchnpc_location_".. FileName ..".txt", "DATA" ) then 
			ply:ChatPrint("This file name is already in use. Please choose another one or remove this one by typing 'propertynpc_remove "..FileName.."' in console.")
			return
		end
		local HisVector = string.Explode(" ", tostring(ply:GetPos()))
		local HisAngles = string.Explode(" ", tostring(ply:GetAngles()))
		
		file.Write("craphead_scripts/scratch_cards/".. string.lower(game.GetMap()) .."/scratchnpc_location_".. FileName ..".txt", ""..(HisVector[1])..";"..(HisVector[2])..";"..(HisVector[3])..";"..(HisAngles[1])..";"..(HisAngles[2])..";"..(HisAngles[3]).."", "DATA")
		ply:ChatPrint("New position for the NPC has been succesfully set. Please restart your server!")
	else
		ply:ChatPrint("Only administrators can perform this action")
	end
end
concommand.Add("scratchnpc_setpos", CH_Scratch_Position)

function CH_Scratch_Position_Remove( ply, cmd, args )
	if ply:IsAdmin() then
		local FileName = args[1]
		
		if not FileName then
			ply:ChatPrint("Please enter a filename!") 
			return
		end
		
		if file.Exists( "craphead_scripts/scratch_cards/".. string.lower(game.GetMap()) .."/scratchnpc_location_".. FileName ..".txt", "DATA" ) then
			file.Delete( "craphead_scripts/scratch_cards/".. string.lower(game.GetMap()) .."/scratchnpc_location_".. FileName ..".txt" )
			ply:ChatPrint("The selected NPC has been removed. Please restart your server in order for the updates to take place!")
			return
		end
		
	else
		ply:ChatPrint("Only administrators can perform this action")
	end
end
concommand.Add("scratchnpc_remove", CH_Scratch_Position_Remove)

umsg.PoolString("ScratchPool")

util.AddNetworkString("CH_ScratchFinal")
net.Receive("CH_ScratchFinal", function(length, ply)
local ToBet = net.ReadDouble()

if ToBet > 25000 then
	ToBet = 25000
end
-- Pay them money if they won, or tell them if they lost.
if ply.RandomServerNumber == 2 or ply.RandomServerNumber == 5 or ply.RandomServerNumber == 9 then
    ply:AddMoney( ToBet * 2 ) -- Give them twice as much as they betted.
	GAMEMODE:Notify(ply, 1, 6,  "You won $".. ToBet * 2 .."!")
	ply.RandomServerNumber = nil
else
	GAMEMODE:Notify(ply, 1, 6,  "You lost $".. ToBet .."!")
	ply.RandomServerNumber = nil
end  
end)

util.AddNetworkString("CH_ScratchPay")
net.Receive("CH_ScratchPay", function(length, ply)
local ToBet = net.ReadDouble()
local money = ply:getDarkRPVar("money")

if ToBet > money then 
	GAMEMODE:Notify(ply, 1, 6,  "You dont have that much cash in your wallet!")
	ply.RandomServerNumber = nil
return 
end

if ToBet < 100 then 
	GAMEMODE:Notify(ply, 1, 6,  "You need to bet at least 100 dollars!")
	ply.RandomServerNumber = nil
return 
end 

if ToBet > 25000 then
	GAMEMODE:Notify(ply, 1, 6,  "You cannot bet more than 25k at a time.")
	ToBet = 25000
end

ply:AddMoney(ToBet * - 1) -- Taking away whatever they betted.

end)

function ENT:AcceptInput(ply, caller)
	if caller:IsPlayer() && !caller.CantUse && !caller.MenuOpen then
		caller.CantUse = true
		caller.MenuOpen = true
		timer.Simple(3, function()  caller.CantUse = false end)

		if caller:IsValid() then
		caller.RandomServerNumber = math.random(1,10)
		umsg.Start( "ScratchPool", caller )
			umsg.Short( caller.RandomServerNumber )
		umsg.End()
		end
	end
end

util.AddNetworkString("CH_CloseSMenu")
net.Receive("CH_CloseSMenu", function(length, ply)
	ply.MenuOpen = false
end)

util.AddNetworkString("CH_ScratchRestart")
net.Receive("CH_ScratchRestart", function(length, ply)
	ply.RandomServerNumber = math.random(1,10)
	umsg.Start( "ScratchPool", ply )
		umsg.Short( ply.RandomServerNumber )
	umsg.End()
end)