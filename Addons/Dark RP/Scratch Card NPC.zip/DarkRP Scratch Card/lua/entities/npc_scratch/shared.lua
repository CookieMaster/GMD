ENT.Base = "base_ai" 
ENT.Type = "ai"
ENT.PrintName = "Scratch Card NPC"
ENT.Author = "Crap-Head"