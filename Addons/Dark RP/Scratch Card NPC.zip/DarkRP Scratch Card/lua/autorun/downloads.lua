resource.AddFile("materials/cg_ocrp/scratch/scratch_bomb.vmt")
resource.AddFile("materials/cg_ocrp/scratch/scratch_bomb.vtf")

resource.AddFile("materials/cg_ocrp/scratch/scratch_bus.vmt")
resource.AddFile("materials/cg_ocrp/scratch/scratch_bus.vtf")

resource.AddFile("materials/cg_ocrp/scratch/scratch_danger.vmt")
resource.AddFile("materials/cg_ocrp/scratch/scratch_danger.vtf")

resource.AddFile("materials/cg_ocrp/scratch/scratch_mail.vmt")
resource.AddFile("materials/cg_ocrp/scratch/scratch_mail.vtf")

resource.AddFile("materials/cg_ocrp/scratch/scratch_plane.vmt")
resource.AddFile("materials/cg_ocrp/scratch/scratch_plane.vtf")

resource.AddFile("materials/cg_ocrp/scratch/scratch_warning.vmt")
resource.AddFile("materials/cg_ocrp/scratch/scratch_warning.vtf")