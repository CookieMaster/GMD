hook.Add( "Think", "CarSplode", function( )
	for k, v in pairs( player.GetAll( ) ) do
		if v:InVehicle( ) then
			local vehicle = v:GetVehicle( );
			
			if vehicle.target then
				if v:KeyDown( IN_FORWARD ) or v:KeyDown( IN_BACK ) then
					vehicle.destroyed = true;
					v:SetVelocity( Vector( math.random( -250, 250 ), math.random( -250, 250 ), 800 ) );
					v:Kill( );
					vehicle:Ignite(200)
					
					local ent = vehicle
					local shake = ents.Create("env_shake")
					shake:SetOwner(ent)
					shake:SetPos(ent:GetPos())
					shake:SetKeyValue("amplitude", "2000")	
					shake:SetKeyValue("radius", "900")		
					shake:SetKeyValue("duration", "2.5")	
					shake:SetKeyValue("frequency", "255")	
					shake:SetKeyValue("spawnflags", "4")	
					shake:Spawn()
					shake:Activate()
					shake:Fire("StartShake", "", 0)
					local effectdata = EffectData()
					effectdata:SetOrigin(ent:GetPos())
					util.Effect("HelicopterMegaBomb", effectdata)
					local ar2Explo = ents.Create("env_ar2explosion")
					ar2Explo:SetOwner(ent)
					ar2Explo:SetPos(ent:GetPos())
					ar2Explo:Spawn()
					ar2Explo:Activate()
					ar2Explo:Fire("Explode", "", 0)
					ent:GetPhysicsObject():ApplyForceCenter(Vector( 0, 0, 350000 ))
					local explo = ents.Create("env_explosion")
					explo:SetOwner(ent)
					explo:SetPos(ent:GetPos())
					explo:SetKeyValue("iMagnitude", "1")
					explo:Spawn()
					explo:Activate()
					explo:Fire("Explode", "", 0)
					util.BlastDamage(ent,ent, ent:GetPos(), 250, 220)
						
					timer.Simple(5, function()
						vehicle.bomb:Remove( );
						vehicle:Remove()
					end)
				end;
			end;
		end;
	end;
	
	for k, v in pairs( ents.FindByClass( "prop_physics" ) ) do
		if v.bomb then
			if not IsValid( v.owner ) then
				v:Remove( );
			end;
		end;
	end;
end );

hook.Add( "CanPlayerEnterVehicle", "NoSplodedCarEnter", function( ply, vehicle, role )
	if vehicle.destroyed then
		return false;
	end;
end );
