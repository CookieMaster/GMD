
if ( SERVER ) then

	AddCSLuaFile( "shared.lua" )
	
end

if ( CLIENT ) then

	SWEP.PrintName			= "Car Bomb"			
	SWEP.Author				= ""
	SWEP.Slot				= 1
	SWEP.SlotPos			= 3
	SWEP.ViewModelFOV = 65;
	SWEP.IconLetter			= "k"
	
end

SWEP.HoldType			= "slam"
--SWEP.Base				= "weapon_cs_base"
SWEP.Category			= "Other"

SWEP.Spawnable			= false
SWEP.AdminSpawnable		= false

SWEP.ViewModel			= "models/weapons/v_c4.mdl"
SWEP.WorldModel			= "models/weapons/w_c4.mdl"

SWEP.Weight				= 5
SWEP.AutoSwitchTo		= false
SWEP.AutoSwitchFrom		= false

SWEP.Primary.Recoil			= 0
SWEP.Primary.Damage			= 0
SWEP.Primary.NumShots		= 0
SWEP.Primary.Cone			= 0
SWEP.Primary.ClipSize		= -1
SWEP.Primary.Delay			= 0.5
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "none"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

/*---------------------------------------------------------
	PrimaryAttack
---------------------------------------------------------*/
function SWEP:PrimaryAttack()
	self.Weapon:SetNextSecondaryFire( CurTime() + self.Primary.Delay )
	self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
	
	local trace = self.Owner:GetEyeTraceNoCursor( );
		
	if trace.Entity:IsVehicle( ) then
		if self.Owner:GetShootPos( ):Distance( trace.HitPos ) <= 85 then
			self.Owner:SetAnimation( PLAYER_ATTACK1 );
			self.Weapon:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
			
			timer.Simple(3, function()
				if (not self.Owner or not self.Owner:Alive() or self.Weapon:GetOwner():GetActiveWeapon():GetClass() ~= "rp_carsplode" or not IsFirstTimePredicted()) then return end
			
				self.Weapon:SendWeaponAnim(ACT_VM_SECONDARYATTACK)
				
				local tr = {}
				tr.start = self.Owner:GetShootPos()
				tr.endpos = self.Owner:GetShootPos() + 85 * self.Owner:GetAimVector()
				tr.filter = {self.Owner}
				local trace2 = util.TraceLine(tr)
			
				if not trace2.Hit or not trace2.Entity:IsVehicle( ) then
					self.Weapon:SendWeaponAnim(ACT_VM_DRAW)
					return 
				end
				
				if trace2.Entity.target then
					self.Weapon:SendWeaponAnim(ACT_VM_DRAW)
					return 
				end;
				
				self.Owner:SetAnimation(PLAYER_ATTACK1)
			
				if (CLIENT) then return end
				
				self.Weapon:EmitSound( "weapons/c4/c4_plant.wav" );
				
				local bomb = ents.Create("prop_physics")
				bomb:SetPos(trace2.HitPos + trace2.HitNormal)
				bomb:SetModel( "models/weapons/w_c4_planted.mdl" );
				trace2.HitNormal.z = trace2.HitNormal.z * -1;
				bomb:SetAngles(trace2.HitNormal:Angle() - Angle(90, 180, 0))
				bomb:Spawn()
				bomb:SetCollisionGroup( COLLISION_GROUP_DEBRIS );
				bomb:SetParent(trace2.Entity)
				constraint.Weld(bomb, trace2.Entity)
				trace2.Entity.target = true;
				bomb.bomb = true;
				bomb.owner = self.Owner;
				trace2.Entity.bomb = bomb;
				
				self.Weapon:Remove( );
				self.Owner:ConCommand("lastinv")
			end)
		end;
	end;
end

/*---------------------------------------------------------
	DrawHUD
	
	Just a rough mock up showing how to draw your own crosshair.
	
---------------------------------------------------------*/
function SWEP:DrawHUD()

	// No crosshair when ironsights is on
	if ( self.Weapon:GetNetworkedBool( "Ironsights" ) ) then return end

	local x, y

	// If we're drawing the local player, draw the crosshair where they're aiming,
	// instead of in the center of the screen.
	if ( self.Owner == LocalPlayer() && self.Owner:ShouldDrawLocalPlayer() ) then

		local tr = util.GetPlayerTrace( self.Owner )
		tr.mask = CONTENTS_SOLID,CONTENTS_MOVEABLE,CONTENTS_MONSTER,CONTENTS_WINDOW,CONTENTS_DEBRIS,CONTENTS_GRATE,CONTENTS_AUX 
		local trace = util.TraceLine( tr )
		
		local coords = trace.HitPos:ToScreen()
		x, y = coords.x, coords.y

	else
		x, y = ScrW() / 2.0, ScrH() / 2.0
	end
	
	local scale = 10 * self.Primary.Cone
	
	// Scale the size of the crosshair according to how long ago we fired our weapon
	local LastShootTime = self.Weapon:GetNetworkedFloat( "LastShootTime", 0 )
	scale = scale * (2 - math.Clamp( (CurTime() - LastShootTime) * 5, 0.0, 1.0 ))
	
	surface.SetDrawColor( 0, 255, 0, 255 )
	
	// Draw an awesome crosshair
	local gap = 40 * scale
	local length = gap + 20 * scale
	surface.DrawLine( x - length, y, x - gap, y )
	surface.DrawLine( x + length, y, x + gap, y )
	surface.DrawLine( x, y - length, x, y - gap )
	surface.DrawLine( x, y + length, x, y + gap )

end
