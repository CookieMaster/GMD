ENT.Type = "anim"
ENT.PrintName = "NeonShop"
ENT.Author = "Malboro"
ENT.AutomaticFrameAdvance = true 
ENT.Spawnable = false
ENT.AdminSpawnable = false