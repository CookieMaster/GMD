include('shared.lua')

function Kun_Lockpick()
	local ply = LocalPlayer()
	locklbuf = ScrW() / 5
	
	Kun_Tumbs = {}

	local frame = vgui.Create("DFrame")
	frame:SetSize( 500, 500 )
	frame:Center()
	frame:SetDraggable( false )
	frame:SetVisible( true )
	frame:ShowCloseButton( true )
	frame:MakePopup()
	frame:SetTitle(" ")
	frame.Paint = function(frame)
		kunsid = math.floor(gui.MouseX() / locklbuf) + 1

		surface.SetDrawColor( 250, 250, 250, 255) 
		surface.DrawRect(0 , 0, frame:GetWide(), frame:GetTall() )
		
		surface.SetDrawColor( 50, 50,50, 255) 
		surface.DrawRect(2 , 2, frame:GetWide()-4, frame:GetTall()-4 )
		
		local mtumb = Material("pick.png")
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( mtumb )
		if(KUN_LOCKPICKICON != nil) then
			KUN_LOCKPICKICON:SetPos((kunsid * 100) - 400, frame:GetTall() - 60)
		end
		--surface.DrawTexturedRect( (kunsid * 100) - 500, frame:GetTall() - 50, 476, 36)

		--draw.SimpleText("Lockpick", "Default", (kunsid * 100) - 200, frame:GetTall() - 50, Color(255,255,255,255))
		
		surface.SetDrawColor( 240, 240,240, 255) 
		surface.DrawRect(10 , 100, frame:GetWide() - 20, 5 )
		surface.DrawRect(10 , frame:GetTall() - 100, frame:GetWide() - 20, 5 )
		surface.DrawRect(10 , frame:GetTall() - 185, frame:GetWide() - 20, 5 )
		
		for i=1,5 do
			surface.DrawRect(i * 100, 130, 5, frame:GetTall() - 200 )
		end
		
		draw.SimpleText("Lockpicking", "DermaLarge", frame:GetWide() / 2, 50, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("Click the tumblers until all of them are above the line at the same time.", "Default", 10, 80, Color(255,255,255,255))
	end
	frame.DoClose = function()
		if(KUN_LOCKPICKBUTT != nil and KUN_LOCKPICKBUTT:IsValid()) then
			KUN_LOCKPICKBUTT:Remove()
		end
	end
	KUN_LOCKPICKMEN = frame
	
	local icon = vgui.Create( "DModelPanel", frame )
	icon:SetAnimated(false)
	icon:SetAnimSpeed(0)
	icon:SetModel( "models/weapons/w_crowbar.mdl" )
	icon:SetPos(10, frame:GetTall() - 100)
	icon:SetSize( 400, 80 )
	icon:SetCamPos( Vector( 0, 50, 120 ) )
	icon:SetLookAt( Vector( 0, 0, 0 ) )
	icon:SetFOV(20)
	KUN_LOCKPICKICON = icon
	
	function icon:LayoutEntity( ) return end

	if(Kun_LockpickBreakOnFail == 1) then
		timer.Simple( Kun_LockpickFailTime, function() if(frame != nil and frame:IsValid()) then frame:Close() net.Start("Kun_LockpickFail") net.SendToServer() end end )
	end
		
	for i=1,5 do
		local tumb = vgui.Create("DPanel", frame)
		tumb:SetSize( 30, 70 )
		tumb:SetPos((i * 100) - 66, frame:GetTall() - 175)
		tumb.Paint = function(tumb)
			kunsid = math.floor(gui.MouseX() / locklbuf) + 1
			
			surface.SetDrawColor( 250, 250, 250, 255) 
			surface.DrawRect(0 , 0, tumb:GetWide(), tumb:GetTall() )
			
			if(i == kunsid) then
				surface.SetDrawColor( 0, 200, 0, 255) 
			else
				surface.SetDrawColor( 100, 100, 100, 255) 
			end
			surface.DrawRect(2 , 2, tumb:GetWide()-4, tumb:GetTall()-4 )
			

			local mtumb = Material("tumbler.png")
			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.SetMaterial( mtumb )
			surface.DrawTexturedRect( 0, 0, tumb:GetWide(), tumb:GetTall())
					
			surface.SetDrawColor( 240, 240,240, 255) 
			surface.DrawRect(10 , 100, tumb:GetWide() - 20, 5 )
			
			draw.SimpleText("Lockpicking", "DermaLarge", frame:GetWide() / 2, 50, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		Kun_Tumbs[i] = tumb
	end
	Kun_ManageTumbs()
	
	local clicktumb = vgui.Create("DButton")
	clicktumb:SetSize(ScrW(), ScrH())
	clicktumb:SetPos(0,0)
	clicktumb:SetText("")
	clicktumb.Paint = function() end
	clicktumb.DoClick = function()
		Kun_CheckTumbs()
	end
	KUN_LOCKPICKBUTT = clicktumb
	
	local clicktumb2 = vgui.Create("DButton",frame)
	clicktumb2:SetSize(frame:GetWide(), frame:GetTall() - 30)
	clicktumb2:SetPos(0,30)
	clicktumb2:SetText("")
	clicktumb2.Paint = function() end
	clicktumb2.DoClick = function()
		Kun_CheckTumbs()
	end	
end
net.Receive( "Kun_Lockpick", Kun_Lockpick)

function Kun_CheckTumbs()
	--Buf = 240
	--SCRW = 1200
	local id = math.floor(gui.MouseX() / locklbuf) + 1
	if(id <= 0 or id > 5) then return end
	if(Kun_Tumbs != nil and Kun_Tumbs[id] != nil and Kun_Tumbs[id]:IsValid()) then
		Kun_Tumbs[id].SpecAdd = (math.random(Kun_MinLockpickValAdd,Kun_MaxLockpickValAdd) * 0.1)
		Kun_Tumbs[id]:SetPos(Kun_Tumbs[id].x, 130)
		
		KUNDONEPICK = 1
		for i=1,5 do
			if(Kun_Tumbs[i].y >= 245) then
				KUNDONEPICK = 0
			end
		end
		if(KUNDONEPICK == 1) then
			net.Start("Kun_FinishLockpicking")
			net.SendToServer()
			KUN_LOCKPICKMEN:Close()
		end
	end
end

function Kun_ManageTumbs(id)
	if(KUN_LOCKPICKMEN != nil and KUN_LOCKPICKMEN:IsValid()) then
		for k,v in pairs(Kun_Tumbs) do
			local id = k
			if(Kun_Tumbs[id] != nil and Kun_Tumbs[id]:IsValid()) then
				if(Kun_Tumbs[id].y < 400 and Kun_Tumbs[id].y < KUN_LOCKPICKMEN:GetTall() - 175) then
					Kun_Tumbs[id]:SetPos(Kun_Tumbs[id].x, Kun_Tumbs[id].y + Kun_Tumbs[id].SpecAdd + 1)
				end
			end
		end
		timer.Simple(0.005, function() Kun_ManageTumbs() end )
	end
end