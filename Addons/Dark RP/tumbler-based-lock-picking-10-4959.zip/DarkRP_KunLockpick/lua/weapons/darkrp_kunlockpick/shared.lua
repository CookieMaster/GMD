if SERVER then
	AddCSLuaFile("shared.lua")
	AddCSLuaFile("cl_init.lua")
	util.AddNetworkString( "Kun_Lockpick" )
	util.AddNetworkString( "Kun_FinishLockpicking" )
	util.AddNetworkString( "Kun_LockpickFail" )
	resource.AddFile( "materials/Tumbler.png" )
end

Kun_VehicleLockpicking = 1 --Set to 0 to disable lockpicking vehicles.
Kun_LockpickFailTime = 20 --Time to lock before you fail.

Kun_LockpickBreakOnWin = 1 --Gives a chance to break on win
Kun_LockpickBreakOnFail = 1 --Gives a chance to break on fail.
Kun_LockpickBreakChance = 10 --1 / 10 to break

Kun_MaxLockpickValAdd = 30 -- This affects the speed in which tumblers will fall.
Kun_MinLockpickValAdd = 10 -- This affects the speed in which tumblers will fall.

if(CLIENT) then
	SWEP.PrintName = "Lockpick+"
	SWEP.Slot = 5
	SWEP.SlotPos = 0
	SWEP.DrawAmmo = false
	SWEP.DrawCrosshair = false
	SWEP.Author = "Kunit"
	SWEP.Instructions = "Left click to start picking."
end

SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.ViewModel = Model("models/weapons/v_crowbar.mdl")
SWEP.WorldModel = Model("models/weapons/w_crowbar.mdl")

SWEP.Spawnable = false
SWEP.AdminSpawnable = true
SWEP.Sound = ""
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

function SWEP:Initialize()
	self:SetWeaponHoldType("normal")
end

function SWEP:Deploy()
	if SERVER then
		self.Owner:DrawWorldModel(false)
	end
end

function SWEP:PrimaryAttack()
	if SERVER then
		local ply = self.Owner
		local ent = ply:GetEyeTrace().Entity
		if(ply.KLockpickTime == nil or (CurTime() - ply.KLockpickTime) >= 2) then
			DarkRP_K_Lockpick(ply,ent)
		end
		return
	end
end

function SWEP:SecondaryAttack()
	return
end

function DarkRP_K_Lockpick(ply,door)
	local carslist = list.Get("SCarsListz") --SCars table to auto-load
	if(carslist != nil and Kun_VehicleLockpicking == 1) then
		FOUNDSCARZ = 0
		for k,v in pairs(carslist) do
			if(v.Base == door:GetClass()) then
				FOUNDSCARZ = 1
			end
		end
	end
		
	if((string.find(door:GetClass(),"door") != nil) or (Kun_VehicleLockpicking == 1 and door:IsVehicle()) or (FOUNDSCARZ != nil and FOUNDSCARZ == 1)) then

		net.Start("Kun_Lockpick")
		net.Send(ply)
		ply.KLockpickTime = CurTime()
		return
	end
end

net.Receive( "Kun_LockpickFail", function( length, ply )
	if(Kun_LockpickBreakOnFail == 1) then
		local breakchance = math.random(1,Kun_LockpickBreakChance)
		if(breakchance == 1) then
			ply:StripWeapon("darkrp_kunlockpick")
			GAMEMODE:Notify(ply, 0, 4, "Your Lockpick broke!")
		end
	end
end )

net.Receive( "Kun_FinishLockpicking", function( length, ply )
		local ent = ply:GetEyeTrace().Entity
		ent:Fire("Unlock")
		ent:EmitSound("doors/latchunlocked1.wav")
		if(Kun_LockpickBreakOnWin == 1) then
			local breakchance = math.random(1,Kun_LockpickBreakChance)
			if(breakchance == 1) then
				ply:StripWeapon("darkrp_kunlockpick")
				GAMEMODE:Notify(ply, 0, 4, "Your Lockpick broke!")
			end
		end
end )
