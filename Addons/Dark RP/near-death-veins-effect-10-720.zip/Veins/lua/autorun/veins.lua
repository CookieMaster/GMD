if SERVER then
	resource.AddSingleFile("materials/veins.vmt")
	resource.AddSingleFile("materials/veins.vtf")
	resource.AddSingleFile("materials/veins2.vmt")
	resource.AddSingleFile("materials/veins2.vtf")
	resource.AddSingleFile("materials/redring.vmt")
	resource.AddSingleFile("materials/redring.vtf")
else

	local RING = surface.GetTextureID( "redring" )
	local VEINS = surface.GetTextureID( "veins2" )
	local VEINS2 = surface.GetTextureID( "veins" )

	CreateClientConVar("hide_veins",0,true,false)
	
	function PlayerHudEffect()
		if GetConVar("hide_veins"):GetBool() then return end
		local ply = LocalPlayer()
		if !ply:Alive() then return end
		local x = 100-ply:Health() -- math.Clamp(100-((ply:Health())),0,40)

		if ply:Health() < 40 then
			surface.SetTexture( RING )
			local speed = x/4
			local mul = math.sin(CurTime()*speed/7 + math.pi/1.5)+1
			--print(mul)
			--draw.SimpleText(tostring(mul),"Default",0,0,Color(255,255,255,255))
			surface.SetDrawColor(Color(255,255,255,mul*(x/4)))
			surface.DrawTexturedRect(0,0,ScrW(),ScrH())
		end
		if ply:Health() < 25 then
			local speed = x/4
			local mul = math.sin(CurTime()*speed/7 + math.pi/1.2)+1

			surface.SetTexture( VEINS )
			surface.SetDrawColor(Color(160,150,110,mul*(x/1.5)))
			surface.DrawTexturedRect(0,0,ScrW(),ScrH())

			local mul = math.sin(CurTime()*speed/7 + math.pi/1.5)+1

			surface.SetTexture( VEINS2 )
			surface.SetDrawColor(Color(160,150,110,mul*(x/1.5)))
			surface.DrawTexturedRect(0,0,ScrW(),ScrH())
		end
	end

	hook.Add("HUDPaint","Veins_Effect",PlayerHudEffect)
end
--DrawMotionBlur( 0.1, f1*f2, 0.05)