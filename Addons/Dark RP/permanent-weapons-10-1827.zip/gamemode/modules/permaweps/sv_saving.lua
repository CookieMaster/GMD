--SV

hook.Add("InitPostEntity", "DealerInitPostEntity", function()
	if !file.Exists("dealerpositions.txt", "DATA") then
		MsgN("Please Set Up Some Dealers!")
	else
		local Table = util.JSONToTable(file.Read("dealerpositions.txt", "DATA"))
		
		for k,v in pairs(Table) do
			local ent = ents.Create(v.class)
				ent:SetPos(v.pos)
				ent:SetAngles(v.ang)
				ent:Spawn()
				local phys = ent:GetPhysicsObject()
					if(IsValid(phys)) then
					phys:EnableMotion(false)
					end
		end
	end
end)


AddChatCommand("/spawnwepdealer", function(ply)
	if !ply:IsSuperAdmin() then
		ply:ChatPrint("Insufficient Permissions")
		return
	end
	
	local ent = ents.Create("npc_dealer")
	ent:SetPos(ply:FindPlayerTrace().HitPos)
	ent:Spawn()
	
	ply:SendLua([[surface.PlaySound("UI/buttonclick.wav")]])
end)

function SaveDealerPositions()
	local Dealers = {}
	for k,v in pairs(ents.FindByClass("npc_dealer")) do
		table.insert(Dealers, {pos = v:GetPos(), ang = v:GetAngles(), class = v:GetClass()})
	end
	file.Write("dealerpositions.txt", util.TableToJSON(Dealers))
	for k,v in pairs(player.GetAll()) do
		if(!v:IsSuperAdmin()) then continue end
		v:ChatPrint("Dealers Saved!")
	end
end

local meta = FindMetaTable("Player")
function meta:FindPlayerTrace()
	local ply = self
	local pos = ply:GetShootPos()
	local ang = ply:GetAimVector()
	local tracedata = {}
	tracedata.start = pos
	tracedata.endpos = pos + (ang * 100)
	tracedata.filter = self
	local trace = util.TraceLine(tracedata)
	return trace
end