--SV
util.AddNetworkString("Weps_HandleWeapon")
util.AddNetworkString("Weps_UpdateCLWeapon")
util.AddNetworkString("Weps_OpenWeaponMenu")

local meta = FindMetaTable("Player")

function meta:OpenPermaWeaponsMenu()
	net.Start("Weps_OpenWeaponMenu")
		net.WriteTable(self.UnmountedWeapons)
		net.WriteTable(self.MountedWeapons)
	net.Send(self)
end

function meta:PermEquipWeapon(class)
	if table.HasValue(self.MountedWeapons, class) then return end
	if !table.HasValue(self.UnmountedWeapons, class) then return end
	
	self:Give( class )
	table.insert(self.MountedWeapons, class)
	table.RemoveByValue(self.UnmountedWeapons, class)
	self:SaveWeapons()
	self:ChatPrint("You have equipped you'r " .. WEPCFG.Weapons[class].name)
end

function meta:PermUnequipWeapon(class)
	if !table.HasValue(self.MountedWeapons, class) then return end
	if table.HasValue(self.UnmountedWeapons, class) then return end
	
	self:StripWeapon( class )
	table.insert(self.UnmountedWeapons, class)
	table.RemoveByValue(self.MountedWeapons, class)
	self:SaveWeapons()
	self:ChatPrint("You have unequipped you'r " .. WEPCFG.Weapons[class].name)
end

function meta:PermBuyWeapon(class)
	if table.HasValue(self.MountedWeapons, class) then return end
	if table.HasValue(self.UnmountedWeapons, class) then return end
	if(self:CanAfford(WEPCFG.Weapons[class].price)) then
		self:AddMoney(-WEPCFG.Weapons[class].price)
		self:ChatPrint("You have brought a " .. WEPCFG.Weapons[class].name .. " for $" .. WEPCFG.Weapons[class].price .. ".")
		table.insert(self.UnmountedWeapons, class)
		self:SaveWeapons()
	else
		self:ChatPrint("You cannot afford that much!")
	end
end

function meta:SaveWeapons()
	net.Start("Weps_UpdateCLWeapon")
		net.WriteTable(self.UnmountedWeapons)
		net.WriteTable(self.MountedWeapons)
	net.Send(self)
	
	local steamid = string.gsub(string.sub(self:SteamID(), 7), ":", "_")
	
	local tab = {}
	tab.mounted = self.MountedWeapons
	tab.unmounted = self.UnmountedWeapons
	tab.banned = self.BannedFromPeramWeapons
	file.Write("permaweapons/" .. steamid .. ".txt", util.TableToJSON(tab))
end

function meta:BanFromPermaWeapons()
	local steamid = string.gsub(string.sub(self:SteamID(), 7), ":", "_")
	local tab = {}
	tab.mounted = self.MountedWeapons
	tab.unmounted = self.UnmountedWeapons
	tab.banned = true
	self.BannedFromPeramWeapons = true
	file.Write("permaweapons/" .. steamid .. ".txt", util.TableToJSON(tab))
end

AddChatCommand("/banpweps", function(ply, args)
	if(ply:IsAdmin()) then
		local target = GAMEMODE:FindPlayer(args)
		if(IsValid(target)) then
			target:BanFromPermaWeapons()
			target:ChatPrint("You have been banned from Perma Weapons!")
			ply:ChatPrint("You have banned " .. target:Nick() .. " from Perma Weapons!")
		else
			ply:ChatPrint("This is not a valid player!")
		end
	end
	if ply.MountedWeapons and ply.MountedWeapons[1] then
		for k,v in pairs(ply.MountedWeapons) do
			ply:StripWeapon(v)
		end
	end
	return ""
end)

function meta:UnbanFromPermaWeapons()
	local steamid = string.gsub(string.sub(self:SteamID(), 7), ":", "_")
	local tab = {}
	tab.mounted = self.MountedWeapons
	tab.unmounted = self.UnmountedWeapons
	tab.banned = false
	self.BannedFromPeramWeapons = false
	file.Write("permaweapons/" .. steamid .. ".txt", util.TableToJSON(tab))
end

AddChatCommand("/unbanpweps", function(ply, args)
	if(ply:IsAdmin()) then
		local target = GAMEMODE:FindPlayer(args)
		if(IsValid(target)) then
			target:UnbanFromPermaWeapons()
			target:ChatPrint("You have been unbanned from Perma Weapons!")
			ply:ChatPrint("You have unbanned " .. target:Nick() .. " from Perma Weapons!")
		else
			ply:ChatPrint("This is not a valid player!")
		end
	end
	if ply.MountedWeapons and ply.MountedWeapons[1] then
		for k,v in pairs(ply.MountedWeapons) do
			ply:Give(v)
		end
	end
	return ""
end)

net.Receive("Weps_HandleWeapon", function(ln, ply) 
	local Type = net.ReadString()
	local Class = net.ReadString()
	if !ply.BannedFromPeramWeapons then
		if(Type == "Buy") then
			local group = WEPCFG.Weapons[Class].groups
			if !table.HasValue(group, "all") and !table.HasValue(group, ply:GetNetworkedString( "UserGroup" )) then 
				ply:ChatPrint("You need to have the correct rank to buy this!")
			else
				ply:PermBuyWeapon( Class )
			end
		elseif(Type == "Equip") then
			ply:PermEquipWeapon( Class )
		elseif(Type == "Unequip") then
			ply:PermUnequipWeapon( Class )
		end
	else
		ply:ChatPrint("You can't do that! you'r banned from Perma Weapons")
	end
end)

hook.Add("PlayerSpawn", "GiveWeaponPlayer", function(ply)
	if !ply.BannedFromPeramWeapons then
		if ply.MountedWeapons and ply.MountedWeapons[1] then
			for k,v in pairs(ply.MountedWeapons) do
				ply:Give(v)
			end
		end
	end
	
end)

hook.Add("PlayerInitialSpawn", "IntitialSpawnPermWeps", function(ply)
	timer.Simple(2, function()
		ply.MountedWeapons = {}
		ply.UnmountedWeapons = {}
		ply.BannedFromPeramWeapons = false
		local steamid = string.gsub(string.sub(ply:SteamID(), 7), ":", "_")
		
		if (file.Exists("permaweapons/" .. steamid .. ".txt", "DATA")) then
			local tab = util.JSONToTable(file.Read("permaweapons/" .. steamid .. ".txt", "DATA"))
			ply.BannedFromPeramWeapons = tab.banned or false
			ply.MountedWeapons = tab.mounted
			ply.UnmountedWeapons = tab.unmounted
		end
		if !ply.BannedFromPeramWeapons then
			if ply.MountedWeapons and ply.MountedWeapons[1] then
				for k,v in pairs(ply.MountedWeapons) do
					ply:Give(v)
				end
			end
		end
	end)
end)

hook.Add("InitPostEntity", "PermaWeaponsFolder", function()
	if (!file.IsDir("permaweapons", "DATA")) then
		file.CreateDir("permaweapons")
	end
end)

hook.Add("OnPlayerChangedTeam", "ChangeTeamWeps", function(ply,lastteam)
		if !ply.BannedFromPeramWeapons then
		if ply.MountedWeapons and ply.MountedWeapons[1] then
			for k,v in pairs(ply.MountedWeapons) do
				ply:Give(v)
			end
		end
	end
end)


