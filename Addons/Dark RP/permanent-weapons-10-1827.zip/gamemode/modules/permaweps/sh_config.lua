WEPCFG = {}
WEPCFG.Weapons = {}

local function AddWeapon(namein, classin, modelin, pricein, groupsin)
	WEPCFG.Weapons[classin] = {name = namein, class = classin, model = modelin, price = pricein, groups = groupsin}
	MsgN("Weapon Added: " .. namein)
end

AddWeapon("Pump Shotgun", "weapon_pumpshotgun2", "models/weapons/w_shot_m3super90.mdl", 24000, {"all"})
AddWeapon("AK-47", "weapon_ak472", "models/weapons/w_rif_ak47.mdl", 20000, {"all"})
AddWeapon("MP5", "weapon_mp52", "models/weapons/w_smg_mp5.mdl", 16000, {"all"})
AddWeapon("Mac 10", "weapon_mac102", "models/weapons/w_smg_mac10.mdl", 12000, {"all"})
AddWeapon("Deagle", "weapon_deagle2", "models/weapons/w_pist_deagle.mdl", 8000, {"all"})
AddWeapon("Five Seven", "weapon_fiveseven2", "models/weapons/w_pist_fiveseven.mdl", 5000, {"vip"})












