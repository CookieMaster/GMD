--CL
LocalPlayer().MountedWeapons = LocalPlayer().MountedWeapons or {}
LocalPlayer().UnmountedWeapons = LocalPlayer().UnmountedWeapons or {}
net.Receive("Weps_OpenWeaponMenu", function()
	LocalPlayer().UnmountedWeapons = net.ReadTable()
	LocalPlayer().MountedWeapons = net.ReadTable()
	local WepFrame  = vgui.Create( "DFrame" )
		WepFrame:SetTitle( "PermaWeapons (TCWilliamson)" )
		WepFrame:SetSize( 500, 400 )
		WepFrame:Center()
		WepFrame:MakePopup()

		local WepScroll = vgui.Create( "DScrollPanel", WepFrame )
		WepScroll:SetSize( 490, 365 )
		WepScroll:SetPos( 5, 30 )

		local WepList = vgui.Create( "DIconLayout", WepScroll )
		WepList:SetSize( 475, 365 )
		WepList:SetPos( 0, 0 )
		WepList:SetSpaceY( 5 )
		WepList:SetSpaceX( 5 )
		
		local function DoPanel()
			for k,v in pairs(WepList:GetChildren()) do
				v:Remove()
			end
			for _,tab in pairs(WEPCFG.Weapons) do
				local WepListItem = WepList:Add( "DPanel" )
				WepListItem:SetSize( 470, 74 )
				WepListItem.Paint = function()
					draw.RoundedBox( 4, 0, 0, WepListItem:GetWide(), WepListItem:GetTall(), Color( 155, 155, 155, 150 ) )
					draw.RoundedBox( 4, 5, 5, 64, 64, Color( 55, 55, 55, 150 ) )
					draw.DrawText( "Name: " .. tab.name, "PermaWepFont", 75, 5, Color(0, 0, 0, 255), TEXT_ALIGN_LEFT )
					draw.DrawText( "Price: $" .. tab.price, "PermaWepFont", 75, 24, Color(0, 0, 0, 255), TEXT_ALIGN_LEFT )
					if !table.HasValue(tab.groups, "all") and !table.HasValue(tab.groups, LocalPlayer():GetNetworkedString( "UserGroup" )) then 
						draw.DrawText( "VIP Only", "PermaWepFont", 75, 40, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT )
					end
				end
				local SpawnI = vgui.Create( "SpawnIcon" , WepListItem )
					SpawnI:SetPos( 5,5 )
					SpawnI:SetModel( tab.model )
					SpawnI:SetToolTip( tab.name )
				
				local BuyMount = vgui.Create( "DButton", WepListItem )
					BuyMount:SetSize( 100, 32 )
					BuyMount:SetPos( 365, 37 )
					
					if (LocalPlayer().MountedWeapons and LocalPlayer().MountedWeapons[1] and table.HasValue(LocalPlayer().MountedWeapons, tab.class)) then
						BuyMount:SetText( "Unequip Weapon" )
						BuyMount.DoClick = function( button )
							net.Start("Weps_HandleWeapon")
								net.WriteString("Unequip")
								net.WriteString(tab.class)
							net.SendToServer()
						end
					elseif(LocalPlayer().UnmountedWeapons and #LocalPlayer().UnmountedWeapons > 0 and table.HasValue(LocalPlayer().UnmountedWeapons, tab.class)) then
						BuyMount:SetText( "Equip Weapon" )
						BuyMount.DoClick = function( button )
							net.Start("Weps_HandleWeapon")
								net.WriteString("Equip")
								net.WriteString(tab.class)
							net.SendToServer()
						end
					else
						BuyMount:SetText( "Buy Weapon" )
						BuyMount.DoClick = function( button )
							net.Start("Weps_HandleWeapon")
								net.WriteString("Buy")
								net.WriteString(tab.class)
							net.SendToServer()
						end
					end
					
			end 
		end
		DoPanel()
		net.Receive("Weps_UpdateCLWeapon", function()
			LocalPlayer().UnmountedWeapons = net.ReadTable()
			LocalPlayer().MountedWeapons = net.ReadTable()
			DoPanel()
		end)
end)

surface.CreateFont( "PermaWepFont", {
 font = "Trebuchet",
 size = 16,
 weight = 1500,
 antialias = true
} )



