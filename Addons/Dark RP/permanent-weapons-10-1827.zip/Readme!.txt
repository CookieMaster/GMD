Thank you for purchasing this product!

To Install:
Simply Murge it with your DarkRP files!


To Use:

First, a superadmin must place down the NPC, to do this he must use the chat command "/spawnwepdealer"
He must then press E on it to save its position. to change its position, simply move it and click E on it again
to place another one, just place another one and click E on it. to remove one, use the remover tool.

As a Player:
Click E on the NPC then buy a weapon, it will automaticly update the menu, you can then equip the weapon, it will be given to you
instantly, you can then die or rejoin, you will still have it.

Banning players:
If a player is breaking the rules, you can simply ban him buy using the command "/banpweps <username here>" and he will be banned, his permaweapons stripped.

To unban a player, use the command "/unbanpweps <username here>" he will automaticly be given his permaweapons back.




ADDING A WEAPON:
open up sh_config.lua in DarkRP/gamemode/modules/PermaWeps folder

Some weapons are already added on there, please change the prices to what you wish them to be.

example:
AddWeapon("Five Seven", "weapon_fiveseven2", "models/weapons/w_pist_fiveseven.mdl", 5000, {"vip"})

AddWeapon("<NAME HERE>", "<CLASS HERE>", "<WEAPON MODEL HERE>", <PRICE HERE>, {"<USERGROUP HERE>"})

if you wish a weapon to be accessable for all to buy, simply put "all" for the usergroup like this:

AddWeapon("Five Seven", "weapon_fiveseven2", "models/weapons/w_pist_fiveseven.mdl", 5000, {"all"})

to add more then one usergroup do this:
AddWeapon("Five Seven", "weapon_fiveseven2", "models/weapons/w_pist_fiveseven.mdl", 5000, {"admin", "superadmin"})


To Contact Me:
add me on steam!
or email:
thomas.williamson@thegeekgroup.org

