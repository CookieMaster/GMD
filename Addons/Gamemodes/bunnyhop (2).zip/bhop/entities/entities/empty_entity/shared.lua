 	
ENT.Type 		= "anim"
ENT.Base 		= "base_entity"

ENT.PrintName	= ""
ENT.Author		= ""
ENT.Contact		= ""

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
ENT.RenderGroup 		= RENDERGROUP_OPAQUE

AddCSLuaFile( "shared.lua" )

/*---------------------------------------------------------
   Name: Initialize
---------------------------------------------------------*/
function ENT:Initialize()

	Msg( "Empty Entity Initialized (Remove this line!)\n" )

end
