
/*---------------------------------------------------------
   Init
   - Initialize the effect
---------------------------------------------------------*/
function EFFECT:Init( data )
	
end


/*---------------------------------------------------------
   Think
   - Returning false removes the effect.
---------------------------------------------------------*/
function EFFECT:Think( )
	return false
end

/*---------------------------------------------------------
   Render
   - Draw the effect
---------------------------------------------------------*/
function EFFECT:Render()
end
