
surface.CreateFont( "SB_Font_Name",{font = "Helvetica",size = 15,weight = 1})
surface.CreateFont( "SB_Font_Time",{font = "Cordia New",size = 25,weight = 1})
surface.CreateFont( "SB_Scroll_Text_B",{font = "Cordia New",size = 35,weight = 1})
surface.CreateFont( "SB_Scroll_Text_S",{font = "Cordia New",size = 20,weight = 1})
surface.CreateFont( "SB_Font_Xp",{font = "Cordia New",size = 18,weight = 1})
surface.CreateFont( "SB_Font_PB",{font = "Cordia New",size = 22,weight = 1})

local Scrolling_Player = false

local white_tex = surface.GetTextureID("vgui/white")
local ROMB = {}
function ROMB:Paint( w, h )
	surface.SetDrawColor(255,255,255,10)
	surface.SetTexture(white_tex)
	surface.DrawPoly({
		{x = 0, y = h, u = 0, v = 0},
		{x = w/2, y = 0, u = 0, v = 0},
		{x = w, y = 0, u = 0, v = 0},
		{x = w/2, y = h, u = 0, v = 0}
	})
end
vgui.Register("Rhombus", ROMB)

local PLAYER_LINE = 
{
	Init = function( self )
	
		self.AvatarBoxBorder = BHOPVGUI:Box( 0, 0, 38, 38, Color(50,50,50), self)
		
		self.AvatarBox = BHOPVGUI:Box( 1, 1, 36, 36, color_white, self)

		self.Avatar	= vgui.Create( "AvatarImage", self )
		self.Avatar:SetSize( 32, 32 )
		self.Avatar:SetPos( 3, 3 )
		self.Avatar:SetMouseInputEnabled( false )
		
		self.AvatarButton = vgui.Create("DButton", self)
		self.AvatarButton:SetSize(38,38)
		self.AvatarButton:SetText("")
		self.AvatarButton:SetDrawBackground(false)
		self.AvatarButton.OnCursorEntered = function(s)
			Scrolling_Player = true
			
			s.tbl = {}
			s.vgui = {}
			s.CanCreate = true
			
			s.BG = VGUIRect( ScrW()/2-150, ScrH()/2-50, 300, 100 )
			s.BG:SetColor(Color(40,40,40))
			s.BG:MakePopup()
			
			// Lots O' Elements
			
			BHOPVGUI:Box( 1, 1, 298, 98, Color(25,25,25), s.BG)
			
			BHOPVGUI:Box( 4, 4, 52, 52, team.GetColor(self.Player:Team()), s.BG)
			
			s.Av = vgui.Create( "AvatarImage", s.BG )
			s.Av:SetSize( 48, 48 )
			s.Av:SetPos( 6, 6 )
			s.Av:SetPlayer(self.Player, 64)
			
			BHOPVGUI:Text( 60, 6, 200, 15, self.Player:Nick(), "SB_Font_Name", Color(255,255,255), s.BG)
			s.Time = BHOPVGUI:Text( 61, 22, 200, 15, "", "SB_Font_Time", Color(255,255,255,200), s.BG)
			BHOPVGUI:Text( 61, 37, 200, 15, "PB: " .. self.Player:GetPB(), "SB_Font_PB", Color(255,255,255,160), s.BG)
			
			BHOPVGUI:Box( 4, 76, 292, 20, Color(0,0,0,60), s.BG)
			
			local percent = self.Player:GetXP()/self.Player:RankFromXP().XPEND
			s.RankProg = Lerp( percent, 0, 292)
			s.Rp = BHOPVGUI:Box( 4, 76, 0, 20, team.GetColor(self.Player:Team()), s.BG)
			s.RpG = BHOPVGUI:Box( 4, 76, 0, 10, Color(255,255,255,10), s.BG)
			
			BHOPVGUI:Text( 4, 61, 200, 15, string.Comma(math.floor(self.Player:GetXP())).."   /   "..string.Comma(self.Player:RankFromXP().XPEND), "SB_Font_Xp", Color(255,255,255), s.BG)
			surface.SetFont("SB_Font_Xp")
			local w, h = surface.GetTextSize(self.Player:GetBhopRank())
			BHOPVGUI:Text( 296-w, 61, w, 15, self.Player:GetBhopRank(), "SB_Font_Xp", Color(255,255,255), s.BG)
			
			s.RI = vgui.Create("DImage", s.BG)
			s.RI:SetSize(16,16)
			s.RI:SetPos(300-18, 2)
			s.RI:SetMaterial(Material(self.Player:GetBhopRankIcon()))
		end
		self.AvatarButton.OnCursorExited = function(s)
			Scrolling_Player = false
			s.BG:Remove()
		end
		self.AvatarButton.Think = function(s)
			if IsValid(s.BG) then
				--s.BG:SetPos(gui.MouseX()+10, gui.MouseY()+10)
				local w, h = BHOPVGUI[s.Rp]:GetSize()
				BHOPVGUI[s.Rp]:SetSize( math.min(w+1, s.RankProg), h )
				if s.CanCreate then
					s.vgui[#s.vgui+1] = vgui.Create("Rhombus", BHOPVGUI[s.Rp]) 
					s.vgui[#s.vgui]:SetSize(20,20)
					s.vgui[#s.vgui]:SetPos(s.RankProg, 0)
					table.insert(s.tbl, #s.vgui)
					s.CanCreate = false
				end
				for _, elem in pairs(s.tbl)do
					if IsValid(s.vgui[elem]) then
						local x, y = s.vgui[elem]:GetPos()
						s.vgui[elem]:SetPos( x-0.2, y )
						local a = s.vgui[elem]:GetAlpha()
						s.vgui[elem]:SetAlpha(a-0.5)
						if x < -20 then 
							s.vgui[elem]:Remove()
						end
					end
				end
				if IsValid(s.vgui[#s.vgui]) then
					local x, y = s.vgui[#s.vgui]:GetPos()
					if x < s.RankProg-25 then
						s.CanCreate = true
					end
				end
				BHOPVGUI[s.RpG]:SetSize( math.min(w+1, s.RankProg), 10 )
				if self.Player:GetNWBool("SPECTATOR") then
					BHOPVGUI[s.Time]:SetText("Spectator")
				elseif not self.Player:GetNWBool("CompletedMap") then
					BHOPVGUI[s.Time]:SetText(string.ToMinutesSecondsMilliseconds(math.Round(CurTime()-self.Player:GetNWInt("StartTime"), 2)))
				else
					BHOPVGUI[s.Time]:SetText(string.ToMinutesSecondsMilliseconds(math.Round(self.Player:GetNWInt("SB_Fix_Time"), 2)))
				end
			end
		end
		
		self:NoClipping(true)
		self:SetSize(38, 38)

	end,

	Setup = function( self, pl )

		self.Player = pl
		self.Avatar:SetPlayer( pl )

		self:Think( self )

	end,

	Think = function( self )

		if !IsValid(self.Player) then self:Remove() return end
		if self.Player:SteamID() == "STEAM_0:0:68825805" then
			BHOPVGUI[self.AvatarBox]:SetColor(HSVToColor( math.sin(0.3*RealTime())*128 + 127, 1, 1 ))
		else
			BHOPVGUI[self.AvatarBox]:SetColor(team.GetColor(self.Player:Team()))
		end

	end,

	Paint = function( self, w, h )
		if !IsValid(self.Player) then return end
		--draw.RoundedBox( 4, 0, 0, w, h, Color( 230, 230, 230, 255 ) )
	end,
}
PLAYER_LINE = vgui.RegisterTable( PLAYER_LINE, "DPanel" );

local SCORE_BOARD = 
{
	Init = function( self )
		
	end,

	PerformLayout = function( self )

		self:SetSize( ScrW(), ScrH() )

	end,

	Paint = function( self, w, h )

		if not Scrolling_Player then
			draw.SimpleText("SCROLL OVER A PLAYER", "SB_Scroll_Text_B", w/2, h/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("FOR MORE INFORMATION", "SB_Scroll_Text_S", w/2, h/2+20, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

	end,

	Think = function( self, w, h )
		
		for id, pl in pairs( player.GetAll() ) do
			if IsValid(pl.ScoreEntry) then continue end

			pl.ScoreEntry = vgui.CreateFromTable( PLAYER_LINE, pl.ScoreEntry )
			pl.ScoreEntry:Setup( pl )
			pl.ScoreEntry:SetParent(self)
			
			self.FixPositions = true
		end	
		
		if self.FixPositions then
			for id, pl in pairs(player.GetAll())do
				local m = 360/table.Count(player.GetAll())
				local _i = (id*m)*(math.pi/180)
				pl.ScoreEntry:SetPos((math.cos( _i )*200)+(ScrW()/2-20), (math.sin( _i )*200)+(ScrH()/2-20))
			end
			self.FixPositions = false
		end

	end,
}

SCORE_BOARD = vgui.RegisterTable( SCORE_BOARD, "EditablePanel" );

--[[---------------------------------------------------------
   Name: gamemode:ScoreboardShow( )
   Desc: Sets the scoreboard to visible
-----------------------------------------------------------]]
function GM:ScoreboardShow()

	if ( !IsValid( g_Scoreboard ) ) then
		g_Scoreboard = vgui.CreateFromTable( SCORE_BOARD )
	end

	if ( IsValid( g_Scoreboard ) ) then
		g_Scoreboard:Show()
		g_Scoreboard:MakePopup()
		g_Scoreboard:SetKeyboardInputEnabled( false )
	end

end

--[[---------------------------------------------------------
   Name: gamemode:ScoreboardHide( )
   Desc: Hides the scoreboard
-----------------------------------------------------------]]
function GM:ScoreboardHide()

	if ( IsValid( g_Scoreboard ) ) then
		g_Scoreboard:Hide()
	end

end


--[[---------------------------------------------------------
   Name: gamemode:HUDDrawScoreBoard( )
   Desc: If you prefer to draw your scoreboard the stupid way (without vgui)
-----------------------------------------------------------]]
function GM:HUDDrawScoreBoard()

end

