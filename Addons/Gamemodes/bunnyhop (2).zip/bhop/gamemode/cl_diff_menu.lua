
CreateClientConVar("bhop_no_hud", 0, true)
CreateClientConVar("p_hullsize", 44, true)
cvars.AddChangeCallback( "p_hullsize", function( convar_name, oldValue, newValue )
	--print( convar_name, value_old, value_new )
		if tonumber(newValue) > 44 then
			MsgC(Color(255,0,0), "Your hull may not be bigger than 44!\n")
			RunConsoleCommand("p_hullsize", 44)
		elseif tonumber(newValue) < 28 then
			MsgC(Color(255,0,0), "Your hull may not be smaller than 28!\n")
			RunConsoleCommand("p_hullsize", 28)
		end
		
		if tonumber(newValue) >= 28 and tonumber(newValue) <= 44 then
			net.Start("UpdatePlayerHull")
			net.WriteFloat(LocalPlayer():EntIndex())
			net.WriteFloat(math.floor(tonumber(newValue)))
			net.SendToServer()
		end
end )

local d_menu = {}
d_menu.IsOpen = false
d_menu.NextOpenTime = 0
d_menu.vgui = {}
d_menu.page = 1

timer.Create("Refresh Map Money", 1, 10, function()
d_menu.Difficulties = {
	{NAME = "EASY", TEAM = 5, DESC = {"$" .. string.Comma(math.Round(BUNNYHOP.EndingMoney*BUNNYHOP.team_mult[5])) .. " on map completion.", string.Comma(math.Round((BUNNYHOP.EndingMoney/3.14)*BUNNYHOP.team_mult[5])) .. " points on map completion.","0.8 seconds per block.", "Double block jumping is aloud."}},
	{NAME = "MEDIUM", TEAM = 7, DESC = {"$" .. string.Comma(math.Round(BUNNYHOP.EndingMoney*BUNNYHOP.team_mult[7])) .. " on map completion.", string.Comma(math.Round((BUNNYHOP.EndingMoney/3.14)*BUNNYHOP.team_mult[7])) .. " points on map completion.","0.5 seconds per block.", "Double block jumping is aloud."}},
	{NAME = "HARD", TEAM = 8, DESC = {"$" .. string.Comma(math.Round(BUNNYHOP.EndingMoney*BUNNYHOP.team_mult[8])) .. " on map completion.", string.Comma(math.Round((BUNNYHOP.EndingMoney/3.14)*BUNNYHOP.team_mult[8])) .. " points on map completion.","0.05 seconds per block.", "Double block jumping is aloud."}},
	{NAME = "NIGHTMARE", TEAM = 1, DESC = {"$" .. string.Comma(math.Round(BUNNYHOP.EndingMoney*BUNNYHOP.team_mult[1])) .. " on map completion.", string.Comma(math.Round((BUNNYHOP.EndingMoney/3.14)*BUNNYHOP.team_mult[1])) .. " points on map completion.","0.05 seconds per block.", "Double block jumping will result in death.", "Standing on platform too long will result in death."}},
	--{NAME = "PB MODE", TEAM = 2, DESC = {"$" .. string.Comma(math.Round(BUNNYHOP.EndingMoney*BUNNYHOP.team_mult[2])) .. " on map completion.", string.Comma(math.Round((BUNNYHOP.EndingMoney/3.14)*BUNNYHOP.team_mult[2])) .. " points on map completion.","0.05 seconds per block.", "Double block jumping will result in death.", "Standing on platform too long will result in death.", "If your time is higher than your PB, you will be reset."}},
	{NAME = "SIDEWAYS", TEAM = 3, DESC = {"$" .. string.Comma(math.Round(BUNNYHOP.EndingMoney*BUNNYHOP.team_mult[3])) .. " on map completion.", string.Comma(math.Round((BUNNYHOP.EndingMoney/3.14)*BUNNYHOP.team_mult[3])) .. " points on map completion.","0.05 seconds per block.", "Double block jumping will result in death.", "Standing on platform too long will result in death.", "Only W and S keys may be used."}},
	{NAME = "W-ONLY", TEAM = 4, DESC = {"$" .. string.Comma(math.Round(BUNNYHOP.EndingMoney*BUNNYHOP.team_mult[4])) .. " on map completion.", string.Comma(math.Round((BUNNYHOP.EndingMoney/3.14)*BUNNYHOP.team_mult[4])) .. " points on map completion.","0.05 seconds per block.", "Double block jumping will result in death.", "Standing on platform too long will result in death.", "Only your W key may be used."}},
	{NAME = "SPECTATOR", TEAM = 6, DESC = {"Spectate players to see how a part in the map is done.","Useful when relatively new to bunnyhop"}}
}
end)

surface.CreateFont( "Diff_title",{font = "Cordia New",size = 22,weight = 1})
surface.CreateFont( "Diff_btns",{font = "Cordia New",size = 25,weight = 1})
surface.CreateFont( "Diff_close",{font = "Cordia New",size = 27,weight = 1})
surface.CreateFont( "Diff_teamname",{font = "Cordia New",size = 30,weight = 1})
surface.CreateFont( "Diff_desc",{font = "Cordia New",size = 18,weight = 1,italic = true})
surface.CreateFont( "Diff_desc2",{font = "Cordia New",size = 20,weight = 1})
surface.CreateFont( "Diff_hull",{font = "Cordia New",size = 23,weight = 1})

concommand.Add("open_diff_menu", function(ply, cmd, arg)
	d_menu.Open()
	d_menu.IsOpen = true
	gui.EnableScreenClicker(d_menu.IsOpen)
end)

hook.Add( "Think", "d menu toggle", function()
	if input.IsKeyDown(KEY_F1) and d_menu.NextOpenTime < CurTime() then
		if d_menu.IsOpen then
			d_menu.Close()
			d_menu.IsOpen = false
		else
			d_menu.Open()
			d_menu.IsOpen = true
		end
		d_menu.NextOpenTime = CurTime()+1
		gui.EnableScreenClicker(d_menu.IsOpen)
	end
end)

local function LowerOpac( c, a)
	return Color( c.r, c.g, c.b, a)
end

function d_menu:Refresh()
	d_menu.Close()
	d_menu.Open()
end

function d_menu:Open()
	
	d_menu.main_bg = BHOPVGUI:Box( ScrW()/2-352/2, ScrH()/2-402/2, 352, 402, Color(31,35,39))
	BHOPVGUI:Box( 1, 1, 350, 400, Color(51,55,59), BHOPVGUI[d_menu.main_bg])
	
	for i = 1, 5 do
		BHOPVGUI[#BHOPVGUI+1] = vgui.Create("DImage", BHOPVGUI[d_menu.main_bg])
		BHOPVGUI[#BHOPVGUI]:SetSize(128+i*2,128+i*2)
		BHOPVGUI[#BHOPVGUI]:SetPos(350/2-(64+i), 30-i)
		BHOPVGUI[#BHOPVGUI]:SetAlpha(200/i)
		BHOPVGUI[#BHOPVGUI].ialpha = 200/i
		BHOPVGUI[#BHOPVGUI]:SetMaterial(Material("materials/bunnyhop_logo.png"))
		BHOPVGUI[#BHOPVGUI].Think = function(s)
			s:SetAlpha(math.Clamp(math.sin(3*RealTime())*(s.ialpha/2), 0, s.ialpha))
		end
	end
	
	BHOPVGUI[#BHOPVGUI+1] = vgui.Create("DImage", BHOPVGUI[d_menu.main_bg])
	BHOPVGUI[#BHOPVGUI]:SetSize(128,128)
	BHOPVGUI[#BHOPVGUI]:SetPos(350/2-64, 30)
	BHOPVGUI[#BHOPVGUI]:SetMaterial(Material("materials/bunnyhop_logo.png"))
	
	local close_btn = BHOPVGUI:Btn( 350-20, 0, 20, 20, BHOPVGUI[d_menu.main_bg])
	BHOPVGUI[close_btn].Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(0,0,0,50) )
		draw.SimpleText( "x", "Diff_close", w/2, h/2, Color(255,255,255,60), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	BHOPVGUI[close_btn].DoClick = function()
		d_menu.Close()
		d_menu.IsOpen = false
		gui.EnableScreenClicker(false)
	end
	
	surface.SetFont("Diff_title")
	local w, h = surface.GetTextSize("BUNNY HOP")
	BHOPVGUI:Text( 350/2-w/2, 20, 200, 20, "BUNNY HOP", "Diff_title", Color(255,255,255,20), BHOPVGUI[d_menu.main_bg])
	
	surface.SetFont("Diff_desc")
	local w, h = surface.GetTextSize("A gamemode by Ilya, hosted by " .. GetHostName() .. ".")
	BHOPVGUI:Text( 350/2-w/2, 140, 200, 20, "A gamemode by Ilya, hosted by " .. GetHostName() .. ".", "Diff_desc", Color(255,255,255,20), BHOPVGUI[d_menu.main_bg])
	
	if d_menu.page == 1 then
		d_menu.DrawMain()
	elseif d_menu.page == 2 then
		d_menu.DrawDifficulties()
	elseif d_menu.page == 3 then
		d_menu.DrawSettings()
	elseif d_menu.page == 4 then
		d_menu.DrawHelp()
	end
end

function d_menu:DrawMain()
	BHOPVGUI:Box( 1, 180, 350, 110, Color(227,139,100), BHOPVGUI[d_menu.main_bg])
	
	BHOPVGUI:Box( 1, 290, 350, 111, Color(126,222,217), BHOPVGUI[d_menu.main_bg])
	
	local settings_btn = BHOPVGUI:Btn( 350/2-200/2, 180+110/2-30, 200, 60, BHOPVGUI[d_menu.main_bg])
	BHOPVGUI[settings_btn].Paint = function( s, w, h )
		draw.RoundedBox( 4, 0, 0, w, h, Color(0,0,0,50) )
		draw.SimpleText( "Player Settings", "Diff_btns", w/2, h/2, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	BHOPVGUI[settings_btn].DoClick = function()
		d_menu.page = 3
		d_menu:Refresh()
	end
	
	local diff_btn = BHOPVGUI:Btn( 350/2-200/2, 290+111/2-30, 200, 60, BHOPVGUI[d_menu.main_bg])
	BHOPVGUI[diff_btn].Paint = function( s, w, h )
		draw.RoundedBox( 4, 0, 0, w, h, Color(0,0,0,50) )
		draw.SimpleText( "Bunny Hop Difficulty", "Diff_btns", w/2, h/2, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	BHOPVGUI[diff_btn].DoClick = function()
		d_menu.page = 2
		d_menu:Refresh()
	end
end

function d_menu:DrawDifficulties()
	local back_btn = BHOPVGUI:Btn( 0, 0, 40, 20, BHOPVGUI[d_menu.main_bg])
	BHOPVGUI[back_btn].Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(0,0,0,50) )
		draw.SimpleText( "BACK", "Diff_close", w/2, h/2, Color(255,255,255,60), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	BHOPVGUI[back_btn].DoClick = function()
		d_menu.page = 1
		d_menu:Refresh()
	end
	
	BHOPVGUI[#BHOPVGUI+1] = vgui.Create( "DScrollPanel", BHOPVGUI[d_menu.main_bg])
    BHOPVGUI[#BHOPVGUI]:SetSize(350, 400-180)
    BHOPVGUI[#BHOPVGUI]:SetPos(0,180)
	BHOPVGUI[#BHOPVGUI].VBar.Paint = function( s, w, h )
		draw.RoundedBox( 4, 3, 13, 8, h-24, Color(0,0,0,70))
	end
	BHOPVGUI[#BHOPVGUI].VBar.btnUp.Paint = function( s, w, h ) end
	BHOPVGUI[#BHOPVGUI].VBar.btnDown.Paint = function( s, w, h ) end
	BHOPVGUI[#BHOPVGUI].VBar.btnGrip.Paint = function( s, w, h )
		draw.RoundedBox( 4, 5, 0, 4, h+22, Color(0,0,0,70))
	end
	local diff_scroller = #BHOPVGUI
	
	for _, d in pairs(d_menu.Difficulties)do
		local last_box = BHOPVGUI:Btn( 2, (_-1)*51, 348, 50)
		BHOPVGUI[last_box].s = 1
		BHOPVGUI[last_box].u = 1
		BHOPVGUI[last_box].nextdesc = CurTime() + math.random( 2, 5 )
		BHOPVGUI[last_box].DoClick = function()
			RunConsoleCommand("team_" .. d.TEAM)
			d_menu.Close()
			d_menu.IsOpen = false
			gui.EnableScreenClicker(false)
		end
		BHOPVGUI[last_box].Paint = function( s, w, h )
			local desc = d.DESC[s.u]
			if CurTime() >= s.nextdesc then
				s.u = s.u + 1
				s.nextdesc = CurTime() + math.random( 2, 5 )
				if s.u > #d.DESC then
					s.u = 1
				end
			end
			draw.RoundedBox( 0, 0, 0, w, h, Color(40,40,40,70) )
			draw.RoundedBox( 0, 0, 0, s.s, h, LowerOpac( team.GetColor(d.TEAM), 20) )
			draw.SimpleText( d.NAME, "Diff_teamname", 5, h/2, Color(255,255,255,60), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
			draw.SimpleText( desc, "Diff_desc2", w-25, h/2, Color(255,255,255,20), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER )
		end
		BHOPVGUI[last_box].OnCursorEntered = function(s)
			s.DoLoad = true
		end
		BHOPVGUI[last_box].OnCursorExited = function(s)
			s.DoLoad = false
		end
		BHOPVGUI[last_box].Think = function(s)
			if s.DoLoad then
				s.s = math.min(s.s + 10, s:GetWide())
			else
				s.s = math.max(s.s - 10, 1)
			end
		end
		BHOPVGUI[diff_scroller]:Add(BHOPVGUI[last_box])
	end
end

function d_menu:DrawHelp()
	
end

function d_menu:DrawSettings()
	local back_btn = BHOPVGUI:Btn( 0, 0, 40, 20, BHOPVGUI[d_menu.main_bg])
	BHOPVGUI[back_btn].Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(0,0,0,50) )
		draw.SimpleText( "BACK", "Diff_close", w/2, h/2, Color(255,255,255,60), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	BHOPVGUI[back_btn].DoClick = function()
		d_menu.page = 1
		d_menu:Refresh()
	end
	
	BHOPVGUI[#BHOPVGUI+1] = vgui.Create( "DScrollPanel", BHOPVGUI[d_menu.main_bg])
    BHOPVGUI[#BHOPVGUI]:SetSize(350, 400-180)
    BHOPVGUI[#BHOPVGUI]:SetPos(0,180)
	BHOPVGUI[#BHOPVGUI].VBar.Paint = function( s, w, h )
		draw.RoundedBox( 4, 3, 13, 8, h-24, Color(0,0,0,70))
	end
	BHOPVGUI[#BHOPVGUI].VBar.btnUp.Paint = function( s, w, h ) end
	BHOPVGUI[#BHOPVGUI].VBar.btnDown.Paint = function( s, w, h ) end
	BHOPVGUI[#BHOPVGUI].VBar.btnGrip.Paint = function( s, w, h )
		draw.RoundedBox( 4, 5, 0, 4, h+22, Color(0,0,0,70))
	end
	local sett_scroller = #BHOPVGUI
	
	BHOPVGUI:Text( 5, 0, 200, 20, "HULL SIZE", "Diff_hull", Color(130,130,130), BHOPVGUI[sett_scroller])
	
	BHOPVGUI[#BHOPVGUI+1] = vgui.Create( "Slider", BHOPVGUI[d_menu.main_bg])
	BHOPVGUI[#BHOPVGUI]:SetPos( 10, 20 ) 
	BHOPVGUI[#BHOPVGUI]:SetWide( 330 )
	BHOPVGUI[#BHOPVGUI]:SetMin( 28 )
	BHOPVGUI[#BHOPVGUI]:SetMax( 44 )
	BHOPVGUI[#BHOPVGUI]:SetValue( GetConVarNumber("p_hullsize") )
	BHOPVGUI[#BHOPVGUI]:SetDecimals( 0 )
	BHOPVGUI[#BHOPVGUI].OnValueChanged = function( s, value )
		RunConsoleCommand( "p_hullsize", math.floor(value) )
	end
	BHOPVGUI[#BHOPVGUI].Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(0,0,0,50) )
	end
	BHOPVGUI[sett_scroller]:Add(BHOPVGUI[#BHOPVGUI])
	
	BHOPVGUI[#BHOPVGUI+1] = vgui.Create( "DCheckBoxLabel" )
	BHOPVGUI[#BHOPVGUI]:SetPos( 10, 60 )
	BHOPVGUI[#BHOPVGUI]:SetText( "Disable Bunnyhop HUD" )
	BHOPVGUI[#BHOPVGUI]:SetConVar( "bhop_no_hud" ) 
	BHOPVGUI[#BHOPVGUI]:SetValue( GetConVarNumber("bhop_no_hud") )
	BHOPVGUI[#BHOPVGUI]:SizeToContents()
	BHOPVGUI[sett_scroller]:Add(BHOPVGUI[#BHOPVGUI])
	
	BHOPVGUI[#BHOPVGUI+1] = vgui.Create( "DCheckBoxLabel" ) 
	BHOPVGUI[#BHOPVGUI]:SetPos( 10, 80 )
	BHOPVGUI[#BHOPVGUI]:SetText( "Play sounds on map complete" )
	BHOPVGUI[#BHOPVGUI]:SetConVar( "bhop_soundplay" ) 
	BHOPVGUI[#BHOPVGUI]:SetValue( GetConVarNumber("bhop_soundplay") )
	BHOPVGUI[#BHOPVGUI]:SizeToContents()
	BHOPVGUI[sett_scroller]:Add(BHOPVGUI[#BHOPVGUI])
	
	BHOPVGUI[#BHOPVGUI+1] = vgui.Create( "DCheckBoxLabel" ) 
	BHOPVGUI[#BHOPVGUI]:SetPos( 10, 100 )
	BHOPVGUI[#BHOPVGUI]:SetText( "Show chat notifications on map complete" )
	BHOPVGUI[#BHOPVGUI]:SetConVar( "bhop_chat_notify" ) 
	BHOPVGUI[#BHOPVGUI]:SetValue( GetConVarNumber("bhop_chat_notify") )
	BHOPVGUI[#BHOPVGUI]:SizeToContents()
	BHOPVGUI[sett_scroller]:Add(BHOPVGUI[#BHOPVGUI])
	
end

function d_menu:Close()
	BHOPVGUI[d_menu.main_bg]:Remove()
end
