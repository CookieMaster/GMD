/* To do:
     - MySQLoo Support
     - Prestige Ranks
*/

BUNNYHOP = BUNNYHOP or {}

local Player = FindMetaTable("Player")

function Player:RankFromXP()
	local xp = tonumber(self:GetXP())
	for _, rank in pairs(BUNNYHOP.Ranks)do
		if xp >= rank.XPSTART and xp < rank.XPEND then
			return rank
		end
	end
	return {NAME = "Max Rank", XPSTART = 0, XPEND = 0, ICON = "icon16/exclamation.png"}
end

function Player:GetXP()
	return self:GetNWInt("Bunnyhop_EXP", 0)
end

function Player:GetBhopRank()
	return self:RankFromXP().NAME
end

function Player:GetBhopRankIcon()
	return self:RankFromXP().ICON
end

function Player:GetNextBhopRank()
	local xp = self:GetXP()
	for _, rank in pairs(BUNNYHOP.Ranks)do
		if xp >= rank.XPSTART and xp < rank.XPEND then
			return BUNNYHOP.Ranks[_+1]
		end
	end
end

function Player:GetPB()
	return string.ToMinutesSecondsMilliseconds(math.Round(tonumber(self:GetNWInt("Personal_Best")),2))
end

if SERVER then
	
	hook.Add("PlayerInitialSpawn", "SetPlayersEXP", function(ply)
		ply:SetNWInt("Bunnyhop_EXP", ply:GetPData("Bunnyhop_EXP", 0))
		ply:SetNWInt("Personal_Best", ply:GetPData("PB_"..game.GetMap(), 0))
	end)
	
	function Player:UpdatePB( time )
		self:SetNWInt("Personal_Best", math.Round(time, 2))
		self:SavePB( time )
	end
	
	function Player:SavePB( time )
		self:SetPData("PB_"..game.GetMap(), math.Round(time, 2))
	end
	
	function Player:UpdateXP( xp )
		local newxp = self:GetNWInt("Bunnyhop_EXP")+xp
		self:SetNWInt("Bunnyhop_EXP", newxp)
		self:SaveXP( newxp )
	end
	
	function Player:SaveXP( xp )
		self:SetPData("Bunnyhop_EXP", xp)
	end
	
end
