local LB = {}
LB.NextOpenTime = CurTime()
LB.IsOpen = false
local CurLB = 1

local LEADERBOARDS = LEADERBOARDS or { 
	easy = {},
	medium = {},
	hard = {},
	nightmare = {},
	sideways = {},
	wonly = {}
}

LB.Names = { "easy", "medium", "hard", "nightmare", "sideways", "w-only"}

net.Receive("LB_SendLB", function()
	LEADERBOARDS = net.ReadTable()
	--PrintTable(LEADERBOARDS)
end)

--PrintTable(LEADERBOARDS)

local function NumToLb(n)
	if n == 1 then return LEADERBOARDS.easy end
	if n == 2 then return LEADERBOARDS.medium end
	if n == 3 then return LEADERBOARDS.hard end
	if n == 4 then return LEADERBOARDS.nightmare end
	if n == 5 then return LEADERBOARDS.sideways end
	if n == 6 then return LEADERBOARDS.wonly end
end

surface.CreateFont( "LB_diff",{font = "Cordia New",size = 22,weight = 1})
surface.CreateFont( "LB_diff_s",{font = "Cordia New",size = 15,weight = 1})

concommand.Add("open_wr", function()
	LB.Open()
	LB.IsOpen = true
	gui.EnableScreenClicker(LB.IsOpen)
end)

hook.Add( "Think", "lb toggle", function()
	if input.IsKeyDown(KEY_F2) and LB.NextOpenTime < CurTime() then
		if LB.IsOpen then
			LB.Close()
			LB.IsOpen = false
		else
			LB.Open()
			LB.IsOpen = true
		end
		LB.NextOpenTime = CurTime()+1
		gui.EnableScreenClicker(LB.IsOpen)
	end
end)

function LB:Refresh()
	LB.Close()
	LB.Open()
end

function LB:Open()
	LB.main_bg = BHOPVGUI:Box( ScrW()/2-402/2, ScrH()/2-462/2, 402, 462, Color(31,35,39))
	BHOPVGUI:Box( 1, 1, 400, 460, Color(51,55,59), BHOPVGUI[LB.main_bg])
	
	local close = BHOPVGUI:Btn( 380, 2, 20, 20, BHOPVGUI[LB.main_bg])
	BHOPVGUI[close].Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(0,0,0,50) )
		draw.SimpleText( "x", "LB_diff", w/2, h/2, Color(255,255,255,70), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	BHOPVGUI[close].DoClick = function()
		LB.Close()
		LB.IsOpen = false
		gui.EnableScreenClicker(LB.IsOpen)
	end
	
	for i = 1, 6 do
		local b = BHOPVGUI:Btn( 2+(i-1)*61, 2, 60, 20, BHOPVGUI[LB.main_bg])
		BHOPVGUI[b].Paint = function( s, w, h )
			if i == CurLB then
				draw.RoundedBox( 0, 0, 0, w, h, Color(227,139,100) )
			else
				draw.RoundedBox( 0, 0, 0, w, h, Color(0,0,0,50) )
			end
			draw.SimpleText( LB.Names[i], "LB_diff", w/2, h/2, Color(255,255,255,70), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end
		BHOPVGUI[b].DoClick = function()
			CurLB = i
			LB:Refresh()
		end
	end
	
	BHOPVGUI[#BHOPVGUI+1] = vgui.Create( "DScrollPanel", BHOPVGUI[LB.main_bg])
    BHOPVGUI[#BHOPVGUI]:SetSize(398, 460)
    BHOPVGUI[#BHOPVGUI]:SetPos(2,43)
	BHOPVGUI[#BHOPVGUI].VBar.Paint = function( s, w, h )
		draw.RoundedBox( 4, 3, 13, 8, h-24, Color(0,0,0,70))
	end
	BHOPVGUI[#BHOPVGUI].VBar.btnUp.Paint = function( s, w, h ) end
	BHOPVGUI[#BHOPVGUI].VBar.btnDown.Paint = function( s, w, h ) end
	BHOPVGUI[#BHOPVGUI].VBar.btnGrip.Paint = function( s, w, h )
		draw.RoundedBox( 4, 5, 0, 4, h+22, Color(0,0,0,70))
	end
	local lb_scroller = #BHOPVGUI
	
	table.sort(NumToLb(CurLB), function(a, b) return tonumber(a.TIME) < tonumber(b.TIME) end)
	
	for i, t in pairs(NumToLb(CurLB))do
		local b = BHOPVGUI:Box( 1, (i-1)*41, 396, 40, Color(0,0,0,50), BHOPVGUI[LB.main_bg])
		if t.STEAM == LocalPlayer():SteamID() then
			BHOPVGUI[b]:SetColor(Color(126,222,217,40))
		end
		BHOPVGUI[b].Paint = function( s, w, h )
			draw.RoundedBox( 0, 0, 0, w, h, s:GetColor())
			draw.SimpleText( t.NAME, "LB_diff", 45, h/2, Color(255,255,255,70), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
			draw.SimpleText( string.ToMinutesSecondsMilliseconds(math.Round(t.TIME,2)), "LB_diff", 275, h/2, Color(255,255,255,50), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
			draw.SimpleText( t.STEAM, "LB_diff_s", w, h-5, Color(255,255,255,10), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER )
		end
		local a = BHOPVGUI:Box( 1, 1, 38, 38, Color(0,0,0,50), BHOPVGUI[b])
		BHOPVGUI[a].Paint = function( s, w, h )
			draw.RoundedBox( 0, 0, 0, w, h, s:GetColor())
			draw.SimpleText( i, "LB_diff", w/2, h/2, Color(255,255,255,70), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end
		BHOPVGUI[lb_scroller]:AddItem(BHOPVGUI[b])
	end
	
	if #NumToLb(CurLB) == 0 then
		local a = BHOPVGUI:Box( 1, 50, 400, 78, Color(0,0,0,50), BHOPVGUI[LB.main_bg])
		BHOPVGUI[a].Paint = function( s, w, h )
			draw.SimpleText( "NO TIMES FOR THIS MAP ON THIS DIFFICULTY!", "LB_diff", w/2, h/2, Color(255,255,255,70), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		end
	end
end

function LB:Close()
	BHOPVGUI[LB.main_bg]:Remove()
end