
util.AddNetworkString( "GetEndPos" )
util.AddNetworkString( "TeamMultiplier" )
util.AddNetworkString( "e_notify" )
util.AddNetworkString( "FinishedMap" )
util.AddNetworkString( "ResetFinished" )
util.AddNetworkString( "ending_remove" )
util.AddNetworkString( "end_map_playsound" )

local team_multiplier = {
	[1] = 2,
	[2] = 2.3,
	[3] = 2.5,
	[4] = 3.0,
	[5] = 1,
	[6] = 0,
	[7] = 1.5,
	[8] = 1.7
}

BUNNYHOP = BUNNYHOP or {}

local EndCreated = false
local EndingFound = false
local MapMoney = 0
local SentPos = false
local EndingPos = Vector(0,0,0)
local s_end = ents.Create("prop_physics")
local c_end = ents.Create("prop_physics")
local EndMat = "models/wireframe"
local MoveDistance = 10
local LOCAL_ENDINGS = {}
local MapCompleters = {}

local function e_notify( t, ply)
	net.Start("e_notify")
	net.WriteTable(t)
	if ply then net.Send(ply)
	else net.Broadcast() end
end

hook.Add("PlayerInitialSpawn", "SendTeamMultUpdates", function(ply)
	net.Start("TeamMultiplier")
	net.WriteTable(team_multiplier)
	net.Send(ply)
end)

hook.Add("PlayerSpawn", "NotFinished", function(ply)
	ply.CompletedMap = false
	net.Start("ResetFinished")
	net.Send(ply)
end)

local function AppendLine(filename, addme)
	local datar = file.Read(filename)
	if ( datar ) then
		file.Write(filename, datar .. "|" .. tostring(addme))
	else
		file.Write(filename, tostring(addme))
	end
end

local function CreateEndingList()
	local ending_data = file.Read("data/map_ending.txt", true)
	local end_lines = string.Explode("|", ending_data)
	for k, v in pairs(end_lines)do
		local d = string.Explode(" ", v)
		LOCAL_ENDINGS[d[1]] = { d[2], Vector(d[3],d[4],d[5]) }
		if d[1] == game.GetMap() then
			EndingPos = LOCAL_ENDINGS[game.GetMap()][2]
			MapMoney = LOCAL_ENDINGS[game.GetMap()][1]
			EndingFound = true
		end
	end
	--PrintTable(LOCAL_ENDINGS)
end
CreateEndingList()

concommand.Add("bhop_end_map", function(ply,cmd,arg)

	if not BUNNYHOP.PlayerCanAddEndingAndStarting(ply) then return end
	if EndingFound then return end
	if not arg[1] then return end
	
	local pos = ply:GetPos()
	local money = tonumber(arg[1])
	
	s_end = ents.Create("prop_physics")
	c_end = ents.Create("prop_physics")
	
	EndingPos = Vector( pos.x, pos.y, pos.z+40)
	EndingFound = true
	MapMoney = money
	
	AppendLine("map_ending.txt", game.GetMap() .. " " .. money .. " " .. tostring(EndingPos))
	timer.Simple(1, function()
		CreateEndingList()
	end)
	
end)

hook.Add("Think", "PlayerFinishMap", function()
	for _, ply in pairs(player.GetAll())do
		if !ply.CompletedMap and EndingFound then
			if ply:Team() != 6 then 
			if ply:GetPos():Distance(EndingPos) < 100 then
				local col = BUNNYHOP.NotifyColor or Color(245,198,118)
				local wol = Color(255,255,255)
				local points = math.floor(MapMoney/3.14)*team_multiplier[ply:Team()]
				local money = math.floor(MapMoney*team_multiplier[ply:Team()])
				if not table.HasValue(MapCompleters, ply:SteamID()) then
					ply:UpdateXP( points )
					table.insert(MapCompleters, ply:SteamID())
				else points = 0 end
				e_notify({col, ply:Nick(), wol, " has completed the map in ", col, string.ToMinutesSecondsMilliseconds(math.Round(CurTime()-ply:GetNWInt("StartTime"), 2)), wol, " on ", col, team.GetName(ply:Team()), wol, " mode."})
				e_notify({wol, "You have obtained ", col, "$" .. string.Comma(money), wol, " and ", col, string.Comma(points), wol, " points!"}, ply)
				if math.Round(CurTime()-ply:GetNWInt("StartTime"), 2) < tonumber(ply:GetNWInt("Personal_Best")) or tonumber(ply:GetNWInt("Personal_Best")) < 3 then
					ply:UpdatePB( CurTime()-ply:GetNWInt("StartTime") )
				end
				if BUNNYHOP.UsingPointshopUndefined then
					ply:PS_GivePoints(money)
				end
				PlayerCompletedMap(ply, CurTime()-ply:GetNWInt("StartTime"))
				ply.CompletedMap = true
				ply:SetNWBool("CompletedMap", true)
				ply:SetNWInt("SB_Fix_Time", CurTime()-ply:GetNWInt("StartTime"))
				net.Start("FinishedMap")
				net.WriteFloat(CurTime()-ply:GetNWInt("StartTime"))
				net.Send(ply)
				net.Start("end_map_playsound")
				net.Broadcast()
			end
			end
		end
	end
end)

hook.Add("Think", "ShouldCreateEnding", function()
	if EndingFound and !EndCreated then
		s_end:SetModel("models/XQM/Rails/gumball_1.mdl")
		s_end:SetMaterial(EndMat)
		s_end:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
		
		c_end:SetModel("models/hunter/blocks/cube025x025x025.mdl")
		c_end:SetMaterial(EndMat)
		c_end:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
		
		s_end:Spawn()
		c_end:Spawn()
		
		EndCreated = true
	end
	if EndCreated then
		-- Set position
		local pos = EndingPos
		local inc = math.sin( 1 * RealTime() ) * 10
		local newpos = Vector( pos.x, pos.y, pos.z + inc)
		s_end:SetPos(newpos)
		c_end:SetPos(newpos)
		
		-- Set angles
		local yaw = math.sin( 0.5 * RealTime() ) * 180
		local pitch = math.sin( 1 * RealTime() ) * 90
		local roll = math.sin( 1.5 * RealTime() ) * 30
		local newang = Angle( pitch, yaw, roll)
		s_end:SetAngles(newang)
		c_end:SetAngles(newang*2)
		
		-- Color :3
		c_end:SetColor(HSVToColor(math.sin(1*RealTime())*128+127, 1, 1))
		--s_end:SetColor(HSVToColor(math.abs(math.sin(0.7*RealTime())*128), 1, 1))
		
		--if not SentPos then
			net.Start("GetEndPos")
			net.WriteVector(newpos)
			net.WriteFloat(MapMoney)
			net.Broadcast()
			--SentPos = true
		--end
	end
end) 

concommand.Add("bhop_remove_ending", function(ply)
	if not BUNNYHOP.PlayerCanAddEndingAndStarting(ply) then return end
	
	-- remove old
	local p = EndingPos
	EndingFound = false
	EndCreated = false
	s_end:SetPos( Vector(p.x, p.y, p.z-200) )
	c_end:SetPos( Vector(p.x, p.y, p.z-200) )
	net.Start("ending_remove")
	net.Broadcast()
	
	-- delete from file
	local temp = {}
	for _, v in pairs(LOCAL_ENDINGS)do
		if _ != game.GetMap() then
			temp[_] = v
		end
	end	
	
	file.Delete("map_ending.txt")
	
	for _, v in pairs(temp)do
		AppendLine("map_ending.txt", _ .. " " .. v[1] .. " " .. tostring(v[2]))
	end
	
end)
