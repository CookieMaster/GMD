-- Need to replace all the CSS weapons.

AddCSLuaFile()



if SERVER then
	concommand.Add("make_zomb", function(ply)
		local c = ents.Create("weapon_smg1")
		c:SetPos(ply:GetPos())
		c:Spawn()
	end)
end