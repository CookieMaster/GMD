-- Initial stuff
BUNNYHOP = BUNNYHOP or {}

-- Add more bunnyhop ranks here
-- Ranks are made in the order you create them here.
-- So the start of each rank will be the end of the last created rank.
--           Rank         Points      Icon
AddBhopRank( "Newbie",    100,        "icon16/award_star_bronze_1.png")
AddBhopRank( "Beginner",  5000,       "icon16/award_star_bronze_2.png")
AddBhopRank( "Learning",  15000,      "icon16/award_star_bronze_3.png")
AddBhopRank( "Rookie",    30000,      "icon16/award_star_silver_1.png")
AddBhopRank( "Casual",    60000,      "icon16/award_star_silver_2.png")
AddBhopRank( "Usual",     100000,     "icon16/award_star_silver_3.png")
AddBhopRank( "Decent",    180000,     "icon16/award_star_gold_1.png")
AddBhopRank( "Good",      260000,     "icon16/award_star_gold_2.png")
AddBhopRank( "Addict",    390000,     "icon16/award_star_gold_3.png")

-- Color of key text when a player completes a map or recieves xp/money
BUNNYHOP.NotifyColor = Color(89,191,255)

-- Here you can add or remove sounds that play when someone completes a map
-- NOTE: the player can toggle these off in the settings menu. (f1)
BUNNYHOP.MapCompleteSounds = {
	"vo/Citadel/eli_goodgod.wav",
	"vo/Citadel/eli_notobreen.wav",
	"vo/coast/barn/female01/youmadeit.wav",
	"vo/coast/barn/male01/youmadeit.wav",
	"vo/coast/odessa/female01/nlo_cheer01.wav",
	"vo/coast/odessa/female01/nlo_cheer02.wav",
	"vo/coast/odessa/female01/nlo_cheer03.wav",
	"vo/coast/odessa/male01/nlo_cheer01.wav",
	"vo/coast/odessa/male01/nlo_cheer02.wav",
	"vo/coast/odessa/male01/nlo_cheer03.wav",
	"vo/eli_lab/al_sweet.wav"
}

-- Are you using Pointshop by undefined?
-- If so set this to true so players can get money on map complete.
BUNNYHOP.UsingPointshopUndefined = false 

-- I would recommend it stay at this or close to it
BUNNYHOP.DefaultHullStanding = 60 

-- This will be the weapon that replaces all weapons on the map
BUNNYHOP.DefaultWeapon = "weapon_smg1"

-- Here you can change or add weapons that the gamemode will replace in the map.
-- In case you installed an addon for css weapons or have custom weapons in your 
-- pointshop.
BUNNYHOP.AcceptableWeapons = {
	"weapon_smg1",
	"weapon_crowbar",
	"no_wep"
}

-- Here you can define what players can add endings and startings to maps
/*
	Example:
	
	if ply:IsUserGroup("admin") then
		return true end
		
	Typically if your using ULX, you'll want to use ply:IsUserGroup("name of group")
	then if your using Evolve then you may want to use ply:EV_GetRank() == "ranknamehere"
	
	If need help message me on steam. :)
*/
function BUNNYHOP.PlayerCanAddEndingAndStarting(ply)

	if ply:IsAdmin() then
		return true end
		
	-- leave the return false so if the player fits none of the above
	-- he has no access to do so.
	return false
	
end


-- Developer help
/*
	If you have a custom chat box that allows you to use line icons or chat tags 
	then this may be on interest for you.
	
	To get the player's Bhop rank call the function 
		ply:GetBhopRank()
	
	To get the icon of their current rank call the function
		ply:GetBhopRankIcon()
	
	If you also wanted to get the player's personal best for this map, you would call
		ply:GetPB()
*/

-- Adding and removing ending / startings
/*
	
	------ Adding a starting
	Although a starting for a map is not needed you can add them if wanted.
	They are created like so, In one corner of the box you want to make do
	place_point in console, then you go to the opposite corner of the box you 
	are trying to make and do place_point once more. The starting for the map will
	then be saved and will load everytime for the map. If you misplace point 1 then
	you can use reset_start_placement in console to reset point 1.
	
	------ Adding an ending
	Endings are needed for a map so that you can see your time and get your points
	and money. When you find out where you want to place the ending simply do
	bhop_end_map <money> in console where you want to place the ending, I recommend you
	do this in spectator mode and stay close to the ground when placing it. This is so
	that you don't mess up your leaderboards. The ending will now be saved and the
	points / money will be calculated depending on team and your input number. 
	
	------ Removing an ending
	If at any time you want to remove an ending so you can replace it or just want
	to get rid of it you can do bhop_remove_ending in console and it will remove
	the ending for the map you are currently on.
	
	------ Removing a starting
	If you want to remove the starting of a map you can do remove_bhop_start in
	console and it will delete the starting from the save file and allow you to 
	replace new points for the starting.
	
*/