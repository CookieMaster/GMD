
BUNNYHOP = BUNNYHOP or {}

CreateClientConVar("bhop_soundplay", 1, true)
CreateClientConVar("bhop_chat_notify", 1, true)

local EndingPos = Vector(0,0,0)
local CreatedEnding = false
local got_team_stuff = false

surface.CreateFont( "3D2DComplete", { font = "Bebas Neue", size = 80, weight = 300 } )
surface.CreateFont( "3D2DInfo", { font = "Bebas Neue", size = 40, weight = 300 } )

net.Receive("GetEndPos", function()
	EndingPos = net.ReadVector()
	BUNNYHOP.EndingMoney = net.ReadFloat()
	CreatedEnding = true
end)

net.Receive("TeamMultiplier", function()
	BUNNYHOP.team_mult = net.ReadTable()
	got_team_stuff = true
end)

net.Receive("e_notify", function()
	if GetConVarNumber("bhop_chat_notify") == 1 then
		chat.AddText(unpack(net.ReadTable()))
		chat.PlaySound()
	end
end)

net.Receive("ending_remove", function()
	CreatedEnding = false
end)

net.Receive("end_map_playsound", function()
	if GetConVarNumber("bhop_soundplay") == 1 then
		surface.PlaySound(table.Random(BUNNYHOP.MapCompleteSounds))
	end
end)

hook.Add("PostDrawTranslucentRenderables", "Draw Ending Text", function()
	local ang = LocalPlayer():EyeAngles()
	ang:RotateAroundAxis( ang:Forward(), 90 )
	ang:RotateAroundAxis( ang:Right(), 90 )
	local pos = EndingPos
	--local inc = math.sin( 1 * RealTime() ) * 10 + 30
	local newpos = Vector( pos.x, pos.y, pos.z + 30)
	if CreatedEnding and got_team_stuff then
		local PlayerTeam = LocalPlayer():Team() or 1
		cam.Start3D2D( newpos, Angle( 0, ang.y, 90 ), 0.15)
		
			surface.SetFont("3D2DComplete")
			local w, h = surface.GetTextSize("COMPLETE MAP")
			draw.DrawText( "COMPLETE MAP", "3D2DComplete", -(w/2), 0, Color(255,255,255,255) )
			
			surface.SetFont("3D2DInfo")
			local t = ""
			if CurTime() - LocalPlayer():GetNWInt("StartTime") > 5 then
				t = "FOR $" .. string.Comma(math.floor(BUNNYHOP.EndingMoney*BUNNYHOP.team_mult[PlayerTeam])) .. " AND " .. string.Comma(math.floor((BUNNYHOP.EndingMoney/3.14)*BUNNYHOP.team_mult[PlayerTeam])) .. " POINTS!"	
			end
			local w, h = surface.GetTextSize(t)
			draw.DrawText( t, "3D2DInfo", -(w/2), 60, team.GetColor(LocalPlayer():Team()))
			
		cam.End3D2D()
	end
end)
