/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
///////////////////////////Spectator/////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

hook.Add("PlayerInitialSpawn", "Not Specing", function(ply)
	ply:SetNWBool("SPECTATOR", false)
	ply.Spec = 0
end)

local function SpecPly(ply)
	if ply.Spec >= table.Count(player.GetAll()) then
		ply.Spec = 1
	end
	for _, v in pairs(player.GetAll())do
		if _ > ply.Spec then
			if v:Team() != 6 and v != ply and IsValid(v) then
				ply.Spec = _
				ply:SetNWInt("Spectating", _)
				return player.GetAll()[_]
			end
		end
	end
end

hook.Add("PlayerDisconnected", "NextPlayerSpec", function(ply)
	for _, p in pairs(player.GetAll())do
		if p:GetNWBool("SPECTATOR") then
			if p != ply and p:GetNWInt("Spectating", 0) == ply:EntIndex() then
				p:ConCommand("spectate")
			end
		end
	end
end)

concommand.Add("spectate", function( ply, cmd, arg )
	
	ply:SetTeam(6)
	ply:StripWeapons()
	
	if not ply:GetNWBool("SPECTATOR") then
		ply:Spectate( OBS_MODE_CHASE )
	end
	ply:SpectateEntity(SpecPly(ply))
	ply:SetNWBool("SPECTATOR", true)
	
end)

concommand.Add("endspectator", function(ply)
	ply:SetNWBool("SPECTATOR", false)
end)

concommand.Add("povchange", function(ply)
	if(ply:GetObserverMode() == OBS_MODE_CHASE  ) then
		ply:Spectate( OBS_MODE_IN_EYE )
	elseif(ply:GetObserverMode() == OBS_MODE_IN_EYE ) then
		ply:Spectate( OBS_MODE_ROAMING )
	elseif(ply:GetObserverMode() == OBS_MODE_ROAMING)then
		ply:Spectate( OBS_MODE_CHASE )
	end
end)
