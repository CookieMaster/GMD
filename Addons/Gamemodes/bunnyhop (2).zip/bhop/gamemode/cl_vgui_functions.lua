
function BHOPVGUI:Box( x, y, w, h, c, p)
	BHOPVGUI[#BHOPVGUI+1] = VGUIRect( x, y, w, h )
	BHOPVGUI[#BHOPVGUI]:SetColor(c)
	BHOPVGUI[#BHOPVGUI]:SetParent(p)
	return #BHOPVGUI
end

function BHOPVGUI:Text( x, y, w, h, tt, f, c, p)
	BHOPVGUI[#BHOPVGUI+1] = vgui.Create( "DLabel", p)
	BHOPVGUI[#BHOPVGUI]:SetPos( x, y )
	BHOPVGUI[#BHOPVGUI]:SetSize( w, h )
	BHOPVGUI[#BHOPVGUI]:SetText(tt)
	BHOPVGUI[#BHOPVGUI]:SetFont(f)
	BHOPVGUI[#BHOPVGUI]:SetColor(c)
	return #BHOPVGUI
end

function BHOPVGUI:Btn( x, y, w, h, p)
	BHOPVGUI[#BHOPVGUI+1] = vgui.Create( "DButton", p)
	BHOPVGUI[#BHOPVGUI]:SetPos( x, y )
	BHOPVGUI[#BHOPVGUI]:SetSize( w, h )
	BHOPVGUI[#BHOPVGUI]:SetText("")
	BHOPVGUI[#BHOPVGUI]:SetDrawBackground(false)
	return #BHOPVGUI
end