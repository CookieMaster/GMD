
hook.Add("PlayerBindPress", "Log keys for spectator", function( ply, bind, pressed )
	if ply:Team() == 6 then
		if string.find(string.lower(bind), "jump") then
			ply:ConCommand("povchange")
		elseif string.find(string.lower(bind), "attack") then
			ply:ConCommand("spectate")
		end
	end
end)
