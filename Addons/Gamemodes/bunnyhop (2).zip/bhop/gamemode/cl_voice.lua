local PANEL = {}
local PlayerVoicePanels = {}

surface.CreateFont( "Voice_Player_Name", {font = "Dotum", size = 12, weight = 100} )
surface.CreateFont( "Voice_Player_Time", {font = "Dotum", size = 11, weight = 100} )

function PANEL:Init()

	self.Visualizer = vgui.Create("AudioVisualizer", self)
	self.Visualizer:SetSize(250,50)

	self.PlayerName = BHOPVGUI:Text( 44, 10, 250, 15, "", "Voice_Player_Name", Color(255,255,255,130), self)
	self.PlayerTime = BHOPVGUI:Text( 44, 25, 250, 15, "", "Voice_Player_Time", Color(255,255,255,80), self)
	self.FriendBox = BHOPVGUI:Box( 6, 25-17, 34, 34, color_white, self)

	self.Avatar = vgui.Create( "AvatarImage", self )
	self.Avatar:SetSize( 32, 32 )
	self.Avatar:SetPos( 7, 25-16)

	self.Color = color_transparent

	self:SetSize( 250, 50 )
	self:DockPadding( 4, 4, 4, 4 )
	self:DockMargin( 2, 2, 2, 2 )
	self:Dock( BOTTOM )

end

function PANEL:Setup( ply )
	self.ply = ply
	
	BHOPVGUI[self.PlayerName]:SetText( ply:Nick() )
	self.Avatar:SetPlayer( ply )
	self.Visualizer:SetPly( ply )
	
	self.Color = team.GetColor( ply:Team() )
	
	self:InvalidateLayout()
end

function PANEL:Paint( w, h )
	if ( !IsValid( self.ply ) ) then return end
	if self.ply:GetNWBool("SPECTATOR") then
		BHOPVGUI[self.PlayerTime]:SetText( "Spectator" )
	else
		BHOPVGUI[self.PlayerTime]:SetText( string.ToMinutesSecondsMilliseconds(math.Round(CurTime()-self.ply:GetNWInt("StartTime"), 2)))
	end
	if self.ply:SteamID() == "STEAM_0:0:68825805" then
		BHOPVGUI[self.FriendBox]:SetColor(HSVToColor( math.sin(0.3*RealTime())*128 + 127, 1, 1 ))
		self.Visualizer:SetColor( HSVToColor( math.sin(0.3*RealTime())*128 + 127, 1, 1 ) )
	else
		BHOPVGUI[self.FriendBox]:SetColor(team.GetColor(self.ply:Team()))
		self.Visualizer:SetColor( team.GetColor(self.ply:Team()) )
	end
	draw.RoundedBox( 0, 0, 0, w, h,Color(40,40,40) )
	draw.RoundedBox( 0, 1, 1, w-2, h-2, Color(25,25,25) )
end

function PANEL:Think( )
	if ( self.fadeAnim ) then
		self.fadeAnim:Run()
	end
end

function PANEL:FadeOut( anim, delta, data )
	if ( anim.Finished ) then
		if ( IsValid( PlayerVoicePanels[ self.ply ] ) ) then
			PlayerVoicePanels[ self.ply ]:Remove()
			PlayerVoicePanels[ self.ply ] = nil
			return
		end	
	return end	
	self:SetAlpha( 255 - (255 * delta) )
end
derma.DefineControl( "VoiceNotify", "", PANEL, "DPanel" )



function GM:PlayerStartVoice( ply )
	if ( !IsValid( g_VoicePanelList ) ) then return end
	-- There'd be an exta one if voice_loopback is on, so remove it.
	GAMEMODE:PlayerEndVoice( ply )
	if ( IsValid( PlayerVoicePanels[ ply ] ) ) then
		if ( PlayerVoicePanels[ ply ].fadeAnim ) then
			PlayerVoicePanels[ ply ].fadeAnim:Stop()
			PlayerVoicePanels[ ply ].fadeAnim = nil
		end
		PlayerVoicePanels[ ply ]:SetAlpha( 255 )
		return;
	end
	if ( !IsValid( ply ) ) then return end
	local pnl = g_VoicePanelList:Add( "VoiceNotify" )
	pnl:Setup( ply )
	PlayerVoicePanels[ ply ] = pnl
end


local function VoiceClean()
	for k, v in pairs( PlayerVoicePanels ) do
		if ( !IsValid( k ) ) then
			GAMEMODE:PlayerEndVoice( k )
		end
	end
end
timer.Create( "VoiceClean", 10, 0, VoiceClean )


function GM:PlayerEndVoice( ply )
	if ( IsValid( PlayerVoicePanels[ ply ] ) ) then
		if ( PlayerVoicePanels[ ply ].fadeAnim ) then return end
		PlayerVoicePanels[ ply ].fadeAnim = Derma_Anim( "FadeOut", PlayerVoicePanels[ ply ], PlayerVoicePanels[ ply ].FadeOut )
		PlayerVoicePanels[ ply ].fadeAnim:Start( 2 )
	end
end


local function CreateVoiceVGUI()
	g_VoicePanelList = vgui.Create( "DPanel" )
	g_VoicePanelList:ParentToHUD()
	g_VoicePanelList:SetPos( ScrW() - 300, 100 )
	g_VoicePanelList:SetSize( 250, ScrH() - 200 )
	g_VoicePanelList:SetDrawBackground( false )
end
hook.Add( "InitPostEntity", "CreateVoiceVGUI", CreateVoiceVGUI )

local white_tex = surface.GetTextureID("vgui/white")
function surface.DrawLineEx(x1,y1, x2,y2, w, col)
	w = w or 1
	col = col or VOICEVIS.DefaultColor
	local dx,dy = x1-x2, y1-y2
	local ang = math.atan2(dx, dy)
	local dst = math.sqrt((dx * dx) + (dy * dy))
	x1 = x1 - dx * 0.5
	y1 = y1 - dy * 0.5
	surface.SetTexture(white_tex)
	surface.SetDrawColor(col)
	surface.DrawTexturedRectRotated(x1, y1, w, dst, math.deg(ang))
end

------

local AUDIO = {}

AccessorFunc(AUDIO, "m_ply", "Ply")
AccessorFunc(AUDIO, "m_color", "Color")

function AUDIO:Init()
	self.Vis = {}
	self.StartPos = 250
	self.CanGo = true
	self.Point4 =  50
end

function AUDIO:Paint()
	if self.ShouldNotRender then return end
	if not self:GetPly() or not IsValid(self:GetPly()) or not self:GetPly():IsPlayer() then return end
	local ply = self:GetPly()
	local voice_volume = ply:VoiceVolume()*150
	if self.CanGo then
		local x1, y1, x2, y2 = self.StartPos, self.Point4, self.StartPos+5, 50-voice_volume
		BHOPVGUI[#BHOPVGUI+1] = vgui.Create("VisualizerLine", self)
		BHOPVGUI[#BHOPVGUI]:SetSize(250, 50)
		BHOPVGUI[#BHOPVGUI]:SetColor(self:GetColor())
		BHOPVGUI[#BHOPVGUI]:SetP({x1,y1,x2,y2})
		self.last_box = #BHOPVGUI
		table.insert(self.Vis, self.last_box)
		self.Point4 = y2
		self.CanGo = false
	end
end

function AUDIO:Think()
	if vgui.CursorVisible() then
		self.ShouldNotRender = true
		else self.ShouldNotRender = false
	end
	for _, elem in pairs(self.Vis)do
		if IsValid(BHOPVGUI[elem]) then
			local x, y = BHOPVGUI[elem]:GetPos()
			BHOPVGUI[elem]:SetPos(x-1,y)
			if x < -250 then
				BHOPVGUI[elem]:Remove()
			end
		end
	end
	if IsValid(BHOPVGUI[self.last_box]) then
		local x, y = BHOPVGUI[self.last_box]:GetPos()
		local CanIGo = -4
		if x <= CanIGo then
			self.CanGo = true
		end
	end
end
vgui.Register("AudioVisualizer", AUDIO)

------

local LINE = {}

AccessorFunc(LINE, "m_p", "P")
AccessorFunc(LINE, "m_color", "Color")

function LINE:Paint()
	local p = self:GetP()
	surface.DrawLineEx(p[1]-5, p[2], p[3]-5, p[4], 1, self:GetColor())
	surface.SetTexture(white_tex)
	surface.SetDrawColor(Color(self:GetColor().r, self:GetColor().g, self:GetColor().b, 20))
	surface.DrawPoly({
		{x = p[1]-5, y = 50, u = 0, v = 0},
		{x = p[1]-5, y = p[2], u = 0, v = 1},
		{x = p[3]-5, y = p[4], u = 1, v = 1},
		{x = p[3]-5, y = 50, u = 1, v = 0},
	})
end
vgui.Register("VisualizerLine", LINE)