function GM:OnPlayerHitGround(ply)
	local plt = ply:GetGroundEntity()
	if plt:GetClass() == "func_door" then
		timer.Simple(0.03, function()
			plt:SetOwner(ply) 
		end)
		timer.Simple(0.7, function() 
			plt:SetOwner(nil)
		end)
	end
end