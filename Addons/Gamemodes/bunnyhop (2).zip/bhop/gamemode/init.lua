AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "bhop_hud.lua" )
AddCSLuaFile( "cl_scoreboard.lua" ) 
AddCSLuaFile( "cl_spectator.lua" )
AddCSLuaFile( "cl_map_ending.lua" )
AddCSLuaFile( "cl_diff_menu.lua" )
AddCSLuaFile( "cl_voice.lua" )
AddCSLuaFile( "cl_vgui_functions.lua" )
AddCSLuaFile( "sh_bhop_ranks.lua" )
AddCSLuaFile( "bunnyhop.lua" )
AddCSLuaFile( "cl_leaderboards.lua" )

include( 'shared.lua' )
include( 'sv_boosters.lua' )
include( 'sv_spectator.lua' )
include( 'sv_map_ending.lua' )
include( 'sv_diff_menu.lua' )
include( 'sh_bhop_ranks.lua' )
include( 'bunnyhop.lua' )
include( 'sv_leaderboards.lua' )

BUNNYHOP = BUNNYHOP or {}

resource.AddFile("materials/bunnyhop_logo.png")

hook.Add("Initialize", "Set Cvars", function()
	RunConsoleCommand("sv_airaccelerate", 1000)
	RunConsoleCommand("sv_gravity", 800)
	RunConsoleCommand("sv_sticktoground", 0)
	RunConsoleCommand("sv_kickerrornum", 0)
	RunConsoleCommand("sv_alltalk", 1)
end)

TimeForPlat = {
	[1] = 0.05,
	[2] = 0.05,
	[3] = 0.05,
	[4] = 0.05,
	[5] = 0.8,
	[6] = 69,
	[7] = 0.5,
	[8] = 0.05
}

plyShudDie = {
	[1] = true,
	[2] = true,
	[3] = true,
	[4] = true,
	[5] = false,
	[6] = false,
	[7] = false,
	[8] = false
}

function GM:OnPlayerHitGround(ply)
	local plt = ply:GetGroundEntity()
	
	if plt:IsWorld() then
		ply.last_plt = nil
	end
	
	if plt:GetClass() == "func_door" then
		
		if ply:GetGroundEntity():EntIndex() == ply.last_plt and plyShudDie[ply:Team()] then
			ply:Kill()
			ply.last_plt = nil
			ply.ded = true
		end
		
		if not ply.ded then
			ply.last_plt = plt:EntIndex()
		end
		
		time = TimeForPlat[ply:Team()]
			
		timer.Simple(time, function()
			plt:SetOwner(ply) 
			if plyShudDie[ply:Team()] and ply:GetGroundEntity():EntIndex() == ply.last_plt then
				ply:Kill()
			end
		end)
		
		timer.Simple(time+0.4, function() 
			plt:SetOwner(nil)
		end)
		
		ply.ded = false
	end
end

function GM:InitPostEntity()
	local doors  = ents.FindByClass("func_door")
	for k, v in pairs(doors) do
		if(game.GetMap() != "bhop_fury" and game.GetMap() != "bhop_aperture_beta") then
			v:Fire("lock", "", 0)
			if(game.GetMap() == "bhop_impulse") then
				if(v:EntIndex() == 20 or v:EntIndex() == 23 or v:EntIndex() == 22 or v:EntIndex() == 21 or v:EntIndex() == 19 or v:EntIndex() == 24)then
					v:Fire("unlock", "", 0)
				end
			end
		end
    end
end

util.AddNetworkString( "UpdatePlayerHull" )

local function SetHullSizes(ply)
	local hull = tonumber(ply:GetPData("HullSize", 44))
	
	ply:SetHull( Vector( -16, -16, 0 ), Vector( 16, 16, BUNNYHOP.DefaultHullStanding ) )
	ply:SetViewOffset(Vector(0,0,BUNNYHOP.DefaultHullStanding))
	ply:SetHullDuck(Vector(-16,-16,0), Vector( 16, 16, hull ))
	ply:SetViewOffsetDucked(Vector(0,0,hull))
	
	timer.Simple(2, function()
		ply:SendLua('LocalPlayer():SetViewOffset(Vector(0,0,BUNNYHOP.DefaultHullStanding))')
		ply:SendLua('LocalPlayer():SetViewOffsetDucked(Vector(0,0,math.Round(GetConVarNumber("p_hullsize")) or 44))')
		ply:SendLua('LocalPlayer():SetHull( Vector( -16, -16, 0 ), Vector( 16, 16, BUNNYHOP.DefaultHullStanding) )')
		ply:SendLua('LocalPlayer():SetHullDuck(Vector(-16,-16,0), Vector( 16, 16,math.Round(GetConVarNumber("p_hullsize")) or 44 ))')
	end)
end

net.Receive("UpdatePlayerHull", function()
	local ply = player.GetByID(net.ReadFloat())
	ply:SetPData("HullSize", net.ReadFloat())
	SetHullSizes(ply)
end)

function GM:PlayerInitialSpawn(ply)
	ply:SetTeam(6)
	
	ply:SetWalkSpeed( 250 ) 
    ply:SetRunSpeed( 250 )
	ply:SetJumpPower( 280 )
	ply:SetCollisionGroup(COLLISION_GROUP_WEAPON)
	
	ply:ConCommand("spectate")
	ply:ConCommand("open_diff_menu")
	
	SetHullSizes(ply)
	
	ply.PersonalBest = ply:GetPData("pb_"..game.GetMap(), 0)
end

local css_weps = {
	"weapon_awp",
	"weapon_deagle",
	"weapon_scout",
	"weapon_knife",
	"weapon_m3",
	"weapon_m249",
	"weapon_p90",
	"weapon_fiveseven",
	"weapon_ak47",
	"weapon_xm1014"
}

hook.Add("Initialize", "Replace_Weapons", function()
	for _, wep in pairs(css_weps)do
		weapons.Register( weapons.Get("blank_wep"), wep )
	end
end)

hook.Add("Think", "Replace all no weps", function()
	local dwep = BUNNYHOP.DefaultWeapon or "weapon_smg1"
	local accept_weps = BUNNYHOP.AcceptableWeapons or { "weapon_smg1",  "weapon_crowbar", "no_wep" }
	local w = ents.FindByClass("weapon_*")
	for _, wep in pairs(w)do
		if not table.HasValue(accept_weps, wep:GetClass()) then
			local p = wep:GetPos()
			local n = ents.Create(dwep)
			n:SetPos(p)
			n:Spawn()
			wep:Remove()
		end
	end
	
	for _, ply in pairs(player.GetAll())do
		if IsValid(ply:GetActiveWeapon()) then
			if ply:GetActiveWeapon():GetClass() == "weapon_smg1" then
				ply:GiveAmmo( 10000, "smg1")
			end
		end
	end
end)

concommand.Add("bhop_weapons", function(ply)
	ply:StripWeapons()
	ply:Give("weapon_crowbar")
	ply:Give("no_wep")
end)

function GM:PlayerSpawn ( ply )
	if(ply:Team() != 6) then
		ply:ConCommand("bhop_weapons")
	end
	ply:GodEnable()
	local teamcolor = team.GetColor(ply:Team())
	ply:SetModel( "models/player/group01/male_0" .. math.random( 1, 9 ) .. ".mdl" )       
    ply:SetPlayerColor( Vector(teamcolor.r/255, teamcolor.g/255, teamcolor.b/255) )
	ply:SetCollisionGroup(COLLISION_GROUP_WEAPON)
	
	if(game.GetMap() == "kz_bhop_yonkoma") then
		ply:SetPos(Vector(1617, 4141, 384))
	elseif(game.GetMap() == "kz_bhop_benchmark") then
		ply:SetPos(Vector(7175, -7166, -8074))
	end
	
	local hands = ents.Create( "gmod_hands" )
	if ( IsValid( hands ) ) then
		ply:SetHands( hands )
		hands:SetOwner( ply )

		-- Which hands should we use?
		local cl_playermodel = ply:GetInfo( "cl_playermodel" )
		local info = player_manager.TranslatePlayerHands( cl_playermodel )
		if ( info ) then
			hands:SetModel( info.model )
			hands:SetSkin( info.skin )
			hands:SetBodyGroups( info.body )
		end

		-- Attach them to the viewmodel
		local vm = ply:GetViewModel( 0 )
		hands:AttachToViewmodel( vm )

		vm:DeleteOnRemove( hands )
		ply:DeleteOnRemove( hands )

		hands:Spawn()
	end
	ply:SetNWBool("CompletedMap", false)
	ply:SetNWInt("StartTime", CurTime())
end

hook.Add("Think", "NOnotices", function()
	for k, v in pairs(player.GetAll())do
		if(!v:IsValid())then return end
		v:SetSuppressPickupNotices(true)
	end
end)

local function pickup( fag , wep)
	if(fag:HasWeapon(wep:GetClass())) then
		fag:SelectWeapon( wep:GetClass() )
		return false
	else 
		fog = fag
		wup = wep
		timer.Simple(0.2, function() fog:SelectWeapon( wup:GetClass() ) end)
		return true 
	end
end
hook.Add("PlayerCanPickupWeapon", "nopickup", pickup )

for i = 1, 8 do
	if i != 6 then
		concommand.Add("team_" .. i, function(fag)
			fag:SetTeam(i)
			fag:UnSpectate()
			fag:UnLock()
			fag:Spawn()
			fag:ConCommand("endspectator")
		end)
	end
end

concommand.Add("team_6", function(ply)
	ply:SetTeam(6)
	ply:ConCommand("spectate")
end)

function GM:GetFallDamage() return 0 end
function GM:PlayerSwitchFlashlight() return true end
function GM:PlayerShouldTakeDamage() return false end
function GM:AllowPlayerPickup() return false end

util.AddNetworkString("SendStartPoints")
util.AddNetworkString("RemoveStartPoints")

local function AppendLine(filename, addme)
	local datar = file.Read(filename)
	if ( datar ) then
		file.Write(filename, datar .. "|" .. tostring(addme))
	else
		file.Write(filename, tostring(addme))
	end
end

local point_1, point_2 = false, false
local p1, p2, p3, p4 = Vector(0,0,0), Vector(0,0,0), Vector(0,0,0), Vector(0,0,0)
local MapStartings = {}

local function GetMapStart()
	local data = file.Read("map_starting.txt")
	local ex = string.Explode("|", data)
	for _, map in pairs(ex)do
		local info = string.Explode(" ", map)
		MapStartings[info[1]] = {
			P1 = Vector(tonumber(info[2]), tonumber(info[3]), tonumber(info[4])),
			P3 = Vector(tonumber(info[5]), tonumber(info[6]), tonumber(info[7]))
		}
	end
	
	for _, map in pairs(MapStartings)do
		if _ == game.GetMap() then
			p1 = map.P1
			p3 = map.P3
			p2 = Vector( map.P1.x, map.P3.y, map.P1.z)
			p4 = Vector( map.P3.x, map.P1.y, map.P1.z)
			
			net.Start("SendStartPoints")
			net.WriteVector(p1)
			net.WriteVector(p2)
			net.WriteVector(p3)
			net.WriteVector(p4)
			net.Broadcast()
		
			hook.Add("PlayerInitialSpawn", "SendStarting", function(ply)
				net.Start("SendStartPoints")
				net.WriteVector(p1)
				net.WriteVector(p2)
				net.WriteVector(p3)
				net.WriteVector(p4)
				net.Send(ply)
			end)
			
			point_1, point_2, WrotePoints = true, true, true
		end
	end
end
GetMapStart()

local function WriteMapStartData()
	local str = game.GetMap() .. " " .. tostring(p1) .. " " .. tostring(p3)
	AppendLine("map_starting.txt", str)
end

concommand.Add("reset_start_placement", function(ply)
	if not BUNNYHOP.PlayerCanAddEndingAndStarting(ply) then return end
	 point_1, point_2 = false, false
end)

concommand.Add("remove_bhop_start", function(ply)
	if not BUNNYHOP.PlayerCanAddEndingAndStarting(ply) then return end
	
	local tbl = MapStartings
	file.Delete("map_starting.txt")
	for _, map in pairs(tbl)do
		if _ != game.GetMap() then
			local mapid, p1, p3 = _, tostring(map.P1), tostring(map.P3)
			local str = mapid .. " " .. tostring(p1) .. " " .. tostring(p3)
			AppendLine("map_starting.txt", str)
		end
	end
	
	point_1, point_2 = false, false
	WrotePoints = false
	
	net.Start("RemoveStartPoints")
	net.Broadcast()
	
end)

local WrotePoints = false
concommand.Add("bhop_place_point", function(ply, cmd, arg)
	if not BUNNYHOP.PlayerCanAddEndingAndStarting(ply) then return end
	
	if not point_1 then
		local p = ply:GetPos()
		p1 = Vector( p.x, p.y, p.z+5)
		point_1 = true
	elseif point_1 and not point_2 then
		local pp = ply:GetPos()
		p3 = Vector( pp.x, pp.y, pp.z+5)
		point_2 = true
	end
	
	if point_1 and point_2 and not WrotePoints then
		p2 = Vector( p1.x, p3.y, p1.z) 
		p4 = Vector( p3.x, p1.y, p1.z) 
	
		net.Start("SendStartPoints")
		net.WriteVector(p1)
		net.WriteVector(p2)
		net.WriteVector(p3)
		net.WriteVector(p4)
		net.Broadcast()
		
		hook.Add("PlayerInitialSpawn", "SendStarting", function(ply)
			net.Start("SendStartPoints")
			net.WriteVector(p1)
			net.WriteVector(p2)
			net.WriteVector(p3)
			net.WriteVector(p4)
			net.Send(ply)
		end)
		
		WriteMapStartData()
		
		WrotePoints = true
	end
	
end)

hook.Add("Think", "ResetTime", function()
	if point_1 and point_2 then
		local PeopleInBox = ents.FindInBox( p1, p3 )
		for o, box in pairs(PeopleInBox)do
			for _, ply in pairs(player.GetAll())do
				if box == ply and ply:GetVelocity():Length2D() < 300 then
					ply:SetNWInt("StartTime", CurTime())
					if ply.CompletedMap then
						ply.CompletedMap = false
						net.Start("ResetFinished")
						net.Send(ply)
					end
				end
			end
		end
		if #PeopleInBox == 0 then for k, v in pairs(player.GetAll())do v:SetNWBool("InsideStart", false) end end
	end
end)

hook.Add("PlayerSay", "RestartTime", function(ply, txt, pub)
	if string.lower(txt) == "/r" or string.lower(txt) == "!r" then
		if point_1 and point_2 then
			ply:SetPos(Vector(math.random(p1.x,p3.x), math.random(p1.y,p3.y), math.random(p1.z,p3.z)))
		else
			ply:Spawn()
		end
		ply.CompletedMap = false
		net.Start("ResetFinished")
		net.Send(ply)
		return ""
	end
end)
