BHOPVGUI = {}
BUNNYHOP = BUNNYHOP or {}
BUNNYHOP.team_mult = {0,0,0,0,0,0,0,0}
BUNNYHOP.EndingMoney = 0

include( 'shared.lua' )
include( 'bhop_hud.lua' ) 
include( 'cl_scoreboard.lua' )
include( 'cl_spectator.lua' )
include( 'cl_map_ending.lua' )
include( 'cl_diff_menu.lua' )
include( 'cl_voice.lua' )
include( 'cl_vgui_functions.lua' )
include( 'sh_bhop_ranks.lua' )
include( 'bunnyhop.lua' )
include( 'cl_leaderboards.lua' )

local GotNetMsg = false
local p1, p2, p3, p4 = 0, 0, 0, 0

function GM:PostDrawViewModel( vm, ply, weapon )
   if weapon.UseHands or (not weapon:IsScripted()) then
      local hands = LocalPlayer():GetHands()
      if IsValid(hands) then hands:DrawModel() end
   end
end

function HUDHide( myhud )
    for k, v in pairs{ "CHudHealth" , "CHudBattery" , "CHudAmmo"} do
        if myhud == v then return false end
    end
end
hook.Add( "HUDShouldDraw", "HUDHide", HUDHide)

function GM:DrawDeathNotice(x, y)
	return
end

function GM:HUDDrawTargetID()
     return false
end

function GM:PlayerBindPress( P, bind, pressed )
	if(P:Team() == 3)then
		if(string.find(bind, "moveleft"))then
			return true
		end
		if(string.find(bind, "moveright"))then
			return true
		end
	end
	if(P:Team() == 4)then
		if(string.find(bind, "moveleft"))then
			return true
		end
		if(string.find(bind, "moveright"))then
			return true
		end
		if(string.find(bind, "back"))then
			return true
		end
	end
end

net.Receive("RemoveStartPoints", function()
	GotNetMsg = false
end)

net.Receive("SendStartPoints", function()
	p1 = net.ReadVector()
	p2 = net.ReadVector()
	p3 = net.ReadVector()
	p4 = net.ReadVector()
	GotNetMsg = true
end)

local mat_laser = Material( "cable/redlaser" )

function GM:PostDrawOpaqueRenderables()
	if GotNetMsg then
		render.SetMaterial( mat_laser )
		render.DrawBeam( p1, p2, 5, 1, 1, Color( 255, 255, 255, 255 ) ) 
		render.DrawBeam( p2, p3, 5, 1, 1, Color( 255, 255, 255, 255 ) ) 
		render.DrawBeam( p3, p4, 5, 1, 1, Color( 255, 255, 255, 255 ) ) 
		render.DrawBeam( p4, p1, 5, 1, 1, Color( 255, 255, 255, 255 ) ) 
	end
end

local DrawName = false
local TargetPly = nil

surface.CreateFont( "BhopNameS", {font = "Arial",size = 15,weight = 1000} )
surface.CreateFont( "BhopTimeS", {font = "Arial",size = 12,weight = 100} )

hook.Add("HUDPaint", "DrawNames", function()
	if DrawName then 
		if not IsValid(TargetPly) then return end
		
		draw.SimpleTextOutlined( string.upper(TargetPly:Nick()), "BhopNameS", ScrW()/2, ScrH()/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,30) )
		draw.SimpleTextOutlined( string.upper(TargetPly:Nick()), "BhopNameS", ScrW()/2, ScrH()/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,60) )
		
		local w, h = surface.GetTextSize(string.upper(TargetPly:Nick()))
		draw.RoundedBox( 0, ScrW()/2-w/2, ScrH()/2+7, w, 1, team.GetColor(TargetPly:Team()) )
		
		draw.SimpleTextOutlined( string.ToMinutesSecondsMilliseconds(math.Round(CurTime()-TargetPly:GetNWInt("StartTime"),2)), "BhopTimeS", ScrW()/2, ScrH()/2+13, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,30) )
		draw.SimpleTextOutlined( string.ToMinutesSecondsMilliseconds(math.Round(CurTime()-TargetPly:GetNWInt("StartTime"),2)), "BhopTimeS", ScrW()/2, ScrH()/2+13, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,60) )
	end
end)

hook.Add("Think", "PlayerNames", function()
	ply = LocalPlayer():GetEyeTrace().Entity
	if ply:IsPlayer() then 
		DrawName = true
		TargetPly = ply
	else
		DrawName = false
	end
end)