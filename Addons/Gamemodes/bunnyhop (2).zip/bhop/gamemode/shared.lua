GM.Name 	= "Bunny Hop"
GM.Author 	= "Ilya"
GM.Email 	= "im3coolyo@aol.com"
GM.Website 	= "N/A"

BUNNYHOP = BUNNYHOP or {}

function GM:Initialize()
	self.BaseClass.Initialize( self )
end

//Teams
team.SetUp( 1, "Nightmare", Color( 255, 84, 84) )//red
team.SetUp( 2, "PB", Color( 200, 44, 44) ) //darker red
team.SetUp( 3, "Sideways", Color( 150, 4, 4))//darkest red
team.SetUp( 4, "W-Only", Color( 30, 30, 30) ) //black
team.SetUp( 5, "Easy", Color( 151, 252, 175) ) //green
team.SetUp( 6, "spectator", Color(203,203,203)) //grey
team.SetUp( 7, "Normal", Color( 168, 235, 255)) //blue
team.SetUp( 8, "Advanced", Color( 250, 165, 75)) //orange

BUNNYHOP.Ranks = {}
function AddBhopRank( rankname, xpneeded, icon)
	local xpstart = 0
	if #BUNNYHOP.Ranks > 0 then
		xpstart = BUNNYHOP.Ranks[#BUNNYHOP.Ranks].XPEND 
	end
	local tbl = {NAME = rankname, XPSTART = xpstart, XPEND = xpneeded, ICON = icon or "icon16/exclamation.png"}
	table.insert(BUNNYHOP.Ranks, tbl)
end
