
hook.Add( "Think", "BoosterFix", function()
	for _, ply in pairs(player.GetAll())do
		if IsValid(ply) then
			local booster = ply:GetEyeTrace().Entity
			if( ply:KeyDown( IN_ATTACK ) ) and IsValid(ply:GetActiveWeapon()) and ply:GetActiveWeapon():Clip1() > 0 then
				booster:TakeDamage( 1337, ply, "weapon_crowbar" )
			end
		end
	end
end)