If you want to use the anti script, then place the folder name anti_script in your addons folder. To install the gamemode
place the folder named bhop inside your gamemodes folder. Also place the 2 txt files located inside data into your data folder
on your server.