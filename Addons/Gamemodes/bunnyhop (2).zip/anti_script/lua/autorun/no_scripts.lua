AddCSLuaFile()

if CLIENT then
	
	local nonobinds = {
		"+bhop",
		"+bunnyhop",
		"+hop",
		"+bunny",
		"+script",
	}

	local match = string.match
	local lower = string.lower
	local HasV = table.HasValue
	local CL_RED = Color(230,50,50)
	local CL_WHT = Color(255,255,255)
	local NextPrintTime = CurTime()+1
	
	hook.Add("PlayerBindPress", "No Jump quikhop or krolek", function( ply, bind, press )
		if lower(bind) == "+jump" then
			ply:ConCommand("jump_power_sc 1")
		elseif match(lower(bind), "jump [%d]") then
			ply:ConCommand("jump_power_sc 0")
			if NextPrintTime <= CurTime() then
				chat.AddText(CL_WHT, "Bind: ", CL_RED, bind, CL_WHT, " is NOT Allowed. Please use +jump only.")
			end
			NextPrintTime = CurTime()+1
			return true
		elseif HasV(nonobinds, lower(bind)) then
			return true
		end
	end)
	
	local KeyDownCount = 0 
	
	hook.Add("Think", "krolek does not need a bind", function()
		if input.IsKeyDown(KEY_SPACE) then
			KeyDownCount = KeyDownCount + 1
		else
			KeyDownCount = 0
		end
		if KeyDownCount >= 100 and LocalPlayer():GetVelocity():Length2D() > 300 then
			LocalPlayer():ConCommand("jump_power_sc 0")
			timer.Simple(1, function() LocalPlayer():ConCommand("jump_power_sc 1") end)
			if NextPrintTime <= CurTime() then
				chat.AddText(color_white, "Bunnyhop scripts detected, stopping player speed gain.")
				NextPrintTime = CurTime()+1
			end
		end	
	end)
	
	
end

if SERVER then

	concommand.Add("jump_power_sc", function( ply, cmd, arg )
		if tonumber(arg[1]) == 1 then
			ply:SetJumpPower( 280 )
		else
			ply:SetJumpPower( 0 )
		end
	end)
	
end
