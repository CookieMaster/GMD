ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "NG Money Printer"
ENT.Author = "Netheous"
ENT.Spawnable = false
ENT.AdminSpawnable = false

sh_ng_printer = {}
sh_ng_printer.PrintAmount 	= 100 -- Money stored per print
sh_ng_printer.HeatAmount  	= 10  -- Heat gained per print
sh_ng_printer.ExpAmount		= 25  -- Experience gained per print
sh_ng_printer.PrintDelay	= 30  -- 1,25 hour to get maxed printer, better leave default ( 30 )

sh_ng_printer.LvlTbl	= {}
sh_ng_printer.LvlTbl[1]	= {ExpReq = 250, PrintMul = 1.00, StorageSize = 2000, Clr = Color( 0, 205, 0, 255 )} 	-- Green
sh_ng_printer.LvlTbl[2]	= {ExpReq = 500, PrintMul = 1.25, StorageSize = 2500, Clr = Color( 55, 180, 205, 255 )} -- Blue
sh_ng_printer.LvlTbl[3]	= {ExpReq = 750, PrintMul = 1.50, StorageSize = 3000, Clr = Color( 255, 230, 0, 255 )} 	-- Yellow
sh_ng_printer.LvlTbl[4]	= {ExpReq = 1000, PrintMul = 1.75, StorageSize = 3500, Clr = Color( 170, 0, 165, 255 )} -- Purple
sh_ng_printer.LvlTbl[5]	= {ExpReq = 1250, PrintMul = 2.25, StorageSize = 4500, Clr = Color( 190, 50, 50, 255 )} -- Red

function ENT:SetupDataTables()
	self:DTVar("Entity",1,"owning_ent")
end