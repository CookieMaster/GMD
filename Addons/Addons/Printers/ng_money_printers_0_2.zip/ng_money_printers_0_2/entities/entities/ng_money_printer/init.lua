AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

util.AddNetworkString( 'NET_PrinterInfo' )
util.AddNetworkString( 'NET_OpenPrinterMenu' )
util.AddNetworkString( 'NET_DoPrinterAction' )

local sv_ng_printer = {}

function sv_ng_printer.SendInfo( Printer )
	local Tbl 			= {}
	Tbl.Experience 		= Printer.Experience
	Tbl.Level			= Printer.Level
	Tbl.StoredMoney		= Printer.StoredMoney
	Tbl.Multiplier		= Printer.Multiplier
	Tbl.Temperature		= Printer.Temperature 

	Tbl.HasCooler		= Printer.HasCooler
	Tbl.HasTuner		= Printer.HasTuner
	Tbl.HasOverclocker	= Printer.HasOverclocker
	Tbl.IsTurnedOn		= Printer.IsTurnedOn

	net.Start( 'NET_PrinterInfo' )
		net.WriteEntity( Printer )
		net.WriteTable( Tbl )
	net.Broadcast()
end

function sv_ng_printer.DoAction()
	local PRINTER_DO_STOPSTART = 1
	local PRINTER_DO_TAKEMONEY = 2
	local PRINTER_DO_REMOVEMOD = 3

	local Caller = net.ReadEntity()
	local Printer = net.ReadEntity()
	local Action = net.ReadInt( 16 )
	local Mod = net.ReadString() or ""

	if Action == PRINTER_DO_TAKEMONEY then
		if Printer.StoredMoney <= 0 then return end
		GAMEMODE:Notify( Caller, 2, 3, "You have picked up $"..Printer.StoredMoney)
		Caller:AddMoney( Printer.StoredMoney )
		Printer.StoredMoney = 0
	end
	if Action == PRINTER_DO_STOPSTART then
		if Printer.IsTurnedOn == true then 
			Printer.IsTurnedOn = false
		else
			Printer.IsTurnedOn = true
		end
	end
	if Action == PRINTER_DO_REMOVEMOD then
		if Mod == "Cooler" then
			Printer.Cooler:Remove()
			Printer.HasCooler = false
		end
		if Mod == "Tuner" then
			Printer.Tuner:Remove()
			Printer.HasTuner = false
		end
		if Mod == "Overclocker" then
			Printer.Overclocker:Remove()
			Printer.HasOverclocker = false
		end
	end

	sv_ng_printer.SendInfo( Printer )
end
net.Receive( 'NET_DoPrinterAction', sv_ng_printer.DoAction )

function ENT:Initialize()
	self:SetModel("models/props_c17/consolebox01a.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)

	local phys = self:GetPhysicsObject()
	phys:Wake()

	self.Damage			= 100

	self.Experience 	= 0
	self.Level			= 1
	self.StoredMoney	= 0
	self.Multiplier 	= 1
	self.Temperature	= 0
	
	self.HasCooler		= false
	self.HasTuner		= false
	self.HasOverclocker	= false
	self.IsTurnedOn = true

	self.Cooler = nil
	self.Tuner = nil
	self.Overclocker = nil

	self:SetUseType( SIMPLE_USE )

	self:InitTimer()
end

function ENT:OnTakeDamage(dmg)
	self.Damage = self.Damage - dmg:GetDamage()
	if self.Damage <= 0 then
		self:Remove()
	end
end

function ENT:InitTimer()
	if self.HasOverclocker == true then
		timer.Simple( sh_ng_printer.PrintDelay - ( sh_ng_printer.PrintDelay * 0.25 ), function() 
			if not self:IsValid() then return end
			self:Print()
			self:InitTimer()
		end)
	else
		timer.Simple( sh_ng_printer.PrintDelay, function() 
			if not self:IsValid() then return end
			self:Print()
			self:InitTimer()
		end)
	end
end

function ENT:UpdateMods()
	sv_ng_printer.SendInfo( self )
end

function ENT:Print()
	if self.IsTurnedOn == false then 
		if self.Temperature > 0 then
			if self.HasCooler == true then
				self.Temperature = self.Temperature - 25
			else
				self.Temperature = self.Temperature - 20
			end
		end
		if self.Temperature < 0 then
			self.Temperature = 0
		end
	else

		if self.HasTuner then
			self.Multiplier = sh_ng_printer.LvlTbl[self.Level].PrintMul + 0.25
		end

		if self.StoredMoney < sh_ng_printer.LvlTbl[self.Level].StorageSize then
			self.StoredMoney = self.StoredMoney + sh_ng_printer.PrintAmount * self.Multiplier
			if self.Temperature >= 100 then
				self:BurningSequence()
			else
				if self.HasCooler == true then
					self.Temperature = self.Temperature + (sh_ng_printer.HeatAmount / 2)
				else
					self.Temperature = self.Temperature + sh_ng_printer.HeatAmount
				end
			end
			self:Upgrade()

			if self.StoredMoney > sh_ng_printer.LvlTbl[self.Level].StorageSize then
				self.StoredMoney = sh_ng_printer.LvlTbl[self.Level].StorageSize
			end
		else
			if self.Temperature > 0 then
				if self.HasCooler == true then
					self.Temperature = self.Temperature - (sh_ng_printer.HeatAmount * 2)
				else
					self.Temperature = self.Temperature - sh_ng_printer.HeatAmount
				end
			elseif self.Temperature < 0 then
				self.Temperature = 0
			end
		end
	end

	sv_ng_printer.SendInfo( self )
end

function ENT:Upgrade()
	if self.Level == #sh_ng_printer.LvlTbl and self.Experience == sh_ng_printer.LvlTbl[self.Level].ExpReq then return end
	
	self.Experience = self.Experience + 25

	if self.Experience >= sh_ng_printer.LvlTbl[self.Level].ExpReq and self.Level < #sh_ng_printer.LvlTbl then
		self.Level = self.Level + 1
		self.Experience = 0
		if self.HasTuner then
			self.Multiplier = sh_ng_printer.LvlTbl[self.Level].PrintMul + 0.25
		else
			self.Multiplier = sh_ng_printer.LvlTbl[self.Level].PrintMul
		end
	end

	sv_ng_printer.SendInfo( self )
end

function ENT:BurningSequence()
	if self.IsBurning == true then return end
	
	self.IsBurning = true
	self:Ignite( 15 )

	timer.Simple( 15, function() 
		if not self:IsValid() then return end
		self:Remove()
	end)
end

function ENT:Think()
end

function ENT:Use( activator, caller )
	net.Start( 'NET_OpenPrinterMenu' )
		net.WriteEntity( self )
	net.Send( caller )
end