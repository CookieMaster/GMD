ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "NG Cooler"
ENT.Author = "Netheous"
ENT.Spawnable = false
ENT.AdminSpawnable = false