AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/props_lab/reciever01a.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)

	local phys = self:GetPhysicsObject()
	self.nodupe = true
	self.ShareGravgun = true

	phys:Wake()
end


function ENT:Use(activator,caller)
	GAMEMODE:Notify(activator, 0, 4, "Printer cooler, place it on the printer to get it installed, it decreases heating by half")
end

function ENT:StartTouch(ent)
	if ent:GetClass() == "ng_money_printer" then
		if ent.HasCooler == true then return end
		ent.HasCooler = true
		ent:UpdateMods()

		local Pos, Ang = LocalToWorld( Vector( 10, -3.5, 7 ), Angle( 0, 0, 0 ), ent:GetPos(), ent:GetAngles())

		local Attachment = ents.Create('prop_physics')
		Attachment:SetModel( self:GetModel() )
		Attachment:SetPos( Pos )
		Attachment:SetAngles( Ang )
		Attachment:Spawn()
		Attachment:SetParent( ent )
		Attachment:SetCollisionGroup( COLLISION_GROUP_WORLD )

		ent.Cooler = Attachment
		--play effect

		self:SetCollisionGroup( COLLISION_GROUP_WORLD )
		self:Remove()
	end
end

function ENT:Think()
end