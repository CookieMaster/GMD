include("shared.lua")

local cl_ng_printer = {}

function cl_ng_printer.ReceiveInfo()
	local Printer 			= net.ReadEntity()
	local Tbl 				= net.ReadTable()
	Printer.Experience 		= Tbl.Experience
	Printer.Level			= Tbl.Level
	Printer.StoredMoney		= Tbl.StoredMoney
	Printer.Multiplier 		= Tbl.Multiplier
	Printer.Temperature		= Tbl.Temperature 

	Printer.HasCooler		= Tbl.HasCooler
	Printer.HasTuner		= Tbl.HasTuner
	Printer.HasOverclocker	= Tbl.HasOverclocker
	Printer.IsTurnedOn		= Tbl.IsTurnedOn
end
net.Receive( 'NET_PrinterInfo', cl_ng_printer.ReceiveInfo )

function cl_ng_printer.OpenMenu()
	local Printer = net.ReadEntity()
	local Clr = sh_ng_printer.LvlTbl[Printer.Level].Clr

	cl_ng_printer.Menu = vgui.Create( 'DFrame' )
	cl_ng_printer.Menu:SetSize( 200, 100 )
	cl_ng_printer.Menu:SetPos(ScrW()/2-cl_ng_printer.Menu:GetWide()/2, ScrH())
	cl_ng_printer.Menu:MoveTo( ScrW()/2-cl_ng_printer.Menu:GetWide()/2, ScrH()/2-cl_ng_printer.Menu:GetTall()/2, 0.25, 0, 0.5)
	cl_ng_printer.Menu:MakePopup()
	cl_ng_printer.Menu.Paint = function()
		draw.RoundedBox( 4, 0, 0, cl_ng_printer.Menu:GetWide(), cl_ng_printer.Menu:GetTall(), Color( Clr.r, Clr.g, Clr.b, Clr.a ) )
		draw.RoundedBox( 4, 2, 2, cl_ng_printer.Menu:GetWide()-4, cl_ng_printer.Menu:GetTall()-4, Color( 35, 35, 35, 255 ) )
	end

	local StartStopButton = vgui.Create( 'DButton', cl_ng_printer.Menu )
	StartStopButton:SetSize( 180, 20 )
	StartStopButton:SetPos( 10, 30 )
	StartStopButton:SetText( 'Stop Printing' )
	if Printer.IsTurnedOn == false then
		StartStopButton:SetText( 'Start Printing' )
	end
	StartStopButton.DoClick = function()
		net.Start( 'NET_DoPrinterAction' )
			net.WriteEntity( LocalPlayer() )
			net.WriteEntity( Printer )
			net.WriteInt( 1, 16 )
		net.SendToServer()
	cl_ng_printer.Menu:Close()
	end

	local PickupMoneyButton = vgui.Create( 'DButton', cl_ng_printer.Menu )
	PickupMoneyButton:SetSize( 180, 20 )
	PickupMoneyButton:SetPos( 10, 50 )
	PickupMoneyButton:SetText( 'Take stored money ($'..Printer.StoredMoney..')' )
	PickupMoneyButton.DoClick = function()
		net.Start( 'NET_DoPrinterAction' )
			net.WriteEntity( LocalPlayer() )
			net.WriteEntity( Printer )
			net.WriteInt( 2, 16 )
		net.SendToServer()
	cl_ng_printer.Menu:Close()
	end

	local UninstallModsButton = vgui.Create( 'DButton', cl_ng_printer.Menu )
	UninstallModsButton:SetSize( 180, 20 )
	UninstallModsButton:SetPos( 10, 70 )
	UninstallModsButton:SetText( 'Remove Mods' )
	UninstallModsButton.DoClick = function ()
		if not Printer.HasCooler and not Printer.HasTuner and not Printer.HasOverclocker then return end
		local MenuButtonOptions = DermaMenu()

		if Printer.HasCooler then
			MenuButtonOptions:AddOption("Cooler", function()  
			net.Start( 'NET_DoPrinterAction' )
				net.WriteEntity( LocalPlayer() )
				net.WriteEntity( Printer )
				net.WriteInt( 3, 16 )
				net.WriteString( "Cooler" )
			net.SendToServer()
			cl_ng_printer.Menu:Close()
			end )
		end
		if Printer.HasTuner then
			MenuButtonOptions:AddOption("Tuner", function()  
			net.Start( 'NET_DoPrinterAction' )
				net.WriteEntity( LocalPlayer() )
				net.WriteEntity( Printer )
				net.WriteInt( 3, 16 )
				net.WriteString( "Tuner" )
			net.SendToServer()
			cl_ng_printer.Menu:Close()
			end )
		end
		if Printer.HasOverclocker then
			MenuButtonOptions:AddOption("Overclocker", function()  
			net.Start( 'NET_DoPrinterAction' )
				net.WriteEntity( LocalPlayer() )
				net.WriteEntity( Printer )
				net.WriteInt( 3, 16 )
				net.WriteString( "Overclocker" )
			net.SendToServer()
			cl_ng_printer.Menu:Close()
			end )
		end
		MenuButtonOptions:Open()
	end
end
net.Receive( 'NET_OpenPrinterMenu', cl_ng_printer.OpenMenu )

function ENT:Initialize()
	self.Experience 	= 0
	self.Level			= 1
	self.StoredMoney	= 0
	self.Multiplier 	= 1
	self.Temperature	= 0

	self.HasCooler		= false
	self.HasTuner		= false
	self.HasOverclocker	= false
	self.IsTurnedOn		= true
end

function ENT:Draw()
	self:DrawModel()

	local Pos = self:GetPos()
	local Ang = self:GetAngles()
	local Clr = sh_ng_printer.LvlTbl[self.Level].Clr
	local ExpProgress 		= self.Experience / sh_ng_printer.LvlTbl[self.Level].ExpReq
	local StorageProgress 	= self.StoredMoney / sh_ng_printer.LvlTbl[self.Level].StorageSize
	local HeatProgress 		= self.Temperature / 100
	local Owner = "Disconnected"
	local Dist = LocalPlayer():GetPos():Distance(self:GetPos())

	if Dist > 400 then
		return
	end

	if self.dt.owning_ent:IsValid() then
		Owner = self.dt.owning_ent:Nick()
	end

	local Cooler, Tuner, Overclocker = "No", "No", "No"
	if self.HasCooler 		then Cooler = "Yes" end
	if self.HasTuner 		then Tuner = "Yes" end
	if self.HasOverclocker 	then Overclocker = "Yes" end

	Ang:RotateAroundAxis( Ang:Up(), 90)
	
	cam.Start3D2D(Pos + Ang:Up() * 10.7, Ang, 0.1)
		--Background
		surface.SetDrawColor( 35, 35, 35, 255 )
		surface.DrawRect( -150, -160, 305, 300 )
		surface.SetDrawColor( Clr.r, Clr.g, Clr.b, Clr.a )
		surface.DrawRect( -145, -155, 295, 40 )
		surface.DrawOutlinedRect( -145, -155, 295, 290 )
		surface.DrawRect( -145, -60, 295, 40 )
		--Titles
		if self.IsTurnedOn == false then
			draw.SimpleTextOutlined( "Money Printer (Lv."..self.Level..")", "DermaLarge", 0, -135, Color( 205, 0, 0, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		else
			draw.SimpleTextOutlined( "Money Printer (Lv."..self.Level..")", "DermaLarge", 0, -135, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		end
		draw.SimpleTextOutlined( "Properties", "DermaLarge", 0, -40, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		--Stats
		draw.SimpleTextOutlined( "Owned by: "..Owner, "DermaDefaultBold", -140, -95, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Print multiplier: "..self.Multiplier, "DermaDefaultBold", -140, -80, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Print amount: $"..sh_ng_printer.PrintAmount * self.Multiplier, "DermaDefaultBold", -140, -65, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
		--Mods
		draw.SimpleTextOutlined( "Cooler: "..Cooler, "DermaDefaultBold", 50, -95, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Tuner: "..Tuner, "DermaDefaultBold", 50, -80, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Overclocker: "..Overclocker, "DermaDefaultBold", 50, -65, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
		--Properties
		draw.SimpleTextOutlined( "Experience: "..self.Experience.."/"..sh_ng_printer.LvlTbl[self.Level].ExpReq, "DermaDefaultBold", -140, 0, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
		surface.DrawOutlinedRect( -135, 10, 275, 15 )
		surface.DrawRect( -135, 10, ExpProgress * 275, 15 )

		draw.SimpleTextOutlined( "Stored Money: $"..self.StoredMoney.."/"..sh_ng_printer.LvlTbl[self.Level].StorageSize, "DermaDefaultBold", -140, 45, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
		surface.DrawOutlinedRect( -135, 55, 275, 15 )
		surface.DrawRect( -135, 55, StorageProgress * 275, 15 )

		draw.SimpleTextOutlined( "Temperature", "DermaDefaultBold", -140, 90, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
		if self.Temperature >= 75 then
			surface.SetDrawColor( 225, 0, 0, 255 )
		else
			surface.SetDrawColor( Clr.r, Clr.g, Clr.b, Clr.a )
		end
		surface.DrawOutlinedRect( -135, 100, 275, 15 )
		surface.DrawRect( -135, 100, HeatProgress * 275, 15 )

	cam.End3D2D()
end

function ENT:Think()
end
