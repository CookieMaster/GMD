MODE:REGISTER(1, "Kills/Deaths")

function logDeathsKills(pl, weapon, killer)

	local KillerName = (killer:IsPlayer() and killer:Nick()) or tostring(killer)

	local WeaponName = IsValid(weapon) and ((weapon:IsPlayer() and IsValid(weapon:GetActiveWeapon()) and weapon:GetActiveWeapon():GetClass()) or weapon:GetClass()) or "unknown"
	if IsValid(weapon) and weapon:GetClass() == "prop_physics" then
		WeaponName = weapon:GetClass() .. " (" .. (weapon:GetModel() or "unknown") .. ")"
	end

	if killer:IsVehicle() and killer:GetDriver():IsPlayer() then 

		KillerName = killer:GetDriver():Nick()

	end

	if killer == pl then

		KillerName = "Himself"
		WeaponName = "suicide trick"

	end

	ELS:Log(pl:Nick() .. " was killed by " .. KillerName .. " with a " .. WeaponName, 1)

end
hook.Add("PlayerDeath", "logDeathsKills", logDeathsKills)