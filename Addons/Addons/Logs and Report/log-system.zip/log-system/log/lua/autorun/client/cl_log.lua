include( 'autorun/sh_config.lua' )

local logtbl = {}
local mode = 0
local logview 

local Modes = { }

local mat = Material("materials/persious/menu_mat.png")
		
local page = "gui/silkicons/page.png"
local time = "gui/silkicons/time.png"
local attach = "gui/silkicons/attach.png"
local group = "gui/silkicons/attach.png"
local admin = "gui/silkicons/shield.png"
local user = "gui/silkicons/user.png"


net.Receive( "SendModes", function( len )
     
	Modes = net.ReadTable()
		
end )

surface.CreateFont( "TitleText", {
 font = "Arial",
 size = 20,
 weight = 1000,
 antialias = true
} )

function ShowAMenu()

	MAIN = vgui.Create("DFrame")
	MAIN:SetSize(800,450)
	MAIN:Center()
	MAIN:MakePopup()
	MAIN:SetDeleteOnClose(true)
	MAIN:SetDraggable(false)
	MAIN:ShowCloseButton(true)
	MAIN:SetTitle("")
	MAIN.Paint = function(self)

    surface.SetDrawColor(255, 255, 255)
    surface.SetMaterial(mat)
    surface.DrawTexturedRect( 0, 0, self:GetWide(), self:GetTall() )

    surface.SetDrawColor(0, 0, 0)
    surface.DrawOutlinedRect( 0, 0, self:GetWide(), self:GetTall() )

    draw.SimpleText(ELS.Title, "TitleText", 5, 5, Color( 255, 255, 255, 255 ) )

end

	local atab = vgui.Create("DPanel", MAIN)
	atab:SetPos(100, 27)
	atab:SetSize(MAIN:GetWide() - 105, MAIN:GetTall() - 32)

	local btab = vgui.Create("DPanelList", MAIN)
	btab:SetPos(5, 27)
	btab:SetSize(90, MAIN:GetTall() - 32)
	btab:SetPadding(6)
	btab:SetSpacing(4)
	btab:EnableVerticalScrollbar()
	btab.PaintOver = function()
    	surface.SetDrawColor( 0, 0, 0, 0 ) 
    	surface.DrawRect( 0, 0, btab:GetWide(), btab:GetTall() )
	end

for k, v in pairs(Modes) do

	local btn = vgui.Create("DButton", catpan)
	btn:SetText(v.Text)
	btn:SetWide(65)
	btn.DoClick = function()
					mode = v.ID
					FillLog()
				end	

	btab:AddItem(btn)

		end			

if LocalPlayer():GetCustomUserGroup() == "superadmin" then

	local clearbtn = vgui.Create("DButton", MAIN)
	clearbtn:SetText("Clear Log")
	clearbtn:SetWide(65 + 25)
	clearbtn:SetPos(5, btab:GetTall() + clearbtn:GetTall() + 10)
	clearbtn.DoClick = function()
						logtbl = {}
						FillLog()
					end								
		end

	logview = vgui.Create("DListView", atab)
	logview:SetPos(0, 0)
	logview:SetSize(atab:GetWide(), atab:GetTall())
	
	logview.OnRowRightClick = function(self, lineID, line)

		local menu = DermaMenu()
		local SubMenu = menu:AddSubMenu("Clipboard Options")
 		SubMenu:AddOption("Copy Everything", function() SetClipboardText(line:GetColumnText(1).." - "..line:GetColumnText(2)) end):SetImage(attach)
 		SubMenu:AddOption("Copy Time", function() SetClipboardText(line:GetColumnText(1)) end):SetImage(time)
 		SubMenu:AddOption("Copy Entry", function() SetClipboardText(line:GetColumnText(2)) end):SetImage(page)
 		SubMenu:AddSpacer()
		local Other = menu:AddSubMenu("Other Options")

		local plmenu = SubMenu:AddSubMenu("Print to Player")
		
		for k, v in pairs(player.GetAll()) do
				
			if v:IsAdmin() then 
					rank = admin
				else
					rank = user
			end

        		plmenu:AddOption(v:Nick(), function() 

 			net.Start("PrtToPlayers")
 			net.WriteString("Player")
 			net.WriteEntity(v)
			net.WriteString(line:GetColumnText(1).." - "..line:GetColumnText(2))
			net.SendToServer()

        	end):SetImage(rank)

        end

 		SubMenu:AddOption("Print to Everyone", function() 

 			net.Start("PrtToPlayers")
 			net.WriteString("All")
			net.WriteString(line:GetColumnText(1).." - "..line:GetColumnText(2))
			net.SendToServer() 
 		
 		end):SetImage(group)

		menu:Open()

	end
	
	local timecol = logview:AddColumn( "Time" ):SetFixedWidth( 150 ) 
	local entrycol = logview:AddColumn( "Entry" ):SetFixedWidth( atab:GetWide() - 150 ) 

	FillLog()

end
usermessage.Hook("ShowAMenu", ShowAMenu)

function FillLog()

	if (!logview) then return end

		logview:Clear()

	for k,v in pairs(logtbl) do

		if (mode > 0) then

			if (v.Mode == mode) then

				logview:AddLine(v.Time,v.Event)

			end

		else

			logview:AddLine(v.Time,v.Event)

		end

	end

end  

function AddLogEntry(str,amode,timestamp)

	local temp = {}
	temp.Time = os.date("%x - %I:%M:%S %p",timestamp)
	temp.Event = str
	temp.Mode = tonumber(amode)
	
	table.insert(logtbl,temp)

end

net.Receive( "SendLogEntry", function( len )
     
        local str = net.ReadString()
        local mode = net.ReadInt(8)

        AddLogEntry(str, mode, tonumber(os.time()))
     
end )