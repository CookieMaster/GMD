MODE:REGISTER(2, "Demotes")
MODE:REGISTER(3, "Arrests")
MODE:REGISTER(4, "Wanted")
MODE:REGISTER(5, "Warrants")

function logDemotes(pl, target, reason)

	ELS:Log(pl:Nick() .. " has issued a demote on " .. target:Nick(), 2)

end
hook.Add("CanDemote", "logDemotes", logDemotes)

function logArrests(criminal, time, actor)


	ELS:Log(actor:Nick() .. " has arrested " .. criminal:Nick(), 3)

end
hook.Add("playerArrested", "logArrests", logArrests) 

function logWanted(pl, target, reason)
	
	ELS:Log(pl:Nick() .. " issued a wanted state on " .. target:Nick(), 4)

end
hook.Add("PlayerWanted", "logWanted", logWanted)

function logWarranted(pl, target, reason)

	ELS:Log(pl:Nick() .. " has issued a warrant on " .. target:Nick(), 5)

end
hook.Add("PlayerWarranted", "logWarranted", logWarranted)