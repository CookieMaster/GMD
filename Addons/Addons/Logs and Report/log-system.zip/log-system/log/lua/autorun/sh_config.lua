---------------------------------------------------------
--------------DO NOT TOUCH ANYTHING HERE-----------------
---------------------------------------------------------
ELS = { }
MODE = { }
---------------------------------------------------------

ELS.GroupsPermitted = {"admin", "superadmin"}

ELS.Command = "/log"

ELS.Title = "Global Log System"

ELS.AdminMod = "ULX"


---------------------------------------------------------
--------------DO NOT TOUCH ANYTHING HERE-----------------
---------------------------------------------------------
local PLAYER = FindMetaTable("Player")

function PLAYER:GetCustomUserGroup()

	if string.lower(ELS.AdminMod) == "ulx" then

		return self:GetUserGroup()

	elseif string.lower(ELS.AdminMod) == "exsto" then

		return self:GetRank()

	end

end
---------------------------------------------------------