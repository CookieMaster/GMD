AddCSLuaFile( "autorun/sh_config.lua" )
AddCSLuaFile("autorun/client/cl_log.lua")

include( 'autorun/sh_config.lua' )

util.AddNetworkString( "SendModes" )
util.AddNetworkString( "SendLogEntry" )
util.AddNetworkString( "PrtToPlayers" )

resource.AddFile( "materials/gui/silkicons/page.png" )
resource.AddFile( "materials/gui/silkicons/tick.png" )
resource.AddFile( "materials/gui/silkicons/time.png" )
resource.AddFile( "materials/gui/silkicons/attach.png" )
resource.AddFile( "materials/gui/silkicons/group.png" )
resource.AddFile( "materials/gui/silkicons/shield.png" )
resource.AddFile( "materials/gui/silkicons/user.png" )
resource.AddFile( "materials/persious/menu_mat.png" )

local Modes = { }

function MODE:REGISTER(ID, Text)
table.insert(Modes, {ID = ID, Text = Text})
end

MODE:REGISTER(0, "All")

local fol = "autorun/server/modes/"
local files, folders = file.Find(fol .. "*", "LUA")
for k,v in pairs(files) do
	include(fol .. v)
end

for _, folder in SortedPairs(folders, true) do
	if folder ~= "." and folder ~= ".." then

		for _, File in SortedPairs(file.Find(fol .. folder .."/mode_*.lua", "LUA"), true) do
			include(fol.. folder .. "/" ..File)
		end

	end
end

function ELS.SendModes(pl)

net.Start( "SendModes" )
net.WriteTable(Modes)
net.Send( pl )

end
hook.Add("PlayerInitialSpawn", "ELS.SendModes", ELS.SendModes)

function ELS.OpenLOGMenu(pl, txt)

	if string.lower(txt) == ELS.Command then

		if !table.HasValue(ELS.GroupsPermitted, pl:GetCustomUserGroup()) then 

			return txt 

		end

			umsg.Start("ShowAMenu", pl)
			umsg.End()

		return ""

	end

end
hook.Add("PlayerSay", "ELS.OpenLOGMenu", ELS.OpenLOGMenu)

function ELS:Log(str,mode)

	for k,v in pairs(player.GetAll()) do

		if table.HasValue(ELS.GroupsPermitted, v:GetCustomUserGroup()) then

			net.Start( "SendLogEntry" )
			net.WriteString(str)
			net.WriteInt(mode, 8)
			net.Send( v )

		end

	end

end

net.Receive("PrtToPlayers", function(length, pl) 


	local pltype = net.ReadString()
	local sentpl = net.ReadEntity()
	local msg = net.ReadString()

	if pltype == "All" then

		for k, v in pairs(player.GetAll()) do
	
			v:ChatPrint(msg)

		end

	else

		sentpl:ChatPrint(msg)

		end

end)