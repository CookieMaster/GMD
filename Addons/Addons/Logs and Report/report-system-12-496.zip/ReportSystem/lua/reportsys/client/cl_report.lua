function openReportMenu( )
	local reportFrame = vgui.Create( "DFrame" )
	local width, height = 500, 300
	reportFrame:SetPos( ScrW( ) / 2 - width / 2, ScrH( ) / 2 - height / 2 )
	reportFrame:SetSize( width, height )
	reportFrame:SetTitle( "Report a player" )
	reportFrame:SetVisible( true )
	reportFrame:SetDraggable( true )
	reportFrame:ShowCloseButton( true )
	reportFrame:MakePopup( )

	local playerList = vgui.Create( "DListView", reportFrame )
	playerList:SetWide( 100 )
	playerList:DockMargin( 10, 10, 10, 10 )
	playerList:Dock( LEFT )
	playerList:SetMultiSelect( false )
	playerList:AddColumn( "Player" )
	for k, v in pairs( player.GetAll( ) ) do
		if IsValid( v ) and v != LocalPlayer( ) then
			local name = ( v.DarkRPVars and v.DarkRPVars["rpname"] ) or v:Nick( )
			playerList:AddLine( name ).steamId = v:SteamID( )
		end
	end
	
	local rightPanel = vgui.Create( "DPanelList", reportFrame )
	rightPanel:DockMargin( 0, 10, 10, 10 )
	rightPanel:Dock( FILL )
	rightPanel:EnableHorizontal( false )
	rightPanel:SetSpacing( 5 )
	
	local reasonLabel = vgui.Create( "DLabel" )
	reasonLabel:SetText( "Report Reason:" )
	rightPanel:AddItem( reasonLabel )
	local reasonMultiChoice = vgui.Create( "DComboBox", reasonPanel )
	reasonMultiChoice:AddChoice( "RDM" )
	reasonMultiChoice:AddChoice( "Mass RDM (more than 3 people)" )
	reasonMultiChoice:AddChoice( "Abusive language" )
	reasonMultiChoice:AddChoice( "Prop killing" )
	reasonMultiChoice:AddChoice( "Hacking" )
	reasonMultiChoice:AddChoice( "Other" )
	reasonMultiChoice:AddChoice( "Admin/trusted abuse" )

	local selectedReason
	function reasonMultiChoice.OnSelect( index, value, data ) 
		selectedReason = data
	end
	rightPanel:AddItem( reasonMultiChoice )
	
	local textLabel = vgui.Create( "DLabel" )
	textLabel:SetText( "Further information/details" )
	rightPanel:AddItem( textLabel )
	local textInput = vgui.Create( "DTextEntry" )
	textInput:SetText( "Please explain what happened" )
	textInput:SetTall( 145 )
	textInput:SetMultiline(true)
	rightPanel:AddItem( textInput )
	
	local confirmButton = vgui.Create( "DButton" )
	confirmButton:SetText( "Submit report" )
	function confirmButton.DoClick( ) 
		local line = playerList:GetSelectedLine( )
		if not line then
			Derma_Message( "You did not select any player!", "Error", "Ok" )
			return
		end
		line = playerList:GetLine( line )
		local steamId = line.steamId
		local reason = selectedReason
		if not reason then 
			Derma_Message( "You did not select a reason!", "Error", "Ok" )
			return
		end
		local details = textInput:GetValue( )
		if not details then 
			Derma_Message( "You did not provide a description!", "Error", "Ok" )
			return
		end
		
		net.Start( "TransferReport" )
			net.WriteString( steamId )
			net.WriteString( reason )
			net.WriteString( details )
		net.SendToServer( )
		
		reportFrame:Close( )
		Derma_Message( "Thank you for your report. An admin will look at it shortly.", "Report sent", "Ok" )
	end
	rightPanel:AddItem( confirmButton )
end

REPORTS = { }
net.Receive( "TransferAllReports", function( len )
	REPORTS = net.ReadTable( )
	if LocalPlayer( ).reportList and LocalPlayer( ).reportList.reload then
		LocalPlayer( ).reportList:reload( ) 
	end
end )

function openReportAdminMenu( )
	local reportsFrame = vgui.Create( "DFrame" )
	local width, height = 1000, 700
	reportsFrame:SetPos( ScrW( ) / 2 - width / 2, ScrH( ) / 2 - height / 2 )
	reportsFrame:SetSize( width, height )
	reportsFrame:SetTitle( "Manage Reports" )
	reportsFrame:SetVisible( true )
	reportsFrame:SetDraggable( true )
	reportsFrame:ShowCloseButton( true )
	reportsFrame:MakePopup( )

	local reportList = vgui.Create( "DListView", reportsFrame )
	reportList:SetWide( 440 )
	reportList:SetTall( 680 )
	reportList:DockMargin( 10, 10, 10, 10 )
	reportList:Dock( LEFT )
	reportList:SetMultiSelect( false )
	reportList:AddColumn( "Date" ):SetWidth( 120 )
	reportList:AddColumn( "Reporter" )
	reportList:AddColumn( "Player" )
	reportList:AddColumn( "Reason" ):SetWidth( 130 )
	reportList:AddColumn( "Warning Level" ):SetWidth( 110 )
	function reportList:reload( )
		local selectedReportId = nil
		if self:GetSelectedLine( ) then
			selectedReportId = self:GetLine( self:GetSelectedLine( ) ).report.id
		end
		local selectedItem = nil
		
		self:Clear( )
		for k, report in pairs( REPORTS ) do
			local line = reportList:AddLine( report.time_created, 
				report.reporter_rpname != "UNKNOWN" and report.reporter_rpname or report.reporter_nick,
				report.reported_rpname != "UNKNOWN" and report.reported_rpname or report.reported_nick,
				report.reason, 
				report.warning_level )
			
			function line:GetColumnText( i )
				if i == 5 then --Warning Level
					if self.Columns[i] then
						return self.Columns[i].Value != "" and self.Columns[i].Value or 0
					else
						return 0
					end
				end
				return self.Columns[i] and self.Columns[i].value or ""
			end
				
			line.report = report
			if line.report.id == selectedReportId then
				selectedItem = line
			end
			function line:Paint( )
				self:SizeToContents( )
				local highlightColor 
				if string.len( self.report.resolved_by ) < 1 then 
					highlightColor = Color( 255, 0, 0, 180)
				elseif self.report.warning_level and self.report.warning_level > 0 then
					highlightColor = Color( 255, 255, 0 )
				else
					highlightColor = Color( 0, 255, 0, 150 )
				end
				
				if self:IsLineSelected( ) then
					surface.SetDrawColor( 0, 0, 255, 255 )
					surface.DrawRect( 0, 0, self:GetWide( ), self:GetTall( ) )
					surface.SetDrawColor( Color( 0, 0, 255, 255 ) )
					surface.DrawRect( 2, 2, self:GetWide( ) - 4, self:GetTall( ) - 4 )
				else
					surface.SetDrawColor( highlightColor )
					surface.DrawRect( 0, 0, self:GetWide( ), self:GetTall( ) )
				end
			end
		end
		if not selectedItem then 
			self:SelectFirstItem( ) 
		else
			self:SelectItem( selectedItem )
		end
	end
	reportList:reload( )
	LocalPlayer( ).reportList = reportList
	
	local rightPanel = vgui.Create( "DPanel", reportsFrame )
	rightPanel:DockMargin( 0, 10, 10, 10 )
	rightPanel:SetWide( 520 )
	rightPanel:SetTall( 680 )
	rightPanel:Dock( FILL )
	
	local topPanelLeft = vgui.Create( "DPanel", rightPanel )
	topPanelLeft:SetPos( 5, 5 )
	topPanelLeft:SetWide( 270 )
	topPanelLeft:SetTall( 100 )
	local infoLabelLeft = vgui.Create( "DLabel", topPanelLeft )
	infoLabelLeft:SetPos( 5, 5 )
	
	local topPanelRight = vgui.Create( "DPanel", rightPanel )
	topPanelRight:SetPos( 280, 5 )
	topPanelRight:SetWide( 270 )
	topPanelRight:SetTall( 100 )
	local infoLabelRight = vgui.Create( "DLabel", topPanelRight )
	infoLabelRight:SetPos( 5, 5 )
	
	local reasonEntry = vgui.Create( "DTextEntry", rightPanel )
	reasonEntry:DockMargin( 5, 110, 5, 5 )
	reasonEntry:Dock( FILL )
	reasonEntry:SetMultiline( true )
	reasonEntry:SetEnabled( false )
	
	function reportList:OnRowSelected( line ) 
		local report = self:GetLine( line ).report
		infoLabelLeft:SetText( string.format( "Reported Player:\n\nRpName: %s\nNick: %s\nSteamID: %s\nWarning Level: %i\n", report.reported_rpname, report.reported_nick, report.reported_steamid, WARNINGLEVELS[report.reported_steamid] and WARNINGLEVELS[report.reported_steamid].warning_level or 0 ) )
		infoLabelLeft:SetTextColor( Color(0, 0, 0, 255) )
		infoLabelLeft:SizeToContents( )
		infoLabelRight:SetText( string.format( "Reporting Player:\n\nRpName: %s\nNick: %s\nSteamID: %s\nWarning level: %i\n", report.reporter_rpname, report.reporter_nick, report.reporter_steamid, WARNINGLEVELS[report.reporter_steamid] and WARNINGLEVELS[report.reporter_steamid].warning_level or 0 ) )
		infoLabelRight:SetTextColor( Color(0, 0, 0, 255) )
		infoLabelRight:SizeToContents( )
		reasonEntry:SetText( report.description )
		reasonEntry:SetTextColor( Color(0, 0, 0, 255) )
	end
	
	function reportList:OnRowRightClick( line )
		local menu = DermaMenu( )
		local selectedDbId = self:GetLine( line ).report.id
		menu:AddOption( "Delete", function( ) 
			RunConsoleCommand( "reportremove", selectedDbId )
			self:RemoveLine( line )
		end )
		
		local submenu = menu:AddSubMenu( "Tools" )
		local copySteamSub = submenu:AddSubMenu( "Copy SteamID" )
		copySteamSub:AddOption( "Reported Player", function( )
			SetClipboardText( self:GetLine( line ).report.reported_nick )
		end )
		copySteamSub:AddOption( "Reporter Player", function( )
			SetClipboardText( self:GetLine( line ).report.reporter_nick )
		end )
		
		local copyNameSub = submenu:AddSubMenu( "Copy Name" )
		copyNameSub:AddOption( "Reported Player", function( )
			SetClipboardText( self:GetLine( line ).report.reported_steamid )
		end )
		copyNameSub:AddOption( "Reporter Player", function( )
			SetClipboardText( self:GetLine( line ).report.reporter_steamid )
		end )
		
		if string.len( self:GetLine( line ).report.resolved_by ) < 1 then
			menu:AddOption( "Mark as resolved", function( )
				RunConsoleCommand( "reportresolve", selectedDbId )
				self:GetLine( line ).report.resolved_by = LocalPlayer( ):Nick( )
			end )
		end
		local setWarning = menu:AddSubMenu( "Set warning level" )
		for i = 0, 5 do
			setWarning:AddOption( i, function( )
				timer.Simple( 1, function( ) reportList:OnRowSelected( line ) end )
				net.Start( "ReportWarning" )
					net.WriteUInt( selectedDbId, 32 )
					net.WriteUInt( i, 32 )
				net.SendToServer( )
				self:GetLine( line ).report.resolved_by = LocalPlayer( ):Nick( )
				reportList:reload( )
			end )
		end
		menu:Open( )
	end
end

net.Receive( "ReportUpdate", function( len ) 
	if LocalPlayer( ).reportList then LocalPlayer( ).reportList:reload( ) end
end )

WARNINGLEVELS = { }
net.Receive( "TransferWarningLevel", function( len )
	WARNINGLEVELS = net.ReadTable( )
end )

surface.CreateFont("reportfont", {
	size = 18,
	weight = 400,
	antialias = true,
	shadow = false,
	font = "coolvetica"})
	

local function reportInfoDraw()
 	for _,v in pairs(player.GetAll()) do
        if v != LocalPlayer() and v:Alive() then
			local ply = LocalPlayer( )
            local pos = v:EyePos()
            
            local Alpha = 255 - (v:GetPos():Distance( ply:GetPos() ) / 3)
            if Alpha > 2 then
                local ScreenPos = (v:GetPos() + Vector(0,0,95)):ToScreen()
                if WARNINGLEVELS[v:SteamID()] then
				    draw.SimpleTextOutlined( string.format( "Warning Level: %i", WARNINGLEVELS[v:SteamID()].warning_level ), "reportfont", ScreenPos.x, ScreenPos.y - 20, Color(255,0,0,Alpha), 1, 0, 0.8, Color(60,60,60,Alpha - 50))
					draw.SimpleTextOutlined( string.format( "Times Reported: %i", WARNINGLEVELS[v:SteamID()].reported_count ), "reportfont", ScreenPos.x, ScreenPos.y - 3, Color(255,0,0,Alpha), 1, 0, 0.8, Color(60,60,60,Alpha - 50))
				end
            end
        end
    end
end
hook.Add( "HUDPaint", "DrawReportInfo", reportInfoDraw )

net.Receive( "OpenReportMenu", function() 
	openReportMenu( )
end )

net.Receive( "OpenReportAdminMenu", function() 
	openReportAdminMenu( )
end )