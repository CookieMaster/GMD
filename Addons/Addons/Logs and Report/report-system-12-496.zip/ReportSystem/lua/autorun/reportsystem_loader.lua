local luaroot = "reportsys"
local name = "ReportSystem"
if SERVER then
	AddCSLuaFile( )
	local folder = luaroot .. "/shared"
	local files = file.Find( folder .. "/" .. "*.lua", "LUA" )
	for _, file in ipairs( files ) do
		AddCSLuaFile( folder .. "/" .. file )
	end

	folder = luaroot .."/client"
	files = file.Find( folder .. "/" .. "*.lua", "LUA" )
	for _, file in ipairs( files ) do
		AddCSLuaFile( folder .. "/" .. file )
	end

	--Shared modules
	local files = file.Find( luaroot .."/shared/*.lua", "LUA" )
	if #files > 0 then
		for _, file in ipairs( files ) do
			Msg( "[ReportSystem] Loading SHARED file: " .. file .. "\n" )
			include( luaroot .."/shared/" .. file )
			AddCSLuaFile( luaroot .."/shared/" .. file )
		end
	end

	--Server modules
	local files = file.Find( luaroot .."/server/*.lua", "LUA" )
	if #files > 0 then
		for _, file in ipairs( files ) do
			Msg( "[ReportSystem] Loading SERVER file: " .. file .. "\n" )
			include( luaroot .."/server/" .. file )
		end
	end

	MsgN( "ReportSystem by Kamshak loaded" )
end

if CLIENT then
	--Shared modules
	local files = file.Find( luaroot .."/shared/*.lua", "LUA" )
	if #files > 0 then
		for _, file in ipairs( files ) do
			Msg( "[ReportSystem] Loading SHARED file: " .. file .. "\n" )
			include( luaroot .."/shared/" .. file )
		end
	end

	--Client modules
	local files = file.Find( luaroot .."/client/*.lua", "LUA" )
	if #files > 0 then
		for _, file in ipairs( files ) do
			Msg( "[ReportSystem] Loading CLIENT file: " .. file .. "\n" )
			include( luaroot .."/client/" .. file )
		end
	end
	MsgN( luaroot .." by Kamshak loaded" )
end