
local PLUGIN = {}

PLUGIN.Name = "Report System"
PLUGIN.Author = "Kamshak"
PLUGIN.Date = "14th July 2013"
PLUGIN.Filename = "ass_report.lua"
PLUGIN.ClientSide = true
PLUGIN.ServerSide = true
PLUGIN.APIVersion = 2.3
PLUGIN.Gamemodes = {}

if (SERVER) then

	ASS_NewLogLevel("ASS_ACL_REPORT")
	
	function PLUGIN.Report( PLAYER, CMD, ARGS )
		if IsValid( PLAYER ) then
			openReportMenu( PLAYER )
		end
	end
	concommand.Add("ASS_Report", PLUGIN.Report)

	function PLUGIN.ReportAdmin( PLAYER, CMD, ARGS )
		if (PLAYER:IsTempAdmin()) then
			openReportAdminMenu( PLAYER )
		end
	end
	concommand.Add("ASS_ReportAdmin", PLUGIN.ReportAdmin)

end

if (CLIENT) then

	function PLUGIN.Report()
		RunConsoleCommand("ASS_Report")
	end
	
	function PLUGIN.ReportAdmin()
		RunConsoleCommand("ASS_ReportAdmin")
	end

	function PLUGIN.AddMenu(DMENU)			
		DMENU:AddOption( "Report Player", function() PLUGIN.Report( ) end ):SetImage( "icon16/report_add.png" )
		DMENU:AddOption( "Manage Reports", function() PLUGIN.ReportAdmin( ) end ):SetImage( "icon16/report_go.png" )
	end

	function PLUGIN.AddNonAdminMenu( DMENU )
		DMENU:AddOption( "Report Player", function() PLUGIN.Report( ) end ):SetImage( "icon16/report_add.png" )
	end
end

ASS_RegisterPlugin(PLUGIN)


