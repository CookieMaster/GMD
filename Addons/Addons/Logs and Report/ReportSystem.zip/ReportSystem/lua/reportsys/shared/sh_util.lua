function Log( intLogLevel, strMessage )
	/*
	1: Error
	2: Warning
	3: Important messages
	4: Debug messages
	*/
	local logLevel = 4
	if( intLogLevel <= logLevel ) then
			if SERVER then
				--MsgN( strMessage )
				file.Append( "reports_errorlog.txt", os.date() .. " - " .. strMessage .. "\n" )
			end
	end
end