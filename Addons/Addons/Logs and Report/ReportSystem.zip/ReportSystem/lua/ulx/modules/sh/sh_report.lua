function reportMenu( calling_ply )
	if calling_ply:IsValid() then
		ULib.clientRPC( calling_ply, "openReportMenu" )
	end
end
local reportmenucmd = ulx.command( "Report", "reportmenu", reportMenu, "!report", true )
reportmenucmd:defaultAccess( ULib.ACCESS_ALL )
reportmenucmd:help( "Open the user report panel" )

function reportAdminMenu( calling_ply )
	if calling_ply:IsValid( ) then
		sendReportsToClient( calling_ply )
		ULib.clientRPC( calling_ply, "openReportAdminMenu" )
	end
end
local reportmenucmd = ulx.command( "Report", "reportadminmenu", reportAdminMenu, "!reportadmin", true )
reportmenucmd:defaultAccess( ULib.ACCESS_ADMIN )
reportmenucmd:help( "Open the admin report panel" )