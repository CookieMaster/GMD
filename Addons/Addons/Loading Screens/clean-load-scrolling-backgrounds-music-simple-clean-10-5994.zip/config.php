<?php
$loadingScreen['backgroundMusic'] = "http://www.youtube.com/watch?v=0UjsXo9l6I8"; //Only youtube links.. (for now). (if you dont want to play music leave it blank) 
?>