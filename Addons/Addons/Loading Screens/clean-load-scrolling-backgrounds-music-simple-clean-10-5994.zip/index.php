<?php
require_once "lib/steam-condenser.php";
require_once "config.php";
$id = $_GET['sid'];
$getData = SteamId::create($id);
?>
<!DOCTYPE HTML>
<html>
    <head>
		<meta charset="UTF-8">
		<link rel="stylesheet" href="css/main.css" type="text/css" media="screen">
		<link rel="stylesheet" href="css/jquery.maximage.css" type="text/css" media="screen" title="CSS" charset="utf-8" />
		<script type="text/javascript" src="js/progressbar.js"></script>
    </head>
    <body>
	<section id="downloadInfo">
		<div id="progressBarText"><span id="fileName">filename.vmt </span><span id="downloadPresent"><b>0%</b></span></div>
		<div id="progressBar"><div></div> </div>
	</section>
	<section id="playerInfo" style="margin-left: 15%;">
	<?php
	echo '
		<img src="'.$getData->getFullAvatarUrl().'" width="299">
		<ul>
			<li style="width: 70%;"><h1 id="serverName">serverName</h1></li>
			<li style="width: 60%;"><h2>'.$getData->getNickname().'<span class="steamid">['.SteamId::convertCommunityIdToSteamId($id).']</span></h2></li>
			<li style="width: 50%;"><h3 id="mapName">mapName</h3></li>
		</ul>';
	?>
	</section>
	<?php
		if($loadingScreen['backgroundMusic'] != "")
		{
			$ytLink = explode("v=", $loadingScreen['backgroundMusic']);
			echo '<iframe width="1" height="1" src="//www.youtube.com/embed/'.$ytLink[1].'?autoplay=1" frameborder="0" style="opacity: 0;"></iframe>';
		}
	?>
	<div id="maximage">
		<?php
		$imgDir = scandir("images/backgrounds/");
		$picNum = 0;
		foreach($imgDir as &$files)
		{
			$picNum++;
			if($picNum >= 3)
			{
				echo "<img src='images/backgrounds/".$files."' alt='' width='1400' height='1050' />\n";
			}
		}
		?>
	</div>
	<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.js'></script>
	<script src="js/jquery.cycle.all.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.maximage.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript" charset="utf-8">
		$(function(){
			jQuery('#maximage').maximage();
		});
		
		function GameDetails( servername, serverurl, mapname, maxplayers, steamid, gamemode ) 
		{
			document.getElementById("serverName").innerHTML = servername;
			document.getElementById("mapName").innerHTML = mapname;
		}
		function SetFilesTotal( total ) { 
			var totalFiles = total;
		}
		function SetFilesNeeded( needed ) { 
			var filesLeft = needed;
			var present = (totalFiles / filesLeft);
			document.getElementById("downloadPresent").innerHTML = present + "%";
			progressBar(Math.round(present), $('#progressBar'));
		}
		function DownloadingFile( fileName ) {
			document.getElementById("fileName").innerHTML = fileName;
		}
	</script>
	<footer>
	</footer>
    </body>
</html>