<?php

//Steam Info
$config["steaminfo"]["enabled"] = true; //Show Steam name/avatar?
$config["steaminfo"]["apikey"] = "04494B7FC61EF412DA7510C2F5BDBCA7"; // Steam Web API Key

//Header Text
$config["headertext"]["text"] = "SmartLoad";

//Footer Text
$config["footertext"]["text"] = "By Mattles";

/* ----- THEME COLOUR -----
   BLUE = 1
   GREEN = 2
   PINK = 3
   RED = 4
   ORANGE = 5
*/

$config["themecolour"] = 1;

$config["logo"] = "images/b_sl.png"; // Logo path

?>