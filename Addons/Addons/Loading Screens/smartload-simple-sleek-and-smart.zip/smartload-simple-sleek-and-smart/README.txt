---------------SmartLoad V0.30---------------

Thankyou for purchasing my loading screen!

INSTRUCTIONS:

SETUP:
1.) Upload all files inside SmartLoad directory to your web host. For this I recommend using FileZilla: https://filezilla-project.org/download.php?type=client
2.) If you don't already have a steam API key, apply for one here: http://steamcommunity.com/dev/apikey
2.) Inside the config directory edit config.php and config.js to set your Steam API key and customise the loading screen to your liking.
3.) Inside your gameserver's 'server.cfg' file add the line: sv_loadingurl 'yourwebsite.com/loadingscreen.php?id=%s'.
4.) Add -sv_loadingurl 'yourwebsite.com/loadingscreen.php?id=%s' to your server's startup commandline.
4.) Enjoy! :)