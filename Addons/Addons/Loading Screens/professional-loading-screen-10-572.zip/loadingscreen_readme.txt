First of all thanks for purchasing "Professional Loading Screen" from "Blu" @ Coder Hire!

If you have ANY trouble, and need support feel free to contact me @

CoderHire - http://coderhire.com/profile/view/249
Steam - http://steamcommunity.com/id/Long_Live_ASAP

[]Installation[]
Drag and drop the loading folder in the zip that contains this read me file into your web server.
If you dropped it into the base directory of your webserver, the url to the loading screen should be @ http://yoursite.com/loading

[]Configuration[]
	[]Web Part[]
		To configure the script entirely, you would need to open up the config.php file under "loading/cfg/"

		After opening it, you can change what you want to make your loading screen unique and YOURS!

		THE FIRST THING YOU SHOULD DO IS FILL IN YOUR STEAM WEB API KEY. Can be found @ http://steamcommunity.com/dev/apikey

		The only things you would be editing are the define lines

		Lets say i want to change the default "NOW JOINING" text you may see on your loading screen, to "YOU'RE JOINING"

		I would then find ::ABOVE TEXT:: FIRST LINE, find the define line which is

		"define('ABOVE_FIRST', 'NOW JOINING');" and change it to "define('ABOVE_FIRST', 'YOU'RE JOINING');"

		----------

		So now you get the basics of editing your loading screen, lets move on to the background color.

		This is VERY simple too, I've pre made 10 differen't coloured back drops. The default it blue.

		To change it, to lets say yellow, you would find

		"define('BG', 'images/bg_blue.png');" and change it to "define('BG', 'images/bg_yellow.png');"

		----------

		So thats basically the basics of configuring the loading screen to your liking.

		NOTE! THIS IS NOT THE ONLY WAY TO EDIT THE SCRIPTS CONTENTS AND LOOKS, IF YOUR EXPERIENCED WITH HTML, CSS, PHP GO AHEAD AND CHANGE IT UP EVEN MORE.

		[]Configuring Random Changing Icons Next To Name[]
		If you open up index.php and navigate to line "152" you shall see an array like this (deafult)
		"
		theImages[0] = 'images/icons/star.png'
		theImages[1] = 'images/icons/bulb.png'
		theImages[2] = 'images/icons/skull.png'
		theImages[3] = 'images/icons/star.png'
		theImages[4] = 'images/icons/bulb.png'
		theImages[5] = 'images/icons/skull.png'
		"

		Lets say you wanted to add two more icons (which have to be 32 x 32) to the array. For example, those two file names are "ball.png" & "cash.png"

		Ok, so first of all, add "ball.png" and "cash.png" to the "images/icons/" folder.

		Next navigate back to line 152 in index.php and edit the array to match this:
		"
		theImages[0] = 'images/icons/star.png'
		theImages[1] = 'images/icons/bulb.png'
		theImages[2] = 'images/icons/skull.png'
		theImages[3] = 'images/icons/ball.png'
		theImages[4] = 'images/icons/cash.png'
		theImages[5] = 'images/icons/star.png'
		theImages[6] = 'images/icons/bulb.png'
		theImages[7] = 'images/icons/skull.png'
		theImages[8] = 'images/icons/ball.png'
		theImages[9] = 'images/icons/cash.png'
		"

		See what a did there, you have to add it twice in that order but still have the numbers counter from 0 and up... Then your done.
	
	[]GameServer Part[]
		Ok now that your done confiuring your Web Server part, now you need to make the webpage your actual server loading screen!
		
		While in your gameserver files navigate to "garrysmod/cf/" there should be a file called "server.cfg" in there.
		
		Open it with a text editor and first try to find "sv_loadingurl" if you can't find it, then add this as a new line in your server.cfg
		
		sv_loadingurl "http://yoursite.com/loading/?steamid=%s&mapname=%m"
		
		so lets say your site is 123gaming.com and the url to your loading screen was 123gaming.com/loading .
		
		You would then put
		
		sv_loadingurl "http://123gaming.com/loading/?steamid=%s&mapname=%m
		
		Then you save the server.cfg make sure its uploaded back into your gameserver.. and your DONE!
		
		If you do have sv_loadingurl in the first place, replace the in quotation marked url to the ones we stated will be yours.

[]Wrap Up[]

Once again, full support is available.. just contact to me your having any problems.

