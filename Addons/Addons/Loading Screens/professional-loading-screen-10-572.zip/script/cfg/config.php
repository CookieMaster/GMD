<?
##################################################################################################################
###                                        Loading Screen Configuration                                        ###
##################################################################################################################

##################################################################################################################
###                                           ::STEAM WEB OPTIONS::                                            ###
##################################################################################################################
define('API_KEY', 'FB26EDDD878D5069155687BDC66E7139'); // Your web api key // Get your's @ http://steamcommunity.com/dev/apikey

##################################################################################################################
###                                          ::GENERAL HEAD OPTIONS::                                          ###
##################################################################################################################
define('TITLE', 'Loading...');
// Document Title
define('BG', 'images/bg_blue.png');
// Document Background // ex. (default background images start with bg_) // colors: blue, lightblue, brown, green, green2, pink, pink2, purple, red, yellow //

##################################################################################################################
###                                               ::ABOVE TEXT::                                               ###
##################################################################################################################

	##################################################################################################################
	###                                               ::ABOVE TEXT::                                               ###
	###                                                 FIRST LINE                                                 ###
	##################################################################################################################
	define('ABOVE_FIRST', 'NOW JOINING');
	// Your loading screen first text
	define('ABOVE_FIRST_SIZE', '40px');
	// Your loading first text font size // Default is '40px'
	define('ABOVE_FIRST_POS', 'center');
	// Your loading screen first text pos // options: left | center | right // IF YOUR USING THE EXACT OPTION LEAVE AT 'left'
	define('ABOVE_FIRST_POS_EXACT', '0px');
	// Your loading screen first text pos // ex: 25px // IF YOUR USING THE OTHER OPTION LEAVE AT '0px'
	
	##################################################################################################################
	###                                               ::ABOVE TEXT::                                               ###
	###                                                SECOND LINE                                                 ###
	##################################################################################################################
	define('ABOVE_SECOND', 'GARRYSMOD');
	// Your loading screen title
	define('ABOVE_SECOND_SIZE', '53px');
	// Your loading screen title font size // Default is '53px'
	define('ABOVE_SECOND_POS', 'center');
	// Your loading screen title pos // options: left | center | right // IF YOUR USING THE EXACT OPTION LEAVE AT 'left'
	define('ABOVE_SECOND_POS_EXACT', '0px');
	// Your sever name pos // ex: 25px // IF YOUR USING THE OTHER OPTION LEAVE AT '0px'
	
	##################################################################################################################
	###                                              ::LOGO OPTIONS::                                              ###
	##################################################################################################################
	define('LOGO', 'images/logo.png');
	// Change Logo to custom file. // ORIGINAL DIMENSIONS ARE 352 x 350
	define('LOGO_OPACITY', '0');
	// Logo opacity adjustment // options: 0.0 to 1.0 // ex. 0.1, 0.2, 0.3, etc...
	define('LOGO_HEIGHT', '350px');
	// Logo image height adjustment
	define('LOGO_WIDTH', '350px');
	// Logo image width adjustment
	
##################################################################################################################
###                                            ::CONTAINER OPTIONS::                                           ###
##################################################################################################################

	##################################################################################################################
	###                                            ::CONTAINER OPTIONS::                                           ###
	###                                                 TAB TITLES                                                 ###
	##################################################################################################################
	define('TOPTAB', 'Community Information / Community Name'); // Your top tab title
	define('TOPTAB_POS', 'center'); // Your top tab title position // options: left | center | right //
	define('LEFTTAB', 'Server Info'); // Your left tab title
	define('LEFTTAB_POS', 'center'); // Your left tab title position // options: left | center | right //
	define('RIGHTTAB', 'Community Info'); // Your right tab title
	define('RIGHTTAB_POS', 'center'); // Your right tab title position // options: left | center | right //
	
	##################################################################################################################
	###                                            ::CONTAINER OPTIONS::                                           ###
	###                                             LEFT GROUP OPTIONS                                             ###
	##################################################################################################################
	define('LEFT_POS', 'center'); // Left tab contents info pos // ex. left, center, right
	define('LEFT_TITLE1', 'Server:'); // Title 1
	define('LEFT_TITLE2', 'Server IP:'); // Title 2
	define('LEFT_TITLE3', 'Player Slots:'); // Title 3
	define('LEFT_OPT1', 'Server Name'); // Option 1
	define('LEFT_OPT2', 'xx.xx.xxx.xxx'); // Option 2
	define('LEFT_OPT3', '30 slots'); // Option 3
	
	##################################################################################################################
	###                                            ::CONTAINER OPTIONS::                                           ###
	###                                            RIGHT GROUP OPTIONS                                             ###
	##################################################################################################################
	define('RIGHT_POS', 'center'); // Right tab contents info pos // ex. left, center, right
	define('RIGHT_TITLE1', 'Owner:'); // Title 1
	define('RIGHT_TITLE2', 'Website:'); // Title 2
	define('RIGHT_TITLE3', 'Server Rank:'); // Title 3
	define('RIGHT_OPT1', 'Name'); // Option 1
	define('RIGHT_OPT2', 'http://example.com'); // Option 2
	define('RIGHT_OPT3', '#th'); // Option 3