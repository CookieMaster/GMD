<?php
require 'core/core.php';
require 'cfg/config.php';

// Must use a valid Steam Web API key
if ( API_KEY == '') {
	echo "No API key set!<br />";
	echo "See API_KEY in steam.php<br />";
	echo "<a href='http://steamcommunity.com/dev/apikey'>Get an API key here</a>";
	return;
}

function get_data($url) { //get data from a url
					$ch = curl_init();
					$timeout = 5;
					$userAgent = 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322)';
					curl_setopt($ch, CURLOPT_URL, $url);
					curl_setopt($ch, CURLOPT_USERAGENT, $userAgent);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
					curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
					$data = curl_exec($ch);
					curl_close($ch);
					return $data;
				   
					
			}
			
//Get data from the url
$MapName = isset($_GET['mapname']) ? $_GET['mapname'] : false;

if ($playerinfo == false) {
		$lastonline = "Unkown!";
}

// Check if 'steamid' GET variable is set
if ( isset($_GET['steamid']) ) {
	// Request player info from Steam
	$playerinfo = getPlayerSummary($_GET['steamid']);

	if ( $playerinfo ) {
		$playerinfo = $playerinfo['response']['players'][0];
		$lastonline = date( "F jS, Y", $playerinfo['lastlogoff'] );
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title><? echo TITLE ?></title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	
	<style type="text/css">
		.screen_title {
		margin: 5px 0px 10px <? echo ABOVE_SECOND_POS_EXACT ?>;
		font: <? echo ABOVE_SECOND_SIZE ?> "action", Arial;
		text-shadow: rgba(0, 0, 0, 1.00) 0.1em 0.1em 0.25em;
		color: white;
		letter-spacing: 5px;
		}

		.screen_title_pos {
		text-align: <? echo ABOVE_SECOND_POS ?>;
		width: 750px;
		}

		.screen_joining {
		margin: -459px 0px 0px <? echo ABOVE_FIRST_POS_EXACT ?>;
		font: <? echo ABOVE_FIRST_SIZE ?> "bebasn2", Arial;
		text-shadow: rgba(0, 0, 0, 1.00) 0.1em 0.1em 0.25em;
		color: rgb(247, 247, 247);
		}

		.screen_joining_pos {
		text-align: <? echo ABOVE_FIRST_POS ?>;
		width: 750px;
		}

		.group_left_list {
		text-align: <? echo LEFT_POS ?>;
		color: white;
		list-style-type: none;
		margin: 0px 0px 0px 0px;
		padding: 12px;
		}

		.group_right_list {
		text-align: <? echo RIGHT_POS ?>;
		color: white;
		list-style-type: none;
		margin: 0px 0px 0px 0px;
		padding: 12px;
		}
		.group_left_title {
		text-align: <? echo LEFTTAB_POS ?>;
		padding: 6px 13px 0px 13px;
		margin: 0px 0px 0px 0px;
		color: white;
		font-family:noodleo;
		font-size: 38px;
		text-shadow: rgba(0, 0, 0, 0.56) 0.1em 0.1em 0.25em;
		}

		.group_left_title:after {
		content: '';
		background: -webkit-linear-gradient(left,rgba(255,255,255,0) 0,rgba(255,255,255,0.11) 11%,rgba(255,255,255,0.33) 50%,rgba(255,255,255,0.11) 88%,rgba(255,255,255,0) 100%);
		height: 1px;
		display: block;
		}

		.group_right_title {
		text-align: <? echo SERVER_RIGHTTAB_POS ?>;
		padding: 6px 13px 0px 13px;
		margin: 0px 0px 0px 0px;
		color: white;
		font-family:noodleo;
		font-size: 38px;
		text-shadow: rgba(0, 0, 0, 0.56) 0.1em 0.1em 0.25em;
		}

		.group_right_title:after {
		content: '';
		background: -webkit-linear-gradient(left,rgba(255,255,255,0) 0,rgba(255,255,255,0.11) 11%,rgba(255,255,255,0.33) 50%,rgba(255,255,255,0.11) 88%,rgba(255,255,255,0) 100%);
		height: 1px;
		display: block;
		}

	</style>
	
	<SCRIPT LANGUAGE="JavaScript">

		console.log("`Professional Loading Screen` created by Blu");
		console.log("`Find it here @");
		console.log("http://coderhire.com/scripts/view/54");
	</script>
	
	<SCRIPT LANGUAGE="JavaScript">

		<!-- This script and many more are available free online at -->
		<!-- The JavaScript Source!! http://javascript.internet.com -->

		<!-- Begin
		// Set up the image files to be used.
		var theImages = new Array() // do not change this
		// To add more image files, continue with the
		// pattern below, adding to the array.
		// TO ADD MORE ICONS DIMENSIONS ARE 32 x 32 //
		// RECOMMAND TO PUT THE IMAGE TWICE IN THIS ORDER BELOW //
		theImages[0] = 'images/icons/star.png'
		theImages[1] = 'images/icons/bulb.png'
		theImages[2] = 'images/icons/skull.png'
		theImages[3] = 'images/icons/star.png'
		theImages[4] = 'images/icons/bulb.png'
		theImages[5] = 'images/icons/skull.png'

		// do not edit anything below this line

		var j = 0
		var p = theImages.length;
		var preBuffer = new Array()
		for (i = 0; i < p; i++){
		   preBuffer[i] = new Image()
		   preBuffer[i].src = theImages[i]
		}
		var whichImage = Math.round(Math.random()*(p-1));
		function showImage(){
		document.write('<img src="'+theImages[whichImage]+'">');
		}

		//  End -->
	</script>
</head>
<body style="overflow:hidden;">

	<!--Background Changer-->
			<script type="text/javascript">

					document.body.style.backgroundImage="url('<? echo BG ?>')";	
			</script>
		<!--/ Background Changer-->
		<div class="main">
			<div class="main-line">
				<div class="container size">
					<div class="screen_joining_pos">
						<h2 class="screen_joining" style="position: relative;"><? echo ABOVE_FIRST ?></h2>
					</div>
					<div class="screen_title_pos">
						<h2 class="screen_title"><? echo ABOVE_SECOND ?></h2>
					</div>
					<div class="topper" style="
						background-color: rgba(0,0,0,0.22);
						color: white;
						border: 1px solid rgba(255,255,255,0.14);
						box-shadow: 0px 0px 0px 1px rgba(0,0,0,0.33), 0 0 8px 4px rgba(0,0,0,0.08);
						margin: 0px 0px 2px 0px;  
						padding: 6px;
						color: white;
						font-size: 18px;
						font-family:noodleo;
						text-align: <? echo TOPTAB_POS ?>;
					">
						<h1 style="margin: 0px; text-shadow: rgba(0, 0, 0, 0.56) 0.1em 0.1em 0.25em;">
							<? echo TOPTAB ?>
						</h1>
					
					</div>        
					<div class="group">
						<div class="group_infoBox">
							<div class="group_infoBox_left" style="position: absolute;">
								<h3 class="group_left_title" style=""><? echo LEFTTAB ?></h3>
								<ul class="group_left_list">
									<li class="group_label" style="margin: 0px 0px 0px 0px;"><? echo LEFT_TITLE1 ?></li>
									<li id="group_lines" style="margin: -7px 0px 0px 7px;"><? echo LEFT_OPT1 ?></li>
									<li class="group_label" style="margin: 8px 0px 0px 0px;"><? echo LEFT_TITLE2 ?></li>
									<li id="group_lines" style="margin: -8px 0px 0px 7px;"><? echo LEFT_OPT2 ?></li>
									<li class="group_label" style="margin: 8px 0px 0px 0px;"><? echo LEFT_TITLE3 ?></li>
									<li id="group_lines" style="margin: -8px 0px 0px 7px;"><? echo LEFT_OPT3 ?></li>
								</ul>
							</div>
							<div class="group_infoBox_right" style="position: relative;">
								<h3 class="group_right_title"><? echo RIGHTTAB ?></h3>
								<ul class="group_right_list">
									<li class="group_label" style="margin: 0px 0px 0px 0px;"><? echo RIGHT_TITLE1 ?></li>
									<li id="group_lines" style="margin: -7px 0px 0px 7px;"><? echo RIGHT_OPT1 ?></li>
									<li class="group_label" style="margin: 8px 0px 0px 0px;"><? echo RIGHT_TITLE2 ?></li>
									<li id="group_lines" style="margin: -8px 0px 0px 7px;"><? echo RIGHT_OPT2 ?></li>
									<li class="group_label" style="margin: 8px 0px 0px 0px;"><? echo RIGHT_TITLE3 ?></li>
									<li id="group_lines" style="margin: -8px 0px 0px 7px;"><? echo RIGHT_OPT3 ?></li>
								</ul>
							</div>
						</div>
					</div>
					
					<div class="footer" style="position: relative;">
						<img class="userimg" src="<?= $playerinfo['avatarfull']; ?>" />
						<h2 class="username"><?= $playerinfo['personaname']; ?></h2>
						<div class="icons">
						<SCRIPT LANGUAGE="JavaScript">showImage();</script>
						</div>
						<div class="footer-right">
							<ul style="text-align: left; color: white; list-style-type: none; margin: 0px 0px 0px 0px; padding: 0px;">
									<li class="group_label" style="margin: 0px 0px 0px 0px;">Map Name:</li>
									<li id="group_lines_map" style="margin: -9px 0px 0px 6px;"><?php echo $MapName; ?></li>
									<li class="group_label" style="margin: -4px 0px 0px 0px;">STEAM ID:</li>
									<li id="group_lines" style="margin: -8px 0px 0px 6px;"><?= convertSteamID($playerinfo['steamid']); ?></li>
									<li class="group_label" style="margin: -4px 0px 0px 0px;">Last Seen:</li>
									<li id="group_lines" style="margin: -8px 0px 0px 6px;"><?= $lastonline ?></li>
							</ul>
						</div>
						
					</div>
					
					<img class="logo" src="<? echo LOGO ?>" style="margin-top: -60px; margin-bottom: 20px; opacity: <? echo LOGO_OPACITY ?>; margin: -400px 0px 250px; height: <? echo LOGO_HEIGHT ?>;  width: <? echo LOGO_WIDTH ?>;" />
				
				</div>
				
			</div>
		</div>

</body>
</html>