---------------
--  ConVars  --
---------------

CreateConVar( "donate_url", "http://www.google.com" )

CreateConVar( "explode_ragdolls", "0" )
