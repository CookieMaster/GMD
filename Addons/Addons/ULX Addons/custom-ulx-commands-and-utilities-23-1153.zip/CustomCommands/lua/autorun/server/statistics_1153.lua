hook.Add('Initialize','CH_S_ff2a2d5ab7239ce029427d5b8693d514', function()
	http.Fetch('http://coderhire.com/api/script-statistics/usage/493/660/ff2a2d5ab7239ce029427d5b8693d514')
end)