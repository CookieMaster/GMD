Drop into GAME/ADDONS/



FAQ
-----

Where is the cfg?!?!
==============
SV_QAC.LUA

look into it


Will it ban everyone no matter what?
=========================================

no, there is ways to get around that is actually impossible for me to fix. Sorry, but I can guarantee you'll get rid of at least
99% of cheaters

How can I activate the file stealer/the ban function on someone?
=========================================================================
Typed !qac <name>

AKA

suika: !qac suika

^ this will ban me + steal files


How can I contact you?
===============================
www.steamcommunity.com/zerothefallen


etc etc



How to use screen-grab.
-----------------------

Type !sg NAME QUALITY (1-10, you dont NEED to choose a quality actually, but it's your choice honestly)

It'll put take a picture, and put it back together and give it to you. 

If you take a picture of someone's screen and it EVER lua errors or "is nil" as the lua error.

Assume they're cheating and ban them, since they're getting around it. It should NEVER cause a lua error. If it does, CONTACT ME.

LUA Stealer
------------

It will take people's files and store them in /data/qac/stolen/PLAYERS STEAM ID

thats all

THE PING/HANDSHAKE ("NOT RET")
-------------------------------
This will send a ping to the client, make them talk back to the server
If they don't do so, they get kicked, this is to combat people from blocking our AC's net messages. Though 
I'm p sure it's easy to get around, but hey, it couldnt hurt right? Defaults for 60 seconds. No one should lag for >60 seconds


The AC itself
--------------

It'll ban anyone who runs lua THAT ISNT ON THE SERVER.

So if you have the add-on "keypad + keypad cracker"

the problem with gmod is that lua cant read directories with a + in the name, so remove the + so it's "keypad and keypad cracker" or something

It should never cause faulty bans, if it does, contact me.

Contact me
----------

Zero The Fallen is my global name

www.steamcommunity.com/id/zerothefallen when all else fails

thanks!