local meta = FindMetaTable("Player");


if SERVER then
	util.AddNetworkString( "ACV_SavedACVs" )
	util.AddNetworkString( "ACV_SyncACV" )
			
	net.Receive( "ACV_AdminAdj_Target_C2S", function( len,ply )
		local DATA = net.ReadTable()
		local Target = DATA.Target
		local AchieveLuaname = DATA.AchieveLuaname
		local Value = DATA.Value
		
		if !Target or !Target:IsValid() then return end
		
		Target.ACVData[AchieveLuaname] = 0
		Target:ACV_Increase(AchieveLuaname,Value)
	end)
	
	hook.Add("Initialize", "ACV Dir Check", function()
		file.CreateDir("acv")
	end)

	hook.Add( "PlayerInitialSpawn", "ACV Load", function(ply)
		ply:LoadACVs()
	end)
	
	hook.Add( "PlayerDisconnected", "ACV Save", function(ply)
		ply:SaveACVs()
	end	)
	
	function meta:GetSIDs()
		return string.gsub(self:SteamID(),":","_")
	end
	
	function meta:LoadACVs()
		local Data = {}
		if file.Exists( "acv/" .. self:GetSIDs() .. ".txt" ,"DATA") then
			Data = util.JSONToTable(file.Read( "acv/" .. self:GetSIDs() .. ".txt","DATA" ))
		end
	
		self.ACVData = Data
		
		net.Start( "ACV_SavedACVs" )
			net.WriteTable( Data )
		net.Send(self)
	
	end
	function meta:SaveACVs()
		if !self.ACVData then return end
		
		local Data = self.ACVData or {}
		
		file.Write("acv/" .. self:GetSIDs() .. ".txt", util.TableToJSON(Data));
	end
	
	
	function meta:ACV_Increase(luaname,amount)
		local ADB = ACVTable(luaname)
		if !ADB then return end
		local Max = ADB.Max
		local Min = ADB.Min
		
		self.ACVData[luaname] = self.ACVData[luaname] or Min
		if self.ACVData[luaname] >= Max then return end
		
			self.ACVData[luaname] = self.ACVData[luaname] + amount
			if self.ACVData[luaname] >= Max then -- Clear
				self.ACVData[luaname] = Max
				for k,v in pairs(player.GetAll()) do
					v:ChatPrint(" Player, " .. self:Nick() .. " has finished the achievement : " .. ADB.PrintName .. " !!")
				end
				if ADB.OnClear then
					ADB:OnClear(self)
				end
			end
			if self.ACVData[luaname] < Min then
				self.ACVData[luaname] = Min
			end
			
			net.Start( "ACV_SyncACV" )
				net.WriteTable({LN=luaname,AM=self.ACVData[luaname]})
			net.Send(self)
			
		self:SaveACVs()
	end
end

if CLIENT then
	local ACVTTime = CurTime()
	hook.Add("Think","ACV Test",function()
		if ACVTTime < CurTime() then
			ACVTTime = CurTime() + 8
		--	ACV_DrawNoticer("ACV_Normal_Say_100")
		end
	end)

	ACV_ClientInventory = ACV_ClientInventory or {}
	net.Receive( "ACV_SavedACVs", function( len )
		local DATA = net.ReadTable()
		ACV_ClientInventory = DATA
	end)
	net.Receive( "ACV_SyncACV", function( len )
		local DA = net.ReadTable()
		ACV_ClientInventory[DA.LN] = DA.AM
		
		local ADB = ACVTable(DA.LN)
		if DA.AM >= ADB.Max then
			ACV_DrawNoticer(DA.LN)
		end
	end)
	
	function ACV_DrawNoticer(ACVLuaName)
		local ADB = ACVTable(ACVLuaName)
	
			hook.Remove( "HUDPaint", "ACVNotice_HUD" )
			local StartTime = CurTime()
			local PosX = ScrW()/2-250
			local PosY = ScrH()+50
			
			local SizeX,SizeY = 500,100
			
			hook.Add("HUDPaint","ACVNotice_HUD",function()
				local DeltaTime = CurTime() - StartTime
				
				if DeltaTime < ACVCustomizer.CompleteNoticerHUDDuration then
					local AnimationLerp = 100/(1/FrameTime())
					AnimationLerp = AnimationLerp/15
					PosY = Lerp(AnimationLerp,PosY,ScrH()-150)
				else
					local AnimationLerp = 100/(1/FrameTime())
					AnimationLerp = AnimationLerp/25
					PosY = Lerp(AnimationLerp,PosY,ScrH()+50)
				end
						surface.SetDrawColor(0,0,0,250) 
						surface.DrawRect(PosX,PosY,SizeX,SizeY)
						
						surface.SetDrawColor(0,150,255,250)
						surface.DrawRect(PosX,PosY,SizeX,1)
						surface.DrawRect(PosX,PosY+SizeY-1,SizeX,1)
						surface.DrawRect(PosX,PosY,1,SizeY)
						surface.DrawRect(PosX+SizeX-1,PosY,1,SizeY)
						
						
						draw.SimpleText("Achievement Complete!!", "RXF_TrebOut_S30", PosX+SizeX/2, PosY+5, Color(0,200,255,255), TEXT_ALIGN_CENTER)
						render.SetScissorRect( PosX+10, 0, PosX+SizeX -10 , ScrH(), true )
							draw.SimpleText("< " .. ADB.PrintName .. " >", "RXF_TrebOut_S25", PosX+SizeX/2, PosY+35, Color(0,255,255,255), TEXT_ALIGN_CENTER)
							draw.SimpleText("< " .. ADB.Description .. " >", "RXF_TrebOut_S20", PosX+SizeX/2, PosY+70, Color(150,150,255,255), TEXT_ALIGN_CENTER)
						render.SetScissorRect( PosX+10, 0, PosX+SizeX -10, ScrH() , false )				
				
				if DeltaTime > ACVCustomizer.CompleteNoticerHUDDuration+1 then
					hook.Remove( "HUDPaint", "ACVNotice_HUD" )
					return
				end
			end)	

	end
end