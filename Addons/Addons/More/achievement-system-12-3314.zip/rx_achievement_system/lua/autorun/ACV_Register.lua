ACV = ACV or {}
ACV.Achievements = ACV.Achievements or {}
ACV.AchievementsByCategory = ACV.AchievementsByCategory or {}

function ACV_CreateACVStruct()
	local ACVMT = {}
	ACVMT.Max = 100
	ACVMT.Min = 1
	ACVMT.Order = 1
	function ACVMT:OnClear(ply)
	
	end
	function ACVMT:AddRewardText(text)
		self.RewardTextDB = self.RewardTextDB or {}
		table.insert(self.RewardTextDB,text)
	end
	return table.Copy(ACVMT)
end

function RegisterACVMT(DB)
	ACV.Achievements[DB.LuaName] = DB
	
	ACV.AchievementsByCategory["All"] = ACV.AchievementsByCategory["All"] or {}
	ACV.AchievementsByCategory["All"][DB.LuaName] = DB
	
	if DB.Category then
		ACV.AchievementsByCategory[DB.Category] = ACV.AchievementsByCategory[DB.Category] or {}
		ACV.AchievementsByCategory[DB.Category][DB.LuaName] = DB
	end
end

function ACVTable(luaname)
local ACVDBK = ACV.Achievements[luaname]
	if ACVDBK then
		return ACVDBK
	end
	
	return false
end

function ACV_Include()
MsgN("< ===== Achievement System By RocketMania ===== >")
local path = "achievements/"
	for _, file in pairs(file.Find(path .. "*.lua","LUA")) do
		if SERVER then
			AddCSLuaFile(path .. file)
		end
		include(path .. file)
	end
end
ACV_Include()