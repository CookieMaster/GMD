local PLAYER = FindMetaTable("Player");

if SERVER then
	hook.Add("PlayerSay","SkillVGUI OpenCMD",function(ply,text)
		if text == ACVCustomizer.ChatCommand then
			ply:ACV_Open(ply)
		end
	end)
	
	concommand.Add(ACVCustomizer.ConsoleCommand,function(ply,cmd,args)
		ply:ACV_Open(ply)
	end)

	util.AddNetworkString( "ACV_Open_S2C" )
	util.AddNetworkString( "ACV_Open_AnotherPlayerC2S" )
	util.AddNetworkString( "ACV_AdminAdj_Target_C2S" )
	function PLAYER:ACV_Open(target)
		target = target or self
		
		net.Start( "ACV_Open_S2C" )
			net.WriteTable( {TargetACVData=target.ACVData or {},Target=target} )
		net.Send(self)
	end
	
	net.Receive( "ACV_Open_AnotherPlayerC2S", function( len,ply )
		local DATA = net.ReadTable()
		local TARGET = DATA.Target
		if !TARGET or !TARGET:IsValid() then return end
		ply:ACV_Open(TARGET)
	end)
end

if CLIENT then
	net.Receive( "ACV_Open_S2C", function( len )
		local DATA = net.ReadTable()
		ACVPanel_Open(DATA)
	end)
	

function ACVPanel_Open(DATA)
	if ACVPanel and ACVPanel:IsValid() then 
		ACVPanel:Remove()
	end
	ACVPanel = vgui.Create("ACVPanel")
	ACVPanel:SetSize(ScrW()*0.7,ScrH()*0.7)
	ACVPanel:Center()
	ACVPanel:MakePopup()
	ACVPanel:SetTargetData(DATA)
	ACVPanel:Install()
end


local PANEL = {}

function PANEL:Init()
	self:SetTitle(" ")
	self:ShowCloseButton(false)
	
	self.AdminMode = true
end

function PANEL:Paint()
		draw.RoundedBox(4, 0, 0, self:GetWide(), self:GetTall(), Color(0,150,255,255))
		draw.RoundedBox(4, 2, 2, self:GetWide()-4, self:GetTall()-4, Color(0,0,0,255))
		
		surface.SetDrawColor(Color(0,150,255,255))
		surface.DrawRect(10,40,self:GetWide()-20,2)
		
		if self.Target then
			draw.SimpleText(self.Target:Nick() .. " ' s Achievements" , "RXF_Treb_S27", 30, 22 , Color(200,200,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		
end

function PANEL:BuildCategory()
	self.CategoryList:Clear()
	
	local function CreateCategoryButton(CategoryName)
		local CategoryBTN = vgui.Create("DButton")
		CategoryBTN:SetSize(self.CategoryList:GetWide(),35)
		CategoryBTN:SetText(" ")
		CategoryBTN.FXP = 0
		CategoryBTN.FXPWide = 30
		CategoryBTN.OnCursorEntered = function(slf) slf.Hover = true end
		CategoryBTN.OnCursorExited = function(slf) slf.Hover = false end
		CategoryBTN.DoClick = function(slf)
			self:UpdateList(CategoryName)
		end
		CategoryBTN.Paint = function(slf)
			if self.CurCategoryName and self.CurCategoryName == CategoryName then
				local AnimationLerp = 100/(1/FrameTime())
				AnimationLerp = AnimationLerp/10
				slf.FXP = Lerp(AnimationLerp,slf.FXP,slf.FXPWide)
				surface.SetDrawColor(Color(0,150 + slf.FXP*3,255,255))
			else
				local AnimationLerp = 100/(1/FrameTime())
				AnimationLerp = AnimationLerp/10
				slf.FXP = Lerp(AnimationLerp,slf.FXP,0)
				surface.SetDrawColor(Color(0,150 + slf.FXP*3,255,255))
			end
				surface.DrawRect(slf.FXP,0,slf:GetWide()-slf.FXPWide,slf:GetTall())
			
			if slf.Hover then
				surface.SetDrawColor(Color(0,0,0,200))
			else
				surface.SetDrawColor(Color(0,0,0,220))
			end
				surface.DrawRect(slf.FXP+1,1,slf:GetWide()-2-slf.FXPWide,slf:GetTall()-2)

			draw.SimpleText(CategoryName , "RXF_TrebOut_S20", slf.FXP + (slf:GetWide()-slf.FXPWide)/2, 8 , Color(0,255,255,255), TEXT_ALIGN_CENTER)
		end
		
		self.CategoryList:AddItem(CategoryBTN)
	end
	CreateCategoryButton("All")
	
	for k,v in pairs(ACV.AchievementsByCategory) do
		if k != "All" then
			CreateCategoryButton(k)
		end
	end
end

function PANEL:Admin_EditACV(Luaname)
	local ADB = ACVTable(Luaname)
	local Mask = vgui.Create("DPanel",self)
	Mask:SetSize(self:GetWide(),self:GetTall())
	Mask.Paint = function(slf)
		surface.SetDrawColor(Color(0,0,0,243))
		surface.DrawRect(2,2,slf:GetWide()*4,slf:GetTall()-4)
			
		draw.SimpleText("Manage Achievement" , "RXF_TrebOut_S40", Mask:GetWide()/2, 70 , Color(0,255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
		
		draw.SimpleText("Target Player :" , "RXF_TrebOut_S30", 100, 120 , Color(0,255,255,255))
		draw.SimpleText(self.Target:Nick(), "RXF_TrebOut_S30", Mask:GetWide()-100, 120 , Color(0,150,255,255),TEXT_ALIGN_RIGHT)
		surface.SetDrawColor(Color(0,200,255,50))
		surface.DrawRect(100,150,slf:GetWide()-200,1)
		
		draw.SimpleText("Achievement :" , "RXF_TrebOut_S30", 100, 200 , Color(0,255,255,255))
		draw.SimpleText(ADB.PrintName, "RXF_TrebOut_S30", Mask:GetWide()-100, 200 , Color(0,150,255,255),TEXT_ALIGN_RIGHT)
		surface.SetDrawColor(Color(0,200,255,50))
		surface.DrawRect(100,230,slf:GetWide()-200,1)
		
		draw.SimpleText("Progress Change :" , "RXF_TrebOut_S30", 100, 280 , Color(0,255,255,255))
		if slf.Slider then
			draw.SimpleText(math.Round(slf.Slider:GetValue()), "RXF_TrebOut_S30", Mask:GetWide()-100, 280 , Color(0,150,255,255),TEXT_ALIGN_RIGHT)
		end
		
		surface.SetDrawColor(Color(0,200,255,50))
		surface.DrawRect(100,310,slf:GetWide()-200,1)
		
		draw.SimpleText("Warning. if you lower the progress and target reaches 100 percent, winning price will be sent to target again." , "RXF_TrebOut_S20", slf:GetWide()/2, slf:GetTall()-90 , Color(0,255,255,255),TEXT_ALIGN_CENTER)
	end
	
	local Slider = vgui.Create("ACV_Sliders",Mask)
	Slider:SetPos(100,320)
	Slider:SetSize(200,40)
	Slider:SetMin(ADB.Min)
	Slider:SetMax(ADB.Max)
	Slider:SetUp()
	Mask.Slider = Slider
	
	local Exit = vgui.Create( "ACV_DSWButton", Mask)
		Exit:SetPos(Mask:GetWide()/3 - 70, Mask:GetTall()-60);
		Exit:SetSize(140, 35);
		Exit:SetTexts("Cancel")
		Exit.Click = function()
			Mask:Remove()
		end	
		
	local Exit = vgui.Create( "ACV_DSWButton", Mask)
		Exit:SetPos(Mask:GetWide()/3*2 - 70, Mask:GetTall()-60);
		Exit:SetSize(140, 35);
		Exit:SetTexts("Okay")
		Exit.Click = function()
			local TB2Send = {}
			TB2Send.Target = self.Target
			TB2Send.AchieveLuaname = Luaname
			TB2Send.Value = math.Round(Slider:GetValue())
		
			net.Start( "ACV_AdminAdj_Target_C2S" )
				net.WriteTable( TB2Send )
			net.SendToServer()
			
			Mask:Remove()
		end	
		
	
end

function PANEL:UpdateList(CategoryName)
	self.CurCategoryName = CategoryName
	self.ACVList:Clear()
	
	local Sort = {}
	for _,DB in pairs(ACV.AchievementsByCategory[CategoryName] or {}) do
		table.insert(Sort,table.Copy(DB))
	end
	table.SortByMember(Sort, "Order", function(a, b) return a > b end)
	
	local Count = 0
	for _,DB in pairs(Sort) do
		--
		Count = Count + 1
		local CategoryButton = vgui.Create("DButton")
		CategoryButton:SetSize(self.ACVList:GetWide()-20,90)
		CategoryButton:SetText("")
		CategoryButton.Count = Count
		CategoryButton.Per = 0
		CategoryButton.OnCursorEntered = function(slf) slf.Hover = true end
		CategoryButton.OnCursorExited = function(slf) slf.Hover = false end
		
		-- Reward ToolTip
		if DB.RewardTextDB then
			local RewardToolTipButton = vgui.Create("DButton",CategoryButton)
			RewardToolTipButton:SetText(" ")
			RewardToolTipButton:SetPos(CategoryButton:GetWide()-32,2)
			RewardToolTipButton:SetSize(26,26)
			
			local Text = "< Clear Rewards >"
			for k,v in pairs(DB.RewardTextDB) do
				Text = Text .. " \n" .. v 
			end
			
			RewardToolTipButton:SetToolTip(Text)
			RewardToolTipButton.Paint = function(slf)
				draw.SimpleText("+" , "RXF_TrebOut_S30", 13, 13 , Color(0,255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
			end
		end
		
		
		-- Admin Mode
		if ACV_IsAdmin(LocalPlayer()) then
			local Texture = Material("gui/HTML/refresh")
			local AdminEdit = vgui.Create( "DButton", CategoryButton )
			AdminEdit:SetPos(CategoryButton:GetWide()-62,4)
			AdminEdit:SetSize(22,22)
			AdminEdit:SetText(" ")
			AdminEdit.Paint = function(slf)
				if self.AdminMode then
					surface.SetDrawColor(Color(255,0,0,255))
					surface.SetMaterial(Texture)
					surface.DrawTexturedRect( 0,0,slf:GetWide(),slf:GetTall() );
				end
			end
			AdminEdit.DoClick = function(slf) 
				if !self.AdminMode then return end
				
				self:Admin_EditACV(DB.LuaName)
			end
		end
		
		CategoryButton.Paint = function(slf)
			surface.SetDrawColor(Color(0,150,255,(slf.Count%2)*10+10))
			surface.DrawRect(0,0,slf:GetWide(),slf:GetTall()-1)
			
			if !slf.Hover then
				surface.SetDrawColor(Color(0,0,0,230))
			else
				surface.SetDrawColor(Color(0,0,0,200))
			end
			
			surface.DrawRect(0,0,slf:GetWide(),slf:GetTall()-1)
			
			surface.SetDrawColor(Color(0,150,255,100))
			surface.DrawRect(0,slf:GetTall()-1,slf:GetWide(),1)
			
			if DB.Icon then
				surface.SetDrawColor(Color(0,150,255,50))
				surface.DrawRect(5,5,slf:GetTall()-10,slf:GetTall()-10)
				surface.SetDrawColor(Color(0,0,0,240))
				surface.DrawRect(6,6,slf:GetTall()-12,slf:GetTall()-12)
				draw.SimpleText(DB.PrintName , "RXF_TrebOut_S30", 20+slf:GetTall()-10, 3 , Color(0,255,255,255))
				
				surface.SetDrawColor(Color(0,200,255,10))
				surface.DrawRect(15+slf:GetTall()-10,32,slf:GetWide() - (20+slf:GetTall()-10),1)
				
				draw.SimpleText(DB.Description , "RXF_TrebOut_S20", 20+slf:GetTall()-10, 35 , Color(0,150,255,200))
			else
				draw.SimpleText(DB.PrintName , "RXF_TrebOut_S30", 10, 3 , Color(0,255,255,255))
				
				surface.SetDrawColor(Color(0,200,255,10))
				surface.DrawRect(5,32,slf:GetWide() - 10,1)
				
				draw.SimpleText(DB.Description , "RXF_TrebOut_S20", 10, 35 , Color(0,150,255,200))
			end
			
			-- Progress Bar
			surface.SetDrawColor(Color(0,150,255,100))
			surface.DrawRect(180,65,slf:GetWide()-190,20)
			surface.SetDrawColor(Color(0,0,0,250))
			surface.DrawRect(180,66,slf:GetWide()-190,18)
			
			
			
			local PA,PM = (self.TargetACVData[DB.LuaName] or DB.Min),DB.Max
			
			if self.Target == LocalPlayer() then
				PA = LocalPlayer():ACV_GetEXP(DB.LuaName)
			end
			
			local Percent = PA/PM
			Percent = math.min(Percent,1)
			
				local AnimationLerp = 100/(1/FrameTime())
				AnimationLerp = AnimationLerp/10
				slf.Per = Lerp(AnimationLerp,slf.Per,Percent)
			
			if Percent == 1 then
				surface.SetDrawColor(Color(0,255,0,120))
				surface.DrawRect(182,67,(slf:GetWide()-194)*slf.Per,8)
				surface.SetDrawColor(Color(0,200,0,120))
				surface.DrawRect(182,75,(slf:GetWide()-194)*slf.Per,8)
				draw.SimpleText("Complete!", "BudgetLabel", 182 + (slf:GetWide()-194)/2, 68 , Color(0,255,0,200),TEXT_ALIGN_CENTER)
			else
				surface.SetDrawColor(Color(0,200,255,120))
				surface.DrawRect(182,67,(slf:GetWide()-194)*slf.Per,8)
				surface.SetDrawColor(Color(0,170,255,120))
				surface.DrawRect(182,75,(slf:GetWide()-194)*slf.Per,8)
				draw.SimpleText(math.Round(PA*100)/100 .. " / " .. math.Round(PM*100)/100 .. " ( " .. math.Round(slf.Per*100)  .. " % )", "BudgetLabel", 182 + (slf:GetWide()-194)/2, 68 , Color(0,150,255,200),TEXT_ALIGN_CENTER)
			end

			
			
		end
		
		self.ACVList:AddItem(CategoryButton)
		--
	end
end

function PANEL:SetTargetData(DATA)
	self.Target = DATA.Target
	self.TargetACVData = DATA.TargetACVData
end

function PANEL:Think()
	if !self.Target or !self.Target:IsValid() then
		self:Remove()
	end
end

function PANEL:Install()

	local Exit = vgui.Create( "ACV_DSWButton", self)
		Exit:SetPos(self:GetWide() - 110, 5);
		Exit:SetSize(100, 35);
		Exit:SetTexts("Close")
		Exit.BoarderCol = Color(0,0,0,0)
		Exit.Click = function()
			ACVPanel:Remove()
			ACVPanel = nil
			
		--	ACVPanel_Open()
		end
		
	local BTN = vgui.Create( "ACV_DSWButton", self)
		BTN:SetPos(self:GetWide() - 210, 5);
		BTN:SetSize(100, 35);
		BTN:SetTexts("The Others")
		BTN.BoarderCol = Color(0,0,0,0)
		BTN.Click = function(slf)
			local function Open_AnotherPPL(Target)
				net.Start( "ACV_Open_AnotherPlayerC2S" )
					net.WriteTable( {Target=Target} )
				net.SendToServer()
			end
			
			local menu = DermaMenu()
			for k,v in pairs(player.GetAll()) do
				if v != self.Target then
					menu:AddOption(v:Nick(),function() Open_AnotherPPL(v) end)
				end
			end
			menu:Open()
		end
		
	if ACV_IsAdmin(LocalPlayer()) then
	local BTN = vgui.Create( "ACV_DSWButton", self)
		BTN:SetPos(self:GetWide() - 350, 5);
		BTN:SetSize(140, 35);
		if !self.AdminMode then
			BTN:SetTexts("Admin Mode OFF")
		else
			BTN:SetTexts("Admin Mode ON")
		end
		
		BTN.BoarderCol = Color(0,0,0,0)
		BTN.Click = function(slf)
			self.AdminMode = !self.AdminMode
			if !self.AdminMode then
				slf:SetTexts("Admin Mode OFF")
			else
				slf:SetTexts("Admin Mode ON")
			end
		end
	end
	
		
		-- Category List
		self.CategoryList = vgui.Create("DPanelList", self)
		self.CategoryList:SetPos(20, 50);
		self.CategoryList:SetSize(200, self:GetTall()-150);
		self.CategoryList:SetSpacing(3);
		self.CategoryList:SetPadding(0);
		self.CategoryList:EnableVerticalScrollbar(true);
		self.CategoryList:EnableHorizontal(false);
		self.CategoryList:ACV_PaintListBarC()
		self.CategoryList.Paint = function(slf)
		end
		
		-- Skills List
		self.ACVList = vgui.Create("DPanelList", self)
		self.ACVList:SetPos(230, 50);
		self.ACVList:SetSize(self:GetWide()-250, self:GetTall()-150);
		self.ACVList:SetSpacing(3);
		self.ACVList:SetPadding(0);
		self.ACVList:EnableVerticalScrollbar(true);
		self.ACVList:EnableHorizontal(false);
		self.ACVList:ACV_PaintListBarC()
		self.ACVList.Paint = function(slf)
		end
		
		-- Buttom Bar
		self.ButtomBar = vgui.Create("DPanelList", self)
		self.ButtomBar:SetPos(10, self:GetTall()-90);
		self.ButtomBar:SetSize(self:GetWide()-20, 80);
		self.ButtomBar.Per = 0
		self.ButtomBar.Paint = function(slf)
			surface.SetDrawColor(Color(0,150,255,255))
			surface.DrawRect(0,0,slf:GetWide(),2)
			
			if self.CurCategoryName then
				draw.SimpleText(self.CurCategoryName, "RXF_TrebOut_S30", slf:GetWide()/2, 10 , Color(0,200,255,200),TEXT_ALIGN_CENTER)
			
				local Count = 0
				local ClearCount = 0
				for _,DB in pairs(ACV.AchievementsByCategory[self.CurCategoryName] or {}) do
					Count = Count + 1
					if (self.TargetACVData[DB.LuaName] or DB.Min) >= DB.Max then
						ClearCount = ClearCount + 1
					end
				end
				
				
				-- Progress Bar
				surface.SetDrawColor(Color(0,150,255,100))
				surface.DrawRect(75,45,slf:GetWide()-150,30)
				surface.SetDrawColor(Color(0,0,0,250))
				surface.DrawRect(76,46,slf:GetWide()-152,28)
				
				local PA,PM = ClearCount,Count
				local Percent = PA/PM
				Percent = math.min(Percent,1)
				
				local AnimationLerp = 100/(1/FrameTime())
				AnimationLerp = AnimationLerp/10
				slf.Per = Lerp(AnimationLerp,slf.Per,Percent)
				
				if Percent == 1 then
					surface.SetDrawColor(Color(0,255,0,120))
					surface.DrawRect(77,47,(slf:GetWide()-154)*slf.Per,12)
					surface.SetDrawColor(Color(0,200,0,120))
					surface.DrawRect(77,59,(slf:GetWide()-154)*slf.Per,14)
					draw.SimpleText("Complete!", "RXF_TrebOut_S20", 75 + (slf:GetWide()-150)/2, 50 , Color(0,255,0,200),TEXT_ALIGN_CENTER)
				else
					surface.SetDrawColor(Color(0,200,255,120))
					surface.DrawRect(77,47,(slf:GetWide()-154)*slf.Per,12)
					surface.SetDrawColor(Color(0,170,255,120))
					surface.DrawRect(77,59,(slf:GetWide()-154)*slf.Per,14)
					draw.SimpleText(math.Round(PA*100)/100 .. " / " .. math.Round(PM*100)/100 .. " ( " .. math.Round(slf.Per*100)  .. " % )", "RXF_TrebOut_S20", 75 + (slf:GetWide()-150)/2, 50 , Color(0,150,255,200),TEXT_ALIGN_CENTER)
				end
			end
		end
		
		self:BuildCategory()
		self:UpdateList("All")
end

vgui.Register("ACVPanel",PANEL,"DFrame")
end