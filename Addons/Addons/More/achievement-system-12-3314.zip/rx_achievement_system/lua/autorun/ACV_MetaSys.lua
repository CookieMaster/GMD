local meta = FindMetaTable("Player");

	function meta:ACV_GetEXP(luaname)
		local ADB = ACVTable(luaname)
		if SERVER then
			return self.ACVData[luaname] or ADB.Min or 0
		else
			return ACV_ClientInventory[luaname] or ADB.Min or 0
		end
	end
	
	function meta:ACV_HasCleared(luaname)
		local ADB = ACVTable(luaname)
		if self:ACV_GetEXP(luaname) >= ADB.Max then
			return true
		else
			return false
		end
	end