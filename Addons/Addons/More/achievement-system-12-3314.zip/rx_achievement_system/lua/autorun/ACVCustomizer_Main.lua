ACVCustomizer = {}

ACVCustomizer.ChatCommand = "!acv"
ACVCustomizer.ConsoleCommand = "acv_open"
ACVCustomizer.CompleteNoticerHUDDuration = 5

-- ULX GROUP CHECK
function ACV_IsAdmin(ply)
	local ULXGroupCheck = {}
	ULXGroupCheck["owner"] = true
	ULXGroupCheck["superadmin"] = true
	ULXGroupCheck["admin"] = true
	
	local PlyGroup = ply:GetNWString("usergroup")
	PlyGroup = string.lower(PlyGroup)
	
	if ULXGroupCheck[PlyGroup] then
		return true
	else
		return false
	end
end



// If you want to make it so only you can access to admin page, use this code.

/*
-- STEAM UNIQUE ID CHECK
function ACV_IsAdmin(ply)
	local AvailableUID = {}
	AvailableUID["STEAM_0:1:12312312"] = true -- but if you set this to ' false ' , will not work.
	AvailableUID["STEAM_0:1:22222222"] = true
	AvailableUID["STEAM_0:1:33333333"] = true
	
	
	local UG = ply:SteamID()
	if AvailableUID[UG] then
		return true
	else
		return false
	end
end
*/