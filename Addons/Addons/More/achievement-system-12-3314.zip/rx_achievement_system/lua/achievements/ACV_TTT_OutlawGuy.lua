/* ──────────────────────────────────────────────────────────────────
	Kill Traitor - 50
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_TTT_OutlawGuy_KillTraitor50"
	ACVMT.PrintName = "Hi, Traitor!"
	ACVMT.Description = "Kill Traitor as traitor for 50 times"
	ACVMT.Category = "TTT : Outlaw Guy"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 50

RegisterACVMT(ACVMT)



if SERVER then
	local Timer = CurTime()
	hook.Add("PlayerDeath","ACV " .. "PlayerDeath" .. ACVMT.LuaName,function( victim, infl, attacker)
		if victim:IsPlayer() and attacker:IsPlayer() and victim != attacker then
			if victim:GetRole() == ROLE_TRAITOR and attacker:GetRole() == ROLE_TRAITOR then
				attacker:ACV_Increase(ACVMT.LuaName,1)
			end
		end
	end)
end


/* ──────────────────────────────────────────────────────────────────
	Kill Innocent - 50
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_TTT_OutlawGuy_KillInnocent50"
	ACVMT.PrintName = "Hi, Innocent!"
	ACVMT.Description = "Kill Innocent as innocent for 50 times"
	ACVMT.Category = "TTT : Outlaw Guy"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 50

RegisterACVMT(ACVMT)



if SERVER then
	local Timer = CurTime()
	hook.Add("PlayerDeath","ACV " .. "PlayerDeath" .. ACVMT.LuaName,function( victim, infl, attacker)
		if victim:IsPlayer() and attacker:IsPlayer() and victim != attacker then
			if victim:GetRole() == ROLE_INNOCENT and attacker:GetRole() == ROLE_INNOCENT then
				attacker:ACV_Increase(ACVMT.LuaName,1)
			end
		end
	end)
end



/* ──────────────────────────────────────────────────────────────────
	Kill Detect - 50
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_TTT_OutlawGuy_KillDetect50"
	ACVMT.PrintName = "I don't need you"
	ACVMT.Description = "Kill Detective as innocent for 50 times"
	ACVMT.Category = "TTT : Outlaw Guy"
	
	ACVMT.Order = 3
	ACVMT.Min = 0
	ACVMT.Max = 50

RegisterACVMT(ACVMT)

if SERVER then
	hook.Add("PlayerDeath","ACV " .. "PlayerDeath" .. ACVMT.LuaName,function( victim, infl, attacker)
		if victim:IsPlayer() and attacker:IsPlayer() then
			if victim:GetRole() == ROLE_DETECTIVE and attacker:GetRole() == ROLE_INNOCENT then
				attacker:ACV_Increase(ACVMT.LuaName,1)
			end
		end
	end)
end