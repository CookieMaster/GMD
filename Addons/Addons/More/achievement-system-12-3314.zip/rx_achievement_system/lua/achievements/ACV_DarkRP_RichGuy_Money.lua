/* ──────────────────────────────────────────────────────────────────
	5000
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_DarkRP_Money_5000"
	ACVMT.PrintName = "Where is my Wallet?"
	ACVMT.Description = "Carry 5000 Money"
	ACVMT.Category = "DarkRP : Rich Guy"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 1

RegisterACVMT(ACVMT)

if SERVER then

	local Timer = CurTime()
	hook.Add("Think","ACV " .. "Think" .. ACVMT.LuaName,function()
		Timer = CurTime() + 1
		for k,v in pairs(player.GetAll()) do
			if v.DarkRPVars and v.DarkRPVars["money"] and v.DarkRPVars["money"] >= 5000 then
				v:ACV_Increase(ACVMT.LuaName,1)
			end
		end
	end)

end



/* ──────────────────────────────────────────────────────────────────
	30000
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_DarkRP_Money_30000"
	ACVMT.PrintName = "$ 30,000"
	ACVMT.Description = "Carry 30000 Money"
	ACVMT.Category = "DarkRP : Rich Guy"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 1

RegisterACVMT(ACVMT)

if SERVER then

	local Timer = CurTime()
	hook.Add("Think","ACV " .. "Think" .. ACVMT.LuaName,function()
		Timer = CurTime() + 1
		for k,v in pairs(player.GetAll()) do
			if v.DarkRPVars["money"] and v.DarkRPVars["money"] >= 30000 then
				v:ACV_Increase(ACVMT.LuaName,1)
			end
		end
	end)

end