/* ──────────────────────────────────────────────────────────────────
	Become - 50
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_TTT_MasterDetective_Become50"
	ACVMT.PrintName = "Detective Addiction"
	ACVMT.Description = "Become Detective for 50 times"
	ACVMT.Category = "TTT : Master Detective"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 50

RegisterACVMT(ACVMT)

if SERVER then
	local Timer = CurTime()
	hook.Add("TTTBeginRound","ACV " .. "TTTBeginRound" .. ACVMT.LuaName,function()
		for k,v in pairs(player.GetAll()) do
			if v:GetRole() == ROLE_DETECTIVE then
				v:ACV_Increase(ACVMT.LuaName,1)
			end
		end
	end)
end



/* ──────────────────────────────────────────────────────────────────
	Kill Traitor - 50
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_TTT_MasterDetective_KillTraitor50"
	ACVMT.PrintName = "Traitor Radar"
	ACVMT.Description = "Kill Traitor as Detective for 50 times"
	ACVMT.Category = "TTT : Master Detective"
	
	ACVMT.Order = 3
	ACVMT.Min = 0
	ACVMT.Max = 50

RegisterACVMT(ACVMT)

if SERVER then
	hook.Add("PlayerDeath","ACV " .. "PlayerDeath" .. ACVMT.LuaName,function( victim, infl, attacker)
		if victim:IsPlayer() and attacker:IsPlayer() then
			if victim:GetRole() == ROLE_TRAITOR and attacker:GetRole() == ROLE_DETECTIVE then
				attacker:ACV_Increase(ACVMT.LuaName,1)
			end
		end
	end)
end



/* ──────────────────────────────────────────────────────────────────
	25
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_TTT_MasterDetective_Win25"
	ACVMT.PrintName = "True Detective"
	ACVMT.Description = "Win 25 rounds as Detective"
	ACVMT.Category = "TTT : Master Detective"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 25

RegisterACVMT(ACVMT)

if SERVER then

	hook.Add("TTTEndRound","ACV " .. "TTTEndRound" .. ACVMT.LuaName,function(type)
	   if type == WIN_TIMELIMIT then -- Timelimit. traitor lose
			
	   elseif type == WIN_TRAITOR then

	   elseif type == WIN_INNOCENT then
			for k,v in pairs(player.GetAll()) do
				if v:Alive() and v:GetRole() == ROLE_DETECTIVE then
					v:ACV_Increase(ACVMT.LuaName,1)
				end
			end
	   else
	   
	   end
	end)

end