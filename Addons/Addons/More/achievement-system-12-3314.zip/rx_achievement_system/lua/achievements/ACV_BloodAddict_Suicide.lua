/* ──────────────────────────────────────────────────────────────────
	100
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_Suicide_100"
	ACVMT.PrintName = "Take my Head"
	ACVMT.Description = "Suicide for 100 Times!"
	ACVMT.Category = "Blood Addict"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 100

RegisterACVMT(ACVMT)

if SERVER then
	hook.Add("PlayerDeath", "ACV " .. "PlayerDeath" .. ACVMT.LuaName, function( victim, weapon, killer )
		if victim == killer then
			victim:ACV_Increase(ACVMT.LuaName,1)
		end
	end)
end



/* ──────────────────────────────────────────────────────────────────
	200
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_Suicide_200"
	ACVMT.PrintName = "Take my Body"
	ACVMT.Description = "Suicide for 200 Times!"
	ACVMT.Category = "Blood Addict"
	
	ACVMT.Order = 2
	ACVMT.Min = 0
	ACVMT.Max = 200

RegisterACVMT(ACVMT)

if SERVER then
	hook.Add("PlayerDeath", "ACV " .. "PlayerDeath" .. ACVMT.LuaName, function( victim, weapon, killer )
		if victim == killer then
			victim:ACV_Increase(ACVMT.LuaName,1)
		end
	end)
end



/* ──────────────────────────────────────────────────────────────────
	500
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_Suicide_500"
	ACVMT.PrintName = "Take my Soul"
	ACVMT.Description = "Suicide for 500 Times!"
	ACVMT.Category = "Blood Addict"
	
	ACVMT.Order = 3
	ACVMT.Min = 0
	ACVMT.Max = 500

RegisterACVMT(ACVMT)

if SERVER then
	hook.Add("PlayerDeath", "ACV " .. "PlayerDeath" .. ACVMT.LuaName, function( victim, weapon, killer )
		if victim == killer then
			victim:ACV_Increase(ACVMT.LuaName,1)
		end
	end)
end