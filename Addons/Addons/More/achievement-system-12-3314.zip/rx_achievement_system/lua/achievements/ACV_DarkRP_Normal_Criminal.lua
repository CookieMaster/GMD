/* ──────────────────────────────────────────────────────────────────
	20
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_DarkRP_Criminal_20"
	ACVMT.PrintName = "Typical Criminal 20"
	ACVMT.Description = "be arrested by cop for 20 times"
	ACVMT.Category = "DarkRP"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 20

RegisterACVMT(ACVMT)

if SERVER then

	hook.Add("playerArrested","ACV " .. "playerArrested" .. ACVMT.LuaName,function(ply)
		ply:ACV_Increase(ACVMT.LuaName,1)
	end)
	
end