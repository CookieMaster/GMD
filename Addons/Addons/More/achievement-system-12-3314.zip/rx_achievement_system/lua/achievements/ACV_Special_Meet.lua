/* ──────────────────────────────────────────────────────────────────
	RocketMania
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_Special_Meet1"
	ACVMT.PrintName = "Mr, Lua King"
	ACVMT.Description = "Play with RocketMania on this server! he also created achievement system!"
	ACVMT.Category = "Special : Get signature"

	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 1
	
	ACVMT:AddRewardText("DarkRP Money 500")

RegisterACVMT(ACVMT)

if SERVER then
	local Timer = CurTime()
	hook.Add("Think", "ACV " .. "Think" .. ACVMT.LuaName, function()
		if Timer < CurTime() then
			Timer = CurTime() + 60
			for _,rk in pairs(player.GetAll()) do
				if rk:SteamID() == "STEAM_0:1:18558423" then -- my steam unique id.
					for k,v in pairs(player.GetAll()) do
						v:ACV_Increase(ACVMT.LuaName,1)
					end
					continue
				end
			end
		end
	end)
end