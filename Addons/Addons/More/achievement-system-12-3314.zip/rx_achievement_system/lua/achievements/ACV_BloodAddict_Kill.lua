/* ──────────────────────────────────────────────────────────────────
	100
────────────────────────────────────────────────────────────────── */

local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_BA_Kill_100"
	ACVMT.PrintName = "Wanna be Killer?"
	ACVMT.Description = "Kill other people for 100 Times!"
	ACVMT.Category = "Blood Addict"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 100

RegisterACVMT(ACVMT)

if SERVER then
	hook.Add("PlayerDeath", "ACV " .. "PlayerDeath" .. ACVMT.LuaName, function( victim, weapon, killer )
		if victim != killer and killer:IsPlayer() then
			killer:ACV_Increase(ACVMT.LuaName,1)
		end
	end)
end



/* ──────────────────────────────────────────────────────────────────
	200
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_BA_Kill_200"
	ACVMT.PrintName = "I am Murder!"
	ACVMT.Description = "Kill other people for 200 Times!"
	ACVMT.Category = "Blood Addict"
	
	ACVMT.Order = 2
	ACVMT.Min = 0
	ACVMT.Max = 200

RegisterACVMT(ACVMT)

if SERVER then
	hook.Add("PlayerDeath", "ACV " .. "PlayerDeath" .. ACVMT.LuaName, function( victim, weapon, killer )
		if victim != killer and killer:IsPlayer() then
			killer:ACV_Increase(ACVMT.LuaName,1)
		end
	end)
end




/* ──────────────────────────────────────────────────────────────────
	500
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_BA_Kill_500"
	ACVMT.PrintName = "Runaway from me"
	ACVMT.Description = "Kill other people for 500 Times!"
	ACVMT.Category = "Blood Addict"
	
	ACVMT.Order = 3
	ACVMT.Min = 0
	ACVMT.Max = 500

RegisterACVMT(ACVMT)

if SERVER then
	hook.Add("PlayerDeath", "ACV " .. "PlayerDeath" .. ACVMT.LuaName, function( victim, weapon, killer )
		if victim != killer and killer:IsPlayer() then
			killer:ACV_Increase(ACVMT.LuaName,1)
		end
	end)
end