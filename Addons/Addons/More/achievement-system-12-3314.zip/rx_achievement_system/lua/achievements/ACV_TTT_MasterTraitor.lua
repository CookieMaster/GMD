/* ──────────────────────────────────────────────────────────────────
	Become - 50
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_TTT_MasterTraitor_Become50"
	ACVMT.PrintName = "Traitor Addiction"
	ACVMT.Description = "Become Traitor for 50 times"
	ACVMT.Category = "TTT : Master Traitor"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 50

RegisterACVMT(ACVMT)

if SERVER then
	local Timer = CurTime()
	hook.Add("TTTBeginRound","ACV " .. "TTTBeginRound" .. ACVMT.LuaName,function()
		for k,v in pairs(player.GetAll()) do
			if v:GetRole() == ROLE_TRAITOR then
				v:ACV_Increase(ACVMT.LuaName,1)
			end
		end
	end)
end







/* ──────────────────────────────────────────────────────────────────
	Win - 25
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_TTT_MasterTraitor_Win25"
	ACVMT.PrintName = "True Traitor"
	ACVMT.Description = "Win 25 rounds as traitor"
	ACVMT.Category = "TTT : Master Traitor"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 25

RegisterACVMT(ACVMT)

if SERVER then

	local Timer = CurTime()
	hook.Add("TTTEndRound","ACV " .. "TTTEndRound" .. ACVMT.LuaName,function(type)
	   if type == WIN_TIMELIMIT then -- Timelimit. traitor lose
			
	   elseif type == WIN_TRAITOR then
			for k,v in pairs(player.GetAll()) do
				if v:Alive() and v:GetRole() == ROLE_TRAITOR then
					v:ACV_Increase(ACVMT.LuaName,1)
				end
			end
	   elseif type == WIN_INNOCENT then
	   
	   else
	   
	   end
	end)

end


/* ──────────────────────────────────────────────────────────────────
	Win - 50
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_TTT_MasterTraitor_Win50"
	ACVMT.PrintName = "King of Traitor"
	ACVMT.Description = "Win 50 rounds as traitor"
	ACVMT.Category = "TTT : Master Traitor"
	
	ACVMT.Order = 2
	ACVMT.Min = 0
	ACVMT.Max = 50

RegisterACVMT(ACVMT)


if SERVER then

	local Timer = CurTime()
	hook.Add("TTTEndRound","ACV " .. "TTTEndRound" .. ACVMT.LuaName,function(type)
	   if type == WIN_TIMELIMIT then -- Timelimit. traitor lose
			
	   elseif type == WIN_TRAITOR then
			for k,v in pairs(player.GetAll()) do
				if v:Alive() and v:GetRole() == ROLE_TRAITOR then
					v:ACV_Increase(ACVMT.LuaName,1)
				end
			end
	   elseif type == WIN_INNOCENT then
	   
	   else
	   
	   end
	end)

end


/* ──────────────────────────────────────────────────────────────────
	Kill Innocent - 50
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_TTT_MasterTraitor_KillInnocent50"
	ACVMT.PrintName = "Anti Innocent"
	ACVMT.Description = "Kill Innocent as Traitor for 50 times"
	ACVMT.Category = "TTT : Master Traitor"
	
	ACVMT.Order = 3
	ACVMT.Min = 0
	ACVMT.Max = 50

RegisterACVMT(ACVMT)

if SERVER then
	hook.Add("PlayerDeath","ACV " .. "PlayerDeath" .. ACVMT.LuaName,function( victim, infl, attacker)
		if victim:IsPlayer() and attacker:IsPlayer() then
			if victim:GetRole() == ROLE_INNOCENT and attacker:GetRole() == ROLE_TRAITOR then
				attacker:ACV_Increase(ACVMT.LuaName,1)
			end
		end
	end)
end




/* ──────────────────────────────────────────────────────────────────
	Kill Detect - 50
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_TTT_MasterTraitor_KillDetect50"
	ACVMT.PrintName = "Detective Detective"
	ACVMT.Description = "Kill Detective as traitor for 50 times"
	ACVMT.Category = "TTT : Master Traitor"
	
	ACVMT.Order = 3
	ACVMT.Min = 0
	ACVMT.Max = 50

RegisterACVMT(ACVMT)

if SERVER then
	hook.Add("PlayerDeath","ACV " .. "PlayerDeath" .. ACVMT.LuaName,function( victim, infl, attacker)
		if victim:IsPlayer() and attacker:IsPlayer() then
			if victim:GetRole() == ROLE_DETECTIVE and attacker:GetRole() == ROLE_TRAITOR then
				attacker:ACV_Increase(ACVMT.LuaName,1)
			end
		end
	end)
end


/* ──────────────────────────────────────────────────────────────────
	Kill Detect - 50
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_TTT_MasterTraitor_Kill3Inno50"
	ACVMT.PrintName = "Innocent Killer"
	ACVMT.Description = "Kill 3 Innocent as traitor in 1 round for 50 times"
	ACVMT.Category = "TTT : Master Traitor"
	
	ACVMT.Order = 5
	ACVMT.Min = 0
	ACVMT.Max = 50

RegisterACVMT(ACVMT)

if SERVER then
	hook.Add("PlayerDeath","ACV " .. "PlayerDeath" .. ACVMT.LuaName,function( victim, infl, attacker)
		if victim:IsPlayer() and attacker:IsPlayer() then
			if victim:GetRole() == ROLE_INNOCENT and attacker:GetRole() == ROLE_TRAITOR then
				attacker.ACV_InnoKillCount = attacker.ACV_InnoKillCount or 0
				attacker.ACV_InnoKillCount = attacker.ACV_InnoKillCount + 1
				if attacker.ACV_InnoKillCount == 3 then
					attacker:ACV_Increase(ACVMT.LuaName,1)
				end
			end
		end
	end)
	hook.Add("TTTEndRound","ACV " .. "TTTEndRound" .. ACVMT.LuaName,function(type)
		for k,v in pairs(player.GetAll()) do
			v.ACV_InnoKillCount = 0
		end
	end)
end