/* ──────────────────────────────────────────────────────────────────
	1
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_Timelord_1"
	ACVMT.PrintName = "NEW BE"
	ACVMT.Description = "Stay for 1 hour on server."
	ACVMT.Category = "Time Lord"

	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 60

RegisterACVMT(ACVMT)

if SERVER then
	local Timer = CurTime()
	hook.Add("Think", "ACV " .. "Think" .. ACVMT.LuaName, function()
		if Timer < CurTime() then
			Timer = CurTime() + 60
			for k,v in pairs(player.GetAll()) do
				v:ACV_Increase(ACVMT.LuaName,1)
			end
		end
	end)
end



/* ──────────────────────────────────────────────────────────────────
	12
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_Timelord_12"
	ACVMT.PrintName = "Im here!"
	ACVMT.Description = "Stay for 12 hour on server."
	ACVMT.Category = "Time Lord"

	ACVMT.Order = 2
	ACVMT.Min = 0
	ACVMT.Max = 720 -- 12 hr = 720 min

RegisterACVMT(ACVMT)

if SERVER then
	local Timer = CurTime()
	hook.Add("Think", "ACV " .. "Think" .. ACVMT.LuaName, function()
		if Timer < CurTime() then
			Timer = CurTime() + 60
			for k,v in pairs(player.GetAll()) do
				v:ACV_Increase(ACVMT.LuaName,1)
			end
		end
	end)
end




/* ──────────────────────────────────────────────────────────────────
	24
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_Timelord_24"
	ACVMT.PrintName = "24hr = 1440 Minutes"
	ACVMT.Description = "Stay for 24 hour on server."
	ACVMT.Category = "Time Lord"

	ACVMT.Order = 3
	ACVMT.Min = 0
	ACVMT.Max = 1440

RegisterACVMT(ACVMT)

if SERVER then
	local Timer = CurTime()
	hook.Add("Think", "ACV " .. "Think" .. ACVMT.LuaName, function()
		if Timer < CurTime() then
			Timer = CurTime() + 60
			for k,v in pairs(player.GetAll()) do
				v:ACV_Increase(ACVMT.LuaName,1)
			end
		end
	end)
end