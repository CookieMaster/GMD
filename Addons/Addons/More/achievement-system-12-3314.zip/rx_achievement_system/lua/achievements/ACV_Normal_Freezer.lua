/* ──────────────────────────────────────────────────────────────────
	150
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_Normal_Freezer_150"
	ACVMT.PrintName = "Freezer X150"
	ACVMT.Description = "Freeze Stuff with physicsgun for 150 times!"
	ACVMT.Category = "Normal"
	
	ACVMT.Order = 2
	ACVMT.Min = 0
	ACVMT.Max = 150

RegisterACVMT(ACVMT)

if SERVER then
	hook.Add("OnPhysgunFreeze", "ACV " .. "OnPhysgunFreeze" .. ACVMT.LuaName, function(weapon, physobj, ent, ply)
		ply:ACV_Increase(ACVMT.LuaName,1)
	end)
end