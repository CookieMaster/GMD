/* ──────────────────────────────────────────────────────────────────
	100
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_Normal_Say_100"
	ACVMT.PrintName = "Hello?"
	ACVMT.Description = "Chat for 100 Times!"
	ACVMT.Category = "Normal"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 100

RegisterACVMT(ACVMT)

if SERVER then
	hook.Add("PlayerSay", "ACV " .. "PlayerSay" .. ACVMT.LuaName, function( ply, text, public )
		ply:ACV_Increase(ACVMT.LuaName,1)
	end)
end



/* ──────────────────────────────────────────────────────────────────
	500
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_Normal_Say_500"
	ACVMT.PrintName = "Plz hear me!!"
	ACVMT.Description = "Chat for 500 Times!"
	ACVMT.Category = "Normal"
	
	ACVMT.Order = 3
	ACVMT.Min = 0
	ACVMT.Max = 500

RegisterACVMT(ACVMT)

if SERVER then
	hook.Add("PlayerSay", "ACV " .. "PlayerSay" .. ACVMT.LuaName, function( ply, text, public )
		ply:ACV_Increase(ACVMT.LuaName,1)
	end)
end