/* ──────────────────────────────────────────────────────────────────
	100
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_TTT_Main_PlayTTT100"
	ACVMT.PrintName = "Addicted by TTT"
	ACVMT.Description = "Play 100 Rounds!"
	ACVMT.Category = "TTT"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 100

RegisterACVMT(ACVMT)

if SERVER then

	hook.Add("TTTEndRound","ACV " .. "TTTEndRound" .. ACVMT.LuaName,function(GM,type)
		for k,v in pairs(player.GetAll()) do
			v:ACV_Increase(ACVMT.LuaName,1)
		end
	end)

end