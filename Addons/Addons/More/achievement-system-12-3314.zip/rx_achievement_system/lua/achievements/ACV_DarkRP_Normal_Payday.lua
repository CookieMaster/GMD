/* ──────────────────────────────────────────────────────────────────
	50
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_DarkRP_Payday_50"
	ACVMT.PrintName = "Payday R50"
	ACVMT.Description = "Get Paid for 50 times!"
	ACVMT.Category = "DarkRP"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 50

RegisterACVMT(ACVMT)

if SERVER then

	hook.Add("PlayerGetSalary","ACV " .. "PlayerGetSalary" .. ACVMT.LuaName,function(ply,amount)
		ply:ACV_Increase(ACVMT.LuaName,1)
	end)
	hook.Add("playerGetSalary","ACV " .. "PlayerGetSalary" .. ACVMT.LuaName,function(ply,amount)
		ply:ACV_Increase(ACVMT.LuaName,1)
	end)
	
end