/* ──────────────────────────────────────────────────────────────────
	50
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_DarkRP_NewBorn_50"
	ACVMT.PrintName = "NewBorn. Age 50"
	ACVMT.Description = "Change your job for 50 times!"
	ACVMT.Category = "DarkRP"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 50

RegisterACVMT(ACVMT)

if SERVER then

	hook.Add("OnPlayerChangedTeam","ACV " .. "PlayerGetSalary" .. ACVMT.LuaName,function(ply,oldteam,newteam)
		ply:ACV_Increase(ACVMT.LuaName,1)
	end)
	
end