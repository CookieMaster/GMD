/* ──────────────────────────────────────────────────────────────────
	5
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_DarkRP_GTA_5"
	ACVMT.PrintName = "GTA 5"
	ACVMT.Description = "be warrented by cop for 5 times"
	ACVMT.Category = "DarkRP"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 5

RegisterACVMT(ACVMT)

if SERVER then

	hook.Add("PlayerWarranted","ACV " .. "PlayerWarranted" .. ACVMT.LuaName,function(ply)
		ply:ACV_Increase(ACVMT.LuaName,1)
	end)

	hook.Add("playerWarranted","ACV " .. "playerWarranted" .. ACVMT.LuaName,function(ply)
		ply:ACV_Increase(ACVMT.LuaName,1)
	end)
	
end