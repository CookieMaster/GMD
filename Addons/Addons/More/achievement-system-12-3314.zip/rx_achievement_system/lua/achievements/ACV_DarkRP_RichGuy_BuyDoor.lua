/* ──────────────────────────────────────────────────────────────────
	100
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_DarkRP_RichGuy_BuyDoor100"
	ACVMT.PrintName = "Door Hunter"
	ACVMT.Description = "Buy Door for 100 Times!"
	ACVMT.Category = "DarkRP : Rich Guy"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 100

RegisterACVMT(ACVMT)

if SERVER then

	hook.Add("PlayerBoughtDoor","ACV " .. "PlayerBoughtDoor" .. ACVMT.LuaName,function(ply,entity,cost)
		ply:ACV_Increase(ACVMT.LuaName,1)
	end)
	
	hook.Add("playerBoughtDoor","ACV " .. "playerBoughtDoor" .. ACVMT.LuaName,function(ply,entity,cost)
		ply:ACV_Increase(ACVMT.LuaName,1)
	end)

end



/* ──────────────────────────────────────────────────────────────────
	250
────────────────────────────────────────────────────────────────── */
local ACVMT = ACV_CreateACVStruct()
	ACVMT.LuaName = "ACV_DarkRP_RichGuy_BuyDoor250"
	ACVMT.PrintName = "House Hunter"
	ACVMT.Description = "Buy Door for 250 Times!"
	ACVMT.Category = "DarkRP : Rich Guy"
	
	ACVMT.Order = 1
	ACVMT.Min = 0
	ACVMT.Max = 250

RegisterACVMT(ACVMT)

if SERVER then

	hook.Add("PlayerBoughtDoor","ACV " .. "PlayerBoughtDoor" .. ACVMT.LuaName,function(ply,entity,cost)
		ply:ACV_Increase(ACVMT.LuaName,1)
	end)
	
	hook.Add("playerBoughtDoor","ACV " .. "playerBoughtDoor" .. ACVMT.LuaName,function(ply,entity,cost)
		ply:ACV_Increase(ACVMT.LuaName,1)
	end)

end