--[[ Experience System ]]--
	--Coder: Seagull ³
	--Hire: CoderHire
--[[ Experience System ]]--

--[[ Include ]]--
	include( 'autorun/sh_Exp.lua' )
	
/*

	This one was requested buy those who purchased it.
	You gain Experience( Defined Below ) for killing the Correct role
	You gain Experience( Defined Below ) for winning the round

*/

--[[ Variable Exp. ]]--
	local expGive = 500 -- ( CHANGE ME )
	local expGiveWin = 3000 -- ( CHANGE ME ) -- Don't use 2500, it's buggy for some reason
	local expTTT = true -- ( true = TTT Funcs on | false = TTT Funcs off )
	
--[[ On Kill Correct ]]--
	hook.Add( 'PlayerDeath', 'onPlayerDeath', function( victim, inflictor, attacker )
	
		if ( IsValid( attacker ) && attacker:IsPlayer() && expTTT && GAMEMODE.round_state == ROUND_ACTIVE ) then
	
			if ( victim:Nick() == attacker:Nick() ) then
				
				--Do Nothing for Suicide!
				
			elseif ( victim:GetRoleString() == 'innocent' && attacker:GetRoleString() == 'traitor' ) then
			
				attacker:AddExp( expGive )
				umsg.Start( 'chatMessage', attacker )
				umsg.String( '[Exp.]' )
				umsg.String( '+'..expGive..' Experience!' )
				umsg.End()
			
			elseif ( victim:GetRoleString() == 'detective' && attacker:GetRoleString() == 'traitor' ) then
			
				attacker:AddExp( expGive * 2 )
				umsg.Start( 'chatMessage', attacker )
				umsg.String( '[Exp.]' )
				umsg.String( '+'..expGive..' Experience!' )
				umsg.End()
			
			elseif ( victim:GetRoleString() == 'traitor' && attacker:GetRoleString() == 'innocent' ) then
			
				attacker:AddExp( expGive )
				umsg.Start( 'chatMessage', attacker )
				umsg.String( '[Exp.]' )
				umsg.String( '+'..expGive..' Experience!' )
				umsg.End()
			
			elseif ( victim:GetRoleString() == 'traitor' && attacker:GetRoleString() == 'detective' ) then
			
				attacker:AddExp( expGive * 2 )
				umsg.Start( 'chatMessage', attacker )
				umsg.String( '[Exp.]' )
				umsg.String( '+'..expGive..' Experience!' )
				umsg.End()
			
			end
		
		else
		
			victim:ChatPrint( 'World Kill' )
			
		end
	
	end )
	
--[[ Exp. On Winning Round! ]]--
	hook.Add( 'TTTEndRound', 'onRoundEnd', function( result )
	
		if ( expTTT ) then
		
			for k, v in pairs( player.GetAll() ) do
			
				if ( v:GetRoleString() == 'innocent' && result == WIN_INNOCENT ) then
				
					v:AddExp( expGiveWin )
					umsg.Start( 'chatMessage', v )
					umsg.String( '[Exp.]' )
					umsg.String( '+'..expGiveWin..' Experience for winning the round!' )
					umsg.End()
					v:EmitSound( 'levelup.wav' )
				
				elseif ( v:GetRoleString() == 'detective' && result == WIN_INNOCENT ) then
				
					v:AddExp( expGiveWin )
					umsg.Start( 'chatMessage', v )
					umsg.String( '[Exp.]' )
					umsg.String( '+'..expGiveWin..' Experience for winning the round!' )
					umsg.End()
					v:EmitSound( 'levelup.wav' )
				
				elseif ( v:GetRoleString() == 'traitor' && result == WIN_TRAITOR ) then
				
					v:AddExp( expGiveWin )
					umsg.Start( 'chatMessage', v )
					umsg.String( '[Exp.]' )
					umsg.String( '+'..expGiveWin..' Experience for winning the round!' )
					umsg.End()
					v:EmitSound( 'levelup.wav' )
				
				end
			
			end
		
		end
		
	end )