--[[ Experience System ]]--
	--Coder: Seagull ³
	--Hire: CoderHire
--[[ Experience System ]]--

local meta = FindMetaTable( 'Player' )

--[[ EXP to Next LVL ]]--
	function meta:ExpNeeded()
	
		local lvl = self:GetNWInt( 'LVL' )
		
		return tonumber( 1250 + ( lvl * 250 ) )
	
	end

--[[ Retrieve Player Stats ]]--
	function meta:GetStats()
		
		local steamID = self:SteamID()
	
		local exp = sql.QueryValue( "SELECT exp FROM info WHERE steamid = '"..steamID.."'" )
		local lvl = sql.QueryValue( "SELECT lvl FROM info WHERE steamid = '"..steamID.."'" )
			self:SetNWInt( 'EXP', exp )
			self:SetNWInt( 'LVL', lvl )
	
	end
 
--[[ Saving Player Stats ]]--
	function meta:SaveStats()
	
		local steamID = self:SteamID()
		local exp = self:GetNWInt( 'EXP' )
		local lvl = self:GetNWInt( 'LVL' )
		
		sql.Query( "UPDATE info SET exp = "..exp..", lvl = "..lvl.." WHERE steamid = '"..steamID.."'" )
	
	end
 
--[[ Table Exists? ]]--
	function Table_Exists()
	
		if ( sql.TableExists( 'info' ) ) then
			
			MsgN( '[Exp.] Table exists and is ready to continue!' )
			
		elseif ( !sql.TableExists( 'info' ) ) then
		
			local query = "CREATE TABLE info ( steamid varchar(20), exp int, lvl int )"
			local result = sql.Query( query )
			
			if ( sql.TableExists( 'info' ) ) then
				
				MsgN( '[Exp.] Table has been created!' )
			
			else
			
				MsgN( '[Exp.] Table creation error: '..sql.LastError( result ) )
				
			end
		
		end
		
	
	end
	
--[[ Creating a new Player ]]--
	function CreatePlayer( ply )
	
		local steamID = ply:SteamID()
		
		sql.Query( "INSERT INTO info (`steamid`, `exp`, `lvl`) VALUES ('"..steamID.."', '0', '0')" )
	
	end
 
--[[ Do they exist? ]]--
	function meta:Exists()
	
		local steamID = self:SteamID()
		local result = sql.Query( "SELECT steamid, exp, lvl FROM info WHERE steamid = '"..steamID.."'" )
		
		if ( result ) then
			
			self:GetStats()
			
		else
		
			CreatePlayer( self )
		
		end
	
	end
 
--[[ Adding Experience ]]--
	function meta:AddExp( amt )
	
		local exp = self:GetNWInt( 'EXP' )
		
		self:SetNWInt( 'EXP', exp + amt )
		
		if ( self:GetNWInt( 'EXP' ) >= self:ExpNeeded() ) then
		
			self:LevelUp( 1 )
		
		end
	
	end
	
--[[ Setting Experience ]]--
	function meta:SetExp( amt )
			
		self:SetNWInt( 'EXP', amt )
	
	end
	
--[[ Adding Levels ]]--
	function meta:LevelUp( amt )
	
		local lvl = self:GetNWInt( 'LVL' )
		
		self:Party()
		self:SetExp( 0 )
		self:SetNWInt( 'LVL', lvl + amt )
		self:SaveStats()
		
			umsg.Start( 'chatMessage', self )
			umsg.String( '[Exp.]' )
			umsg.String( 'Level Up!' )
			umsg.End()
	
		self:SetWalkSpeed( 250 + ( lvl*20 ) )
	
	end
	
if ( SERVER ) then
	resource.AddFile( "materials/sprites/sparkle.vmt" )
	resource.AddFile( "sound/levelup.wav" )
end
	
--[[ Party Effects on Level ]]--
	function meta:Party()
	
		local Effect = EffectData()
			Effect:SetOrigin( self:GetPos() + Vector(0, 0, 72) )
			Effect:SetEntity( self )
			util.Effect("achievement_awarded", Effect, true, true)
			util.Effect("achievement_awarded", Effect, true, true)
			util.Effect("achievement_awarded", Effect, true, true)
			
		self:EmitSound( 'levelup.wav' )
	
	end
	