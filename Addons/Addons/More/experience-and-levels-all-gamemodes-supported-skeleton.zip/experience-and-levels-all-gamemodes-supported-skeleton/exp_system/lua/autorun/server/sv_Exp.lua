--[[ Experience System ]]--
	--Coder: Seagull ³
	--Hire: CoderHire
--[[ Experience System ]]--

/*
	Please note this. Incase you did not see it in the description of the purchase:
		This code is a BASE or SKELETON. It is meant to be built upon, as this
		provides the raw functions and accessories needed to start off.
*/

resource.AddFile( 'materials/top.png' )
resource.AddFile( 'materials/bar.png' )

--[[ Add Lua Files ]]--
	AddCSLuaFile( 'autorun/sh_Exp.lua' )
	AddCSLuaFile( '../autorun/cl_Exp.lua' )
	
--[[ Include ]]--
	include( 'autorun/sh_Exp.lua' )
	
--[[ Creation on Spawn ]]--
	hook.Add( "Initialize", "InitializeTables", function()
	
		Table_Exists()
		
		timer.Create( 'saveStatsPls', 60, 0, function()
			for k, v in pairs( player.GetAll() ) do
			
				v:SaveStats()
			
			end
		end )
	
	end )

	hook.Add( 'PlayerInitialSpawn', 'createPlayerData', function( ply )
	
		timer.Simple( 2, function()
			ply:Exists()
		end )
	
	end )
	
--[[ Saving Data on Disconnect ]]--
	hook.Add( 'PlayerDisconnected', 'onDisconnect', function( ply )
	
		ply:SaveStats()
	
	end )
	
--[[ Admin Cheating! ]]--
	hook.Add( 'PlayerSay', 'cheatLevel', function( ply, text, isteam )
	
		text = string.lower( text )
		
		if ( ply:IsUserGroup( 'superadmin' ) ) then
		
			if ( string.sub( text, 1, 9 ) == "!level up" ) then
			
				ply:LevelUp( 1 )
			
			end
			
		end
	
	end )
	hook.Add( 'PlayerSay', 'cheatXP', function( ply, text, isteam )
	
		text = string.lower( text )
		
		if ( ply:IsUserGroup( 'superadmin' ) ) then
		
			if ( string.sub( text, 1, 4 ) == "!exp" ) then
			
				ply:AddExp( 250 )
			
			end
			
		end
	
	end )