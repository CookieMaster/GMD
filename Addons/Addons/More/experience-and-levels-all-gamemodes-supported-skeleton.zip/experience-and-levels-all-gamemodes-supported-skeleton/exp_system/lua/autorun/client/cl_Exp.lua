--[[ Experience System ]]--
	--Coder: Seagull ³
	--Hire: CoderHire
--[[ Experience System ]]--

--[[ Include ]]--
	include( 'autorun/sh_Exp.lua' )
	
surface.CreateFont( 'big', {

	font = 'Trebuchet18',
	size = 28,
	weight = 600

} )	
surface.CreateFont( 'big2', {

	font = 'Trebuchet18',
	size = 32,
	weight = 600

} )	

local bar = Material( 'bar.png' )
local top = Material( 'top.png' )
local grad = surface.GetTextureID( 'gui/gradient' )

--[[ Draw DEBUG Data ]]--
	hook.Add( 'HUDPaint', 'displayInfo', function()
	
		local exp = tonumber( LocalPlayer():GetNWInt( 'EXP' ) )
		local lvl = tonumber( LocalPlayer():GetNWInt( 'LVL' ) )
		local need = tonumber( LocalPlayer():ExpNeeded() )
		local dif = need-exp
		
		local len = 896
		len = math.Clamp( 896* ( ( exp - lvl ) / ( need - lvl ) ), 0, 896 )
		
		surface.SetDrawColor( 255, 255, 255 )
		
		surface.SetMaterial( bar )
		surface.DrawTexturedRect( ScrW()/2-450, ScrH()-38, 900, 28 )
		
		draw.RoundedBox( 0, ScrW()/2-450+2, ScrH()-34, len, 20, Color( 125, 175, 80 ) )
		
		surface.SetDrawColor( 255, 255, 255 )
		surface.SetMaterial( top )
		surface.DrawTexturedRect( ScrW()/2-450, ScrH()-38, 900, 28 )
	
		draw.SimpleText( lvl, 'big', ScrW()/2+2, ScrH()-65+2, Color( 0, 0, 0 ), TEXT_ALIGN_CENTER )
		draw.SimpleText( lvl, 'big', ScrW()/2, ScrH()-65, Color( 125, 175, 80 ), TEXT_ALIGN_CENTER )
		
		draw.SimpleText( exp..'/'..need, 'TargetID', ScrW()/2, ScrH()-24, Color( 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
		
	end )

--[[ Chat Printing Functions ]]--
	usermessage.Hook( 'chatMessage', function( data )
	
		local prefix = data:ReadString()
		local text = data:ReadString()
		
		chat.AddText( Color( 220, 108, 108 ), prefix, Color( 255, 255, 255 ), ' '..text )
	
	end )
