Thanks for purchasing SteamGroup Rewards!
-----------------------------------------
There's not much here, since SteamGroup Rewards was built from the ground up to be super configurable and easy to customize!

Installation
---------------
Unzip the download, and put SteamGroup Rewards into the addons folder
If you use FastDL on your server, add the materials/resource/sound folders to your FastDL directory
Resources inside the addon are added automatically

Configuration
--------------
Configure core settings, theme (colors, text, logo etc) and rewards.  -- lua/sh_rewardsconfig.lua

WebService Files (Optional but recommended)
--------------
To run the steam group web service you need a PHP5 compatible web server.
Put the groupcheck.php file on your web server and update the API URL config in lua/sh_rewardsconfig.lua
e.g.
--REWARDS.Settings.APIURL = "http://ourcommunity.com/groupcheck.php"
Default
--REWARDS.Settings.APIURL = "http://api.friendlyplayers.com/groupcheck.php"

Need more help?
Steam: http://steamcommunity.com/id/chuteuk/
Skype: Chuteuk