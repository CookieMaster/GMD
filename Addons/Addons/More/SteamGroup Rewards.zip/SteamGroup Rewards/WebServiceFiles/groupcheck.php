<?php
error_reporting(0);
//ini_set('max_execution_time', 1);
if(isset($_POST['steam']) && isset($_POST['group']) && isset($_POST['key'])) {

$apikey = ($_POST['key']);
if(!$apikey == "erjh3590232") { die('apierror'); }
$groupname = ($_POST['group']);
$steamid = ($_POST['steam']);
$ran = rand();
$steamurl = "http://steamcommunity.com/groups/".$groupname."/memberslistxml/?xml=1&r=" . $ran;
$result = CheckUserInSteamGroup($steamurl, $steamid, $ran);

error_log('Check: ' . $steamid . ' in '. $groupname . ' ' . (string)$result);
echo ($result) ? ';true;' : ';false;';
}
else
{
echo "errornotset";
}

function CheckUserInSteamGroup($steamurl, $steamid, $ran)
{
	$groupData = simplexml_load_file($steamurl,'SimpleXMLElement',LIBXML_NOWARNING);
	if (!$groupData) { die('steamerror'); }
	$groupMembers = $groupData->members;
	$found = false;
	foreach($groupMembers->steamID64 as $member)
	{
		if ($member == $steamid) { $found = true; break; }
	}
	if ($found == true) { return true; }
	if($groupData->nextPageLink)
	{	
		$url = (string)$groupData->nextPageLink . "&r=" . $ran;
		$found = CheckUserInSteamGroup($url, $steamid, $ran);
	}
	return $found;
}


?>