LibK = {}
LibK.Debug = true
LibK.LogLevel = 4 --Requires Debug
LibK.LogSQL = true