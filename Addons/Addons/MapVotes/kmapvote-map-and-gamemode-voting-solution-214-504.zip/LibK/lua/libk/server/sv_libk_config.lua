LibK.SQL = {}
--SQL Configuration
LibK.SQL.UseMysql = false			--Set to true to use MSQL, false will use SQLite(sv.db)
--MySQL Settings
LibK.SQL.Host = "localhost"
LibK.SQL.Port = 3306
LibK.SQL.User = "gmod"
LibK.SQL.Password = "gmod"
LibK.SQL.Database = "test"