if not MAPVOTE.ShowHUDHint then
	return
end

hook.Add( "HUDPaint", "DrawShit", function( )
	
end )