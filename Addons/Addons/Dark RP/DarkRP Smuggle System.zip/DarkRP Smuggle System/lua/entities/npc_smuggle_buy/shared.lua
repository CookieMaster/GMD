ENT.Base = "base_ai" 
ENT.Type = "ai"
ENT.PrintName = "Property NPC"
ENT.Author = "Crap-Head"