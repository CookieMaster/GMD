ENT.Type 		= "anim"
ENT.Base 		= "base_anim"

ENT.PrintName		= "Smuggle Item"
ENT.Author			= "Crap-Head"
ENT.Contact			= "None"
ENT.Purpose			= "None"
ENT.Instructions	= "None"
