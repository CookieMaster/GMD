ENT.Type = "anim"

ENT.PrintName		= "NPC Indicator"
ENT.Author			= "Crap-Head"

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
