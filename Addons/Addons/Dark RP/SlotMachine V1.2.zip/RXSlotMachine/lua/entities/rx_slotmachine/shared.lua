ENT.Category	= "RocketMania's"
ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName	= "Slot Machine"
ENT.Author	= "RocketMania"
ENT.Contact	= ""
ENT.Purpose	= ""
ENT.Instructions= ""
ENT.Spawnable	= true
ENT.AdminSpawnable = true

if SERVER then
	function ENT:Use(user)
		self:Bet(user)
	end
	function ENT:Bet(ply)
		if self.Betting then return end
		if ply:SM_GetPlayerMoneyM() < SlotMachine_Adjust.BetPrice then return end
		ply:SM_AddPlayerMoneyM(-SlotMachine_Adjust.BetPrice)
		
		self.Betting = ply
		self:EmitSound("ambient/levels/labs/coinslot1.wav")
		
		self:SetDTInt(1,0)
		self:SetDTInt(2,0)
		self:SetDTInt(3,0)
		
		// Check Result.
			self.Success = false
			-- Success.
			if math.random(1,100) <= SlotMachine_Adjust.WinRate then
				self.Success = true
			else -- fail
			
			end
		
			local function GetPriceNum()
				for Num,DB in pairs(SlotMachine_Adjust.Slots) do
					if math.random(1,100) <= DB.Rate then
						return Num
					end
				end
				return GetPriceNum()
			end
			
			local function Generate_non_win_value()
				local V1 = math.random(1,#SlotMachine_Adjust.Slots)
				local V2 = math.random(1,#SlotMachine_Adjust.Slots)
				local V3 = math.random(1,#SlotMachine_Adjust.Slots)
				if V1 == V2 and V2 == V3 then
					return Generate_non_win_value()
				else
					return V1,V2,V3
				end
			end
		
			local Result = {}
			if self.Success then
				local ResultK = GetPriceNum()
				Result[1] = ResultK
				Result[2] = ResultK
				Result[3] = ResultK
			else
				local V1,V2,V3 = Generate_non_win_value()
				Result[1] = V1
				Result[2] = V2
				Result[3] = V3
			end
		for k=1,3 do
			timer.Simple(k,function()
				if self and self:IsValid() then
					self:SetDTInt(k,Result[k])
					if k == 3 then
						self:CheckResult()
					end
				end
			end)
		end
	end
	function ENT:CheckResult()
		local V1,V2,V3 = self:GetDTInt(1),self:GetDTInt(2),self:GetDTInt(3)
		if V1 == V2 and V2 == V3 then
			if self.Betting and self.Betting:IsValid() then
				self.Betting:SM_AddPlayerMoneyM(SlotMachine_Adjust.Slots[V1].Price)
				self.Betting:SM_Notify("You win! you got $".. SlotMachine_Adjust.Slots[V1].Price.. " dollar!")
			end
		end
		self.Betting = false
	end

end