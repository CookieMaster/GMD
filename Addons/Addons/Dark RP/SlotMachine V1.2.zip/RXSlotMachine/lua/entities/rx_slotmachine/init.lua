AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )

include('shared.lua')

function ENT:Initialize( )
	self.Entity:SetModel("models/props_borealis/bluebarrel001.mdl")
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_NONE)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	
	local Model = ents.Create("prop_physics")
	Model:SetPos(self:GetPos()+self:GetUp()*-27)
	Model:SetModel("models/props_lab/eyescanner.mdl")
	Model:SetAngles(self:GetAngles())
	Model:SetParent(self)
	Model:SetModelScale( self:GetModelScale() * 4,0)
	
	self:DrawShadow(false)
	
	self:SetUseType( SIMPLE_USE )
	
	self:SetDTInt(1,1)
	self:SetDTInt(2,1)
	self:SetDTInt(3,1)
	

	
	------ For DarkRP : Not to server to remove atm when you leave the server
	timer.Simple(1,function()
		if self and self:IsValid() then
			self.SID = nil
			self.FPPOwnerID = nil
		end
	end)
	-------------------------------------------------------------
end

function ENT:PhysgunPickup(ply) -- for DarkRP : Allows Owner can move ATM
	if ply:GetNWString("usergroup") == "owner" or ply:GetNWString("usergroup") == "superadmin" then 
		return true
	end
end

function ENT:CanTool(ply, trace, mode) -- for DarkRP : Allows Only Owner to remove ATM. 
	if ply:GetNWString("usergroup") == "owner" or ply:GetNWString("usergroup") == "superadmin" then 
		return true 
	else
		return false
	end
end