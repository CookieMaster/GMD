local GMD = SlotMachine_Adjust.Gamemode or 1
local meta = FindMetaTable("Player");

function meta:SM_GetPlayerMoneyM()
	if GMD == 1 then -- 1 for DarkRP
		return self:getDarkRPVar("money")
	end
end
if SERVER then
	function meta:SM_AddPlayerMoneyM(int)
		if GMD == 1 then  -- 1 for DarkRP
			self:AddMoney(int)
		end
	end
	function meta:SM_Notify(text)
		if GMD == 1 then  -- 1 for DarkRP
			GAMEMODE:Notify(self, 1, 4, text)
		end
	end
end
