	
	--[[
		Do not edit any of these settings. These are only meta settings, giving a default and creating ingame panels.
		Use the ingame configuration panel to change these settings.
		Type zones into console, followed by "Open configuration panel"
	]]
	
	DelMods.zones:AddConfigMeta("length", "Greet time", "How long in seconds the greet lasts", "greet", 3, nil, true)
	DelMods.zones:AddConfigMeta("greet_delay", "Greet delay", "Amount of seconds before a player can be greeted again", "greet", 5, nil, true)
	DelMods.zones:AddConfigMeta("fadein", "Fade in", "The time it takes before it slows down (and fade in), in percent", "greet", .15, nil, true)
	DelMods.zones:AddConfigMeta("fadeout", "Fade out", "When it should start to fade out/accelerate, in percent", "greet", .85, nil, true)
	DelMods.zones:AddConfigMeta("startendoffset", "Fade offset", "How far off its position it should start sliding in from", "greet", 300, nil, true)
	DelMods.zones:AddConfigMeta("startendoffsetmid", "Fade offset mid", "How far off its position it should go slow", "greet", 30, nil, true)
	DelMods.zones:AddConfigMeta("border", "Border", "How big the border around the text is", "greet", 5, nil, true)
	DelMods.zones:AddConfigMeta("screenY", "Top offset", "Distance from top of screen", "greet", 100, nil, true)
	DelMods.zones:AddConfigMeta("topbgcolor", "Top bar bg color", "Color of upper box", "greet", Color(0, 0, 0, 200), nil, true)
	DelMods.zones:AddConfigMeta("toptxtcolor", "Top bar txt color", "Color of upper text", "greet", Color(255, 255, 255), nil, true)
	DelMods.zones:AddConfigMeta("toptxtfont", "Top txt font", "Font settings upper text", "greet", {font = "Arial Black", size = 60}, nil, true)
	DelMods.zones:AddConfigMeta("botbgcolor", "Bot bar bg color", "Color of lower box", "greet", Color(0, 0, 0, 200), nil, true)
	DelMods.zones:AddConfigMeta("bottxtcolor", "Bot txt color", "Color of lower text", "greet", Color(255, 255, 255), nil, true)
	DelMods.zones:AddConfigMeta("bottxtfont", "Bot txt font", "Font settings lower text", "greet", {font = "Arial Black", size = 60}, nil, true)
	
	DelMods.zones:AddConfigMeta("exittitle", "Exit title", "Text shown when player leaves the zone", "greet", "", nil, true)
	DelMods.zones:AddConfigMeta("exitsubtitle", "Exit subtitle", "Text shown when player leaves the zone", "greet", "", nil, true)