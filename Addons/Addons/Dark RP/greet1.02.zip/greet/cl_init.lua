
	local settings = {}
	local zonegreetlast = -1
	local zonegreetent = NULL

	function DelMods.zoneTable:GreetPlayer(title, subtitle)
		if not title and not subtitle then return end
		if tostring(title):len() == 0 and tostring(subtitle):len() == 0 then return end
		zonegreetent = self
		zonegreetlast = CurTime()
		settings = { -- set up local cache of settings
			length = zonegreetent:GetConfig("greet", "length"),
			fadein = zonegreetent:GetConfig("greet", "fadein"),
			fadeout = zonegreetent:GetConfig("greet", "fadeout"),
			startendoffset = zonegreetent:GetConfig("greet", "startendoffset"),
			startendoffsetmid = zonegreetent:GetConfig("greet", "startendoffsetmid"),
			border = zonegreetent:GetConfig("greet", "border"),
			screenY = zonegreetent:GetConfig("greet", "screenY"),
			topbgcolor = zonegreetent:GetConfig("greet", "topbgcolor"),
			toptxtcolor = zonegreetent:GetConfig("greet", "toptxtcolor"),
			toptxtfont = zonegreetent:GetConfig("greet", "toptxtfont"),
			botbgcolor = zonegreetent:GetConfig("greet", "botbgcolor"),
			bottxtcolor = zonegreetent:GetConfig("greet", "bottxtcolor"),
			bottxtfont = zonegreetent:GetConfig("greet", "bottxtfont"),
			name = title or "",
			subname = subtitle or "",
		}
	end

	hook.Add("zone.PlayerEnteredZone", "zone.greet.PlayerEnteredZone", function(zone, ply)
		if zone:IsZoneType("greet") then
			if ply.zoneLastGreeted and ply.zoneLastGreeted[zone:EntIndex()] and ply.zoneLastGreeted[zone:EntIndex()] + zone:GetConfig("greet", "greet_delay") >= CurTime() then return end
			zone:GreetPlayer(zone:GetZoneTitle(), zone:GetZoneSubTitle())
		end
	end)
	
	hook.Add("zone.PlayerLeftZone", "zone.greet.PlayerLeftZone", function(zone, ply)
		if zone:IsZoneType("greet") or ply.zoneLastGreeted then
			ply.zoneLastGreeted = ply.zoneLastGreeted or {}
			if ply.zoneLastGreeted and ply.zoneLastGreeted[zone:EntIndex()] and ply.zoneLastGreeted[zone:EntIndex()] + zone:GetConfig("greet", "greet_delay") >= CurTime() then return end
			zone:GreetPlayer(zone:GetConfig("greet", "exittitle"), zone:GetConfig("greet", "exitsubtitle"))
			ply.zoneLastGreeted[zone:EntIndex()] = CurTime()
		end
	end)

	hook.Add("HUDPaint", "zone.greet.HUDPaint", function()
		if zonegreetlast < 0 then return end
		if not IsValid(zonegreetent) then return end
		
		// Percentage calc
		local percentdone = ((CurTime() - zonegreetlast) / settings.length)
		local midpercentdone = 0
		if percentdone > 1 then return end
		local fadeprocess = 1
		local posoffset = 0
		if percentdone < settings.fadein then
			fadeprocess = percentdone / settings.fadein
			posoffset = settings.startendoffsetmid + (settings.startendoffset * (1 - fadeprocess))
		elseif percentdone > settings.fadeout then
			fadeprocess = (1 - percentdone) / (1 - settings.fadeout)
			posoffset = -settings.startendoffsetmid + (settings.startendoffset * (-1 + fadeprocess))
		else
			midpercentdone = (percentdone - settings.fadein) / (settings.fadeout - settings.fadein)
			posoffset = settings.startendoffsetmid * -((midpercentdone - 0.5)*2)
		end
		
		// Reset texture
		surface.SetTexture(0)
		
		// Top bar
		surface.SetFont(DelMods.getFont(zonegreetent:GetConfig("greet", "toptxtfont")))
		
		local widthname, heightname = surface.GetTextSize(settings.name)
		local namex, namey = (ScrW() / 2) - 100 - (widthname / 2) - posoffset, 100
		surface.SetTextPos( namex, namey )
		
		local poly_name_background = {
			{x = namex - settings.border * 15, y = namey - settings.border}, // Upper left corner
			{x = namex, y = namey + heightname + settings.border}, // Bottom left corner
			{x = namex + widthname + settings.border * 15, y = namey + heightname + settings.border}, // Right bottom corner
			{x = namex + widthname, y = namey - settings.border} // Upper left corner
		}
			
		if settings.name:len() > 0 then
			surface.SetDrawColor(Color(settings.topbgcolor.r, settings.topbgcolor.g, settings.topbgcolor.b, math.Round(settings.topbgcolor.a * math.abs(fadeprocess))))
			surface.DrawPoly(poly_name_background)
			surface.SetTextColor(Color(settings.toptxtcolor.r, settings.toptxtcolor.g, settings.toptxtcolor.b, math.Round(settings.toptxtcolor.a * math.abs(fadeprocess))))
			surface.DrawText(settings.name)
		end
		
		// Bot bar
		if settings.subname:len() > 0 then
			surface.SetFont(DelMods.getFont(zonegreetent:GetConfig("greet", "bottxtfont")))
			
			local widthsubname, heightsubname = surface.GetTextSize(settings.subname)
			local subnamex, subnamey = (ScrW() / 2) + 100 - (widthsubname / 2) + posoffset, namey + heightname + (settings.border * 3)
			surface.SetTextPos( subnamex, subnamey )
			
			local poly_subname_background = {
				{x = subnamex - settings.border * 15, y = subnamey - settings.border}, // Upper left corner
				{x = subnamex, y = subnamey + heightsubname + settings.border}, // Bottom left corner
				{x = subnamex + widthsubname + settings.border * 15, y = subnamey + heightsubname + settings.border}, // Right bottom corner
				{x = subnamex + widthsubname, y = subnamey - settings.border} // Upper left corner
			}
			
			surface.SetDrawColor(Color(settings.botbgcolor.r, settings.botbgcolor.g, settings.botbgcolor.b, settings.botbgcolor.a * fadeprocess))
			surface.DrawPoly(poly_subname_background)
			surface.SetTextColor(Color(settings.bottxtcolor.r, settings.bottxtcolor.g, settings.bottxtcolor.b, settings.bottxtcolor.a * fadeprocess))
			surface.DrawText(settings.subname)
		end
	end)


local function zoneSplash (um)
	local zone, text = um:ReadEntity(), um:ReadString()
	if IsValid(zone) then
		zone:GreetPlayer(text)
	end
end
usermessage.Hook("zone.greet.splash", zoneSplash)