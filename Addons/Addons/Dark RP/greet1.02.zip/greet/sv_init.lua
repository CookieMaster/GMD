
	function DelMods.zoneTable:GreetPlayer(ply, title, subtitle)
		umsg.Start("zone.greet.splash", ply)
			umsg.Entity(self)
			umsg.String(title and title or "")
			umsg.String(subtitle and subtitle or "")
		umsg.End()
	end