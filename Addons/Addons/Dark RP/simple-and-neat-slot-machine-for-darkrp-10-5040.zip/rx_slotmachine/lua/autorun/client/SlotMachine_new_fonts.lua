
surface.CreateFont( "SM_TEXT",{font = "Courier New",size = 35,weight = 700,outline = true})
surface.CreateFont( "SM_PriceList",{font = "Tahoma",size = 28,weight = 700,outline = true})
surface.CreateFont( "SM_CoreText",{font = "Courier New",size = 60,weight = 700,outline = true})