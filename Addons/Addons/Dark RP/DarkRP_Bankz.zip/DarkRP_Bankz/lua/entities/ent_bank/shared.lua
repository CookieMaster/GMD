ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "BankATM"
ENT.Author = "Kunit"
ENT.Spawnable = false
ENT.AdminSpawnable = false
