include( 'shared.lua' )
 
ENT.RenderGroup = RENDERGROUP_BOTH
 ROCKAMT = 0
 
function ENT:Draw( )
	local ply = LocalPlayer()
    --self.Entity:DrawModel( )
	local pos = self:GetPos()
	pos:Add(self:GetForward() * 3)
	pos:Add(Vector(0,0,30))
	--pos:Add(Vector(25,-25,50))
	local mon = 0
	if(ply.KunitB != nil and ply.KunitB["BankCash"] != nil) then mon = ply.KunitB["BankCash"] end
	
	local ang = self:GetAngles()
	local addang = Angle(0, 90, 90)
	local newang = Angle(ang.p + addang.p,ang.y + addang.y,ang.r + addang.r)
	
	cam.Start3D2D( pos, newang, 0.1 )
			draw.RoundedBox( 2, -75, 0, 150, 20, Color( 0, 0, 0, 150 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			draw.RoundedBox( 2, -50, 120, 100, 100, Color( 0, 0, 0, 250 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			draw.DrawText("A. T. M.", "TargetID", 0, 0, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			draw.DrawText("Balance: $"..mon, "Default", -40, 130, Color(255, 255, 255, 255))
	cam.End3D2D()
 
	if(self.MadeEffectATM == nil) then
		self.MadeEffectATM = 1
		
		local effect = ClientsideModel("models/props_lab/eyescanner.mdl", RENDERGROUP_OPAQUE)
		effect:SetPos(self:GetPos())
		effect:SetParent(self)
		effect:Spawn()
		self.ATMEffect = effect
	end
end
