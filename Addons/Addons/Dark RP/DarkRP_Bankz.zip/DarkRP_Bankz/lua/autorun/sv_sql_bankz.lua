
function Kun_BankSpawn( ply )
 	resulta = sql.Query( "SELECT Steam FROM KunitB_Bank WHERE Steam = '"..ply:SteamID().."'" )
	if (resulta == NULL or resulta == nil or resulta == "" or resulta == false) then KunitB_SQL_NewPlayer(ply) end
	if(ply.KunitB == nil) then
		KunitB_SQL_LoadPlayerValues(ply)
	end
end
hook.Add("PlayerSpawn","Kun_BankSpawn",Kun_BankSpawn)

function KunitB_SQL_CheckIfTablesExist()
	for k,v in pairs(KunitB.SQL_Tables) do
		if (sql.TableExists("KunitB_"..v.Name)) then
			print("KunitBData Initialized - Tables Checked and all exist!")
		else
			if (!sql.TableExists("KunitB_"..v.Name)) then 
				sql.Query("CREATE TABLE KunitB_"..v.Name.." ( Steam varchar(255) )")
			end
		end
	end
	
	KunitB_SQL_UpdateTableColums()
end

function KunitB_SQL_UpdateTableColums()
	for k,v in pairs(KunitB.SQL_Var) do
		if(v.Table == nil) then v.Table = "Plys" end
		if(v.Val == nil) then v.Val = 0 end
		if(v.Type == nil) then v.Type = "Int" end

		sql.Query("ALTER TABLE KunitB_"..v.Table.." ADD  "..v.Name.." "..v.Type.."")
	end
end

 function KunitB_SQL_NewPlayer(ply)
 
 		steamID = ply:SteamID()
		if(steamID == nil or steamID == NULL or steamID == "" or steamID == false) then print("Player did not have a steam id upon making a new sql table.") return false end
		
		result = sql.Query( "SELECT Steam FROM KunitB_Bank WHERE Steam = '"..steamID.."'" )

		if (result == NULL or result == nil or result == "" or result == false) then
			sql.Query( "INSERT INTO KunitB_Bank (`Steam`)VALUES ('"..steamID.."')" )
			KunitB_SQL_LoadPlayerValues(ply)
		else
			--Already has a table, load player values here.
			KunitB_SQL_LoadPlayerValues(ply)
		end
 end
 
 function KunitB_SQL_LoadPlayerValues(ply)
	resulta = sql.Query( "SELECT Steam FROM KunitB_Bank WHERE Steam = '"..ply:SteamID().."'" )
	if (resulta == NULL or resulta == nil or resulta == "" or resulta == false) then KunitB_SQL_NewPlayer(ply) end
	if(ply:SteamID() != nil) then
		for k,v in pairs(KunitB.SQL_Var) do
			result = sql.Query( "SELECT "..v.Name.." FROM KunitB_"..v.Table.." WHERE Steam = '"..ply:SteamID().."'" )
			rname = v.Name

			for a,b in pairs(result[1]) do
				if(a == rname) then
					result = b
				end
			end

			if(result == nil) then result = 0 end
			if(result != nil and v.Type == "Int") then
				if(tonumber(result) == nil) then result = 0 end
				if(tonumber(result) <= 0) then result = 0 end
				KunitB_SetVal(ply,v.Name,result)
			else
				if(v.Type == "Text") then
					if(result == 0 or result == nil) then result = "None" end
					KunitB_SetVal(ply,v.Name,result,"Text")
				end
			end
		end
	end
 end
 concommand.Add("KunitB_SQL_LoadPlayerValues",KunitB_SQL_LoadPlayerValues)
 
 function KunitB_SetVal(ply,Name,Amt,Type)
	result = sql.Query( "SELECT Steam FROM KunitB_Bank WHERE Steam = '"..ply:SteamID().."'" )
	if (result == NULL or result == nil or result == "" or result == false) then KunitB_SQL_NewPlayer(ply) end
	
	if(Name == nil) then print("NIL NAME ON SET VAR?") return false end
	if(Type != "Text") then
		Amt = tonumber(Amt)
	else
		if(Amt == nil) then
			for k,v in pairs(KunitB.SQL_Var) do
				if(v.Name == Name) then
					Amt = v.Val
				end
			end
		end
	end
	if(Amt == nil) then Amt = 0 end

	if(ply:IsValid()) then
		if(ply.KunitB == nil) then
			ply.KunitB = {}
		end

		if(Type == "Text") then
			sql.Query("UPDATE KunitB_Bank SET "..Name.." = '"..Amt.."'  WHERE Steam = '"..ply:SteamID().."'")
		else
			sql.Query("UPDATE KunitB_Bank SET "..Name.." = "..Amt.." WHERE Steam = '"..ply:SteamID().."'")
		end

		if(Type != nil and Type == "Text") then
			if(ply.KunitB[Name] == nil) then ply.KunitB[Name] = "None" end
			
			ply.KunitB[Name] = Amt --Amt is actually a universal variable to represent the string or an int depending on the type variable / usage as well. :) 	

			net.Start( "KunitB_Net_CS_SetVal" )
				net.WriteString(Name)
				net.WriteString("Text")
				net.WriteString(Amt)
			net.Send(ply)
		else
			if(ply.KunitB[Name] == nil) then ply.KunitB[Name] = 0 end
			
			ply.KunitB[Name] = Amt

			net.Start( "KunitB_Net_CS_SetVal" )
				net.WriteString(Name)
				net.WriteString("Int")
				net.WriteInt(Amt,32)
			net.Send(ply)
		end
	end
 end
 
function KunitB_SQL_AdminResetPlayer(ply,cmd,arg)
	if(ply:IsSuperAdmin()) then
		for k,v in pairs(player.GetAll()) do
			if(string.find(v:Nick(),arg[1]) != nil) then
				sql.Query("DELETE FROM KunitB_Bank WHERE Steam='"..v:SteamID().."'")
				KunitB_SQL_NewPlayer(v)
				return
			end
		end
	end
 end
 concommand.Add("KunitB_SQL_AdminResetPlayer",KunitB_SQL_AdminResetPlayer)
 
 
 
 
 