

if(SERVER) then
	util.AddNetworkString( "DarkRP_CS_BankMenu" )
	util.AddNetworkString( "DarkRP_SS_BankCash" )
	util.AddNetworkString( "DarkRP_SS_ItemManage" )
	util.AddNetworkString( "KunitB_Net_CS_SetVal" )

end

AddCSLuaFile( "cl_bankz.lua" )

--Preferences
	Kun_ATMCanBankItems = 1 --Set to 0 to make it so ATM's can't deposit / withdraw items, only the NPC can.
	Kun_InterestTimer = 300 --Interest every 5 minutes.
	Kun_InterestValue = 0.001 --$1000 * 0.001 = $1 every 5 minutes.
--End

KunitB = {}

--DO NOT TOUCH THIS
KunitB = {}
KunitB.SQL_Tables = {}
KunitB.SQL_Tables[1] = {Name = "Bank"}
--End
--Sqlvals
KunitB.SQL_Var = {}
KunitB.SQL_Var[1] = {Name = "BankCash", Val = 0, Type = "Int", Table = "Bank"}
--End

--Bank Spawns
KunitB.BankSpawnz = {} --Type 1 = NPC, Type 2 = ATM
KunitB.BankSpawnz[1] = {Type = 1, Vec = Vector(3450, 2903, -139), Ang = Angle(0,0,0)}
KunitB.BankSpawnz[2] = {Type = 2, Vec = Vector(3550, 2903, -139), Ang = Angle(0,0,0)}
--End

--Items that can go into the bank.
KunitB.BankWeps = {}
KunitB.BankWeps[1] = {Mdl = "models/weapons/w_pist_glock18.mdl", Name = "Pistol", WepID = "weapon_pistol"}
KunitB.BankWeps[2] = {Mdl = "models/weapons/w_rif_m4a1_silencer.mdl", Name = "SMG", WepID = "weapon_smg1"}

for k,v in pairs(KunitB.BankWeps) do
	KunitB.SQL_Var[table.Count(KunitB.SQL_Var) + 1] = {Name = v.Name, Val = 0, Type = "Int", Table = "Bank"}
end
--End

include('sv_sql_bankz.lua')
KunitB_SQL_CheckIfTablesExist()

if(SERVER) then
	function DarkRP_Bankyz_Spawn()
		for k,v in pairs(KunitB.BankSpawnz) do
			if(v.Type == 1) then
				ent = ents.Create("npc_bank")
			else
				ent = ents.Create("ent_bank")
			end
			ent:SetPos(v.Vec)
			ent:SetAngles(v.Ang) 
			ent:Spawn()
		end
		
		DarkRP_Kun_Interest()
	end
	hook.Add( "InitPostEntity", "DarkRP_Bankyz_Spawn", DarkRP_Bankyz_Spawn)
end

function DarkRP_Kun_Interest()
	for k,v in pairs(player.GetAll()) do
		KunitB_SQL_LoadPlayerValues(v)
		if(v.KunitB != nil and v.KunitB["BankCash"] != nil) then
			local inamt = math.ceil(v.KunitB["BankCash"] * Kun_InterestValue)
			KunitB_SetVal(v,"BankCash",v.KunitB["BankCash"] + inamt)
		end
	end
	timer.Simple(Kun_InterestTimer, function() DarkRP_Kun_Interest() end )
end

function DarkRP_Kun_OpenBank(ply,self)
	KunitB_SQL_LoadPlayerValues(ply)
	if(self:GetClass() == "npc_bank") then
		banksendint = 1
	else
		banksendint = 2
	end
	net.Start("DarkRP_CS_BankMenu")
		net.WriteInt(banksendint,32)
	net.Send(ply)
end

net.Receive( "DarkRP_SS_BankCash", function( length, ply )
	local btype = net.ReadString()
	local amt = net.ReadInt(32)

	if(amt < 0 or amt == 0 and amt > 50000) then
		GAMEMODE:Notify(ply, 0, 4, "Enter a value higher than zero, and a value less-than $50,000.")
		return false
	end
	
	if(btype == "Withdraw") then
		if(ply.KunitB["BankCash"] < amt) then
			amt = ply.KunitB["BankCash"]
		end
		if(amt == 0) then GAMEMODE:Notify(ply, 0, 4, "You do not have any money in the bank.") return end
		ply:AddMoney(amt)
		KunitB_SetVal(ply,"BankCash",ply.KunitB["BankCash"] - amt)
		GAMEMODE:Notify(ply, 0, 4, "You made a withdrawl of $"..amt..".")
	else
		if(ply:getDarkRPVar("money") < amt) then
			amt = ply:getDarkRPVar("money")
		end
		ply:AddMoney(-amt)
		KunitB_SetVal(ply,"BankCash",ply.KunitB["BankCash"] + amt)
		GAMEMODE:Notify(ply, 0, 4, "You made a deposit of $"..amt..".")
	end
end )

net.Receive( "DarkRP_SS_ItemManage", function( length, ply )
	local name = net.ReadString()
	local wep = net.ReadString()
	DEPOSITEZ = 0
	
	if(name == "All") then
		for k,v in pairs(KunitB.BankWeps) do
			if(ply:GetWeapon(v.WepID):IsValid()) then
				ply:StripWeapon(v.WepID)
				if(ply.KunitB == nil or ply.KunitB[v.Name] == nil) then KunitB_SQL_LoadPlayerValues(ply) end
				KunitB_SetVal(ply,v.Name,ply.KunitB[v.Name] + 1)
			end
		end
	else
		if(name == "Current") then
			for k,v in pairs(KunitB.BankWeps) do
				if(v.WepID == ply:GetActiveWeapon():GetClass()) then
					if(ply.KunitB == nil or ply.KunitB[v.Name] == nil) then KunitB_SQL_LoadPlayerValues(ply) end
					KunitB_SetVal(ply,v.Name,ply.KunitB[v.Name] + 1)
					ply:StripWeapon(v.WepID)
					DEPOSITEZ = 1
				end
			end
			if(DEPOSITEZ == 0) then
				GAMEMODE:Notify(ply, 0, 4, "That item is not able to be placed within the bank.")
			end
		else
			if(ply.KunitB[name] > 0) then
				if(ply.KunitB == nil or ply.KunitB[name] == nil) then KunitB_SQL_LoadPlayerValues(ply) end
				KunitB_SetVal(ply,name,ply.KunitB[name] - 1)
				ply:Give(wep)
			end
		end
	end
end )
