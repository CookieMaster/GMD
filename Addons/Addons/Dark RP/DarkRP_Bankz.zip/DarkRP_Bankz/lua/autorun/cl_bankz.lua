
function KunitB_CS_SetVal()

	local ply = LocalPlayer()
	local Name = net.ReadString()
	local Type = net.ReadString()
	if(Type == "Text") then
		Amt = net.ReadString()
	else
		Amt = net.ReadInt(32)
	end

	if(ply:IsValid()) then
		if(ply.KunitB == nil) then
			ply.KunitB = {}
		end
		
		ply.KunitB[Name] = Amt
	end
end
net.Receive( "KunitB_Net_CS_SetVal", KunitB_CS_SetVal)

function DarkRP_CS_BankMenu()
	local ply = LocalPlayer()
	local btype = net.ReadInt(32)
	
	local frame = vgui.Create("DFrame")
	if(btype == 2 and Kun_ATMCanBankItems == 0) then
		frame:SetSize( 140, 150)
	else
		frame:SetSize( 400, 450)
	end
	frame:Center()
	frame:SetDraggable( false )
	frame:SetVisible( true )
	frame:ShowCloseButton( true )
	frame:MakePopup()
	frame:SetTitle("")
	frame.Paint = function(frame)
		surface.SetDrawColor( 250, 250, 250, 255) 
		surface.DrawRect(0 , 0, frame:GetWide(), frame:GetTall() )
		
		surface.SetDrawColor( 50, 50, 50, 255) 
		surface.DrawRect(2 , 2, frame:GetWide()-4, frame:GetTall()-4 )
		
		surface.SetDrawColor( 240, 240,240, 255) 
		surface.DrawRect(10 , 100, frame:GetWide() - 20, 5 )

		draw.SimpleText( "Bank", "DermaLarge", frame:GetWide() / 2, 60, Color(250,250,250,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local IList = vgui.Create( "DPanelList", frame )
	IList:SetPos( 5, 140 )
	IList:SetSize( frame:GetWide() - 10, frame:GetTall() - 145)
	IList:SetSpacing( 15 )
	IList:SetPadding(10)
	IList:EnableHorizontal( true ) 
	IList:EnableVerticalScrollbar( true ) 
	IList.Paint = function()
		surface.SetDrawColor( 50, 50, 50, 255 ) 
		surface.DrawRect( 0, 0, IList:GetWide(), IList:GetTall() )
	end
	
	local ManageCash = vgui.Create( "DButton", frame )
	ManageCash:SetPos( 10, 110 )
	ManageCash:SetSize( 120, 20)
	ManageCash:SetText("Manage Balance")
	ManageCash.DoClick = function()
		DarkRP_DepositBankCashz()
		frame:Close()
	end
	
	if((btype == 2 and Kun_ATMCanBankItems == 1) or btype == 1) then	
		local DepositWeps = vgui.Create( "DButton", frame )
		DepositWeps:SetPos( 140, 110 )
		DepositWeps:SetSize( 120, 20)
		DepositWeps:SetText("Deposit All Weapons")
		DepositWeps.DoClick = function()
			net.Start("DarkRP_SS_ItemManage")
				net.WriteString("All")
			net.SendToServer()
			frame:Close()
		end
		
		local DepositWep = vgui.Create( "DButton", frame )
		DepositWep:SetPos( 270, 110 )
		DepositWep:SetSize( 120, 20)
		DepositWep:SetText("Deposit Weapon")
		DepositWep.DoClick = function()
			net.Start("DarkRP_SS_ItemManage")
				net.WriteString("Current")
			net.SendToServer()
			frame:Close()
		end

		for k,v in pairs(KunitB.BankWeps) do
			if(ply.KunitB[v.Name] > 0) then
				local itemp = vgui.Create( "DPanel" )
				itemp:SetPos( 5, 130 )
				itemp:SetSize( 80, 80)
				itemp.Paint = function()
					surface.SetDrawColor( 250, 250, 250, 255) 
					surface.DrawRect(0 , 0, itemp:GetWide(), itemp:GetTall() )
					
					surface.SetDrawColor( 50, 50, 50, 255) 
					surface.DrawRect(2 , 2, itemp:GetWide()-4, itemp:GetTall()-4 )	
					draw.SimpleText( v.Name, "Default", itemp:GetWide() / 2, 8, Color(250,250,250,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)			
					draw.SimpleText( ply.KunitB[v.Name], "Default", itemp:GetWide() / 2, itemp:GetTall() - 8, Color(250,250,250,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)						
				end

				local icon = vgui.Create( "SpawnIcon", itemp ) 
				icon:SetModel( v.Mdl )
				icon:SetSize(50,50)
				icon:SetPos(15,15)
				icon:SetToolTip(nil)
				icon.DoClick = function( icon ) 
					net.Start("DarkRP_SS_ItemManage") net.WriteString(v.Name) net.WriteString(v.WepID) net.SendToServer()
					frame:Close()
				end 
				icon.Paint = function()
					surface.SetDrawColor( 255, 255, 255, 255 ) 
					surface.DrawOutlinedRect( 0, 0, icon:GetWide(), icon:GetTall())
				end
				
				IList:AddItem(itemp)
			end
		end
	end
end
net.Receive( "DarkRP_CS_BankMenu", DarkRP_CS_BankMenu)

function DarkRP_DepositBankCashz()
	local ply = LocalPlayer()
	local amt = 0

	local frame = vgui.Create("DFrame")
	frame:SetSize( 300, 190)
	frame:Center()
	frame:SetDraggable( false )
	frame:SetVisible( true )
	frame:ShowCloseButton( true )
	frame:MakePopup()
	frame:SetTitle("")
	frame.Paint = function(frame)
		surface.SetDrawColor( 250, 250, 250, 255) 
		surface.DrawRect(0 , 0, frame:GetWide(), frame:GetTall() )
		
		surface.SetDrawColor( 50, 50, 50, 255) 
		surface.DrawRect(2 , 2, frame:GetWide()-4, frame:GetTall()-4 )
		
		surface.SetDrawColor( 240, 240,240, 255) 
		surface.DrawRect(10 , 100, frame:GetWide() - 20, 5 )

		draw.SimpleText( "Enter an amount to withdraw or deposit.", "TargetID", frame:GetWide() / 2, 60, Color(250,250,250,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText( "$"..ply.KunitB["BankCash"], "Default", 10, 80, Color(250,250,250,255))
	end	
	
	local Amtz = vgui.Create("DTextEntry", frame)
	Amtz:SetPos(10,130)
	Amtz:SetSize(frame:GetWide() - 20, 20)
	Amtz:SetText("0")
	Amtz.OnTextChanged = function()
		amt = tonumber(Amtz:GetValue())
	end
	
	local Withdraw = vgui.Create("DButton", frame)
	Withdraw:SetPos(10,160)
	Withdraw:SetSize(100, 20)	
	Withdraw:SetText("Withdraw")
	Withdraw.DoClick = function()
		net.Start("DarkRP_SS_BankCash")
			net.WriteString("Withdraw")
			net.WriteInt(amt,32)
		net.SendToServer()
	end
	
	local Deposit = vgui.Create("DButton", frame)
	Deposit:SetPos(frame:GetWide() - 110,160)
	Deposit:SetSize(100, 20)	
	Deposit:SetText("Deposit")
	Deposit.DoClick = function()
		net.Start("DarkRP_SS_BankCash")
			net.WriteString("Deposit")
			net.WriteInt(amt,32)
		net.SendToServer()
	end
end
