-- Dynamic Proplimit System
-- A script By Lixquid
-- Rev 2

local debugmode = false

local dm = debugmode and function( s ) print( "DYNAMIC LIMIT: " .. s ) end or function() end

concommand.Add( "dynamiclimit_version", function( ply, com, args )
	ply:ChatPrint( "DynamicLimit Revision 4" )
end )

local settings = {
	mod = "vanilla",
	ranks = {
		superadmin = 5,
		admin = 250
	},
	default = 100
}

hook.Add( "PlayerSpawnProp", "DynamicLimit", function( ply )
	
	dm( ply:Nick() .. " spawn prop" )
	
	local limit = settings.default
	for k, v in pairs( settings.ranks ) do
		if settings.mod == "vanilla" then
			if ply:IsAdmin() and k == "superadmin" then
				limit = v break
			elseif ply:IsSuperAdmin() and k == "admin" then
				limit = v break
			end
		elseif settings.mod == "ulx" or settings.mod == "fadmin" then
			if ply:IsUserGroup( k ) then limit = v break end
		elseif settings.mod == "assmod" then
			if tostring( ply:GetLevel() ) == k or string.lower( LevelToString( ply:GetLevel() ) ) == k then
				limit = v break
			end
		elseif settings.mod == "evolve" then
			if tostring( ply:EV_IsRank( k ) ) then
				limit = v
			end
		end
	end
	
	dm( limit .. " limit, " .. settings.default .. " default" )
	
	if GetConVarNumber( "sbox_maxprops" ) < limit then
		RunConsoleCommand( "sbox_maxprops", limit )
		dm( "extend limit" )
	end
	
	if ply:GetCount( "props" ) >= limit then
		dm( "Denied" )
		ply:SendLua( "GAMEMODE:AddNotify( \"You've hit the Prop limit!\", NOTIFY_ERROR, 6 ) surface.PlaySound( \"buttons/button10.wav\" )" )
		return false
	end
	dm( "Allowed" )
end )