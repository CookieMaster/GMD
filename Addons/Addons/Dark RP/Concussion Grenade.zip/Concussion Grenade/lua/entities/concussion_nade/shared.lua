
if SERVER then AddCSLuaFile("shared.lua") end

ENT.Type 			= "anim"
ENT.Base 			= "base_anim"

if CLIENT then
	ENT.RenderGroup = RENDERGROUP_OPAQUE
	function ENT:Initialize()
	end
		
	function ENT:Draw()
		self:DrawModel()
	end
	
	function ENT:OnRemove()
		sound.Play("weapons/explode3.wav", self:GetPos(), 85, 115) // 85 is soundlevel, 115 is pitch(100 for default pitch)
	end
	
	local effEnd = -100
	local DSPReset = false
	hook.Add("RenderScreenspaceEffects", "concussion_nade", function()
		if effEnd+10 <= CurTime() then
			if !DSPReset then
				LocalPlayer():SetDSP(0, false)
				DSPReset = true
			end
			return
		end
		local tab = {
		 [ "$pp_colour_addr" ] = 0,
		 [ "$pp_colour_addg" ] = 0,
		 [ "$pp_colour_addb" ] = 0,
		 [ "$pp_colour_brightness" ] = -0.6-0.6*((effEnd-CurTime())/10),
		 [ "$pp_colour_contrast" ] = 1,
		 [ "$pp_colour_colour" ] = 1,
		 [ "$pp_colour_mulr" ] = 0,
		 [ "$pp_colour_mulg" ] = 0,
		 [ "$pp_colour_mulb" ] = 0}
		DrawColorModify(tab)
		DrawMotionBlur(0.15, 0.78, 0.07+0.07*((effEnd-CurTime())/10))	
	end)
	net.Receive("CCNadeEff", function()
		effEnd = CurTime()
		LocalPlayer():SetDSP(38, false)
		DSPReset = false
	end)
	
	return
end

function ENT:Initialize()
	self:SetModel("models/Items/grenadeAmmo.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	local phys = self:GetPhysicsObject()    
	if phys:IsValid() then
		phys:Wake()
	end
	self.Spawned = CurTime()
end

util.AddNetworkString("CCNadeEff")
function ENT:Think()
	if self.Spawned + 2 > CurTime() then return end
	local FireExp = ents.Create("env_physexplosion")
	local pos = self:GetPos()
	FireExp:SetPos(pos)
	FireExp:SetParent(self)
	FireExp:SetKeyValue("magnitude", 100)
	FireExp:SetKeyValue("radius", 100)
	FireExp:SetKeyValue("spawnflags", "1")
	FireExp:Spawn()
	FireExp:Fire("Explode", "", 0)
	timer.Simple(2, function() if FireExp:IsValid() then FireExp:Remove() end end) // just incase it doesn't remove itself
	
	local effectdata = EffectData()
	effectdata:SetStart(pos)
	effectdata:SetOrigin(pos)
	effectdata:SetScale(0.1)
	util.Effect("HelicopterMegaBomb", effectdata)
	
	local tbl = player.GetAll()
	local players = {}
	for i=1, #tbl do
		if tbl[i]:Alive() and tbl[i]:Team() != TEAM_SPECTATOR and pos:Distance(tbl[i]:GetPos()) <= 300 and tbl[i]:Visible(self) then
			table.insert(players, tbl[i])
		end
	end
	net.Start("CCNadeEff")
	net.Send(players)
	
	self:Remove()
end
