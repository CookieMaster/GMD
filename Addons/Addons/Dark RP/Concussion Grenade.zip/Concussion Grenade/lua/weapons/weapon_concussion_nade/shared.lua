if SERVER then
	AddCSLuaFile("shared.lua")
end

SWEP.Base = "weapon_tttbase"

if CLIENT then
	SWEP.PrintName = "Concussion Grenade"
	SWEP.Slot = 1
	SWEP.SlotPos = 3
	SWEP.DrawAmmo = false
	SWEP.DrawCrosshair = false
	
	SWEP.Icon = "VGUI/ttt/icon_nades"
    SWEP.EquipMenuData = {
       type = "Concussion",
       desc = "Make people disoriented."
    }
end

SWEP.UseHands = true

SWEP.Author = "Tomasas"
SWEP.Instructions = ""


SWEP.Kind = WEAPON_EQUIP2
SWEP.CanBuy = {ROLE_TRAITOR}
SWEP.AllowDrop = false
SWEP.IsSilent = false

SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.AnimPrefix	 = "rpg"
SWEP.ViewModel = "models/weapons/c_grenade.mdl"
SWEP.WorldModel = "models/weapons/w_grenade.mdl"

SWEP.Spawnable	= true
SWEP.AdminOnly	= true

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"
SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

function SWEP:Initialize()
	self:SetWeaponHoldType("grenade")
end

function SWEP:Deploy()
	return true
end

function SWEP:GetIronsights()
	return false
end

function SWEP:PrimaryAttack()
	//if !self:CanPrimaryAttack() then return end
	//self:TakePrimaryAmmo(1)
	self.Weapon:SetNextPrimaryFire(CurTime() + 0.5)
	self.Weapon:SetNextSecondaryFire(CurTime() + 0.5)
	self.Weapon:SendWeaponAnim(ACT_VM_THROW)
	if CLIENT then return end
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	
	local ang = self.Owner:GetAngles()
	local ent = ents.Create("concussion_nade")
	ent.Owner = self.Owner
	ent:SetPos(self.Owner:GetShootPos()+ang:Forward()*10)
	local newAng = Angle(ang.p, ang.y, ang.r)
	newAng:RotateAroundAxis(newAng:Forward(), -45)
	ent:SetAngles(newAng)
	ent:Spawn()
	ent:GetPhysicsObject():ApplyForceCenter(ang:Forward()*1000)
	self.Owner:StripWeapon("weapon_concussion_nade")
end

function SWEP:SecondaryAttack()
	self.Weapon:SetNextPrimaryFire(CurTime() + 0.5)
	self.Weapon:SetNextSecondaryFire(CurTime() + 0.5)
	self.Weapon:SendWeaponAnim(ACT_VM_THROW)
	if CLIENT then return end
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	
	local ang = self.Owner:GetAngles()
	local ent = ents.Create("concussion_nade")
	ent.Owner = self.Owner
	ent:SetPos(self.Owner:GetShootPos()+ang:Forward()*10)
	local newAng = Angle(ang.p, ang.y, ang.r)
	newAng:RotateAroundAxis(newAng:Forward(), -45)
	ent:SetAngles(newAng)
	ent:Spawn()
	ent:GetPhysicsObject():ApplyForceCenter(ang:Forward()*500)
	self.Owner:StripWeapon("weapon_concussion_nade")
end

