local function CCarNPC()
	local CCarNPC = ents.Create("c_car")
	CCarNPC:SetPos(CCar_NPCPos)
	CCarNPC:SetAngles(CCar_NPCAng)
	CCarNPC:SetModel(CCar_NPCModel)
	CCarNPC:Spawn()
	CCarNPC:Activate()
	CCarNPC:InitializeAnimation(2)
end
hook.Add( "InitPostEntity", "wat", CCarNPC )

CreateConVar("CCars_Enabled", 1, FCVAR_NOTIFY, FCVAR_REPLICATED, FCVAR_SERVER_CAN_EXECUTE, "Whether or not Cop Car spawning is allowed." )

hook.Add("PlayerDisconnected", "Clean_Strays", function(ply)
	for k,v in pairs (ents.FindByClass("prop_vehicle_jeep")) do
		if v.CCOwner == ply then
		v:Remove()
		end
	end
end)

hook.Add('OnPlayerChangedTeam', 'PlayerChangeTeam', function(ply)
	for k,v in pairs (ents.FindByClass("prop_vehicle_jeep")) do
		if v.CCOwner == ply && !v.CCOwner:isCP() then
			v:Remove()
			DarkRP.notify(ply,1,5,"Your police car has been removed as you have changed job.")
		end 
	end
end)

--- Models/materials

resource.AddSingleFile( "models/lonewolfie/ariel.dx80.vtx" )
resource.AddSingleFile( "models/lonewolfie/ariel.dx90.vtx" )
resource.AddSingleFile( "models/lonewolfie/ariel.mdl" )
resource.AddSingleFile( "models/lonewolfie/ariel.phy" )
resource.AddSingleFile( "models/lonewolfie/ariel.sw.vtx" )
resource.AddSingleFile( "models/lonewolfie/ariel.vvd" )
resource.AddSingleFile( "models/lonewolfie/bullbar.dx80.vtx" )
resource.AddSingleFile( "models/lonewolfie/bullbar.dx90.vtx" )
resource.AddSingleFile( "models/lonewolfie/bullbar.mdl" )
resource.AddSingleFile( "models/lonewolfie/bullbar.phy" )
resource.AddSingleFile( "models/lonewolfie/bullbar.sw.vtx" )
resource.AddSingleFile( "models/lonewolfie/bullbar.vvd" )
resource.AddSingleFile( "models/lonewolfie/lightbar.dx80.vtx" )
resource.AddSingleFile( "models/lonewolfie/lightbar.dx90.vtx" )
resource.AddSingleFile( "models/lonewolfie/lightbar.mdl" )
resource.AddSingleFile( "models/lonewolfie/lightbar.phy" )
resource.AddSingleFile( "models/lonewolfie/lightbar.sw.vtx" )
resource.AddSingleFile( "models/lonewolfie/lightbar.vvd" )
resource.AddSingleFile( "models/lonewolfie/lightbarani.dx80.vtx" )
resource.AddSingleFile( "models/lonewolfie/lightbarani.dx90.vtx" )
resource.AddSingleFile( "models/lonewolfie/lightbarani.mdl" )
resource.AddSingleFile( "models/lonewolfie/lightbarani.phy" )
resource.AddSingleFile( "models/lonewolfie/lightbarani.sw.vtx" )
resource.AddSingleFile( "models/lonewolfie/lightbarani.vvd" )
resource.AddSingleFile( "models/lonewolfie/lone.dx80.vtx" )
resource.AddSingleFile( "models/lonewolfie/lone.dx90.vtx" )
resource.AddSingleFile( "models/lonewolfie/lone.mdl" )
resource.AddSingleFile( "models/lonewolfie/lone.phy" )
resource.AddSingleFile( "models/lonewolfie/lone.sw.vtx" )
resource.AddSingleFile( "models/lonewolfie/lone.vvd" )
resource.AddSingleFile( "materials/models/lightbar/chrome.vmt" )
resource.AddSingleFile( "materials/models/lightbar/chrome.vtf" )
resource.AddSingleFile( "materials/models/lightbar/lightbar.vmt" )
resource.AddSingleFile( "materials/models/lightbar/lightbar.vtf" )
resource.AddSingleFile( "materials/models/lightbar/tex.vmt" )
resource.AddSingleFile( "materials/models/lightbar/tex.vtf" )
resource.AddSingleFile( "materials/models/lightbar/texblue.vmt" )
resource.AddSingleFile( "materials/models/lightbar/texblue.vtf" )
resource.AddSingleFile( "materials/models/lightbar/texred.vmt" )
resource.AddSingleFile( "materials/models/lightbar/texred.vtf" )