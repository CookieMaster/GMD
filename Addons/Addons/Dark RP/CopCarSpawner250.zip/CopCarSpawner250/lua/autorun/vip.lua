PLAYER = FindMetaTable( "Player" )
function PLAYER:IsVIP(boolean)
		if self:GetUserGroup() == "donator" or self:GetUserGroup() == "VIP" or self:GetUserGroup() == "superadmin" or self:GetUserGroup() == "CCOwner" or self:GetUserGroup() == "admin" then
			return true
		end
end