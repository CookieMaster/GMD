-- hopefully you can get the idea of how this works - after reading the read.txt file.

if game.GetMap() == "rp_downtown_v4c_v2" then
	CCar_NPCPos = (Vector(-1569.633, -93.792, -159.968))
	CCar_NPCAng = (Angle(0,90,0))
	CCar_NPCModel = ("models/player/police.mdl")

	CCAR_SPAWN_ANG = Angle(0,0,0) -- angle the car spawns at 
	CCAR_SPAWN_POINTS = {Vector(-1316.110, 307.837, -203.968),
					Vector(-1316.110, -121.636, -203.968) -- places the cars can spawn, make sure if you're adding more to include a comma!
					}
end

if game.GetMap() == "rp_evocity_v4b1" then
	CCar_NPCPos = (Vector(-7078.031, -10169.972, -183.968))
	CCar_NPCAng = (Angle(0,180,0))
	CCar_NPCModel = ("models/player/police.mdl")

	CCAR_SPAWN_ANG = Angle(0,90,0)
	CCAR_SPAWN_POINTS = {Vector(-6916.208, -9470.515, -183.968),
						Vector(-6916.208, -9211.261, -183.968),
						Vector(-6916.208, -8942.977, -183.968)
					}
end

if game.GetMap() == "rp_downtown_v4c" then
	CCar_NPCPos = (Vector(-1569.633, -93.792, -159.968))
	CCar_NPCAng = (Angle(0,90,0))
	CCar_NPCModel = ("models/player/police.mdl")

	CCAR_SPAWN_ANG = Angle(0,0,0)
	CCAR_SPAWN_POINTS = {Vector(-1316.110, 307.837, -203.968),
					Vector(-1316.110, -121.636, -203.968)
					}
end

if game.GetMap() == "rp_bangclaw" then
	CCar_NPCPos = (Vector(932.462, 1553.120, 72.031250))
	CCar_NPCAng = (Angle(0,0,0))
	CCar_NPCModel = ("models/player/police.mdl")

	CCAR_SPAWN_ANG = Angle(0,180,0)
	CCAR_SPAWN_POINTS = {Vector(1009.977, 859.399, 64.0312),
					Vector(1009.977, 1277.830, 64.0312),
					Vector(1224.361, 1250.822, 64.0312),
					Vector(1223.785, 804.117, 64.0312)
					}
end




					
					
					


COP_VEHICLES = {}
local function CCarAdd(tbl)
	COP_VEHICLES[tbl.NUM] = CVEH
end

-- you may set your own skins, just in-case you have some from the workshop! 
-- color is also an option, though I'd recommend if you're using cop skins to keep those at 255 or it may look like it has a horrible tinge

-- if you wonder about the upkeep, I was originally going to set that up with the "economy" system but then I realised hey, not everyone has that...
-- if you want me to do that, just ask and I'll set it up for you, for now it can just be a little cost to avoid getting the car, respawning it and selling it (exploit)

--you'll probably want to change these.

CVEH = {}
CVEH.NUM = 1
CVEH.Name = "VIP Cop Car"
CVEH.Model = "models/buggy.mdl"
CVEH.Script = "scripts/vehicles/jeep_test.txt" -- this could be the cause of many a problem, make sure this is 100% correct.
CVEH.Skin = 0
CVEH.Color = Color(255,255,255)
CVEH.BullBarPos = nil  -- if you do not want these, make sure they're nil
CVEH.LightBarPos = nil  -- this too
CVEH.Upkeep = 75
CVEH.VIP = true
CCarAdd(CVEH)

CVEH = {}
CVEH.NUM = 2
CVEH.Name = "Non VIP Cop Car"
CVEH.Model = "models/buggy.mdl"
CVEH.Script = "scripts/vehicles/jeep_test.txt"
CVEH.Skin = 0
CVEH.Color = Color(255,255,255)
CVEH.BullBarPos = nilnil
CVEH.LightBarPos = nil
CVEH.Upkeep = 65
CVEH.VIP = false
CCarAdd(CVEH)

-- here are some examples of cars with bullbars/lights, among the jeep too... (if you want to use the, just remove the comment //, you will require TDMcars)

//CVEH = {}
//CVEH.NUM = // up to you
//CVEH.Name = "Volvo 240"
//CVEH.Model = "models/tdmcars/242turbo.mdl"
//CVEH.Script = "scripts/vehicles/tdmcars/242turbocharged.txt"
//CVEH.Skin = 0
//CVEH.Color = Color(15,15,15)
//CVEH.BullBarPos = {{Vector(2.127, 109.374, 10.214), Angle(0,0,0)}}
//CVEH.LightBarPos = {{Vector(-0.149895, 0.084534, 9.728169), Angle(0,0,0)}}
//CVEH.Upkeep = 100
//CVEH.VIP = false
//CCarAdd(CVEH)

//CVEH = {}
//CVEH.NUM = // up to you
//CVEH.Name = "Dodge Charger Police"
//CVEH.Model = "models/tdmcars/chargersrt8.mdl"
//CVEH.Script = "scripts/vehicles/tdmcars/chargersrt8.txt"
//CVEH.Skin = 0
//CVEH.Color = Color(15,15,15)
//CVEH.BullBarPos = {{Vector(1.905226, 105.165764, 10.829847), Angle(0,0,0)}}
//CVEH.LightBarPos = {{Vector(0.168663, -12.365330, 9.542832), Angle(0,0,0)}}
//CVEH.Upkeep = 100
//CVEH.VIP = false
//CCarAdd(CVEH)

//CVEH = {}
//CVEH.NUM = // up to you
//CVEH.Name = "Dodge RAM"
//CVEH.Model = "models/tdmcars/dodgeram.mdl"
//CVEH.Script = "scripts/vehicles/tdmcars/dodgeram.txt"
//CVEH.Skin = 0
//CVEH.Color = Color(15,15,15)
//CVEH.BullBarPos = {{Vector(2.398663, 112.051369, 21.418852), Angle(0,0,0)}}
//CVEH.LightBarPos = nil // if you want them the vector is {{Vector(-0.045455, -6.167022, 27.778614), Angle(0,0,0)}}
//CVEH.Upkeep = 100
//CVEH.VIP = false
//CCarAdd(CVEH)

//CVEH = {}
//CVEH.NUM = // up to you 
//CVEH.Name = "Cadillac Escalade"
//CVEH.Model = "models/tdmcars/cad_escalade.mdl"
//CVEH.Script = "scripts/vehicles/tdmcars/escalade.txt"
//CVEH.Skin = 0
//CVEH.Color = Color(15,15,15)
//CVEH.BullBarPos = {{Vector(1.645082, 111.174591, 20.67821), Angle(0,0,0)}}
//CVEH.LightBarPos = nil // if you want them the vector is {{Vector(0.21470, 2.122230, 24.544558), Angle(0,0,0)}}
//CVEH.Upkeep = 100
//CVEH.VIP = false
//CCarAdd(CVEH)

