include('shared.lua') -- At this point the contents of shared.lua are ran on the client only.
function AcceptMenu(len)

	-- Small derma panel just for the example.
	local pShop = vgui.Create('DFrame')
	pShop:SetSize(300, 60)
	pShop:SetPos(ScrW()*0.5-150, ScrH()*0.5-30)
	pShop:SetTitle('Do you want to accept a quest?')
	pShop:SetSizable(true)
	pShop:SetDeleteOnClose(true)
	pShop:MakePopup()
	local button_yes = vgui.Create( "DButton", pShop )
	button_yes:SetSize( 100, 30 )
	button_yes:SetPos( 25, 25 )
	button_yes:SetText( "Yes" )
	button_yes.DoClick = function( button )
		net.Start( "Runner_AcceptedQuest" )
		net.SendToServer()
		pShop:Close()
	end
	local button_no = vgui.Create( "DButton", pShop )
	button_no:SetSize( 100, 30 )
	button_no:SetPos( 175, 25 )
	button_no:SetText( "No" )
	button_no.DoClick = function( button )
		pShop:Close()
	end
	
	
end

 net.Receive("Runner_AcceptQuest", AcceptMenu) --Hook to messages from the server so we know when to display the menu.
 
