AddCSLuaFile( "cl_init.lua" ) -- This means the client will download these files
AddCSLuaFile( "shared.lua" )
include('shared.lua')

-- Called when the entity initializes.
function ENT:Initialize()
	self:SetModel("models/extras/info_speech.mdl");
	self:SetMoveType(MOVETYPE_NONE);
	self:SetSolid(SOLID_NONE);
end