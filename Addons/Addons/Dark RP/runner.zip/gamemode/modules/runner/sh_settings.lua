-- determines how much money the player get's depening on how far away the target was.
DISTANCEMULT = 0.01
-- how long does a player need to wait until he can get a new quest in seconds.
RUNNERWAIT = 10
-- can other runners see runners on a mission?
RUNNERSEE = true
-- does the runner get money for killing another runner?
RUNNERLOOT = true
