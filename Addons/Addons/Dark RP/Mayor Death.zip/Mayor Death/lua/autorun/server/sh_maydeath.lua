--Simple Mayor Death Code
--All that I ask is that you don't say you made it
--Untested but should work
--To all the noobs that didn't know LUA or were just too lazy fuckwits to compile themselves ;)

local gamemodeget = GetConVarString("gamemode")
if string.find(gamemodeget, "darkrp") then
	function PlayerDied(victim, attacker)
if victim:Team() == TEAM_MAYOR then
victim:SetTeam(TEAM_CITIZEN)
	for k,v in pairs(player.GetAll()) do
v:ChatPrint(victim:Nick().." has been assassinated by "..attacker:Nick())
	end
		end
			end
				end
				
	hook.Add("PlayerDeath", "mayordied", PlayerDied)