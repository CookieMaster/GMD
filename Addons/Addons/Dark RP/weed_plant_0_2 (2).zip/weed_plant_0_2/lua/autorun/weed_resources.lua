--model
resource.AddFile( "models/nv_weed_plant/plant_big.mdl" );
resource.AddFile( "models/nv_weed_plant/plant_big.dx80" );
resource.AddFile( "models/nv_weed_plant/plant_big.dx90" );
resource.AddFile( "models/nv_weed_plant/plant_big.sw" );
resource.AddFile( "models/nv_weed_plant/plant_big.vvd" );
resource.AddFile( "models/nv_weed_plant/plant_big.phy" );

resource.AddFile( "models/nv_weed_plant/plant_medium.mdl" );
resource.AddFile( "models/nv_weed_plant/plant_medium.dx80" );
resource.AddFile( "models/nv_weed_plant/plant_medium.dx90" );
resource.AddFile( "models/nv_weed_plant/plant_medium.sw" );
resource.AddFile( "models/nv_weed_plant/plant_medium.vvd" );
resource.AddFile( "models/nv_weed_plant/plant_medium.phy" );

resource.AddFile( "models/nv_weed_plant/plant_small.mdl" );
resource.AddFile( "models/nv_weed_plant/plant_small.dx80" );
resource.AddFile( "models/nv_weed_plant/plant_small.dx90" );
resource.AddFile( "models/nv_weed_plant/plant_small.sw" );
resource.AddFile( "models/nv_weed_plant/plant_small.vvd" );
resource.AddFile( "models/nv_weed_plant/plant_small.phy" );

--materials
resource.AddFile( "materials/models/nv_weed_plant/canabis_diffuse.vmt" );
resource.AddFile( "materials/models/nv_weed_plant/canabis_diffuse.vtf" );
resource.AddFile( "materials/models/nv_weed_plant/canabis_normal.vtf" );
resource.AddFile( "materials/models/nv_weed_plant/dirt.vmt" );
resource.AddFile( "materials/models/nv_weed_plant/dirt.vtf" );
resource.AddFile( "materials/models/nv_weed_plant/dirt_normal.vtf" );
resource.AddFile( "materials/models/nv_weed_plant/lightwarp.vtf" );
resource.AddFile( "materials/models/nv_weed_plant/pot.vtf" );
resource.AddFile( "materials/models/nv_weed_plant/pot.vmt" );