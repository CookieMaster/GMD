AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )

util.AddNetworkString('NET_NCD_OpenMenu')
util.AddNetworkString('NET_NCD_BuyCar')
util.AddNetworkString('NET_NCD_SellCar')

function ENT:Initialize()
	self:SetModel( "models/odessa.mdl" )
	self:SetHullType( HULL_HUMAN )
	self:SetHullSizeNormal( )
	self:SetNPCState( NPC_STATE_SCRIPT )
	self:SetSolid( SOLID_BBOX )
	self:CapabilitiesAdd( CAP_ANIMATEDFACE )
	self:SetUseType( SIMPLE_USE )
	self:DropToFloor()
 
	self:SetMaxYawSpeed( 90 )

end

function ENT:SpawnFunction( ply, tr )
    if ( !tr.Hit ) then return end
    local ent = ents.Create( 'neths_car_dealer' )
    ent:SetPos( tr.HitPos + tr.HitNormal * 16 ) 
    ent:Spawn()
    ent:Activate()
 
    return ent
end

function ENT:AcceptInput( Name, Activator, Caller )
	if Name == "Use" and Caller:IsPlayer() then
		net.Start('NET_NCD_OpenMenu')
			net.WriteEntity( self )
		net.Send( Caller )
	end
end

function sv_nCD.Init()
	if file.Exists('ncd_dealer_pos.txt', 'DATA') then
		sv_nCD.DealerPos = util.JSONToTable( file.Read( 'ncd_dealer_pos.txt', 'DATA' ) )
	else
		sv_nCD.DealerPos = {}
		file.Write( 'ncd_dealer_pos.txt', util.TableToJSON( sv_nCD.DealerPos ) )
	end

	timer.Simple( 10, function()
		for i, DealerTbl in pairs (sv_nCD.DealerPos) do
			if ents.FindInSphere( DealerTbl.Pos, 32 ) then
				local ent = ents.Create( 'neths_car_dealer' )
			    ent:SetPos( DealerTbl.Pos )
			    ent:SetAngles( DealerTbl.Ang ) 
			    ent:Spawn()
			    ent:Activate()
			    print('CAR DEALER SPAWNED AT: '..tostring(DealerTbl.Pos))
			else
				print('BLOCKED CAR DEALER SPAWN AT: '..tostring(DealerTbl.Pos))
			end
		end
	end)
end
hook.Add('Initialize', 'sv_nCD_Init', sv_nCD.Init)

--THIS SCRIPT HAS BEEN MADE BY NETHEOUS AND SHOULD NOT BE RESOLD

function sv_nCD.BuyCar()
	local Buyer = net.ReadEntity()
	local Dealer = net.ReadEntity()
	local CarClass = net.ReadString()
	local CarColor = net.ReadTable()
	local CarTbl = sh_nCD.Cars[CarClass]

	local HasOtherVehicles = false
	for num, ent in pairs (ents.GetAll()) do
		if ent:IsVehicle() and ent.Owner then
			if ent.Owner == Buyer then 
				HasOtherVehicles = true
				if ent:GetPos():Distance( Dealer:GetPos() ) <= sh_nCD.Config.CarReturnRange then
					ent:Remove()
					HasOtherVehicles = false
					GAMEMODE:Notify( Buyer, 2, 3, "Your car has been returned!")
				end
				break
			end
		end
	end

	if HasOtherVehicles == true then
		GAMEMODE:Notify( Buyer, 2, 3, "You already have one vehicle, come within range of car dealer to repleace it!")
		return
	end

	local HasCar = false
	for num, class in pairs (Buyer.NCD.Cars) do
		if class == CarClass then
			HasCar = true
			break
		end
	end

	if sh_nCD.Config.PermamentCars == false then
		HasCar = false
	end

	if not HasCar == true then

		if tonumber(Buyer.DarkRPVars.money) < CarTbl.CarPrice then
			GAMEMODE:Notify( Buyer, 2, 3, "You don't have enought money!")
			return
		end

		if CarTbl.GroupOnly then
			local IsInGroup = false
			for num, group in pairs (CarTbl.GroupOnly) do
				if Buyer:IsUserGroup(group) then
					IsInGroup = true
					break
				end
			end
			if IsInGroup == false then
				GAMEMODE:Notify( Buyer, 2, 3, "It's restricted to certain groups only!")
				return
			end
		end

		if CarTbl.TeamOnly then
			local IsInTeam = false
			if team.GetName(Buyer:Team()) == CarTbl.TeamOnly then
				IsInTeam = true
			end
			if IsInTeam == false then
				GAMEMODE:Notify( Buyer, 2, 3, "It's restricted to "..CarTbl.TeamOnly.." only!")
				return
			end
		end

		local Vehicle = list.Get('Vehicles')[CarClass]

		local SpawnPos = LocalToWorld( Vector(150, 0, 10), Angle(0, 0, 0), Dealer:GetPos(), Dealer:GetAngles())
		local e = ents.Create(Vehicle.Class)
		e:SetModel(Vehicle.Model)
		e:SetPos(SpawnPos)
		for k, v in pairs (Vehicle.KeyValues) do
			e:SetKeyValue(k, v)
		end
		e:Spawn()
		e:Activate()
		e:SetCollisionGroup( COLLISION_GROUP_VEHICLE )
		e:SetColor( Color(CarColor.r, CarColor.g, CarColor.b, 255) )

		e.Owner = Buyer
		e.OwnerID = Buyer:SteamID()
		e.SID = Buyer.SID
		e:Own(Buyer)

		e.VehicleName = Vehicle.name
		e.VehicleTable = Vehicle
		e.VehicleScriptName = CarClass

		Buyer:AddMoney(-CarTbl.CarPrice)
		GAMEMODE:Notify( Buyer, 1, 3, "You bought a car for $"..CarTbl.CarPrice.."!")

		if sh_nCD.Config.PermamentCars == true then
			table.insert(Buyer.NCD.Cars, CarClass)
			sv_nCD.SaveCars( Buyer )
			sv_nCD.SendCars( Buyer )
		end

		hook.Call("PlayerSpawnedVehicle", GAMEMODE, Buyer, e)
		hook.Call("playerBoughtVehicle", nil, Buyer, Vehicle, e)
	else
		if CarTbl.GroupOnly then
			local IsInGroup = false
			for num, group in pairs (CarTbl.GroupOnly) do
				if Buyer:IsUserGroup(group) then
					IsInGroup = true
					break
				end
			end
			if IsInGroup == false then
				GAMEMODE:Notify( Buyer, 2, 3, "It's restricted to certain groups only!")
				return
			end
		end

		if CarTbl.TeamOnly then
			local IsInTeam = false
			if team.GetName(Buyer:Team()) == CarTbl.TeamOnly then
				IsInTeam = true
			end
			if IsInTeam == false then
				GAMEMODE:Notify( Buyer, 2, 3, "It's restricted to "..CarTbl.TeamOnly.." only!")
				return
			end
		end
		
		local Vehicle = list.Get('Vehicles')[CarClass]

		local SpawnPos = LocalToWorld( Vector(150, 0, 10), Angle(0, 0, 0), Dealer:GetPos(), Dealer:GetAngles())
		local e = ents.Create(Vehicle.Class)
		e:SetModel(Vehicle.Model)
		e:SetPos(SpawnPos)
		for k, v in pairs (Vehicle.KeyValues) do
			e:SetKeyValue(k, v)
		end
		e:Spawn()
		e:Activate()
		e:SetCollisionGroup( COLLISION_GROUP_VEHICLE )
		e:SetColor( Color(CarColor.r, CarColor.g, CarColor.b, 255) )

		e.Owner = Buyer
		e.OwnerID = Buyer:SteamID()
		e.SID = Buyer.SID
		e:Own(Buyer)

		e.VehicleName = Vehicle.name
		e.VehicleTable = Vehicle
		e.VehicleScriptName = CarClass

		GAMEMODE:Notify( Buyer, 2, 3, "You spawned a car!")

		hook.Call("PlayerSpawnedVehicle", GAMEMODE, Buyer, e)
		hook.Call("playerBoughtVehicle", nil, Buyer, Vehicle, e)
	end
end
net.Receive('NET_NCD_BuyCar', sv_nCD.BuyCar)

function sv_nCD.SaveDealerPos( ply )
	if not ply:IsPlayer() then return end
	if not ply:IsSuperAdmin() then return end

	sv_nCD.DealerPos = {}
	for i, e in pairs (ents.FindByClass('neths_car_dealer')) do
		local PosAng = { Pos = e:GetPos(), Ang = e:GetAngles()}
		table.insert(sv_nCD.DealerPos, PosAng)
	end
	file.Write( 'ncd_dealer_pos.txt', util.TableToJSON( sv_nCD.DealerPos ) )
end
concommand.Add('ncd_savedealerpos', sv_nCD.SaveDealerPos)

function sv_nCD.SellCar()
	local Seller = net.ReadEntity()
	local CarClass = net.ReadString()
	local HasCar = false

	for i, car in pairs (Seller.NCD.Cars) do
		if car == CarClass then
			table.remove( Seller.NCD.Cars, i )
			HasCar = true
			break
		end
	end

	if not HasCar then return end

	local Vehicle = list.Get('Vehicles')[CarClass]
	for i, ent in pairs (ents.FindByClass( Vehicle.Class ) ) do
		if ent.Owner == Seller then
			ent:Remove()
		end
	end

	Seller:AddMoney(sh_nCD.Cars[CarClass].CarPrice * 0.75)

	sv_nCD.SaveCars( Seller )
	sv_nCD.SendCars( Seller )

	GAMEMODE:Notify( Seller, 2, 3, "You sold the access to car for $"..sh_nCD.Cars[CarClass].CarPrice * 0.75)
end
net.Receive('NET_NCD_SellCar', sv_nCD.SellCar)

function sv_nCD.PlayerChangeTeam( p, oldTeam_ID, newTeam_ID )
	for num, ent in pairs (ents.GetAll()) do
		if ent:IsVehicle() and ent.Owner and ent.VehicleScriptName then
			if ent.Owner == p and sh_nCD.Cars[ent.VehicleScriptName].TeamOnly then
				ent:Remove()
			end
		end
	end
end
hook.Add('OnPlayerChangedTeam', 'PlayerChangeTeam', sv_nCD.PlayerChangeTeam)