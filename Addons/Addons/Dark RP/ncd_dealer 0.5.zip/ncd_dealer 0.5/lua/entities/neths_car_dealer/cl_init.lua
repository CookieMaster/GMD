include('shared.lua')
surface.CreateFont("DefaultBoldTahoma", {font = "Tahoma",
                                   size = 35,
                                   weight = 1000,
                                   shadow = true, 
                                   antialias = true})
surface.CreateFont("CarDealerTitle",    {font = "Tahoma",
                                   size = 130,
                                   weight = 1700,
                                   shadow = true, 
                                   antialias = true})
surface.CreateFont("nCD_Trebutchet", {font = "Trebuchet MS",
                                   size = 22,
                                   weight = 900})

cl_nCD = cl_nCD or {}

function cl_nCD.DrawNPCInfo()
	local Ents = ents.FindByClass('neths_car_dealer')
	for i, ent in pairs (Ents) do
		if ent:IsValid() then
			if ent:GetPos():Distance(LocalPlayer():GetPos()) < 400 then
				local Pos = ent:GetPos()+Vector(0,0,75) or (Vector(0, 0, 0))
				local Ang = ent:GetAngles() or Angle(0, 0, 0)

				Ang:RotateAroundAxis( Ang:Forward(), 90)
				Ang:RotateAroundAxis( Ang:Right(), -90)
			
				cam.Start3D2D(Pos + Ang:Up() * 1.2, Ang, 0.055)
					draw.SimpleTextOutlined( 'Car Dealer', 'CarDealerTitle', 0, 0, sh_nCD.Config.MenuOutlineColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255))			
				cam.End3D2D()
			end
		end
	end
end
hook.Add('PostDrawOpaqueRenderables', 'DrawNPCInfo', cl_nCD.DrawNPCInfo)

function cl_nCD.OpenMenu()
	local Wallet = tonumber(LocalPlayer().DarkRPVars.money)
	local CarDealer = net.ReadEntity()
	
	cl_nCD.Menu = vgui.Create('DFrame')
	cl_nCD.Menu:SetSize(400, 600)
	cl_nCD.Menu:Center()
	cl_nCD.Menu:MakePopup()
	cl_nCD.Menu.lblTitle:SetText('')
	cl_nCD.Menu.Paint = function( self )
    	draw.RoundedBox( 6, 0, 0, self:GetWide(), self:GetTall(), sh_nCD.Config.MenuOutlineColor )
    	draw.RoundedBox( 6, 1, 1, self:GetWide()-2, self:GetTall()-2, Color( 35, 35, 35, 255 ) )
    end
    cl_nCD.Menu.btnMinim:Hide()
    cl_nCD.Menu.btnMaxim:Hide()

	local LogoPanel = vgui.Create('DPanel', cl_nCD.Menu)
	LogoPanel:SetSize( 350, 40 )
	LogoPanel:SetPos( 25, 30)
	LogoPanel:CenterHorizontal()
	LogoPanel.Paint = function( self )
		draw.RoundedBox( 6, 0, 0, self:GetWide(), self:GetTall(), sh_nCD.Config.MenuOutlineColor )
    	draw.RoundedBox( 6, 1, 1, self:GetWide()-2, self:GetTall()-2, Color( 50, 50, 50, 255 ) )
	end

    local MainLabel = vgui.Create('DLabel', LogoPanel)
    MainLabel:SetFont('DefaultBoldTahoma')
    MainLabel:SetText('Car Shop')
    MainLabel:SizeToContents()
    MainLabel:SetColor(sh_nCD.Config.MenuOutlineColor)
    MainLabel:SetPos( 0, 0 )
    MainLabel:CenterHorizontal()

    local ScrollPanel = vgui.Create( "DScrollPanel", cl_nCD.Menu )
	ScrollPanel:SetSize( 390, 520 )
	ScrollPanel:SetPos( 5, 75 )
	ScrollPanel.Paint = function( self )
		draw.RoundedBox( 6, 0, 0, self:GetWide(), self:GetTall(), sh_nCD.Config.MenuOutlineColor  )
    	draw.RoundedBox( 6, 1, 1, self:GetWide()-2, self:GetTall()-2, Color( 75, 75, 75, 255 ) )
	end

	local CarList = vgui.Create( "DIconLayout", ScrollPanel )
	CarList:SetSize( 375, 515 )
	CarList:SetPos( 1, 1 )
	CarList:SetSpaceY( 1 )
	CarList:SetSpaceX( 0 )

	for i, carTbl in pairs (sh_nCD.Cars) do
		local CostColor = sh_nCD.Config.MenuOutlineColor
		if carTbl.CarPrice > Wallet then
			CostColor = Color( 100, 100, 100, 255 )
			if sh_nCD.Config.PermamentCars == true then
				for k, v in pairs (cl_nCD.PlayerCars) do
					if v == i then
						CostColor = sh_nCD.Config.MenuOutlineColor
						break
					end
				end
			end
		end

		local CarPanel = vgui.Create('DPanel', CarList)
		CarPanel:SetSize( 375, 200 )
		CarPanel.Paint = function( self )
			draw.RoundedBox( 6, 0, 0, self:GetWide(), self:GetTall(), Color( 35, 35, 35, 255 ) )
		end

		local CarName = vgui.Create('DLabel', CarPanel)
		CarName:SetFont('nCD_Trebutchet')
		CarName:SetText( carTbl.CarName )
		CarName:SetColor(CostColor)
		CarName:SizeToContents()
		CarName:SetPos( 5, 5)
		for number, carOwned in pairs (cl_nCD.PlayerCars) do
			if carOwned == i then
				CarName:SetText( carTbl.CarName..' (Owned)' )
				CarName:SizeToContents()
			end
		end

		PriceLabel = vgui.Create('DLabel', CarPanel)
		PriceLabel:SetFont('nCD_Trebutchet')
	    PriceLabel:SetText( "$"..carTbl.CarPrice )
	    PriceLabel:SetColor(CostColor)
	    PriceLabel:SizeToContents()
	    surface.SetFont('nCD_Trebutchet')
	    local AlignSize = surface.GetTextSize( "$"..carTbl.CarPrice )
	    PriceLabel:SetPos( 370-AlignSize, 5 )

	    local ModelPanel = vgui.Create('DPanel', CarPanel)
	    ModelPanel:SetSize( 360, 160 )
	    ModelPanel:SetPos( 7.5, 35 )
	    ModelPanel.Paint = function( self )
			draw.RoundedBox( 6, 0, 0, self:GetWide(), self:GetTall(), CostColor)
    		draw.RoundedBox( 6, 1, 1, self:GetWide()-2, self:GetTall()-2, Color( 50, 50, 50, 255 ) )
		end
		ModelPanel.ModelPres = nil

		if carTbl.GroupOnly then
			local GroupOnlyName = vgui.Create('DLabel', ModelPanel)
			GroupOnlyName:SetFont('DermaDefaultBold')
			GroupOnlyName:SetText( 'Restricted to: '.. string.Implode( ', ', carTbl.GroupOnly ) )
			GroupOnlyName:SetPos( 5, 5 )
			GroupOnlyName:SetColor( Color( 235, 0, 0, 255 ) )
			GroupOnlyName:SizeToContents()

			local IsGroupMember = false
			for num, groupName in pairs (carTbl.GroupOnly) do
				if LocalPlayer():IsUserGroup(groupName) then
					IsGroupMember = true
					GroupOnlyName:SetColor(Color( 0, 235, 0, 255))
					break
				end
			end
			if not IsGroupMember then
				CarName:SetColor( Color( 75, 75, 75, 255) )
				PriceLabel:SetColor( Color( 75, 75, 75, 255) )
				ModelPanel.Paint = function( self )
					draw.RoundedBox( 6, 0, 0, self:GetWide(), self:GetTall(), Color( 75, 75, 75, 255 ) )
	    			draw.RoundedBox( 6, 1, 1, self:GetWide()-2, self:GetTall()-2, Color( 50, 50, 50, 255 ) )
				end
			end
		end

		local Vehicle = list.Get('Vehicles')[i] or nil
		if Vehicle then
			ModelPanel.ModelPres = vgui.Create('DModelPanel', ModelPanel)
			ModelPanel.ModelPres:SetSize( ModelPanel:GetWide(), ModelPanel:GetTall() )
			ModelPanel.ModelPres:SetModel(Vehicle.Model)
			ModelPanel.ModelPres:SetCamPos(Vector( 300, 0, 75))
			ModelPanel.ModelPres:SetLookAt(Vector( 0, 0, 35))
			ModelPanel.ModelPres:NoClipping(true)
			local oldPaint = DModelPanel.Paint
			ModelPanel.ModelPres.Paint = function( self )
				local x, y = self:LocalToScreen( 0, 0 )
				local w, h = self:GetSize()
				 
				local sl, st, sr, sb = x, y, x + w, y + h
				 
				local p = self
				while p:GetParent() do
					p = p:GetParent()
					local pl, pt = p:LocalToScreen( 0, 0 )
					local pr, pb = pl + p:GetWide(), pt + p:GetTall()
					sl = sl < pl and pl or sl
					st = st < pt and pt or st
					sr = sr > pr and pr or sr
					sb = sb > pb and pb or sb
				end
				 
				render.SetScissorRect( sl, st, sr, sb, true )
				oldPaint(self)
				render.SetScissorRect( 0, 0, 0, 0, false )
			end
			ModelPanel.ModelPres.DoClick = function()
				cl_nCD.Menu:Close()
				net.Start('NET_NCD_BuyCar')
					net.WriteEntity(LocalPlayer())
					net.WriteEntity(CarDealer)
					net.WriteString( i )
					net.WriteTable( ModelPanel.ModelPres.Entity:GetColor() )
				net.SendToServer()
			end
		end

		local SellButton = vgui.Create('DButton', ModelPanel)
		SellButton:SetText('Sell')
		SellButton:SetSize( 40, 20 )
		SellButton:SetPos( 5, 135 )
		SellButton.Paint = function( self )
			draw.RoundedBox( 6, 0, 0, self:GetWide(), self:GetTall(), CostColor)
			draw.RoundedBox( 6, 1, 1, self:GetWide()-2, self:GetTall()-2, Color( 50, 50, 50, 255 ) )
		end
		SellButton.DoClick = function( )
			for number, carOwned in pairs (cl_nCD.PlayerCars) do
				if carOwned == i then
					cl_nCD.Menu:Close()
					net.Start('NET_NCD_SellCar')
						net.WriteEntity(LocalPlayer())
						net.WriteString( i )
					net.SendToServer()
				end
			end
		end

		local ColorButton = vgui.Create('DButton', ModelPanel)
		ColorButton:SetText('Color')
		ColorButton:SetSize( 40, 20 )
		ColorButton:SetPos( 47, 135 )
		ColorButton.Paint = function( self )
			draw.RoundedBox( 6, 0, 0, self:GetWide(), self:GetTall(), CostColor)
			draw.RoundedBox( 6, 1, 1, self:GetWide()-2, self:GetTall()-2, Color( 50, 50, 50, 255 ) )
		end
		ColorButton.DoClick = function( self )
			if carTbl.Paintable == true then
				local CarView = ModelPanel.ModelPres
				ColorButton.ColorSelection = vgui.Create('DFrame')
				ColorButton.ColorSelection:SetSize( 200, 150 )
				ColorButton.ColorSelection:SetTitle('Color Selection')
				ColorButton.ColorSelection:SetPos(cl_nCD.Menu.x-200, cl_nCD.Menu.y)
				ColorButton.ColorSelection:MakePopup()
				ColorButton.ColorSelection.btnMinim:Hide()
    			ColorButton.ColorSelection.btnMaxim:Hide()
    			ColorButton.ColorSelection.Paint = function( self )
					draw.RoundedBox( 6, 0, 0, self:GetWide(), self:GetTall(), CostColor)
					draw.RoundedBox( 6, 1, 1, self:GetWide()-2, self:GetTall()-2, Color( 50, 50, 50, 255 ) )
				end
				local Mixer = vgui.Create( "DColorMixer", ColorButton.ColorSelection )
				Mixer:Dock( FILL )
				Mixer:SetPalette( false )
				Mixer:SetAlphaBar( false )
				Mixer:SetWangs( false )
				Mixer.Think = function( self )
					if not ModelPanel.ModelPres then 
						self:GetParent():Close()
					else
						ModelPanel.ModelPres.Entity:SetColor(self:GetColor())
						ModelPanel.ModelPres:SetColor(self:GetColor())
					end
				end
			end
		end

	end
end
net.Receive('NET_NCD_OpenMenu', cl_nCD.OpenMenu)

net.Receive('NET_NCD_SendCars', function()
	local NCD = net.ReadTable()
	PrintTable(NCD)
	LocalPlayer().NCD = NCD
	cl_nCD.PlayerCars = NCD.Cars
end)