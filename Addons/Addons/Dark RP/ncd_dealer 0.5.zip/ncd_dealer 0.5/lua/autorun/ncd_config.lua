sh_nCD = {}

sh_nCD.Config = {}
sh_nCD.Config.PermamentCars = true			-- 'true' will make cars save in database, so person doesn't have to buy them over and over again
sh_nCD.Config.CarSellPercentage = 0.75 		-- % of car price you get while selling a car
sh_nCD.Config.MenuOutlineColor = Color( 145, 235, 0, 255 ) -- Obvious
sh_nCD.Config.CarReturnRange = 400			-- Range in which old car has to be in order to repleace it with a new one

sh_nCD.Cars = {}
sh_nCD.Cars['escaladetdm'] 		= { CarName = 'A', 		CarPrice = 245000,	Paintable = true,	GroupOnly = {'vip'} }
sh_nCD.Cars['murcielagotdm'] 	= { CarName = 'B', 		CarPrice = 100000,	Paintable = true, 	TeamOnly = 'Civil Protection'}
sh_nCD.Cars['rx8tdm'] 			= { CarName = 'C', 		CarPrice = 150000,	Paintable = true}
sh_nCD.Cars['h1tdm'] 			= { CarName = 'D', 		CarPrice = 55,		Paintable = true}


--sh_nCD.Cars['ScriptName'] = { CarName = 'CarName', CarPrice = 1000, GroupOnly = { 'admin' } }
//**Explanation:
//ScriptName 	- You put a name of script in here, it can be found in Q menu, simply go Q > Vehicles > Right mouse button on icon of vehicle you want to add > Copy to clipboard
//CarName 		- Name of car that'll be displaying, pretty obvious
//CarPrice		- fo' real ?
//GroupOnly		- If it's added, vehicle will be limited to the members of certain groups

if SERVER then
	util.AddNetworkString('NET_NCD_SendCars')

	sv_nCD = {}

	function sv_nCD.PrepareDB()
		if not sql.TableExists('ncd_savedcars') then
			sql.Query('CREATE TABLE ncd_savedcars ( id TEXT, cars TEXT )')
		end
	end
	hook.Add('Initialize', 'PrepDB', sv_nCD.PrepareDB )

	function sv_nCD.ResetCars( ply )
		ply.NCD.Cars = {}
		sv_nCD.SaveCars( ply )
		sv_nCD.SendCars( ply )
	end

	function sv_nCD.LoadCars( ply )
		if not ply:IsValid() then return end
		ply.NCD = {}
		ply.NCD.Cars = {}

		local DB_Result = sql.Query("SELECT * FROM ncd_savedcars WHERE id ='"..ply:SteamID().."'")
		if DB_Result then
			if DB_Result[1].cars != "" then
				ply.NCD.Cars = util.JSONToTable(DB_Result[1].cars)
			else
				ply.NCD.Cars = {}
			end
			sv_nCD.SendCars( ply )
		else
			sql.Query( "INSERT INTO ncd_savedcars ( 'id', 'cars') VALUES ('"..ply:SteamID().."', '')" )
			sv_nCD.LoadCars( ply )
		end
	end
	hook.Add('PlayerInitialSpawn', 'LoadCars', sv_nCD.LoadCars)

	function sv_nCD.SendCars( ply )
		net.Start('NET_NCD_SendCars')
			net.WriteTable( ply.NCD )
		net.Send( ply )
	end
	hook.Add('PlayerInitialSpawn', 'LoadCars', sv_nCD.LoadCars)

	function sv_nCD.SaveCars( ply )
		sql.Query("UPDATE ncd_savedcars SET cars = "..sql.SQLStr( util.TableToJSON( ply.NCD.Cars ) ).." WHERE id = '"..ply:SteamID().."'")
	end
end