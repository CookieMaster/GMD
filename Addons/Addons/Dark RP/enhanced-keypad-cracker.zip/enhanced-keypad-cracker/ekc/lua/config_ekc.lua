
	DelMods = DelMods or {}
	DelMods.cracker = {
		chance_to_break = 10, // Percentage chance of breaking completely
		chance_to_fail = 20, // Percentage chance of failing without breaking
		min_break_time = 15, // Min time broken
		max_break_time = 120, // Max time broken
		min_time = 2, // Minimum time it'll spend cracking in seconds
		max_time = 15, // Maximum time it'll spend cracking in seconds
	}