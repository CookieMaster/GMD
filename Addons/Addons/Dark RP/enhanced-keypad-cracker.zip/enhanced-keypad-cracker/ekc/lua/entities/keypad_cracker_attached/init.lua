AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include("shared.lua")
include("../../config_ekc.lua")

function ENT:Initialize()
	self.Entity:SetModel( "models/weapons/w_c4_planted.mdl" )
	self.Entity:PhysicsInit( SOLID_VPHYSICS )
	self.Entity:SetMoveType( MOVETYPE_VPHYSICS )
	self.Entity:SetSolid( SOLID_VPHYSICS )
	self.Entity:SetUseType( SIMPLE_USE )
	self.Entity:SetCollisionGroup( COLLISION_GROUP_WEAPON )
	self.attached_to_keypad = NULL

	local phys = self.Entity:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:Wake()
	end
end

function ENT:Use(activator, caller)
	if IsValid(self:GetNWEntity("cracking")) then
		if self.SID == activator.SID or self:GetNWEntity("cracking").Owner == activator then
			self:Detach()
		end
	else
		if IsValid(activator) and activator:IsPlayer() then
			// PlayerCanPickupWeapon requires the real weapon entity, as such, I have to create it just to test it. Silly fucking thing.
			local test_cracker = ents.Create("keypad_cracker")
			if hook.Call("PlayerCanPickupWeapon", GAMEMODE, activator, test_cracker) then
				self:Remove()
				activator:Give("keypad_cracker")
			end
			test_cracker:Remove()
		end
	end
end

function ENT:Attach(keypad)
	if IsValid(keypad) and keypad:GetClass() == "sent_keypad" then
		if keypad:GetNWBool("keypad_broken") then return end
		if keypad.being_cracked then return end
		self:SetPos(keypad:GetPos() + keypad:GetForward() - (keypad:GetUp() * .7) - (keypad:GetRight() * .7))
		local angle = keypad:GetAngles() 
		angle:RotateAroundAxis(keypad:GetUp(), 90)
		angle:RotateAroundAxis(keypad:GetForward(), 180) 
		angle:RotateAroundAxis(keypad:GetRight(), 90)
		self:SetAngles(angle)
		
		self:GetPhysicsObject():EnableMotion(false)
		
		keypad:CallOnRemove("keypad_cracker_attached", function(ent, cracker)
			if IsValid(cracker) then
				cracker:Detach()
			end
		end, self)
		
		self:SetNWEntity("cracking", keypad)
		keypad.being_cracked = true
		self:EmitSound("weapons/c4/c4_plant.wav")
		timer.Create("keypadcracker"..tostring(self:EntIndex()), math.random(DelMods.cracker.min_time, DelMods.cracker.max_time), 1, function()
			if IsValid(self) and IsValid(keypad) and IsValid(self:GetNWEntity("cracking")) then
				local chance = math.random(1, 100)
				if chance <= DelMods.cracker.chance_to_break then
					keypad:Fail()
					keypad:Break()
				elseif chance <= DelMods.cracker.chance_to_break + DelMods.cracker.chance_to_fail then
					keypad:Fail()
				else
					keypad:Success()
				end
				self:Detach()
			end
		end)
	end
end

function ENT:Detach()
	if IsValid(self:GetNWEntity("cracking")) then 
		self:GetNWEntity("cracking"):RemoveCallOnRemove("keypad_cracker_attached")
		self:GetNWEntity("cracking").being_cracked = false
	end
	self:GetPhysicsObject():EnableMotion(true)
	self:GetPhysicsObject():Wake()
	self:SetNWEntity("cracking", NULL)
	self:EmitSound("weapons/c4/c4_disarm.wav")
end