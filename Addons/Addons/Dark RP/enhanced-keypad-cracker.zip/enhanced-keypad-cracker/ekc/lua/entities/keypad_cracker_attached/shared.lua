ENT.Type			= "anim"
ENT.Base			= "base_gmodentity"

ENT.PrintName		= "Keypad cracker (attached)"
ENT.Author			= "Dellkan"
ENT.Contact			= "sammyservers.com"
ENT.Purpose			= ""
ENT.Instructions	= ""

ENT.Spawnable		= false
ENT.AdminSpawnable	= false

util.PrecacheSound("weapons/c4/c4_disarm.wav")
util.PrecacheSound("weapons/c4/c4_plant.wav")