AddCSLuaFile()

ENT.Type = "anim"

ENT.Spawnable = false
ENT.AdminSpawnable = true

ENT.Model = "models/props_c17/TrapPropeller_Lever.mdl"
ENT.HitSound = Sound( "ambient/energy/spark5.wav" )

// Configs for taser 
ENT.MissTime = 3 --Seconds
ENT.TaseTime = 5 --Seconds

ENT.TeamBlacklist = { --Doesn't hit these teams
	[TEAM_POLICE] = true,
	[TEAM_CHIEF] = true,
	[TEAM_MAYOR] = true,
	[TEAM_SWAT] = true,
}

// Add any ragdoll models into this you want, these are just the ones I have
// Done for you, anything not in the table will be defaulted to a set model
ENT.WhiteList = { --Models whitelist, to prevent bad models
	--Anything not in the table is assumed to be false
	--Human Characters
	["models/kleiner.mdl"] = true,
	["models/mossman.mdl"] = true,
	["models/alyx.mdl"] = true,
	["models/barney.mdl"] = true,
	["models/breen.mdl"] = true,
	["models/eli.mdl"] = true,
	["models/gman_high.mdl"] = true,
	["models/monk.mdl"] = true,
	["models/odessa.mdl"] = true,
	--Citizens
	["models/humans/group01/female_01.mdl"] = true,
	["models/humans/group01/female_02.mdl"] = true,
	["models/humans/group01/female_03.mdl"] = true,
	["models/humans/group01/female_04.mdl"] = true,
	["models/humans/group01/female_05.mdl"] = true,
	["models/humans/group01/female_06.mdl"] = true,
	["models/humans/group01/female_07.mdl"] = true,
	["models/humans/group01/male_01.mdl"] = true,
	["models/humans/group01/male_02.mdl"] = true,
	["models/humans/group01/male_03.mdl"] = true,
	["models/humans/group01/male_04.mdl"] = true,
	["models/humans/group01/male_05.mdl"] = true,
	["models/humans/group01/male_06.mdl"] = true,
	["models/humans/group01/male_07.mdl"] = true,
	["models/humans/group01/male_08.mdl"] = true,
	["models/humans/group01/male_09.mdl"] = true,
	["models/humans/group01/male_cheaple.mdl"] = true, --Is this neccessary?
	["models/humans/group02/female_01.mdl"] = true,
	["models/humans/group02/female_02.mdl"] = true,
	["models/humans/group02/female_03.mdl"] = true,
	["models/humans/group02/female_04.mdl"] = true,
	["models/humans/group02/female_05.mdl"] = true,
	["models/humans/group02/female_06.mdl"] = true,
	["models/humans/group02/female_07.mdl"] = true,
	["models/humans/group02/male_01.mdl"] = true,
	["models/humans/group02/male_02.mdl"] = true,
	["models/humans/group02/male_03.mdl"] = true,
	["models/humans/group02/male_04.mdl"] = true,
	["models/humans/group02/male_05.mdl"] = true,
	["models/humans/group02/male_06.mdl"] = true,
	["models/humans/group02/male_07.mdl"] = true,
	["models/humans/group02/male_08.mdl"] = true,
	["models/humans/group02/male_09.mdl"] = true,
	--Resistance
	["models/humans/group03/female_01.mdl"] = true,
	["models/humans/group03/female_02.mdl"] = true,
	["models/humans/group03/female_03.mdl"] = true,
	["models/humans/group03/female_04.mdl"] = true,
	["models/humans/group03/female_05.mdl"] = true,
	["models/humans/group03/female_06.mdl"] = true,
	["models/humans/group03/female_07.mdl"] = true,
	["models/humans/group03/male_01.mdl"] = true,
	["models/humans/group03/male_02.mdl"] = true,
	["models/humans/group03/male_03.mdl"] = true,
	["models/humans/group03/male_04.mdl"] = true,
	["models/humans/group03/male_05.mdl"] = true,
	["models/humans/group03/male_06.mdl"] = true,
	["models/humans/group03/male_07.mdl"] = true,
	["models/humans/group03/male_08.mdl"] = true,
	["models/humans/group03/male_09.mdl"] = true,
	["models/Humans/group03m/female_01.mdl"] = true,
	["models/Humans/group03m/female_02.mdl"] = true,
	["models/Humans/group03m/female_03.mdl"] = true,
	["models/Humans/group03m/female_04.mdl"] = true,
	["models/Humans/group03m/female_05.mdl"] = true,
	["models/Humans/group03m/female_06.mdl"] = true,
	["models/Humans/group03m/female_07.mdl"] = true,
	["models/humans/group03m/male_01.mdl"] = true,
	["models/humans/group03m/male_02.mdl"] = true,
	["models/humans/group03m/male_03.mdl"] = true,
	["models/humans/group03m/male_04.mdl"] = true,
	["models/humans/group03m/male_05.mdl"] = true,
	["models/humans/group03m/male_06.mdl"] = true,
	["models/humans/group03m/male_07.mdl"] = true,
	["models/humans/group03m/male_08.mdl"] = true,
	["models/humans/group03m/male_09.mdl"] = true,
	--Combine
	["models/combine_super_soldier.mdl"] = true,
	["models/combine_soldier_prisonguard.mdl"] = true,
	["models/combine_soldier.mdl"] = true,
	["models/police.mdl"] = true,
	["models/police_cheaple.mdl"] = true, --Is this neccessary?
	--Human corpses
	["models/humans/charple01.mdl"] = true,
	["models/humans/charple02.mdl"] = true,
	["models/humans/charple03.mdl"] = true,
	["models/humans/charple04.mdl"] = true,
	["models/humans/corpse1.mdl"] = true,
}
// Set the defaulted ragdoll model here
ENT.DefaultRagdoll = "models/humans/group01/male_01.mdl"

function ENT:SetupDataTables()
	self:NetworkVar( "Int", 0, "Damage" )
end

function ENT:Initialize()
	self:SetModel( self.Model )
	
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:PhysicsInit( SOLID_VPHYSICS )
	
	--self:PhysWake()
	
	self:SetModelScale( 0.5, 0 )
	self:SetDamage(0)
	
	hook.Add( "ShouldCollide", self, self.ShouldCollide )
	self:SetCustomCollisionCheck( true )
	
	timer.Simple( 10, function()
		if IsValid(self) and (not self.HasHitTarget) then self:Remove() end
	end)
end

local function RagdollTakeDmg( self, rag, dmginfo )
	if rag~=self then return end
	
	self.Owner:TakeDamageInfo( dmginfo )
end

function ENT:PhysicsCollide( data, physnum )
	local tme = self.MissTime
	
	if IsValid(data.HitEntity) then
		if data.HitEntity:IsPlayer() and self.TeamBlacklist[ data.HitEntity:Team() ] then return end
		
		local tr = util.TraceLine({start=self:GetPos(), endpos=data.HitEntity:LocalToWorld(data.HitEntity:OBBCenter()), filter={self.Entity, self.Owner}, mask=MASK_SHOT_HULL})
		if tr.MatType==MAT_METAL or tr.MatType==MAT_GRATE then
			self.HitCount = self.HitCount and self.HitCount+1 or 1
			if self.HitCount<3 then
				local ef = EffectData()
				ef:SetOrigin( data.HitPos )
				ef:SetNormal( data.HitNormal )
				ef:SetStart( data.HitPos )
				ef:SetEntity( ent )
				ef:SetMagnitude( 2 )
				
				util.Effect( "Sparks", ef, true, true )
				util.Effect( "TeslaHitBoxes", ef, true, true )
				if not data.HitEntity:IsPlayer() then return end
			end
		end
		
		local ent = data.HitEntity
		
		local ply
		if ent:IsPlayer() then
		
			local effect = ent
			effect:ConCommand("pp_motionblur 1")  
			effect:ConCommand("pp_motionblur_addalpha 0.05")  
			effect:ConCommand("pp_motionblur_delay 0.035")  
			effect:ConCommand("pp_motionblur_drawalpha 1.00")  
			effect:ConCommand("pp_dof 1")  
			effect:ConCommand("pp_dof_initlength 9")  
			effect:ConCommand("pp_dof_spacing 8")
			
			timer.Simple(10, function()
			
				effect:ConCommand("pp_motionblur 0")    
				effect:ConCommand("pp_dof 0")  
				
			end)
			tme = self.TaseTime
			if not ent:isArrested() then
				ent.PreTaseWeapons = {}
				for k,v in pairs(ent:GetWeapons()) do
					ent.PreTaseWeapons[k] = {v:GetClass(), ent:GetAmmoCount(v:GetPrimaryAmmoType()), v:GetPrimaryAmmoType(), ent:GetAmmoCount(v:GetSecondaryAmmoType()), v:GetSecondaryAmmoType(), v:Clip1(), v:Clip2()}
				end
			end
			local ragdoll = ents.Create("prop_ragdoll")
			ragdoll:SetPos(ent:GetPos())
			ragdoll:SetAngles(Angle(0,ent:GetAngles().Yaw,0))
			
			local model = ent:GetModel()
			if string.lower(model) == "models/player/corpse1.mdl" then model = "models/Humans/corpse1.mdl" end
			if not self.WhiteList[ string.lower(model) ] then model = self.DefaultRagdoll end
			ragdoll:SetModel(model)
			ragdoll:Spawn()
			ragdoll:Activate()
			ragdoll:SetCollisionGroup( COLLISION_GROUP_WORLD )
			
			ragdoll:SetColor( ent:GetColor() )
			ragdoll.IsTasedRagdoll = true
			ragdoll.Owner = ent
			
			ragdoll:SetVelocity(ent:GetVelocity())
			ragdoll.PhysgunPickup = false
			ragdoll.CanTool = false
			
			hook.Add( "EntityTakeDamage", ragdoll, RagdollTakeDmg )
			
			ent:GetTable().BeforeSleepTeam = ent:Team()
			
			local OldMove = ent:GetMoveType()
			local OldColl = ent:GetCollisionGroup()
			ent:SetMoveType( MOVETYPE_NONE )
			ent:SetCollisionGroup( COLLISION_GROUP_WORLD )
			ent:StripWeapons()
			--player:Spectate(OBS_MODE_CHASE)
			--player:SpectateEntity(ragdoll)
			ent.IsSleeping = true
			ent.tased = true
			ent.TasedRag = ragdoll
			--player.SleepRagdoll = ragdoll
			ent.KnockoutTimer = CurTime() +  30
			ragdoll:CPPISetOwner(ent)
			
			--SendUserMessage("blackScreen", ent, true)
			
			ent.Sleeping = true
			ent:SetNoDraw( true )
			
			ply = ent
			timer.Simple( tme, function()
				if not (IsValid(ply) and ply.tased) then return end
				
				ply.tased = false
				ply:SetNoDraw( false )
				ply.OldHunger = ply:getDarkRPVar("Energy")
				local health = ply:Health()
				local armor = ply:Armor()
				local pos,ang, mdl = ply:GetPos(), ply:GetAngles(), ply:GetModel()
				ply:Spawn()
				ply:SetPos(pos) ply:SetAngles( ang ) ply:SetModel( mdl )
				
				ply:SetHealth(health)
				ply:SetArmor(armor)
				ply:StripWeapons()
				if IsValid(ragdoll) then ragdoll:Remove() end
				if ply.PreTaseWeapons and ply:GetTable().BeforeSleepTeam == ply:Team() then
					for k,v in pairs(ply.PreTaseWeapons) do
						local wep = ply:Give(v[1])
						ply:RemoveAllAmmo()
						ply:SetAmmo(v[2], v[3], false) ply:SetAmmo(v[4], v[5], false)
						
						wep:SetClip1(v[6]) wep:SetClip2(v[7])
					end
					local cl_defaultweapon = ply:GetInfo("cl_defaultweapon")
					if ply:HasWeapon( cl_defaultweapon ) then ply:SelectWeapon( cl_defaultweapon ) end
					ply:GetTable().BeforeSleepTeam = nil
				else
					GAMEMODE:PlayerLoadout(ply)
				end
				
				SendUserMessage("blackScreen", ply, false)
				
				ply.Sleeping = false
				ply:setDarkRPVar("Energy", ply.OldHunger)
				ply.OldHunger = nil
				
				if ply:isArrested() then GAMEMODE:SetPlayerSpeed(ply, GAMEMODE.Config.arrestspeed, GAMEMODE.Config.arrestspeed ) end
			end)
			
			ent=ragdoll
		end
		
		self:SetPos( data.HitPos-data.HitNormal*1 )
		self:SetAngles( data.HitNormal:Angle() )
		self:SetMoveType( MOVETYPE_NONE )
		self:SetCollisionGroup( COLLISION_GROUP_WORLD )
		self:SetParent( ent )
		
		
		local phys = ent:GetPhysicsObject()
		if phys then
			phys:SetVelocity( data.TheirOldVelocity )
		else
			ent:SetVelocity( data.TheirOldVelocity )
		end
		
		local ef = EffectData()
		ef:SetOrigin( data.HitPos )
		ef:SetNormal( data.HitNormal )
		ef:SetStart( data.HitPos )
		ef:SetEntity( ent )
		ef:SetMagnitude( 2 )
		
		util.Effect( "Sparks", ef, true, true )
		util.Effect( "TeslaHitBoxes", ef, true, true )
		
		sound.Play( self.HitSound, data.HitPos, 75, 100 )
		
		timer.Simple( tme, function() if IsValid(self) then
			self:SetMoveType( MOVETYPE_NOCLIP )
			self:SetSolid( SOLID_NONE )
			self:SetParent( nil )
			self.Retracting = true
			hook.Add( "Tick", self, self.Tick )
		end end)
		
		if ply then ply:TakeDamage( self:GetDamage(), self:GetOwner(), self ) else ent:TakeDamage( self:GetDamage(), self:GetOwner(), self ) end
	else
		self:SetPos( data.HitPos-data.HitNormal*3 )
		self:SetAngles( data.HitNormal:Angle() )
		self:SetMoveType( MOVETYPE_NONE )
		
		local ef = EffectData()
		ef:SetOrigin( data.HitPos )
		ef:SetNormal( data.HitNormal )
		ef:SetStart( data.HitPos )
		ef:SetMagnitude( 2 )
		
		util.Effect( "Sparks", ef, true, true )
		sound.Play( self.HitSound, data.HitPos, 75, 100 )
		
		timer.Simple( tme, function() if IsValid(self) then
			self:SetMoveType( MOVETYPE_NOCLIP )
			self:SetSolid( SOLID_NONE )
			self.Retracting = true
			hook.Add( "Tick", self, self.Tick )
		end end)
	end
	
	self.HasHitTarget = true
end

function ENT:Think()
	if SERVER then
		if not self.Fired then
			local phys = self:GetPhysicsObject()
			if IsValid(phys) then
				phys:SetVelocity( self.FireVelocity )
				self.Fired = true
			else
				self:PhysWake()
				local phys = self:GetPhysicsObject()
				phys:SetVelocity( self.FireVelocity )
				self.Fired = true
			end
		end
	end
end

function ENT:Tick()
	if not self.Retracting then return end
	if not IsValid( self.Weapon ) then self:Remove() return end
	
	local Target = IsValid(self.Weapon.Owner) and self.Weapon.Owner:GetShootPos() or self.Weapon:GetPos()
	local dir = (Target - self:GetPos()):GetNormal()
	
	self:SetAngles( dir:Angle() )
	
	self:SetVelocity( dir*200 )
	
	if self:GetPos():Distance( Target ) < 150 then self:Remove() return end
end

function ENT:ShouldCollide( ent1, ent2 )
	if ent1~=self and ent2~=self then return end
	local other = ent1==self and ent2 or ent1
	
	if not (IsValid(other) and other:IsPlayer()) then return end
	if self.TeamBlacklist[ other:Team() ] then return false end
end

hook.Add( "CanPlayerSuicide", "Taser CanSuicide", function( ply ) if IsValid(ply) and ply.tased then return false end end)
hook.Add( "DoPlayerDeath", "Taser DoDeath", function(ply)
	if IsValid(ply) and ply.tased then
		ply.tased = false
		if IsValid( ply.TasedRag ) then ply.TasedRag:Remove() end
	end
end)