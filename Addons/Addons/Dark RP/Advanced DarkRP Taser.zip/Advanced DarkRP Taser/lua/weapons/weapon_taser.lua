SWEP.Base = "weapon_base"

SWEP.Author			= "Imarijuanaman"
SWEP.Contact		= ""
SWEP.Purpose		= "Fires a projectile to stun a player"
SWEP.Instructions	= "Left click to fire, right click to damage hit entity"

SWEP.Spawnable			= false
SWEP.AdminOnly			= true
SWEP.UseHands			= false

SWEP.ViewModel			= "models/weapons/c_pistol.mdl" -- DO NOT CHANGE TO VIEW MODEL
SWEP.WorldModel			= "models/weapons/w_pistol.mdl"

SWEP.UseHands = true

SWEP.Primary.Ammo = -1
SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1
SWEP.Primary.Delay			= 1
SWEP.Primary.Range			= 500
SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "none"

SWEP.Secondary.Damage = 5 -- Change how much damage the swep's shocker does
SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"
SWEP.Secondary.Delay			= 0.5
SWEP.ZapSound = Sound( "ambient/energy/spark5.wav" )

SWEP.Weight				= 5
SWEP.AutoSwitchTo		= false
SWEP.AutoSwitchFrom		= false

SWEP.PrintName			= "Taser"
SWEP.Slot				= 3
SWEP.SlotPos			= 1
SWEP.DrawAmmo			= false
SWEP.DrawCrosshair		= true

// DO NOT EDIT
function SWEP:Initialize()
	self.NextThinks = CurTime() + 0.25
	self:SetCharge( 0 )
end

if CLIENT then surface.CreateFont( "Akbar5", {font = "Segoe UI", size = 21, weight = 1500} ) end
local HookCable = Material( "cable/blue_elec" )
function SWEP:DrawHUD()
	if (not LocalPlayer():Alive()) then return false end
	
	local charge = self:GetCharge()
	local coulor = Color( 255 - ( charge * 2.55 ), charge * 2.55, 0, 255 )
	local w = ScrW() - 200
	local h = ScrH() - 80
	draw.RoundedBox( 8, w - 5, h - 5, 175, 41, Color( 0, 0, 0, 255 ) )
	draw.RoundedBox( 8, w, h, 165, 31, Color( 255, 255, 255, 150 ) )
	draw.RoundedBox( 1, w + 8, h + 5, 150, 7, Color( 0, 0, 0, 50 ) )
	draw.RoundedBox( 1, w + 8, h + 5, charge * 1.5, 7, coulor )
	draw.WordBox( 8, w + 35, h + 2, "Reload : "..math.Round(charge).."%","Akbar5",Color(255,255,255,1),Color(255,255,255,255))
	
		local vm = IsValid(self.Owner) and self.Owner:GetViewModel()
		if IsValid(vm) then
			vm:SetMaterial( "phoenix_storms/stripes" )
		end
		
		if IsValid(self:GetBolt()) and IsValid(self.Owner) then
			render.SetMaterial( HookCable )
			
			local att
			if IsValid(vm) then att = vm:GetAttachment( 1 ) end
			
			cam.Start3D( EyePos(), EyeAngles() )
				if IsValid(vm) and att then
					render.DrawBeam( self:GetBolt():GetPos(), att.Pos, 1, 0, 2, Color(255,255,255,255) )
				else
					render.DrawBeam( self:GetBolt():GetPos(), self:GetPos(), 1, 0, 2, Color(255,255,255,255) )
				end
			cam.End3D()
		end
end

local ShootSound = Sound( "weapons/mortar/mortar_fire1.wav" )

function SWEP:SetupDataTables()
	self:NetworkVar( "Entity", 0, "Bolt" )
	self:NetworkVar( "Int", 0, "Charge" )
end

function SWEP:FireTaser( DoDmg )
	if not IsValid( self.Owner ) then return end
	
	local tsr = ents.Create( "ent_taser_hook" )
	if IsValid(tsr) then
		tsr:SetPos( self.Owner:GetShootPos()-self.Owner:GetAimVector()*10 )
		tsr:SetAngles( self.Owner:EyeAngles() )
		tsr:SetOwner( self.Owner )
		tsr:Spawn()
		
		if DoDmg then
			tsr:SetDamage( 5 )
		end
		
		tsr.Weapon = self
		
		self:SetBolt( tsr )
		
		tsr.FireVelocity = self.Owner:GetAimVector()*1500
		
		local phys = tsr:GetPhysicsObject()
		if IsValid(phys) then
			phys:SetVelocity( tsr.FireVelocity )
			tsr.Fired = true
		end
	end
end

function SWEP:PrimaryAttack()
	if self:GetCharge() < 100 then return end
	
	self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
	self.Weapon:SetNextSecondaryFire( CurTime() + self.Primary.Delay )
	
	if not IsValid(self.Owner) then return end
	if IsValid(self:GetBolt()) then return end
	
	self.Weapon:EmitSound( ShootSound )
	if SERVER then
		self:SetCharge( 0 )
		self.Owner:SetAnimation( PLAYER_ATTACK1 )
		
		self:FireTaser()
	end
end
function SWEP:SecondaryAttack()
	self.Weapon:SetNextPrimaryFire( CurTime() + 0.2 )
	self.Weapon:SetNextSecondaryFire( CurTime() + 0.2 )
	
	if not IsValid(self.Owner) then return end
	if not IsValid(self:GetBolt()) then return end
	
	local prnt = self:GetBolt():GetParent()
	
	local ply = prnt.IsTasedRagdoll and prnt.Owner or nil
	
	sound.Play( self.ZapSound, self:GetBolt():GetPos(), 75, 100 )
	
	if ply then
		ply:TakeDamage( self.Secondary.Damage, self.Owner, self )
		
		ply.TasedRag:GetPhysicsObject():ApplyForceCenter( Vector( math.random(-4000, 4000 ), math.random(-4000 ,4000 ), math.random(-4000, 4000 ) ) ) 
        
		
		if not ply.TaserKill then ply.TaserKill= 0 end
		ply.TaserKill = ply.TaserKill + 1
		
		if ply.TaserKill == 10 then ply:TakeDamage( ply:Health()*10, self.Owner, self ) end
		
	elseif IsValid(prnt) and prnt.TakeDamage then
		prnt:TakeDamage( self.Secondary.Damage, self.Owner, self )
	end
end

function SWEP:Reload() end
function SWEP:Think()
	if not self.NextThinks then self.NextThinks = CurTime() + 0.5 end
	
	if 	self.NextThinks < CurTime() then -- change the recharge bar time
		if self:GetCharge() < 100 then
			self:SetCharge(self:GetCharge()+1)
		end
		
		self.NextThinks = CurTime() + 0.05
	end
end

function SWEP:ShouldDropOnDie() return false end

if CLIENT then
	function SWEP:Holster()
		if IsValid(self.Owner) then
			local vm = self.Owner:GetViewModel()
			if IsValid(vm) then vm:SetMaterial() end
		end
		return self.BaseClass.Holster( self )
	end

	function SWEP:DrawWorldModel()
		self:SetMaterial( "phoenix_storms/stripes" )
		self:DrawModel()
		local att = self:GetAttachment( 1 )
		if IsValid(self:GetBolt()) and IsValid(self.Owner) then
			render.SetMaterial( HookCable )
			render.DrawBeam( self:GetBolt():GetPos(), att and att.Pos or self.Owner:GetShootPos(), 1, 0, 2, Color(255,255,255,255) )
		end
		
		--return self.BaseClass.DrawWorldModel( self )
	end
end

// Credits to [GFL] my_hat_stinks, without him this wouldn't of been possible. thanks hat!