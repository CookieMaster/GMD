AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/combine_turrets/floor_turret.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	local phys = self:GetPhysicsObject()
	phys:Wake()
	self:DropToFloor( )
end

util.AddNetworkString( "StartRadarView" )
util.AddNetworkString( "LeaveRadar" )
util.AddNetworkString( "PlayerSpeeding" )
function ENT:Use( activator, called, useType, value )
	if not IsValid( activator ) or not activator:IsPlayer( ) then
		return
	end
	
	if CurTime( ) < ( activator.leftRadar or 0 ) + 0.5 then
		return
	end
	
	if IsValid( self:GetUser( ) ) then
		return
	end
	
	if not table.HasValue( { TEAM_CHIEF, TEAM_POLICE }, activator:Team( ) ) then
		return
	end
	
	if activator:GetPos( ):Distance( self:GetPos( ) ) > 50 then
		return
	end
	
	--Player needs to stand behind the radar
	local entToPlayer = activator:GetPos( ) - self:GetPos( )
	entToPlayer:Normalize( )
	local dot = self:GetForward( ):Dot( entToPlayer )
	if dot > -0.6 then
		return
	end
	
	self:SetUser( activator )
	net.Start( "StartRadarView" )
		net.WriteEntity( self )
	net.Send( activator )
	activator:Freeze( )
	activator.controlledRadar = self
end

function ENT:GiveTicket( vehicle )
	if not IsValid( vehicle ) or not IsValid( vehicle:GetDriver( ) ) then
		return 
	end
	
	local speed = getEntitySpeed( vehicle:GetVelocity( ):Length( ), self.unit )
	if speed < self:GetMaxSpeed( ) then
		return
	end
	
	local driver = vehicle:GetDriver( )
	if CurTime( ) < ( driver.lastShot or 0 ) + 5 then
		return
	end
	
	self:SetFlashEnd( CurTime( ) + 0.15 )
	self:EmitSound( "npc/scanner/scanner_photo1.wav", 100,100 )
	
	local mul = speed / self:GetMaxSpeed( )
	local penalty = math.Round( self:GetPenalty( mul ) )
	if driver:CanAfford( penalty ) then
		driver:AddMoney( -penalty )
		GAMEMODE:Notify( driver, 0, 4, "You have been caught speeding, fine: " .. penalty .. GAMEMODE.Config.currency )
		
		local ply = self:GetUser( )
		GAMEMODE:Notify( ply, 0, 4, "You earned " .. self.giveAmount * penalty .. GAMEMODE.Config.currency .. " for catching " .. driver:Nick( ) .. " speeding." )
		ply:Give( self.giveAmount * penalty )
	else
		driver:wanted( self:GetUser( ), "Speeding(" .. penalty .. GAMEMODE.Config.currency .. ")" )
	end
	
	driver.lastShot = CurTime( )
end

net.Receive( "PlayerSpeeding", function( len, ply )
	if not ply.controlledRadar then
		return
	end
	ply.controlledRadar:GiveTicket( net.ReadEntity( ) )
end )

function ENT:ejectUser( )
	local ply = self:GetUser( )
	self:SetUser( nil )
	ply.controlledRadar = nil
	ply.leftRadar = CurTime( )
end

net.Receive( "LeaveRadar", function( len, ply )
	if IsValid( ply.controlledRadar ) then
		ply.controlledRadar:ejectUser( )
	end
end )

hook.Add( "SetupMove", "FreezePlys", function( ply, mv )
	if IsValid( ply.controlledRadar ) then
		ply.controlledRadar:SetAimAngle( ply.controlledRadar:GetForward( ):Angle( ) + mv:GetAngles( ) )
		mv:SetAngles( ( ply.controlledRadar:GetPos( ) - ply:GetPos( ) ):Angle( ) )
		mv:SetForwardSpeed( 0 )
		mv:SetSideSpeed( 0 )
		mv:SetUpSpeed( 0 )
		mv:SetVelocity( Vector( 0, 0, 0 ) )
	end
end )

function ENT:SpawnFunction( ply, tr, ClassName )
	if ( !tr.Hit ) then return end
	
	local SpawnPos = tr.HitPos + tr.HitNormal * 2
	
	local ent = ents.Create( ClassName )
	ent:SetPos( SpawnPos )
	ent:SetAngles( Angle( 0, ply:EyeAngles( ).y, 0 ) )
	ent:Spawn()
	ent:Activate()
	
	return ent
end

function ENT:Think()
	if IsValid( self:GetUser( ) ) and not self:GetUser( ):Alive( ) then
		self:ejectUser( )
	end
	if IsValid( self:GetUser( ) ) and self:GetUser( ):GetPos( ):Distance( self:GetPos( ) ) > 50 then
		self:ejectUser( )
	end
end

function ENT:OnRemove()
	self:ejectUser( )
end