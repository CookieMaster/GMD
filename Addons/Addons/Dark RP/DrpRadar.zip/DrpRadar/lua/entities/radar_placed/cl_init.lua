include("shared.lua")



function ENT:Initialize( )
	pac.SetupENT( self )
	self.outfit = CompileFile("drpradar/client/pac_outfit_radarstation.lua")()
	self:AttachPACPart( self.outfit, "self" )
	self:SetPACDrawDistance( 30000 )
	
	self.rtName = "ScreenRT" .. self:EntIndex( ) .. math.random( )
	self.rtSize = { x = 512, y = 512 }
	
	self.matName = "ScreenMat" .. self:EntIndex( ) .. math.random( )
	self.renderTarget = GetRenderTarget( self.rtName, self.rtSize.x, self.rtSize.y, false )
	
	self.screenMaterial = CreateMaterial( self.matName, "UnlitGeneric" )
	self.screenMaterial:SetTexture( "$basetexture", self.renderTarget )
	
	local part = self:FindPACPart( self.outfit, "screenMaterial" )
	part.BaseTexture = self.rtName
	
	self.scanningSound = CreateSound( self, "npc/scanner/combat_scan_loop6.wav" )
	self.lockedSound = CreateSound( self, "npc/scanner/scanner_combat_loop1.wav" )
	self.lockingSound = CreateSound( self, "npc/scanner/scanner_scan_loop1.wav" )
end

function ENT:Draw( )
	self:DrawModel( )
	
	/*
	local part = self:FindPACPart( self.outfit, "camera" )
	local min, max = self:WorldSpaceAABB( ) 
	render.DrawWireframeBox( Vector( 0, 0, 0 ), Angle( 0, 0, 0 ), min, max, Color( 255, 0, 0 ), true )
	local ppos, pang = part:GetDrawPosition( )
	pang:Normalize( )
	render.DrawLine( ppos + pang:Forward( ) * 20, ppos + pang:Forward( ) * 250, Color( 255, 0, 0 ) )
	 
	local pos, ang = self:GetPos( ), self:GetForward( ):Angle( )
	render.DrawLine( ppos, ppos + ang:Forward( ) * 250, Color( 255, 0, 255 ) )
	*/
end

net.Receive( "StartRadarView", function() 
	LocalPlayer( ).controlledRadar = net.ReadEntity( )
	local aim = LocalPlayer( ).controlledRadar:FindPACPart( LocalPlayer( ).controlledRadar.outfit, "aimbone" )
	local fwAngles = LocalPlayer( ).controlledRadar:GetForward( ):Angle( )
	local realAngle = aim:GetAngles( ) + Angle( fwAngles.y, fwAngles.r, fwAngles.p )
	realAngle = Angle( realAngle.r, realAngle.p, realAngle.y )
	LocalPlayer( ):SetEyeAngles( realAngle )
	LocalPlayer( ).radarCtrlStart = CurTime( )
end )

function ENT:drawVehicleChams( fullscreen )
	--Draw Vehicle Chams
	local part = self:FindPACPart( self.outfit, "camera" )
	local ppos, pang = part:GetDrawPosition( )
	for k, v in pairs( ents.GetAll( ) ) do
		if v:IsVehicle( ) and ( ppos:Distance( v:GetPos( ) ) < self.maxDistance or v == self.aimingAtVehicle ) then
			render.MaterialOverride( )
			render.SetColorModulation( 1, 1, 1 )
			render.SuppressEngineLighting( true )
			render.SetBlend( 1 )
			v:DrawModel( )
			
			render.MaterialOverride( Material( "models/shiny" ) )
			render.SetColorModulation( 1, 1, 0 )
			render.SetBlend( 0.34 )
			local color = Color( 255, 255, 0 )
			if self.aimingAtVehicle == v and self.canShoot then
				if getEntitySpeed( v:GetVelocity( ):Length( ), self.unit ) > self:GetMaxSpeed( ) then
					render.SetColorModulation( 1, 0, 0 )
					color = Color( 255, 0, 0 )
				else
					render.SetColorModulation( 0, 1, 0 )
					color = Color( 0, 255, 0 )
				end
			end
			v:DrawModel( )
			
			if v == self.aimingAtVehicle then
				local min, max = v:WorldSpaceAABB( ) 
				render.DrawWireframeBox( Vector( 0, 0, 0 ), Angle( 0, 0, 0 ), min, max, Color( 255, 0, 0 ), true )
			end
			
			if fullscreen then
				halo.Render{
					Ents = { v },
					Color = color,
					Hidden = false,
					BlurX = 2,
					BlurY = 2,
					DrawPasses = 1,
					Additive = true,
					IgnoreZ = false
				}
			end
		end
	end
	render.SuppressEngineLighting( false )
end

surface.CreateFont( "ScreenText", { font = "Lucida Console", size = 30 })
surface.CreateFont( "ScreenTextSmall", { font = "Lucida Console", size = 22 })
function ENT:drawHudView( isFullscreen, w2sfunc )
	local w, h = isFullscreen and ScrW( ) or 512, isFullscreen and ScrH( ) or 512
	local aim = self:FindPACPart( self.outfit, "aimbone" )
	local p, y = aim:GetAngles( ).r, aim:GetAngles( ).p
	local user = self:GetUser( )
	
	surface.SetFont( "ScreenText" )
	surface.SetTextPos( 50, 20 )
	surface.SetTextColor( 255, 255, 0 )
	draw.SimpleText( "KTech CP Radar v.09", "ScreenText", 20, 30, Color( 30, 255, 185 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER ) 
	draw.SimpleText( math.Round( ( p or 0 ) * 10000 ) / 10000 .. "|" .. math.Round( ( y or 0 ) * 10000 ) / 10000, "ScreenText", 20, 65, Color( 100, 100, 0 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER ) 
	
	if self.aimingAtVehicleStarted and IsValid( self.aimingAtVehicle )  then
		local timeLeft = ( self.aimingAtVehicleStarted + self.lockTime ) - CurTime( )
		local coord
		local worldCoord = self.aimingAtVehicle:OBBCenter( ) + self.aimingAtVehicle:GetPos( )
		if w2sfunc then 
			local x, y, visible = w2sfunc( worldCoord )
			if visible then
				coord = { x = x, y = y }
			end
		else
			coord = worldCoord:ToScreen( )
		end
		if timeLeft > 0 then
			if coord then
				draw.SimpleTextOutlined( "Measuring...", "ScreenText", coord.x, coord.y, Color( 255, 255, 0 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 3, Color( 30, 30, 30 ) ) 
			end
		else
			local color = Color( 0, 255, 0 )
			local entSpeed = getEntitySpeed( self.aimingAtVehicle:GetVelocity( ):Length( ), self.unit )
			if entSpeed > self:GetMaxSpeed( ) then
				color = Color( 255, 0, 0 )
			end
			if coord then
				local speed = math.Round( entSpeed )
				draw.SimpleTextOutlined( "Speed: " .. speed .. " " .. self.unit , "ScreenText", coord.x, coord.y, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 3, Color( 30, 30, 30 ) )
			end
		end
	end
	
	surface.SetDrawColor( color_white )
	surface.DrawRect( w / 2 - 30, h / 2 - 10 / 2, 20, 10 ) 
	surface.DrawRect( w / 2 + 10, h / 2 - 10 / 2, 20, 10 ) 
	surface.DrawRect( w / 2 - 10 / 2, h / 2 + 10, 10, 20 ) 
	surface.DrawRect( w / 2 - 10 / 2, h / 2 - 30, 10, 20 )  
	
	if IsValid( user ) then
		draw.SimpleText( "System in use by " .. user:Nick( ), "ScreenTextSmall", 20, h - 50, Color( 0, 255, 0 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
	else
		draw.SimpleText( "System on standby", "ScreenTextSmall", 20, h - 50, Color( 255, 0, 0 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
	end
	
	if isFullscreen then
		if CurTime( ) < LocalPlayer().controlledRadar:GetFlashEnd( ) then
			local alpha = 1 / ( LocalPlayer().controlledRadar:GetFlashEnd( ) - CurTime( ) )
			surface.SetDrawColor( 255, 255, 255, alpha )
			surface.DrawRect( 0, 0, w, h )
		end
	end
end

local tab = {
	[ "$pp_colour_addr" ] = 0.00,
	[ "$pp_colour_addg" ] = 0.10,
	[ "$pp_colour_addb" ] = 0.5,
	[ "$pp_colour_brightness" ] = 0.1,
	[ "$pp_colour_contrast" ] = 0.3,
	[ "$pp_colour_colour" ] = 0.2,
	[ "$pp_colour_mulr" ] = 0.02,
	[ "$pp_colour_mulg" ] = 0.00,
	[ "$pp_colour_mulb" ] = 0
}

local drawScreen = false
local dm, db, dc = DrawMotionBlur, DrawBloom, DrawColorModify
hook.Add( "RenderScreenspaceEffects", "goobypls", function( )
	local ent = LocalPlayer( ).controlledRadar
	if IsValid( ent ) then
		dc( tab )
		cam.Start3D( )
			ent:drawVehicleChams( true )
		cam.End3D( )
		ent:drawHudView( true )
	end
end )

hook.Add( "HUDShouldDraw", "hideElems", function( )
	if IsValid( LocalPlayer( ).controlledRadar ) then
		return false
	end
end )

hook.Add( "CreateMove", "a", function( cmd )
	if IsValid( LocalPlayer( ).controlledRadar ) then
		if cmd:KeyDown( IN_USE ) and CurTime( ) > ( LocalPlayer( ).radarCtrlStart + 0.5 ) then
			net.Start( "LeaveRadar" )
			net.SendToServer( )
			LocalPlayer( ).controlledRadar = nil
		end
		if cmd:KeyDown( IN_ATTACK ) then
			LocalPlayer( ).controlledRadar:playerClicked( )
		end
		cmd:ClearButtons( )
	end
end )

hook.Add( "PreRender", "DrawToRTs", function( )
	for k, v in pairs( ents.FindByClass( "radar_placed" ) ) do
		local part = v:FindPACPart( v.outfit, "camera" )
		local pos, ang = part:GetDrawPosition( )
		local camPos = pos + ang:Forward( ) * 100
		local oldW, oldH = ScrW(), ScrH( )
		local oldRt = render.GetRenderTarget( )
		local fov = 30
		
		local function w2s( vec )
			return VectorToLPCameraScreen( vec - camPos, v.rtSize.x, v.rtSize.y, ang, fov )
		end	
		
		local rt = GetRenderTarget( v.rtName, v.rtSize.x, v.rtSize.y, false )
		render.SetRenderTarget( rt )
			render.Clear( 0, 0, 0, 255, true )
			cam.Start3D( )
				--ang.r = 0
				drawScreen = true
				render.RenderView{
					angles = ang,
					origin = camPos,
					fov = fov,
					x = 0, 
					y = 0,
					w = v.rtSize.x,
					h = v.rtSize.y,
					drawmonitors = false,
					drawviewmodel = false,
					dopostprocess = true,
				}
				drawScreen = false
				
				local mat_ColorMod = Material( "pp/colour" )
				render.CopyRenderTargetToTexture( render.GetScreenEffectTexture( 0 ) ) 
				mat_ColorMod:SetTexture( "$basetexture", render.GetScreenEffectTexture( 0 ) )
				for k, v in pairs(tab) do
					mat_ColorMod:SetFloat( k, v )
				end
				render.SetMaterial( mat_ColorMod )
				render.DrawScreenQuad()
			cam.End3D( )
			
			cam.Start3D( camPos, ang )
				v:drawVehicleChams( )
			cam.End3D( )
			
			render.SetViewPort( 0, 0, v.rtSize.x, v.rtSize.y )
			cam.Start2D( )
				v:drawHudView( false, w2s )
			cam.End2D( )
		render.SetRenderTarget( oldRt )
		render.SetViewPort( 0, 0, oldW, oldH )
		
	end
end )

function ENT:Think( )
	local flash = self:FindPACPart( self.outfit, "flash" )
	if IsValid( flash ) then 
		if CurTime( ) < self:GetFlashEnd( ) then
			flash:SetBrightness( 255 )
			flash:SetSize( 512 )
		else
			flash:SetBrightness( 0 )
			flash:SetSize( 0 )
		end
	end

	local aim = self:FindPACPart( self.outfit, "aimbone" )
	if IsValid( self:GetUser( ) ) then
		local eyeAngles = self:GetUser( ):EyeAngles( )
		local fwAngles = self:GetForward( ):Angle( )
		aim:SetAngles( Angle( eyeAngles.y, eyeAngles.r, eyeAngles.p ) - Angle( fwAngles.y, fwAngles.r, fwAngles.p ) )
	end
	self.canShoot = false
	
	if not IsValid( self:GetUser( ) ) then
		self.aimingAtVehicle = nil
		self.aimingAtVehicleStarted = nil
		self:OnRemove( ) --stop sounds
		return
	end
	
	local part = self:FindPACPart( self.outfit, "camera" )
	local ppos, pang = part:GetDrawPosition( )
	local cameraVec = pang:Forward( )
	cameraVec:Normalize( )
	
	local bestDot = -1
	local bestVehicle
	for k, v in pairs( ents.GetAll( ) ) do
		if v:IsVehicle( ) then
			local toVehicle = v:GetPos( ) - ppos
			toVehicle:Normalize( )
			local dot = cameraVec:Dot( toVehicle )
			if dot < 0.90 then
				continue
			end
			local allEnts = ents.GetAll( ) 
			for _, ent in pairs( allEnts ) do
				if ent == v then
					allEnts[_] = nil
				end
			end
			table.insert( allEnts, self )
			
			local tr2 = util.TraceLine( {
				start = ppos + cameraVec * 150,
				endpos = ppos + cameraVec * ( self.maxDistance ),
				filter = allEnts,
				mask = MASK_SHOT
			}, v )
			if tr2.Entity == v then
				bestVehicle = v
				break
			end
				
			if math.abs( 1 - dot ) < math.abs( 1 - bestDot ) then
				local tr = util.TraceEntity( {
					start = ppos + cameraVec * 150,
					endpos = ppos + cameraVec * ( self.maxDistance ),
					filter = allEnts,
					mask = MASK_SHOT
				}, v )
				if tr.Entity == v then	
					bestVehicle = v
					bestDot = dot
				end
			end
		end
	end
	if bestVehicle != self.aimingAtVehicle then
		self.aimingAtVehicle = bestVehicle
		self.aimingAtVehicleStarted = CurTime( )
	end
	
	if self.aimingAtVehicle and CurTime( ) > self.aimingAtVehicleStarted + self.lockTime then
		self.canShoot = true
	end
	
	if not self.aimingAtVehicle then
		if not self.scanningSound:IsPlaying( ) then
			self.scanningSound:Play( )
		end
		if self.lockingSound:IsPlaying( ) then
			self.lockingSound:Stop( )
		end
		if self.lockedSound:IsPlaying( ) then
			self.lockedSound:Stop( )
		end
	else
		if self.scanningSound:IsPlaying( ) then
			self.scanningSound:Stop( )
		end
		
		if self.canShoot then
			if not self.lockedSound:IsPlaying( ) then
				self.lockedSound:Play( )
			end
			if self.lockingSound:IsPlaying( ) then
				self.lockingSound:Stop( )
			end
		else
			if self.lockedSound:IsPlaying( ) then
				self.lockedSound:Stop( )
			end
			if not self.lockingSound:IsPlaying( ) then
				self.lockingSound:Play( )
			end
		end
	end
end

ENT.lastShot = 0
function ENT:playerClicked( )
	if not self.canShoot or CurTime( ) < self.lastShot + 0.5 then 
		return false
	end
	
	if IsValid( self.aimingAtVehicle ) then
		net.Start( "PlayerSpeeding" )
			net.WriteEntity( self.aimingAtVehicle )
		net.SendToServer( )
		self.lastShot = CurTime( )
	end
end

hook.Add( "HUDPaint", "DrawToRTs", function( )
	/*for k, v in pairs( ents.FindByClass( "radar_placed" ) ) do
		surface.SetDrawColor( color_white )
		surface.SetMaterial( v.screenMaterial )
		surface.DrawTexturedRect( 0, 0, 512/2, 512/2 )
	end*/
end )

hook.Add( "AdjustMouseSensitivity", "cv", function( default )
	if IsValid( LocalPlayer( ).controlledRadar ) then
		return 0.6
	end
	return default
end )

hook.Add( "SetupMove", "FreezePlys", function( ply, mv )
	if IsValid( ply.controlledRadar ) then
		mv:SetForwardSpeed( 0 )
		mv:SetSideSpeed( 0 )
		mv:SetUpSpeed( 0 )
		mv:SetVelocity( Vector( 0, 0, 0 ) )
	end
end )

hook.Add("CalcView", "cv", function(pl,pos,ang,fov,zNear,zFar)
	local ent = LocalPlayer( ).controlledRadar
	if not IsValid( ent ) then
		return
	end

	local part = ent:FindPACPart( ent.outfit, "camera" )
	local camPos, camAng = part:GetDrawPosition( )
	
	local entAngle = ent:GetForward( ):Angle( )
	local viewAngle = ang
	
	local yawDiff = math.AngleDifference( viewAngle.y, entAngle.y )
	if yawDiff >= 60 then
		ang.y = entAngle.y + 60
	elseif yawDiff <= -60 then
		ang.y = entAngle.y - 60
	end
	
	local pitchDiff = math.AngleDifference( viewAngle.p, entAngle.p )
	if pitchDiff >= 30 then
		ang.p = entAngle.p + 30
	elseif pitchDiff <= -30 then
		ang.p = entAngle.p - 30
	end
	

	ang.r = 0
	fov = 45
	LocalPlayer( ):SetEyeAngles( ang )

	return {
		origin = camPos + camAng:Forward( ) * 10,
		angles = ang,
		fov = fov,
		znear = zNear,
		zfar = zFar,
		drawviewer = true
	}
end)

function ENT:OnRemove( )
	self.scanningSound:Stop( )
	self.lockedSound:Stop( )
	self.lockingSound:Stop( )
end