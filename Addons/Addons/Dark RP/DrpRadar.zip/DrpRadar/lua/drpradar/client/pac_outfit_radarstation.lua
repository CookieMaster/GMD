return {
	["children"] = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["GlobalID"] = "2295484349",
								["UniqueID"] = "750575149",
								["Angles"] = Angle(-88.21875, 0, 0),
								["Position"] = Vector(-4.478759765625, 0.17926025390625, 19.100578308105),
								["ClassName"] = "clip",
							},
						},
						[2] = {
							["children"] = {
								[1] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "sunbeams",
												["Size"] = -0.225,
												["GlobalID"] = "440817441",
												["Hide"] = true,
												["Multiplier"] = 0.09,
												["UniqueID"] = "1957608967",
											},
										},
										[2] = {
											["children"] = {
											},
											["self"] = {
												["ClassName"] = "sprite",
												["Position"] = Vector(0.00030517578125, 0.00146484375, 0.40679931640625),
												["SpritePath"] = "sprites/redglow1",
												["Size"] = 10,
												["EditorExpand"] = true,
												["GlobalID"] = "3372008333",
												["UniqueID"] = "4109530387",
											},
										},
										[3] = {
											["children"] = {
											},
											["self"] = {
												["Max"] = 3,
												["UniqueID"] = "4234257718",
												["Axis"] = "y",
												["Min"] = -3,
												["VariableName"] = "Position",
												["ClassName"] = "proxy",
												["InputMultiplier"] = 2,
												["GlobalID"] = "1473211086",
												["EditorExpand"] = true,
											},
										},
									},
									["self"] = {
										["Size"] = 0.1,
										["GlobalID"] = "1014150363",
										["Position"] = Vector(0.59213256835938, 2.6500318050385, 0.09881591796875),
										["EditorExpand"] = true,
										["Color"] = Vector(255, 0, 0),
										["UniqueID"] = "2197027949",
										["ClassName"] = "model",
										["Material"] = "models/shiny",
									},
								},
							},
							["self"] = {
								["Position"] = Vector(2.0474243164063, -0.05908203125, 23.562591552734),
								["LightBlend"] = 1.1,
								["Material"] = "phoenix_storms/metalfloor_2-3",
								["Scale"] = Vector(1, 2.0999999046326, 1),
								["EditorExpand"] = true,
								["GlobalID"] = "731348340",
								["Size"] = 0.1,
								["UniqueID"] = "2959089849",
								["Color"] = Vector(255, 0, 0),
								["Angles"] = Angle(64.84375, 0, 0),
								["Model"] = "models/hunter/plates/plate1x1.mdl",
								["ClassName"] = "model",
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(0, 0, -180),
						["Position"] = Vector(8.939208984375, 0.0089111328125, 3.5826263427734),
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["UniqueID"] = "3355432116",
						["Model"] = "models/props_lab/eyescanner.mdl",
						["GlobalID"] = "1333973245",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "light",
								["Position"] = Vector(-5.5059814453125, -0.0003662109375, 13.963592529297),
								["Brightness"] = 3,
								["Size"] = 512,
								["GlobalID"] = "3407900983",
								["Name"] = "flash",
								["UniqueID"] = "1082814328",
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(-11.53125, 177.125, -177.8125),
						["Position"] = Vector(6.9596557617188, 0.33404541015625, -16.003112792969),
						["Size"] = 0.3,
						["EditorExpand"] = true,
						["UniqueID"] = "2536684344",
						["Model"] = "models/props_combine/combine_light001b.mdl",
						["GlobalID"] = "2874367890",
					},
				},
				[3] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["GlobalID"] = "2571973119",
										["UniqueID"] = "3633183564",
										["Angles"] = Angle(-4.4375, 0, 0),
										["Position"] = Vector(11.010000228882, 0, 0.10000000149012),
										["ClassName"] = "clip",
									},
								},
								[2] = {
									["children"] = {
									},
									["self"] = {
										["GlobalID"] = "2581014721",
										["UniqueID"] = "407083978",
										["Angles"] = Angle(-89.03125, -180, 180),
										["Position"] = Vector(0.11999999731779, -0.019999999552965, -5.7399997711182),
										["ClassName"] = "clip",
									},
								},
								[3] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["BaseTexture"] = "models/props_c17/paper01",
												["ClassName"] = "material",
												["UniqueID"] = "2203877559",
												["Name"] = "screenMaterial",
												["GlobalID"] = "3662508574",
											},
										},
									},
									["self"] = {
										["UniqueID"] = "293928439",
										["Name"] = "monitorScreen",
										["Scale"] = Vector(1, 1.1000000238419, 1),
										["GlobalID"] = "2696988378",
										["ClassName"] = "model",
										["Size"] = 0.25,
										["EditorExpand"] = true,
										["Angles"] = Angle(-83.34375, 180.59375, 179.96875),
										["Fullbright"] = true,
										["Model"] = "models/hunter/plates/plate1x1.mdl",
										["Position"] = Vector(11.98582649231, -0.065582275390625, 2.8518371582031),
									},
								},
							},
							["self"] = {
								["UniqueID"] = "2283562196",
								["Scale"] = Vector(1, 0.69999998807907, 0.69999998807907),
								["Model"] = "models/props_lab/monitor01a.mdl",
								["GlobalID"] = "2223724982",
								["EditorExpand"] = true,
								["ClassName"] = "model",
								["Color"] = Vector(10, 80, 255),
								["Angles"] = Angle(3.90625, -0.09375, 0),
								["Brightness"] = 1.7,
								["Position"] = Vector(-2.5099999904633, 0.14000000059605, 6.7399997711182),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(12.59375, 179.96875, 0),
						["Position"] = Vector(3.1113891601563, -0.89581298828125, -22.555953979492),
						["Size"] = 0.35,
						["EditorExpand"] = true,
						["UniqueID"] = "1095392778",
						["Model"] = "models/props_combine/combine_intmonitor003.mdl",
						["GlobalID"] = "3348100960",
					},
				},
				[4] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["GlobalID"] = "4185234703",
								["UniqueID"] = "45967126",
								["Angles"] = Angle(89.21875, 179.96875, 179.96875),
								["Position"] = Vector(3.7322387695313, -0.02520751953125, 3.30126953125),
								["ClassName"] = "clip",
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(-0.0625, -0.15625, -179.96875),
						["Position"] = Vector(5.6152954101563, 2.6856079101563, -15.453399658203),
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["UniqueID"] = "3839300540",
						["Model"] = "models/dav0r/camera.mdl",
						["GlobalID"] = "2947110556",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.31024169921875, 2.2998428344727, 0.67303466796875),
				["Scale"] = Vector(0.20000000298023, 0.10000000149012, -0.20000000298023),
				["UniqueID"] = "1590978367",
				["EditorExpand"] = true,
				["Size"] = 0.95,
				["ClassName"] = "model",
				["Angles"] = Angle(-90, 0, 90),
				["Bone"] = "leftright",
				["Model"] = "models/props_combine/combine_booth_short01a.mdl",
				["GlobalID"] = "547054823",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.02691650390625, 2.2990341186523, 11.037780761719),
				["Scale"] = Vector(0.20000000298023, 0.10000000149012, -0.20000000298023),
				["UniqueID"] = "1232941948",
				["EditorExpand"] = true,
				["Size"] = 0.95,
				["ClassName"] = "model",
				["Angles"] = Angle(-270.09375, 0, 90),
				["Bone"] = "leftright",
				["Model"] = "models/props_combine/combine_booth_short01a.mdl",
				["GlobalID"] = "547054823",
			},
		},
		[3] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1876616367",
				["EditorExpand"] = true,
				["Position"] = Vector(-0.00921630859375, -5.2350845336914, 0.009765625),
				["GlobalID"] = "960992510",
				["ClassName"] = "bone",
				["Bone"] = "leftright",
				["Name"] = "aimbone",
				["Angles"] = Angle(0.96875, -0.96875, -0.96875),
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "1089865789",
				["UniqueID"] = "2787124904",
				["Loop"] = false,
				["SequenceName"] = "aim_leftright",
				["Hide"] = true,
				["ClassName"] = "animation",
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["OwnerName"] = "self",
		["EditorExpand"] = true,
		["GlobalID"] = "547054823",
		["UniqueID"] = "940863718",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
}

/*return {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["GlobalID"] = "1089865789",
				["UniqueID"] = "2787124904",
				["Loop"] = false,
				["SequenceName"] = "aim_leftright",
				["Hide"] = true,
				["ClassName"] = "animation",
			},
		},
		[2] = {
			["children"] = {
			},
			["self"] = {
				["Position"] = Vector(-0.02691650390625, 2.2990341186523, 11.037780761719),
				["Scale"] = Vector(0.20000000298023, 0.10000000149012, -0.20000000298023),
				["UniqueID"] = "1232941948",
				["EditorExpand"] = true,
				["Size"] = 0.95,
				["ClassName"] = "model",
				["Angles"] = Angle(-270.10000610352, 0, 90),
				["Bone"] = "leftright",
				["Model"] = "models/props_combine/combine_booth_short01a.mdl",
				["GlobalID"] = "547054823",
			},
		},
		[3] = {
			["children"] = {
				[1] = {
					["children"] = {
						[1] = {
							["children"] = {
								[1] = {
									["children"] = {
									},
									["self"] = {
										["GlobalID"] = "2581014721",
										["UniqueID"] = "407083978",
										["Angles"] = Angle(-89.059997558594, -180, 180),
										["Position"] = Vector(0.11999999731779, -0.019999999552965, -5.7399997711182),
										["ClassName"] = "clip",
									},
								},
								[2] = {
									["children"] = {
									},
									["self"] = {
										["GlobalID"] = "2571973119",
										["UniqueID"] = "3633183564",
										["Angles"] = Angle(-4.4499998092651, 0, 0),
										["Position"] = Vector(11.010000228882, 0, 0.10000000149012),
										["ClassName"] = "clip",
									},
								},
								[3] = {
									["children"] = {
										[1] = {
											["children"] = {
											},
											["self"] = {
												["BaseTexture"] = "models/props_c17/paper01",
												["ClassName"] = "material",
												["UniqueID"] = "2203877559",
												["Name"] = "screenMaterial",
												["GlobalID"] = "3662508574",
											},
										},
									},
									["self"] = {
										["Position"] = Vector(11.98582649231, -0.065582275390625, 2.8518371582031),
										["Name"] = "monitorScreen",
										["Scale"] = Vector(1, 1.1000000238419, 1),
										["EditorExpand"] = true,
										["Size"] = 0.25,
										["UniqueID"] = "293928439",
										["GlobalID"] = "2696988378",
										["ClassName"] = "model",
										["Model"] = "models/hunter/plates/plate1x1.mdl",
										["Fullbright"] = true,
										["Angles"] = Angle(-83.351654052734, 180.60000610352, 179.99978637695),
									},
								},
							},
							["self"] = {
								["UniqueID"] = "2283562196",
								["Scale"] = Vector(1, 0.69999998807907, 0.69999998807907),
								["Model"] = "models/props_lab/monitor01a.mdl",
								["GlobalID"] = "2223724982",
								["EditorExpand"] = true,
								["ClassName"] = "model",
								["Color"] = Vector(10, 80, 255),
								["Angles"] = Angle(3.9300000667572, -0.10000000149012, 0),
								["Brightness"] = 1.7,
								["Position"] = Vector(-2.5099999904633, 0.14000000059605, 6.7399997711182),
							},
						},
					},
					["self"] = {
						["ClassName"] = "model",
						["Angles"] = Angle(12.622101783752, 179.99996948242, 0.00030756107298657),
						["Position"] = Vector(3.1113891601563, -0.89581298828125, -22.555953979492),
						["Size"] = 0.35,
						["EditorExpand"] = true,
						["UniqueID"] = "1095392778",
						["Model"] = "models/props_combine/combine_intmonitor003.mdl",
						["GlobalID"] = "3348100960",
					},
				},
				[2] = {
					["children"] = {
						[1] = {
							["children"] = {
							},
							["self"] = {
								["ClassName"] = "light",
								["Position"] = Vector(24.916931152344, 0.64520263671875, -3.684326171875),
								["Size"] = 255,
								["Hide"] = false,
								["GlobalID"] = "3320445095",
								["UniqueID"] = "3572109474",
							},
						},
					},
					["self"] = {
						["Angles"] = Angle(-0.06318012624979, -0.1873371899128, -179.99981689453),
						["Position"] = Vector(5.605712890625, 2.076416015625, -15.454879760742),
						["ClassName"] = "model",
						["EditorExpand"] = true,
						["UniqueID"] = "3839300540",
						["Model"] = "models/dav0r/camera.mdl",
						["GlobalID"] = "2947110556",
					},
				},
			},
			["self"] = {
				["Position"] = Vector(-0.31024169921875, 2.2998428344727, 0.67303466796875),
				["Scale"] = Vector(0.20000000298023, 0.10000000149012, -0.20000000298023),
				["UniqueID"] = "1590978367",
				["EditorExpand"] = true,
				["Size"] = 0.95,
				["ClassName"] = "model",
				["Angles"] = Angle(-90, -0.00021546542120632, 90.000038146973),
				["Bone"] = "leftright",
				["Model"] = "models/props_combine/combine_booth_short01a.mdl",
				["GlobalID"] = "547054823",
			},
		},
		[4] = {
			["children"] = {
			},
			["self"] = {
				["UniqueID"] = "1876616367",
				["EditorExpand"] = true,
				["Position"] = Vector(-0.00921630859375, -5.2350845336914, 0.009765625),
				["GlobalID"] = "960992510",
				["ClassName"] = "bone",
				["Bone"] = "leftright",
				["Name"] = "aimbone",
				["Angles"] = Angle(0.99859601259232, -0.99859601259232, -0.99859601259232),
			},
		},
	},
	["self"] = {
		["ClassName"] = "group",
		["OwnerName"] = "self",
		["EditorExpand"] = true,
		["GlobalID"] = "547054823",
		["UniqueID"] = "940863718",
		["Name"] = "my outfit",
		["Description"] = "add parts to me!",
	},
}
*/