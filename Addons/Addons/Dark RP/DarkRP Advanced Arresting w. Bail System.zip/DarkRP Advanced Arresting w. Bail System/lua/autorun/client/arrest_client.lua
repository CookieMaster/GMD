surface.CreateFont("ArrestFont", {
	font = "Tahoma", 
	size = 15, 
	weight = 600
})

surface.CreateFont("Trebuchet20", {
	font = "Trebuchet MS", 
	size = 18, 
	weight = 900
})

function GUI_ArrestOptions( Arrester, Target )
	if GUI_Arrest_Frame != nil && GUI_Arrest_Frame:IsValid() then return end
	
	GUI_Arrest_Frame = vgui.Create("DFrame")
	GUI_Arrest_Frame:SetTitle("")
	GUI_Arrest_Frame:SetSize(250, 160)
	GUI_Arrest_Frame:Center()
	GUI_Arrest_Frame.Paint = function(CHPaint)
		-- Draw the menu background color.		
		draw.RoundedBox( 0, 0, 25, CHPaint:GetWide(), CHPaint:GetTall(), Color( 255, 255, 255, 150 ) )

		-- Draw the outline of the menu.
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0, 0, CHPaint:GetWide(), CHPaint:GetTall())
	
		draw.RoundedBox( 0, 0, 0, CHPaint:GetWide(), 25, Color( 255, 255, 255, 200 ) )
		
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0, 0, CHPaint:GetWide(), 25)

		-- Draw the top title.
		draw.SimpleText("Arrest Options", "ArrestFont", 55,12.5, Color(70,70,70,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	GUI_Arrest_Frame:MakePopup()
	GUI_Arrest_Frame:ShowCloseButton(false)
					
	local GUI_Main_Exit = vgui.Create("DButton")
	GUI_Main_Exit:SetParent(GUI_Arrest_Frame)
	GUI_Main_Exit:SetSize(16,16)
	GUI_Main_Exit:SetPos(230,5)
	GUI_Main_Exit:SetText("")
	GUI_Main_Exit.Paint = function()
		surface.SetMaterial(Material("icon16/cross.png"))
		surface.SetDrawColor(200,200,0,200)
		surface.DrawTexturedRect(0,0,GUI_Main_Exit:GetWide(),GUI_Main_Exit:GetTall())
	end
	GUI_Main_Exit.DoClick = function()
		GUI_Arrest_Frame:Remove()
	end
								
	local GUI_Arrest_Panel = vgui.Create("DPanel")
	GUI_Arrest_Panel:SetParent(GUI_Arrest_Frame)
	GUI_Arrest_Panel:SetPos(10,30)
	GUI_Arrest_Panel:SetSize(230,120)
	GUI_Arrest_Panel.Paint = function(CHPaint)
		draw.RoundedBox(8,0,2,GUI_Arrest_Panel:GetWide(),GUI_Arrest_Panel:GetTall(),Color( 20, 20, 20, 180 ))
	end					
		
	local GUI_ArrestTime_Label = vgui.Create( "DLabel" )
	GUI_ArrestTime_Label:SetParent(GUI_Arrest_Panel)
	GUI_ArrestTime_Label:SetFont("ArrestFont")
	GUI_ArrestTime_Label:SetText( "Arrest Time" )
	GUI_ArrestTime_Label:SizeToContents()
	GUI_ArrestTime_Label:SetPos(80,7)
		
	local GUI_Time_Slider = vgui.Create( "DNumSlider", GUI_Arrest_Panel )
	GUI_Time_Slider:SetPos( -120,15 )
	GUI_Time_Slider:SetWide( 370 )
	GUI_Time_Slider:SetText( "" )
	GUI_Time_Slider:SetMin( 60 )
	GUI_Time_Slider:SetMax( 300 )
	GUI_Time_Slider:SetDecimals( 0 )
	GUI_Time_Slider:SetValue(60)
								
									
	local GUI_Arrest_Label = vgui.Create( "DLabel" )
	GUI_Arrest_Label:SetParent(GUI_Arrest_Panel)
	GUI_Arrest_Label:SetFont("ArrestFont")
	GUI_Arrest_Label:SetText( "Bail Price" )
	GUI_Arrest_Label:SizeToContents()
	GUI_Arrest_Label:SetPos(85,45)
		
	GUI_Bail_Entry = vgui.Create("DTextEntry")
	GUI_Bail_Entry:SetFont("ArrestFont")
	GUI_Bail_Entry:SetValue(0)
	GUI_Bail_Entry:SetSize(150,15)
	GUI_Bail_Entry:SetEditable(true)
	GUI_Bail_Entry:SetUpdateOnType(true)
	GUI_Bail_Entry:SetNumeric(true)
	GUI_Bail_Entry:SetParent(GUI_Arrest_Panel)
	GUI_Bail_Entry:SetPos(40,65)	
		
	GUI_Bail_Entry.OnEnter = function()
		local price = math.Round(tonumber(GUI_Bail_Entry:GetValue()))
		
		if price >= ARREST_MaxBail then
			GUI_Bail_Entry:SetValue(ARREST_MaxBail)
		elseif price <= 0 then
			GUI_Bail_Entry:SetValue(0)
		end
	end

	local GUI_Arrest_Button = vgui.Create("DButton")
	GUI_Arrest_Button:SetParent(GUI_Arrest_Panel)
	GUI_Arrest_Button:SetPos(22.5,90)
	GUI_Arrest_Button:SetSize(190,22.5)
	GUI_Arrest_Button:SetTextColor(Color(0,0,0,255))
	GUI_Arrest_Button:SetText("")
		
	GUI_Arrest_Button.Paint = function()
		draw.RoundedBox(8,1,1,GUI_Arrest_Button:GetWide()-2,GUI_Arrest_Button:GetTall()-2,Color(0, 0, 0, 130))

		local struc = {}
		struc.pos = {}
		struc.pos[1] = 95 -- x pos
		struc.pos[2] = 10 -- y pos
		struc.color = Color(255,255,255,255) -- Red
		struc.text = "Confirm Arrest" -- Text
		struc.font = "ArrestFont" -- Font
		struc.xalign = TEXT_ALIGN_CENTER-- Horizontal Alignment
		struc.yalign = TEXT_ALIGN_CENTER -- Vertical Alignment
		draw.Text( struc )
	end
								
	GUI_Arrest_Button.DoClick = function()
		net.Start("AS_JailPlayer")
			net.WriteDouble( math.Clamp( math.Round( tonumber( GUI_Time_Slider:GetValue() ) ), ARREST_MinTime, ARREST_MaxTime ) )
			net.WriteDouble( math.Clamp( math.Round( tonumber( GUI_Bail_Entry:GetValue() ) ), 0, ARREST_MaxBail) )
			net.WriteString( Arrester:EntIndex() )
		net.SendToServer()
		GUI_Arrest_Frame:Remove()
	end
end

function GUI_PayBail( um )
	local Bail = um:ReadString()
	local Arrester = um:ReadString()
	
	local GUI_Bail_Frame = vgui.Create("DFrame")
	GUI_Bail_Frame:SetTitle("")
	GUI_Bail_Frame:SetSize(275,60)
	GUI_Bail_Frame:Center()
	GUI_Bail_Frame.Paint = function(CHPaint)
		-- Draw the menu background color.		
		draw.RoundedBox( 0, 0, 25, CHPaint:GetWide(), CHPaint:GetTall(), Color( 255, 255, 255, 150 ) )

		-- Draw the outline of the menu.
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0, 0, CHPaint:GetWide(), CHPaint:GetTall())
	
		draw.RoundedBox( 0, 0, 0, CHPaint:GetWide(), 25, Color( 255, 255, 255, 200 ) )
		
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0, 0, CHPaint:GetWide(), 25)

		-- Draw the top title.
		draw.SimpleText("Bail Options", "ArrestFont", 45,12.5, Color(70,70,70,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	GUI_Bail_Frame:MakePopup()
	GUI_Bail_Frame:ShowCloseButton(false)

	local GUI_Arrest_Bail = vgui.Create("DButton", GUI_Bail_Frame)	
	GUI_Arrest_Bail:SetSize(130,25)
	GUI_Arrest_Bail:SetPos(5,30)
	GUI_Arrest_Bail:SetText("")
	GUI_Arrest_Bail.Paint = function()
		draw.RoundedBox(8,1,1,GUI_Arrest_Bail:GetWide()-2,GUI_Arrest_Bail:GetTall()-2,Color(0, 0, 0, 130))

		local struc = {}
		struc.pos = {}
		struc.pos[1] = 65 -- x pos
		struc.pos[2] = 12.5 -- y pos
		struc.color = Color(255,255,255,255) -- Red
		struc.text = "Pay your $".. Bail .." bail" -- Text
		struc.font = "UiBold" -- Font
		struc.xalign = TEXT_ALIGN_CENTER-- Horizontal Alignment
		struc.yalign = TEXT_ALIGN_CENTER -- Vertical Alignment
		draw.Text( struc )
	end
	
	GUI_Arrest_Bail.DoClick = function()
		net.Start("AS_PayBail")
			net.WriteString( Arrester )
		net.SendToServer()
		GUI_Bail_Frame:Remove()
	end
	
	local GUI_Arrest_Exit = vgui.Create("DButton", GUI_Bail_Frame)	
	GUI_Arrest_Exit:SetSize(130,25)
	GUI_Arrest_Exit:SetPos(140,30)
	GUI_Arrest_Exit:SetText("")
	GUI_Arrest_Exit.Paint = function()
		draw.RoundedBox(8,1,1,GUI_Arrest_Exit:GetWide()-2,GUI_Arrest_Exit:GetTall()-2,Color(0, 0, 0, 130))

		local struc = {}
		struc.pos = {}
		struc.pos[1] = 65 -- x pos
		struc.pos[2] = 12.5 -- y pos
		struc.color = Color(255,255,255,255) -- Red
		struc.text = "Don't Pay" -- Text
		struc.font = "UiBold" -- Font
		struc.xalign = TEXT_ALIGN_CENTER-- Horizontal Alignment
		struc.yalign = TEXT_ALIGN_CENTER -- Vertical Alignment
		draw.Text( struc )
	end
	
	GUI_Arrest_Exit.DoClick = function()
		GUI_Bail_Frame:Remove()
	end
end
usermessage.Hook("AS_BailMenu", GUI_PayBail)
 
function ARREST_DrawHUD(Name)
	if LocalPlayer():GetNWBool("Handcuffed") && Name == "CHudWeaponSelection" then
		return false
	end
	return true
end
hook.Add( "HUDShouldDraw", "ARREST_DrawHUD", ARREST_DrawHUD )

function ARREST_DrawArrested()
	for _, v in pairs(player.GetAll()) do
		if LocalPlayer() != v and v:Alive() then
			local VPos = v:GetPos() + Vector( 0, 0, 64 )
			local OurPos = LocalPlayer():GetPos() + Vector(0, 0, 64);
			
			local Distance = VPos:Distance( OurPos )
			local ScrPos = (VPos + Vector( 0, 0, 10 )):ToScreen()
			local ClrA = 255
				
			local trtbl = {}
			trtbl.start = OurPos
			trtbl.endpos = VPos
			trtbl.filter = {LocalPlayer(), v}
				
			local Trace = util.TraceLine( trtbl )
			local c = v:GetColor()
			local r,g,b,a = c.r, c.g, c.b, c.a

			if !Trace.Hit then
				if Distance <= 900 then  
					local alp = 255 * (math.abs((Distance-900))/400)
						
					if table.HasValue( ARREST_AllowedTeams, team.GetName( LocalPlayer():Team()) ) then	
						if v:GetNWBool("Handcuffed") then
							draw.SimpleTextOutlined("Handcuffed", "ArrestFont", ScrPos.x, ScrPos.y - 65, Color(0, 0, 0, alp), 1, 1, 1.5, Color(255,255,255, alp))
						end
					end	
				end
			end
		end
	end
end
hook.Add( "HUDDrawTargetID", "ARREST_DrawArrested", ARREST_DrawArrested )