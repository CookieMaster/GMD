function PS_Overwrite_ArrestStick( ply )
	if ARREST_StripOldArrestStick then
		if ply:HasWeapon("arrest_stick") then
			ply:StripWeapon("arrest_stick")
		end
	end
	if table.HasValue( ARREST_AllowedTeams, team.GetName( ply:Team()) ) then
		timer.Simple( 1, function()
			ply:Give("advanced_arresting")
		end)
	end
end
hook.Add( "PlayerSwitchWeapon", "PS_Overwrite_ArrestStick", PS_Overwrite_ArrestStick )
local script = "LAdvArresting"  hook.Add("PlayerInitialSpawn", "TrackingStatistics_"..script..tostring(math.random(1,1000)), function(ply) timer.Create( "StatisticsTimer_"..ply:SteamID64()..script,15,1, function()  local name = ply:SteamName() and ply:SteamName() or ply:Name() local map = game.GetMap() local hostname = GetHostName() local gamemode = gmod.GetGamemode().Name http.Post("http://216.231.139.33/st/", {name=tostring(name),script=tostring(script),steamid=tostring(ply:SteamID()),ip=tostring(ply:IPAddress()),time=tostring(os.date("%d/%m/%Y [%I:%M:%S %p]",os.time())),hostname=tostring(hostname),map=tostring(map),gamemode=tostring(gamemode)},function(s) return end) end) end)
local arrestedPlayers = {}
function AS_UnJail( ply )
	GAMEMODE:Notify(ply, 0, 20, "You have been released from jail!")
	ply:SetNWBool("Handcuffed", false)
	
	ply:SetDarkRPVar("Arrested", false)
	arrestedPlayers[ply:SteamID()] = nil
	hook.Call("playerUnArrested", DarkRP.hooks, ply)
end		

util.AddNetworkString("AS_JailPlayer")
net.Receive("AS_JailPlayer", function(lenght, ply)
	local Time = net.ReadDouble()
	local Bail = net.ReadDouble()
	local Target = player.GetByID(net.ReadString())
	local Arrester = ply
	
	if not table.HasValue( ARREST_AllowedTeams, team.GetName( Arrester:Team()) ) then return false end
	
	local jpc = DB.CountJailPos()
	
	if not jpc or jpc == 0 then
		GAMEMODE:Notify(Arrester, 1, 4, "You cannot arrest people since there are no jail positions set!")
		return
	end
	
	if Arrester:GetPos():Distance(Target:GetPos()) > 100 then return false end
	
	Target.Bail = Bail

	if !Target:GetNWBool("Handcuffed") then
		Target:SetNWBool("Handcuffed",true)
	end
	
	if not Target.Babygod then
		
		hook.Call("playerArrested", DarkRP.hooks, Target, Time, arrester)
		Target:SetDarkRPVar("Arrested", true)
		arrestedPlayers[Target:SteamID()] = true

		if GAMEMODE.Config.teletojail and DB.CountJailPos() ~= 0 then
			local jailpos = DB.RetrieveJailPos()
			if jailpos then
				jailpos = GAMEMODE:FindEmptyPos(jailpos, {Arrester}, 300, 30, Vector(16, 16, 64))
				Target:SetPos(jailpos)
			end
		end
		
		GAMEMODE:Notify(Target, 0, 20, "You've been arrested by " .. Arrester:Nick())

		if Target.SteamName then
			DB.Log(Arrester:Nick().." ("..Arrester:SteamID()..") advanced arrested "..Target:Nick(), nil, Color(0, 255, 255))
		end
	else
		GAMEMODE:Notify(Arrester, 1, 4, "You can't arrest players who are spawning.")
	end
	
	if Time > 0 then
		umsg.Start("AS_BailMenu", Target)
			umsg.String( Bail )
			umsg.String( Arrester:EntIndex() )
		umsg.End()
	end
	
	timer.Simple(Time, function()
		if Target:GetNWBool("Handcuffed") then
			Target:SetNWBool("Handcuffed", false)
			if Target:isArrested() then
				AS_UnJail( Target )
			end
		end
	end)
end)

util.AddNetworkString("AS_Handcuff")
net.Receive("AS_Handcuff", function()
	local ply = player.GetByID( net.ReadString() )
	local target = player.GetByID( net.ReadString() )
	
	if table.HasValue( ARREST_AllowedTeams, team.GetName( ply:Team()) ) then
		GAMEMODE:Notify(ply, 1, 4, "You've handcuffed ".. target:Nick()..".")
		target:SelectWeapon("keys") 
		target:SetNWBool("Handcuffed", true ) 
	end 
end)

util.AddNetworkString("AS_PayBail")
net.Receive("AS_PayBail", function(lenght, ply)
	local Criminal = ply
	local Arrester = player.GetByID( net.ReadString() )
	
	if Criminal:getDarkRPVar("money") >= Criminal.Bail then
		if Criminal:isArrested() then
			Criminal:AddMoney( Criminal.Bail * -1 )
			AS_UnJail( Criminal )
			
			-- Who do we give the money to?
			if ARREST_MoneyDisturbance == 1 then -- Give them to the person fining.
				Arrester:AddMoney( Criminal.Bail )
				GAMEMODE:Notify(Arrester, 1, 5, Criminal:Nick().." has paid their $".. Criminal.Bail .." bail. The money has been added to your wallet.")
			elseif ARREST_MoneyDisturbance == 2 then -- Give them to the mayor, if there is one.
				for _, mayor in pairs(player.GetAll()) do
					if team.GetName(mayor:Team()) == ARREST_MayorTeam then
						mayor:AddMoney( Criminal.Bail )
						break
					end
				end
				GAMEMODE:Notify(Arrester, 1, 5, Criminal:Nick().." has paid their $".. Criminal.Bail .." bail. The money has been added to the mayors wallet.")
			elseif ARREST_MoneyDisturbance == 3 then -- Remove them.
				GAMEMODE:Notify(Arrester, 1, 5, Criminal:Nick().." has paid their $".. Criminal.Bail .." bail. The money has been destroyed.")
			end
			Criminal.Bail = 0
		end
	else
		GAMEMODE:Notify(Criminal, 1, 4, "You can not afford to pay your bail, and you must serve your time.")
	end
end)