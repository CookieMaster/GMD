ARREST_AllowedTeams = { -- These are the names of the jobs that gets the new arrest stick.
	"Civil Protection",
	"Civil Protection Chief" -- THE LAST LINE SHOULD NOT HAVE A COMMA AT THE END. BE AWARE OF THIS WHEN EDITING THIS!
}

ARREST_MayorTeam = "Mayor" -- Job name of your mayor team.

ARREST_MaxBail = 500 -- The maximum amount an officer can set the bail to. [Default = 500]

ARREST_MinTime = 60 -- The minimum amount an officer can set the arrest timer to. [Default = 60]
ARREST_MaxTime = 300 -- The maximum amount an officer can set the arrest timer to. [Default = 300]

ARREST_ArrestDistance = 80 -- The distance between the officer and the player before he/she can arrest them. [Default = 80] (RECOMMENDED)

ARREST_MoneyDisturbance = 1 -- The player the money from a bail should go to. This setting has 3 stages. 1, 2 and 3. 1 = The person who arrested him/her. 2 = The mayor (if there is one). 3 = Money disappears, and is removed forever. [Default = 1]

ARREST_StripOldArrestStick = true -- Weather or not to remove the default arrest stick. [Default = true]