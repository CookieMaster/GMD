if SERVER then
	AddCSLuaFile("shared.lua")
end

if CLIENT then
	SWEP.PrintName = "Advanced Arresting"
	SWEP.Slot = 1
	SWEP.SlotPos = 3
	SWEP.DrawAmmo = false
	SWEP.DrawCrosshair = true
end

SWEP.Base = "weapon_cs_base2"

SWEP.Author = "Crap-Head"
SWEP.Instructions = "Left click to arrest a handcuffed person.\nRight click to handcuff your target."
SWEP.Contact = ""
SWEP.Purpose = ""
SWEP.IconLetter = ""

SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.AnimPrefix = "stunstick"

SWEP.Spawnable = false
SWEP.AdminSpawnable = true

SWEP.NextStrike = 0

SWEP.ViewModel = Model("models/weapons/v_stunbaton.mdl")
SWEP.WorldModel = Model("models/weapons/w_stunbaton.mdl")

SWEP.Sound = Sound("weapons/stunstick/stunstick_swing1.wav")

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = ""
SWEP.Primary.Delay = 1.0

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""
SWEP.Secondary.Delay = 1.0

function SWEP:Initialize()
	self:NewSetWeaponHoldType("normal")
end

function SWEP:Deploy()
	if SERVER then
		self:SetWeaponHoldType("normal")
	end
end

function SWEP:Reload()
end

function SWEP:Think()
end
	
function SWEP:PrimaryAttack()
	local tr = self.Owner:GetEyeTrace()
	if !tr.Entity:IsPlayer() then return false end

	local Dist = self.Owner:EyePos():Distance(tr.HitPos)
	if Dist > ARREST_ArrestDistance then return false end
	
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	self.Weapon:SendWeaponAnim(ACT_VM_HITCENTER)
	
	self.Weapon:SetNextPrimaryFire(CurTime() + self.Primary.Delay)
	tr.Entity:Freeze( true )
	
	if SERVER then
		if IsValid(tr.Entity) and tr.Entity:IsPlayer() and tr.Entity:IsCP() and not GAMEMODE.Config.cpcanarrestcp then
			GAMEMODE:Notify(self.Owner, 1, 5, "You can not arrest other CPs!")
			return
		end

		if tr.Entity:IsNPC() then
			return
		end

		if GAMEMODE.Config.needwantedforarrest and not tr.Entity:IsNPC() and not tr.Entity:getDarkRPVar("wanted") then
			GAMEMODE:Notify(self.Owner, 1, 5, "The player must be wanted in order to be able to arrest them.")
			return
		end

		if FAdmin and tr.Entity:IsPlayer() and tr.Entity:FAdmin_GetGlobal("fadmin_jailed") then
			GAMEMODE:Notify(self.Owner, 1, 5, "You cannot arrest a player who has been jailed by an admin.")
			return
		end
		
		if tr.Entity:GetNWBool("Handcuffed") then
			GAMEMODE:Notify(tr.Entity, 1, 5, "You are being arrested. Please do what the officer says to avoid any conflicts.")
		else
			GAMEMODE:Notify(self.Owner, 1, 5, "You need to handcuff the player before you can arrest them.")
		end
		
		timer.Simple( 5, function() 
			tr.Entity:Freeze(false) 
		end)
	elseif CLIENT then
		if tr.Entity:GetNWBool("Handcuffed") then
			GUI_ArrestOptions( self.Owner, tr.Entity )
		end
	end
end

function SWEP:SecondaryAttack()
	local tr = self.Owner:GetEyeTrace()
	if !tr.Entity:IsPlayer() && tr.Entity:GetClass() != "prop_ragdoll" then return false end
	local Dist = self.Owner:EyePos():Distance(tr.HitPos)
	if Dist > ARREST_ArrestDistance then return false end
	
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	self.Weapon:SendWeaponAnim(ACT_VM_HITCENTER)
	
	if SERVER then
		if tr.Entity:GetClass() == "prop_ragdoll" && !tr.Entity.player:IsValid() then return false end
		
		local player = tr.Entity
		if tr.Entity:GetClass() == "prop_ragdoll" && tr.Entity.player:IsValid() then
			player = tr.Entity.player
			GAMEMODE:Notify(self.Owner, 1, 5, "You've handcuffed ".. player:Nick()..".")
			player:SetNWBool("Handcuffed", true )
		else
			if player:GetNWBool("Handcuffed") then
				player:SetNWBool("Handcuffed", false)
				GAMEMODE:Notify(self.Owner, 1, 5, "You've released "..player:Nick().." from his handcuffs.")
				return
			end
		end	
	end
	
	if CLIENT then
		if !tr.Entity:GetNWBool("Handcuffed") && tr.Entity:IsPlayer() then
			self.Target = tr.Entity
			self.JailTime = CurTime() + 1
		end
	end
	self.Weapon:SetNextSecondaryFire(CurTime() + self.Secondary.Delay)
end

function SWEP:Think()
	local tr = self.Owner:GetEyeTrace()
	if !tr.Entity:IsPlayer() then return false end
	local Dist = self.Owner:EyePos():Distance(tr.HitPos)
	if Dist > ARREST_ArrestDistance then return false end
end
	
if CLIENT then
	function SWEP:DrawHUD()
		local tr = self.Owner:GetEyeTrace()
		if !tr.Entity:IsPlayer() then self.Target = nil self.JailTime = nil end

		local Dist = self.Owner:EyePos():Distance(tr.HitPos)
		if Dist > ARREST_ArrestDistance then self.Target = nil self.JailTime = nil return false end
		
		if tr.Entity == self.Target then
			if self.JailTime <= CurTime() then
				net.Start("AS_Handcuff")
					net.WriteString(self.Owner:EntIndex())
					net.WriteString(self.Target:EntIndex())
				net.SendToServer()
				
				self.Target = nil
				self.JailTime = nil
				return
			else
				surface.SetDrawColor(50,50,50,155)
				surface.DrawRect(ScrW()/2 - 101,ScrH()/2 - 11,202,22)

				surface.SetDrawColor(200,200,200,155)
				surface.DrawRect(ScrW()/2 - 100,ScrH()/2 - 10,200*(((self.JailTime-CurTime())/1)),20)
				
				surface.SetTextColor(255,255,255,255)
				surface.SetFont("UiBold")
				local x,y = surface.GetTextSize("Hand-Cuffing")
				surface.SetTextPos(ScrW()/2 -x/2,ScrH()/2-y/2)
				surface.DrawText("Hand-Cuffing")
			end
		end
	end
end