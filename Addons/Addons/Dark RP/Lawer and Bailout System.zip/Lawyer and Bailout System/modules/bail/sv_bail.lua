util.AddNetworkString( "LawyerOpenBailMenu" )
util.AddNetworkString( "LawyerOfferBail" )
util.AddNetworkString( "AcceptBailOffer" )

util.AddNetworkString( "PlayerBailOffer" )

resource.AddFile( "materials/gui/attorney-legal.png" )

net.Receive( "LawyerOfferBail", function( len, ply )
	if not table.HasValue( BAIL.AllowedTeams, ply:Team( ) ) then
		print( "wrongteam" )
		return
	end
	
	local plyToBail = net.ReadEntity( )
	local bailAmount = net.ReadUInt( 16 )
	if not IsValid( plyToBail ) or not plyToBail.DarkRPVars.Arrested then
		print( "notarrested" )
		return
	end
	
	--Transmit offer to player
	net.Start( "PlayerBailOffer" )
		net.WriteEntity( ply )
		net.WriteUInt( bailAmount, 16 )
	net.Send( plyToBail )
end )

net.Receive( "AcceptBailOffer", function( len, ply )
	local lawyer, amount = net.ReadEntity( ), net.ReadUInt( 16 )
	
	if not IsValid( ply ) or not ply.DarkRPVars.Arrested or not ply:CanAfford( amount ) then
		return
	end
	
	ply:AddMoney( -amount )
	ply:unArrest( )
	lawyer:AddMoney( amount * BAIL.LawyerFraction )
end )

local function RequestBail( ply )
	if not table.HasValue( BAIL.AllowedTeams, ply:Team( ) ) then
		GAMEMODE:Notify(ply, 1, 4, string.format( "You don't have the right job to use /bail"))
		return ""
	end
	
	local LookingAt = ply:GetEyeTrace().Entity

	if not IsValid(LookingAt) or not LookingAt.DarkRPVars.Arrested then
		GAMEMODE:Notify(ply, 1, 4, string.format( "You must be looking at an arrested player to use this command"))
		return ""
	end

	net.Start( "LawyerOpenBailMenu" )
		net.WriteEntity( LookingAt )
	net.Send( ply )
end
AddChatCommand( "/bail", RequestBail )
print( "bail addon loaded" )

hook.Add( "EntityTakeDamage", "asdfniggre", function( target, dmginfo )
	if target:IsPlayer( ) and IsValid( dmginfo:GetAttacker( ) ) and dmginfo:GetAttacker( ):IsPlayer( ) then
		if table.HasValue( BAIL.DisableTeamDamage, dmginfo:GetAttacker( ):Team( ) ) and table.HasValue( BAIL.DisableTeamDamage, target:Team( ) ) then
			dmginfo:SetDamage( 0 )
		end
	end
end )