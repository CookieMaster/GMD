BAIL = {}

TEAM_LAWYER = AddExtraTeam("Lawyer", {
	color = Color(150, 30, 30, 255),
	model = "models/player/breen.mdl",
	description = [[As a Laywer you can bail other players out of jail and represent them in front of the police.
	You can use /bail when looking at a jailed player to open the bail menu.
	]],
	weapons = {},
	command = "lawyer",
	max = 2,
	salary = 80,
	admin = 0,
	vote = false,
	hasLicense = false
})


BAIL.AllowedTeams = {TEAM_LAWYER} --Teams that are allowed to use /bail on arrested players
BAIL.MinimumAmount = 50			--Minimum amount that the lawyer can set
BAIL.MaximumAmount = 350		--Minimum amount that the lawyer can set
BAIL.LawyerFraction = 2/3		--Fraction of the bail money that the lawyer will receive

--Team damage is disabled for the teams in this list
--Remove the dashes to enable.
BAIL.DisableTeamDamage = {
	--TEAM_MAYOR,
	--TEAM_CHIEF,
	--TEAM_POLICE
}