/// ───────────────────────── Player TeamChange
local HName = "PlayerTeamChange"
hook.Add( "OnPlayerChangedTeam", "ADVLOG " .. HName, function(ply,oldteam,newteam)
	local LHOOK = AdvLoger.Hooks[HName]
	if LHOOK and LHOOK.Enable then
		local LMsg = LHOOK.Format
		LMsg = string.gsub(LMsg,"#1",ply:Nick())
		LMsg = string.gsub(LMsg,"#2",team.GetName(oldteam))
		LMsg = string.gsub(LMsg,"#3",team.GetName(newteam))
		ADVLOG_DoLog(LMsg,HName)
	end
end)


/// ───────────────────────── Player Arrested
local HName = "playerArrested"
hook.Add( "playerArrested", "ADVLOG " .. HName, function(ply,time,arrester)
	local LHOOK = AdvLoger.Hooks[HName]
	if LHOOK and LHOOK.Enable then
		local LMsg = LHOOK.Format
		LMsg = string.gsub(LMsg,"#1",ply:Nick())
		LMsg = string.gsub(LMsg,"#2",arrester:Nick())
		LMsg = string.gsub(LMsg,"#3",time)
		ADVLOG_DoLog(LMsg,HName)
	end
end)

/// ───────────────────────── Player UnArrested
local HName = "playerUnArrested"
hook.Add( "playerUnArrested", "ADVLOG " .. HName, function(ply)
	local LHOOK = AdvLoger.Hooks[HName]
	if LHOOK and LHOOK.Enable then
		local LMsg = LHOOK.Format
		LMsg = string.gsub(LMsg,"#1",ply:Nick())
		ADVLOG_DoLog(LMsg,HName)
	end
end)

