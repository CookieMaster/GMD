/// ───────────────────────── Player FirstJoin
local HName = "ServerStart"
hook.Add( "InitPostEntity", "ADVLOG " .. HName, function(ply)
	local LHOOK = AdvLoger.Hooks[HName]
	if LHOOK and LHOOK.Enable then
		local LMsg = LHOOK.Format
		ADVLOG_DoLog(LMsg,HName)
	end
end)

/// ───────────────────────── Player FirstJoin
local HName = "ShutDown"
hook.Add( "ShutDown", "ADVLOG " .. HName, function(ply)
	local LHOOK = AdvLoger.Hooks[HName]
	if LHOOK and LHOOK.Enable then
		local LMsg = LHOOK.Format
		ADVLOG_DoLog(LMsg,HName)
	end
end)

/// ───────────────────────── Player FirstJoin
local HName = "PlayerFirstJoin"
hook.Add( "PlayerInitialSpawn", "ADVLOG " .. HName, function(ply)
	local LHOOK = AdvLoger.Hooks[HName]
	if LHOOK and LHOOK.Enable then
		local LMsg = LHOOK.Format
		LMsg = string.gsub(LMsg,"#1",ply:Nick())
		ADVLOG_DoLog(LMsg,HName)
	end
end)

/// ───────────────────────── Player Spawn
local HName = "PlayerSpawn"
hook.Add( "PlayerSpawn", "ADVLOG " .. HName, function(ply)
	local LHOOK = AdvLoger.Hooks[HName]
	if LHOOK and LHOOK.Enable then
		local LMsg = LHOOK.Format
		LMsg = string.gsub(LMsg,"#1",ply:Nick())
		ADVLOG_DoLog(LMsg,HName)
	end
end)

/// ───────────────────────── Player Disconnect
local HName = "PlayerDisconnect"
hook.Add( "PlayerDisconnected", "ADVLOG " .. HName, function(ply)
	local LHOOK = AdvLoger.Hooks[HName]
	if LHOOK and LHOOK.Enable then
		local LMsg = LHOOK.Format
		LMsg = string.gsub(LMsg,"#1",ply:Nick())
		ADVLOG_DoLog(LMsg,HName)
	end
end)


/// ───────────────────────── Player Death
local HName = "PlayerDeath"
hook.Add( "PlayerDeath", "ADVLOG " .. HName, function(victim,weapon,killer)
	local LHOOK = AdvLoger.Hooks[HName]
	if LHOOK and LHOOK.Enable then
		local LMsg = LHOOK.Format
		LMsg = string.gsub(LMsg,"#1",killer:Nick())
		LMsg = string.gsub(LMsg,"#2",victim:Nick())
		ADVLOG_DoLog(LMsg,HName)
	end
end)

/// ───────────────────────── Player Take Damage
local HName = "PlayerTakeDamage"
hook.Add( "EntityTakeDamage", "ADVLOG " .. HName, function( ent, dmginfo )
	local LHOOK = AdvLoger.Hooks[HName]
	if LHOOK and LHOOK.Enable and ent:IsPlayer() then
		local LMsg = LHOOK.Format
		LMsg = string.gsub(LMsg,"#1",ent:Nick())
		local Inflictor = dmginfo:GetInflictor()
		
		if Inflictor:IsPlayer() then
			LMsg = string.gsub(LMsg,"#2",Inflictor:Nick())
			local CurWep = dmginfo:GetInflictor():GetActiveWeapon()
			if CurWep then
				LMsg = string.gsub(LMsg,"#3",CurWep:GetClass())
			else
				LMsg = string.gsub(LMsg,"#3","??")
			end
		else
			LMsg = string.gsub(LMsg,"#3","!NO WEAPON DATA!")
			LMsg = string.gsub(LMsg,"#2",Inflictor:GetClass())
		end
		
		LMsg = string.gsub(LMsg,"#4",tostring(dmginfo:GetDamage()))
		ADVLOG_DoLog(LMsg,HName)
	end
end)


/// ───────────────────────── Player Say
local HName = "PlayerSay"
hook.Add( "PlayerSay", "ADVLOG " .. HName, function(ply,text)
	local LHOOK = AdvLoger.Hooks[HName]
	if LHOOK and LHOOK.Enable then
		local LMsg = LHOOK.Format
		LMsg = string.gsub(LMsg,"#1",ply:Nick())
		LMsg = string.gsub(LMsg,"#2",text)
		ADVLOG_DoLog(LMsg,HName)
	end
end)




/// ───────────────────────── Player Say
local HName = "PlayerSpawnProp"
hook.Add( "PlayerSpawnProp", "ADVLOG " .. HName, function(ply,mdl)
	local LHOOK = AdvLoger.Hooks[HName]
	if LHOOK and LHOOK.Enable then
		local LMsg = LHOOK.Format
		LMsg = string.gsub(LMsg,"#1",ply:Nick())
		LMsg = string.gsub(LMsg,"#2",mdl)
		ADVLOG_DoLog(LMsg,HName)
	end
end)


