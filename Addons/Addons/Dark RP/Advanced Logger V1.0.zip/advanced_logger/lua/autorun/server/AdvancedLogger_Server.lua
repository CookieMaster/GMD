ADVLOGDB = ADVLOGDB or {}

function ADVLOG_CheckTable(CurDay)
	sql.Query( "CREATE TABLE IF NOT EXISTS ADV_Logger_" .. CurDay .. " ( ID INTEGER PRIMARY KEY, Time STRING, Type STRING, Message STRING )" )
	sql.Query( "INSERT INTO ADVLogger_List (`Name`)VALUES ('"..CurDay.."')" )
end

hook.Add("InitPostEntity", "ADVLOG Dir Check", function()
	sql.Query( [[CREATE TABLE IF NOT EXISTS ADVLogger_List (
		Name STRING
	)]] )
end)

function ADVLOG_DoLog(msg,type)

	local CurDay = tostring( os.date("%Y_%m_%d") )
	local Time = tostring(os.date("%H:%M:%S"))
	
	type = type or "None"
	msg = msg or "No Message"
	
	type = tostring(type)
	msg = tostring(msg)
	msg = string.gsub(msg,"'","|")
	MsgN(msg)
	
	
	if sql.TableExists("ADV_Logger_"..CurDay) then --파일 있음. 날짜가 넘어가지 않음.
		MsgN("EXIST")
		sql.Query( "INSERT INTO ".."ADV_Logger_"..CurDay.." (`Time`, `Type`, `Message`)VALUES ('"..Time.."', '"..type.."', '"..msg.."')" ) -- 데이터 삽입
	else -- 파일 없음. 넘어감
		ADVLOG_CheckTable(CurDay)
		sql.Query( "INSERT INTO ".."ADV_Logger_"..CurDay.." (`Time`, `Type`, `Message`)VALUES ('"..Time.."', '"..type.."', '"..msg.."')" ) -- 데이터 삽입
	end
end