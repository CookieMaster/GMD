local meta = FindMetaTable("Player");
LogFilterData = LogFilterData or {}

local ListAmount = 70
local AvailableGroups = {}
AvailableGroups["superadmin"] = true
AvailableGroups["owner"] = true

if CLIENT then 
	concommand.Add("Advlogger_open",function(ply,cmd,args)
		MsgN(ply:GetNWString("usergroup"))
		if !AvailableGroups[ply:GetNWString("usergroup")] then return end
		
		AdvLogger_Open()
	end)
	
	net.Receive( "ADVLOG_LogList_S2C", function( len,ply )
		local DATA = net.ReadTable()
		LogFilterData = DATA.HookList
		
		if AdvLoggerPanel and AdvLoggerPanel:IsValid() then
			AdvLoggerPanel:UpdateLogFileList(DATA.Data)
		end
	end)
	
	net.Receive( "ADVLOG_Log_S2C", function( len,ply )
		local DATA = net.ReadTable()
		if AdvLoggerPanel and AdvLoggerPanel:IsValid() then
			AdvLoggerPanel:UpdateLog(DATA)
		end
	end)
	
	
	function RequestLogList()
		net.Start( "ADVLOG_RequestLogList_C2S" )
		net.SendToServer()
	end
	function RequestLog(day,page)
		net.Start( "ADVLOG_RequestLog_C2S" )
			net.WriteTable({Page=page,Day=day,Filter=LogFilterData})
		net.SendToServer()
	end

end
if SERVER then
	util.AddNetworkString( "ADVLOG_RequestLog_C2S" )
	util.AddNetworkString( "ADVLOG_RequestLogList_C2S" )
	util.AddNetworkString( "ADVLOG_LogList_S2C" )
	util.AddNetworkString( "ADVLOG_Log_S2C" )

	net.Receive( "ADVLOG_RequestLog_C2S", function( len,ply ) --
		local DATA = net.ReadTable()
		local Filter = DATA.Filter
		
		local FilterQuery = nil
		for k,v in pairs(Filter) do
			if v then
				if !FilterQuery then FilterQuery = "WHERE TYPE =" end
				FilterQuery = FilterQuery .. sql.SQLStr(k) .. " or TYPE = "
			end
		end
		FilterQuery = string.Left(FilterQuery,string.len(FilterQuery)-11)

		local page = DATA.Page
		local Data = sql.Query( "SELECT * FROM ADV_Logger_"..DATA.Day.." "..FilterQuery.." ORDER BY ID LIMIT "..ListAmount.." OFFSET " .. (page-1)*ListAmount )

		local FullData = sql.Query( "SELECT * FROM ADV_Logger_"..DATA.Day.." "..FilterQuery.." ORDER BY ID")
		local Amount = #FullData
		
		
		
		local TB2Send = {}
		TB2Send.Log = Data
		TB2Send.Amount = Amount
		
		net.Start( "ADVLOG_Log_S2C" )
			net.WriteTable(TB2Send)
		net.Send(ply)
	end)
	
	
	net.Receive( "ADVLOG_RequestLogList_C2S", function( len,ply )
		
		local TB2Send = {}
		
		local HookList = {}
		for k,v in pairs(AdvLoger.Hooks) do
			if v.Enable then
				HookList[k] = true
			end
		end
		TB2Send.HookList = HookList
		TB2Send.Data = sql.Query( "SELECT * FROM ADVLogger_List")
		
		
		net.Start( "ADVLOG_LogList_S2C" )
			net.WriteTable(TB2Send)
		net.Send(ply)
	end)
	
end

if CLIENT then

	function AdvLogger_Open()
		if AdvLoggerPanel and AdvLoggerPanel:IsValid() then
			AdvLoggerPanel:Remove()
			AdvLoggerPanel = nil
		end
			AdvLoggerPanel = vgui.Create("AdvLogger")
			AdvLoggerPanel:SetPos(0,0)
			AdvLoggerPanel:SetSize(ScrW(),ScrH())
			AdvLoggerPanel.SellerNPC = SellerNPC
			AdvLoggerPanel:Install()
			AdvLoggerPanel:MakePopup()
			AdvLoggerPanel.NearMyCars = NearMyCars or {}
			
			return AdvLoggerPanel
	end
end

if CLIENT then

local PANEL = {}
function PANEL:Init()
	self:ShowCloseButton(false)
	self:SetTitle(" ")
	self:SetDraggable(false)
	
	self.LogPage = 1
	self.LogMaxPage = 1
	
	self.CarList = {}
	
	self.CarColor = Color(255,255,255,255)
end
function PANEL:UpdateLog(DATA)
	self.LogDataLister:Clear()
	
	self.CurLogFullAmount = DATA.Amount
	self.LogMaxPage = math.ceil(DATA.Amount/ListAmount)
	for k,v in pairs(DATA.Log) do
		local BT = vgui.Create("DButton")
		BT:SetSize(self.LogDataLister:GetWide(),20)
		BT:SetText(" ")
		BT.OnCursorEntered = function(slf) slf.Hover = true end
		BT.OnCursorExited = function(slf) slf.Hover = false end
		BT:SetToolTip(v.Message)
		BT.Paint = function(slf)
			local ColoJ = 25+(k%2)*10
			if slf.Hover then
				surface.SetDrawColor( Color(100,100,100,255) )
			else
				surface.SetDrawColor( Color(ColoJ,ColoJ,ColoJ,255) )
			end
			surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
			draw.SimpleText(v.ID, "SansationOut_S20", 10,0, Color(0,200,255,255))
			draw.SimpleText("[ " .. v.Time .. " ]", "SansationOut_S20", 100,0, Color(0,200,255,255))
			draw.SimpleText(v.Type, "SansationOut_S20", 250,0, Color(0,120,255,255))
			draw.SimpleText(v.Message, "SansationOut_S20", 480,0, Color(220,220,220,255))
		end
		BT.DoClick = function(slf)
			SetClipboardText(v.ID .. "   [ " .. v.Time .. " ]   " .. v.Type .. "  " .. v.Message);
		end
		self.LogDataLister:AddItem(BT)
	end
end

function PANEL:UpdateLogFileList(DATA)
	self.LogFileListLT:Clear()
	
	for k,v in pairs(DATA) do
		local BT = vgui.Create("DButton")
		BT:SetSize(self.LogFileListLT:GetWide(),20)
		BT:SetText(" ")
		BT.OnCursorEntered = function(slf) slf.Hover = true end
		BT.OnCursorExited = function(slf) slf.Hover = false end
		BT.Paint = function(slf)
			local ColoJ = 25+(k%2)*10
			if self.CurLogDay == v.Name then
				surface.SetDrawColor( Color(100,100,100,255) )
			else
				if slf.Hover then
					surface.SetDrawColor( Color(100,100,100,255) )
				else
					surface.SetDrawColor( Color(ColoJ,ColoJ,ColoJ,255) )
				end
			end
			surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
			draw.SimpleText(v.Name, "SansationOut_S20", 10,0, Color(0,200,255,255))
		end
		BT.DoClick = function(slf)
			self.LogPage = 1
			RequestLog(v.Name,self.LogPage)
			self.CurLogDay = v.Name
		end
		self.LogFileListLT:AddItem(BT)
	end
	
	self.ControlPanelLister:Clear()
	
		local FilterBG = vgui.Create("DPanel")
		FilterBG:SetSize(self.ControlPanelLister:GetWide(),math.ceil(table.Count(LogFilterData)/2)*20)
		FilterBG.Paint = function(slf) end
		
		local Count = 0
		for k,v in pairs(LogFilterData) do
			Count = Count + 1
			
			local CheckBoxThing = vgui.Create( "DCheckBoxLabel", FilterBG )
			CheckBoxThing:SetPos( 10 + (Count%2)*(FilterBG:GetWide()/2),math.ceil(Count/2)*20 - 19 )
			CheckBoxThing:SetText( k )
			if v then
				CheckBoxThing:SetChecked(true)
			end
			CheckBoxThing.OnChange = function(pSelf, fValue)
			   if fValue then
					LogFilterData[k] = true
			   else
					LogFilterData[k] = false
			   end
			end
			CheckBoxThing:SizeToContents() -- Make its size to the contents. Duh?
		end
		
		self.ControlPanelLister:AddItem(FilterBG)
		
	
end

function PANEL:Paint()
		surface.SetDrawColor( Color(0,150,255,255) )
		surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
		
		surface.SetDrawColor( Color(0,0,0,255) )
		surface.DrawRect( 2, 2, self:GetWide()-4, self:GetTall()-4 )
end

function PANEL:Install()
	RequestLogList()
	
	local BGP = vgui.Create("DPanel",self)
	BGP:SetPos(10,15)
	BGP:SetSize(200,30)
	BGP.Paint = function(slf)
		surface.SetDrawColor( 0,150,255,255 )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		surface.SetDrawColor( 0,40,80,255 )
		surface.DrawRect( 1, 1, slf:GetWide()-2, slf:GetTall()-2 )
		
		draw.SimpleText("Day Log List", "SansationOut_S20", 50,5, Color(0,200,255,255))
	end
	
	local ControlPanel = vgui.Create("DPanel",self)
	ControlPanel:SetPos(220,15)
	ControlPanel:SetSize(self:GetWide()-230,30)
	ControlPanel.Paint = function(slf)
		surface.SetDrawColor( 0,150,255,255 )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		surface.SetDrawColor( 0,40,80,255 )
		surface.DrawRect( 1, 1, slf:GetWide()-2, slf:GetTall()-2 )
		
		if self.CurLogDay then
			draw.SimpleText("Cur List : " .. self.CurLogDay .. " ( total log amount : " .. (self.CurLogFullAmount or 0) .. " )", "SansationOut_S20", 10,5, Color(0,200,255,255))
		else
			draw.SimpleText("Advanced Logger by RocketMania", "SansationOut_S20", 10,5, Color(0,200,255,255))
		end
	end
	
	local ControlPanelLister = vgui.Create("DPanelList",self)
	ControlPanelLister:SetPos(220,50)
	ControlPanelLister:SetSize(self:GetWide()-400,100)
	ControlPanelLister.Paint = function(slf)
		surface.SetDrawColor( 0,150,255,255 )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		surface.SetDrawColor( 0,25,50,255 )
		surface.DrawRect( 1, 1, slf:GetWide()-2, slf:GetTall()-2 )
	end
	ControlPanelLister:EnableVerticalScrollbar(true);
	ControlPanelLister:EnableHorizontal(false)
	self.ControlPanelLister = ControlPanelLister

	
	local PageMain = vgui.Create("DPanel",self)
	PageMain:SetPos(self:GetWide()-175,50)
	PageMain:SetSize(165,100)
	PageMain.Paint = function(slf)
		surface.SetDrawColor( 0,150,255,255 )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		surface.SetDrawColor( 0,40,80,255 )
		surface.DrawRect( 1, 1, slf:GetWide()-2, slf:GetTall()-2 )

		draw.SimpleText("Page", "SansationOut_S20", 82,5, Color(0,200,255,255),TEXT_ALIGN_CENTER)
		draw.SimpleText(self.LogPage .. " / " .. self.LogMaxPage, "SansationOut_S20", 85,25, Color(0,200,255,255),TEXT_ALIGN_CENTER)
	end
	
	
		local Page = vgui.Create("ADVLG_DSWButton",PageMain)
		Page:SetPos(25,50)
		Page:SetSize(30,30)
		Page:SetTexts("<")
		Page.Click = function(slf)
			if self.CurLogDay and self.LogPage > 1 then
				self.LogPage = self.LogPage - 1
				RequestLog(self.CurLogDay,self.LogPage)
			end
		end
		
		local Page = vgui.Create("ADVLG_DSWButton",PageMain)
		Page:SetPos(110,50)
		Page:SetSize(30,30)
		Page:SetTexts(">")
		Page.Click = function(slf)
			if self.CurLogDay and self.LogPage < self.LogMaxPage then
				self.LogPage = self.LogPage + 1
				RequestLog(self.CurLogDay,self.LogPage)
			end
		end
		
		local BT = vgui.Create("ADVLG_DSWButton",ControlPanel)
		BT:SetPos(ControlPanel:GetWide()-150,0)
		BT:SetSize(150,30)
		BT:SetTexts("Close")
		BT.Click = function(slf)
			self:Remove()
		end
	
	self.LogFileListLT = vgui.Create("DPanelList", self)
		self.LogFileListLT:SetPos(10,50)
		self.LogFileListLT:SetSize(200,self:GetTall() - 60)
		self.LogFileListLT:SetSpacing(3);
		self.LogFileListLT:SetPadding(0);
		self.LogFileListLT:EnableVerticalScrollbar(true);
		self.LogFileListLT:EnableHorizontal(false)
		self.LogFileListLT.Paint = function(slf)
			surface.SetDrawColor( 0,10,20,255 )
			surface.DrawRect( 1, 1, slf:GetWide()-2, slf:GetTall()-2 )
		end
		
	self.LogDataLister = vgui.Create("DPanelList", self)
		self.LogDataLister:SetPos(220,160)
		self.LogDataLister:SetSize(self:GetWide()-230,self:GetTall() - 170)
		self.LogDataLister:SetSpacing(3);
		self.LogDataLister:SetPadding(0);
		self.LogDataLister:EnableVerticalScrollbar(true);
		self.LogDataLister:EnableHorizontal(false)
		self.LogDataLister.Paint = function(slf)
			surface.SetDrawColor( 0,10,20,255 )
			surface.DrawRect( 1, 1, slf:GetWide()-2, slf:GetTall()-2 )
		end
		
	
end


vgui.Register("AdvLogger",PANEL,"DFrame")



end