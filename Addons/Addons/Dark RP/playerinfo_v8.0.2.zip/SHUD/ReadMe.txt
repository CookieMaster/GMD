
# Installation
1. Extract shud_8.0.2 in garrysmod > garrysmod > addons.
2. Restart your server.

# Usage
1. Go to garrysmod > garrysmod > addons > SHUD > client > shud.lua
2. Change the configs

# Support
Email: samuel@nonexhosting.com
Steam: sam9709

# Updates
Visit the coderhire page to see/download the updates

# How to remove the DarkRP one?
[The new DarkRP]
1. Go to garrysmod > garrysmod > gamemodes > darkrp > gamemode > modules > hud > cl_hud.lua
2. Find "DrawPlayerInfo"
3. Replace the DrawPlayerInfo function (from "local function DrawPlayerInfo(ply)" to "end") with the index of DrawPlayerInfo.lua

[The old DarkRP]
1. Go to garrysmod > garrysmod > gamemodes > darkrp > gamemode > client > hud.lua
2. Find "DrawPlayerInfo"
3. Replace the DrawPlayerInfo function (from "local function DrawPlayerInfo(ply)" to "end") with the index of DrawPlayerInfo.lua