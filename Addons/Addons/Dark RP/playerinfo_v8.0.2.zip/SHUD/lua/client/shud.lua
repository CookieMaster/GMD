/*---------------------------------------------------------------------------------------------------------
© Samuel DH Ahlstrom. All Rights Reserved under the Swedish Law (1960:729)
---------------------------------------------------------------------------------------------------------*/
////////////////////////
//  SHud Version 8.0  //
////////////////////////

local SHud = {}
SHud.Config = {}

//Configs
SHud.Config.vrange = 400 //Range of the player card
SHud.Config.showinfohp = true //HP bar under the job name
SHud.Config.showgang = false //Show gang name (DarkRP Gang System)
SHud.Config.showrank = true //Show the rank of admins
SHud.Config.round = 1 //The main box: 1 = Default , 2 = Square
SHud.Config.font = 1 //Text fonts: 1 = Default, 2 = SHud BIG, 3 = Old School

//Configs that will be added in 8.1 and 8.2
SHud.Config.lang = 1 //Languages: 1 = English, 2 = Swedish, 3 = Danish
SHud.Config.nlr = false //Show nlr time left (NLR DLC Needed)

//DLC Configs (*Will be added in 8.1 or 8.2*)
SHud.Config.snlr = false //Enable/Disable nlr module

//Colors
local nametext = Color(10,10,10,180)
local namebg = Color(160, 160, 160)

local jobtext = Color(255, 255, 255)
local jobbg = Color(255, 255, 255)

local gang = Color(200, 200, 200, 200)
local gangbg = Color(200, 200, 200, 200)

local ranktext = Color(255,255,255,180)
local rankbg = Color(0, 0, 0, 200)

//Text
local wantedtext = "Wanted by The Police"

//Icons    
local gun = "icon16/gun.png"
local paper = "icon16/page.png"


//Ranks    
    SHud.Ranks = {}
    SHud.Ranks["superadmin"] = {"Super Admin", "icon16/shield_add.png"}
    SHud.Ranks["admin"] = {"Admin", "icon16/shield.png"}
	

//Only edit if you know what you are doing
    if SHud.Config.font == 1 then 
    surface.CreateFont ("SHudName", {
    size = 23,
    weight = 400,
    antialias = true,
    shadow = false,
    font = "coolvetica"})
    end
    if SHud.Config.font == 2 then 
    surface.CreateFont ("SHudName", {
    size = 23,
    weight = 400,
    antialias = true,
    shadow = false,
    font = "DejaVu Sans"})
    end
    if SHud.Config.font == 3 then 
    surface.CreateFont ("SHudName", {
    size = 20,
    weight = 400,
    antialias = true,
    shadow = false,
    font = "akbar"})
    end
	
    local function drb(r, x, y, w, h, col)
    draw.RoundedBox(r, x, y, w, h, col)
    end
    
    local function ddt(text, font, x, y, col, align)
    draw.DrawText(text, font, x, y, col, align or 0)
    end
     
    local function dicon(mat, x, y, w, h)
    surface.SetDrawColor( 255, 255, 255, 255 )
    surface.SetMaterial( Material(mat) )
    surface.DrawTexturedRect( x, y, w, h)  
    end

    function SHud.DrawHUD(ply)
    local pos = ply:EyePos()
 
    pos.z = pos.z + 10
    pos = pos:ToScreen()
    pos.y = pos.y - 50
    ply.DarkRPVars = ply.DarkRPVars or {}
    local RankData = SHud.Ranks[ply:GetUserGroup()] or {}
    local hasRank = (RankData[1] and true or false)
    local x, y = pos.x - 115 , pos.y + 1
    local w, h = 250, (hasRank and SHud.Config.showrank and 90 or 60)
    local name = ply:Nick() or "???"
    local tname = ply.DarkRPVars.job or teamname or "???"	
    if SHud.Config.round == 1 then 
	round = 6
	end	
    if SHud.Config.round == 2 then 
	round = 0
    end
    
	drb(round, x, y, w, h, Color(10,10,10,180))
  
    drb(round, x + 3, y + 3, w - 6, 25, nametext)
    ddt(name, "SHudName", x + w / 2, y + 4, namebg, TEXT_ALIGN_CENTER)
 
    ddt(tname, "SHudName", x + w / 2, y + 34, nametext, TEXT_ALIGN_CENTER)     
   
    local tcol = team.GetColor(ply:Team())
    if SHud.Config.showinfohp then
    local hp = ply:Health()
    local unit = (w - 6) / 100
     
    drb(round, x + 3, y + 32, w - 6, 25, Color(tcol.r / 2, tcol.g / 2, tcol.b / 2))
    drb(round, x + 3, y + 32, math.Clamp(hp * unit, 12, w - 6), 25, tcol)
    else
    drb(round, x + 3, y + 32, w - 6, 25, tcol) 
    end
   
    ddt(tname, "SHudName", x + w / 2, y + 34, jobtext, TEXT_ALIGN_CENTER)     
    if SHud.Config.showgang then
    local gang = ply:GetNWString("Gang")
    if gang != "" then
    drb(round, x, y - 28, w, 25, gangbg)
    ddt(gang, "SHudName", x + w / 2, y - 26, gang, TEXT_ALIGN_CENTER)
    end
    end

    if hasRank and SHud.Config.showrank then
    local rank = RankData[1]
    surface.SetFont("SHudName")
    local tw = surface.GetTextSize(rank) + 30
    local txtPos = x + w / 2 - tw / 2
    drb(round, txtPos, pos.y + 62, tw, 25, rankbg)
    ddt(rank, "SHudName", txtPos + 24, y + 64, ranktext)
    dicon(RankData[2], txtPos + 4, y + 66, 16, 16)
    end
    
    if ply.DarkRPVars.HasGunlicense then
    dicon(paper, x + 10, y + 66, 16, 16)
    dicon(gun, x + 9, y + 68, 16, 16)
    end
    
    if ply:getDarkRPVar("wanted") and ply:Alive() then
    local wy = y - 33
    if SHud.Config.showgang and ply:GetNWString("Gang") != "" then
    wy = wy - 23
    end
    drb(round, x, wy, w, 25, Color(0, 0, 0, 200))
    ddt(wantedtext, "SHudName", x + w / 2, wy + 2, Color(255, 255, 255, 200), TEXT_ALIGN_CENTER)
    ddt(wantedtext, "SHudName", x + w / 2 - 1, wy + 3, Color(255, 0, 0), TEXT_ALIGN_CENTER)
    end
    end
    
    local function SDisplay()
    local localply = LocalPlayer()
    local localpos = localply:GetShootPos()
      
    for k, v in pairs(player.GetAll()) do  
	//if !v:Alive() then return false end
    local pos = v:GetShootPos()
    if localpos:Distance(pos) < SHud.Config.vrange then
    local diff = pos - localpos
    local trace = util.QuickTrace(localpos, diff, localply)
    if trace.Hit and trace.Entity ~= v then return end
    SHud.DrawHUD(v)
	end
	end
    end
    hook.Add("HUDPaint", "DrawSammyHud", SDisplay)