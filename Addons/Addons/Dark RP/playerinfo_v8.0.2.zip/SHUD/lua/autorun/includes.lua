/////////////////////////////////////////////
//            Do not edit this             //
/////////////////////////////////////////////

if SERVER then
	AddCSLuaFile('client/shud.lua')
	AddCSLuaFile('configs.lua')
end

if CLIENT then
    include('client/shud.lua')
    include('configs.lua')
end

//////////////////////////////////////////
//      Please dont remove this         //
//////////////////////////////////////////
function version()
	print( "This server is running SHUD version 8.0.1 by Samuel" )
end
concommand.Add( "shud_version", version )
//////////////////////////////////////////
//      Please dont remove this         //
//////////////////////////////////////////