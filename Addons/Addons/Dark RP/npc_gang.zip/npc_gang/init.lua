AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )

include( 'shared.lua' )


local SPAWN_POS = Vector(-4433.378418, 2958.572021, -203.968750)
local SPAWN_ANG = Angle(-0, -32, 0)

P_ORGS = {}

local function SpawnNPC()
	timer.Simple(5,function()
		local npc = ents.Create("npc_gang")
		npc:SetPos(SPAWN_POS)
		npc:SetAngles(SPAWN_ANG)
		npc:Spawn()
	end)

end
hook.Add("InitPostEntity","SpawnGangNPC",SpawnNPC)


function ENT:Initialize( )
	self:SetModel( "models/odessa.mdl" )
 	self:SetHullType( HULL_HUMAN )
	self:SetUseType( SIMPLE_USE )
	self:SetHullSizeNormal( )
	self:SetSolid( SOLID_BBOX )
	self:CapabilitiesAdd( CAP_ANIMATEDFACE || CAP_USE_SHOT_REGULATOR || CAP_TURN_HEAD || CAP_AIM_GUN )
	self:SetMaxYawSpeed( 5000 )
	local PhysAwake = self.Entity:GetPhysicsObject( )
	if PhysAwake:IsValid( ) then
		PhysAwake:Wake( )
	end 
end

function ENT:OnTakeDamage( dmg ) 
	return false
end

function ENT:AcceptInput( name, activator, caller )
    if ( name == "Use" && IsValid( activator ) && activator:IsPlayer( ) ) then
    	if activator:GetNWBool("Org_Leader",true) == true then
    		umsg.Start("OrgDisband",activator)
    		umsg.End()
    	elseif activator:GetNWString("Gang","") != "" then
    		umsg.Start("OrgLeave",activator)
    		umsg.End()
    	else
			umsg.Start( "OrgRegister", activator )
			umsg.End( )
		end
    end
end




local function PInitSpawn(ply)
	ply:SetNWString("Gang","")
	ply:SetNWBool("Org_Leader",false)
	SetupPlayerOrg(ply)
	ply.Invited = {}
end
hook.Add("PlayerInitialSpawn","InitValues",PInitSpawn)

local function PDisconnect(ply)
	ply:LeaveGang()
end
//hook.Add("PlayerDisconnect","PLeave",PDisconnect)

local function InvitePlayer(ply,cmd,args)
	local p2i = GAMEMODE:FindPlayer(args[1])

	if !ply:InGang() then
		GAMEMODE:Notify(ply,1,3,"You must be in an gang to invite someone!")
		return
	end

	if !p2i then
		GAMEMODE:Notify(ply,1,3, "No player found to invite!")
		return
	end

	if (p2i == ply) then
		GAMEMODE:Notify(ply,1,3,"You cannot invite your imaginary friend!")
		return
	end

	if (p2i:GetNWString("Gang","") != "") then
		GAMEMODE:Notify(ply, 1, 3, "That player is already in an gang!")
		return
	end

	if (ply:GetNWBool("Org_Leader",false) != true) then
		GAMEMODE:Notify(ply,1,3, "Only gang leaders can invite people!")
		return
	end

	if !table.HasValue(p2i.Invited,ply:GetNWString("Gang","")) then
		table.insert(p2i.Invited,ply:GetNWString("Gang",""))
		GAMEMODE:Notify(p2i,3,3,"You have been invited to "..ply:GetNWString("Gang","").."!")
		GAMEMODE:Notify(ply,3,3,"You have invited "..p2i:Name().." to your gang!")
		p2i:ConCommand("org_invited \""..ply:GetNWString("Gang","").."\"")
		return
	end
end
concommand.Add("org_invite",InvitePlayer)

local function CreateOrg(ply,cmd,args)
	local name = args[1]

	if ply:InGang() then
		GAMEMODE:Notify(ply,1,3,"You must leave your current gang before you create one!")
		return
	end

	if !name then
		GAMEMODE:Notify(ply,1,3,"You must enter an gang name!")
		return
	end

	if ply:CanAfford(GANG_COST) then
		ply:AddMoney(-GANG_COST)
	else
		GAMEMODE:Notify(ply, 1, 3, "You need $20,000 in your wallet to start an gang!")
		return
	end

	if GangExists(name) then
		GAMEMODE:Notify(ply,1,3,"An gang with that name already exists!")
		return
	end

	
	AddPlayerToOrg(ply,name)
	NewGang(name,ply)
	ply:SetNWBool("Org_Leader",true)

	GAMEMODE:Notify(ply,0,3, "Your gang has been registered!")
end
concommand.Add("org_create",CreateOrg)

local function JoinOrg(ply,cmd,args)
	local name = args[1]

	if ply:InGang() then
		GAMEMODE:Notify(ply,1,3,"You must leave your current gang before you join another!")
		return
	end

	if !name then
		GAMEMODE:Notify(ply,1,3,"You chose to join a invalid gang!")
		return
	end

	if GangExists(name) then
		if table.HasValue(ply.Invited,name) then

			AddPlayerToOrg(ply,name)
			ply.Invited = {}

			GAMEMODE:Notify(ply,0,3,"You have joined "..name)
			return
		else
			GAMEMODE:Notify(ply,1,3,"You were not invited to join that gang!")
			return
		end
	else
		GAMEMODE:Notify(ply,1,3,"You chose to join a invalid gang!")
	end
end
concommand.Add("org_join",JoinOrg)

local function LeaveOrg(ply,cmd,args)
	if ply:GetNWString("Gang","") != "" then
		ply:LeaveGang()
		
	else
		GAMEMODE:Notify(ply,1,3, "You're not in an gang!")
	end
end
concommand.Add("org_leave", LeaveOrg)

local function KickPlayer(ply,cmd,args)
	local p2i = GAMEMODE:FindPlayer(args[1])

	if !ply:InGang() then
		GAMEMODE:Notify(ply,1,3,"You must be in an gang to kick someone!")
		return
	end

	if (p2i == ply) then
		GAMEMODE:Notify(ply,1,3,"You cannot kick your imaginary friend!")
		return
	end

	if (ply:GetNWBool("Org_Leader",false) != true) then
		GAMEMODE:Notify(ply,1,3, "Only gang leaders can kick people!")
		return
	end

	if p2i then
		GAMEMODE:Notify(p2i,1,3,"You have been kicked from your gang!")
		p2i:LeaveGang()
	else
		RemovePlayerFromOrgID(args[1])
	end
	GAMEMODE:Notify(ply,0,3,"Member kicked!")

end
concommand.Add("org_kick",KickPlayer)


local function DisbandOrg(ply,cmd,args)
	if ply:GetNWString("Gang","") != "" then
		if ply:GetNWBool("Org_Leader",false) == true then

			local gang = ply:GetNWString("Gang","")

			DeleteGang(ply:GetNWString("Gang",""))
			ply:SetNWBool("Org_Leader",false)

			for k,v in pairs(player.GetAll()) do
				if v:GetNWString("Gang","") == gang then
					v:SetNWString("Gang","")
					v:SetNWBool("Org_Leader",false)
					GAMEMODE:Notify(v,0,3, "Your gang has been disbanded!")
				end
			end

		else
			GAMEMODE:Notify(ply,1,3, "You're nor your gangs leader!")
		end
		
	else
		GAMEMODE:Notify(ply,1,3, "You're not in an gang!")
	end
end
concommand.Add("org_disband",DisbandOrg)

local meta = FindMetaTable("Player")


function meta:LeaveGang()
	if self:GetNWBool("Org_Leader",false) == true then
		GAMEMODE:Notify(self,1,3, "You must disband your gang to leave it!")
		return
	end
	local org = self:GetNWString("Gang")

	self:SetNWString("Gang","")
	self:SetNWBool("Org_Leader",false)

	RemovePlayerFromOrg(self)

	GAMEMODE:Notify(ply,0,3, "You have left your gang!")
	if org == "" then return end
/*
	local last = true
	for k,v in pairs(player.GetAll()) do
		if v:GetNWString("Gang","") == org then
			last = false
		end
	end
	if last == true then
		P_ORGS[table.KeyFromValue(P_ORGS,org)] = nil
	end
	*/
end

function meta:InGang()
	return self:GetNWString("Gang","") != ""
end

function AddPlayerToOrg(ply,name)
	ply:SetNWString("Gang",name)
	ply:SetNWBool("Org_Leader",false) -- double check
	sql.Begin()
	local r = sql.Query("INSERT INTO player_orgdata (steamid, name, org) VALUES ('"..ply:SteamID().."','"..ply:Name().."','"..name.."')")
	sql.Commit()
	--MsgN( sql.LastError( r ))
end

function RemovePlayerFromOrg(ply)
	sql.Begin()
	local r = sql.Query("DELETE FROM player_orgdata WHERE steamid='"..ply:SteamID().."'")
	sql.Commit()
	--MsgN( sql.LastError( r ))
end

function RemovePlayerFromOrgID(sid)
	sql.Begin()
	local r = sql.Query("DELETE FROM player_orgdata WHERE steamid='"..sid.."'")
	sql.Commit()
	--MsgN( sql.LastError( r ))
end

function GangExists(name)
	local r = sql.Query("SELECT * FROM player_orgs WHERE name='"..name.."'")
	return r != nil
end

function NewGang(name, ply)
	sql.Begin()
	local r = sql.Query("INSERT INTO player_orgs (name, leader,motd) VALUES ('"..name.."', '"..ply:SteamID().."','Default MOTD')")
	sql.Commit()
	--MsgN( sql.LastError( r ))
end

hook.Add("PlayerSay","Gangmenushortcut", function(ply, text, toteam)
	if ( string.sub( text, 1, 5 ) == "!gang" ) then
		ply:ConCommand("org_menu")
		return ""
	end
end)


function DeleteGang(name)
	sql.Begin()
	local r = sql.Query("DELETE FROM player_orgs WHERE name='"..name.."'")
	r = sql.Query("DELETE FROM player_orgdata WHERE org='"..name.."'")
	sql.Commit()
	--MsgN( sql.LastError( r ))
end

function GetGangMembers(name)
	local r = sql.Query("SELECT * FROM player_orgdata WHERE org='"..name.."'")
	return r
end

function SetupPlayerOrg(ply)
	local data = sql.Query("SELECT * FROM player_orgdata WHERE steamid='"..ply:SteamID().."'")
	if !data then return end
	data = data[1]
	if GangExists(data.org) then
		ply:SetNWString("Gang",data.org)
	else
		RemovePlayerFromOrg(ply)
		ply:SetNWString("Gang","")
		return
	end
	data = sql.Query("SELECT * FROM player_orgs WHERE name='"..data.org.."'")
	data = data[1]
	if data.leader == ply:SteamID() then
		ply:SetNWBool("Org_Leader",true)
	end
end

function SendOrgMembers(ply)
	local org = ply:GetNWString("Gang","")
	if org == "" then return end
	local members = GetGangMembers(org)
	umsg.Start("ClearMembers",ply)
	umsg.End()
	for k,v in pairs(members) do
		umsg.Start("OrgMember",ply)
		umsg.String(v.steamid)
		umsg.String(v.name)
		umsg.End()
	end
end
concommand.Add("org_getmembers",SendOrgMembers)

function SendOrgMOTD(ply)
	local org = ply:GetNWString("Gang","")
	if org == "" then return end
	local MOTD = GetOrgMOTD(org)
	umsg.Start("SendMotd",ply)
	umsg.String(MOTD)
	umsg.End()
end
concommand.Add("org_getmotd",SendOrgMOTD)

function ShowOrgMenu(ply)
	SendOrgMembers(ply)
	SendOrgMOTD(ply)
	ply:ConCommand("org_panel")
end
concommand.Add("org_menu",ShowOrgMenu)

function SetOrgMOTD(ply,cmd,args)
	local org = ply:GetNWString("Gang","")
	if org == "" then return end
	local nm = args[1]
	for k,v in pairs(player.GetAll()) do
		if v:GetNWString("Gang","") == org then
			GAMEMODE:Notify(v,1,3,"Gang MOTD has been changed!")
		end
	end
	SetOrgMotdD(org,nm)
end
concommand.Add("org_setmotd",SetOrgMOTD)

function GetOrgMOTD(org)
	local r = sql.Query("SELECT * FROM player_orgs WHERE name='"..org.."'")
	return r[1].motd
end

function SetOrgMotdD(org,motd)
	sql.Begin()
	local r = sql.Query("UPDATE player_orgs SET motd='"..motd.."' WHERE name='"..org.."'")
	sql.Commit()
	----MsgN( sql.LastError( r ))
end


if !(sql.TableExists("player_orgs")) then
	local r = sql.Query("CREATE TABLE player_orgs (name varchar(255), leader varchar(255), motd varchar(255))")
	--MsgN( sql.LastError( r ))
	r = sql.Query("CREATE TABLE player_orgdata (steamid varchar(255), name varchar(255), org varchar(255))")
	----MsgN( sql.LastError( r ))
end