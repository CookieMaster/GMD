include( 'shared.lua' )
 
ENT.RenderGroup = RENDERGROUP_BOTH

ORG_MOTD = ""
ORG_MEMBERS = {}


CreateClientConVar("gang_esp",1,true,false)

local function GangESP()
	local gang = LocalPlayer():GetNWString("Gang","")
	if gang == "" then return end
	local size = 6
	if !GetConVar("gang_esp"):GetBool() then return end

	local scrpos = Vector(0,0,0)
	for k,v in pairs(player.GetAll()) do
		if gang == v:GetNWString("Gang","") && v != LocalPlayer() then
			scrpos = v:GetPos() + Vector(0,0,60)
			scrpos = scrpos:ToScreen()
			draw.RoundedBox(4,scrpos.x-(size/2),scrpos.y-(size/2),size,size,Color(0,0,255,255))
			--draw.DrawText("Gang Member","DarkRPHUD2",scrpos.x,scrpos.y,Color(0,0,0,200),TEXT_ALIGN_CENTER)
		end
	end
end
hook.Add("HUDPaint","HUDPAINT_gangesp",GangESP)


 
function ENT:Draw( )
    self.Entity:DrawModel( )
end

function LeaveOrg(d)
	local panel = vgui.Create("DFrame")
	panel:SetSize(300,100)
	panel:Center()
	panel:MakePopup()
	panel:SetDraggable(true)
	panel:SetTitle("Gang Registery")
	function panel:Paint( w, h )
				draw.RoundedBox( 0, 0, 0, w, h, Color( 5, 0, 200 ) )
				surface.SetDrawColor( 0, 0, 0 )
				surface.DrawOutlinedRect( 1, 1, w-2, h-2 )
			end

	local pt  = vgui.Create("DLabel",panel)
	pt:SetText("Leave your gang?")
	pt:SetPos(panel:GetWide()/4,22)
	pt:SizeToContents()

	local on = vgui.Create("DTextEntry",panel)
	on:SetPos(panel:GetWide()/2-100,38)
	on:SetSize(200,20)
	function on:AllowInput(txt)
		if #self:GetValue() > 25 then return true end
		return false
	end
	on:SetText("Type \"I'm sure\"")

	local bt = vgui.Create("DButton",panel)
	bt:SetPos(panel:GetWide()/6,60)
	bt:SetSize(200,30)
	bt:SetText("Leave your gang")
	function bt:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color(150, 150, 150) )
		end
	function bt:DoClick()
		if string.lower(on:GetValue()) != "i'm sure" then return end
		LocalPlayer():ConCommand("org_leave")
		panel:Remove()
	end
end
usermessage.Hook("OrgLeave",LeaveOrg)


function RegisterOrg(d)
	local panel = vgui.Create("DFrame")
	panel:SetSize(300,100)
	panel:Center()
	panel:MakePopup()
	panel:SetDraggable(true)
	panel:SetTitle("Gang Registery")
	function panel:Paint( w, h )
				draw.RoundedBox( 0, 0, 0, w, h, Color( 5, 0, 200 ) )
				surface.SetDrawColor( 0, 0, 0 )
				surface.DrawOutlinedRect( 1, 1, w-2, h-2 )
			end

	local pt  = vgui.Create("DLabel",panel)
	pt:SetText("Enter your gang name:")
	pt:SetPos(panel:GetWide()/4,22)
	pt:SizeToContents()

	local on = vgui.Create("DTextEntry",panel)
	on:SetPos(panel:GetWide()/2-100,38)
	on:SetSize(200,20)
	function on:AllowInput(txt)
		if string.find( "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ", txt ) then return false end
		if #self:GetValue() > 25 then return true end
		return false
	end

	local bt = vgui.Create("DButton",panel)
	bt:SetPos(panel:GetWide()/6,60)
	bt:SetSize(200,30)
	bt:SetText("Create Gang ($"..tostring(GANG_COST)..")")
	function bt:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color(150, 150, 150) )
		end
	function bt:DoClick()
		LocalPlayer():ConCommand("org_create \""..on:GetValue().."\"")
	end
end
usermessage.Hook("OrgRegister",RegisterOrg)

function DisbandOrg(d)
	local panel = vgui.Create("DFrame")
	panel:SetSize(300,100)
	panel:Center()
	panel:MakePopup()
	panel:SetDraggable(true)
	panel:SetTitle("Gang Registery")
	function panel:Paint( w, h )
				draw.RoundedBox( 0, 0, 0, w, h, Color( 5, 0, 200 ) )
				surface.SetDrawColor( 0, 0, 0 )
				surface.DrawOutlinedRect( 1, 1, w-2, h-2 )
			end

	local pt  = vgui.Create("DLabel",panel)
	pt:SetText("Disband your gang!?")
	pt:SetPos(3,22)
	pt:SizeToContents()

	local on = vgui.Create("DTextEntry",panel)
	on:SetPos(panel:GetWide()/2-100,38)
	on:SetSize(200,20)
	function on:AllowInput(txt)
		if #self:GetValue() > 25 then return true end
		return false
	end
	on:SetText("Type \"I'm sure\"")

	local bt = vgui.Create("DButton",panel)
	bt:SetPos(panel:GetWide()/4,60)
	bt:SetSize(panel:GetWide()/2,30)
	bt:SetText("Disband Gang?")
	function bt:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color(150, 150, 150) )
		end
	function bt:DoClick()
		if string.lower(on:GetValue()) != "i'm sure" then return end
		LocalPlayer():ConCommand("org_disband")
		panel:Remove()
	end
end
usermessage.Hook("OrgDisband",DisbandOrg)


function GetMembers(data)
	if !ORG_MEMBERS then ORG_MEMBERS = {} end
	local sid = data:ReadString()
	local nick = data:ReadString()
	local online = (GAMEMODE:FindPlayer(sid) != nil)
	local pobj = GAMEMODE:FindPlayer(sid)
	local t = {sid,nick,online,pobj}
	table.insert(ORG_MEMBERS,t)
end
usermessage.Hook("OrgMember",GetMembers)

function ClearMembers(data)
	if !ORG_MEMBERS then ORG_MEMBERS = {} end
	ORG_MEMBERS = {}
end
usermessage.Hook("ClearMembers",ClearMembers)

function GetMOTD(data)
	ORG_MOTD = data:ReadString()
end
usermessage.Hook("SendMotd",GetMOTD)

local function booltonorm(bool)
	if bool == true then
		return "Yes"
	else
		return "No"
	end
end


function CreateOrgPanel()

	local panel = vgui.Create("DFrame")
	panel:SetSize(700,500)
	panel:Center()
	panel:MakePopup()
	panel:SetDraggable(true)
	panel:SetTitle("Gang: "..LocalPlayer():GetNWString("Gang",""))
	function panel:Paint( w, h )
				draw.RoundedBox( 0, 0, 0, w, h, Color( 5, 0, 200 ) )
				surface.SetDrawColor( 0, 0, 0 )
				surface.DrawOutlinedRect( 1, 1, w-2, h-2 )
			end

	if LocalPlayer():GetNWString("Gang","") == "" then
		local oo = vgui.Create("DLabel",panel)
		oo:SetPos(40,250)
		oo:SetText("You currently aren't in any gang. If you would like to join one, request an invitation from someone who's in an gang")

		oo:SizeToContents()
		return
	end

	local pt  = vgui.Create("DLabel",panel)
	pt:SetText("Gang Members:")
	pt:SetPos(3,24)
	pt:SizeToContents()

	if  LocalPlayer():GetNWBool("Org_Leader",false) == true then

		local ml = vgui.Create("DListView",panel)
		ml:SetPos(3,40)
		ml:SetSize(398,300)
		ml:SetMultiSelect(false)
		ml:AddColumn("Name")
		ml:AddColumn("SteamID")
		ml:AddColumn("Online")

		if ORG_MEMBERS then
			for k,v in pairs(ORG_MEMBERS) do
				ml:AddLine(v[2],v[1],booltonorm(v[3]))
			end
		end

		local md = vgui.Create("DLabel",panel)
		md:SetPos(5,340)
		md:SetText("MOTD:")
		md:SizeToContents()

		local mdt = vgui.Create("DTextEntry",panel)
		mdt:SetPos(2,355)
		mdt:SetSize(398,50)
		mdt:SetText(ORG_MOTD)
		mdt:SetMultiline(true)
		function mdt:AllowInput(text)
			return true
		end

		local al = vgui.Create("DLabel",panel)
		al:SetText("Administration")
		al:SetPos(413,24)
		al:SizeToContents()


		local md = vgui.Create("DLabel",panel)
		md:SetPos(5,405)
		md:SetText("Change your MOTD:")
		md:SizeToContents()


		local mdc = vgui.Create("DTextEntry",panel)
		mdc:SetPos(2,420)
		mdc:SetSize(398,50)
		mdc:SetText(ORG_MOTD)
		mdc:SetMultiline(true)
		function mdc:AllowInput(text)
			if string.find( "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ !.?-=", text) then return false end
			if #self:GetValue() > 200 then return true end
			return false
		end

		local mdb = vgui.Create("DButton",panel)
		mdb:SetPos(2,470)
		mdb:SetSize(398,20)
		mdb:SetText("Change MOTD")
		function mdb:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color(150, 150, 150) )
		end
		mdb.DoClick = function()
			LocalPlayer():ConCommand("org_setmotd \""..mdc:GetValue().."\"")
		end

		local npl = vgui.Create("DListView",panel)
		npl:SetPos(410,40)
		npl:SetSize(280,190)
		npl:SetMultiSelect(false)
		npl:AddColumn("Name")
		npl:AddColumn("SteamID")
		for k,v in pairs(player.GetAll()) do
			if v:GetNWString("Gang","") == "" then
				npl:AddLine(v:Nick(),v:SteamID())
			end
		end

		local npb = vgui.Create("DButton",panel)
		npb:SetPos(410,230)
		npb:SetSize(280,20)
		npb:SetText("Invite Selected Player")
		function npb:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color(150, 150, 150) )
		end
		npb.DoClick = function()
			if !npl:GetSelected() then return end
			if !npl:GetSelected()[1] then return end
			LocalPlayer():ConCommand("org_invite \""..npl:GetSelected()[1]:GetValue(1).."\"")
		end

		local opl = vgui.Create("DListView",panel)
		opl:SetPos(410,260)
		opl:SetSize(280,210)
		opl:SetMultiSelect(false)
		opl:AddColumn("Name")
		opl:AddColumn("SteamID")
		opl:AddColumn("Online")
		for k,v in pairs(ORG_MEMBERS) do
			if v[2] != LocalPlayer():Nick() then
				opl:AddLine(v[2],v[1],booltonorm(v[3]))
			end
		end

		local opb = vgui.Create("DButton",panel)
		opb:SetPos(410,470)
		opb:SetSize(280,20)
		opb:SetText("Kick Selected Player")
		function opb:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color(150, 150, 150) )
		end
		opb.DoClick = function()
			if !opl:GetSelected() then return end
			if !opl:GetSelected()[1] then return end
			LocalPlayer():ConCommand("org_kick \""..opl:GetSelected()[1]:GetValue(2).."\"")
		end


		
	else
		local ml = vgui.Create("DListView",panel)
		ml:SetPos(3,40)
		ml:SetSize(694,410)
		ml:SetMultiSelect(false)
		ml:AddColumn("Name")
		ml:AddColumn("SteamID")
		ml:AddColumn("Online")

		if ORG_MEMBERS then
			for k,v in pairs(ORG_MEMBERS) do
				ml:AddLine(v[2],v[1],booltonorm(v[3]))
			end
		end

		local md = vgui.Create("DLabel",panel)
		md:SetPos(5,450)
		md:SetText("MOTD:")
		md:SizeToContents()

		local mdt = vgui.Create("DTextEntry",panel)
		mdt:SetPos(2,465)
		mdt:SetSize(696,30)
		mdt:SetText(ORG_MOTD)
		mdt:SetMultiline(true)
		function mdt:AllowInput(text)
			return true
		end
	end
end
concommand.Add("org_panel",CreateOrgPanel)

function OrgInvited(ply,cmd,args)
	local panel = vgui.Create("DFrame")
	panel:SetSize(300,90)
	panel:Center()
	panel:MakePopup()
	panel:SetDraggable(true)
	function panel:Paint( w, h )
				draw.RoundedBox( 0, 0, 0, w, h, Color( 5, 0, 200 ) )
				surface.SetDrawColor( 0, 0, 0 )
				surface.DrawOutlinedRect( 1, 1, w-2, h-2 )
			end
	panel:SetTitle("You have been invited to "..args[1])

	local pt  = vgui.Create("DLabel",panel)
	pt:SetText("Join the gang: "..args[1])
	pt:SetPos(80,24)
	pt:SizeToContents()

	local yb = vgui.Create("DButton",panel)
	yb:SetText("Join")
	yb:SetPos(10,40)
	yb:SetSize(135,40)
	function yb:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color(150, 150, 150) )
		end
	function yb:DoClick()
		LocalPlayer():ConCommand("org_join \""..args[1].."\"")
		panel:Remove()
	end

	local nb = vgui.Create("DButton",panel)
	nb:SetText("Decline")
	nb:SetPos(155,40)
	nb:SetSize(135,40)
	function nb:Paint( w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color(150, 150, 150) )
		end
	function nb:DoClick()
		panel:Remove()
	end
	MsgN("You have been invited to '"..args[1].."'")
	MsgN("You can type 'org_join \""..args[1].."\"'")
	MsgN("In your console, to join!")
end
concommand.Add("org_invited",OrgInvited)


