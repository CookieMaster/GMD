itemstore.data = {}

CreateConVar( "itemstore_inventory_persist", 1, FCVAR_ARCHIVE )

for _, dir in ipairs( { "itemstore/", "itemstore/banks/", "itemstore/banks/maps/" } ) do
	if not ( file.IsDir( dir, "DATA" ) ) then
		file.CreateDir( dir )
	end
end

function itemstore.data.LoadPlayer( pl )
	local path = "itemstore/" .. pl:UniqueID() .. ".txt"
	local data = file.Read( path, "DATA" )
	
	if ( data ) then
		local inv = util.JSONToTable( data )
		
		if ( inv ) then
			for k, v in pairs( inv ) do
				local item = itemstore.items.New( v.UniqueName )
				item.Data = v.Data
				
				pl:GetInventory():SetItem( item, k )
			end
		end
	end
end

function itemstore.data.SavePlayer( pl )
	local path = "itemstore/" .. pl:UniqueID() .. ".txt"
	
	local data = {}
	for k, v in pairs( pl:GetInventory().Items ) do
		data[ k ] = { UniqueName = v.UniqueName, Data = v.Data }
	end
	
	file.Write( path, util.TableToJSON( data ) )
end

function itemstore.data.LoadPlayerBank( pl )
	local path = "itemstore/banks/" .. pl:UniqueID() .. ".txt"
	local data = file.Read( path, "DATA" )
	
	if ( data ) then
		local inv = util.JSONToTable( data )
		
		if ( inv ) then
			local items = {}
			
			for k, v in pairs( inv ) do
				local item = itemstore.items.New( v.UniqueName )
				item.Data = v.Data
				
				items[ k ] = item
			end
			
			return items
		end
	end
end

function itemstore.data.SavePlayerBank( pl, bank )
	local path = "itemstore/banks/" .. pl:UniqueID() .. ".txt"
	
	if ( bank.Inventories[ pl ] ) then
		local data = {}
		for k, v in pairs( bank.Inventories[ pl ].Items ) do
			data[ k ] = { UniqueName = v.UniqueName, Data = v.Data }
		end
		
		file.Write( path, util.TableToJSON( data ) )
	end
end

function itemstore.data.LoadBanks()
	local path = "itemstore/banks/maps/" .. game.GetMap() .. ".txt"
	local data = file.Read( path, "DATA" )
	
	if ( data ) then
		local banks = util.JSONToTable( data )
		
		if ( banks ) then
			return banks
		end
	end
end

function itemstore.data.SaveBanks()
	local path = "itemstore/banks/maps/" .. game.GetMap() .. ".txt"
	
	local data = {}
	for _, ent in ipairs( ents.FindByClass( "itemstore_bank" ) ) do
		local bank = {}
		bank.Position = ent:GetPos()
		bank.Angles = ent:GetAngles()
		
		table.insert( data, bank )
	end
	
	file.Write( path, util.TableToJSON( data ) )
end

hook.Add( "PlayerDisconnected", "ItemStoreSaveItems", function( pl )
	if ( GetConVarNumber( "itemstore_inventory_persist" ) == 1 ) then
		itemstore.data.SavePlayer( pl )
	end
	
	local bank = ents.FindByClass( "itemstore_bank" )[ 1 ]
	if ( IsValid( bank ) ) then
		itemstore.data.SavePlayerBank( pl, bank )
	end
end )

hook.Add( "ShutDown", "ItemStoreSaveItems", function()
	for _, pl in ipairs( player.GetAll() ) do
		if ( GetConVarNumber( "itemstore_inventory_persist" ) == 1 ) then
			itemstore.data.SavePlayer( pl )
		end
		
		local bank = ents.FindByClass( "itemstore_bank" )[ 1 ]
		if ( IsValid( bank ) ) then
			itemstore.data.SavePlayerBank( pl, bank )
		end
	end
end )

timer.Create( "ItemStoreSaveInventories", 60, 0, function()
	for _, pl in ipairs( player.GetAll() ) do
		if ( GetConVarNumber( "itemstore_inventory_persist" ) == 1 ) then
			itemstore.data.SavePlayer( pl )
		end
		
		local bank = ents.FindByClass( "itemstore_bank" )[ 1 ]
		if ( IsValid( bank ) ) then
			itemstore.data.SavePlayerBank( pl, bank )
		end
	end
end )