ITEM.Name = "Weapon"
ITEM.Description = "Pew pew.\n\nWeapon: %s\nAmount: %d"
ITEM.Model = "models/Items/item_item_crate.mdl"
ITEM.Base = "base_darkrp"

local HL2Weapons = {
	"weapon_physgun",
	"weapon_physcannon",
	"weapon_crowbar",
	"weapon_stunstick",
	"weapon_pistol",
	"weapon_357",
	"weapon_smg1",
	"weapon_ar2",
	"weapon_annabelle",
	"weapon_shotgun",
	"weapon_crossbow",
	"weapon_frag",
	"weapon_rpg",
	"weapon_slam",
	"weapon_bugbait"
}
function ITEM:CanPickup( pl, ent )
	return not ent.PlyerUse and ( weapons.Get( ent.weaponclass ) or table.HasValue( HL2Weapons, ent.weaponclass ) )
end

function ITEM:GetDescription()
	return string.format( self.Description, self:GetData( "Class" ), self:GetData( "Amount" ) )
end

function ITEM:GetModel()
	return self:GetData( "Model" )
end

function ITEM:SaveData( ent )
	self:SetData( "Class", ent.weaponclass )
	self:SetData( "Amount", ent:Getamount() )
	self:SetData( "Model", ent:GetModel() )
	
	self:SetData( "Clip1", ent.clip1 )
	self:SetData( "Clip2", ent.clip2 )
	self:SetData( "Ammo", ent.ammoadd )
end

function ITEM:LoadData( ent )
	ent:SetModel( self:GetData( "Model" ) )
	ent:Setamount( self:GetData( "Amount" ) )
	ent.weaponclass = self:GetData( "Class" )
	
	ent.clip1 = self:GetData( "Clip1" )
	ent.clip2 = self:GetData( "Clip2" )
	ent.ammoadd = self:GetData( "Ammo" )
	
	-- The dumbest hack: FPtje sets the amount to 1 in Initialize() instead of, oh, I dunno, doing something
	-- that doesn't fuck everything up. Go suck on a bag of dicks. We override initialize so we can set the amount
	-- properly without anything interfering.
	ent.Initialize = function( self )
		self:PhysicsInit( SOLID_VPHYSICS )
		self:SetMoveType( MOVETYPE_VPHYSICS )
		self:SetSolid( SOLID_VPHYSICS )
		self:SetUseType( SIMPLE_USE )
		self:GetPhysicsObject():Wake()
		
		self:SetCollisionGroup( COLLISION_GROUP_INTERACTIVE_DEBRIS )
	end
end

function ITEM:Use( pl )
	self:SetData( "Amount", self:GetData( "Amount" ) - 1 )
	pl:Give( self:GetData( "Class" ) )
	
	local wep = pl:GetWeapon( self:GetData( "Class" ) )
	wep:SetClip1( self:GetData( "Clip1" ) or 0 )
	wep:SetClip2( self:GetData( "Clip2" ) or -1 )
	
	pl:GiveAmmo( self:GetData( "Ammo" ) or 0, wep:GetPrimaryAmmoType() )
	
	if ( self:GetData( "Amount" ) < 1 ) then
		return true
	end
end