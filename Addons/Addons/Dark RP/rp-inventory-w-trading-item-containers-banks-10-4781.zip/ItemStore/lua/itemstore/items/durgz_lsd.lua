ITEM.Name = "LSD"
ITEM.Description = "Drug joke."
ITEM.Model = "models/smile/smile.mdl"
ITEM.Base = "base_darkrp"