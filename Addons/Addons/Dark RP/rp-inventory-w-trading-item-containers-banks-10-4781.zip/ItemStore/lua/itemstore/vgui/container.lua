local PANEL = {}

AccessorFunc( PANEL, "ContainerID", "ContainerID" )
AccessorFunc( PANEL, "Rows", "Rows" )
AccessorFunc( PANEL, "Columns", "Columns" )

function PANEL:Init()
	self.Items = {}
	
	table.insert( itemstore.containers.Panels, self )
end

function PANEL:Refresh()
	for k, v in ipairs( self.Items ) do
		v:Remove()
		self.Items[ k ] = nil
	end
	
	local container = itemstore.containers.Get( self:GetContainerID() )
	if ( container ) then
		for i = 1, container.Size do
			table.insert( self.Items, self:Add( "ItemStoreItem" ) )
		end
		
		self:InvalidateLayout()
	end
end

function PANEL:SetContainerID( containerid )
	self.ContainerID = containerid
	self:Refresh()
end

function PANEL:PerformLayout()
	self:SetSpaceX( 1 )
	self:SetSpaceY( 1 )
	
	local container = itemstore.containers.Get( self:GetContainerID() )
	if ( container ) then
		for i = 1, container.Size do
			local panel = self.Items[ i ]
			
			if ( panel ) then
				panel:SetSize( 45, 45 )
				panel:SetContainerID( self:GetContainerID() )
				panel:SetSlot( i )
				
				local item = itemstore.containers.Get( self:GetContainerID() ):GetItem( i )
				if ( item ) then
					panel:SetItem( item )
				end
				
				panel.DoClick = function( panel )
					local menu = DermaMenu()
					
					if ( item ) then
						if ( item.Use ) then
							menu:AddOption( "Use", function() RunConsoleCommand( "itemstore_use", self:GetContainerID(), i ) end ):SetIcon( "icon16/wrench.png" )
							menu:AddSpacer()
						end
						
						menu:AddOption( "Drop", function() RunConsoleCommand( "itemstore_drop", self:GetContainerID(), i ) end ):SetIcon( "icon16/arrow_out.png" )
						menu:AddOption( "Destroy", function() Derma_Query( "Are you sure you want to destroy this item?", "Confirmation", "Yes", function() RunConsoleCommand( "itemstore_destroy", self:GetContainerID(), i ) end, "Cancel" ) end ):SetIcon( "icon16/delete.png" )
						menu:Open()
					end
				end
				
				panel:Receiver( "ItemStore", function( receiver, droppable, dropped )
					if ( dropped ) then
						local dest = receiver:GetContainerID()
						local destslot = receiver:GetSlot()
						local source = droppable[ 1 ]:GetContainerID()
						local sourceslot = droppable[ 1 ]:GetSlot()
						
						RunConsoleCommand( "itemstore_swap", source, sourceslot, dest, destslot )
					end
				end )
				
				panel:Droppable( "ItemStore" )
			end
		end
	end
	
	self.BaseClass.PerformLayout( self )
end

function PANEL:SizeToChildren()
	-- fuck you, that's what
end

vgui.Register( "ItemStoreContainer", PANEL, "DIconLayout" )