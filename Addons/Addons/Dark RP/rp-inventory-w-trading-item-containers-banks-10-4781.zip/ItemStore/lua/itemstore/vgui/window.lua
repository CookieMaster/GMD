local PANEL = {}

function PANEL:Init()
	self.Container = vgui.Create( "ItemStoreContainer", self )
end

function PANEL:SetContainerID( containerid )
	self.Container:SetContainerID( containerid )
end

function PANEL:SetDimensions( columns, rows )
	self:SetSize( 10 + 46 * columns - 1, 46 * rows + 33 )
end

function PANEL:Paint()
	surface.SetDrawColor( itemstore.config.WindowColour )
	surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
end

function PANEL:PerformLayout()
	self.BaseClass.PerformLayout( self )
	self.lblTitle:SetColor( itemstore.config.TitleColour )
	self.Container:Dock( FILL )
end

vgui.Register( "ItemStoreWindow", PANEL, "DFrame" )