/*---------------------------------------------------------------------------------------------------------
© Samuel DH Ahlstrom. All Rights Reserved under the Swedish Law (1960:729)
---------------------------------------------------------------------------------------------------------*/

local SHud = {}
SHud.Config = {}

//Configs
SHud.Config.vrange = 250 //Range of the player card
SHud.Config.showhp = true //Show HP bar
SHud.Config.showrank = true //Show the rank of admins
SHud.Config.round = 1 //The main box: 1 = Default , 2 = Square
SHud.Config.font = 1 //Text fonts: 1 = Default, 2 = SHud BIG, 3 = Old School
SHud.Config.lang = 1 //Languages: 1 = English, 2 = Swedish, 3 = Danish
SHud.Config.showwanted = true //Show if a player is wanted

//Configs for DLC's and other Addons
SHud.Config.showgang = false //Show gang name (DarkRP Gang System)

//Will be added later
SHud.Config.tag = false //Custom tag (SHud Tag System)
SHud.Config.size = false //Change size when you get closer
SHud.Config.hit = false //Shows if you have a hit on you
SHud.Config.showarmor = false //Show Armor bar
SHud.Config.dead = false //Show the hud when you are dead

//Colors
nametext = Color(10,10,10,180)
namebg = Color(160,160,160)

jobtext = Color(255,255,255)
jobbg = Color(255,255,255)

gangtext = Color(10,10,10,180)
gangbg = Color(10,10,10,180)

ranktext = Color(255,255,255,180)
rankbg = Color(0,0,0,180)

//Icons    
local gun = "icon16/gun.png"
local paper = "icon16/page.png"

//Ranks    
SHud.Ranks = {}
SHud.Ranks["superadmin"] = {"Super Admin", "icon16/shield_add.png"}
SHud.Ranks["admin"] = {"Admin", "icon16/shield.png"}
	

//Only edit if you know what you are doing

SHud.version = ""

    if SHud.Config.font == 1 then 
    surface.CreateFont ("SHudName", {
    size = 23,
    weight = 400,
    antialias = true,
    shadow = false,
    font = "coolvetica"})
    end
    if SHud.Config.font == 2 then 
    surface.CreateFont ("SHudName", {
    size = 23,
    weight = 400,
    antialias = true,
    shadow = false,
    font = "DejaVu Sans"})
    end
    if SHud.Config.font == 3 then 
    surface.CreateFont ("SHudName", {
    size = 20,
    weight = 400,
    antialias = true,
    shadow = false,
    font = "akbar"})
    end
	
	if SHud.Config.lang == 1 then 
    wantedtext = "Wanted by The Police"
	goterror = "Please contact an administrator"
	end	
	
	if SHud.Config.lang == 2 then 
    wantedtext = "Efterlyst av Polisen"
	end
	
	if SHud.Config.lang == 3 then 
    wantedtext = "Eftersøgt af politiet"
	end
	
    local function drb(r, x, y, w, h, col)
    draw.RoundedBox(r, x, y, w, h, col)
    end
    
    local function ddt(text, font, x, y, col, align)
    draw.DrawText(text, font, x, y, col, align or 0)
    end
    
    local function dicon(mat, x, y, w, h)
    surface.SetDrawColor( 255, 255, 255, 255 )
    surface.SetMaterial( Material(mat) )
    surface.DrawTexturedRect( x, y, w, h)  
    end

    function SHud.DrawHUD(ply)
    local pos = ply:EyePos()
 
    pos.z = pos.z + 15
    pos = pos:ToScreen()
    pos.y = pos.y - 60
    ply.DarkRPVars = ply.DarkRPVars or {}
    local RankData = SHud.Ranks[ply:GetNWString("usergroup")] or {}
    local hasRank = (RankData[1] and true or false)
    local x, y = pos.x - 115 , pos.y + 1
    local w, h = 250, (hasRank and SHud.Config.showrank and 90 or 60)
    local name = ply:Nick() or "???"
    local tname = ply.DarkRPVars.job or teamname or "???"	
	
    if SHud.Config.round == 1 then 
	round = 6
	end	
    if SHud.Config.round == 2 then 
	round = 0
    end
    
	drb(round, x, y, w, h, Color(10,10,10,180))
  
    drb(round, x + 3, y + 3, w - 6, 25, nametext)
    ddt(name, "SHudName", x + w / 2, y + 4, namebg, TEXT_ALIGN_CENTER)
 
    ddt(tname, "SHudName", x + w / 2, y + 34, nametext, TEXT_ALIGN_CENTER)     
   
    local tcol = team.GetColor(ply:Team())
	
    if SHud.Config.showhp then
    local hp = ply:Health()
    local unit = (w - 6) / 100

    drb(round, x + 3, y + 32, w - 6, 25, Color(tcol.r / 2, tcol.g / 2, tcol.b / 2))
    drb(round, x + 3, y + 32, math.Clamp(hp * unit, 12, w - 6), 25, tcol)
    else
    drb(round, x + 3, y + 32, w - 6, 25, tcol) 
    end
   
    ddt(tname, "SHudName", x + w / 2, y + 34, jobtext, TEXT_ALIGN_CENTER)     

	if ply:GetNWString("Gang","") != "" and SHud.Config.showgang then
	local gang = ply:GetNWString("Gang","") or "No Gang"
    drb(round, x, y - 28, w, 25, Color(10, 10, 10, 150))
    ddt(gang, "SHudName", x + w / 2, y - 26, gangtext, TEXT_ALIGN_CENTER)
    elseif ply:GetNWBool("Org_Leader",true) == true then
    drb(round, x, y - 28, w, 25, Color(10, 10, 10, 0))
	end
	
	if SHud.Config.tag == false then
	rankpos = 2
	end
	
	if SHud.Config.tag then
	rankpos = 5
	end

    if hasRank and SHud.Config.showrank then
    local rank = RankData[1]
    surface.SetFont("SHudName")
    local tw = surface.GetTextSize(rank) + 30
    local txtPos = x + w / rankpos - tw / 2
    drb(round, txtPos, pos.y + 62, tw, 25, rankbg)
    ddt(rank, "SHudName", txtPos + 24, y + 64, ranktext)
    dicon(RankData[2], txtPos + 4, y + 66, 16, 16)
	end
	
	if SHud.Config.tag then
	local tagsize = 85
    local tagPos = x + w / 1.3 - tagsize / 2
	local ptag = ply:GetNWString("STag") != "" or ""
    drb(round, tagPos, pos.y + 62, tagsize, 25, rankbg)
    ddt(ptag, "SHudName", tagPos + 24, y + 64, Color(218,165,32, 255))
    end
    
    if ply.DarkRPVars.HasGunlicense then
    dicon(paper, x + 10, y + 66, 16, 16)
    dicon(gun, x + 9, y + 68, 16, 16)
    end
    
    if SHud.Config.showwanted and ply:getDarkRPVar("wanted") and ply:Alive() then
    local wy = y - 58
    if SHud.Config.showgang and ply:GetNWString("Gang") != "" then
    wy = wy - 23
    end
    drb(round, x, wy, w, 25, Color(0, 0, 0, 200))
    ddt(wantedtext, "SHudName", x + w / 2 - 1, wy + 3, Color(180, 20, 20), TEXT_ALIGN_CENTER)
    end
    end

    local function SDisplay()
    local localply = LocalPlayer()
    local localpos = localply:GetShootPos()
    
	if localply:Alive() then
    for k, v in pairs(player.GetAll()) do
    local pos = v:GetShootPos()
    if localpos:Distance(pos) < SHud.Config.vrange then
    local diff = pos - localpos
    local trace = util.QuickTrace(localpos, diff, localply)
    if trace.Hit and trace.Entity ~= v then return end
    SHud.DrawHUD(v)
	end
	end
	end
    end
    hook.Add("HUDPaint", "DrawSammyHud", SDisplay)