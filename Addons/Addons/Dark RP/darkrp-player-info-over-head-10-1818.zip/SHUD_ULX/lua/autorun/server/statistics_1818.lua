hook.Add('Initialize','CH_S_cf53e8aa843f3ac4eacb2f772fd077e1', function()
	http.Fetch('http://coderhire.com/api/script_statistics/usage/1663/155/cf53e8aa843f3ac4eacb2f772fd077e1')
end)