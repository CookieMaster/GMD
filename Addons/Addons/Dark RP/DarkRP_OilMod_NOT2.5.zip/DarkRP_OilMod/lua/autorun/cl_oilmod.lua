
function Kun_Oil_SellMenu()
	local ply = LocalPlayer()
	local ent = net.ReadEntity()
	local eclass = net.ReadString()
	local name = net.ReadString()
	local amt = net.ReadInt(32)
	
	local frame = vgui.Create("DFrame")
	frame:SetSize( 400, 170)
	frame:Center()
	frame:SetDraggable( false )
	frame:SetVisible( true )
	frame:ShowCloseButton( true )
	frame:MakePopup()
	frame:SetTitle("")
	frame.Paint = function(frame)
		surface.SetDrawColor( 250, 250, 250, 255) 
		surface.DrawRect(0 , 0, frame:GetWide(), frame:GetTall() )
		
		surface.SetDrawColor( 50, 50, 50, 255) 
		surface.DrawRect(2 , 2, frame:GetWide()-4, frame:GetTall()-4 )
		
		surface.SetDrawColor( 240, 240,240, 255) 
		surface.DrawRect(10 , 100, frame:GetWide() - 20, 5 )
		
		draw.SimpleText( name, "DermaLarge", frame:GetWide() / 2, 60, Color(250,250,250,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText( "$"..amt, "TargetID", 10, 80, Color(250,250,250,255))
		draw.SimpleText( "Your Oil: "..ply:GetNWInt("Oil"), "TargetID", 10, 110, Color(250,250,250,255))
	end
		
	local selloil = vgui.Create("DButton", frame)
	selloil:SetSize( frame:GetWide() - 20, 20)
	selloil:SetPos(10, 140)
	selloil:SetText("Sell Oil!")
	selloil.DoClick = function()
		net.Start("Kun_SellOil")
			net.WriteEntity(ent)
		net.SendToServer()
		frame:Close()
	end
end
net.Receive( "Kun_Oil_SellMenu", Kun_Oil_SellMenu)

function Kun_OilWell_Menu()
	local ply = LocalPlayer()
	
	local oiltype = net.ReadString()
	local tbl = KunzOilMod.Drills[oiltype]
	local name = tbl.Name
	
	local frame = vgui.Create("DFrame")
	frame:SetSize( 400, 200)
	frame:Center()
	frame:SetDraggable( false )
	frame:SetVisible( true )
	frame:ShowCloseButton( true )
	frame:MakePopup()
	frame:SetTitle("")
	frame.Paint = function(frame)
		surface.SetDrawColor( 250, 250, 250, 255) 
		surface.DrawRect(0 , 0, frame:GetWide(), frame:GetTall() )
		
		surface.SetDrawColor( 50, 50, 50, 255) 
		surface.DrawRect(2 , 2, frame:GetWide()-4, frame:GetTall()-4 )
		
		surface.SetDrawColor( 240, 240,240, 255) 
		surface.DrawRect(10 , 100, frame:GetWide() - 20, 5 )
		
		draw.SimpleText( name, "DermaLarge", frame:GetWide() / 2, 60, Color(250,250,250,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText( "Your Oil: "..ply:GetNWInt("Oil"), "TargetID", 10, 80, Color(250,250,250,255))
		
		if(tbl.MakesXOil == 1) then
			draw.SimpleText( "Will produce "..tbl.MakesXOil.." oil every "..tbl.Speed.." seconds!", "TargetID", 10, 120, Color(250,250,250,255))
		else
			draw.SimpleText( "Will produce (1-"..tbl.MakesXOil..") oil every "..tbl.Speed.." seconds!", "TargetID", 10, 120, Color(250,250,250,255))
		end
	end
	
	local takeoil = vgui.Create("DButton", frame)
	takeoil:SetSize( frame:GetWide() - 20, 20)
	takeoil:SetPos(10, 140)
	takeoil:SetText("Take Oil!")
	takeoil.DoClick = function()
		net.Start("Kun_TakeOil")
		net.SendToServer()
	end
	
	local oilangle = vgui.Create("DButton", frame)
	oilangle:SetSize( frame:GetWide() - 20, 20)
	oilangle:SetPos(10, 170)
	oilangle:SetText("Fix Angle")
	oilangle.DoClick = function()
		net.Start("Kun_OilAngle")
		net.SendToServer()
	end
end
net.Receive( "Kun_OilWell_Menu", Kun_OilWell_Menu)

function Kun_OilTank_Menu()
	local ply = LocalPlayer()
	local amt = net.ReadInt(32)
	
	local frame = vgui.Create("DFrame")
	frame:SetSize( 400, 200)
	frame:Center()
	frame:SetDraggable( false )
	frame:SetVisible( true )
	frame:ShowCloseButton( true )
	frame:MakePopup()
	frame:SetTitle("")
	frame.Paint = function(frame)
		surface.SetDrawColor( 250, 250, 250, 255) 
		surface.DrawRect(0 , 0, frame:GetWide(), frame:GetTall() )
		
		surface.SetDrawColor( 50, 50, 50, 255) 
		surface.DrawRect(2 , 2, frame:GetWide()-4, frame:GetTall()-4 )
		
		surface.SetDrawColor( 240, 240,240, 255) 
		surface.DrawRect(10 , 100, frame:GetWide() - 20, 5 )
		
		draw.SimpleText( "Oil Tank", "DermaLarge", frame:GetWide() / 2, 60, Color(250,250,250,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText( "Your Oil: "..ply:GetNWInt("Oil"), "TargetID", 10, 80, Color(250,250,250,255))
		draw.SimpleText( "Tank Oil: "..amt, "TargetID", 10, 110, Color(250,250,250,255))
	end
	
	local takeoil = vgui.Create("DButton", frame)
	takeoil:SetSize( frame:GetWide() - 20, 20)
	takeoil:SetPos(10, 140)
	takeoil:SetText("Take Oil!")
	takeoil.DoClick = function()
		net.Start("Kun_OilTankManage")
			net.WriteInt(1,32)
		net.SendToServer()
		frame:Close()
	end
	
	local putoil = vgui.Create("DButton", frame)
	putoil:SetSize( frame:GetWide() - 20, 20)
	putoil:SetPos(10, 170)
	putoil:SetText("Deposit Oil!")
	putoil.DoClick = function()
		net.Start("Kun_OilTankManage")
			net.WriteInt(2,32)
		net.SendToServer()
		frame:Close()
	end
end
net.Receive( "Kun_OilTank_Menu", Kun_OilTank_Menu)