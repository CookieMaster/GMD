ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Fracker"
ENT.Author = "Kunit"
ENT.Spawnable = false
ENT.AdminSpawnable = false
