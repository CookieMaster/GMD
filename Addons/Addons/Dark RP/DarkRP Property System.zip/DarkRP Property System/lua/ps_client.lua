include("ps_shared.lua")

function DrawDoorText()
	local tr = util.TraceLine(util.GetPlayerTrace(LocalPlayer(),LocalPlayer():GetAimVector()))
	
	if tr.Hit and tr.Entity and tr.Entity:IsDoor() and tr.Entity:GetPos():Distance(LocalPlayer():GetPos() + Vector(0, 0, 64)) < 200 then	
		if tr.Entity:IsDoor() then
			local Pos = tr.Entity:LocalToWorld(tr.Entity:OBBCenter()):ToScreen()
			
			if Properties[string.lower(tostring(game.GetMap()))] != nil then
				for pskey, data in pairs(Properties[string.lower(tostring(game.GetMap()))]) do
					for _, vector in pairs(data.Doors) do
						for _, ent in pairs(ents.FindInSphere(vector,5)) do
							if ent:IsValid() && ent:IsDoor() then
								ent.DoorKey = pskey
							end
						end
					end
				end
			end
			
			if tr.Entity.DoorKey && Properties[string.lower(game.GetMap())][tr.Entity.DoorKey] != nil then 
				draw.SimpleTextOutlined(Properties[string.lower(game.GetMap())][tr.Entity.DoorKey].Name, "HUDNumber5", Pos.x, Pos.y, Color(153, 0, 0, 255), 1, 1, 2, Color(0, 0, 0, 255))
			else
				draw.SimpleTextOutlined("Public Property", "HUDNumber5", Pos.x, Pos.y, Color(153, 0, 0, 255), 1, 1, 2, Color(0, 0, 0, 255))
				return
			end
			
			if tr.Entity:GetNWInt( "DoorOwner" ) > 0 then
				draw.SimpleTextOutlined("Owner: " .. player.GetByID(tr.Entity:GetNWEntity( "DoorOwner" )):Nick(), "HUDNumber5", Pos.x, Pos.y + 35, Color(153, 0, 0, 255), 1, 1, 2, Color(0, 0, 0, 255))
			elseif Properties[string.lower(game.GetMap())][tr.Entity.DoorKey].Price == 0 then
				draw.SimpleTextOutlined("Government Property", "UiBold", Pos.x, Pos.y + 25, Color(153, 0, 0, 255), 1, 1, 2, Color(0, 0, 0, 255))
			else
				draw.SimpleTextOutlined("This property is for sale at the property store npc", "UiBold", Pos.x, Pos.y + 25, Color(153, 0, 0, 255), 1, 1, 2, Color(0, 0, 0, 255))
			end
		end
	end
end
hook.Add( "HUDDrawTargetID", "DrawDoorText", DrawDoorText )

local META = FindMetaTable( "Entity" )

local lastDataRequested = 0
function META:DrawCustomOwnableInfo()
	if LocalPlayer():InVehicle() then return end

	local pos = {x = ScrW()/2, y = ScrH() / 2}
	
	local theowner = ""
	local ownerstr = ""
	
	if self.DoorData == nil and lastDataRequested < (CurTime() - 0.7) then
		RunConsoleCommand("_RefreshDoorData", self:EntIndex())
		lastDataRequested = CurTime()

		return
	end

	for k,v in pairs(player.GetAll()) do
		if self:OwnedBy(v) then
			if self:IsVehicle() then
				ownerstr = ownerstr .. v:Nick() .. "\n"
				theowner = v:Nick()
			else
				--ownerstr = ownerstr .. v:Nick() .. "\n"
				theowner = v:Nick()
			end
		end
	end
	
	if type(self.DoorData.AllowedToOwn) == "string" and self.DoorData.AllowedToOwn ~= "" and self.DoorData.AllowedToOwn ~= ";" then
			local names = {}
			for a,b in pairs(string.Explode(";", self.DoorData.AllowedToOwn)) do
				if b ~= "" and IsValid(Player(tonumber(b))) then
					table.insert(names, Player(tonumber(b)):Nick())
				end
			end
			ownerstr = ownerstr .. DarkRP.getPhrase("keys_other_allowed", table.concat(names, "\n"))
		elseif type(self.DoorData.AllowedToOwn) == "number" and IsValid(Player(self.DoorData.AllowedToOwn)) then
			ownerstr = ownerstr .. DarkRP.getPhrase("keys_other_allowed", Player(self.DoorData.AllowedToOwn):Nick())
		end

		self.DoorData.title = self.DoorData.title or ""

		local blocked = self.DoorData.NonOwnable
		local st = self.DoorData.title .. "\n"
		local superadmin = LocalPlayer():IsSuperAdmin()
		local whiteText = true -- false for red, true for white text

		if superadmin and blocked then
			st = st .. DarkRP.getPhrase("keys_allow_ownership") .. "\n"
		end

		if self.DoorData.TeamOwn then
			st = st .. DarkRP.getPhrase("keys_owned_by") .."\n"

			for k, v in pairs(self.DoorData.TeamOwn) do
				if v then
					st = st .. RPExtraTeams[k].name .. "\n"
				end
			end
		elseif self.DoorData.GroupOwn then
			st = st .. DarkRP.getPhrase("keys_owned_by") .."\n"
			st = st .. self.DoorData.GroupOwn .. "\n"
		end

		if self:IsOwned() then
			if superAdmin then
				if ownerstr ~= "" then
					st = st .. DarkRP.getPhrase("keys_owned_by") .."\n" .. ownerstr
				end
				st = st ..DarkRP.getPhrase("keys_disallow_ownership") .. "\n"
			elseif not blocked and ownerstr ~= "" then
				st = st .. DarkRP.getPhrase("keys_owned_by") .. "\n" .. ownerstr
			end
		elseif not blocked then
			if superAdmin then
				st = DarkRP.getPhrase("keys_unowned") .."\n".. DarkRP.getPhrase("keys_disallow_ownership")
				if not self:IsVehicle() then
					st = st .. "\n"..DarkRP.getPhrase("keys_cops")
				end
			elseif not self.DoorData.GroupOwn and not self.DoorData.TeamOwn then
				whiteText = false
				st = "Unknown\nPress Reload with keys to own"
			end
		end

		if self:IsVehicle() then
			for k,v in pairs(player.GetAll()) do
				if v:GetVehicle() == self then
					whiteText = true
					st = st .. "\n" .. "Driver: " .. v:Nick()
				end
			end
		end
	if self:IsVehicle() then
		draw.DrawText(st, "TargetID", pos.x + 1, pos.y + 1, Color(0, 0, 0, 200), 1)
		draw.DrawText(st, "TargetID", pos.x, pos.y, Color(255, 255, 255, 200), 1)	
	elseif LocalPlayer():Nick() == theowner then
		draw.DrawText("Press 'R' (reload) with keys to open the buddies panel", "TargetID", pos.x , pos.y , Color(255, 255, 255, 255), 1)
		draw.DrawText(ownerstr, "TargetID", pos.x, pos.y + 25, Color(255, 255, 255, 200), 1)	
	end
end

function PS_BuddiesMenu(um)
	local Vehicle = LocalPlayer():GetEyeTrace().Entity
	Vehicle = IsValid(Vehicle) and Vehicle:IsVehicle()
	if KeyFrameVisible then return end
	local trace = LocalPlayer():GetEyeTrace()
	local Frame = vgui.Create("DFrame")
	KeyFrameVisible = true
	Frame:SetSize(200, 240)
	Frame:Center()
	Frame:SetVisible(true)
	Frame:MakePopup()

	function Frame:Think()
		local ent = LocalPlayer():GetEyeTrace().Entity
		if not IsValid(ent) or (not ent:IsDoor() and not string.find(ent:GetClass(), "vehicle")) or ent:GetPos():Distance(LocalPlayer():GetPos()) > 200 then
			self:Close()
		end
		if (!self.Dragging) then return end
		local x = gui.MouseX() - self.Dragging[1]
		local y = gui.MouseY() - self.Dragging[2]
		x = math.Clamp( x, 0, ScrW() - self:GetWide() )
		y = math.Clamp( y, 0, ScrH() - self:GetTall() )
		self:SetPos( x, y )
	end
	Frame:SetTitle("Buddies Menu")

	function Frame:Close()
		KeyFrameVisible = false
		self:SetVisible( false )
		self:Remove()
	end

	if trace.Entity:OwnedBy(LocalPlayer()) then
		if not trace.Entity.DoorData then return end -- Don't open the menu when the door settings are not loaded yet

		local AddOwner = vgui.Create("DButton", Frame)
		AddOwner:SetPos(10, 30)
		AddOwner:SetSize(180, 100)
		AddOwner:SetText("Add owner")
		AddOwner.DoClick = function()
			local menu = DermaMenu()
			menu.found = false
			for k,v in pairs(player.GetAll()) do
				if not trace.Entity:OwnedBy(v) and not trace.Entity:AllowedToOwn(v) then
					menu.found = true
					menu:AddOption(v:Nick(), function() RunConsoleCommand("darkrp", "/ao", v:SteamID()) end)
				end
			end
			if not menu.found then
				menu:AddOption("Noone available", function() end)
			end
			menu:Open()
		end

		local RemoveOwner = vgui.Create("DButton", Frame)
		RemoveOwner:SetPos(10, 135)
		RemoveOwner:SetSize(180, 100)
		RemoveOwner:SetText("Remove owner")
		RemoveOwner.DoClick = function()
			local menu = DermaMenu()
			for k,v in pairs(player.GetAll()) do
				if (trace.Entity:OwnedBy(v) and not trace.Entity:IsMasterOwner(v)) or trace.Entity:AllowedToOwn(v) then
					menu.found = true
					menu:AddOption(v:Nick(), function() RunConsoleCommand("darkrp", "/ro", v:SteamID()) end)
				end
			end
			if not menu.found then
				menu:AddOption("Noone available", function() end)
			end
			menu:Open()
		end
	elseif not trace.Entity:OwnedBy(LocalPlayer()) and trace.Entity:AllowedToOwn(LocalPlayer()) then
		Frame:SetSize(200, 140)
		local Owndoor = vgui.Create("DButton", Frame)
		Owndoor:SetPos(10, 30)
		Owndoor:SetSize(180, 100)
		Owndoor:SetText("Co-Own")
		Owndoor.DoClick = function() 
			net.Start("PS_Purchase_Buddy")
				net.WriteEntity(trace.Entity)
			net.SendToServer()
			Frame:Close()
		end
	end
end
usermessage.Hook("PS_BuddiesMenu", PS_BuddiesMenu)

function CL_UpdateDoorOwner( um )
	local OwnerId = um:ReadLong()
	local PropertyName = um:ReadString()
	
	for _, data in pairs(Properties[string.lower(game.GetMap())]) do
		if data.Name == PropertyName then
			Properties[string.lower(game.GetMap())][_].OwnerId = OwnerId
		end
	end
end
usermessage.Hook('PS_UpdateDoorOwner', CL_UpdateDoorOwner)

surface.CreateFont("UiBold", {
	font = "Tahoma", 
	size = 13, 
	weight = 700
})

surface.CreateFont("Trebuchet24", {
	font = "Trebuchet MS", 
	size = 24, 
	weight = 900
})
	
surface.CreateFont("Trebuchet22", {
	font = "Trebuchet MS", 
	size = 22, 
	weight = 900
})

surface.CreateFont("Trebuchet20", {
	font = "Trebuchet MS", 
	size = 20, 
	weight = 900
})