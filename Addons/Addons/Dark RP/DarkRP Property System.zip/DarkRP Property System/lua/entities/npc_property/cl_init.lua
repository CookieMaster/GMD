include('shared.lua')

local function formatNumber(n)
	n = tonumber(n)
	if (!n) then
		return 0
	end
	if n >= 1e14 then return tostring(n) end
    n = tostring(n)
    sep = sep or ","
    local dp = string.find(n, "%.") or #n+1
	for i=dp-4, 1, -3 do
		n = n:sub(1, i) .. sep .. n:sub(i+1)
    end
    return n
end

function NPC_PropertyMenu()
	local PropertyMenu = vgui.Create( "DFrame" )
	PropertyMenu:SetSize( 570, 600 ) 
	PropertyMenu:Center() 
	PropertyMenu:SetTitle( "" )  
	PropertyMenu:SetVisible( true )
	PropertyMenu:SetDraggable( true ) 
	PropertyMenu:ShowCloseButton( false )
	PropertyMenu:MakePopup()
	PropertyMenu:SizeToContents()
	PropertyMenu.Paint = function(CHPaint)
		-- Draw the menu background color.		
		draw.RoundedBox( 0, 0, 25, CHPaint:GetWide(), CHPaint:GetTall(), Color( 255, 255, 255, 150 ) )

		-- Draw the outline of the menu.
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0, 0, CHPaint:GetWide(), CHPaint:GetTall())
	
		draw.RoundedBox( 0, 0, 0, CHPaint:GetWide(), 25, Color( 255, 255, 255, 200 ) )
		
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0, 0, CHPaint:GetWide(), 25)

		-- Draw the top title.
		draw.SimpleText("The Property Store", "UiBold", 60,12.5, Color(70,70,70,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
		
	local GUI_Main_Exit = vgui.Create("DButton", PropertyMenu)
	GUI_Main_Exit:SetSize(16,16)
	GUI_Main_Exit:SetPos(550,5)
	GUI_Main_Exit:SetText("")
	GUI_Main_Exit.Paint = function()
		surface.SetMaterial(Material("icon16/cross.png"))
		surface.SetDrawColor(200,200,0,200)
		surface.DrawTexturedRect(0,0,GUI_Main_Exit:GetWide(),GUI_Main_Exit:GetTall())
	end
	GUI_Main_Exit.DoClick = function()
		PropertyMenu:Remove()
		net.Start("CH_ClosePropertyMenu")
		net.SendToServer()
	end
		
	local TheListPanel = vgui.Create( "DPanelList", PropertyMenu )
	TheListPanel:SetTall( 565 )
	TheListPanel:SetWide( 560 )
	TheListPanel:SetPos( 5, 30 )
	TheListPanel:EnableVerticalScrollbar( true )
	TheListPanel:EnableHorizontal( true )
		
	for k, v in pairs( Properties[string.lower(tostring(game.GetMap()))] ) do
		if v.Name then
			if v.Price != 0 then
				local PropertyList = vgui.Create("DPanelList")
				PropertyList:SetTall( 150 )
				PropertyList:SetWide( 560 )
				PropertyList:SetPos( 10, 30 )
				PropertyList:SetSpacing( 5 )
				PropertyList.Paint = function()
					draw.RoundedBox(8,0,2,PropertyList:GetWide(),PropertyList:GetTall(),Color( 20, 20, 20, 180 ))
				end
					
				local PropertyBackground = vgui.Create( "DPanel", PropertyList )
				PropertyBackground:SetPos( 0, 10 )
				PropertyBackground:SetSize( 560, 132.5 )
				PropertyBackground.Paint = function() -- Paint function
					draw.RoundedBoxEx(8,1,1,PropertyBackground:GetWide()-2,PropertyBackground:GetTall()-2,Color(70, 70, 70, 200), false, false, false, false)
				end
					
				local PropertyDisplay = vgui.Create( "DImage", PropertyBackground )
				PropertyDisplay:SetPos( 5, 5 )
				PropertyDisplay:SetImage( v.Picture )
				PropertyDisplay:SetToolTip(false)
				PropertyDisplay:SetSize(120,120)
				
				local PropertyName = vgui.Create( "DLabel", PropertyBackground )
				PropertyName:SetPos( 130, 10 )
				PropertyName:SetFont( "Trebuchet24" )
				PropertyName:SetColor( Color(255,255,255,255) )
				PropertyName:SetText( v.Name )
				PropertyName:SizeToContents()
				
				local PropertyPrice = vgui.Create( "DLabel", PropertyBackground )
				PropertyPrice:SetPos( 130, 30 )
				PropertyPrice:SetFont( "Trebuchet20" )
				if LocalPlayer().DarkRPVars.money >= v.Price then
					PropertyPrice:SetColor( Color(0,150,0,255) )
				else
					PropertyPrice:SetColor( Color(150,0,0,255) )
				end
				PropertyPrice:SetText( "Price: $"..formatNumber(v.Price) )
				PropertyPrice:SizeToContents()
					
				local PropertyDescription = vgui.Create( "DLabel", PropertyBackground )
				PropertyDescription:SetPos( 130, 50 )
				PropertyDescription:SetFont( "UiBold" )
				PropertyDescription:SetColor( Color(255,255,255,255) )
				PropertyDescription:SetText( v.Description )
				PropertyDescription:SetSize(440, 30)
				PropertyDescription:SetWrap(true)
				
				if !player.GetByID(v.OwnerId):IsValid() then
					v.OwnerId = 0
				end
				
				if v.OwnerId == LocalPlayer():EntIndex() then -- If you own the property.
					local PropertySold = vgui.Create( "DLabel", PropertyBackground )
					PropertySold:SetPos( 18.5, 5 )
					PropertySold:SetSize( 100, 20 )
					PropertySold:SetColor( Color(200,0,0,255) )
					PropertySold:SetFont( "Trebuchet20" )
					PropertySold:SetText("Property Sold")
					
					local BuyProperty = vgui.Create("DButton", PropertyBackground)
					BuyProperty:SetSize( 200, 30 )
					BuyProperty:SetPos( 360, 95 )
					BuyProperty:SetText("")
					BuyProperty.Paint = function(panel)
						draw.RoundedBoxEx(8,1,1,BuyProperty:GetWide()-2,BuyProperty:GetTall()-2,Color(0, 0, 0, 130), true, false, true, false)
							
						local struc = {}
						struc.pos = {}
						struc.pos[1] = 100
						struc.pos[2] = 15
						struc.color = Color(255,255,255,255)
						struc.text = "Sell" 
						struc.font = "Trebuchet22" 
						struc.xalign = TEXT_ALIGN_CENTER
						struc.yalign = TEXT_ALIGN_CENTER
						draw.Text( struc )
					end
					BuyProperty.DoClick = function()
						PropertyMenu:Remove()
						net.Start("CH_ClosePropertyMenu")
						net.SendToServer()
						
						net.Start("PS_Sell")
							net.WriteString(k)
						net.SendToServer()
					end
				elseif v.OwnerId == 0 || v.OwnerId == nil then -- If nobody owns the property.
					local BuyProperty = vgui.Create("DButton", PropertyBackground)
					BuyProperty:SetSize( 200, 30 )
					BuyProperty:SetPos( 360, 95 )
					BuyProperty:SetText("")
					if LocalPlayer().DarkRPVars.money < v.Price then
						BuyProperty:SetDisabled( true )
						BuyProperty:SetToolTip("You cannot afford the ".. string.lower(v.Name) ..".")
					end
					BuyProperty.Paint = function(panel)
						draw.RoundedBoxEx(8,1,1,BuyProperty:GetWide()-2,BuyProperty:GetTall()-2,Color(0, 0, 0, 130), true, false, true, false)
							
						local struc = {}
						struc.pos = {}
						struc.pos[1] = 100
						struc.pos[2] = 15
						if LocalPlayer().DarkRPVars.money >= v.Price then
							struc.color = Color(255,255,255,255)
						else
							struc.color = Color(150,150,150,255)
						end
						struc.text = "Purchase" 
						struc.font = "Trebuchet22" 
						struc.xalign = TEXT_ALIGN_CENTER
						struc.yalign = TEXT_ALIGN_CENTER
						draw.Text( struc )
					end
					BuyProperty.DoClick = function()
						PropertyMenu:Remove()
						net.Start("CH_ClosePropertyMenu")
						net.SendToServer()
						
						net.Start("PS_Purchase")
							net.WriteString(k)
						net.SendToServer()
					end
				else -- If somebody else owns the property.
					local PropertySold = vgui.Create( "DLabel", PropertyBackground )
					PropertySold:SetPos( 18.5, 5 )
					PropertySold:SetSize( 100, 20 )
					PropertySold:SetColor( Color(200,0,0,255) )
					PropertySold:SetFont( "Trebuchet20" )
					PropertySold:SetText("Property Sold")
					
					local BuyProperty = vgui.Create("DButton", PropertyBackground)
					BuyProperty:SetSize( 200, 30 )
					BuyProperty:SetPos( 360, 95 )
					BuyProperty:SetText("")
					BuyProperty:SetToolTip("This property is already sold.")
					BuyProperty.Paint = function(panel)
						draw.RoundedBoxEx(8,1,1,BuyProperty:GetWide()-2,BuyProperty:GetTall()-2,Color(0, 0, 0, 130), true, false, true, false)
							
						local struc = {}
						struc.pos = {}
						struc.pos[1] = 100
						struc.pos[2] = 15
						struc.color = Color(150,150,150,255)
						struc.text = "Purchase" 
						struc.font = "Trebuchet22" 
						struc.xalign = TEXT_ALIGN_CENTER
						struc.yalign = TEXT_ALIGN_CENTER
						draw.Text( struc )
					end
				end
				TheListPanel:AddItem( PropertyList )
			end 
		end
	end
end
usermessage.Hook("Property_NPC", NPC_PropertyMenu)