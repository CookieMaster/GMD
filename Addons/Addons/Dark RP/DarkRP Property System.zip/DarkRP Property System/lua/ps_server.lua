include("ps_shared.lua")
AddCSLuaFile("ps_shared.lua")

function PS_AddDir(dir)
	local list = file.Find(dir.."/*", "DATA")
	for _, fdir in pairs(list) do
		if fdir != ".svn" then
			PS_AddDir(dir.."/"..fdir)
		end
		end
	  
	for k,v in pairs(file.Find(dir.."/*", "GAME")) do
		resource.AddFile(dir.."/"..v)
	end
end

PS_AddDir("materials/property_system")

function PS_Overwrite_Keys( ply )
	timer.Simple( 1, function() 
		if ply:HasWeapon("keys") then
			ply:StripWeapon("keys")
			ply:Give("property_keys")
		end
	end)
end
hook.Add( "PlayerSwitchWeapon", "PS_Overwrite_Keys", PS_Overwrite_Keys )

function PS_PlayerInitSpawn( ply )
	for _, ent in pairs(ents.GetAll()) do
		if ent:IsDoor() then
			if ent:GetNWInt("DoorOwner") > 0 then
				umsg.Start("PS_UpdateDoorOwner", ply)
					umsg.Long( player.GetByID(ent:GetNWInt("DoorOwner")):EntIndex() )
					umsg.String( Properties[string.lower(game.GetMap())][ent.PropertyKey].Name )
				umsg.End()	
			end
		end
	end
end
hook.Add("PlayerInitialSpawn", "PS_PlayerInitSpawn", PS_PlayerInitSpawn )

function MapInit()
	if Properties[string.lower(tostring(game.GetMap()))] != nil then
		for pskey, data in pairs(Properties[string.lower(tostring(game.GetMap()))]) do
			for _, door in pairs(data.Doors) do
				for _,ent in pairs(ents.FindInSphere(door,5)) do
					if ent:IsValid() && ent:IsDoor() then
						ent.PropertyKey = pskey
						
						if Properties[string.lower(game.GetMap())][pskey].Description == "police" then
							ent:SetNWInt("DoorOwnerGroup", "police")
						end

						break
					end
				end
			end
		end
	end
end
hook.Add( "InitPostEntity", "MapInit", MapInit )

util.AddNetworkString("PS_Purchase")
net.Receive("PS_Purchase", function(length, ply)
	local PKey = tonumber(net.ReadString())
	local PlayersMoney = ply:getDarkRPVar("money")
	
	if Properties[string.lower(game.GetMap())][PKey] != nil then
		local Doors = {}
		local PropertyPrice = Properties[string.lower(game.GetMap())][PKey].Price
		local PropertyName = Properties[string.lower(game.GetMap())][PKey].Name
		
		for _, entity in pairs(ents.GetAll()) do
			if entity:IsDoor() && entity:IsValid() then
				if entity.PropertyKey != nil && entity.PropertyKey == PKey then
					if entity:GetNWInt("DoorOwner") > 0 then
						return
					else
						table.insert( Doors, entity )
					end
				end
			end
		end

		if PlayersMoney >= PropertyPrice then 
			ply:AddMoney( PropertyPrice * -1 )
			
			for k, v in pairs(player.GetAll()) do
				umsg.Start("PS_UpdateDoorOwner", v)
					umsg.Long( ply:EntIndex() )
					umsg.String( PropertyName )
				umsg.End()	
			end
			
			for _, entity in pairs(Doors) do
				if entity:IsDoor() && entity:IsValid() then 
					if entity.PropertyKey != nil && entity.PropertyKey == PKey then
						entity:SetNWInt( "DoorOwner", ply:EntIndex() )
						DarkRP_Door_Edit( ply, entity )
					end
				end
			end
			ply:ChatPrint("You have purchased the ".. PropertyName .." for $"..PropertyPrice)
		end
	end
end)

util.AddNetworkString("PS_Sell")
net.Receive("PS_Sell", function(length, ply)
	local PKey = tonumber(net.ReadString())
	
	if Properties[string.lower(game.GetMap())][PKey] != nil then
		local Doors = {}
		local PropertySellPrice = Properties[string.lower(game.GetMap())][PKey].Price / 2
		local PropertyName = Properties[string.lower(game.GetMap())][PKey].Name
		
		for _, entity in pairs(ents.GetAll()) do
			if entity:IsDoor() && entity:IsValid() then 
				if entity.PropertyKey != nil && entity.PropertyKey == PKey then
					if entity:GetNWInt("DoorOwner") != ply:EntIndex() then
						return
					else
						table.insert( Doors, entity )
					end
				end
			end
		end
			
		ply:AddMoney( PropertySellPrice )	
		ply:ChatPrint("You have been given $".. PropertySellPrice .." for selling the ".. PropertyName ..".")
		
		for k, v in pairs(player.GetAll()) do
			umsg.Start("PS_UpdateDoorOwner", v)
				umsg.Long(0)
				umsg.String(PropertyName)
			umsg.End()	
		end
		
		for _, entity in pairs(Doors) do
			if entity:IsDoor() && entity:IsValid() then 
				if entity.PropertyKey != nil && entity.PropertyKey == PKey then
					entity:SetNWInt("DoorOwner", 0)
					DarkRP_Door_Edit( ply, entity )
				end
			end
		end
	end
end)

function DarkRP_Door_Edit(ply, door)

	if IsValid(door) then
		local Owner = door:CPPIGetOwner()

		door.DoorData = door.DoorData or {}

		if door:OwnedBy(ply) then
			if door:IsMasterOwner(ply) then
				door.DoorData.AllowedToOwn = nil
				door.DoorData.ExtraOwners = nil
				door:Fire("unlock", "", 0)
			end

			door:UnOwn(ply)
			ply:GetTable().Ownedz[door:EntIndex()] = nil
			ply:GetTable().OwnedNumz = math.abs(ply:GetTable().OwnedNumz - 1)
		else
			local bAllowed, strReason, bSuppress = hook.Call("PlayerBuy"..( door:IsVehicle() and "Vehicle" or "Door"), GAMEMODE, ply, door );
			if( bAllowed == false ) then
				if( strReason and strReason != "") then
					GAMEMODE:Notify( ply, 1, 4, strReason );
				end
				return "";
			end

			
			door:Own(ply)
			
			if ply:GetTable().OwnedNumz == 0 then
				timer.Create(ply:UniqueID() .. "propertytax", 270, 0, function() ply.DoPropertyTax(ply) end)
			end

			ply:GetTable().OwnedNumz = ply:GetTable().OwnedNumz + 1

			ply:GetTable().Ownedz[door:EntIndex()] = door
		end
		return ""
	end
	return ""
end

util.AddNetworkString("PS_Purchase_Buddy")
net.Receive("PS_Purchase_Buddy", function(length, ply)
	local door = net.ReadEntity()
	
	door:Own(ply)
			
	if ply:GetTable().OwnedNumz == 0 then
		timer.Create(ply:UniqueID() .. "propertytax", 270, 0, function() ply.DoPropertyTax(ply) end)
	end

	ply:GetTable().OwnedNumz = ply:GetTable().OwnedNumz + 1
	ply:GetTable().Ownedz[door:EntIndex()] = door
end)

function PS_GiveTool( ply )
	if ply:IsAdmin() then
		ply:Give("property_system")
		ply:ChatPrint("You have been given the property system tool. Use this to grab the position of doors.")
	end
end
concommand.Add("PS_SpawnTool", PS_GiveTool)

function PS_StripTool( ply )
	if ply:IsAdmin() then
		ply:StripWeapon("property_system")
		ply:ChatPrint("You have stripped yourself from the property system tool.")
	end
end
concommand.Add("PS_RemoveTool", PS_StripTool)

function PS_Disconnect( ply )
	for _, ent in pairs(ents.GetAll()) do
		if ent:IsDoor() then
			if ent:GetNWInt("DoorOwner") == ply:EntIndex() then
				ent:SetNWInt("DoorOwner",0)
				DarkRP_Door_Edit( ply, ent )
					
				for k, v in pairs(player.GetAll()) do
					umsg.Start("PS_UpdateDoorOwner", v)
						umsg.Long( 0 )
						umsg.String( Properties[string.lower(game.GetMap())][ent.PropertyKey].Name )
					umsg.End()	
				end
			end
		end
	end
end
hook.Add( "PlayerDisconnected", "PS_Disconnect", PS_Disconnect )