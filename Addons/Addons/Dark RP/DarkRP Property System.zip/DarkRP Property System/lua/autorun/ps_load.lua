if SERVER then
	include("ps_server.lua")
	AddCSLuaFile("ps_client.lua")
	include("ps_maps.lua")
	AddCSLuaFile("ps_maps.lua")
	
	AddCSLuaFile("autorun/ps_load.lua")
elseif CLIENT then
	include("ps_client.lua")
	include("ps_maps.lua")
end