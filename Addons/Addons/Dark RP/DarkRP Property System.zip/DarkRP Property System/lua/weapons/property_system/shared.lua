if (SERVER) then
	AddCSLuaFile("shared.lua")
	SWEP.AutoSwitchTo		= true
	SWEP.AutoSwitchFrom		= true
	SWEP.IconLetter			= "D"
end

if (CLIENT) then
	SWEP.DrawAmmo			= false
	SWEP.ViewModelFOV		= 64
	SWEP.ViewModelFlip		= false
	SWEP.CSMuzzleFlashes	= false
	SWEP.PrintName			= "Property System Tool"			
	SWEP.Author				= "Crap-Head"
	SWEP.Slot				= 0
	SWEP.SlotPos			= 0
	SWEP.IconLetter			= "D"
end

SWEP.Author			= "Crap-Head"

SWEP.ViewModel			= "models/weapons/v_crowbar.mdl"
SWEP.WorldModel			= "models/weapons/w_crowbar.mdl"

SWEP.Primary.Recoil			= 0
SWEP.Primary.Damage			= -1
SWEP.Primary.NumShots		= 0
SWEP.Primary.Cone			= 0
SWEP.Primary.Delay			= 1.0
SWEP.Primary.ClipSize		= -1
SWEP.Primary.DefaultClip	= -1

SWEP.Primary.Automatic		= false
SWEP.Primary.Ammo			= "none"

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

function SWEP:Initialize()
	if (SERVER) then
		self:SetWeaponHoldType("melee")
	end
end

function SWEP:PrimaryAttack()
	local tr = self.Owner:GetEyeTrace()
	local Vect = tr.HitPos
	local Ang = tr.Entity:GetAngles()
	
	if tr.Entity:IsDoor() then
		self.Owner:ChatPrint("Vector("..math.Round(Vect.x)..","..math.Round(Vect.y)..","..math.Round(Vect.z)..")")
		
	else
		self.Owner:ChatPrint("You must be aiming at a door!")
	end
end

function SWEP:Reload()
end

function SWEP:SecondaryAttack()
end