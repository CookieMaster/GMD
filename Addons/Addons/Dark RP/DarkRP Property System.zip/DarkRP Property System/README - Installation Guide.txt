**Click on the banner to see the full picture.**

**THIS ADDON IS ON SALE FOR THE FIRST 24 HOURS.**
==

**EXCLUSE OFFER: Receive a free copy of my [DarkRP Simply HUD](http://coderhire.com/scripts/view/10) if you purchase DarkRP Property System. Offer ends 11/08/13!**
==
**Once you've purchased this script, send me a PM, and I will grand you access to the hud files.**

##Description##
This addon changes the way you purchase properties in DarkRP. If you want something unique for your server, you're at the right place.
With this addon comes a whole new way of purchasing a property. To purchase a property you must walk to the npc (location set by the server owner), and talk to him. He will have a list of properties you can purchase.
In the menu you can see the name of the property, the price, and a description.
The server owner also has the ability to set up the menu to include small preview pictures of the properties. These are all very easy to add, and there's already a system in place to have the clients download them (tho if you want/have FastDL, you will have to set that up yourself).  

The property system comes with 1 map that is already set up. More maps can be purchased upon request, or you can simply set it up yourself.  
As you can see below in the features list, the addon comes with a tool to get door locations (this has to be done manually, and takes some time. Depending on the size of the map of course).  

##Features##
-Buy & Sell properties using an NPC.  
-Buying/Selling a place from the NPC will buy/sell all the doors attached to that place.  
-Property Stick swep that helps you set up new maps for your server.  
-Buddies/Co-Owners can easily be added using the modified keys system. Pressing reload while having your keys out, looking at a door you own, will open the buddies menu (DarkRP default system).  
-Automatic system of downloading map preview pictures (png images). You simply put in the path of the folder, in the map loading file (following the instructions), and the files will download for your clients.  
-Place as many NPCs as you want. Has support for multiply maps so it will save, even if you switch map.
-Support for government owned doors. Simply set the description of a place to "police", and the price to be 0.

##Installation##
Installing this addon is not difficult, but requires just a bit more than extracting the addon to addons.  

But still, the first thing you want to do is extract the folder to your addons folder. That way, you now have the property system installed.

Because of some DarkRP code that conflicts, we will have to remove/comment out some code.  
Head over to gamemodes/DarkRP/gamemode/client and open hud.lua. On line ~363 you will find this code: tr.Entity:DrawOwnableInfo(). Simply replace it with this: tr.Entity:DrawCustomOwnableInfo()  
Now in the same folder, open the vgui.lua file. Scroll all the way to the bottom and find this code: GM.ShowTeam = KeysMenu. Replace it with this: --GM.ShowTeam = KeysMenu  

Next we will want to disable the way to purchase doors the old DarkRP style, /toogleown in chat. Head over to the FOLDER called gamemodes/DarkRP/gamemode/shared, and find the file called entity.lua.  
There's a few thing we want to replace here.  

At the very top of the file, add this:

local function PS\_CommandDenied( ply )  
GAMEMODE:Notify(ply, 1, 4, "Property System is active. Access denied!")  
end  

Now that we have this notification in place, we will want to replace a few lines.  

On line 461, replace AddChatCommand("/toggleown", OwnDoor) with AddChatCommand("/toggleown", PS\_CommandDenied)  
On line 472, replace AddChatCommand("/unownalldoors", UnOwnAll) with AddChatCommand("/unownalldoors", PS\_CommandDenied)  
On line 580, replace AddChatCommand("/title", SetDoorTitle) with AddChatCommand("/title", PS\_CommandDenied)  

Now for the last step of installing your new property system, is to set up the NPC location.  

All you have to do now is launch your server, find a fitting spot for the NPC, and type "propertynpc\_setpos uniquename" in console.
With the latest update of all my scripts I have added support for multiply NPCs.
You place an NPC as before, but you must make a space, and put an unique name. This will be the filename.
This new system also introduces map support. So now you can have as many NPCs as you want, on as many maps as you want.
All of this without having to make a new position every time you switch map.
This also adds the option to remove an NPC. Just type "propertynpc\_remove filename" in console to remove the NPC with that name.
Or you can go to the directory craphead\_scripts/property\_system/map\_name, and remove it manually.

##Adding Maps##
To set up more maps, you will want to use the "Property Stick". To get this weapon, type "PS\_SpawnTool" in console. This command is only accessable by admins.  
First of all, go the DarkRP Property System/lua/maps.lua. In that file you will see the default map that comes with the script (rp\_downtown\_v4c\_v2), and at the very top there's a table called rp\_default.
You will see the beginning of the table you will want to extend on. This table determens name, preview picture, description, price and the doors in the property you are setting up.  
A simply example of how to add a property is shown below. This property has 2 doors.  
{Name = "Classy Property Name",Picture = "property\_system/PS\_QuestionMark.png",Description = "This place is extremely classy, but also expensive.",Price = 6000,Doors = {Vector(-8335,-1025,126),Vector(-7943,-10233,125),}},
If you are confused with anything here, just take a look at how the rp\_downtown\_v4c\_v2 one is done. It's very easy to understand.

The Property Stick helps you to get the vectors of the doors for your property.  
Equip the property stick, aim at a door, and left click. This will print the vector into your console. Like this: Vector(100,100,100).  
Repeat for all the doors in the property, and add them to the table, like shown above. Remember to always put a comma at the end of the vector. As shown above in the example.  

I know it can be dificult to set up a map, but do it carefully, and don't rush. Check over the codes if they match the example shown, as in if you are missing commas or the like.  
You are always very welcome to request new maps. I usually charge around 2-4 dollars per map. Depending the size of the map. 

##Adding Preview Pictures##
After you've set up your map, you might want to include pictures of all the properties.  
When you've gathered all the pictures you want (one for each property I would assume), go to DarkRP Property System/materials/properties.  
Create a folder with the name of the map the pictures are from.  
Now go to the lua file with all the maps in, DarkRP Property System/lua/maps.lua
In the very top, there's code like this: AddDir("materials/properties/map\_name")  
Simply replace map\_name with the name of your map (as in the folder for materials you created).
If you're adding more maps, just copy/paste that line, and edit the map name again. Simple as that. 
The pictures will now download for your clients. If you have FastDL on your server, make sure you upload the pictures to your FastDL server as well.  

##Available Extra Maps##
[RP\_EvoCity\_V2D](http://coderhire.com/scripts/view/202)  
[RP\_EvoCity\_V33X](http://coderhire.com/scripts/view/201)

##Future Support##
If you run into any troubles with the addon, report them to me and they will be fixed as soon as possible. I will keep this addon updated as long as it exists on CoderHire. Any future issues with GMod updates will be patched.

##Media##
![Alt text](http://filesmelt.com/dl/Property_Menu.jpg)
![Alt text](http://filesmelt.com/dl/Property_For_Sale.jpg)
![Alt text](http://filesmelt.com/dl/Property_Owned.jpg)
![Alt text](http://filesmelt.com/dl/Property_Co-Owners.jpg)