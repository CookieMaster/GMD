do -- includes / resources
    include("sh_trading.lua")
    include("vgui/DPointShopTradeNotification.lua")
    include("vgui/DPointShopTradeScreen.lua")
end

do -- networked hooks
    net.Receive('PS.Trading_StartTrade', function(len)
        PS.Trading:StartTrade(net.ReadTable())
        local requestid = net.ReadUInt(8)

        local pnl = PS.Trading.TradeNotificationPanels[requestid]
        if IsValid(pnl) then
            pnl:Remove()
            PS.Trading.TradeNotificationPanels[requestid] = nil
        end
    end)
    net.Receive('PS.Trading_RequestTrade', function(len)
        local trade = net.ReadTable()
        PS.Trading:RequestTrade(trade)
    end)
    net.Receive('PS.Trading_ItemAdded', function(len)
        local id = net.ReadUInt(8)
        local senderkey = net.ReadUInt(8)
        local item = net.ReadString()

        local trade = PS.Trading.ActiveTrades[id]
        if not trade then return end

        trade.Panel:AddItem(senderkey, item)
    end)
    net.Receive('PS.Trading_ItemRemoved', function(len)
        local id = net.ReadUInt(8)
        local senderkey = net.ReadUInt(8)
        local item = net.ReadString()

        local trade = PS.Trading.ActiveTrades[id]
        if not trade then return end

        trade.Panel:RemoveItem(senderkey, item)
    end)

    net.Receive('PS.Trading_PointsSet', function(len)
        local id = net.ReadUInt(8)
        local senderkey = net.ReadUInt(8)
        local points = net.ReadUInt(32)

        local trade = PS.Trading.ActiveTrades[id]
        if not trade then return end

        trade.Panel:SetPoints(senderkey, points)
    end)

    net.Receive('PS.Trading_TradeDeclined', function(len)
        PS.Trading:TradeDeclined(net.ReadUInt(8))
    end)

    net.Receive('PS.Trading_Notify', function(len)
        local id = net.ReadUInt(8)
        local msg = net.ReadString()

        local trade = PS.Trading.ActiveTrades[id]
        if not trade then return end

        if IsValid(trade.Panel) then
            trade.Panel:Notify(msg)
        end
    end)

    net.Receive('PS.Trading_ReadyChanged', function(len)
        local id = net.ReadUInt(8)
        local senderkey = net.ReadUInt(8)
        local state = net.ReadBit() == 1

        local trade = PS.Trading.ActiveTrades[id]
        if not trade then return end

        if IsValid(trade.Panel) then
            trade.Panel:ReadyChanged(senderkey, state)
        end
    end)

    net.Receive('PS.Trading_EndTrade', function(len)
        local id = net.ReadUInt(8)
        local reason = net.ReadString()

        local trade = PS.Trading.ActiveTrades[id]
        if not trade then return end

        if IsValid(trade.Panel) then trade.Panel:Close() end
        PS.Trading.ActiveTrades[id] = nil

        chat.AddText(Color(255, 0, 0), "Trade ended: " .. reason)
    end)
end

PS.Trading.TradeNotificationPanels = {}
PS.Trading.ActiveTrades = {}

function PS.Trading:StartTrade(trade)
    PS.Trading.ActiveTrades[trade.id] = trade

    local pnl = vgui.Create("DPointShopTradeScreen")
    pnl:Setup(trade.id)

    PS.Trading.ActiveTrades[trade.id].Panel = pnl
end

function PS.Trading:TradeDeclined(id)
    local pnl = self.TradeNotificationPanels[id]
    if not pnl and not IsValid(pnl) then return end

    pnl:Declined()
end

function PS.Trading:RequestTrade(trade)
   local pnl = g_TradePanelList:Add("DPointShopTradeNotification")
   pnl:Setup(trade)

   self.TradeNotificationPanels[trade.id] = pnl
end

hook.Add( "InitPostEntity", "CreatePSTradingVGUI", function()
    g_TradePanelList = vgui.Create( "DPanel" )

    --g_TradePanelList:ParentToHUD()
    g_TradePanelList:SetPos( ScrW() - 320, 0 )
    g_TradePanelList:SetSize( 320, ScrH() - 200 )
    g_TradePanelList:SetDrawBackground( false )
    g_TradePanelList:SetMouseInputEnabled( true )
end )

