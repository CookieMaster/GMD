if SERVER then
	AddCSLuaFile()
	include('sv_trading.lua')
end

if CLIENT then
	include('cl_trading.lua')
end