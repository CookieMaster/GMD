hook.Add("HUDPaint", "DrawVehicleHealth", function()
		local pos = LocalPlayer():GetShootPos()
		local ang = LocalPlayer():GetAimVector()
		local tracedata = {}
		tracedata.start = pos
		tracedata.endpos = pos + (ang * 100)
		tracedata.filter = LocalPlayer()
		local trace = util.TraceLine(tracedata)
		local ent = trace.Entity
		if(LocalPlayer():InVehicle() && ent:IsVehicle() && ent:Health() > 0) then
			draw.RoundedBox( 16, 0, 595, 1005, 40, Color( 0, 0, 0, 200 ) )
			draw.RoundedBox( 16, 5, 600, ent:Health() * 5, 30, Color( 255, 0, 0, 200 ) )
			draw.DrawText( "Vehicle Health: " .. ent:Health(), "TargetID", ScrW() * 0.5, 605, Color( 255,255,255,255 ), TEXT_ALIGN_CENTER )
		elseif LocalPlayer():InVehicle() then
			draw.RoundedBox( 16, 0, 595, 1005, 40, Color( 0, 0, 0, 200 ) )
			draw.RoundedBox( 16, 5, 600, 200 * 5, 30, Color( 255, 0, 0, 200 ) )
			draw.DrawText( "Vehicle Health: NOT REGISTERED", "TargetID", ScrW() * 0.5, 605, Color( 255,255,255,255 ), TEXT_ALIGN_CENTER )
		end
end)

