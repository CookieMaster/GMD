------------------------------------------------------------------------------------
---------------------------- Garrrys Mod Vehicle Health 1.4 ----------------------------
------------------------------ Create by Home Sparkle ------------------------------
------------------------------------------------------------------------------------
CarDamageConfig =
{
	Debug = true, ---------------------- Print Damage 
	OneHitExplode = true, --------------- One Hit Explode on take damage from explosion (ex. RPG C4)
	HPtoSmoke = 50, ----------------------- Minimum HP to making smoke
	VehicleHP = 200, ----------------------- Vehicle HP
	CleanVehicleProp = 30, ---------------------- Clear Vehicles in second
	MinRandomExplode = 1, ------------------------ Minimum random time to explode after the car burning
	MaxRandomExplode = 15, ------------------------ Maximum random time to explode after the car burning
	MagnitudeDamage = 100, --------------------------- explosion damages given to player
	DamageMultiple = 800, --------------------------- Damage Multiple
	MinDamageEntity = 1, ----------------------------- Minimum damage can take to vehicle
	MaxDamageEntity = 10, ----------------------------- Maximum damage can take to vehicle
	FireRadius = 100, ------------------------------- Radius to ignite around prop near car when explode
	ExplodeRadius = 500, ------------------------------- Radius Explosion around prop near car when explode
	IgniteAroundProp = 30, -------------------------- Second to ignite around prop near car when explode
	VehicleUp = 100, --------------------- Make vehicle fly up in to sky when explode
	ExplosionSound = "ambient/explosions/explode_1.wav", ------------- Sound Explode
	IgniteSound = "ambient/fire/ignite.wav", ----------------- Sound start ignite
	ExplosionEffect = "HelicopterMegaBomb", ------------------ Particle Explode list here : http://maurits.tv/data/garrysmod/wiki/wiki.garrysmod.com/indexe14a.html
	BurningEffect = "fire_large_01", ------------------ Particle Burning after out of HP
	IgniteEffect = "burning_engine_01", ------------------ Particle Smoke near explode
	WreckCar = "models/props_pipes/GutterMetal01a" --------------- Material Wreck car
}

----------------Burning Sound-------------------
sound.Add( 
{
 name = "fire_med_loop1",
 channel = CHAN_STATIC,
 volume = 10.0,
 soundlevel = 100,
 pitchstart = 100,
 pitchend = 100,
 sound = "ambient/fire/fire_med_loop1.wav" ------------- Config burning sound here!
} )

function SetHealthVehicle(ent)
	if ent:IsVehicle() then 
		if ent:GetClass() == "prop_vehicle_prisoner_pod" then return end
		ent:SetHealth(CarDamageConfig.VehicleHP) 
	end
end
hook.Add("OnEntityCreated","SetHealthVehicle",SetHealthVehicle)

function VehicleHealth (ent, dmginfo)
	local infl = dmginfo:GetInflictor()
	local att = dmginfo:GetAttacker()
	local amount	= dmginfo:GetDamage()
	
	if not ent:IsVehicle() then return end
	if ent:GetClass() == "prop_vehicle_prisoner_pod" then return end
	local vPoint = Vector(ent:GetPos())
	local effectdata = EffectData()
	effectdata:SetStart( vPoint ) 
	effectdata:SetOrigin( vPoint )
	effectdata:SetScale(10000)
	util.Effect( CarDamageConfig.ExplosionEffect, effectdata )
	local damage
	if dmginfo:IsExplosionDamage() then
		ent.IsDamageFromExplosion = true
		damageExplosion = amount * CarDamageConfig.DamageMultiple
		ent:SetHealth(ent:Health() - damageExplosion)
	else
		damage = amount * CarDamageConfig.DamageMultiple
		if damage <= CarDamageConfig.MinDamageEntity then damage = CarDamageConfig.MinDamageEntity end
		if damage >= CarDamageConfig.MaxDamageEntity then damage = CarDamageConfig.MaxDamageEntity end
		-- damage = math.Clamp(damage, 1, 10)
		ent:SetHealth(ent:Health() - damage)
	end
	
	if CarDamageConfig.Debug == true and not ent.Burning and not ent.IsDamageFromExplosion == true then att:ChatPrint("Vehicle HP : "..ent:Health().." has take "..damage.." damage") end
	if CarDamageConfig.Debug == true and not ent.Burning and ent.IsDamageFromExplosion == true then att:ChatPrint("Vehicle HP : "..ent:Health().."has take "..damageExplosion.." damage") end
	if ent:Health() <= CarDamageConfig.HPtoSmoke and not ent.smoke then
		ParticleEffectAttach(CarDamageConfig.IgniteEffect,PATTACH_ABSORIGIN_FOLLOW,ent,0)
		ent:EmitSound(CarDamageConfig.IgniteSound, 100)
		ent.smoke = true
	end
	if ent:Health() <= 0 and not ent.Burning and ent.IsDamageFromExplosion == true and CarDamageConfig.OneHitExplode == true then
			ent.Burning = true
			local vPoint = ent:GetPos()
			local effectdata = EffectData()
			effectdata:SetStart( vPoint ) 
			effectdata:SetOrigin( vPoint )
			effectdata:SetScale(1)
			util.Effect( CarDamageConfig.ExplosionEffect, effectdata )	
			util.BlastDamage(ent, ent, ent:GetPos(), CarDamageConfig.ExplodeRadius, CarDamageConfig.MagnitudeDamage)
			ent:EmitSound(CarDamageConfig.ExplosionSound, 100)
			if ent:GetDriver():IsPlayer() then
				local explodeplayer = DamageInfo()
				explodeplayer:SetDamage( 9999999999 )
				explodeplayer:SetDamageType( DMG_BLAST )
				ent:GetDriver():TakeDamageInfo( explodeplayer )
			end
			local victiments = ents.FindInSphere( ent:GetPos() , CarDamageConfig.FireRadius )
			for k, v in pairs(ents.FindInSphere( ent:GetPos() , CarDamageConfig.FireRadius )) do
				v:Ignite( CarDamageConfig.IgniteAroundProp )
			end
			ent:Remove()
			local prop = ents.Create("prop_physics")
			prop:SetModel(ent:GetModel())
			prop:SetMaterial(CarDamageConfig.WreckCar)
			prop:SetPos(ent:GetPos())
			prop:SetAngles(ent:GetAngles())
			prop:Spawn()
			prop:Ignite(CarDamageConfig.CleanVehicleProp -1, 0)
			timer.Simple(CarDamageConfig.CleanVehicleProp, function() prop:StopSound("fire_med_loop1") prop:Remove() end)
			ParticleEffectAttach(CarDamageConfig.BurningEffect,PATTACH_ABSORIGIN_FOLLOW,prop,0)
			prop:EmitSound("fire_med_loop1", 100)
			local phys = prop:GetPhysicsObject()
			local propmove = prop:GetPos() - (prop:GetPos() - prop:GetUp() * CarDamageConfig.VehicleUp)
			local vForce = propmove * 5000		
			phys:ApplyForceCenter(vForce)
	elseif ent:Health() <= 0 and not ent.Burning then
		ent.Burning = true
		local ExplodeTime = math.random(CarDamageConfig.MinRandomExplode,CarDamageConfig.MaxRandomExplode)
		ParticleEffectAttach(CarDamageConfig.BurningEffect,PATTACH_ABSORIGIN_FOLLOW,ent,0)
		ent:EmitSound(CarDamageConfig.IgniteSound, 100)
		ent:EmitSound("fire_med_loop1", 100)
		ent:Ignite(ExplodeTime, 0)
		timer.Simple(ExplodeTime, function()
			ent:StopSound("fire_med_loop1")
			local vPoint = ent:GetPos()
			local effectdata = EffectData()
			effectdata:SetStart( vPoint ) 
			effectdata:SetOrigin( vPoint )
			effectdata:SetScale(10000)
			util.Effect( CarDamageConfig.ExplosionEffect, effectdata )	
			util.BlastDamage(ent, ent, ent:GetPos(), CarDamageConfig.ExplodeRadius, CarDamageConfig.MagnitudeDamage)
			ent:EmitSound(CarDamageConfig.ExplosionSound, 100)
			if ent:GetDriver():IsPlayer() then
				local explodeplayer = DamageInfo()
				explodeplayer:SetDamage( 9999999999 )
				explodeplayer:SetDamageType( DMG_BLAST )
				ent:GetDriver():TakeDamageInfo( explodeplayer )
			end
			local victiments = ents.FindInSphere( ent:GetPos() , CarDamageConfig.FireRadius )
			for k, v in pairs(ents.FindInSphere( ent:GetPos() , CarDamageConfig.FireRadius )) do
				v:Ignite( CarDamageConfig.IgniteAroundProp )
			end
			ent:Remove()
			local prop = ents.Create("prop_physics")
			prop:SetModel(ent:GetModel())
			prop:SetMaterial(CarDamageConfig.WreckCar)
			prop:SetPos(ent:GetPos())
			prop:SetAngles(ent:GetAngles())
			prop:Spawn()
			prop:Ignite(CarDamageConfig.CleanVehicleProp -1, 0)
			timer.Simple(CarDamageConfig.CleanVehicleProp, function() prop:StopSound("fire_med_loop1") prop:Remove() end)
			ParticleEffectAttach(CarDamageConfig.BurningEffect,PATTACH_ABSORIGIN_FOLLOW,prop,0)
			prop:EmitSound("fire_med_loop1", 100)
			local phys = prop:GetPhysicsObject()
			local propmove = prop:GetPos() - (prop:GetPos() - prop:GetUp() * CarDamageConfig.VehicleUp)
			local vForce = propmove * 5000
			phys:ApplyForceCenter(vForce)
		end)
	end
end
hook.Add("EntityTakeDamage", "VehicleHealth", VehicleHealth)