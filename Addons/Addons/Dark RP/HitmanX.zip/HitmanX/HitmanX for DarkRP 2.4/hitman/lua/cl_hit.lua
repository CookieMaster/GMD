surface.CreateFont( "NotifTitle", {
 font = "Bebas Neue",
 size = 24,
 weight = 0,
 antialias = true
} )

surface.CreateFont( "NotifTitle2", {
 font = "Bebas Neue",
 size = 26,
 weight = 0,
 antialias = true
} )

surface.CreateFont( "NotifBody", {
 font = "Bebas Neue",
 size = 30,
 weight = 0,
 antialias = true
} )

surface.CreateFont( "HitInfoFont", {
 font = "Bebas Neue",
 size = 40,
 weight = 0,
 antialias = true
} )

surface.CreateFont( "HitInfoFontSmall", {
 font = "Bebas Neue",
 size = 24,
 weight = 0,
 antialias = true
} )

surface.CreateFont( "NotifHeader", {
 font = "Bebas Neue",
 size = 16,
 weight = 0,
 antialias = true
} )

surface.CreateFont( "HitComplete", {
 font = "Bebas Neue",
 size = 100,
 weight = 0,
 antialias = true
} )

surface.CreateFont( "HitComplete2", {
 font = "Bebas Neue",
 size = 50,
 weight = 0,
 antialias = true
} )

surface.CreateFont( "NotifConf", {
 font = "Myriad Pro",
 size = 24,
 weight = 0,
 antialias = true
} )

surface.CreateFont( "HitPlaceFont", {
 font = "Myriad Pro",
 size = 16,
 weight = 0,
 antialias = true
} )

surface.CreateFont( "HitButton", {
 font = "Myriad Pro",
 size = 20,
 weight = 0,
 antialias = true
} )

surface.CreateFont( "fontclose", {
 font = "Cabin",
 size = 14,
 weight = 500,
 blursize = 0,
 scanlines = 0,
 antialias = true
} )

local function formatNumber(n)
	if not n then return "" end
	if n >= 1e14 then return tostring(n) end
    n = tostring(n)
    local sep = sep or ","
    local dp = string.find(n, "%.") or #n+1
	for i=dp-4, 1, -3 do
		n = n:sub(1, i) .. sep .. n:sub(i+1)
    end
    return n
end

local function FindThePlayerEz( l )
	local target
	for k, v in pairs( player.GetAll() ) do
		if l == v:Name() then
			target = v
		end
	end
	return target
end

local function DrawPlayerAvatar( p )
	ff = vgui.Create("DFrame")
	ff:SetPos( 34, 34 )
	ff:SetSize( 80, 80 )
	ff:SetVisible( true )
	
	av = vgui.Create("AvatarImage", ff)
	av:SetPos(0,0)
	av:SetSize(80, 80)
	av:SetPlayer( p, 184 )
end

local function CloseAv()
	ff:Close()
end
usermessage.Hook( "CloseAv", CloseAv )

local function DrawHitInfo()
	if string.len(LocalPlayer():GetNWString( "targ" )) >= 2 then
	
		local q = FindThePlayerEz(LocalPlayer():GetNWString( "targ" ))
		local fd = q:GetPos()
		local md = LocalPlayer():GetPos()
		local d = md:Distance( fd )
		
		draw.RoundedBox( 4, 13, 13, 402, 122, Color( 28, 28, 28, 255 ) )
		draw.RoundedBox( 4, 14, 14, 400, 120, Color( 244, 244, 244, 255 ) )
		draw.RoundedBox( 4, 32, 32, 84, 84, Color( 0, 0, 0, 255 ) )
		draw.SimpleText( "Name: "..LocalPlayer():GetNWString( "targ" ), "HitInfoFont", 140, 30, Color( 28, 28, 28, 255 ) )
		draw.SimpleText( "Occupation: "..team.GetName(q:Team()), "HitInfoFontSmall", 140, 60, Color( 135, 135, 135, 255 ) )
		draw.SimpleText( "Distance: "..tostring( math.floor(d) ), "HitInfoFontSmall", 140, 80, Color( 135, 135, 135, 255 ) )
		draw.SimpleText( "Reward: $"..tonumber(LocalPlayer():GetNWString( "bounty" )), "HitInfoFontSmall", 400, 100, Color( 28, 28, 28, 255 ), TEXT_ALIGN_RIGHT )
	end
end
hook.Add( "HUDPaint", "skhdsakjl", DrawHitInfo )

local function DrawConfPanel()
	
	local bounty = net.ReadFloat()
	--local timel = net.ReadFloat()
	local targy = net.ReadEntity()
	local req = net.ReadEntity()
	local offset = 30
	local conf = vgui.Create( "DFrame" )
	conf:SetSize( 250 * 2, 160 * 2)
	conf:SetPos( ScrW() / 2 - 250, ScrH() / 2 - 160 )
	conf:SetTitle( "" )
	conf:SetDraggable( false )
	conf:ShowCloseButton( false )
	conf:MakePopup()
	conf.Paint = function( self, w, h )
		draw.RoundedBox( 4, 0, 0, w, h, Color( 0, 0, 0, 255 ) )
		draw.RoundedBox( 4, 1, 1, w - 2, h - 2, Color( 252, 252, 252, 255 ) )
		draw.RoundedBox( 4, 1, 1, w - 2, 30, Color( 225, 245, 252, 255 ) )
		draw.RoundedBox( 0, 1, 30, w - 2, 1, Color( 148, 171, 185, 255 ) )
		draw.RoundedBox( 0, 1, 31, w - 2, 1, Color( 214, 225, 233, 255 ) )
		draw.RoundedBox( 0, 1, 32, w - 2, 1, Color( 229, 236, 241, 255 ) )
		draw.RoundedBox( 0, 1, 33, w - 2, 1, Color( 240, 244, 246, 255 ) )
		surface.SetDrawColor( Color( 224, 224, 224, 255 ) )
		surface.DrawLine( 0, 30, w, 30 )
			
		draw.RoundedBox( 0, 0, 0, w, 30, Color( 51, 54, 58, 255 ) )
			
		draw.RoundedBox( 0, 1, 1, w - 2, 30 - 2, Color( 62, 67, 77 ) )
			
		surface.SetDrawColor( Color( 84, 89, 100, 255 ) )
		surface.DrawLine( 1, 1, w - 1, 1 )
		surface.DrawLine( 1, 1, 1, 30 )
		surface.DrawLine( 1, 28, w - 1, 28 )
		surface.DrawLine( w - 2, 1, w - 2, 30 )
		draw.SimpleText( "Bounty Notification", "NotifTitle", w / 2, 4, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
		draw.SimpleText( "Target: "..targy:Name(), "NotifBody", 50, 50, Color( 2, 46, 61, 255 ) )
		draw.SimpleText( "Target Occupation: "..team.GetName( targy:Team() ), "NotifBody", 50, 80, Color( 2, 46, 61, 255 ) )
		draw.SimpleText( "Initiator: "..req:Name(), "NotifBody", 50, 110, Color( 2, 46, 61, 255 ) )
		draw.SimpleText( "Reward: $"..formatNumber(tonumber(bounty)), "NotifBody", 50, 140, Color( 2, 46, 61, 255 ) )
		draw.RoundedBox( 0, 80, h - 130, w - 160, 1, Color( 200, 200, 200, 255 ) )
		draw.SimpleText( "Would you like to accept this hit/bounty?", "NotifConf", w / 2, h - 114, Color( 2, 46, 61, 255 ), TEXT_ALIGN_CENTER )
		draw.RoundedBox( 8, 26, conf:GetTall() - 74, 178, 58, Color( 233, 233, 233, 255 ) )
		draw.RoundedBox( 8, conf:GetWide() - 204, conf:GetTall() - 74, 178, 58, Color( 233, 233, 233, 255 ) )
	end
	
	local function CreateButtonHit( posx, posy, label, colIn, colOut )
		local yesbut = vgui.Create( "DButton", conf )
		yesbut:SetSize( 85 * 2, 25 * 2 )
		yesbut:SetPos( posx, posy )
		yesbut:SetFont( "NotifConf" )
		yesbut:SetText( label )
		yesbut:SetTextColor( Color( 252, 252, 252, 255 ) )
		yesbut.Paint = function( self, w, h )
			local gcol
				if self.hover then
					gcol = Color( 36, 190, 255 )
				else
					gcol = Color( 26, 160, 212 )
				end
				draw.RoundedBox( 0, 0, 0, w, h, Color( 22, 131, 173 ) )
				draw.RoundedBox( 0, 1, 1, w - 2, h - 2, gcol )
				
				surface.SetDrawColor( Color( 31, 191, 255, 255 ) )
				surface.DrawLine( 1, 1, w - 1, 1 )
				surface.DrawLine( 1, 1, 1, 50 )
				surface.DrawLine( 1, 48, w - 1, 48 )
				surface.DrawLine( w - 2, 1, w - 2, 30 )
			end
			yesbut.OnCursorEntered = function( self )
				self.hover = true
			end
			yesbut.OnCursorExited = function( self )
				self.hover = false
			end
		yesbut.DoClick = function()
			if label == "Hell yeah!" then
				AcceptBounty()
				conf:Close()
			elseif label == "No thanks" then
				conf:Close()
			end
		end
	end
	
	function AcceptBounty()
		net.Start( "SendMoney" )
			net.WriteEntity( req )
			net.WriteEntity( LocalPlayer() )
			net.WriteEntity( targy )
			net.WriteString( bounty )
		net.SendToServer()
		
		DrawPlayerAvatar( targy )
	end
	
	CreateButtonHit( 30, conf:GetTall() - 70, "Hell yeah!", Color( 36, 165, 221 ), Color( 16, 96, 130 ) )
	CreateButtonHit( conf:GetWide() - 200, conf:GetTall() - 70, "No thanks", Color( 235, 84, 78 ), Color( 161, 44, 40 ) )
	
	local targmodel = vgui.Create( "DModelPanel", conf )
	targmodel:SetSize( 180, 180 )
	targmodel:SetPos( conf:GetWide() - 220, 10 )
	targmodel:SetModel( targy:GetModel() )
end
net.Receive( "ConfPanel", DrawConfPanel )

local function PrintHitAccept( data )
	local r = data:ReadEntity()
	chat.AddText( Color( 150, 150, 255, 255 ), "[HitmanX] ", Color( 252, 252, 252, 255 ), "Your hit has been accepted by "..r:Name().."." )
end
usermessage.Hook( "MHitAccept", PrintHitAccept )

local function HitComplete()
	local con = vgui.Create( "Panel" )
	con:SetSize( 600, 200 )
	con:SetPos( ScrW() / 2 - 300, ScrH() / 2 - 100 )
	con.Paint = function( self, w, h )
		draw.SimpleText( "HIT COMPLETE", "HitComplete", w / 2, h / 2 - 20, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
		draw.SimpleText( "Congratulations", "HitComplete2", w / 2, h / 2 - 40, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
	end
	timer.Simple( 4, function() con:Remove() end )
end
usermessage.Hook( "HitComplete", HitComplete )

local pickedPlayer

local function ChooseHit()
	local selectedply
	
	local bg = vgui.Create( "DFrame" )
	bg:SetSize( 600, 300 )
	bg:SetPos( ScrW() / 2 - 300, ScrH() / 2 - 150 )
	bg:MakePopup()
	bg:SetDraggable( false )
	bg:ShowCloseButton( false )
	bg:SetTitle( "" )
	bg.Paint = function( self, w, h )
		draw.RoundedBox( 4, 0, 0, w, h, Color( 0, 0, 0, 200 ) )
		draw.RoundedBox( 4, 1, 1, w - 2, h - 2, Color( 252, 252, 252, 255 ) )
		draw.SimpleText("Available Hitmen","HitPlaceFont",108,h - 140 + 8,Color(0,0,0,255), TEXT_ALIGN_CENTER)
		
		surface.SetDrawColor( Color( 224, 224, 224, 255 ) )
		surface.DrawLine( 0, 30, w, 30 )
			
		draw.RoundedBox( 0, 0, 0, w, 30, Color( 51, 54, 58, 255 ) )
			
		draw.RoundedBox( 0, 1, 1, w - 2, 30 - 2, Color( 62, 67, 77 ) )
			
		surface.SetDrawColor( Color( 84, 89, 100, 255 ) )
		surface.DrawLine( 1, 1, w - 1, 1 )
		surface.DrawLine( 1, 1, 1, 30 )
		surface.DrawLine( 1, 28, w - 1, 28 )
		surface.DrawLine( w - 2, 1, w - 2, 30 )
		
		draw.SimpleText( "Hit Request Form", "NotifTitle2", w / 2, 3, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER )
		
		draw.SimpleText("Hit Reward","HitPlaceFont",108,h - 100 + 10,Color(0,0,0,255), TEXT_ALIGN_CENTER)
		--draw.SimpleText("Time Limit","HitPlaceFont",108,h - 60 + 10,Color(0,0,0,255), TEXT_ALIGN_CENTER)
	end
	
	local cl = vgui.Create( "DButton", bg )
	cl:SetSize( 50, 20 )
	cl:SetPos( bg:GetWide() - 60, 0 )
	cl:SetText( "X" )
	cl:SetFont( "fontclose" )
	cl:SetTextColor( Color( 255, 255, 255, 255 ) )
	cl.Paint = function( self, w, h )
		local kcol
		if self.hover then
			kcol = Color( 255, 150, 150, 255 )
		else
			kcol = Color( 175, 100, 100 )
		end
		draw.RoundedBoxEx( 0, 0, 0, w, h, Color( 255, 150, 150, 255 ), false, false, true, true )
		draw.RoundedBoxEx( 0, 1, 0, w - 2, h - 1, kcol, false, false, true, true )
	end
	cl.DoClick = function()
		bg:Close()
	end
	cl.OnCursorEntered = function( self )
		self.hover = true
	end
	cl.OnCursorExited = function( self )
		self.hover = false
	end
	
	local qp
	
	local plylist = vgui.Create( "DListView", bg )
	plylist:SetSize( 200, 120 )
	plylist:SetPos( 10, 40 )
	plylist:SetMultiSelect(false)
	plylist:AddColumn( "Name" )
	plylist.PaintOver = function(self, w, h)
		draw.RoundedBox( 0, 0, 0, w, 15, Color( 252, 252, 252 ) )
		draw.SimpleText("Players","HitPlaceFont",w / 2,0,Color(0,0,0,255), TEXT_ALIGN_CENTER)
	end
	
	for k,v in pairs(player.GetAll()) do
		if v != LocalPlayer() and !table.HasValue( HIT.HitmanTeams, team.GetName(v:Team()) ) and v:Alive() then
			plylist:AddLine(v:Name())
		end
	end
	
	local hl = vgui.Create( "DComboBox", bg)
	hl:SetPos(10,bg:GetTall() - 122 + 8)
	hl:SetSize( 200, 20 )
	
	for k,v in pairs(player.GetAll()) do
		print( v:Name().." "..v:Team() )
		if table.HasValue( HIT.HitmanTeams, team.GetName(v:Team()) ) then
			hl:AddChoice( v:Name() )
		end
	end
	
	local hms
	
	hl.OnSelect = function( panel, index, value, data )
		local lk = value
		hms = FindThePlayerEz( lk )
	end
	
	local myText = vgui.Create("DTextEntry", bg)
	myText:SetText("Enter Hit Reward Here!")
	myText:SetPos( 10, bg:GetTall() - 80 + 8 )
	myText:SetSize( 200, 20	)
	
	local plypanel = vgui.Create( "DFrame", bg )
	plypanel:SetSize( 380, 260 )
	plypanel:SetPos( bg:GetWide() / 2 - 80, 40 )
	plypanel:SetTitle( "" )
	plypanel:ShowCloseButton( false )
	plypanel.Paint = function(self, w, h)
		if selectedply then
			for k, v in pairs( player.GetAll() ) do
				if string.find( string.lower( v:Name() ), string.lower( selectedply ) ) != nil then
					tf = v
				end
			end
			draw.SimpleText( "Name: "..selectedply, "NotifBody", 0, 10, Color( 2, 46, 61, 255 ) )
			draw.SimpleText( "Occupation: "..team.GetName(tf:Team()), "NotifBody", 0, 40, Color( 2, 46, 61, 255 ) )
			draw.SimpleText( "Appearance", "NotifHeader", w - 112, 12, Color( 2, 46, 61, 255 ), TEXT_ALIGN_CENTER )
			draw.SimpleText( "Health: "..tf:Health(), "NotifBody", 0, 70, Color( 2, 46, 61, 255 ) )
			draw.SimpleText( "Armor: "..tf:Armor(), "NotifBody", 0, 100, Color( 2, 46, 61, 255 ) )
			draw.RoundedBox( 0, 80, h - 66, w - 160, 1, Color( 200, 200, 200, 255 ) )
			draw.RoundedBox( 6, w / 2 - 82, plypanel:GetTall() - 52, 164, 34, Color( 233, 233, 233, 255 ) )
		end
	end
	
	local function OpenModel( ent )
		if targmodel then
			targmodel:Remove()
		end
		targmodel = vgui.Create( "DModelPanel", plypanel )
		targmodel:SetSize( 180, 180 )
		targmodel:SetPos( plypanel:GetWide() - 200, 10 )
		targmodel:SetModel( ent:GetModel() )
	end
	
	plylist.OnRowSelected = function( panel, line )
		selectedply = panel:GetLine( line ):GetValue( 1 )
		qp = FindThePlayerEz( selectedply )
		OpenModel( qp )
		pickedPlayer = true
	end
	
	plylist:SelectFirstItem()
	
	local placebut = vgui.Create( "DButton", plypanel )
	placebut:SetSize( 160, 30 )
	placebut:SetPos( plypanel:GetWide() / 2 - 80, plypanel:GetTall() - 50 )
	placebut:SetFont( "HitButton" )
	placebut:SetText( "Place Hit!" )
	placebut:SetTextColor( Color( 252, 252, 252, 255 ) )
	placebut.Paint = function( self, w, h )
				local gcol
				if self.hover then
					gcol = Color( 36, 190, 255 )
				else
					gcol = Color( 26, 160, 212 )
				end
				draw.RoundedBox( 0, 0, 0, w, h, Color( 22, 131, 173 ) )
				draw.RoundedBox( 0, 1, 1, w - 2, h - 2, gcol )
				
				surface.SetDrawColor( Color( 31, 191, 255, 255 ) )
				surface.DrawLine( 1, 1, w - 1, 1 )
				surface.DrawLine( 1, 1, 1, 30 )
				surface.DrawLine( 1, 28, w - 1, 28 )
				surface.DrawLine( w - 2, 1, w - 2, 30 )
			end
			placebut.OnCursorEntered = function( self )
				self.hover = true
			end
			placebut.OnCursorExited = function( self )
				self.hover = false
			end
	placebut.DoClick = function()
		local n = player.GetAll()
		local h = false
		
		if pickedPlayer then
		if hms then
			local rw = tonumber(myText:GetValue())
			if type( rw ) == "number" then
				if rw <= LocalPlayer():getDarkRPVar( "money" ) then
					if rw >= HIT.MinimumHitPrice then
						local c = qp
				
						net.Start( "DaHit" )
							net.WriteFloat( rw )
							--net.WriteFloat( tm )
							net.WriteEntity( c )
							net.WriteEntity( LocalPlayer() )
							net.WriteEntity( hms )
						net.SendToServer()
						bg:Close()
					else
						chat.AddText( Color( 150, 150, 255, 255 ), "[HitmanX] ", Color( 252, 252, 252, 255 ), "The hit reward must be above $"..tostring(HIT.MinimumHitPrice).."!" )
					end
				else
					chat.AddText( Color( 150, 150, 255, 255 ), "[HitmanX] ", Color( 252, 252, 252, 255 ), "You cannot afford this!" )
				end
			else
				chat.AddText( Color( 150, 150, 255, 255 ), "[HitmanX] ", Color( 252, 252, 252, 255 ), "The hit reward must be a number!" )
			end
		else
			chat.AddText( Color( 150, 150, 255, 255 ), "[HitmanX] ", Color( 252, 252, 252, 255 ), "You must choose a hitman!" )
		end
		else
			chat.AddText( Color( 150, 150, 255, 255 ), "[HitmanX] ", Color( 252, 252, 252, 255 ), "You must choose a target!" )
		end
	end
	
end
usermessage.Hook( "PlaceHit", ChooseHit )

local function CannotPlace()
	chat.AddText( Color( 150, 150, 255, 255 ), "[HitmanX] ", Color( 252, 252, 252, 255 ), "You cannot place hits as a hitman!" )
end
usermessage.Hook( "CannotPlace", CannotPlace )

local function TargLeft()
	chat.AddText( Color( 150, 150, 255, 255 ), "[HitmanX] ", Color( 252, 252, 252, 255 ), "Your contract target has left the game and your hit has been canceled." )
end
usermessage.Hook( "TargLeft", TargLeft )

local function NoHitmen()
	chat.AddText( Color( 150, 150, 255, 255 ), "[HitmanX] ", Color( 252, 252, 252, 255 ), "No hitmen currently online!" )
end
usermessage.Hook( "NoHitmen", NoHitmen )


local function AnnounceHit( data )
	local v = data:ReadEntity()
	chat.AddText( Color( 150, 150, 255, 255 ), "[HitmanX] ", Color( 252, 252, 252, 255 ), "Contract kill on "..v:Name().." completed." )
end
usermessage.Hook( "AnnounceHit", AnnounceHit )

local function HitmanDied( data )
	local v = data:ReadEntity()
	chat.AddText( Color( 150, 150, 255, 255 ), "[HitmanX] ", Color( 252, 252, 252, 255 ), v:Name().." has died, thus, the hit has been cancelled." )
end
usermessage.Hook( "HitmanDied", HitmanDied )

local function HitmanChanged( data )
	local v = data:ReadEntity()
	chat.AddText( Color( 150, 150, 255, 255 ), "[HitmanX] ", Color( 252, 252, 252, 255 ), v:Name().." has changed jobs, thus, the hit has been cancelled." )
end
usermessage.Hook( "HitmanChanged", HitmanChanged )