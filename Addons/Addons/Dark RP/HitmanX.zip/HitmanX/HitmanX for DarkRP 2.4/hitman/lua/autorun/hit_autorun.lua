MsgN("Initializing HitmanX by Wolf Haley")

HIT = {}

if SERVER then
	AddCSLuaFile("cl_hit.lua")
	include("sv_hit.lua" )
else
	include( "cl_hit.lua" )
end

HIT = {}

//Time before player can place another hit
HIT.HitCooldown = 1

//Minimum price of a hit
HIT.MinimumHitPrice = 400

HIT.HitmanTeams = {"Hitman"}