	concommand.Add("ATM_Save",function(ply,cmd,args)
		if ply:GetNWString("usergroup") != "owner" then return end
		
		MsgN("ATM - Saving all ATMs")
		local TB2Save = {}
		for k,v in pairs(ents.FindByClass("realistic_atm")) do
			local TB2Insert = {}
			TB2Insert.Pos = v:GetPos()
			TB2Insert.Angle = v:GetAngles()
			table.insert(TB2Save,TB2Insert)
		end
		
		local Map = string.lower(game.GetMap())
		file.Write("realistic_atm/mapsave/" .. Map .. ".txt", util.TableToJSON(TB2Save))
	end)
	
	hook.Add( "InitPostEntity", "ATM Entity Post", function()
	local Map = string.lower(game.GetMap())
		local Data = {}
		if file.Exists( "realistic_atm/mapsave/" .. Map .. ".txt" ,"DATA") then
			Data = util.JSONToTable(file.Read( "realistic_atm/mapsave/" .. Map .. ".txt" ))
		end
		MsgN("ATM - Spawning all ATMs")
		for k,v in pairs(Data) do
			local ATM = ents.Create("realistic_atm")
			ATM:SetPos(v.Pos)
			ATM:SetAngles(v.Angle)
			ATM:Spawn()
		end
		MsgN("ATM - Spawning Complete. [ " .. #Data .. " ] ")
	end )