ATM_Adjust = {}
	-- Gamemode code.
		-- DarkRP : 1
ATM_Adjust.Gamemode = 1

-- Every 'Interrest Time' Passed. Interest will be added every bank account.
	-- Set the Time ( Second )
		ATM_Adjust.Interest_Time = 1800 -- 1800 means. 1800 seconds. ( 30 minutes ) 

ATM_Adjust.Interest_Percent_Online = 0.1 -- Gives 0.5% of Interest for Online players.
ATM_Adjust.Interest_Percent_Offline = 0 -- Gives 0.1% of Interest for Offline players. ( Set to 0 if you dont want to give any interest.. )

