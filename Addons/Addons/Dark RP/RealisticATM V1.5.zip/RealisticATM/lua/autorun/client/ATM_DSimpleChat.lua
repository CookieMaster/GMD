local PANEL = {}

function PANEL:Init()
	self.Scroll = 0
	self.ScrollData = {Time = 1,Direction = 1}
	
	self.ChatListTable = {}
	self.TextCol = Color(255,255,255,255)
	self.Font = "BudgetLabel"
	self.NextSpace = 5
end

function PANEL:SetBGColor(col)
	self.BGCol = col
end

function PANEL:SetTextColor(col)
	self.TextCol = col
end
function PANEL:SetLeftSpace(space)
	self.NextSpace = space
end
function PANEL:Paint()
	if self.BGCol then
		surface.SetDrawColor(self.BGCol)
		surface.DrawRect(0,0,self:GetWide(),self:GetTall())
	end
	if self.BGPaint then
		self.BGPaint(self)
	end
			local MaxTextY = (self:GetTall()/20)
			for k,v in pairs(self.ChatListTable) do
				if k >= self.Scroll and k <= self.Scroll+MaxTextY +1 then
					v.X = v.X or 0
					surface.SetFont("BudgetLabel")
					local Width, Height = surface.GetTextSize(tostring(v.txt))
					
					local count = k-self.Scroll
					local TextAlpha = 255
					
					if count < 1 then
						TextAlpha = (count-0.5)*510
					end
					if count > ((self):GetTall()/20) then
						TextAlpha = (((self):GetTall()/20)-count+0.5)*510
					end
					
					v.X = Lerp(0.1,v.X,Width*(TextAlpha/255))

					draw.SimpleText(tostring(v.txt), self.Font, 5+self.NextSpace+v.X - Width,20*count, self.TextCol, TEXT_ALIGN_LEFT,TEXT_ALIGN_TOP)
				end
			end
end

function PANEL:Think()
		if self.ScrollData.Time > 0 then
			local Speed = FrameTime()*self.ScrollData.Time*3
			self.Scroll = self.Scroll + Speed*self.ScrollData.Direction
			self.ScrollData.Time = self.ScrollData.Time - Speed
		end
			if #self.ChatListTable <= ((self):GetTall()/20) then
				self.Scroll = 0
			else
				if self.Scroll+((self):GetTall()/20) > #(self.ChatListTable) then
					self.Scroll = #(self.ChatListTable) -((self):GetTall()/20)
					self.ScrollData.Time = 0
				end
			end
			if self.Scroll < 0 then 
				self.Scroll = 0
				self.ScrollData.Time = 0
			end
end
	
function PANEL:OnMouseWheeled(delta)
		local dir = -1
			if delta < 0 then
				dir = 1
			end
		self.ScrollData = {Time = self.ScrollData.Time + 1,Direction = dir}
end


function PANEL:AddChat(text)

	surface.SetFont("BudgetLabel")
	local Width, Height = surface.GetTextSize(tostring(text))

	local WrappedStr = String_Wrap(text,self:GetWide()-10 - (self.NextSpace*2),self.Font)
	
		for k,v in pairs(WrappedStr) do
			table.insert(self.ChatListTable,{txt = v})
			
			self.ScrollData = {Time = self.ScrollData.Time+1,Direction = 1}
		end
	
end

vgui.Register("DSimpleChat",PANEL,"Panel")