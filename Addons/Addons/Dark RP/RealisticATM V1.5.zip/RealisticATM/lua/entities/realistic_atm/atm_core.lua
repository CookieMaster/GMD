local meta = FindMetaTable("Player");

function meta:GetPlayerMoneyM()
	if ATM_Adjust.Gamemode == 1 then -- 1 for DarkRP
		return self:getDarkRPVar("money")
	end
end
if SERVER then
	function meta:AddPlayerMoneyM(int)
		if ATM_Adjust.Gamemode == 1 then  -- 1 for DarkRP
			self:addMoney(int)
		end
	end
	function meta:ATM_Notify(text)
		if ATM_Adjust.Gamemode == 1 then  -- 1 for DarkRP
			DarkRP.notify(self, 1, 4, text)
		end
	end
end

-- 
if CLIENT then
local AuctionDB = {}

	net.Receive( "OpenATMPanel_S2C", function( len )
			OpenBankPanel(Ent)
	end)
	net.Receive( "GenerateBankbookNum_R_S2C", function( len )
		local DATA = net.ReadTable().Num
		if ATMPanel and ATMPanel:IsValid() and ATMPanel.AccountNumGener and ATMPanel.AccountNumGener:IsValid() then
			ATMPanel.AccountNumGener:SetGenedNum(DATA)
		end
	end)
	net.Receive( "ATM_Verify_R_S2C", function( len )
		local DATA = net.ReadTable()
		if ATMPanel and ATMPanel:IsValid() then
			ATMPanel:Verify(DATA)
		end
	end)
	net.Receive( "ATM_DEP_Verify_R_S2C", function( len )
		local DATA = net.ReadTable()
		if ATMPanel and ATMPanel:IsValid() and ATMPanel.DepositBG and ATMPanel.DepositBG:IsValid() then
			ATMPanel.DepositBG:VerifyTargetAccount(DATA)
		end
	end)
	net.Receive( "ATM_CL_Verify_R_S2C", function( len )
		local DATA = net.ReadTable().Amount
		if ATMPanel and ATMPanel:IsValid() and ATMPanel.WithDrawBG and ATMPanel.WithDrawBG:IsValid() then
			ATMPanel.WithDrawBG:VerifyCashLeft(DATA)
		end
	end)
	

function OpenBankPanel()
	if ATMPanel and ATMPanel:IsValid() then
		ATMPanel:Remove()
	end
	ATMPanel = vgui.Create("BankPanel")
	ATMPanel:SetSize(ScrW()*0.95,ScrH()*0.9)
	ATMPanel:Center()
	ATMPanel:Install()
	ATMPanel:MakePopup()
	
end



net.Receive( "BankChat_S2C", function( len )
	local DATA = net.ReadTable()

	if ATMPanel and ATMPanel:IsValid() then
		ATMPanel.DebugChat:AddChat(DATA.t)
	
	end
end)

net.Receive( "MyBankBookData_S2C", function( len )
	local AuctionDB = net.ReadTable()
	if ATMPanel and ATMPanel:IsValid() then	
		ATMPanel:UpdateMyBankBookDB(AuctionDB)
	end
end)


local PANEL = {}
PANEL.Page = 1
PANEL.Filter = nil

PANEL.Delay = CurTime()
PANEL.Filter = "all"
PANEL.ListType = "auction"
PANEL.RequestDelay = CurTime()
PANEL.ClickDelay = CurTime()
PANEL.Text11 = " "
PANEL.MaxPage = 1


function PANEL:Verify(DATA)
	self.Verified = DATA
	self.DebugChat:AddChat("Verifing Complete.")
	self.DebugChat:AddChat("Account Number : " .. DATA.Num)
	self.DebugChat:AddChat("Account Name : " .. DATA.Name)
end

function PANEL:Init()
	self:ShowCloseButton(false)
	self:SetTitle(" ")
	
end

function PANEL:Install()
	local CloseButton = vgui.Create("ATM_DSWButton",self)
		CloseButton:SetSize(100,20)
		CloseButton:SetPos(self:GetWide()-110,5)
		CloseButton:SetTexts("Close")
		CloseButton.Click = function(slf)
			self:Remove()
			GAMEMODE.QuestPanel = nil
	--		OpenBankPanel()
		end

			
			
			local Buttons = {}
				table.insert(Buttons,{PrintName = "Create Account", Exec = function(mainp) mainp:CreateAccount() end })
				table.insert(Buttons,{PrintName = "Login", Exec = function(mainp) mainp:VerifyAccount() end })
				table.insert(Buttons,{PrintName = "Check Statement", Exec = function(mainp) mainp:CheckBankBook() end })
				table.insert(Buttons,{PrintName = "Withdraw Money", Exec = function(mainp) mainp:WithdrawalMONEY() end })
				table.insert(Buttons,{PrintName = "Deposit Money", Exec = function(mainp) mainp:DepositMONEY() end })
				table.insert(Buttons,{PrintName = "Transfer Money", Exec = function(mainp) mainp:MoneyTransfer() end })
				
				
				
			
		for k=1,#Buttons do
				local FilterButton = vgui.Create( "ATM_DSWButton", self)
					FilterButton:SetPos(20,50*k)
					FilterButton:SetTexts(Buttons[k].PrintName)
					FilterButton:SetSize(180,40)
					
					FilterButton.Click = function(slf)
						Buttons[k].Exec(self)
					end
		end

		
		
		
	self.List = vgui.Create( "DPanelList", self )
	self.List:SetPos( 220,40 )
	self.List:SetSize( self:GetWide()-230, self:GetTall()-210 )
	self.List:SetSpacing( 0 ) -- Spacing between items
	self.List:EnableHorizontal( false ) -- Only vertical items
	self.List:EnableVerticalScrollbar( true ) -- Allow scrollbar if you exceed the Y axis
	self.List:PaintListBar() -- Allow scrollbar if you exceed the Y axis

	self.DebugChat = vgui.Create("DSimpleChat",self )
	self.DebugChat:SetPos( 220,80 + self:GetTall()-240 )
	self.DebugChat:SetSize( self:GetWide()-230 - 250, 140 )
	self.DebugChat:SetLeftSpace(5)
	self.DebugChat.BGPaint = function(slf)
			surface.SetDrawColor( 0,10,30,120 )
			surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
										
			surface.SetDrawColor( 0,150,255,255 )
			surface.DrawRect( 0, 0, slf:GetWide(), 1 )
			surface.DrawRect( 0, 0, 1, slf:GetTall() )
			surface.DrawRect( slf:GetWide()-1, 0, 1, slf:GetTall() )
			surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
	end
	
	self.Panel5 = vgui.Create( "DPanel" , self)
	self.Panel5:SetPos(self:GetWide()-250,80 + self:GetTall()-240)
	self.Panel5:SetSize(240,140)
	self.Panel5.Paint = function(slf)
		draw.RoundedBox(4, 0, 0, slf:GetWide(), slf:GetTall(), Color(0,150,255,255))
		draw.RoundedBox(4, 1, 1, slf:GetWide()-2, slf:GetTall()-2, Color(0,0,0,255))
		
		if self.Verified then
			draw.SimpleText("Account Verified", "Kostar_S15", 10, 10, Color(0, 150, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(self.Verified.Num, "Kostar_S15", 10, 30, Color(0, 150, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(self.Verified.Name, "Kostar_S15", 10, 50, Color(0, 150, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		
		draw.SimpleText("You have ", "KostarOut_S20", 10, slf:GetTall()-40, Color(0, 150, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(string.Comma(LocalPlayer():GetPlayerMoneyM()) .. " cash", "KostarOut_S20", 10, slf:GetTall()-15, Color(0, 150, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	self.DebugChat:AddChat("ATM System Activated")
	
	self.Page = 1
end

function PANEL:Paint()
		draw.RoundedBox(1, 0, 0, self:GetWide(), self:GetTall(), Color(0,0,0,240))
		draw.RoundedBox(0, 0, 0, self:GetWide(), 1, Color(0,150,255,255))
		draw.RoundedBox(0, 0, 0, 1, self:GetTall(), Color(0,150,255,255))
		
		draw.RoundedBox(0, self:GetWide()-1, 0, 1, self:GetTall(), Color(0,150,255,255))
		draw.RoundedBox(0, 0, self:GetTall()-1, self:GetWide(), 1, Color(0,150,255,255))
		
		draw.SimpleText("ATM", "Jupiter_S20", 30, 17 , Color(0,150,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

			
		draw.RoundedBox(0, 210, 40,1, self:GetTall()-60, Color(0,150,255,255))
end

function PANEL:CheckBankBook()
	if !self.Verified then
		self.DebugChat:AddChat("You need to log into your account first!" )
		return
	end
	
	net.Start( "MyBankBook_C2S" )
		net.WriteTable( {Num=self.Verified.Num,Page=1} )
	net.SendToServer()
end
function PANEL:VerifyAccount()
	self.List:Clear()
	
	local List = self.List
	
	self.TopLabel = vgui.Create( "DPanel")
	self.TopLabel:SetPos(2,2)
	self.TopLabel:SetSize( List:GetWide(),40 )
	self.TopLabel.Paint = function(slf)
			surface.SetDrawColor( 0,255,255,120 )
			surface.DrawRect( 1, 39, slf:GetWide()-2, 1 )
		draw.SimpleText("Access to Your Account", "SansationOut_S35", 20,20, Color(0,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	List:AddItem(self.TopLabel)
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		draw.SimpleText("Enter your Account Number ( including '-' )  ( ex. 1234-1234 )", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 200, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
	end

	local DTextEntry_NUM = vgui.Create("DTextEntry",BG)
		DTextEntry_NUM:SetText("")
		DTextEntry_NUM:SetPos(20,35)
		DTextEntry_NUM:SetSize(350,30)
		DTextEntry_NUM:SetAllowNonAsciiCharacters(true)
		DTextEntry_NUM:SetTextColor(Color(0,255,255,255))
	
		DTextEntry_NUM:SetDrawBackground(false)
		DTextEntry_NUM:SetCursorColor(Color(200,200,200,255))
		DTextEntry_NUM.OnTextChanged = function(slf)
		
			if string.len(slf:GetValue()) > 9 or string.len(slf:GetValue()) < 9 then
				slf:SetTextColor(Color(255,0,0,255))
			else
				slf:SetTextColor(Color(0,255,255,255))
			end
		
		end
		
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		draw.SimpleText("Type your Password", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 200, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
	end

	local DTextEntry_PW = vgui.Create("DTextEntry",BG)
		DTextEntry_PW:SetText("")
		DTextEntry_PW:SetPos(20,35)
		DTextEntry_PW:SetSize(350,30)
		DTextEntry_PW:SetAllowNonAsciiCharacters(true)
		DTextEntry_PW:SetTextColor(Color(0,255,255,255))
	
		DTextEntry_PW:SetDrawBackground(false)
		DTextEntry_PW:SetCursorColor(Color(200,200,200,255))
		DTextEntry_PW.OnTextChanged = function(slf)
		end
		
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		if string.len(DTextEntry_NUM:GetValue()) > 9 or string.len(DTextEntry_NUM:GetValue()) < 9 then
			draw.SimpleText("That account number is invalid.", "Kostar_S17", 30,10, Color(255,50,0,255))
			return
		end
		
		draw.SimpleText("Account number verified!", "Kostar_S17", 30,10, Color(0,255,0,255))
		
	end
	List:AddItem(BG)
	
	local DSButton = vgui.Create("ATM_DSWButton",BG)
		DSButton:SetTexts("Login")
		DSButton:SetPos(BG:GetWide()-150,35)
		DSButton:SetSize(140,30)
		DSButton.DoClick = function(slf)
			if string.len(DTextEntry_NUM:GetValue()) > 9 or string.len(DTextEntry_NUM:GetValue()) < 9 then
				return
			end
			net.Start("ATM_Verify_C2S")
				net.WriteTable({Num=DTextEntry_NUM:GetValue(),Password=DTextEntry_PW:GetValue()})
			net.SendToServer()
		end
	//============================= Text Entry =====================//
end
function PANEL:UpdateMyBankBookDB(DB)
	self.List:Clear()
	
	local List = self.List
	local CurPage = DB.CurPage
	local MaxPage = math.max(1,math.ceil(DB.LogAmount/30))
	
	self.TopLabel = vgui.Create( "DPanel")
	self.TopLabel:SetPos(2,2)
	self.TopLabel:SetSize( List:GetWide(),40 )
	self.TopLabel.Paint = function(slf)
			surface.SetDrawColor( 0,255,255,120 )
			surface.DrawRect( 1, 39, slf:GetWide()-2, 1 )
		draw.SimpleText("My BankBook", "SansationOut_S35", 20,20, Color(0,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("Page = " .. CurPage .. " / " .. MaxPage, "SansationOut_S20", slf:GetWide()-190,20, Color(0,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	List:AddItem(self.TopLabel)
	

		local Page_Up = vgui.Create( "ATM_DSWButton", self.TopLabel)
			Page_Up:SetPos(self.TopLabel:GetWide()-250,7)
			Page_Up:SetTexts("-")
			Page_Up:SetSize(30,25)
			Page_Up.Click = function()
				if CurPage > 1 then 
					net.Start( "MyBankBook_C2S" )
						net.WriteTable( {Num=self.Verified.Num,Page=CurPage-1} )
					net.SendToServer()
				end
			end
		
		local Page_Down = vgui.Create( "ATM_DSWButton", self.TopLabel)
			Page_Down:SetPos(self.TopLabel:GetWide()-60,7)
			Page_Down:SetTexts("+")
			Page_Down:SetSize(30,25)
			Page_Down.Click = function()
				if CurPage >= MaxPage then return end
					net.Start( "MyBankBook_C2S" )
						net.WriteTable( {Num=self.Verified.Num,Page=CurPage+1} )
					net.SendToServer()
			end
	
	
	self.DebugChat:AddChat("Reciving Bankbook Data.." )
	self.DebugChat:AddChat("Trading Log Amount " .. " : " .. DB.LogAmount)
	self.DebugChat:AddChat("Cash Balance : " .. DB.CurMoney)
	self.CurMoney = DB.CurMoney
		local count = 0
		
					local SButton = vgui.Create( "DButton")
						SButton:SetPos(0,0)
						SButton:SetText(" ")
						SButton.Count = count
						SButton:SetSize(self.List:GetWide()-20,20)
						SButton.OnCursorEntered = function(slf) slf.Hover = true end
						SButton.OnCursorExited = function(slf) slf.Hover = false end
						
						SButton.Paint = function(slf)
							local Col = 20+((slf.Count%2)*5)
															
							surface.SetDrawColor( 255,255,255,80 )
							surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
															
							draw.SimpleText("No.", "KostarOut_S15", 10, 3, Color(0,150,255,255))
							draw.SimpleText("Memo", "KostarOut_S15", slf:GetWide()/6*1, 3, Color(0,150,255,255))
							
								draw.SimpleText("Income", "KostarOut_S15", slf:GetWide()/6*2, 3, Color(0,150,255,255))
								draw.SimpleText("Outgoing", "KostarOut_S15", slf:GetWide()/6*3, 3, Color(0,150,255,255))
								draw.SimpleText("Ending Balance", "KostarOut_S15", slf:GetWide()/6*4, 3, Color(0,150,255,255))
							
							draw.SimpleText("Time", "KostarOut_S15", slf:GetWide()/6*5, 3, Color(0,150,255,255))
						end -- Paint End
					self.List:AddItem(SButton)
		
			for Num,DataBase in pairs(DB.Log or {}) do
				count = count + 1
					local SButton = vgui.Create( "DButton")
						SButton:SetPos(0,0)
						SButton:SetText(" ")
						SButton.Count = count
						SButton:SetSize(self.List:GetWide()-20,40)
						SButton.OnCursorEntered = function(slf) slf.Hover = true end
						SButton.OnCursorExited = function(slf) slf.Hover = false end
						
						SButton.Paint = function(slf)
															
							surface.SetDrawColor( 255,255,255,30 )
							surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
							
							draw.SimpleText(DataBase.Count, "KostarOut_S15", 10, 7, Color(0,150,255,255))
							draw.SimpleText(DataBase.Memo, "KostarOut_S15", slf:GetWide()/6*1, 7, Color(0,150,255,255))
							
							if DataBase.Plus then
								draw.SimpleText(string.Comma(DataBase.Plus), "KostarOut_S15", slf:GetWide()/6*2, 7, Color(0,150,255,255))
							end
							if DataBase.Sub then
								draw.SimpleText(string.Comma(DataBase.Sub), "KostarOut_S15", slf:GetWide()/6*3, 7, Color(0,150,255,255))
							end
							draw.SimpleText(string.Comma(DataBase.MoneyLeft), "KostarOut_S15", slf:GetWide()/6*4, 7, Color(0,150,255,255))
							
							draw.SimpleText(DataBase.Day, "KostarOut_S15", slf:GetWide()/6*5, 7, Color(0,150,255,255))
							draw.SimpleText(DataBase.Time, "KostarOut_S15", slf:GetWide()/6*5, 25, Color(0,150,255,255))
						end -- Paint End

						
				self.List:AddItem(SButton)
			end
end



function PANEL:CreateAccount()
	self.List:Clear()
	local List = self.List
	
	self.TopLabel = vgui.Create( "DPanel")
	self.TopLabel:SetPos(2,2)
	self.TopLabel:SetSize( List:GetWide(),40 )
	self.TopLabel.Paint = function(slf)
			surface.SetDrawColor( 0,255,255,120 )
			surface.DrawRect( 1, 39, slf:GetWide()-2, 1 )
		draw.SimpleText("Bank Account Creation", "SansationOut_S35", 20,20, Color(0,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	List:AddItem(self.TopLabel)
	
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel") self.AccountNumGener = BG
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		draw.SimpleText("Generate your unique account number. (DO NOT forget this! You will lose all money in the account!)", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 200, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 200, 1 )
		
		if slf.GendNum then
			draw.SimpleText(slf.GendNum, "SansationOut_S20", 50,40, Color(0,255,255,255), TEXT_ALIGN_LEFT)
		end
	end
	function BG:SetGenedNum(Data)
		self.GendNum = Data
	end
	List:AddItem(BG)
	
	local DSButton = vgui.Create("ATM_DSWButton",BG)
		DSButton:SetTexts("Generate")
		DSButton:SetPos(BG:GetWide()-150,35)
		DSButton:SetSize(140,30)
		DSButton.DoClick = function(slf)
			net.Start("GenerateBankbookNum_C2S")
			net.SendToServer()
		end
	//============================= Text Entry =====================//
	
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		draw.SimpleText("Enter an account name. (You can't change this. Others will recognize you better if you use your RPName. )", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 200, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
	end

	local DTextEntry_ID = vgui.Create("DTextEntry",BG)
		DTextEntry_ID:SetText("")
		DTextEntry_ID:SetPos(20,35)
		DTextEntry_ID:SetSize(350,30)
		DTextEntry_ID:SetAllowNonAsciiCharacters(true)
		DTextEntry_ID:SetTextColor(Color(0,255,255,255))
	
		DTextEntry_ID:SetDrawBackground(false)
		DTextEntry_ID:SetCursorColor(Color(200,200,200,255))
		DTextEntry_ID.OnTextChanged = function(slf)
		
			if string.len(slf:GetValue()) > 100 then
				slf:SetTextColor(Color(255,0,0,255))
			else
				slf:SetTextColor(Color(0,255,255,255))
			end
		
		end
		
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		draw.SimpleText("Enter a Password (DO NOT forget this! You will lose all money in the account!)", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 200, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
	end

	local DTextEntry_PW = vgui.Create("DTextEntry",BG)
		DTextEntry_PW:SetText("")
		DTextEntry_PW:SetPos(20,35)
		DTextEntry_PW:SetSize(350,30)
		DTextEntry_PW:SetAllowNonAsciiCharacters(false)
		DTextEntry_PW:SetTextColor(Color(0,255,255,255))
	
		DTextEntry_PW:SetDrawBackground(false)
		DTextEntry_PW:SetCursorColor(Color(200,200,200,255))
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		if !self.AccountNumGener.GendNum then
			draw.SimpleText("Generate An Account Number", "Kostar_S17", 30,10, Color(255,50,0,255))
			return
		end
		if string.len(DTextEntry_ID:GetValue()) > 25 then
			draw.SimpleText("That account name is too long!", "Kostar_S17", 30,10, Color(255,50,0,255))
			return
		end
		if string.len(DTextEntry_ID:GetValue()) < 4 then
			draw.SimpleText("It is recommended that you make a longer account name.", "Kostar_S17", 30,10, Color(255,255,0,255))
			return
		end
		if string.len(DTextEntry_PW:GetValue()) < 5 then
			draw.SimpleText("It is recommended that you make a more secure password.", "Kostar_S17", 30,10, Color(255,255,0,255))
			return
		end
		
		draw.SimpleText("Strong user name and password! Create your account! |REMEMBER YOUR ACCOUNT NUMBER AND PASSWORD!|", "Kostar_S17", 30,10, Color(0,255,0,255))
		
	end
	List:AddItem(BG)
	
	local DSButton = vgui.Create("ATM_DSWButton",BG)
		DSButton:SetTexts("Create Account")
		DSButton:SetPos(BG:GetWide()-150,35)
		DSButton:SetSize(140,30)
		DSButton.DoClick = function(slf)
			if !self.AccountNumGener.GendNum then return end
			if string.len(DTextEntry_ID:GetValue()) > 100 then return end
			
			net.Start("ATM_CreateAccount_C2S")
				net.WriteTable({Num=self.AccountNumGener.GendNum,Name=DTextEntry_ID:GetValue(),Password=DTextEntry_PW:GetValue()})
			net.SendToServer()
		end
	//============================= Text Entry =====================//
	
end



function PANEL:DepositMONEY()
	self.List:Clear()
	local List = self.List
	
	self.TopLabel = vgui.Create( "DPanel")
	self.TopLabel:SetPos(2,2)
	self.TopLabel:SetSize( List:GetWide(),40 )
	self.TopLabel.Paint = function(slf)
			surface.SetDrawColor( 0,255,255,120 )
			surface.DrawRect( 1, 39, slf:GetWide()-2, 1 )
		draw.SimpleText("Deposit Money To Account", "SansationOut_S35", 20,20, Color(0,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	List:AddItem(self.TopLabel)

	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel") self.DepositBG = BG
	BG:SetSize(List:GetWide(),100)
	BG.VerifiedData = {}
	BG.Paint = function(slf)
		draw.SimpleText("Type the account number you wish to deposit to ( including '-' )  ( ex. 1234-1234 )", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 200, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
		
		if slf.VerifiedData and slf.VerifiedData.Name then
			draw.SimpleText("Account Verified. ( Name : " .. slf.VerifiedData.Name .. " ) ", "Kostar_S17", slf:GetWide()-10,40, Color(0,200,0,255),TEXT_ALIGN_RIGHT)
		end
	end
	function BG:VerifyTargetAccount(DATA)
		self.VerifiedData = DATA
		self.VerifyChecker:SetVisible(false)
	end
	
	local DSButton = vgui.Create("ATM_DSWButton",BG) BG.VerifyChecker = DSButton
		DSButton:SetTexts("Verify")
		DSButton:SetPos(BG:GetWide()-150,35)
		DSButton:SetSize(140,30)
		DSButton.DoClick = function(slf)
			if string.len(BG.NumEntry:GetValue()) > 9 or string.len(BG.NumEntry:GetValue()) < 9 then
				return
			end
			net.Start("ATM_DEP_Verify_C2S")
				net.WriteTable({Num=BG.NumEntry:GetValue()})
			net.SendToServer()
		end

	local DTextEntry_NUM = vgui.Create("DTextEntry",BG) BG.NumEntry = DTextEntry_NUM
		DTextEntry_NUM:SetText("")
		DTextEntry_NUM:SetPos(20,35)
		DTextEntry_NUM:SetSize(350,30)
		DTextEntry_NUM:SetAllowNonAsciiCharacters(true)
		DTextEntry_NUM:SetTextColor(Color(0,255,255,255))
	
		DTextEntry_NUM:SetDrawBackground(false)
		DTextEntry_NUM:SetCursorColor(Color(200,200,200,255))
		DTextEntry_NUM.OnTextChanged = function(slf)
			BG.VerifyChecker:SetVisible(true)
			BG.VerifiedData = {}
			if string.len(slf:GetValue()) > 9 or string.len(slf:GetValue()) < 9 then
				slf:SetTextColor(Color(255,0,0,255))
			else
				slf:SetTextColor(Color(0,255,255,255))
			end
		
		end
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		draw.SimpleText("How much money do you wish to deposit?", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 200, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
	end
		
			local Wang = vgui.Create( "DNumberWang", BG )
			Wang:SetPos(20,35)
			Wang:SetSize(350,30)
			Wang:SetValue( LocalPlayer():GetPlayerMoneyM() )
			Wang:SetMax( LocalPlayer():GetPlayerMoneyM() )
			Wang:SetDecimals( 0 )
			Wang:SetAlpha(255)
			Wang:SetTextColor(Color(0,150,255,255))
			Wang:SetDrawBackground(false)
			Wang:SetCursorColor(Color(0,150,255,255))
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		draw.SimpleText("Add a memo.", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 200, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
	end

	local DTextEntry_MEMO = vgui.Create("DTextEntry",BG)
		DTextEntry_MEMO:SetText("")
		DTextEntry_MEMO:SetPos(20,35)
		DTextEntry_MEMO:SetSize(350,30)
		DTextEntry_MEMO:SetAllowNonAsciiCharacters(true)
		DTextEntry_MEMO:SetTextColor(Color(0,255,255,255))
	
		DTextEntry_MEMO:SetDrawBackground(false)
		DTextEntry_MEMO:SetCursorColor(Color(200,200,200,255))
		DTextEntry_MEMO.OnTextChanged = function(slf)
			if string.len(slf:GetValue()) > 20 then
				slf:SetTextColor(Color(255,0,0,255))
			else
				slf:SetTextColor(Color(0,255,255,255))
			end
		end
		
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		if !self.DepositBG.VerifiedData.Num then
			draw.SimpleText("Verify Target Account", "Kostar_S17", 30,10, Color(255,50,0,255))
			return
		end
		if math.Round(Wang:GetValue()) < 1 then
			draw.SimpleText("Type Right Money to deposit. ( at least 1 )", "Kostar_S17", 30,10, Color(255,50,0,255))
			return
		end
		if math.Round(Wang:GetValue()) > LocalPlayer():GetPlayerMoneyM() then
			draw.SimpleText("Not Enough Money", "Kostar_S17", 30,10, Color(255,50,0,255))
			return
		end
		
		draw.SimpleText("You are Ready to go!", "Kostar_S17", 30,10, Color(0,255,0,255))
		
	end
	List:AddItem(BG)
	
	local DSButton = vgui.Create("ATM_DSWButton",BG)
		DSButton:SetTexts("Deposit Money")
		DSButton:SetPos(BG:GetWide()-150,35)
		DSButton:SetSize(140,30)
		DSButton.DoClick = function(slf)
			if !self.DepositBG.VerifiedData.Num then return end
			if math.Round(Wang:GetValue()) < 1 then return end
			if string.len(DTextEntry_MEMO:GetValue()) > 20 then return end
			if math.Round(Wang:GetValue()) > LocalPlayer():GetPlayerMoneyM() then return end
			
			net.Start("ATM_DepositMoney_C2S")
				net.WriteTable({Memo = DTextEntry_MEMO:GetValue(),Num=self.DepositBG.VerifiedData.Num,Amount=math.Round(Wang:GetValue())})
			net.SendToServer()
		end
	//============================= Text Entry =====================//
	
end


function PANEL:WithdrawalMONEY()
	if !self.Verified then
		self.DebugChat:AddChat("You have to log into your account first!" )
		return
	end
	
	self.List:Clear()
	local List = self.List
	
	self.TopLabel = vgui.Create( "DPanel")
	self.TopLabel:SetPos(2,2)
	self.TopLabel:SetSize( List:GetWide(),40 )
	self.TopLabel.Paint = function(slf)
			surface.SetDrawColor( 0,255,255,120 )
			surface.DrawRect( 1, 39, slf:GetWide()-2, 1 )
		draw.SimpleText("Withdraw Money From Account", "SansationOut_S35", 20,20, Color(0,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	List:AddItem(self.TopLabel)

	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel") self.WithDrawBG = BG
	BG:SetSize(List:GetWide(),100)
	BG.VerifiedCash = nil
	BG.Paint = function(slf)
		draw.SimpleText("Check your account how much money in there", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 350, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
		
		if slf.VerifiedCash then
			draw.SimpleText("Cash Verified. ( " .. string.Comma(slf.VerifiedCash) .. " ) ", "Kostar_S17", 30,40, Color(0,200,0,255))
		end
	end
	function BG:VerifyCashLeft(DATA)
		self.VerifiedCash = DATA
		if self.Wang then
			self.Wang:SetMax(DATA)
			self.Wang:SetValue(DATA)
		end
	end
	
	local DSButton = vgui.Create("ATM_DSWButton",BG) BG.VerifyChecker = DSButton
		DSButton:SetTexts("Check")
		DSButton:SetPos(BG:GetWide()-150,35)
		DSButton:SetSize(140,30)
		DSButton.DoClick = function(slf)
			net.Start("ATM_CL_Verify_C2S")
				net.WriteTable({Num=self.Verified.Num})
			net.SendToServer()
		end
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		draw.SimpleText("How much money do you want to withdraw?", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 200, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
	end
		
			local Wang = vgui.Create( "DNumberWang", BG ) BG.Wang = Wang
			Wang:SetPos(20,35)
			Wang:SetSize(350,30)
			Wang:SetValue( LocalPlayer():GetPlayerMoneyM() )
			Wang:SetMax( LocalPlayer():GetPlayerMoneyM() )
			Wang:SetDecimals( 0 )
			Wang:SetAlpha(255)
			Wang:SetTextColor(Color(0,150,255,255))
			Wang:SetDrawBackground(false)
			Wang:SetCursorColor(Color(0,150,255,255))
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		draw.SimpleText("You can add small memo.", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 200, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
	end

	local DTextEntry_MEMO = vgui.Create("DTextEntry",BG)
		DTextEntry_MEMO:SetText("")
		DTextEntry_MEMO:SetPos(20,35)
		DTextEntry_MEMO:SetSize(350,30)
		DTextEntry_MEMO:SetAllowNonAsciiCharacters(true)
		DTextEntry_MEMO:SetTextColor(Color(0,255,255,255))
	
		DTextEntry_MEMO:SetDrawBackground(false)
		DTextEntry_MEMO:SetCursorColor(Color(200,200,200,255))
		DTextEntry_MEMO.OnTextChanged = function(slf)
			if string.len(slf:GetValue()) > 20 then
				slf:SetTextColor(Color(255,0,0,255))
			else
				slf:SetTextColor(Color(0,255,255,255))
			end
		end
		
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		if !self.WithDrawBG.VerifiedCash then
			draw.SimpleText("Verify your balance.", "Kostar_S17", 30,10, Color(255,50,0,255))
			return
		end
		if math.Round(Wang:GetValue()) > self.WithDrawBG.VerifiedCash then
			draw.SimpleText("Insufficient Funds! CANNOT TRANSFER", "Kostar_S17", 30,10, Color(255,50,0,255))
			return
		end
		if math.Round(Wang:GetValue()) < 100 then
			draw.SimpleText("Enter an amount to withdraw. (At least $100.)", "Kostar_S17", 30,10, Color(255,50,0,255))
			return
		end
		draw.SimpleText("Account verified. You are ready to withdraw!", "Kostar_S17", 30,10, Color(0,255,0,255))
		
	end
	List:AddItem(BG)
	
	local DSButton = vgui.Create("ATM_DSWButton",BG)
		DSButton:SetTexts("Withdraw Money")
		DSButton:SetPos(BG:GetWide()-150,35)
		DSButton:SetSize(140,30)
		DSButton.DoClick = function(slf)
			if !self.WithDrawBG.VerifiedCash then return end
			if math.Round(Wang:GetValue()) < 1 then return end
			if string.len(DTextEntry_MEMO:GetValue()) > 20 then return end
			if math.Round(Wang:GetValue()) > self.WithDrawBG.VerifiedCash then return end
			net.Start("WithdrawalMoney_C2S")
				net.WriteTable({Memo = DTextEntry_MEMO:GetValue(),Num=self.Verified.Num,Amount=math.Round(Wang:GetValue())})
			net.SendToServer()
		end
	//============================= Text Entry =====================//
	
end

function PANEL:MoneyTransfer()
	if !self.Verified then
		self.DebugChat:AddChat("You have to log into your account first!" )
		return
	end
	
	self.List:Clear()
	local List = self.List
	
	self.TopLabel = vgui.Create( "DPanel")
	self.TopLabel:SetPos(2,2)
	self.TopLabel:SetSize( List:GetWide(),40 )
	self.TopLabel.Paint = function(slf)
			surface.SetDrawColor( 0,255,255,120 )
			surface.DrawRect( 1, 39, slf:GetWide()-2, 1 )
		draw.SimpleText("Transfer Your money to Others", "SansationOut_S35", 20,20, Color(0,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	List:AddItem(self.TopLabel)

	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel") self.DepositBG = BG
	BG:SetSize(List:GetWide(),100)
	BG.VerifiedData = {}
	BG.Paint = function(slf)
		draw.SimpleText("Type Recipient's Account Number ( including '-' )  ( ex. 1234-1234 )", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 200, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
		
		if slf.VerifiedData and slf.VerifiedData.Name then
			draw.SimpleText("Account Verified. ( Name : " .. slf.VerifiedData.Name .. " ) ", "Kostar_S17", slf:GetWide()-10,40, Color(0,200,0,255),TEXT_ALIGN_RIGHT)
		end
	end
	
	function BG:VerifyTargetAccount(DATA)
		self.VerifiedData = DATA
		self.VerifyChecker:SetVisible(false)
	end
	
	local DSButton = vgui.Create("ATM_DSWButton",BG) BG.VerifyChecker = DSButton
		DSButton:SetTexts("Verify")
		DSButton:SetPos(BG:GetWide()-150,35)
		DSButton:SetSize(140,30)
		DSButton.DoClick = function(slf)
			if string.len(BG.NumEntry:GetValue()) > 9 or string.len(BG.NumEntry:GetValue()) < 9 then
				return
			end
			if BG.NumEntry:GetValue() == self.Verified.Num then
				self.DebugChat:AddChat("You can't make a transfer to the account you are currently using!")
				return
			end
			net.Start("ATM_DEP_Verify_C2S")
				net.WriteTable({Num=BG.NumEntry:GetValue()})
			net.SendToServer()
		end

	local DTextEntry_NUM = vgui.Create("DTextEntry",BG) BG.NumEntry = DTextEntry_NUM
		DTextEntry_NUM:SetText("")
		DTextEntry_NUM:SetPos(20,35)
		DTextEntry_NUM:SetSize(350,30)
		DTextEntry_NUM:SetAllowNonAsciiCharacters(true)
		DTextEntry_NUM:SetTextColor(Color(0,255,255,255))
		DTextEntry_NUM:SetDrawBackground(false)
		DTextEntry_NUM:SetCursorColor(Color(200,200,200,255))
		DTextEntry_NUM.OnTextChanged = function(slf)
			BG.VerifyChecker:SetVisible(true)
			BG.VerifiedData = {}
			if string.len(slf:GetValue()) > 9 or string.len(slf:GetValue()) < 9 then
				slf:SetTextColor(Color(255,0,0,255))
			else
				slf:SetTextColor(Color(0,255,255,255))
			end
		
		end
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel") self.WithDrawBG = BG
	BG:SetSize(List:GetWide(),100)
	BG.VerifiedCash = nil
	BG.Paint = function(slf)
		draw.SimpleText("Verify that you have proper funding for a transfer.", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 350, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
		
		if slf.VerifiedCash then
			draw.SimpleText("Funds Verified. ( " .. string.Comma(slf.VerifiedCash) .. " ) ", "Kostar_S17", 30,40, Color(0,200,0,255))
		end
	end
	function BG:VerifyCashLeft(DATA)
		self.VerifiedCash = DATA
		if self.Wang then
			self.Wang:SetMax(DATA)
			self.Wang:SetValue(DATA)
		end
	end
	
	local DSButton = vgui.Create("ATM_DSWButton",BG) BG.VerifyChecker = DSButton
		DSButton:SetTexts("Check")
		DSButton:SetPos(BG:GetWide()-150,35)
		DSButton:SetSize(140,30)
		DSButton.DoClick = function(slf)
			net.Start("ATM_CL_Verify_C2S")
				net.WriteTable({Num=self.Verified.Num})
			net.SendToServer()
		end
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		draw.SimpleText("How much money do you wish to transfer?", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 200, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
	end
		
			local Wang = vgui.Create( "DNumberWang", BG ) BG.Wang = Wang
			Wang:SetPos(20,35)
			Wang:SetSize(350,30)
			Wang:SetValue( LocalPlayer():GetPlayerMoneyM() )
			Wang:SetMax( LocalPlayer():GetPlayerMoneyM() )
			Wang:SetDecimals( 0 )
			Wang:SetAlpha(255)
			Wang:SetTextColor(Color(0,150,255,255))
			Wang:SetDrawBackground(false)
			Wang:SetCursorColor(Color(0,150,255,255))
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		draw.SimpleText("Add a memo for the account sending the money. (Your account)", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 200, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
	end

	local DTextEntry_MEMO = vgui.Create("DTextEntry",BG)
		DTextEntry_MEMO:SetText("")
		DTextEntry_MEMO:SetPos(20,35)
		DTextEntry_MEMO:SetSize(350,30)
		DTextEntry_MEMO:SetAllowNonAsciiCharacters(true)
		DTextEntry_MEMO:SetTextColor(Color(0,255,255,255))
	
		DTextEntry_MEMO:SetDrawBackground(false)
		DTextEntry_MEMO:SetCursorColor(Color(200,200,200,255))
		DTextEntry_MEMO.OnTextChanged = function(slf)
			if string.len(slf:GetValue()) > 20 then
				slf:SetTextColor(Color(255,0,0,255))
			else
				slf:SetTextColor(Color(0,255,255,255))
			end
		end
		
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		draw.SimpleText("Add a memo for the account that is receiving the money.", "Kostar_S17", 30,10, Color(200,200,200,255))
		surface.SetDrawColor( 0,0,0,100 )
		surface.DrawRect( 20, 35, 200, 30 )
		
		surface.SetDrawColor( 200,200,200,100 )
		surface.DrawRect( 20, 64, 350, 1 )
	end

	local DTextEntry_MEMO_T = vgui.Create("DTextEntry",BG)
		DTextEntry_MEMO_T:SetText("")
		DTextEntry_MEMO_T:SetPos(20,35)
		DTextEntry_MEMO_T:SetSize(350,30)
		DTextEntry_MEMO_T:SetAllowNonAsciiCharacters(true)
		DTextEntry_MEMO_T:SetTextColor(Color(0,255,255,255))
		DTextEntry_MEMO_T:SetText("From " .. LocalPlayer():Nick())
		DTextEntry_MEMO_T:SetDrawBackground(false)
		DTextEntry_MEMO_T:SetCursorColor(Color(200,200,200,255))
		DTextEntry_MEMO_T.OnTextChanged = function(slf)
			if string.len(slf:GetValue()) > 20 then
				slf:SetTextColor(Color(255,0,0,255))
			else
				slf:SetTextColor(Color(0,255,255,255))
			end
		end
		
	
	List:AddItem(BG)
	//============================= Text Entry =====================//
	
	//============================= Text Entry =====================//
	local BG = vgui.Create("DPanel")
	BG:SetSize(List:GetWide(),100)
	BG.Paint = function(slf)
		if !self.DepositBG.VerifiedData.Num then
			draw.SimpleText("You can't transfer money to the account you are using!", "Kostar_S17", 30,10, Color(255,50,0,255))
			return
		end
		if !self.WithDrawBG.VerifiedCash then
			draw.SimpleText("Verify that you have the funds.", "Kostar_S17", 30,10, Color(255,50,0,255))
			return
		end
		if math.Round(Wang:GetValue()) < 100 then
			draw.SimpleText("Please transfer a reasonable amount. (at least $100)", "Kostar_S17", 30,10, Color(255,50,0,255))
			return
		end
		if math.Round(Wang:GetValue()) > self.WithDrawBG.VerifiedCash then
			draw.SimpleText("You don't have enough money to transfer that much!", "Kostar_S17", 30,10, Color(255,50,0,255))
			return
		end
		
		draw.SimpleText("Funds and account verified, transfer ready!", "Kostar_S17", 30,10, Color(0,255,0,255))
		
	end
	List:AddItem(BG)
	
	local DSButton = vgui.Create("ATM_DSWButton",BG)
		DSButton:SetTexts("Deposit Money")
		DSButton:SetPos(BG:GetWide()-150,35)
		DSButton:SetSize(140,30)
		DSButton.DoClick = function(slf)
			if !self.WithDrawBG.VerifiedCash then return end
			if math.Round(Wang:GetValue()) < 1 then return end
			if string.len(DTextEntry_MEMO:GetValue()) > 20 then return end
			if math.Round(Wang:GetValue()) > self.WithDrawBG.VerifiedCash then return end
			
			net.Start("ATM_TransferMoney_C2S")
			
				local TB2Send = {}
				TB2Send.MyAccountNum = self.Verified.Num
				TB2Send.TargetAccountNum = self.DepositBG.VerifiedData.Num
				TB2Send.MyMemo = DTextEntry_MEMO:GetValue()
				TB2Send.TargetMemo = DTextEntry_MEMO_T:GetValue()
				TB2Send.Amount = math.Round(Wang:GetValue())
			
				net.WriteTable(TB2Send)
			net.SendToServer()
		end
	//============================= Text Entry =====================//
	
end

vgui.Register("BankPanel", PANEL, "DFrame")
end

if SERVER then
local meta = FindMetaTable("Player")

-----
util.AddNetworkString( "OpenATMPanel_S2C" )
	function Open_ATMPanel(ply)
		net.Start( "OpenATMPanel_S2C" )
		net.Send(ply)
	end
	
-----
util.AddNetworkString( "GenerateBankbookNum_C2S" )
util.AddNetworkString( "GenerateBankbookNum_R_S2C" )
net.Receive( "GenerateBankbookNum_C2S", function( len,ply )
	local function Gen()
		local Gened = math.random(1000,9999) .. "-" .. math.random(1000,9999)
		if (file.Exists( "realistic_atm/" .. Gened .. ".txt","DATA")) then
			return Gen()
		else
			return Gened
		end
	end

	local GenedNum = Gen()
	net.Start("GenerateBankbookNum_R_S2C")
		net.WriteTable({Num=GenedNum})
	net.Send(ply)
end)

------
util.AddNetworkString( "ATM_CreateAccount_C2S" )
net.Receive( "ATM_CreateAccount_C2S", function( len,ply )
	local DATA = net.ReadTable()
	local Num = DATA.Num
	local Name = DATA.Name
	local Password = DATA.Password
	
	if (file.Exists( "realistic_atm/" .. Num .. ".txt","DATA")) then
		ply:BankDebugChat("Someone Already using that Number. please generate another number.")
		return
	else
		local InitData = {}
		InitData.Log = {}
		InitData.CurMoney = 0
		InitData.Password = Password
		InitData.Name = Name
		InitData.SteamID = ply:SteamID()
		
		file.Write("realistic_atm/" .. Num .. ".txt", util.TableToJSON(InitData))
		ply:BankDebugChat("Your account has been created!")
	end
end)

-----
util.AddNetworkString( "ATM_Verify_C2S" )
util.AddNetworkString( "ATM_Verify_R_S2C" )
net.Receive( "ATM_Verify_C2S", function( len,ply )
	local DATA = net.ReadTable()
	local Num = DATA.Num
	local Password = DATA.Password
	
	
	if !file.Exists( "realistic_atm/" .. Num .. ".txt","DATA") then
		ply:BankDebugChat("That account doesn't exist. Make sure the account number is correct.")
		return
	else
		local FileData = util.JSONToTable(file.Read( "realistic_atm/" .. Num .. ".txt" ))
		if FileData.Password != Password then
			ply:BankDebugChat("PASSWORD INCORRECT.")
			return
		else
			net.Start("ATM_Verify_R_S2C")
				net.WriteTable({Num=Num,Name=FileData.Name})
			net.Send(ply)
		end
	end
end)

-----
util.AddNetworkString( "ATM_DEP_Verify_C2S" )
util.AddNetworkString( "ATM_DEP_Verify_R_S2C" )
net.Receive( "ATM_DEP_Verify_C2S", function( len,ply )
	local DATA = net.ReadTable()
	local Num = DATA.Num
	
	
	if !file.Exists( "realistic_atm/" .. Num .. ".txt","DATA") then
		ply:BankDebugChat("That account doesn't exist. Make sure the account number is correct.")
		return
	else
		local FileData = util.JSONToTable(file.Read( "realistic_atm/" .. Num .. ".txt" ))
		net.Start("ATM_DEP_Verify_R_S2C")
			net.WriteTable({Num=Num,Name=FileData.Name})
		net.Send(ply)
	end
end)

-----
util.AddNetworkString( "ATM_CL_Verify_C2S" )
util.AddNetworkString( "ATM_CL_Verify_R_S2C" )
net.Receive( "ATM_CL_Verify_C2S", function( len,ply )
	local DATA = net.ReadTable()
	local Num = DATA.Num
	
	
	if !file.Exists( "realistic_atm/" .. Num .. ".txt","DATA") then
		ply:BankDebugChat("That account doesn't exist. Make sure the account number is correct.")
		return
	else
		local FileData = util.JSONToTable(file.Read( "realistic_atm/" .. Num .. ".txt" ))
		net.Start("ATM_CL_Verify_R_S2C")
			net.WriteTable({Amount=FileData.CurMoney})
		net.Send(ply)
	end
end)

util.AddNetworkString( "BankChat_S2C" )
function meta:BankDebugChat(text)
	net.Start( "BankChat_S2C" )
		net.WriteTable( {t=text} )
		net.Send(self)
end


util.AddNetworkString( "MyBankBook_C2S" )
util.AddNetworkString( "MyBankBookData_S2C" )
net.Receive( "MyBankBook_C2S", function( len,ply )
	local DATA = net.ReadTable()
	local Num = DATA.Num
	local Page = DATA.Page or 1
	
		local Data = {}
		if !file.Exists( "realistic_atm/" .. Num .. ".txt" ,"DATA") then
			return
		else
			Data = util.JSONToTable(file.Read( "realistic_atm/" .. Num .. ".txt" ))
		end
		
		
	local TB2Send = {}
	TB2Send.Log = {}

		local RCount = 0
		for count = 1,#Data.Log do
			count = #Data.Log - count + 1
			RCount = RCount + 1
			if RCount >= (Page*30-29) and RCount <= (Page*30) then
				local DB = Data.Log[count]
				local TB2Insert = table.Copy(DB)
				TB2Insert.Count = count
				table.insert(TB2Send.Log,TB2Insert)
			end
		end
		
		
	TB2Send.CurMoney = Data.CurMoney or 0
	TB2Send.LogAmount = #(Data.Log or {})
	TB2Send.CurPage = Page
	
	net.Start( "MyBankBookData_S2C" )
		net.WriteTable( TB2Send )
		net.Send(ply)

end)


util.AddNetworkString( "ATM_DepositMoney_C2S" )
net.Receive( "ATM_DepositMoney_C2S", function( len,ply )
	local DATA = net.ReadTable()
	local Amount = DATA.Amount
	local Num = DATA.Num
	local Memo = DATA.Memo
	if ply:GetPlayerMoneyM() < Amount then 
		ply:BankDebugChat("Error : Not Enough Money")
		return 
	end
	
	if ATM_AddItem2Account(Num,Amount,Memo,ply) then
		ply:AddPlayerMoneyM(-Amount)
		ply:BankDebugChat("Deposit Complete")
	else
		MsgN("SOMETHING WRONG")
	end
end)




function ATM_AddItem2Account(Num,Amount,Memo,ply)
	local Data = {}
	if file.Exists( "realistic_atm/" .. Num .. ".txt" ,"DATA") then
		Data = util.JSONToTable(file.Read( "realistic_atm/" .. Num .. ".txt" ))
	else
		ply:BankDebugChat("ERROR Code A521.  Transfer Cancelled")
		MsgN("ERROR ?!")
		return false
	end
	
	Data.CurMoney = Data.CurMoney + Amount
	-----
	local DB2Write = {}
	DB2Write.Day = os.date( "20%y-%m-%d" )
	DB2Write.Time = os.date( "%p %I:%M" )
	DB2Write.Memo = Memo
	DB2Write.Plus = Amount
	DB2Write.MoneyLeft = Data.CurMoney
	table.insert(Data.Log, DB2Write)
	
	for k,v in pairs(player.GetAll()) do
		if v:SteamID() == Data.SteamID then
			v:ATM_Notify(ply:Nick() .. " sent $ " .. string.Comma(Amount) .. " dollar to your bank account!")
		end
	end
	
	if #Data.Log > 99 then
		local NewData = {}
			NewData.Log = {}
			NewData.CurMoney = Data.CurMoney --
			NewData.SteamID = Data.SteamID --
			NewData.Name = Data.Name --
			NewData.Password = Data.Password --
		local Count = 0
		for k = #Data.Log-99,#Data.Log do
			Count = Count + 1
			NewData.Log[Count] = Data.Log[k]
		end
		file.Write("realistic_atm/" .. Num .. ".txt", util.TableToJSON(NewData))
	else
		MsgN("Writing Data")
		file.Write("realistic_atm/" .. Num .. ".txt", util.TableToJSON(Data))
	end
	
	
	return true
end


util.AddNetworkString( "WithdrawalMoney_C2S" )
net.Receive( "WithdrawalMoney_C2S", function( len,ply )
	local DATA = net.ReadTable()
	local Num = DATA.Num
	local Amount = DATA.Amount
	local Memo = DATA.Memo
	
	local Data = {}
	if file.Exists( "realistic_atm/" .. Num .. ".txt" ,"DATA") then
		Data = util.JSONToTable(file.Read( "realistic_atm/" .. Num .. ".txt" ))
	else
		ply:BankDebugChat("WithDraw - Error : There is no statement.",ply)
		return
	end
	
	if Amount > Data.CurMoney then 
		ply:BankDebugChat("Error: Insufficient Funds",ply)
		return 
	end
	
	Data.CurMoney = Data.CurMoney - Amount
	ply:AddPlayerMoneyM(Amount)
	
	local DB2Write = {}
	DB2Write.Day = os.date( "20%y-%m-%d" )
	DB2Write.Time = os.date( "%p %I:%M" )
	DB2Write.Memo = Memo
	DB2Write.Sub = Amount
	DB2Write.MoneyLeft = Data.CurMoney
	table.insert(Data.Log, DB2Write)
	
	file.Write("realistic_atm/" .. Num .. ".txt", util.TableToJSON(Data));
	
	ply:BankDebugChat("Withdraw Complete")
end)

util.AddNetworkString( "ATM_TransferMoney_C2S" )
net.Receive( "ATM_TransferMoney_C2S", function( len,ply )
	local DATA = net.ReadTable()
	local TargetAccountNum = DATA.TargetAccountNum
	local MyAccountNum = DATA.MyAccountNum
	local Amount = DATA.Amount
	local MyMemo = DATA.MyMemo
	local TargetMemo = DATA.TargetMemo
	
	local MyData = {}
	if file.Exists( "realistic_atm/" .. MyAccountNum .. ".txt" ,"DATA") then
		MyData = util.JSONToTable(file.Read( "realistic_atm/" .. MyAccountNum .. ".txt" ))
	else
		ply:BankDebugChat("WithDraw - Error Code TM1 : There is no statement.",ply)
		return
	end
	
	local TargetData = {}
	if file.Exists( "realistic_atm/" .. TargetAccountNum .. ".txt" ,"DATA") then
		TargetData = util.JSONToTable(file.Read( "realistic_atm/" .. TargetAccountNum .. ".txt" ))
	else
		ply:BankDebugChat("WithDraw - Error Code TM2 : There is no statement.",ply)
		return
	end
	
	if Amount > MyData.CurMoney then 
		ply:BankDebugChat("Error : Insufficient funds.",ply)
		return 
	end
	
	MyData.CurMoney = MyData.CurMoney - Amount
	TargetData.CurMoney = TargetData.CurMoney + Amount
	

	local DB2Write = {}
	DB2Write.Day = os.date( "20%y-%m-%d" )
	DB2Write.Time = os.date( "%p %I:%M" )
	DB2Write.Memo = MyMemo
	DB2Write.Sub = Amount
	DB2Write.MoneyLeft = MyData.CurMoney
	table.insert(MyData.Log, DB2Write)
	
	local DB2Write = {}
	DB2Write.Day = os.date( "20%y-%m-%d" )
	DB2Write.Time = os.date( "%p %I:%M" )
	DB2Write.Memo = TargetMemo
	DB2Write.Plus = Amount
	DB2Write.MoneyLeft = TargetData.CurMoney
	table.insert(TargetData.Log, DB2Write)
	
	for k,v in pairs(player.GetAll()) do
		if v:SteamID() == TargetData.SteamID then
			v:ATM_Notify(ply:Nick() .. " sent $ " .. string.Comma(Amount) .. " dollars to your bank account!")
		end
	end
	
	if #MyData.Log > 99 then
		local NewData = {}
			NewData.Log = {}
			NewData.CurMoney = MyData.CurMoney --
			NewData.SteamID = MyData.SteamID --
			NewData.Name = MyData.Name --
			NewData.Password = MyData.Password --
		local Count = 0
		for k = #MyData.Log-99,#MyData.Log do
			Count = Count + 1
			NewData.Log[Count] = MyData.Log[k]
		end
		file.Write("realistic_atm/" .. MyAccountNum .. ".txt", util.TableToJSON(NewData))
	else
		file.Write("realistic_atm/" .. MyAccountNum .. ".txt", util.TableToJSON(MyData))
	end
	
	if #TargetData.Log > 99 then
		local NewData = {}
			NewData.Log = {}
			NewData.CurMoney = TargetData.CurMoney --
			NewData.SteamID = TargetData.SteamID --
			NewData.Name = TargetData.Name --
			NewData.Password = TargetData.Password --
		local Count = 0
		for k = #TargetData.Log-99,#TargetData.Log do
			Count = Count + 1
			NewData.Log[Count] = TargetData.Log[k]
		end
		file.Write("realistic_atm/" .. TargetAccountNum .. ".txt", util.TableToJSON(NewData))
	else
		file.Write("realistic_atm/" .. TargetAccountNum .. ".txt", util.TableToJSON(TargetData))
	end
	
	
	
	ply:BankDebugChat("Transfer Complete")
end)

end

