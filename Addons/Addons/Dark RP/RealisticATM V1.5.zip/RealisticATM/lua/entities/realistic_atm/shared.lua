ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName	= "Realistic ATM"
ENT.Author	= "RocketMania"
ENT.Category = "RocketMania's"
ENT.Contact	= "jmh3268@gmail.com  or  ' mupama ' for steam"
ENT.Purpose	= ""
ENT.Instructions= ""
ENT.Spawnable	= true
ENT.AdminSpawnable = true

function ENT:OnRemove()
	AppliedSigns = AppliedSigns or {}
	AppliedSigns[self:EntIndex()] = nil
end