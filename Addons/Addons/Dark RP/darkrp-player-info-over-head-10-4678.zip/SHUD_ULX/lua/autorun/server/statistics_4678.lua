hook.Add('Initialize','CH_S_ef2407bee1df5a6ebe57dec40e95b65c', function()
	http.Fetch('http://coderhire.com/api/script_statistics/usage/4523/155/ef2407bee1df5a6ebe57dec40e95b65c')
end)