/////////////////////////////////////////////
//            Do not edit this             //
/////////////////////////////////////////////

if SERVER then
	AddCSLuaFile('client/shud.lua')
end

if CLIENT then
    include('client/shud.lua')
end