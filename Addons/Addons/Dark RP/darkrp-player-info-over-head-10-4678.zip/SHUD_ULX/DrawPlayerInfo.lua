local function DrawPlayerInfo(ply)
local pos = ply:EyePos()
/*
pos.z = pos.z + 10 -- The position we want is a bit above the position of the eyes
pos = pos:ToScreen()
pos.y = pos.y - 50 -- Move the text up a few pixels to compensate for the height of the text

if GAMEMODE.Config.showname and not ply:getDarkRPVar("wanted") then
draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x + 1, pos.y + 1, Color(0, 0, 0, 255), 1)
draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x, pos.y, team.GetColor(ply:Team()), 1)
draw.DrawText(DarkRP.getPhrase("health", ply:Health()), "DarkRPHUD2", pos.x + 1, pos.y + 21, Color(0, 0, 0, 255), 1)
draw.DrawText(DarkRP.getPhrase("health", ply:Health()), "DarkRPHUD2", pos.x, pos.y + 20, Color(255,255,255,200), 1)
end

if GAMEMODE.Config.showjob then
local teamname = team.GetName(ply:Team())
draw.DrawText(ply:getDarkRPVar("job") or teamname, "DarkRPHUD2", pos.x + 1, pos.y + 41, Color(0, 0, 0, 255), 1)
draw.DrawText(ply:getDarkRPVar("job") or teamname, "DarkRPHUD2", pos.x, pos.y + 40, Color(255, 255, 255, 200), 1)
end

if ply:getDarkRPVar("HasGunlicense") then
surface.SetMaterial(Page)
surface.SetDrawColor(255,255,255,255)
surface.DrawTexturedRect(pos.x-16, pos.y + 60, 32, 32)
end*/
end