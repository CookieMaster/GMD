//////////////////////////////////////
//  This version only support Ulx  //
////////////////////////////////////

//////////////////////////////////////
//  Version: 8.0                   //
//  Updated: 27/10/13             //
///////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//# Installation                                                                                                                       //
//1. Extract shud.zip in garrysmod > garrysmod > addons.                                                                               //
//2. Restart your server.                                                                                                              //
//                                                                                                                                     //
//# Usage                                                                                                                              //
//1. Go to garrysmod > garrysmod > addons > SHUD > client > shud.lua                                                    		       //
//2. Change the configs																				                                   //
//                                                                                                                                     //
//# Support                                                                                                                            //
//Email: dev@samueldha.com                                                                                                             //
//                                                                                                                                     //
//# Updates                                                                                                                            //
//Visit the coderhire page to see/download the updates                                                                                 //
//                                                                                                                                     //
//# How to remove the DarkRP one?                                		                                                               //
//[The new DarkRP]                                                                                                                     //
//1. Go to garrysmod > garrysmod > gamemodes > darkrp > gamemode > modules > hud > cl_hud.lua                                          //
//2. Find "DrawPlayerInfo"                                                                                                             //
//3. Replace the DrawPlayerInfo function (from "local function DrawPlayerInfo(ply)" to "end") with the index of DrawPlayerInfo.lua     //
//                                                                                                                                     //
//[The old DarkRP]                                                                                                                     //
//1. Go to garrysmod > garrysmod > gamemodes > darkrp > gamemode > client > hud.lua                                                    //
//2. Find "DrawPlayerInfo"                                                                                                             //
//3. Replace the DrawPlayerInfo function (from "local function DrawPlayerInfo(ply)" to "end") with the index of DrawPlayerInfo.lua     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////
//                               //
//  Thanks for buying my script  //
//                               //
///////////////////////////////////