AddCSLuaFile("autorun/sh_rpnpc.lua")
AddCSLuaFile("autorun/colchat.lua")

local npcs = {}

require("glon")

local function makenpc(ply, cmd, args)
	if !ply:IsSuperAdmin() then return end
	local kind = args[1]
	if buyers[kind] == nil then return end
	local mdl = args[2] or "models/barney.mdl"
	if UTIL_IsUselessModel( mdl ) then return end
	local nam = args[3] or "John"
	local ent = ents.Create("npc_buyer")
	ent:SetPos(ply:GetEyeTraceNoCursor().HitPos + Vector(0,0,5))
	local ihatepitch = ply:EyeAngles()
	ihatepitch.p = 0
	ent:SetAngles(ihatepitch)
	ent.buytype = kind
	ent.model = mdl	
	ent.name = nam	
	ent:Spawn()	
	ent:Activate()
	ply:ColChat("RP-NPC", Color(0,255,0), "Buyer succesfully created! Now run rp_savenpcs to save them!")
end
concommand.Add("rp_makenpc", makenpc)

local function saveall(ply,cmd,args)
	if !ply:IsSuperAdmin() then return end
	local data = {}	
	npcs = {}
	
	for key, npc in pairs(ents.GetAll()) do
		if npc:GetClass() == "npc_buyer" then
			table.insert(npcs, npc)
		end
	end
	
	for k,v in pairs(npcs) do	
		table.insert(data, {mdl = v.model, pos = v:GetPos(), ang = v:GetAngles(), tipe = v.buytype, lpos = v:GetDTVector(0), lang = v:GetDTAngle(0), nam = v.name})	
	end
	
	local dir = "rpnpc/" .. game.GetMap() .. ".txt"
	
	if file.Exists(dir, "DATA") then
		MsgAll("Deleting RP-NPC File...")
		file.Delete(dir, "DATA")
	end
	
	MsgAll(PrintTable(data))
	
	file.Write(dir, glon.encode(data), "DATA")
	ply:ColChat("RP-NPC", Color(0,255,0), "Buyers succesfully saved! (Table Purged)")
end
concommand.Add("rp_savenpcs", saveall)

local function gravpickup( ply, ent )	
	ent.picker = ply
end
hook.Add("GravGunOnPickedUp", "setpicker", gravpickup)

local function gravdrop(ply,ent)
	if ent.picker then
		ent.picker = nil
	end
end
hook.Add( "GravGunOnDropped", "removepicker", gravdrop)

local function SpawnNPCs()
	local dir = "rpnpc/" .. game.GetMap() .. ".txt"
	if file.Exists(dir, "DATA") then	
		for k,v in pairs(glon.decode(file.Read(dir, "DATA"))) do	
			local ent = ents.Create("npc_buyer")		
			ent.model = v.mdl	
			ent:SetPos(v.pos)		
			ent:SetAngles(v.ang)			
			ent.buytype = v.tipe	
			ent.name = v.nam		
			ent:Spawn()
			ent:Activate()	
			table.insert(npcs, ent)		
			ent:SetDTVector(0, v.lpos)	
			ent:SetDTAngle(0, v.lang)	
		end	
	end
end
hook.Add( "InitPostEntity", "SpawnNPCs", SpawnNPCs)