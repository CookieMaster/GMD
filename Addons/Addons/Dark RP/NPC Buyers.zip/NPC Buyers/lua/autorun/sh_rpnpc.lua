buyers = {
	food_buyer = { --name used in concommand
		entclass = "spawned_food", --entity name
		buyamt = 75, --base amount to buy for
		flux = 5, --how much it changes up/down (0 to disable changing)
		max = 100, --if flux =/= 0 then minimun and maximun buy amounts
		min = 50, -- ^^
		nicename = "Food" -- nice name show, shows as "Buying xxx"
	},
	weed_buyer = {
		entclass = "durgz_weed",
		buyamt = 500,
		flux = 25,
		max = 800,
		min = 200,
		nicename = "We Sell Weed Mate?"
	},
	gold_buyer = {
		entclass = "printer_gold",
		buyamt = 1000,
		flux = 100,
		max = 1600,
		min = 400,
		nicename = "Golden Printers"
	},
	emerald_buyer = {
		entclass = "printer_emerald",
		buyamt = 4000,
		flux = 500,
		max = 4000,
		min = 1000,
		nicename = "Emerald Printers"
	},
	sapphire_buyer = {
		entclass = "printer_sapphire",
		buyamt = 8000,
		flux = 1000,
		max = 8000,
		min = 2000,
		nicename = "Sapphire Printers"
	},
	diamond_buyer = {
		entclass = "printer_diamond",
		buyamt = 16000,
		flux = 3000,
		max = 16000,
		min = 4000,
		nicename = "Diamond Printers"
	},
	weed_buyer = {
		entclass = "durgz_weed",
		buyamt = 300,
		flux = 50,
		max = 300,
		min = 50,
		nicename = "Weed"
	},
	lsd_buyer = {
		entclass = "durgz_lsd",
		buyamt = 600,
		flux = 50,
		max = 900,
		min = 300,
		nicename = "LSD"
	},
	alcohol_buyer = {
		entclass = "durgz_alcohol",
		buyamt = 200,
		flux = 25,
		max = 300,
		min = 100,
		nicename = "Beer"
	},
		cocn_buyer = {
		entclass = "durgz_cocaine",
		buyamt = 900,
		flux = 100,
		max = 1200,
		min = 600,
		nicename = "Cocaine"
	}
}