include('shared.lua')
local Container
local Frame

local function introWindow(um)
	local name = um:ReadString()
	local buying = um:ReadString()
	local price = um:ReadString()

	Frame = vgui.Create("DFrame")
	Frame:SetSize(320,140)
	Frame:SetPos(ScrW()/2-150,ScrH()/2-150)
	Frame:SetTitle(name.." the "..buying.." Buyer")
	Frame:SetVisible(true)
	Frame:SetDraggable(true)
	Frame:ShowCloseButton(true)
	Frame:MakePopup()
	Frame.Paint = function(self,w,h)
        draw.RoundedBox(0,0,0,w,h,Color(10,10,10,150))
    end
	
	Container = vgui.Create("DPanel")
	Container:SetParent(Frame)
	Container:SetSize(300,100)
	Container:SetPos(10,30)
	
	local MyName = vgui.Create("DLabel")
	MyName:SetParent(Container)
	MyName:SetText("Hi there! They call me "..name..". Nice to meet you!")
	MyName:SizeToContents()
	MyName:SetTextColor(Color(0, 0, 0, 255))
	MyName:SetPos(5, 5)
	
	local DoYouHave = vgui.Create("DLabel")
	DoYouHave:SetParent(Container)
	DoYouHave:SetText("Do you have any "..buying.." for sale?")
	DoYouHave:SizeToContents()
	DoYouHave:SetTextColor(Color(0, 0, 0, 255))
	DoYouHave:SetPos(5, 25)
	
	local BuyingFor = vgui.Create("DLabel")
	BuyingFor:SetParent(Container)
	BuyingFor:SetText("I'll buy them for $"..price.."!")
	BuyingFor:SizeToContents()
	BuyingFor:SetTextColor(Color(0, 0, 0, 255))
	BuyingFor:SetPos(5, 45)
	
	local Close = vgui.Create("DButton")
	Close:SetParent(Container)
	Close:SetSize(Container:GetWide()-10, 20)
	Close:SetText("Okay")
	Close.DoClick = function()
		Frame:Close()
	end
	Close:SetPos(5,70)
	
end
usermessage.Hook("GetBuyerWindow", introWindow)