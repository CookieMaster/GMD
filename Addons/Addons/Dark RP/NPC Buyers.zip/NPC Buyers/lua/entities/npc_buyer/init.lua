AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()

	self:SetModel(self.model)
	
	self:SetHullType( HULL_HUMAN )
	self:SetHullSizeNormal();
	self:SetSolid( SOLID_BBOX )
	self:SetMoveType( MOVETYPE_STEP )
	self:CapabilitiesAdd( CAP_ANIMATEDFACE || CAP_TURN_HEAD )
	self:SetMaxYawSpeed( 5000 )
  
	//Sets the entity values
	self:SetHealth(1000000)
	self:SetEnemy(NULL)
	self:SetSchedule(SCHED_IDLE_STAND)
	position = self:GetPos()
	self:SetUseType(SIMPLE_USE)
	
	self:SetCollisionGroup( COLLISION_GROUP_NONE )
	
	timer.Create( "BuyMoar" .. self:EntIndex(), 60, 0, function() self:IncreaseBuyAmt() end )
	
	local tab = buyers[self.buytype]
	
	self:SetDTInt(0, tab.buyamt)

end

function ENT:AcceptInput( input, activator, caller )
	if input == "Use" && activator:IsPlayer() then
		umsg.Start( "GetBuyerWindow", activator )  
			umsg.String(self.name)
			umsg.String(buyers[self.buytype]["nicename"])
			umsg.String(self:GetDTInt(0))
		umsg.End()  
	end
end

function ENT:IncreaseBuyAmt()
	local tab = buyers[self.buytype]
	if tab.flux > 0 then
		self:SetDTInt(0, math.Clamp(self:GetDTInt(0) + tab.flux, tab.min, tab.max))
		--print("buy amount increased to" .. self:GetDTInt(0))
	end
end

function ENT:OnTakeDamage(dmg)
	self:SetHealth(100000)
end

function ENT:Think()
end

function ENT:OnRemove()
	timer.Remove("BuyMoar" .. self:EntIndex())
end

function ENT:StartTouch( ent )
	self:SetCollisionGroup( COLLISION_GROUP_NONE )
	
	if buyers[self.buytype] == nil then
		ErrorNoHalt("Incorrect buytype! Removing...")
		self:Remove()
	end
	
	if ent.picker == nil then
		return
	end
	
	local tab = buyers[self.buytype]
	
	if ent:GetClass() == tab.entclass then
		if tab.requiredmodel and ent:GetModel() != tab.requiredmodel then
			MsgAll("Not right model!\n")
			return
		end
		
		if tab.requiredvars then
			for k,v in pairs(tab.requiredvars) do
				if ent[k] != v then 
					MsgAll("Not right var!\n")
					return
				end
			end
		end
		
		-- so it passed the checks time to sell it!
		ent.picker:AddMoney(self:GetDTInt(0))
		ent.picker:ColChat("RP-NPC", Color(0,255,0), "Your item has been sold for " .. self:GetDTInt(0) .. "$!")
		--AddXP(25, ent.picker, "selling to an NPC!")
		
		if tab.flux > 0 then
			self:SetDTInt(0, math.Clamp(self:GetDTInt(0) - tab.flux, tab.min, tab.max))
		end
		ent:Remove()

		self:EmitSound(Sound("Buttons.snd9"))
	end
end