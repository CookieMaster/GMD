 ENT.Base = "base_ai"
 ENT.Type = "ai"
   
 ENT.PrintName = "NPC Buyer"  
 ENT.AutomaticFrameAdvance = true
 ENT.Spawnable = false
 ENT.AdminSpawnable = false
 
