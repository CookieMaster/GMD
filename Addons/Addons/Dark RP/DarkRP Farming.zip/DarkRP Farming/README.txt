Hello! thankyou for purchaseing

Contact:
thomas.williamson@thegeekgroup.org
or add me on steam.

Config:
Edit config at modules/farming/sh_config.lua

Installation:
murge these folders with the darkrp folders




Place this in addentities.lua at the bottom:
//////////////////////////////////////////////////////////////////////////
AddEntity("Banana Seeds", {
	ent = "farming_seedboxbanana",
	model = "models/props_junk/cardboard_box004a.mdl",
	price = 100,
	max = 5,
	cmd = "/buybananaseeds",
	allowed = TEAM_FARMER
})
AddEntity("Melon Seeds", {
	ent = "farming_seedboxmelon",
	model = "models/props_junk/cardboard_box004a.mdl",
	price = 100,
	max = 5,
	cmd = "/buymelonseeds",
	allowed = TEAM_FARMER
})

AddEntity("Orange Seeds", {
	ent = "farming_seedboxorange",
	model = "models/props_junk/cardboard_box004a.mdl",
	price = 100,
	max = 5,
	cmd = "/buyorangeseeds",
	allowed = TEAM_FARMER
})
//////////////////////////////////////////////////////////////////////////




Place this in shared.lua:
//////////////////////////////////////////////////////////////////////////
TEAM_FARMER = AddExtraTeam("Farmer", {
	color = Color(80, 200, 0, 255),
	model = "models/player/eli.mdl",
	description = [[Plant seeds you buy from f4 Menu,
	Grow them then sell them to a NPC or eat them!
	]],
	weapons = {"hoe"},
	command = "farmer",
	max = 2,
	salary = 40,
	admin = 0,
	vote = false,
	hasLicense = false,
	candemote = true
})
//////////////////////////////////////////////////////////////////////////




