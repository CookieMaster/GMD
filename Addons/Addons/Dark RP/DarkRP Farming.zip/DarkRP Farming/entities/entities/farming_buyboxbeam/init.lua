AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/props_junk/wood_crate001a_damaged.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	local phys = self:GetPhysicsObject()
	phys:Wake()
end

function ENT:Use(activator,caller)
	if !IsValid(caller) or self:GetCash() <= 0 then return end
	if(caller:Team() != FARMCFG.Job) then
		caller:ChatPrint("Your not a farmer!")
		return
	end
	
	caller:AddMoney(self:GetCash())
	caller:ChatPrint("You have earned $" .. self:GetCash() .. " from selling food!")
	self:SetCash(0)
end



function ENT:StartTouch(ent)
	if(IsValid(ent) and ent:GetClass() == "spawned_food" and ent.Sellable == true) then
		self:SetCash(self:GetCash() + FARMCFG.Priceperfood)
		ent.Sellable = false
		ent:Remove()
	end
end

function ENT:OnRemove()
	timer.Simple(1, SaveFarmingPositions)
end

function ENT:OnPhysgunFreeze(weapon, phys, ent, ply)
	if(ply:IsSuperAdmin()) then
		SaveFarmingPositions()
	end
end

function ENT:PhysgunPickup(ply, ent)
	return ply:IsSuperAdmin()
end