AddCSLuaFile('cl_init.lua')
AddCSLuaFile('shared.lua')

include('shared.lua')

function ENT:Initialize()
	self:SetModel("models/Humans/Group03/Male_04.mdl" )
	self:SetHullType( HULL_HUMAN )
	self:SetHullSizeNormal( )
	self:SetNPCState( NPC_STATE_SCRIPT )
	self:SetSolid( SOLID_BBOX )
	self:CapabilitiesAdd( bit.bor(CAP_ANIMATEDFACE, CAP_TURN_HEAD) )
	self:SetUseType( SIMPLE_USE )
	self:DropToFloor()
	self:SetMaxYawSpeed( 90 )
end

function ENT:AcceptInput(name, activator, caller, data)
	if !(name == "Use" and IsValid(caller) and caller:IsPlayer()) then return end
	if(caller:Team() != FARMCFG.Job) then
		caller:ChatPrint("Your not a farmer! Go away!")
	else
		caller:ChatPrint("Buying food! Just drop some food into my crate and pick up the cash!")
	end
	if(caller:IsSuperAdmin()) then
		SaveFarmingPositions()
	end
end

function ENT:OnRemove()
	
end

function ENT:OnPhysgunFreeze(weapon, phys, ent, ply)
	if(ply:IsSuperAdmin()) then
		SaveFarmingPositions()
		return true
	end
	return false
end

function ENT:PhysgunPickup(ply, ent)
	return ply:IsSuperAdmin()
end
