ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Seed"
ENT.Author = "TCWilliamson"
ENT.Spawnable = false
ENT.AdminSpawnable = false

function ENT:SetupDataTables()

end