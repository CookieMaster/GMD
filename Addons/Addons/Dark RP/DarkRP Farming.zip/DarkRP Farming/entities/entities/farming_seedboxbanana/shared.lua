ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Seed Box"
ENT.Author = "TCWilliamson"
ENT.Spawnable = true
ENT.AdminSpawnable = true

function ENT:SetupDataTables()
	self:NetworkVar("Int", 0, "Seeds")
	self:NetworkVar("Entity",1,"owning_ent")
end