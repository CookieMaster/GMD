FARMCFG = {}
FARMCFG.Priceperfood = 10			// Price for each food
FARMCFG.Job = TEAM_FARMER			// Only one job allowed
FARMCFG.MelonSeeds = 5 				// Melon seeds per box
FARMCFG.OrangeSeeds = 5 			// Orange seeds per box
FARMCFG.BananaSeeds = 5				// Bananna seeds per box

FARMCFG.SeedGrowMin = 180		//Minimum time for the Seed seed to grow into a plant (Stage 1)
FARMCFG.SeedGrowMax = 200		//Maxmum time for the Seed seed to grow into a plant (Stage 1)


FARMCFG.BananaFruitGrowMin = 5		//Minimum time for the Banana plant to grow fruit (Stage 2)
FARMCFG.BananaFruitGrowMax = 10		//Maxmum time for the Banana plant to grow fruit (Stage 2)

FARMCFG.OrangeFruitGrowMin = 5		//Minimum time for the Orange plant to grow fruit (Stage 2)
FARMCFG.OrangeFruitGrowMax = 10		//Maxmum time for the Orange plant to grow fruit (Stage 2)

FARMCFG.MelonFruitGrowMin = 5 		//Minimum time for the Melon plant to grow fruit (Stage 2)
FARMCFG.MelonFruitGrowMax = 10 		//Maxmum time for the Melon plant to grow fruit (Stage 2)