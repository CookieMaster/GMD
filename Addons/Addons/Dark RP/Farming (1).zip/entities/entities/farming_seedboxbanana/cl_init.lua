include("shared.lua")

function ENT:Initialize()
end

function ENT:Draw()
	self:DrawModel()
	local Pos = self:GetPos()
	local Ang = self:GetAngles()

	cam.Start3D2D(Pos + Ang:Up() * 4.1, Ang, 0.14)
	 	draw.RoundedBox( 0, -30, -30, 60, 60, Color(0,0,0,255) )
		draw.SimpleText(FARMCFG.BananaSeeds, "HUDNumber5",0 , -10, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("Seeds", "Default",0 , 10, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
end