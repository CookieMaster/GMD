include("shared.lua")

function ENT:Initialize()
end

function ENT:Draw()
	self:DrawModel()
end