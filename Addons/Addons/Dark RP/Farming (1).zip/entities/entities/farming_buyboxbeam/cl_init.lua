include("shared.lua")

function ENT:Initialize()
end

function ENT:Draw()
	self:DrawModel()
	local Pos = self:GetPos()
	local Ang = self:GetAngles()
	Ang:RotateAroundAxis(Ang:Forward(), 90)
	cam.Start3D2D(Pos + Ang:Up() * 20.19, Ang, 0.14)
	 	draw.RoundedBox( 0, -130, -40, 260, 80, Color(0,0,0,255) )
		draw.SimpleText("Use to claim money.", "DermaLarge",0 , -20, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("$" .. self:GetCash(), "DermaLarge",0 , 20, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
end