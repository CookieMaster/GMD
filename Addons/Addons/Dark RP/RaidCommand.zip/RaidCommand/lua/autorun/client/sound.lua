usermessage.Hook("RaidCommence", function()
	surface.PlaySound("air-raid.wav")
end) 