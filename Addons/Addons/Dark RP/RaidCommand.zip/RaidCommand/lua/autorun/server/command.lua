function GetPlyByNick(name)
	for k,v in pairs(player.GetAll()) do
		if string.find(string.lower(v:Name()), string.lower(tostring(name))) ~= nil then
			return v
		end
	end
end

function doRaidCommand( ply, msg, isTeam )
	cmd = string.Explode(" ", msg)
	
	if cmd[1] == "/raid" then
		if cmd[2] == nil then return end
		if GetPlyByNick(cmd[2]):IsPlayer() then
			for k,v in pairs(player.GetAll()) do
				v:PrintMessage(HUD_PRINTTALK, ply:Nick().." has declared a raid on "..GetPlyByNick(cmd[2]):Nick())
				ELS:Log(ply:Nick().." has declared a raid on "..GetPlyByNick(cmd[2]):Nick(), 7)
			end
			umsg.Start("RaidCommence", GetPlyByNick(cmd[2]))
			umsg.End()
			return false
		end
	end
	
end
hook.Add( "PlayerSay", "DoRaidCommand", doRaidCommand )