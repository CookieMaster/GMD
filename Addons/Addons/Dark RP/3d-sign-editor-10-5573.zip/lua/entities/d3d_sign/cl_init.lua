include('shared.lua')
include('d3d_sign_core.lua')

function ENT:Initialize()
	
	timer.Simple(1,function()
		if AppliedSigns[self:EntIndex()] then
			self:SetSignData(AppliedSigns[self:EntIndex()])
		end
		self.LayerPanels = {}
	end)
end


function ENT:Draw()
	local MainEnt = self
	self:DrawModel()
end

function ENT:SetSignData(SignData)
	self.SignData = SignData
	self:BuildSign()
end

function ENT:OnRemove()
	if self.D3Panel and self.D3Panel:IsValid() then
		self.D3Panel:Remove()
	end
end

function ENT:HideSign()
	for k,v in pairs(self.LayerPanels or {}) do
		if v.Type == "HTMLTexture" and !v.Hiding then
			v.Hiding = true
			v:SetHTML("")
		end
	end
end
function ENT:DrawSign()
	for k,v in pairs(self.LayerPanels or {}) do
		if v.Type == "HTMLTexture" and v.Hiding then
			v.Hiding = false
			v:SetHTML(v.HTML)
		end
	end
end

function ENT:BuildSign()
	local SD = self.SignData
	if !SD then
		MsgN("Warning. Signdata is not valid")
		return
	else
		MsgN("Building Sign")
	end
	if self.D3Panel and self.D3Panel:IsValid() then
		self.D3Panel:Remove()
	end
	self.D3Panel = vgui.Create("DPanel")
	self.D3Panel:SetSize(SD.CanVasX,SD.CanVasY)
	self.D3Panel:SetPos(0,0)
	self.D3Panel.Paint = function(slf) 
	--	surface.SetDrawColor( 50,50,50,255 )
	--	surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
	end
	
	for k,v in pairs(self.LayerPanels or {}) do
		if v and v:IsValid() then
			v:Remove()
			MsgN("REMOVING PREVIOUS PANEL")
		end
	end
	self.LayerPanels = {}
	
	for LayerNum,Data in pairs(SD.Layer) do
		local function BuildSign()
			if Data.Type == "Text" then
				
				local FontName = D2D_GenerateFontName(Data.Font,Data.FontSize,Data.OutLine)
				local LP = vgui.Create("DPanel",self.D3Panel)
				LP:SetSize(SD.CanVasX,SD.CanVasY)
				LP:SetPos(0,0)
				LP.Type = Data.Type
				LP.Paint = function(slf)
					if D2D_HasFontNM(FontName) then
						draw.SimpleText(Data.Text, FontName,Data.PosX, Data.PosY , Color(Data.Color.r,Data.Color.g,Data.Color.b,Data.Color.a))
					else
						D2D_CreateFont(Data.Font,Data.FontSize,Data.OutLine)
						draw.SimpleText("Generating Fonts.. " .. FontName, "BudgetLabel",Data.PosX, Data.PosY , Color(Data.Color.r,Data.Color.g,Data.Color.b,Data.Color.a))
					end
				end
				table.insert(self.LayerPanels,LP)
			end
			if Data.Type == "Box" then
				local LP = vgui.Create("DPanel",self.D3Panel)
				LP:SetSize(Data.SizeX,Data.SizeY)
				LP:SetPos(Data.PosX,Data.PosY)
				LP.Type = Data.Type
				LP.Paint = function(slf)
					surface.SetDrawColor( Data.Color.r , Data.Color.g , Data.Color.b , Data.Color.a )
					surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
				end
				table.insert(self.LayerPanels,LP)
			end
			if Data.Type == "HTMLTexture" then
				local LP = vgui.Create("HTML",self.D3Panel)
				LP:SetSize(Data.SizeX,Data.SizeY)
				LP:SetPos(Data.PosX,Data.PosY)
				LP.Type = Data.Type
				LP.HTML = [[
						<style type="text/css">
							html 
							{			
								overflow:hidden;
								margin: -8px -8px;
							}
						</style>
						
						<body>
							<img src="]] .. Data.URL .. [[" alt="" width="]] .. LP:GetWide() ..[[" height="]] .. LP:GetTall() .. [[" />
						</body>
					]]
				LP:SetHTML(LP.HTML)
				table.insert(self.LayerPanels,LP)
			end
		end
		timer.Simple(LayerNum/10,function()
			BuildSign()
		end)
	end
end

hook.Add("PostDrawTranslucentRenderables", "Sign Render", function( )
	for k,v in pairs(ents.FindByClass("d3d_sign")) do
		if v.SignData then
			if !v.LastUpdate or (v.UpdateTime or 0) != v.LastUpdate then
				v.UpdateTime = CurTime()
				v.LastUpdate = CurTime()
				
				v:BuildSign()
			end
		end
		if v.D3Panel and v.D3Panel:IsValid() then
			if v:GetPos():Distance(LocalPlayer():GetPos()) < (D3D_Adjust.MaxDrawDistance or 1500) then
				v:DrawSign()
				v.D3Panel:SetVisible(true)
				local Ang = v:GetAngles()
				Ang:RotateAroundAxis(Ang:Forward(), 0)
				Ang:RotateAroundAxis(Ang:Right(), 270)
				Ang:RotateAroundAxis(Ang:Up(), 90)
				
					cam.Start3D2D( v:GetPos() + (v:GetRight() * (v.SignData.CanVasX*(0.3/2))) + (v:GetUp() * (v.SignData.CanVasY*0.3 +5)), Ang, 0.3 )
						v.D3Panel:SetPaintedManually( false )
							v.D3Panel:PaintManual()
						v.D3Panel:SetPaintedManually( true )
					cam.End3D2D()
			else
				v.D3Panel:SetVisible(false)
				v:HideSign()
			end
		end
	end
end)