AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "d3d_sign_core.lua" )

include('shared.lua')
include('d3d_sign_core.lua')


function ENT:SpawnFunction( ply, tr )

	if ( !tr.Hit ) then return end
	
	local SpawnPos = tr.HitPos + tr.HitNormal * 16
	
	local ent = ents.Create( "d3d_sign" )
		ent:SetPos( SpawnPos )
		ent:Spawn()
		ent.OwnedID = ply:SteamID()
	return ent
	
end

function ENT:OnRemove()
	AppliedSigns[self:EntIndex()] = nil
end


function ENT:Initialize( )
	self.Entity:SetModel("models/props_trainstation/traincar_rack001.mdl")
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_VPHYSICS)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	local phys = self.Entity:GetPhysicsObject()
	if phys and phys:IsValid() then
		phys:Wake()
		phys:SetMass(100)
	end
	
	self.Entity:SetUseType(SIMPLE_USE)
end

function ENT:Use( activator, caller )
	if self.OwnedID and activator:SteamID() == self.OwnedID then
		Open_3DSignEditor(activator,self)
	end
end

-- Functions for DarkRP

function ENT:Setowning_ent(ply) -- for DarkRP : Gives a permission to access sign
	self.OwnedID = ply:SteamID()
end

function ENT:PhysgunPickup(ply) -- for DarkRP : Allows Owner can pick up their sign with physicsgun
	if self.OwnedID and ply:SteamID() == self.OwnedID then
		return true
	end
end

function ENT:CanTool(ply, trace, mode) -- for DarkRP : Allows Superadmin to remove sign. 
	if ply:GetNWString("usergroup") == "superadmin" or ply:GetNWString("usergroup") == "owner" then return true end
	if ply:SteamID() == self.OwnedID then return true end
end