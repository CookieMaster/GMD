





--[[  ==================================================================
		Core Files. modifying is not recommanded.
		Do not edit codes below if you dont know what you are doing
]]--      ==================================================================

AppliedSigns = AppliedSigns or {}


local meta = FindMetaTable("Player");
if CLIENT then
	D3D_CreatedFonts = D3D_CreatedFonts or {}
	function D2D_GenerateFontName(BaseName,Size,Outline)
		return tostring(BaseName .. "_" .. Size .. "_" .. tostring(Outline))
	end
	function D2D_HasFont(BaseName,Size,Outline)
		local Name = D2D_GenerateFontName(BaseName,Size,Outline)
		if D3D_CreatedFonts[Name] then
			return true
		else
			return false
		end
	end
	function D2D_HasFontNM(Name)
		if D3D_CreatedFonts[Name] then
			return true
		else
			return false
		end
	end
	
	function D2D_CreateFont(BaseName,Size,Outline)
		if !D3D_CreatedFonts[D2D_GenerateFontName(BaseName,Size,Outline)] then
		
			local FontC = {}
			FontC.font = BaseName
			FontC.size = tonumber(Size)
			FontC.weight = 700
			FontC.outline = Outline or false
			
			surface.CreateFont( D2D_GenerateFontName(BaseName,Size,Outline),FontC)
			
			D3D_CreatedFonts[D2D_GenerateFontName(BaseName,Size,Outline)] = true
		end
	end

local D3D_Sign_EditorPanel = nil
	function Open3DSignEditor(Ent)
		if D3D_Sign_EditorPanel and D3D_Sign_EditorPanel:IsValid() then
			D3D_Sign_EditorPanel:Remove()
		end
		D3D_Sign_EditorPanel = vgui.Create("D3D_Sign_EditorPanel")
		D3D_Sign_EditorPanel:SetSize(ScrW(),ScrH())
		D3D_Sign_EditorPanel:Center()
		D3D_Sign_EditorPanel:MakePopup()
		D3D_Sign_EditorPanel:Install(Ent)
	end
	
	net.Receive( "3DSignEditorOpen_S2C", function( len )
		local TB = net.ReadTable()
		local Ent = ents.GetByIndex(TB.Ent)
		if Ent and Ent:IsValid() then
			Open3DSignEditor(Ent)
		end
	end)
	
	net.Receive( "SyncSign_S2C", function( len )
		local TB = net.ReadTable()
		local Ent = ents.GetByIndex(TB.Ent)
		local PackData = TB.PackData
		if Ent and Ent:IsValid() then
			Ent:SetSignData(PackData)
		end
	end)
	
	
	
	net.Receive( "SyncAllSign_S2C", function( len )
		local TB = net.ReadTable()
		AppliedSigns = TB
		PrintTable(TB)
		for k,v in pairs(ents.FindByClass("d3d_sign")) do
			if TB[v:EntIndex()] then
				v:SetSignData(TB[v:EntIndex()])
			else
			end
		end
	end)


local function OnMouseHover(Panel)
	if !Panel or !Panel:IsValid() then return false end
	
	local X, Y = Panel:LocalToScreen( 0, 0 )
	local SX,SY = Panel:GetSize()
	local MX, MY = gui.MousePos()
			
	if MX < X or MX > X + SX then
		return false
	end
	if MY < Y or MY > Y + SY then
		return false
	end
	return true
end

local PANEL = {}
function PANEL:Init()
	self.Layer = {}
	self.SelectedLayer = 0
	self.CurDraggingThing = false
	self:SetTitle("")
end

function PANEL:About()
	local MaskP = vgui.Create( "DPanel", self)
	MaskP:SetPos(0,0)
	MaskP:SetSize(self:GetWide(),self:GetTall())
	MaskP.Paint = function(slf)
		surface.SetDrawColor( 0,0,0,180 )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
	end
	
		local BGP = vgui.Create( "DPanel", MaskP)
		BGP:SetSize(400,MaskP:GetTall()-200)
		BGP:Center()
		BGP.Paint = function(slf)
				surface.SetDrawColor( 0,10,30,120 )
				surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
											
				surface.SetDrawColor( 200,200,200,255 )
				surface.DrawRect( 0, 0, slf:GetWide(), 1 )
				surface.DrawRect( 0, 0, 1, slf:GetTall() )
				surface.DrawRect( slf:GetWide()-1, 0, 1, slf:GetTall() )
				surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
				draw.SimpleText("Creator", "Kostar_S15", slf:GetWide()/2, 2, Color(255, 255, 255, 255),TEXT_ALIGN_CENTER)
		end
		
	local Lister = vgui.Create("DPanelList", BGP)
	Lister:SetPos(10, 25);
	Lister:SetSize(BGP:GetWide()-20, BGP:GetTall()-65);
	Lister:SetSpacing(4);
	Lister:SetPadding(0);
	Lister:EnableVerticalScrollbar(true);
	Lister:EnableHorizontal(false);
	Lister.Paint = function(slf)
		surface.SetDrawColor( 0,0,0,120 )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
	end
	function Lister:AddText(text)
		local Wrapp = String_Wrap(text,self:GetWide()-20,"Kostar_S20")
		local Labels = vgui.Create("DPanel")
			Labels:SetSize(self:GetWide()-20,#Wrapp*20)
			Labels.Paint = function(slf)
				draw.RoundedBox(0, 2, slf:GetTall()-1, slf:GetWide()-4, 1, Color(255,255,255,10))
				for k,v in pairs(Wrapp) do
					draw.SimpleText(v, "Kostar_S20", 10, -10 + 20*k, Color(150,150,150,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
			end
			self:AddItem(Labels)
	end
	
	Lister:AddText("3D Sign Editor.")
	Lister:AddText("Version 2.0")
	Lister:AddText("Allows you to make various your own signs!")
	Lister:AddText("")
	Lister:AddText("Projector : RocketMania")
	Lister:AddText("Coder : RocketMania")
	Lister:AddText("Steam ID : mupama")
	
				local DSDButton = vgui.Create( "DSDButton", BGP)
				DSDButton:SetPos(230,BGP:GetTall()-35)
				DSDButton:SetSize(120,30)
				DSDButton:SetTexts("Okay!")
				DSDButton:SetHoverAnim(1)
				DSDButton:SetExitAnim(1)
				DSDButton:SetClickAnim(1)
				DSDButton.Click = function(slf)
					MaskP:Remove()
				end
end

function PANEL:CloseWindow()
	self:Remove()
end

function PANEL:LoadSavedFile(SignData)
	self.Layer = {}
	
	self.CanVas:SetSize((SignData.CanVasX or 0),(SignData.CanVasY or 0))
	self.CanVas:Center()
	
	for k,v in pairs(SignData.Layer) do
		if v.Type == "Text" then
			self:AddText(v.Type,v.Text,v.Font,v.Color,v.PosX,v.PosY,v.FontSize,v.OutLine)
		end
		if v.Type == "Box" then
			self:AddBox(v.Type,v.Color,v.PosX,v.PosY,v.SizeX,v.SizeY)
		end
		if v.Type == "HTMLTexture" then
			self:AddHTMLTexture(v.Type,v.PosX,v.PosY,v.SizeX,v.SizeY,v.URL)
		end
		
	end

	
	self:ReBuildLayerList()
	self:ReBuildCanvas()
end

function PANEL:Sign_Apply_MyClient()
	local SignEnt = self.Entity
	
	if SignEnt and SignEnt:IsValid() then
		local PackData = {}
		PackData.Layer = table.Copy(self.Layer)
		PackData.CanVasX = self:GetCanvasSize().x
		PackData.CanVasY = self:GetCanvasSize().y
		
		SignEnt:SetSignData(PackData)
	end
end
function PANEL:Sign_Apply_AllClient()
	local SignEnt = self.Entity
	
		local FilteredLayer = {}
		for k,v in pairs(self.Layer) do
			FilteredLayer[k] = {}
			for a,b in pairs(v) do
				if type(b) != "function" then
					FilteredLayer[k][a] = b
				end
			end
		end
	
		local PackData = {}
		PackData.Layer = FilteredLayer
		PackData.CanVasX = self:GetCanvasSize().x
		PackData.CanVasY = self:GetCanvasSize().y
	
	net.Start( "3DSignApply_C2S" )
		net.WriteTable( {Ent = SignEnt:EntIndex(),PackData = PackData} )
	net.SendToServer()
end

function PANEL:BuildNewCanvas(SizeX,SizeY)
	self.Layer = {}
	self.SelectedLayer = 0

	self.CanVas:SetSize(SizeX,SizeY)
	self.CanVas:Center()
	self:ReBuildLayerList()
	self:ReBuildCanvas()
end

function PANEL:NewFile()
	local MaskP = vgui.Create( "DPanel", self)
	MaskP:SetPos(0,0)
	MaskP:SetSize(self:GetWide(),self:GetTall())
	MaskP.Paint = function(slf)
		surface.SetDrawColor( 0,0,0,180 )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
	end
	
		local BGP = vgui.Create( "DPanel", MaskP)
		BGP:SetSize(400,MaskP:GetTall()-200)
		BGP:Center()
		BGP.Paint = function(slf)
				surface.SetDrawColor( 0,10,30,120 )
				surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
											
				surface.SetDrawColor( 200,200,200,255 )
				surface.DrawRect( 0, 0, slf:GetWide(), 1 )
				surface.DrawRect( 0, 0, 1, slf:GetTall() )
				surface.DrawRect( slf:GetWide()-1, 0, 1, slf:GetTall() )
				surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
				draw.SimpleText("New File", "Kostar_S15", slf:GetWide()/2, 2, Color(255, 255, 255, 255),TEXT_ALIGN_CENTER)
		end
	
	local Lister = vgui.Create("DPanelList", BGP)
	Lister:SetPos(10, 25);
	Lister:SetSize(BGP:GetWide()-20, BGP:GetTall()-65);
	Lister:SetSpacing(4);
	Lister:SetPadding(0);
	Lister:EnableVerticalScrollbar(true);
	Lister:EnableHorizontal(false);
	Lister.Paint = function(slf)
		surface.SetDrawColor( 0,0,0,120 )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
	end
	function Lister:AddText(text)
		local Wrapp = String_Wrap(text,self:GetWide()-20,"Kostar_S15")
		local Labels = vgui.Create("DPanel")
			Labels:SetSize(self:GetWide()-20,#Wrapp*20)
			Labels.Paint = function(slf)
				draw.RoundedBox(0, 2, slf:GetTall()-1, slf:GetWide()-4, 1, Color(255,255,255,100))
				for k,v in pairs(Wrapp) do
					draw.SimpleText(v, "Kostar_S15", 10, -10 + 20*k, Color(150,150,150,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
			end
			self:AddItem(Labels)
	end
	
		-- Canvas Size
		local UPanel = vgui.Create("DPanel")
		UPanel:SetSize(Lister:GetWide(),60)
		UPanel.Paint = function(slf) 
			surface.SetDrawColor( 100,100,255,15 )
			surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
			draw.SimpleText("Canvas Size - X", "Kostar_S15", 0, 0, Color(150, 150, 255, 255))
			
			surface.SetDrawColor( 0,150,255,100 )
			surface.DrawRect( 20, 42, 120, 1 )
			if slf.Wang then
				if math.Round(slf.Wang:GetValue()) <= 0 then
					draw.SimpleText(string.Comma(math.Round(slf.Wang:GetValue())), "Kostar_S20", slf:GetWide()-10, 38, Color(255, 0, 0, 255),TEXT_ALIGN_RIGHT)
				elseif math.Round(slf.Wang:GetValue()) > D3D_Adjust.MaxCanvasSizeX then
					draw.SimpleText(string.Comma(math.Round(slf.Wang:GetValue())), "Kostar_S20", slf:GetWide()-10, 38, Color(255, 0, 0, 255),TEXT_ALIGN_RIGHT)
				else
					draw.SimpleText(string.Comma(math.Round(slf.Wang:GetValue())), "Kostar_S20", slf:GetWide()-10, 38, Color(0, 150, 255, 255),TEXT_ALIGN_RIGHT)
				end
			end
		end

			local Wang = vgui.Create( "DNumberWang", UPanel ) UPanel.Wang = Wang
			Wang:SetPos( 20, 22 )
			Wang:SetMin( 0 )
			Wang:SetMax( D3D_Adjust.MaxCanvasSizeX )
			Wang:SetValue( 500 )
			Wang:SetDecimals( 0 )
			Wang:SetSize(120,20)
			Wang:SetAlpha(255)
			Wang:SetTextColor(Color(0,150,255,255))
			Wang:SetDrawBackground(false)
			Wang:SetCursorColor(Color(0,150,255,255))
		local CanvasSize_X = Wang
		
		Lister:AddItem(UPanel)
		-- END ----==========
		
		
		-- Canvas Size
		local UPanel = vgui.Create("DPanel")
		UPanel:SetSize(Lister:GetWide(),60)
		UPanel.Paint = function(slf) 
			surface.SetDrawColor( 100,100,255,15 )
			surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
			draw.SimpleText("Canvas Size - Y", "Kostar_S15", 0, 0, Color(150, 150, 255, 255))
			
			surface.SetDrawColor( 0,150,255,100 )
			surface.DrawRect( 20, 42, 120, 1 )
			if slf.Wang then
				if math.Round(slf.Wang:GetValue()) <= 0 then
					draw.SimpleText(string.Comma(math.Round(slf.Wang:GetValue())), "Kostar_S20", slf:GetWide()-10, 38, Color(255, 0, 0, 255),TEXT_ALIGN_RIGHT)
				elseif math.Round(slf.Wang:GetValue()) > D3D_Adjust.MaxCanvasSizeY then
					draw.SimpleText(string.Comma(math.Round(slf.Wang:GetValue())), "Kostar_S20", slf:GetWide()-10, 38, Color(255, 0, 0, 255),TEXT_ALIGN_RIGHT)
				else
					draw.SimpleText(string.Comma(math.Round(slf.Wang:GetValue())), "Kostar_S20", slf:GetWide()-10, 38, Color(0, 150, 255, 255),TEXT_ALIGN_RIGHT)
				end
			end
		end

			local Wang = vgui.Create( "DNumberWang", UPanel ) UPanel.Wang = Wang
			Wang:SetPos( 20, 22 )
			Wang:SetMin( 0 )
			Wang:SetMax( D3D_Adjust.MaxCanvasSizeY )
			Wang:SetValue( 250 )
			Wang:SetDecimals( 0 )
			Wang:SetSize(120,20)
			Wang:SetAlpha(255)
			Wang:SetTextColor(Color(0,150,255,255))
			Wang:SetDrawBackground(false)
			Wang:SetCursorColor(Color(0,150,255,255))
		local CanvasSize_Y = Wang
		
		Lister:AddItem(UPanel)
		-- END ----==========
		
		Lister:AddText("Size Limit : " .. D3D_Adjust.MaxCanvasSizeX .. " x " .. D3D_Adjust.MaxCanvasSizeY)
		Lister:AddText("We Recommand 1000x500 Size. its pretty big enough.")
		
				local DSDButton = vgui.Create( "DSDButton", BGP)
				DSDButton:SetPos(230,BGP:GetTall()-35)
				DSDButton:SetSize(120,30)
				DSDButton:SetTexts("Create!")
				DSDButton:SetHoverAnim(1)
				DSDButton:SetExitAnim(1)
				DSDButton:SetClickAnim(1)
				DSDButton.Click = function(slf)
					self:BuildNewCanvas(CanvasSize_X:GetValue(),CanvasSize_Y:GetValue())
					MaskP:Remove()
				end
				
				local DSDButton = vgui.Create( "DSDButton", BGP)
				DSDButton:SetPos(70,BGP:GetTall()-35)
				DSDButton:SetSize(120,30)
				DSDButton:SetTexts("Cancel")
				DSDButton:SetHoverAnim(1)
				DSDButton:SetExitAnim(1)
				DSDButton:SetClickAnim(1)
				DSDButton.Click = function(slf)
					MaskP:Remove()
				end
end

function PANEL:SaveToClient()
	local MaskP = vgui.Create("DPanel",self)
	MaskP:SetSize(self:GetWide(),self:GetTall())
	MaskP:SetPos(0,0)
	MaskP.Paint = function(slf)
		surface.SetDrawColor( 0,0,0,150 )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
	end
	
		local BGP = vgui.Create( "DPanel", MaskP)
		BGP:SetSize(600,300)
		BGP:Center()
		BGP.Paint = function(slf)
				surface.SetDrawColor( 0,10,30,120 )
				surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
											
				surface.SetDrawColor( 0,150,255,255 )
				surface.DrawRect( 0, 0, slf:GetWide(), 1 )
				surface.DrawRect( 0, 0, 1, slf:GetTall() )
				surface.DrawRect( slf:GetWide()-1, 0, 1, slf:GetTall() )
				surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
				draw.SimpleText("Save Sign Data", "Kostar_S15", slf:GetWide()/2, 2, Color(150, 150, 255, 255),TEXT_ALIGN_CENTER)
		end
		
	local Lister = vgui.Create("RXFolderBrowser_Saver", BGP)
	Lister:SetPos(10, 25);
	Lister:SetSize(BGP:GetWide()-20, BGP:GetTall()-65);
	Lister.Mother = self
	Lister.MaskP = MaskP
	Lister:Install()
	Lister:BuildPathCache("signbuilder/")
	Lister:Browse("signbuilder/")
	
		
		local PackData = {}
		PackData.Layer = self.Layer
		PackData.CanVasX = self:GetCanvasSize().x
		PackData.CanVasY = self:GetCanvasSize().y
		
	Lister:SaveThing(util.TableToJSON(PackData))
		

			local MenuButton = vgui.Create( "DSDButton",BGP)
			MenuButton:SetSize(120,30)
			MenuButton:SetPos(BGP:GetWide()-130,BGP:GetTall()-35)
			MenuButton:SetTexts("Cancel")
			MenuButton:SetHoverAnim(1)
			MenuButton:SetExitAnim(1)
			MenuButton:SetClickAnim(1)
			MenuButton.Click = function(slf)
				MaskP:Remove()
				MaskP = nil
			end

		
end
function PANEL:LoadFromClient()
	local MaskP = vgui.Create( "DPanel", self)
	MaskP:SetPos(0,0)
	MaskP:SetSize(self:GetWide(),self:GetTall())
	MaskP.Paint = function(slf)
		surface.SetDrawColor( 0,0,0,180 )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		
	end
	
		local BGP = vgui.Create( "DPanel", MaskP)
		BGP:SetSize(600,300)
		BGP:Center()
		BGP.Paint = function(slf)
			surface.SetDrawColor( 83,83,83,255 )
			surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
											
				surface.SetDrawColor( 200,200,200,255 )
				surface.DrawRect( 0, 0, slf:GetWide(), 1 )
				surface.DrawRect( 0, 0, 1, slf:GetTall() )
				surface.DrawRect( slf:GetWide()-1, 0, 1, slf:GetTall() )
				surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
				draw.SimpleText("Load Saved File", "Kostar_S15", slf:GetWide()/2, 2, Color(150, 150, 255, 255),TEXT_ALIGN_CENTER)
		end
	
	local Lister = vgui.Create("RXFolderBrowser", BGP)
	Lister:SetPos(10, 25);
	Lister:SetSize(BGP:GetWide()-20, BGP:GetTall()-65);
	Lister.Mother = self
	Lister.MaskP = MaskP
	Lister:Install()
	Lister:BuildPathCache("signbuilder/")
	Lister:Browse("signbuilder/")
		
		
		-- END ----==========
				local FilterButton = vgui.Create( "DButton", BGP)
					FilterButton:SetPos(70,BGP:GetTall()-35)
					FilterButton:SetText(" ")
					FilterButton:SetSize(120,30)
					
					FilterButton.DoClick = function()
						MaskP:Remove()
					end
					FilterButton.OnCursorHovered = function(slf) slf.Hover = true end
					FilterButton.OnCursorExited = function(slf) slf.Hover = false end
					
					FilterButton.Paint = function(slf)
									if slf.Hover then
										surface.SetDrawColor( 0,0,0,120 )
										surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
																	
										surface.SetDrawColor( 255,255,255,255 )
										surface.DrawRect( 0, 0, slf:GetWide(), 1 )
										surface.DrawRect( 0, 0, 1, slf:GetTall() )
										surface.DrawRect( slf:GetWide()-1, 0, 1, slf:GetTall() )
										surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
										draw.SimpleText("Cancel", "Kostar_S15", slf:GetWide()/2, 8, Color(150, 150, 255, 255),TEXT_ALIGN_CENTER)
									else
										surface.SetDrawColor( 0,0,0,120 )
										surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
																	
										surface.SetDrawColor( 255,255,255,120 )
										surface.DrawRect( 0, 0, slf:GetWide(), 1 )
										surface.DrawRect( 0, 0, 1, slf:GetTall() )
										surface.DrawRect( slf:GetWide()-1, 0, 1, slf:GetTall() )
										surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
										draw.SimpleText("Cancel", "Kostar_S15", slf:GetWide()/2, 8, Color(150, 150, 255, 255),TEXT_ALIGN_CENTER)
									end
					end
end
function PANEL:Layer_Clone(Layer)
	local LayerDB = self.Layer[Layer]
	if LayerDB then
		if LayerDB.Type == "Text" then
			local ColorK = Color(LayerDB.Color.r,LayerDB.Color.g,LayerDB.Color.b,LayerDB.Color.a)
			self:AddText(LayerDB.Type,LayerDB.Text,LayerDB.Font,ColorK,LayerDB.PosX,LayerDB.PosY,LayerDB.FontSize,LayerDB.OutLine)
		end
		if LayerDB.Type == "Box" then
			local ColorK = Color(LayerDB.Color.r,LayerDB.Color.g,LayerDB.Color.b,LayerDB.Color.a)
			self:AddBox(LayerDB.Type,ColorK,LayerDB.PosX,LayerDB.PosY,LayerDB.SizeX,LayerDB.SizeY)
		end
		if LayerDB.Type == "HTMLTexture" then
			self:AddHTMLTexture(LayerDB.Type,LayerDB.PosX,LayerDB.PosY,LayerDB.SizeX,LayerDB.SizeY,LayerDB.URL)
		end
		
	end
end

function PANEL:Layer_Remove(Layer)
local LayerDB = self.Layer[Layer]
	if LayerDB then
		self.Layer[Layer] = nil
	end
	
	local function MoveFront(Layer)
		if self.Layer[Layer+1] then
			self.Layer[Layer] = self.Layer[Layer+1]
			self.Layer[Layer+1] = nil
			MoveFront(Layer+1)
		end
	end
	MoveFront(Layer)
	
	self:ReBuildLayerList()
	self:ReBuildCanvas()
end

function PANEL:Layer_Move(Layer,amount)

	if Layer <= 1 and amount == -1 then return end
	if Layer >= table.Count(self.Layer) and amount == 1 then return end

local LayerDB = self.Layer[Layer]
	if LayerDB then
	
		local TargetLayerCP = table.Copy(self.Layer[Layer+amount])
		self.Layer[Layer+amount] = self.Layer[Layer]
		self.Layer[Layer] = TargetLayerCP
		
		self.Layer[Layer].Layer = Layer
		self.Layer[Layer+amount].Layer = Layer+amount
	end
	self:ReBuildLayerList()
	self:ReBuildCanvas()
end

function PANEL:ReBuildLayerList()
local MainPanel = self
	self.LayerList:Clear()
	
	
		local LayerButton = vgui.Create("DPanel")
		LayerButton:SetSize(self.LayerList:GetWide(),40)
		LayerButton.Layer = 0
		LayerButton.Paint = function(slf)
			if self.SelectedLayer == slf.Layer then
				surface.SetDrawColor( 255,255,255,100 )
			else
				surface.SetDrawColor( 255,255,255,10 )
			end
			surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
			draw.SimpleText("Background", "BudgetLabel",10, 5 , Color(255 or v.Color.r,255 or v.Color.g,255 or v.Color.b,255 or v.Color.a))
			
		end
		LayerButton.OnMousePressed = function(slf,mousecode)
			if mousecode == MOUSE_LEFT then
				self.SelectedLayer = slf.Layer
				self:ReBuildSettingList(slf.Layer,v)
			end
		end
		self.LayerList:AddItem(LayerButton)
	
	
	local LastLayer = {Layer=0,Data={}}
	for k,v in pairs(self.Layer) do
		if k > LastLayer.Layer then LastLayer = {Layer=k,Data=v} end
		local LayerButton = vgui.Create("DPanel")
		LayerButton:SetSize(self.LayerList:GetWide(),40)
		LayerButton.Layer = k
		LayerButton.Paint = function(slf)
			if self.SelectedLayer == slf.Layer then
				surface.SetDrawColor( 255,255,255,100 )
			else
				surface.SetDrawColor( 255,255,255,20 )
			end
			surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
			draw.SimpleText("No." .. slf.Layer .. " " ..v.Type, "BudgetLabel",10, 5 , Color(255 or v.Color.r,255 or v.Color.g,255 or v.Color.b,255 or v.Color.a))
			if v.Type == "Text" then
				draw.SimpleText(v.Text, "BudgetLabel",20, 20 , Color(v.Color.r,v.Color.g,v.Color.b,v.Color.a))
			end
			
		end
		LayerButton.OnMousePressed = function(slf,mousecode)
			if mousecode == MOUSE_LEFT then
				self.SelectedLayer = slf.Layer
				self:ReBuildSettingList(slf.Layer,v)
			end
			if mousecode == MOUSE_RIGHT then				
				local DSMenu = vgui.Create( "DSMenu" )
					DSMenu:AddOption("Clone Layer",function(slf)
						MainPanel:Layer_Clone(LayerButton.Layer)
					end)
					DSMenu:AddOption("Layer Down",function(slf)
						MainPanel:Layer_Move(LayerButton.Layer,1)
					end)
					DSMenu:AddOption("Layer Up",function(slf)
						MainPanel:Layer_Move(LayerButton.Layer,-1)
					end)
					DSMenu:AddOption("Layer Delete",function(slf)
						MainPanel:Layer_Remove(LayerButton.Layer)
					end)
					
				DSMenu:Open()
			end
		end
		LayerButton.DataBase = v
		self.LayerList:AddItem(LayerButton)
	end
	if LastLayer.Layer > 0 then
		self.SelectedLayer = LastLayer.Layer
		self:ReBuildSettingList(LastLayer.Layer,LastLayer.Data)
	end
end

function PANEL:BuildCanVasElements(Layer,Data)
local MainPanel = self
	// ==================== Canvas - Text
	if Data.Type == "Text" then
		local Elements = vgui.Create( "DPanel",self.CanVas )
		Elements:SetPos(Data:GetPos().x,Data:GetPos().y)
		Elements:SetSize(Data:GetSize().x,Data:GetSize().y)
		Elements.Layer = Layer
		
		function Elements:Update()
			local Data = MainPanel.Layer[self.Layer]
			self:SetPos(Data:GetPos().x,Data:GetPos().y)
			Elements:SetSize(Data:GetSize().x,Data:GetSize().y)
			self:SetAlpha(Data.Color.a)
		end
		
		Elements.Paint = function(slf)
			D2D_CreateFont(Data.Font,Data.FontSize,Data.OutLine)
			local FontName = D2D_GenerateFontName(Data.Font,Data.FontSize,Data.OutLine)
				draw.SimpleText(Data.Text, FontName,0, 0 , Data.Color)
						
			if self.SelectedLayer == slf.Layer then
				surface.SetDrawColor( 255,255,255,255 )
				surface.DrawRect( 0, 0, slf:GetWide(), 1 )
				surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
				surface.DrawRect( 0, 0, 1, slf:GetTall() )
				surface.DrawRect( slf:GetWide()-1, 0, 1, slf:GetTall() )
			end
		end
		Elements.Think = function(slf)
			if OnMouseHover(slf) and input.IsMouseDown(MOUSE_LEFT) and self.SelectedLayer == slf.Layer and !MainPanel.CurDraggingThing then
				if !slf.Clicked then
					local X,Y = slf:GetPos()
					local XX,YY = 0,0
					slf.LastPos = { x = X+XX,y=Y+YY }
					slf.LastDataPos = Data:GetPos()
					slf.LastMousePos = { x = gui.MouseX() , y = gui.MouseY() }
				end
				slf.Clicked = true
			end
			if input.IsMouseDown(MOUSE_LEFT) and slf.Clicked and slf.LastPos and slf.LastMousePos and slf.LastDataPos then
				MainPanel.CurDraggingThing = Elements
				local MX, MY = gui.MousePos()
				slf:SetPos(slf.LastPos.x + (MX-slf.LastMousePos.x) , slf.LastPos.y + (MY-slf.LastMousePos.y))
				Data:SetPos(slf.LastDataPos.x + (MX-slf.LastMousePos.x) , slf.LastDataPos.y + (MY-slf.LastMousePos.y))
				
				if Data:GetPos().y < 0 then 
					slf:SetPos(Data:GetPos().x,0)
					Data:SetPos(Data:GetPos().x,0) 
				end
				if (Data:GetPos().y + slf:GetTall()) > self.CanVas:GetTall() then 
					slf:SetPos(Data:GetPos().x,self.CanVas:GetTall()-slf:GetTall())
					Data:SetPos(Data:GetPos().x,self.CanVas:GetTall()-slf:GetTall()) 
				end
				
				if Data:GetPos().x < 0 then 
					slf:SetPos(0,Data:GetPos().y)
					Data:SetPos(0,Data:GetPos().y)
				end
				if (Data:GetPos().x + slf:GetWide()) > self.CanVas:GetWide() then 
					slf:SetPos(self.CanVas:GetWide()-slf:GetWide(),Data:GetPos().y)
					Data:SetPos(self.CanVas:GetWide()-slf:GetWide(),Data:GetPos().y)
				end
			end
			if !input.IsMouseDown(MOUSE_LEFT) then
				if slf.Clicked then
					slf.Clicked = false
				end
			end
		end
		self.CanVas.Elements[Layer] = Elements
	end
	
	
	// ==================== Canvas - Box --
	if Data.Type == "Box" then
		local Elements = vgui.Create( "DPanel",self.CanVas )
		Elements:SetPos(Data:GetPos().x,Data:GetPos().y)
		Elements:SetSize(Data:GetSize().x,Data:GetSize().y)
		Elements.Layer = Layer
		
		function Elements:Update()
			local Data = MainPanel.Layer[self.Layer]
			self:SetPos(Data:GetPos().x,Data:GetPos().y)
			Elements:SetSize(Data:GetSize().x,Data:GetSize().y)
			self:SetAlpha(Data.Color.a)
		end
		
		Elements.Paint = function(slf)
			surface.SetDrawColor( Data.Color.r , Data.Color.g , Data.Color.b , Data.Color.a )
			surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
			if self.SelectedLayer == slf.Layer then
				surface.SetDrawColor( 255,255,255,255 )
				surface.DrawRect( 0, 0, slf:GetWide(), 1 )
				surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
				surface.DrawRect( 0, 0, 1, slf:GetTall() )
				surface.DrawRect( slf:GetWide()-1, 0, 1, slf:GetTall() )
			end
		end
		Elements.Think = function(slf)
			if OnMouseHover(slf) and input.IsMouseDown(MOUSE_LEFT) and self.SelectedLayer == slf.Layer and !MainPanel.CurDraggingThing then
				if !slf.Clicked then
					local X,Y = slf:GetPos()
					local XX,YY = 0,0
					slf.LastPos = { x = X+XX,y=Y+YY }
					slf.LastDataPos = Data:GetPos()
					slf.LastMousePos = { x = gui.MouseX() , y = gui.MouseY() }
				end
				slf.Clicked = true
			end
			if input.IsMouseDown(MOUSE_LEFT) and slf.Clicked and slf.LastPos and slf.LastMousePos and slf.LastDataPos then
				MainPanel.CurDraggingThing = Elements
				local MX, MY = gui.MousePos()
				slf:SetPos(slf.LastPos.x + (MX-slf.LastMousePos.x) , slf.LastPos.y + (MY-slf.LastMousePos.y))
				Data:SetPos(slf.LastDataPos.x + (MX-slf.LastMousePos.x) , slf.LastDataPos.y + (MY-slf.LastMousePos.y))
				
				if Data:GetPos().y < 0 then 
					slf:SetPos(Data:GetPos().x,0)
					Data:SetPos(Data:GetPos().x,0) 
				end
				if (Data:GetPos().y + slf:GetTall()) > self.CanVas:GetTall() then 
					slf:SetPos(Data:GetPos().x,self.CanVas:GetTall()-slf:GetTall())
					Data:SetPos(Data:GetPos().x,self.CanVas:GetTall()-slf:GetTall()) 
				end
				
				if Data:GetPos().x < 0 then 
					slf:SetPos(0,Data:GetPos().y)
					Data:SetPos(0,Data:GetPos().y)
				end
				if (Data:GetPos().x + slf:GetWide()) > self.CanVas:GetWide() then 
					slf:SetPos(self.CanVas:GetWide()-slf:GetWide(),Data:GetPos().y)
					Data:SetPos(self.CanVas:GetWide()-slf:GetWide(),Data:GetPos().y)
				end
			end
			if !input.IsMouseDown(MOUSE_LEFT) then
				if slf.Clicked then
					slf.Clicked = false
				end
			end
		end
		self.CanVas.Elements[Layer] = Elements
	end

	// ==================== Canvas - HTMLTexture --
	if Data.Type == "HTMLTexture" then
		local Elements = vgui.Create( "SEHTML",self.CanVas )
		Elements:SetPos(Data:GetPos().x,Data:GetPos().y)
		Elements:SetSize(Data:GetSize().x,Data:GetSize().y)
		Elements.Layer = Layer
		Elements.LastControlTime = CurTime()
		Elements:Install()
		
		function Elements:Update()
			local Data = MainPanel.Layer[self.Layer]
			self:SetPos(Data:GetPos().x,Data:GetPos().y)
			Elements:SetSize(Data:GetSize().x,Data:GetSize().y)
			self.LastControlTime = CurTime()
			self:SetHTML(
				[[
					<style type="text/css">
						html 
						{			
							overflow:hidden;
							margin: -8px -8px;
						}
					</style>
					
					<body>
						<img src="]] .. Data.URL .. [[" alt="" width="]] .. self:GetWide() ..[[" height="]] .. self:GetTall() .. [[" />
					</body>
				]]
			)
		end
			Elements:SetHTML(
				[[
					<style type="text/css">
						html 
						{			
							overflow:hidden;
							margin: -8px -8px;
						}
					</style>
					
					<body>
						<img src="]] .. Data.URL .. [[" alt="" width="]] .. Elements:GetWide() ..[[" height="]] .. Elements:GetTall() .. [[" />
					</body>
				]]
			)
		Elements.Think = function(slf)
			if OnMouseHover(slf) and input.IsMouseDown(MOUSE_LEFT) and self.SelectedLayer == slf.Layer and !MainPanel.CurDraggingThing then
				if !slf.Clicked then
					local X,Y = slf:GetPos()
					local XX,YY = 0,0
					slf.LastPos = { x = X+XX,y=Y+YY }
					slf.LastDataPos = Data:GetPos()
					slf.LastMousePos = { x = gui.MouseX() , y = gui.MouseY() }
				end
				slf.Clicked = true
			end
			if input.IsMouseDown(MOUSE_LEFT) and slf.Clicked and slf.LastPos and slf.LastMousePos and slf.LastDataPos then
				MainPanel.CurDraggingThing = Elements
				local MX, MY = gui.MousePos()
				slf:SetPos(slf.LastPos.x + (MX-slf.LastMousePos.x) , slf.LastPos.y + (MY-slf.LastMousePos.y))
				Data:SetPos(slf.LastDataPos.x + (MX-slf.LastMousePos.x) , slf.LastDataPos.y + (MY-slf.LastMousePos.y))
				
				if Data:GetPos().y < 0 then 
					slf:SetPos(Data:GetPos().x,0)
					Data:SetPos(Data:GetPos().x,0) 
				end
				if (Data:GetPos().y + slf:GetTall()) > self.CanVas:GetTall() then 
					slf:SetPos(Data:GetPos().x,self.CanVas:GetTall()-slf:GetTall())
					Data:SetPos(Data:GetPos().x,self.CanVas:GetTall()-slf:GetTall()) 
				end
				
				if Data:GetPos().x < 0 then 
					slf:SetPos(0,Data:GetPos().y)
					Data:SetPos(0,Data:GetPos().y)
				end
				if (Data:GetPos().x + slf:GetWide()) > self.CanVas:GetWide() then 
					slf:SetPos(self.CanVas:GetWide()-slf:GetWide(),Data:GetPos().y)
					Data:SetPos(self.CanVas:GetWide()-slf:GetWide(),Data:GetPos().y)
				end
			end
			if !input.IsMouseDown(MOUSE_LEFT) then
				if slf.Clicked then
					slf.Clicked = false
				end
			end
		end
		self.CanVas.Elements[Layer] = Elements
	end

	
end

function PANEL:ReBuildCanvas()
	for k,v in pairs(self.CanVas.Elements) do
		v:Remove()
	end
	self.CanVas.Elements = {}
	for k,v in pairs(self.Layer) do
		self:BuildCanVasElements(k,v)
	end
end

function PANEL:ReBuildSettingList(Layer,Data)
	self.SettingMenuLister:Clear()
	
	if Layer == 0 then
		return
	end
	
	if Data.Type == "Text" then
		self.SettingMenuLister:AddSubTitle("Text Element Editer")
		self.SettingMenuLister:AddText("Text Setting")
		local TE = self.SettingMenuLister:AddTextEntry()
		TE.OnTextChanged = function(slf)
			Data.Text = slf:GetValue()
			if self.CanVas.Elements[Data.Layer] then
				self.CanVas.Elements[Data.Layer]:Update()
			end
		end
		TE:SetText(Data.Text)
		
		self.SettingMenuLister:AddSubTitle("Font Customizer")
		
		local MultiB = self.SettingMenuLister:CreateMultiChooser("Choose Font")
		MultiB.OnValueChanged = function(slf,value)
			Data.Font = value
			if self.CanVas.Elements[Data.Layer] then
				self.CanVas.Elements[Data.Layer]:Update()
			end
		end
			for k,v in pairs(D3D_Adjust.Font) do
				MultiB:AddItem(k,v)
			end
		if MultiB:HasItem(Data.Font) then MultiB:SetItem(Data.Font) end


		local Color_R = self.SettingMenuLister:CreateSlider("Font Size",10,D3D_Adjust.MaxFontSize,0)
		Color_R:SetValue(Data.FontSize)
		Color_R.OnValueChanged = function(slf,num)
			Data.FontSize = num
			if self.CanVas.Elements[Data.Layer] then
				self.CanVas.Elements[Data.Layer]:Update()
			end
		end
		local OutLine = self.SettingMenuLister:CreateToggler("OutLine")
		OutLine:SetValue(Data.OutLine)
		OutLine.OnValueChanged = function(slf,value)
			Data.OutLine = value
			if self.CanVas.Elements[Data.Layer] then
				self.CanVas.Elements[Data.Layer]:Update()
			end
		end
		
				
	-- 컬러 믹서로 변경
	local CMR = vgui.Create( "DColorMixer");
	CMR:SetSize( self.SettingMenuLister:GetWide(), 160);
	CMR:SetPos( 50, 50 );
	CMR:SetColor(Color(255,0,255,255))
	CMR.ValueChanged = function(slf,color)
		Data.Color = color
		if self.CanVas.Elements[Data.Layer] then
			self.CanVas.Elements[Data.Layer]:Update()
		end
	end
	self.SettingMenuLister:AddItem(CMR)	
	end
	
	
	if Data.Type == "Box" then
		self.SettingMenuLister:AddSubTitle("Box Element Editer")
		self.SettingMenuLister:AddSubTitle("Size Edit")
		local Size_X = self.SettingMenuLister:CreateSlider("Size - X",0,self.CanVas:GetWide(),0)
		Size_X:SetValue(Data.SizeX)
		Size_X.OnValueChanged = function(slf,num)
			Data.SizeX = num
			if Data.PosX + Data.SizeX > self.CanVas:GetWide() then
				Data.SizeX = self.CanVas:GetWide() - Data.PosX
				Size_X:SetValue(Data.SizeX)
			end
			if self.CanVas.Elements[Data.Layer] then
				self.CanVas.Elements[Data.Layer]:Update()
			else
			end
		end
		local Size_Y = self.SettingMenuLister:CreateSlider("Size - Y",0,self.CanVas:GetTall(),0)
		Size_Y:SetValue(Data.SizeY)
		Size_Y.OnValueChanged = function(slf,num)
			Data.SizeY = num
			if Data.PosY + Data.SizeY > self.CanVas:GetTall() then
				Data.SizeY = self.CanVas:GetTall() - Data.PosY
				Size_Y:SetValue(Data.SizeY)
			end
			if self.CanVas.Elements[Data.Layer] then
				self.CanVas.Elements[Data.Layer]:Update()
			end
		end
		
		self.SettingMenuLister:AddSubTitle("Color Edit")
		local CMR = vgui.Create( "DColorMixer");
		CMR:SetSize( self.SettingMenuLister:GetWide(), 160);
		CMR:SetPos( 50, 50 );
		CMR:SetColor(Data.Color or Color(255,0,255,255))
		CMR.ValueChanged = function(slf,color)
			Data.Color = color
			if self.CanVas.Elements[Data.Layer] then
				self.CanVas.Elements[Data.Layer]:Update()
			end
		end
		self.SettingMenuLister:AddItem(CMR)	
		
	end
	
	if Data.Type == "HTMLTexture" then
		self.SettingMenuLister:AddSubTitle("HTMLTexture Editer")
		
		local TE = self.SettingMenuLister:AddTextEntry()
		TE.OnTextChanged = function(slf)
			Data.URL = slf:GetValue()
			if self.CanVas.Elements[Data.Layer] then
				self.CanVas.Elements[Data.Layer]:Update()
			end
		end
		TE:SetText(Data.URL)
			
		self.SettingMenuLister:AddSubTitle("Size Edit")
		local Size_X = self.SettingMenuLister:CreateSlider("Size - X",0,self.CanVas:GetWide(),0)
		Size_X:SetValue(Data.SizeX)
		Size_X.OnValueChanged = function(slf,num)
			Data.SizeX = num
			if Data.PosX + Data.SizeX > self.CanVas:GetWide() then
				Data.SizeX = self.CanVas:GetWide() - Data.PosX
				Size_X:SetValue(Data.SizeX)
			end
			if self.CanVas.Elements[Data.Layer] then
				self.CanVas.Elements[Data.Layer]:Update()
			else
			end
		end
		local Size_Y = self.SettingMenuLister:CreateSlider("Size - Y",0,self.CanVas:GetTall(),0)
		Size_Y:SetValue(Data.SizeY)
		Size_Y.OnValueChanged = function(slf,num)
			Data.SizeY = num
			if Data.PosY + Data.SizeY > self.CanVas:GetTall() then
				Data.SizeY = self.CanVas:GetTall() - Data.PosY
				Size_Y:SetValue(Data.SizeY)
			end
			if self.CanVas.Elements[Data.Layer] then
				self.CanVas.Elements[Data.Layer]:Update()
			end
		end
		
	end
	
	
	
end

function PANEL:AddText(Type,Text,Font,ColorK,PosX,PosY,FontSize,OutLine)
	local DataBase = {}
	DataBase.Type = Type or "Text"
	DataBase.Text = Text or "Text"
	DataBase.Font = Font or "Kostar"
	DataBase.Color = ColorK or Color(255,255,255,255)
	DataBase.PosX = PosX or 0
	DataBase.PosY = PosY or 0
	DataBase.FontSize = FontSize or 20
	DataBase.OutLine = OutLine or false
	function DataBase:GetPos()
		return {x=self.PosX,y=self.PosY}
	end
	function DataBase:SetPos(x,y)
		self.PosX = x
		self.PosY = y
	end
	function DataBase:GetSize()
		D2D_CreateFont(self.Font,self.FontSize,self.OutLine)
		local FontName = D2D_GenerateFontName(self.Font,self.FontSize,self.OutLine)
		surface.SetFont(FontName)
		local x,y = surface.GetTextSize(self.Text)
		return {x=x,y=y}
	end
	
	function FindEmptyLayer(Num)
		if self.Layer[Num] then
			return FindEmptyLayer(Num+1)
		else
			return Num
		end
	end
	local EmptyL = FindEmptyLayer(1)
	self.Layer[EmptyL] = DataBase
	DataBase.Layer = EmptyL
	
	self:ReBuildLayerList()
	self:ReBuildCanvas()
end


function PANEL:AddBox(Type,ColorK,PosX,PosY,SizeX,SizeY)
	local DataBase = {}
	DataBase.Type = Type or "Box"
	DataBase.Color = ColorK or Color(255,255,255,255)
	DataBase.PosX = PosX or 0
	DataBase.PosY = PosY or 0
	DataBase.SizeX = SizeX or 100
	DataBase.SizeY = SizeY or 50
	function DataBase:GetPos()
		return {x=self.PosX,y=self.PosY}
	end
	function DataBase:SetPos(x,y)
		self.PosX = x
		self.PosY = y
	end
	function DataBase:GetSize()
		return {x=self.SizeX,y=self.SizeY}
	end
	function DataBase:SetSize(x,y)
		self.SizeX = x
		self.SizeY = y
	end
	
	function FindEmptyLayer(Num)
		if self.Layer[Num] then
			return FindEmptyLayer(Num+1)
		else
			return Num
		end
	end
	local EmptyL = FindEmptyLayer(1)
	self.Layer[EmptyL] = DataBase
	DataBase.Layer = EmptyL
	
	self:ReBuildLayerList()
	self:ReBuildCanvas()
end

function PANEL:AddHTMLTexture(Type,PosX,PosY,SizeX,SizeY,URL)
	local DataBase = {}
	DataBase.Type = Type or "HTMLTexture"
	DataBase.PosX = PosX or 0
	DataBase.PosY = PosY or 0
	DataBase.SizeX = SizeX or 100
	DataBase.SizeY = SizeY or 50
	DataBase.URL = URL or ""
	function DataBase:GetPos()
		return {x=self.PosX,y=self.PosY}
	end
	function DataBase:SetPos(x,y)
		self.PosX = x
		self.PosY = y
	end
	function DataBase:GetSize()
		return {x=self.SizeX,y=self.SizeY}
	end
	function DataBase:SetSize(x,y)
		self.SizeX = x
		self.SizeY = y
	end
	
	function FindEmptyLayer(Num)
		if self.Layer[Num] then
			return FindEmptyLayer(Num+1)
		else
			return Num
		end
	end
	local EmptyL = FindEmptyLayer(1)
	self.Layer[EmptyL] = DataBase
	DataBase.Layer = EmptyL
	
	self:ReBuildLayerList()
	self:ReBuildCanvas()
end



function PANEL:GetCanvasSize()
	local X,Y = self.CanVas:GetSize()
	return {x=X,y=Y}
end

function PANEL:Install(Ent)
local MainPanel = self
	self.Entity = Ent
	self:SetDraggable(false)
	self:ShowCloseButton(false)
		
	self.TopPanel = vgui.Create( "DPanel" , self)
	self.TopPanel:SetPos(2,2)
	self.TopPanel:SetSize( self:GetWide()-4,25 )
	self.TopPanel.Paint = function(slf)
		surface.SetDrawColor( 50,50,50,255 )
		surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
		draw.SimpleText("SE", "SansationOut_S25", 10,0, Color(0,255,200,255))
	end
	
		local MenuButton = vgui.Create( "DSDButton", self.TopPanel)
		MenuButton:SetPos(self.TopPanel:GetWide()-self.TopPanel:GetTall(),0)
		MenuButton:SetSize(self:GetTall(),self:GetTall())
		MenuButton:SetTexts("")
		MenuButton:SetHoverAnim(1)
		MenuButton:SetExitAnim(1)
		MenuButton:SetClickAnim(1)
		MenuButton:SetBoarderColor(Color(0,0,0,0))
		MenuButton.Click = function(slf)
			self:Remove()
		end
		MenuButton.PaintOverlay = function(slf)
		draw.SimpleText("X", "Kostar_S20", 0,0, Color(255,255,255,255), TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
		end
	
	local CanVasBG = vgui.Create( "DPanel", self )
	CanVasBG:SetPos(20,50)
	CanVasBG:SetSize(self:GetWide()-340,self:GetTall()-60)
	CanVasBG.OnCursorEntered = function(slf) slf.Hover = true end
	CanVasBG.OnCursorExited = function(slf) slf.Hover = false end
	CanVasBG.Paint = function(slf)
		surface.SetDrawColor( 100,100,100,255 )
		surface.DrawRect( 0, 0, slf:GetWide(), 1 )
		surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
		surface.DrawRect( 0, 0, 1, slf:GetTall() )
		surface.DrawRect( slf:GetWide()-1, 0, 1, slf:GetTall() )
						
		surface.SetDrawColor( 38,38,38,255 )
		surface.DrawRect( 1, 1, slf:GetWide()-2, slf:GetTall()-2 )
		
		draw.SimpleText("CanVas X : " .. self:GetCanvasSize().x, "KostarOut_S15", 10,5, Color(255,255,255,255))
		draw.SimpleText("CanVas y : " .. self:GetCanvasSize().y, "KostarOut_S15", 10,25, Color(255,255,255,255))
		
	end
	self.CanVasBG = CanVasBG
	
	self.CanVas = vgui.Create( "DPanel", CanVasBG )
	self.CanVas:SetSize(math.min(500,D3D_Adjust.MaxCanvasSizeX),math.min(250,D3D_Adjust.MaxCanvasSizeY))
	self.CanVas:Center()
	self.CanVas.Elements = {}
	self.CanVas.OnCursorEntered = function(slf) slf.Hover = true end
	self.CanVas.OnCursorExited = function(slf) slf.Hover = false end
	self.CanVas.Paint = function(slf)
		surface.SetDrawColor( 100,100,100,70 )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		
		if MainPanel.SelectedLayer then
			if slf.Elements[MainPanel.SelectedLayer] then
				local PX,PY = slf.Elements[MainPanel.SelectedLayer]:GetPos()
				PX = PX + slf.Elements[MainPanel.SelectedLayer]:GetWide()/2
				PY = PY + slf.Elements[MainPanel.SelectedLayer]:GetTall()/2
				
					surface.SetDrawColor( 255,255,255,50 )
		
					surface.DrawRect( PX, 0, 1, slf:GetTall() )
					surface.DrawRect( 0, PY, slf:GetWide(), 1 )
			end
		end
	end
		self.CanVas.Think = function(slf)
			if MainPanel.SelectedLayer == 0 then 
			--	(OnMouseHover(slf) and input.IsMouseDown(MOUSE_LEFT) and slf.Hover and !MainPanel.CurDraggingThing) 
				if !slf.Clicked then
					local X,Y = slf:GetPos()
					local XX,YY = 0,0
					slf.LastPos = { x = X+XX,y=Y+YY }
					slf.LastMousePos = { x = gui.MouseX() , y = gui.MouseY() }
				end
				slf.Clicked = true
			end
			if input.IsMouseDown(MOUSE_LEFT) and slf.Clicked and slf.LastPos and slf.LastMousePos then
				MainPanel.CurDraggingThing = slf
				local MX, MY = gui.MousePos()
				slf:SetPos(slf.LastPos.x + (MX-slf.LastMousePos.x) , slf.LastPos.y + (MY-slf.LastMousePos.y))
			end
			if !input.IsMouseDown(MOUSE_LEFT) then
				if slf.Clicked then
					slf.Clicked = false
				end
			end
		end
		CanVasBG.Think = function(slf)
			if OnMouseHover(slf) and input.IsMouseDown(MOUSE_LEFT) and slf.Hover and !MainPanel.CurDraggingThing then
				if !slf.Clicked then
					local X,Y = self.CanVas:GetPos()
					local XX,YY = 0,0
					self.CanVas.LastPos = { x = X+XX,y=Y+YY }
					slf.LastMousePos = { x = gui.MouseX() , y = gui.MouseY() }
				end
				slf.Clicked = true
			end
			if input.IsMouseDown(MOUSE_LEFT) and slf.Clicked and self.CanVas.LastPos and slf.LastMousePos then
				MainPanel.CurDraggingThing = slf
				local MX, MY = gui.MousePos()
				self.CanVas:SetPos(self.CanVas.LastPos.x + (MX-slf.LastMousePos.x) , self.CanVas.LastPos.y + (MY-slf.LastMousePos.y))
			end
			if !input.IsMouseDown(MOUSE_LEFT) then
				if slf.Clicked then
					slf.Clicked = false
				end
			end
		end
	
	local SettingBG = vgui.Create( "DPanel" , self)
	SettingBG:SetSize( 300 , self:GetTall()/2-70)
	SettingBG:SetPos( self:GetWide() - 310,50)
	SettingBG.Paint = function(slf)
	
		surface.SetDrawColor( 50,50,50,255 )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		
		surface.SetDrawColor( 100,100,100,255 )
		surface.DrawRect( 0, 0, slf:GetWide(), 1 )
		surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
		surface.DrawRect( 0, 0, 1, slf:GetTall() )
		surface.DrawRect( slf:GetWide()-1, 0, 1, slf:GetTall() )
		
		draw.SimpleText("Elements Setting", "Kostar_S20", 20,2, Color(255,255,255,255))
	end
	
	self.SettingMenuLister = vgui.Create( "DPanelList", SettingBG )
	self.SettingMenuLister:SetSize( 300 , SettingBG:GetTall()-30)
	self.SettingMenuLister:SetPos( 5,25)
	self.SettingMenuLister:SetSpacing( 0 ) -- Spacing between items
	self.SettingMenuLister:EnableHorizontal( false ) -- Only vertical items
	self.SettingMenuLister:EnableVerticalScrollbar( true ) -- Allow scrollbar if you exceed the Y axis
	function self.SettingMenuLister:AddSubTitle(text)
		local Wrapp = String_Wrap(text,self:GetWide()-20,"Kostar_S15")
		local Labels = vgui.Create("DPanel")
			Labels:SetSize(self:GetWide()-20,#Wrapp*20)
			Labels.Paint = function(slf)
				draw.RoundedBox(0, 2, slf:GetTall()-1, slf:GetWide()-4, 1, Color(0,255,255,20))
				for k,v in pairs(Wrapp) do
					draw.SimpleText(v, "Kostar_S25", 10, -10 + 20*k, Color(0,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
			end
		self:AddItem(Labels)
	end
	function self.SettingMenuLister:AddText(text)
		local Wrapp = String_Wrap(text,self:GetWide()-20,"Kostar_S15")
		local Labels = vgui.Create("DPanel")
			Labels:SetSize(self:GetWide()-20,#Wrapp*20)
			Labels.Paint = function(slf)
				draw.RoundedBox(0, 2, slf:GetTall()-1, slf:GetWide()-4, 1, Color(255,255,255,100))
				for k,v in pairs(Wrapp) do
					draw.SimpleText(v, "Kostar_S15", 10, -10 + 20*k, Color(150,150,150,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				end
			end
			self:AddItem(Labels)
	end
	function self.SettingMenuLister:AddTextEntry()
		local BG = vgui.Create("DPanel")
			BG:SetSize(self:GetWide()-20,20)
			BG.Paint = function(slf)
				surface.SetDrawColor( 0,0,0,100 )
				surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
				surface.SetDrawColor( 255,255,255,255 )
				surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
				surface.DrawRect( slf:GetWide()-1, 0, 1, slf:GetTall() )			
			end
		local Labels = vgui.Create("DTextEntry",BG)
			Labels:SetPos(0,0)
			Labels:SetSize(BG:GetWide(),20)
			Labels:SetAllowNonAsciiCharacters(true)
			Labels:SetDrawBackground(false)
			Labels:SetTextColor(Color(255,255,255,255))
			Labels:SetCursorColor(Color(255,255,255,255))
			
			self:AddItem(BG)
			return Labels
	end
	
	function self.SettingMenuLister:CreateSlider(text,min,max,demical)
		local BG = vgui.Create("DPanel")
		BG:SetSize(self:GetWide(),45)
		BG.Paint = function(slf)
			draw.RoundedBox(0, 2, slf:GetTall()-1, slf:GetWide()-4, 1, Color(255,255,255,100))
		end
		
			local Slider = vgui.Create("DSliders",BG)
				Slider:SetSize(self:GetWide(),45)
				Slider:SetMax(max)
				Slider:SetMin(min)
				
				Slider.Last = min
				Slider:SetName(text)
				Slider:SetUp()
				Slider:SetValue(min)

				Slider:SetDemical(demical)
			self:AddItem(BG)
		return Slider
	end
	function self.SettingMenuLister:CreateToggler(PrintName)
			local BG = vgui.Create( "DButton" )
			BG:SetSize(self:GetWide()-20,40)
			BG:SetText(" ")
			BG.Value = false
			BG.Paint = function(slf) 
				draw.RoundedBox(0, 2, slf:GetTall()-1, slf:GetWide()-4, 1, Color(255,255,255,100))
				draw.SimpleText( PrintName , "Kostar_S20", 10, 20, Color(220,220,220,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				if slf.Value then
					draw.SimpleText( " (O) ", "Kostar_S20", slf:GetWide() - 10, 20, Color(0,150,220,255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				else
					draw.SimpleText( " (X) " , "Kostar_S20", slf:GetWide() - 10, 20, Color(220,150,0,255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				end
			end
			function BG:SetValue(bool)
				self.Value = bool
			end
			function BG:OnValueChanged()
			
			end
			BG.DoClick = function(slf) --
				slf.Value = !slf.Value
				slf:OnValueChanged(slf.Value)
			end
			self:AddItem(BG)
			return BG
	end
	function self.SettingMenuLister:CreateMultiChooser(PrintName)
			local BG = vgui.Create( "DPanel" )
			BG:SetSize(self:GetWide()-20,40)
			BG.Items = {}
			
			BG.LeftMenuLister = vgui.Create( "DPanelList", BG )
			BG.LeftMenuLister:SetPos( 10,30 )
			BG.LeftMenuLister:SetSize( BG:GetWide()-20, BG:GetTall()-20 )
			BG.LeftMenuLister:SetSpacing( 0 ) -- Spacing between items
			BG.LeftMenuLister:EnableHorizontal( false ) -- Only vertical items
			BG.LeftMenuLister:EnableVerticalScrollbar( true ) -- Allow scrollbar if you exceed the Y axis
			BG.LeftMenuLister.Paint = function(slf) 
			end
			
			BG.Paint = function(slf) 
				draw.RoundedBox(0, 2, slf:GetTall()-1, slf:GetWide()-4, 1, Color(255,255,255,100))
				draw.SimpleText(PrintName or "Multi Chooser", "Kostar_S15", 10, 0, Color(0,255,220,255))
			end
			function BG:HasItem(Item)
				if self.Items[Item] then
					return true
				else
					return false
				end
			end
			function BG:SetItem(Item)
				if !self:HasItem(Item) then return end
				self.Value = Item
			end
			function BG:OnValueChanged(name)
			
			end
			function BG:AddItem(Item,PrintName)
				self.Items[Item] = PrintName
				local Items = vgui.Create("DButton")
				Items:SetSize(self.LeftMenuLister:GetWide(),20)
				Items:SetText(" ")
				Items.Paint = function(slf) 
					draw.RoundedBox(0, 2, slf:GetTall()-1, slf:GetWide()-4, 1, Color(255,255,255,20))
					if self.Value == Item then
						draw.SimpleText(PrintName, "Kostar_S20", slf:GetWide()/2, 0, Color(220,255,220,255), TEXT_ALIGN_CENTER)
					else
						draw.SimpleText(PrintName, "Kostar_S20", slf:GetWide()/2, 0, Color(0,150,220,100), TEXT_ALIGN_CENTER)
					end
				end
				Items.DoClick = function(slf)
					self.Value = Item
					BG:OnValueChanged(Item)
				end
				
				self.LeftMenuLister:AddItem(Items)
				
				-- Rebuild
				local ItemAmounts = #self.LeftMenuLister:GetItems()
				ItemAmounts = math.min(ItemAmounts,10)
				
				BG:SetTall(ItemAmounts*20 +40)
				BG.LeftMenuLister:SetTall(ItemAmounts*20)
				
			end
			self:AddItem(BG)
			return BG
	end
	
	
	local LayerBG = vgui.Create( "DPanel" , self)
	LayerBG:SetSize( 300 , self:GetTall()/2)
	LayerBG:SetPos( self:GetWide() - 310,self:GetTall()/2-10)
	LayerBG.Paint = function(slf)
	
		surface.SetDrawColor( 50,50,50,255 )
		surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		
		surface.SetDrawColor( 100,100,100,255 )
		surface.DrawRect( 0, 0, slf:GetWide(), 1 )
		surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
		surface.DrawRect( 0, 0, 1, slf:GetTall() )
		surface.DrawRect( slf:GetWide()-1, 0, 1, slf:GetTall() )
		
		
		draw.SimpleText("Layers", "Kostar_S20", 20,2, Color(255,255,255,255))
	end
	
	self.LayerList = vgui.Create( "DPanelList" , LayerBG)
	self.LayerList:SetSize( 290 , LayerBG:GetTall()-30)
	self.LayerList:SetPos( 5,25)
	self.LayerList:SetSpacing(2);
	self.LayerList:SetPadding(2);
	self.LayerList:EnableVerticalScrollbar(true);
	self.LayerList:EnableHorizontal(false);
	self.LayerList.Paint = function(slf)

	end
	
	local MainCategory = {}
	local function CreateCategory(PrintName,IsTree)
		local Data = {}
			Data.PrintName = PrintName
			Data.Flip = true
			Data.Items = {}
			function Data:AddItem(PrintName,Func)
				local IB = {}
				IB.PrintName = PrintName
				IB.Func = Func
				table.insert(Data.Items,IB)
				return IB
			end
			function Data:AddSubTitle(PrintName)
				local IB = {}
				IB.PrintName = PrintName
				IB.IsSubTitle = true
				table.insert(Data.Items,IB)
				return IB
			end
			
		if !IsTree then
			table.insert(MainCategory,Data)
		end
		return Data
	end
	
	local Category = CreateCategory("Main")
	Category:AddSubTitle("File")
	Category:AddItem("New File",function() self:NewFile() end)
	Category:AddItem("Save File",function() self:SaveToClient() end)
	Category:AddItem("Load File",function() self:LoadFromClient() end)
	Category:AddSubTitle("Editor")
	Category:AddItem("Close Editor",function() self:CloseWindow() end)

	local Category = CreateCategory("Apply Sign")
	Category:AddItem("Just for me",function() self:Sign_Apply_MyClient() end)
	Category:AddItem("For Everyone",function() self:Sign_Apply_AllClient() end)	
	
	
	local Category = CreateCategory("Elements")
	Category:AddItem("Text",function() self:AddText() end)
	Category:AddItem("Rectangle",function() self:AddBox() end)
	Category:AddItem("HTML Texture",function() self:AddHTMLTexture() end)

	local Category = CreateCategory("3D Sign Editor")
	Category:AddItem("About",function() self:About() end)

	
	self:BuildMainCategory(MainCategory)
	
	if Ent.SignData then
		self:LoadSavedFile(Ent.SignData)
	end
end

function PANEL:BuildMainCategory(DB)
	for k,v in pairs(DB) do
		local DSButton = vgui.Create( "DButton", self.TopPanel )
			DSButton:SetPos( 40 + k*125 - 125, 0)
			DSButton:SetSize( 120, 20 )
			DSButton:SetText(" ")
			DSButton.OnCursorEntered = function(slf) slf.Status = "Hovering" end
			DSButton.OnCursorExited = function(slf) slf.Status = "idle" end
			DSButton.Status = "idle"
			DSButton.Paint = function(slf)
					if slf.Status == "idle" then
						draw.SimpleText(v.PrintName, "Kostar_S15", slf:GetWide()/2,5, Color(150,150,150,255), TEXT_ALIGN_CENTER)
					else
						if input.IsMouseDown(MOUSE_LEFT) then
							draw.SimpleText(v.PrintName, "Kostar_S15", slf:GetWide()/2,5, Color(200,255,255,255), TEXT_ALIGN_CENTER)
						else
							draw.SimpleText(v.PrintName, "Kostar_S15", slf:GetWide()/2,5, Color(200,200,200,255), TEXT_ALIGN_CENTER)
						end
					end
			end
			DSButton.DoClick = function(slf)
				local SubMenu = vgui.Create( "D3DSE_SubMenuPanel" )
				local X,Y = DSButton:LocalToScreen( 0, 0 )
				SubMenu:SetPos(X,Y+DSButton:GetTall()+3)
				SubMenu.Mother = DSButton
				SubMenu:SetItems(v.Items)
			end
	end
end

function PANEL:Paint()
	if !self.Entity or !self.Entity:IsValid() then 
		self:Remove()
	end
	surface.SetDrawColor( 83,83,83,255 )
	surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
end

function PANEL:Think()
	if !input.IsMouseDown(MOUSE_LEFT) then
		self.CurDraggingThing = false
	end
end
vgui.Register("D3D_Sign_EditorPanel",PANEL,"DFrame")

end





if CLIENT then
local PANEL = {}

function PANEL:Think()
	if input.IsMouseDown(MOUSE_LEFT) and !self.ClickClose then 
		self.ClickClose = true
		timer.Simple(0.1,function()
			if self and self:IsValid() then
				self:Remove() 
			end
		end)
		return 
	end
	if !self.Mother or !self.Mother:IsValid() then 
		self:Remove() 
		return 
	end
end

function PANEL:SetItems(Items)
	self:SetSize(200,#Items*23)
	
	
	local MainPanel = self
	for k,v in pairs(Items) do
		local MenuButton = vgui.Create( "DSDButton", self)
		MenuButton:SetPos(5,3+23*(k-1))
		MenuButton:SetSize(self:GetWide(),20)
		MenuButton:SetTexts(v.PrintName)
		MenuButton:SetHoverAnim(1)
		MenuButton:SetExitAnim(1)
		MenuButton:SetClickAnim(1)
		MenuButton:SetBoarderColor(Color(0,0,0,0))
		MenuButton.Click = function(slf)
		
			if v.Func then
				v.Func()
			end
			self:Remove()
		end
		if v.IsSubTitle then 
			MenuButton:SetTextColor(Color(0,255,200,255))
			
		else
			MenuButton:SetFont("KostarOut_S13")
		end
		
		MenuButton:SetTextAlign(TEXT_ALIGN_LEFT)
		MenuButton.PaintOverlay = function(slf)
			surface.SetDrawColor( 255,255,255,10 )
			surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
		end
	end
	
	self:MakePopup()
end

function PANEL:Init()
end

function PANEL:Paint()
			surface.SetDrawColor( Color(255,255,255,120) )
			surface.DrawRect( 0, 0, self:GetWide(), 1 )
			surface.DrawRect( 0, self:GetTall()-1, self:GetWide(), 1 )
			surface.DrawRect( 0, 0, 1, self:GetTall() )
			surface.DrawRect( self:GetWide()-1, 0, 1, self:GetTall() )
			
			surface.SetDrawColor( 50,50,50,255 )
			surface.DrawRect(1, 1, self:GetWide()-2, self:GetTall()-2 )
end


vgui.Register("D3DSE_SubMenuPanel", PANEL, "Panel")
end






if SERVER then
util.AddNetworkString( "3DSignEditorOpen_S2C" )
util.AddNetworkString( "3DSignApply_C2S" )

util.AddNetworkString( "SyncSign_S2C" )
util.AddNetworkString( "SyncAllSign_S2C" )


	function Open_3DSignEditor(ply,Entity)
		net.Start( "3DSignEditorOpen_S2C" )
			net.WriteTable( {Ent = Entity:EntIndex()} )
		net.Send(ply)
	end
	
	function meta:SyncAllSigns()
		local TB2Send = {}
		for k,v in pairs(AppliedSigns) do
			TB2Send[k] = v
		end
		
		net.Start( "SyncAllSign_S2C" )
			net.WriteTable( TB2Send )
		net.Send(self)
	end
	
	net.Receive( "3DSignApply_C2S", function( len )
		local TB = net.ReadTable()
		local Ent = ents.GetByIndex(TB.Ent)
		local PackData = TB.PackData
		
		Ent.DesignData = PackData
		AppliedSigns[Ent:EntIndex()] = PackData
		
		net.Start( "SyncSign_S2C" )
			net.WriteTable( {Ent = Ent:EntIndex(),PackData=PackData} )
		net.Broadcast()
		
		
		/* -- we need more good code. this sucks
		local CX = PackData.CanVasX
		local CY = PackData.CanVasY
		-- 앞뒤,옆,위아래
		local min=Vector( -10 , -CX/2 *0.3 , 10 )
		local max=Vector( 10 , CX/2 *0.3, CY *0.3)

		Ent:PhysicsInitBox( min, max  )
		Ent:SetCollisionBounds(min,max)
		*/
	end)
	
	hook.Add( "PlayerInitialSpawn", "Update Signs", function(ply)
		timer.Simple(10,function()
			if !ply or !ply:IsValid() then return end
			ply:SyncAllSigns()
			MsgN("SYNCCCC")
		end)
	end)
	
	
end