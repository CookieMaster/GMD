local PANEL = {}

function PANEL:Init()
	self.MenuFunc = {}

end
function PANEL:Install()
	local Mask = vgui.Create("DPanel",self)
	Mask:SetSize(1000,1000)
	Mask.Paint = function(slf) end
end
function PANEL:Paint()
end
vgui.Register("SEHTML",PANEL,"HTML")