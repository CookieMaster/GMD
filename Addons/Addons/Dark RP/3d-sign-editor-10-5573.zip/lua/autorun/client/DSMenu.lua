local PANEL = {}
	
function DSMenu()
	local P = vgui.Create("DSMenu")
	
	return P
end
	
function PANEL:Init()
	self.MenuFunc = {}
end

function PANEL:AddOption(PrintName,Func)
	table.insert(self.MenuFunc,{PrintName = PrintName,Function = Func})
end

function PANEL:Open()
	local mx , my = gui.MousePos()
	
	self:SetPos(mx,my)
	self:SetSize(150,3+23*#self.MenuFunc)
	self:MakePopup()
	local MainPanel = self
	for k,v in pairs(self.MenuFunc) do
	
		local MenuButton = vgui.Create( "DSDButton", self)
		MenuButton:SetPos(5,3+23*(k-1))
		MenuButton:SetSize(140,20)
		MenuButton:SetTexts(v.PrintName)
		MenuButton:SetHoverAnim(1)
		MenuButton:SetExitAnim(1)
		MenuButton:SetClickAnim(1)
		MenuButton:SetBoarderColor(Color(0,0,0,0))
		MenuButton:SetFont("KostarOut_S15")
		
		MenuButton.Click = function(slf)
			if !self.CloseTime then
			v.Function()
			end
		end

	end
	self.CreatedTime = CurTime()
end

function PANEL:Think()
	if input.IsMouseDown(MOUSE_LEFT) and !self.ClickClose then 
		self.ClickClose = true
		timer.Simple(0.1,function()
			if self and self:IsValid() then
				self:Remove() 
			end
		end)
		return 
	end
	
	if self.CreatedTime and !self.CloseTime then
		local DeltaTime = CurTime() - self.CreatedTime
		self:SetSize(150,math.min(DeltaTime*800,3+(23*#self.MenuFunc)))
	end
end

function PANEL:Paint()
			surface.SetDrawColor( Color(255,255,255,120) )
			surface.DrawRect( 0, 0, self:GetWide(), 1 )
			surface.DrawRect( 0, self:GetTall()-1, self:GetWide(), 1 )
			surface.DrawRect( 0, 0, 1, self:GetTall() )
			surface.DrawRect( self:GetWide()-1, 0, 1, self:GetTall() )
			
			surface.SetDrawColor( 50,50,50,255 )
			surface.DrawRect(1, 1, self:GetWide()-2, self:GetTall()-2 )
end
vgui.Register("DSMenu",PANEL,"DPanel")