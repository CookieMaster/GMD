local PANEL = {}
	
function PANEL:Init()
	self.PathCacheData = {}
end

function PANEL:BuildPathCache(path)
	self.CorePath = path
	self.PathCacheData = {}
	
	local function BulidPathDir(path,LastPath)
		self.PathCacheData[path] = {}
		local File,Dir = file.Find(path .. "*", "DATA")
		self.PathCacheData[path].File = {}
		self.PathCacheData[path].Folder = {}
		if LastPath then
			self.PathCacheData[path].LastPath = LastPath
		end
		
		for k,v in pairs(File) do
			table.insert(self.PathCacheData[path].File,v)
		end
		for k,v in pairs(Dir) do
			local TB2Insert = {}
			TB2Insert.Path = path .. v
			TB2Insert.FolderName = v
			table.insert(self.PathCacheData[path].Folder,TB2Insert)
			BulidPathDir(path..v.."/",path)
		end
		
	end
	BulidPathDir(path)
end

function PANEL:Browse(path)
	self.Path = path
	
	self.MainLister:Clear()
		self.PathCacheData[path] = self.PathCacheData[path] or {}
		
		self.PathCacheData[path].Folder = self.PathCacheData[path].Folder or {}
		if self.PathCacheData[path].LastPath then
			local MenuButton = vgui.Create( "DSDButton")
			MenuButton:SetSize(self.MainLister:GetWide()/2-5,20)
			MenuButton:SetTexts("Go Back")
			MenuButton:SetHoverAnim(1)
			MenuButton:SetExitAnim(1)
			MenuButton:SetClickAnim(1)
			MenuButton:SetBoarderColor(Color(0,0,0,0))
			MenuButton.Click = function(slf)
				self:Browse(self.PathCacheData[path].LastPath)
			end
			self.MainLister:AddItem(MenuButton)
		end
		
	for k,v in pairs( self.PathCacheData[path].Folder or {}) do
		local MenuButton = vgui.Create( "DSDButton")
		MenuButton:SetSize(self.MainLister:GetWide()/2-5,20)
		MenuButton:SetTexts(v.FolderName)
		MenuButton:SetHoverAnim(1)
		MenuButton:SetExitAnim(1)
		MenuButton:SetClickAnim(1)
		MenuButton:SetBoarderColor(Color(0,0,0,0))
		MenuButton.Click = function(slf)
			self:Browse(v.Path .. "/")
		end
		self.MainLister:AddItem(MenuButton)
	end
	for k,v in pairs( self.PathCacheData[path].File or {}) do
		local MenuButton = vgui.Create( "DSDButton")
		MenuButton:SetSize(self.MainLister:GetWide()/2-5,20)
		MenuButton:SetTexts(v)
		MenuButton:SetHoverAnim(1)
		MenuButton:SetExitAnim(1)
		MenuButton:SetClickAnim(1)
		MenuButton:SetBoarderColor(Color(0,0,0,0))
		MenuButton.Click = function(slf)
			if self.Mother and self.Mother:IsValid() then
				local Data = util.JSONToTable(file.Read( path .. v ))
				if Data then
					self.Mother:LoadSavedFile(Data)
					if self.MaskP and self.MaskP:IsValid() then
						self.MaskP:Remove()
					end
				end
			end
		end
		self.MainLister:AddItem(MenuButton)
	end
	
end

function PANEL:Install()
	self.TopPanel = vgui.Create( "DPanel" , self)
	self.TopPanel:SetPos(2,2)
	self.TopPanel:SetSize( self:GetWide()-4,25 )
	self.TopPanel.Paint = function(slf)
		surface.SetDrawColor(255,255,255,255 )
		surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
		draw.SimpleText(self.Path or "", "Kostar_S20", 10,0, Color(200,200,200,255))
	end
	
	self.MainLister = vgui.Create( "DPanelList", self )
	self.MainLister:SetSize( self:GetWide()-10 , self:GetTall()-31)
	self.MainLister:SetPos( 5,29)
	self.MainLister:SetSpacing( 0 )
	self.MainLister:EnableHorizontal( true )
	self.MainLister:EnableVerticalScrollbar( true )
end

function PANEL:Paint()
			surface.SetDrawColor( Color(255,255,255,120) )
			surface.DrawRect( 0, 0, self:GetWide(), 1 )
			surface.DrawRect( 0, self:GetTall()-1, self:GetWide(), 1 )
			surface.DrawRect( 0, 0, 1, self:GetTall() )
			surface.DrawRect( self:GetWide()-1, 0, 1, self:GetTall() )
			
			surface.SetDrawColor( 50,50,50,255 )
			surface.DrawRect(1, 1, self:GetWide()-2, self:GetTall()-2 )
end
vgui.Register("RXFolderBrowser",PANEL,"DPanel")






local PANEL = {}
	
function PANEL:Init()
	self.PathCacheData = {}
	self:SetDraggable(false)
	self:ShowCloseButton(false)
	self:SetTitle("")
end
function PANEL:SaveThing(thing)
	self.SaveThis = thing
end

function PANEL:BuildPathCache(path)
	self.CorePath = path
	self.PathCacheData = {}
	
	local function BulidPathDir(path,LastPath)
		self.PathCacheData[path] = {}
		local File,Dir = file.Find(path .. "*", "DATA")
		self.PathCacheData[path].File = {}
		self.PathCacheData[path].Folder = {}
		if LastPath then
			self.PathCacheData[path].LastPath = LastPath
		end
		
		for k,v in pairs(File) do
			table.insert(self.PathCacheData[path].File,v)
		end
		for k,v in pairs(Dir) do
			local TB2Insert = {}
			TB2Insert.Path = path .. v
			TB2Insert.FolderName = v
			table.insert(self.PathCacheData[path].Folder,TB2Insert)
			BulidPathDir(path..v.."/",path)
		end
		
	end
	BulidPathDir(path)
end

function PANEL:Browse(path)
	self.Path = path
	
	self.MainLister:Clear()
		self.PathCacheData[path] = self.PathCacheData[path] or {}
		
		self.PathCacheData[path].Folder = self.PathCacheData[path].Folder or {}
		if self.PathCacheData[path].LastPath then
			local MenuButton = vgui.Create( "DSDButton")
			MenuButton:SetSize(self.MainLister:GetWide()/2-5,20)
			MenuButton:SetTexts("Go Back")
			MenuButton:SetHoverAnim(1)
			MenuButton:SetExitAnim(1)
			MenuButton:SetClickAnim(1)
			MenuButton:SetBoarderColor(Color(0,0,0,0))
			MenuButton.Click = function(slf)
				self:Browse(self.PathCacheData[path].LastPath)
			end
			self.MainLister:AddItem(MenuButton)
		end
		
	for k,v in pairs( self.PathCacheData[path].Folder or {}) do
		local MenuButton = vgui.Create( "DSDButton")
		MenuButton:SetSize(self.MainLister:GetWide()/2-5,20)
		MenuButton:SetTexts(v.FolderName)
		MenuButton:SetHoverAnim(1)
		MenuButton:SetExitAnim(1)
		MenuButton:SetClickAnim(1)
		MenuButton:SetBoarderColor(Color(0,0,0,0))
		MenuButton.Click = function(slf)
			self:Browse(v.Path .. "/")
		end
		self.MainLister:AddItem(MenuButton)
	end
	for k,v in pairs( self.PathCacheData[path].File or {}) do
		local MenuButton = vgui.Create( "DSDButton")
		MenuButton:SetSize(self.MainLister:GetWide()/2-5,20)
		MenuButton:SetTexts(v)
		MenuButton:SetHoverAnim(1)
		MenuButton:SetExitAnim(1)
		MenuButton:SetClickAnim(1)
		MenuButton:SetBoarderColor(Color(0,0,0,0))
		MenuButton.Click = function(slf)
			self.NameEntry:SetText(string.Left(v,string.len(v)-4))
		end
		self.MainLister:AddItem(MenuButton)
	end
	
end

function PANEL:Install()
	self.TopPanel = vgui.Create( "DPanel" , self)
	self.TopPanel:SetPos(2,2)
	self.TopPanel:SetSize( self:GetWide()-4,25 )
	self.TopPanel.Paint = function(slf)
		surface.SetDrawColor(255,255,255,255 )
		surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
		draw.SimpleText(self.Path or "", "Kostar_S20", 10,0, Color(200,200,200,255))
	end
	
	self.MainLister = vgui.Create( "DPanelList", self )
	self.MainLister:SetSize( self:GetWide()-10 , self:GetTall()-50)
	self.MainLister:SetPos( 5,29)
	self.MainLister:SetSpacing( 0 )
	self.MainLister:EnableHorizontal( true )
	self.MainLister:EnableVerticalScrollbar( true )
	
	
	self.BottomPanel = vgui.Create("DPanel",self)
	self.BottomPanel:SetPos(2,self:GetTall()-30)
	self.BottomPanel:SetSize( self:GetWide()-4,28 )
	self.BottomPanel.Paint = function(slf)
		surface.SetDrawColor(255,255,255,255 )
		surface.DrawRect( 0, 0, slf:GetWide(), 1 )
	end
	
	local Entry = vgui.Create("DTextEntry",self.BottomPanel) self.NameEntry = Entry
		Entry:SetText("")
		Entry:SetPos(0,0)
		Entry:SetSize(self.BottomPanel:GetWide()-120,self.BottomPanel:GetTall())
		Entry:SetAllowNonAsciiCharacters(false)
		Entry:SetTextColor(Color(255,255,255,255))
	
		Entry:SetDrawBackground(false)
		Entry:SetEnterAllowed( false )
		Entry:SetCursorColor(Color(255,255,255,255))
		Entry:RequestFocus()
		
			local MenuButton = vgui.Create( "DSDButton",self.BottomPanel)
			MenuButton:SetPos(self.BottomPanel:GetWide()-120,0)
			MenuButton:SetSize(120,30)
			MenuButton:SetTexts("Save")
			MenuButton:SetHoverAnim(1)
			MenuButton:SetExitAnim(1)
			MenuButton:SetClickAnim(1)
			MenuButton.Click = function(slf)
				if self.SaveThis then
					file.Write(self.Path .. Entry:GetValue() .. ".txt",self.SaveThis )
					self:BuildPathCache(self.CorePath)
					self:Browse(self.Path)
				end
			end

end

function PANEL:Paint()
			surface.SetDrawColor( Color(255,255,255,120) )
			surface.DrawRect( 0, 0, self:GetWide(), 1 )
			surface.DrawRect( 0, self:GetTall()-1, self:GetWide(), 1 )
			surface.DrawRect( 0, 0, 1, self:GetTall() )
			surface.DrawRect( self:GetWide()-1, 0, 1, self:GetTall() )
			
			surface.SetDrawColor( 50,50,50,255 )
			surface.DrawRect(1, 1, self:GetWide()-2, self:GetTall()-2 )
end
vgui.Register("RXFolderBrowser_Saver",PANEL,"DFrame")