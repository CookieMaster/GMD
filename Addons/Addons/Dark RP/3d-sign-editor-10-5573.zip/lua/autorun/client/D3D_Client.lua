hook.Add("Initialize", "D3D Dir Check", function()
	file.CreateDir("signbuilder")
end)