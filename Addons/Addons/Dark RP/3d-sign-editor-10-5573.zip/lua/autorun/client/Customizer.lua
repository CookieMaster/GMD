D3D_Adjust = {}


-- Add your custom fonts!
--[[
	D3D_Adjust.Font[FontName] = PrintName
	'FontName' is unique name for font.
	just open font file. then you can find unique name.
	
	'PrintName' will be shown at 3D Sign Editor. 
--]]

	D3D_Adjust.Font = {}
	D3D_Adjust.Font["Verdana"] = "Verdana"
	D3D_Adjust.Font["Trebuchet MS"] = "Trebuchet MS"
	D3D_Adjust.Font["Tahoma"] = "Tahoma"
	D3D_Adjust.Font["Courier New"] = "Courier New"
	D3D_Adjust.Font["Kostar"] = "Starcraft 2"
	D3D_Adjust.Font["Jupiter"] = "Jupiter"
	D3D_Adjust.Font["LCD"] = "LCD"
	D3D_Adjust.Font["Sansation"] = "Sansation"
	D3D_Adjust.Font["D3 Euronism"] = "Euronism"
	D3D_Adjust.Font["HalfLife2"] = "HL2 Weapon"


-- Canvas Setting
	-- Limit Canvas size.
	-- well, you can limit the size of canvas.. 
	-- i dont know.. are you really need to set the limit? 3000x1000 is really really big enough.
	-- anyway.. how knows.. 
		D3D_Adjust.MaxCanvasSizeX = 3000
		D3D_Adjust.MaxCanvasSizeY = 1000
	-- Boom! you can also set max font size.. 
	-- if you dont want to see big shit.... 
		D3D_Adjust.MaxFontSize = 150

-- Etc

	-- when you are far from sign.. sign will be not rendered. this process is really need to save your system resources.
		D3D_Adjust.MaxDrawDistance = 1500
