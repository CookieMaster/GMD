if (SERVER) then
	AddCSLuaFile( "shared.lua" )
	include("config.lua")
	SWEP.PrintName      = "Zipties"
	SWEP.Author    = "Builderboy"
	SWEP.Contact    = ""
	SWEP.DrawAmmo			= true
	SWEP.DrawCrosshair		= true
	SWEP.ViewModelFOV		= 70
	SWEP.ViewModelFlip		= false
end

if ( CLIENT ) then
	SWEP.PrintName      = "Zipties"
	SWEP.Author    = "Builderboy"
	SWEP.Contact    = ""
	SWEP.DrawAmmo			= true
	SWEP.DrawCrosshair		= true
	SWEP.ViewModelFOV		= 70
	SWEP.ViewModelFlip		= false
end
 
SWEP.Spawnable      = false
SWEP.AdminSpawnable  = false
 
SWEP.ViewModel = Model("models/weapons/v_crowbar.mdl")
SWEP.WorldModel = Model("models/weapons/w_crowbar.mdl")
SWEP.HoldType = "normal"
 

SWEP.Primary.ClipSize      = -1
SWEP.Primary.DefaultClip    = -1

SWEP.Primary.Automatic    = false
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize      = -1
SWEP.Secondary.DefaultClip    = -1

function SWEP:Reload()
	return
end

function SWEP:PrimaryAttack()
	if SERVER then
	
		local trace = self.Owner:GetEyeTrace( )
		
		if trace.StartPos:Distance( trace.HitPos ) < TIE_DISTANCE and trace.Entity:IsPlayer() and not trace.Entity:IsTied() then
			trace.Entity:TieUpPlayer(self.Owner, self)
			//print(tostring(trace.StartPos:Distance( trace.HitPos )))
		elseif(trace.StartPos:Distance( trace.HitPos ) < TIE_DISTANCE and trace.Entity:IsPlayer() and trace.Entity:IsTied()) then
			self.Owner:PrintMessage(HUD_PRINTTALK, trace.Entity:Nick().." is already tied up.")
		end

	end
end

function SWEP:SecondaryAttack()
	if SERVER then
	
		local trace = self.Owner:GetEyeTrace( )
			
		if trace.StartPos:Distance( trace.HitPos ) < TIE_DISTANCE and trace.Entity:IsPlayer() and trace.Entity:IsTied() then
			trace.Entity:UnTiePlayer(self.Owner)
		elseif(trace.StartPos:Distance( trace.HitPos ) < TIE_DISTANCE and trace.Entity:IsPlayer() and not trace.Entity:IsTied()) then
			self.Owner:PrintMessage(HUD_PRINTTALK, trace.Entity:Nick().." does not need untying.")
		end
	end
end

function SWEP:Think()
end