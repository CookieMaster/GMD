local meta = FindMetaTable("Player")

include("config.lua")

function meta:TieUpPlayer(otherply, wep)
	timer.Simple(5, function()
	
			local trace = otherply:GetEyeTrace( )
			
			if trace.StartPos:Distance( trace.HitPos ) < TIE_DISTANCE and trace.Entity:IsPlayer() and trace.Entity == self then
				
				self.TiedUp = true
				self.TiedWeps = {}
				
				self:SetWalkSpeed(TIED_WALK)
				self:SetRunSpeed(TIED_RUN)
				self:SetCrouchedWalkSpeed(TIED_CROUCH)
				self:SetJumpPower(TIED_JUMP)
				
				for k,v in pairs(self:GetWeapons()) do
					table.insert(self.TiedWeps, v:GetClass())
					self:StripWeapon(v:GetClass())
				end
				
				self:PrintMessage(HUD_PRINTTALK, "You have been tied up!")
				otherply:PrintMessage(HUD_PRINTTALK, "You have tied up "..self:Nick().." and confiscated their weapons.")
				
			else
				otherply:PrintMessage(HUD_PRINTTALK, "Tying person failed.")
			end
	end)
end

function meta:UnTiePlayer(otherply)
	timer.Simple(3, function()
	
			local trace = otherply:GetEyeTrace( )
			
			if trace.StartPos:Distance( trace.HitPos ) < TIE_DISTANCE and trace.Entity:IsPlayer() and trace.Entity == self then
				
				self.TiedUp = false			
				
				self:SetWalkSpeed(GAMEMODE.Config.walkspeed)
				self:SetRunSpeed(GAMEMODE.Config.runspeed)
				self:SetCrouchedWalkSpeed(0.30000001192093)
				self:SetJumpPower(200)

				if REFUND_WEAPONS then
					for k,v in pairs(self.TiedWeps) do
						self:Give(v)
					end
				else
					gamemode.Call("PlayerLoadout", self)
				end
				self:SetMaterial("")
				
				self:PrintMessage(HUD_PRINTTALK, "You have been untied.")
				otherply:PrintMessage(HUD_PRINTTALK, "You have untied "..self:Nick()..".")
				
				self.TiedWeps = {}
				
			else
				otherply:PrintMessage(HUD_PRINTTALK, "Untying person failed.")
			end
	end)
end

function meta:IsTied()
	return self.TiedUp
end