--[[ CONFIG FILE ]]--

REFUND_WEAPONS = true -- Should weapons be refunded?

TIE_DISTANCE = 50

TIED_RUN = 60
TIED_WALK = 50
TIED_CROUCH = 0.25
TIED_JUMP = 50