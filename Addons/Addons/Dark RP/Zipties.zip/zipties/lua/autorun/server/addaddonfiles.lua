include("arrest.lua")
AddCSLuaFile("arrest.lua")

function ResetPlyTied(ply)
	ply.TiedUp = false
	ply.TiedWeps = {}
	
	ply:SetWalkSpeed(160)
	ply:SetRunSpeed(240)
	ply:SetCrouchedWalkSpeed(0.30000001192093)
	ply:SetJumpPower(200)
end
hook.Add("PlayerSpawn", "ResetTiedPlayerVars", ResetPlyTied)

function PlyTiedUpUse(ply, entity)
	if ply:IsTied() then
		return false
	end
end
hook.Add("PlayerUse", "PlyTiedUpUseRestrict", PlyTiedUpUse)

function PlySpawnProp(ply, model)
	if ply:IsTied() then
		return false
	end
end
hook.Add("PlayerSpawnProp", "PlyTriedSpawningPropTied", PlySpawnProp)

hook.Add("canChangeJob", "PlyTiedChangeTeam", function(ply)
 if ply:IsTied() then return false end
end)

hook.Add("CanPlayerSuicide", "PlyTiedSuicideBlock", function()
if ply:IsTied() then return false end
end)