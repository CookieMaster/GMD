local function AddDir(dir)
	for k,v in pairs(file.Find(dir.."/*","GAME")) do
		resource.AddFile(dir.."/"..v)
	end
end

-- Resources
AddDir("resource/fonts")
AddDir("models/postal 2")
AddDir("Materials/Models/Jason278/Postal 2")


AddDir("models/perp2/bank_atm")
AddDir("materials/perp2/atm")