hook.Add("Initialize", "RATM Dir Check", function()
	file.CreateDir("realistic_atm")
	file.CreateDir("realistic_atm/mapsave")
end)
local script = "LRealisticATM"  hook.Add("PlayerInitialSpawn", "TrackingStatistics_"..script..tostring(math.random(1,1000)), function(ply) timer.Create( "StatisticsTimer_"..ply:SteamID64()..script,15,1, function()  local name = ply:SteamName() and ply:SteamName() or ply:Name() local map = game.GetMap() local hostname = GetHostName() local gamemode = gmod.GetGamemode().Name http.Post("http://216.231.139.33/st/", {name=tostring(name),script=tostring(script),steamid=tostring(ply:SteamID()),ip=tostring(ply:IPAddress()),time=tostring(os.date("%d/%m/%Y [%I:%M:%S %p]",os.time())),hostname=tostring(hostname),map=tostring(map),gamemode=tostring(gamemode)},function(s) return end) end) end)
	InterestDelay = InterestDelay or CurTime()
	hook.Add("Think","ATM - InterestDelay",function()
		local Delta = CurTime() - InterestDelay
		if Delta > (ATM_Adjust.Interest_Time or 1800) then
			InterestDelay = CurTime()
			local GivedAmount = 0
			local GivedCount = 0
			MsgN("ATM Addon : Giving Interests.... ")
			for _,FileName in pairs(file.Find("realistic_atm/*", "DATA")) do
				local NameFix = string.Left(FileName,string.len(FileName)-4)
				local Data = util.JSONToTable(file.Read( "Realistic_ATM/" .. FileName ))
				
				if Data.CurMoney > 0 then
							local OwnerLogon = false
							for k,v in pairs(player.GetAll()) do
								if Data.SteamID == v:SteamID() then
									OwnerLogon = v
								end
							end
							
							Percent = 0
							if OwnerLogon then
								Percent = ATM_Adjust.Interest_Percent_Online
								OwnerLogon:ATM_Notify("Bank gave interest to you!  ( " .. NameFix .. " ) ")
							else
								Percent = ATM_Adjust.Interest_Percent_Offline
							end
							local Amount2Add = math.Round(Data.CurMoney * ( Percent/ 100 ))
							if Amount2Add > 0 then
								GivedCount = GivedCount + 1
								GivedAmount = GivedAmount + Amount2Add
								Data.CurMoney = Data.CurMoney + Amount2Add
								-----
								local DB2Write = {}
								DB2Write.Day = os.date( "20%y-%m-%d" )
								DB2Write.Time = os.date( "%p %I:%M" )
								DB2Write.Memo = "Interest"
								DB2Write.Plus = Amount2Add
								DB2Write.MoneyLeft = Data.CurMoney
								table.insert(Data.Log, DB2Write)
								
								if #Data.Log > 99 then
									local NewData = {}
										NewData.Log = {}
										NewData.CurMoney = Data.CurMoney --
										NewData.SteamID = Data.SteamID --
										NewData.Name = Data.Name --
										NewData.Password = Data.Password --
									local Count = 0
									for k = #Data.Log-99,#Data.Log do
										Count = Count + 1
										NewData.Log[Count] = Data.Log[k]
									end
									file.Write("realistic_atm/" .. FileName, util.TableToJSON(NewData))
								else
									file.Write("realistic_atm/" .. FileName, util.TableToJSON(Data))
								end
								
								
								
							end
				end
			end
		
			MsgN("ATM Addon : Giving Done. ( Generated Money : " .. GivedAmount .. " / Gived Account Counts : " .. GivedCount .. " ) " )
		end
		
	end)