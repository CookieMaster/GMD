surface.CreateFont( "Kostar_S12",{font = "Kostar",size = 12,weight = 700})
surface.CreateFont( "Kostar_S15",{font = "Kostar",size = 15,weight = 700})
surface.CreateFont( "Kostar_S17",{font = "Kostar",size = 17,weight = 700})
surface.CreateFont( "Kostar_S20",{font = "Kostar",size = 20,weight = 700})
surface.CreateFont( "Kostar_S25",{font = "Kostar",size = 25,weight = 700})
surface.CreateFont( "Kostar_S30",{font = "Kostar",size = 30,weight = 700})
surface.CreateFont( "Kostar_S50",{font = "Kostar",size = 50,weight = 700})
surface.CreateFont( "Kostar_S70",{font = "Kostar",size = 70,weight = 700})

surface.CreateFont( "Jupiter_S10",{font = "Jupiter",size = 10,weight = 700})
surface.CreateFont( "Jupiter_S15",{font = "Jupiter",size = 15,weight = 700})
surface.CreateFont( "Jupiter_S17",{font = "Jupiter",size = 17,weight = 700})
surface.CreateFont( "Jupiter_S20",{font = "Jupiter",size = 20,weight = 700})
surface.CreateFont( "Jupiter_S25",{font = "Jupiter",size = 25,weight = 700})
surface.CreateFont( "Jupiter_S70",{font = "Jupiter",size = 70,weight = 700})

surface.CreateFont( "StarCine_S20",{font = "Star Cine",size = 20,weight = 700})
surface.CreateFont( "AlphaMaleModen_S15",{font = "AlphaMaleModern",size = 15,weight = 700})

surface.CreateFont( "LCD_S15",{font = "LCD",size = 15,weight = 700})
surface.CreateFont( "LCD_S25",{font = "LCD",size = 25,weight = 700})
surface.CreateFont( "LCD_S35",{font = "LCD",size = 35,weight = 700})

surface.CreateFont( "LCDOut_S25",{font = "LCD",size = 25,weight = 700,outline = true})

surface.CreateFont( "KostarOut_S13",{font = "Kostar",size = 13,weight = 700,outline = true})
surface.CreateFont( "KostarOut_S15",{font = "Kostar",size = 15,weight = 700,outline = true})
surface.CreateFont( "KostarOut_S17",{font = "Kostar",size = 17,weight = 700,outline = true})
surface.CreateFont( "KostarOut_S20",{font = "Kostar",size = 20,weight = 700,outline = true})
surface.CreateFont( "KostarOut_S25",{font = "Kostar",size = 25,weight = 700,outline = true})
surface.CreateFont( "KostarOut_S30",{font = "Kostar",size = 30,weight = 700,outline = true})

surface.CreateFont( "JupiterOut_S14",{font = "Jupiter",size = 14,weight = 700,outline = true})
surface.CreateFont( "JupiterOut_S15",{font = "Jupiter",size = 15,weight = 700,outline = true})
surface.CreateFont( "JupiterOut_S17",{font = "Jupiter",size = 17,weight = 700,outline = true})
surface.CreateFont( "JupiterOut_S20",{font = "Jupiter",size = 20,weight = 700,outline = true})


surface.CreateFont( "Sansation_S20",{font = "Sansation",size = 20,weight = 700})

surface.CreateFont( "SansationOut_S15",{font = "Sansation",size = 15,weight = 700,outline = true})
surface.CreateFont( "SansationOut_S20",{font = "Sansation",size = 20,weight = 700,outline = true})
surface.CreateFont( "SansationOut_S25",{font = "Sansation",size = 25,weight = 700,outline = true})
surface.CreateFont( "SansationOut_S30",{font = "Sansation",size = 30,weight = 700,outline = true})
surface.CreateFont( "SansationOut_S35",{font = "Sansation",size = 35,weight = 700,outline = true})
surface.CreateFont( "SansationOut_S40",{font = "Sansation",size = 40,weight = 700,outline = true})
surface.CreateFont( "SansationOut_S55",{font = "Sansation",size = 55,weight = 700,outline = true})
surface.CreateFont( "SansationOut_S70",{font = "Sansation",size = 70,weight = 700,outline = true})
surface.CreateFont( "SansationOut_S200",{font = "Sansation",size = 200,weight = 700,outline = true})

surface.CreateFont( "EuroOut_S20",{font = "D3 Euronism",size = 20,weight = 700,outline = true})
surface.CreateFont( "EuroOut_S70",{font = "D3 Euronism",size = 70,weight = 700,outline = true})

-- �޺� ���� ��Ʈ ����. (Ŭ��/�ý���/�޺�)