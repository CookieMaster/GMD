include('shared.lua')
include('atm_core.lua')

function ENT:Initialize()

end


function ENT:Draw()
	local MainEnt = self
	self:DrawModel()
	
		local Ang = self:GetAngles()
		Ang:RotateAroundAxis(Ang:Up(), 90)
		Ang:RotateAroundAxis(Ang:Right(), 0)
		Ang:RotateAroundAxis(Ang:Forward(), 83.5)
		
		local LDist = LocalPlayer():GetPos():Distance(self:GetPos())
		
		cam.Start3D2D( self:GetPos() + self:GetRight()*3.1 + self:GetForward()*2.78 + self:GetUp() * 53.25,Ang, 0.04 )
			-- Black BG
			surface.SetDrawColor( 0,0,0,255 )
			surface.DrawRect( -150,-90,300,180 )
			
			if LDist > 50 then
				draw.SimpleText("ATM Service", "JupiterOut_S20",0, -10 , Color(0,255,255,255),TEXT_ALIGN_CENTER)
			else
				if !ATMPanel or !ATMPanel:IsValid() then
					draw.SimpleText("Welcome!", "JupiterOut_S20",0, -80 , Color(0,255,255,255),TEXT_ALIGN_CENTER)
					draw.SimpleText("PLEASE SELECT YOUR", "JupiterOut_S20",0, -30 , Color(0,255,255,255),TEXT_ALIGN_CENTER)
					draw.SimpleText("REQUIRED SERVICE", "JupiterOut_S20",0, 10 , Color(0,255,255,255),TEXT_ALIGN_CENTER)
				else
					draw.SimpleText("ATM Service", "JupiterOut_S20",0, -80 , Color(0,255,255,255),TEXT_ALIGN_CENTER)
					if ATMPanel.Verified and ATMPanel.Verified.Num and ATMPanel.Verified.Name then
						draw.SimpleText("Account Verified", "JupiterOut_S20",0, -30 , Color(0,255,255,255),TEXT_ALIGN_CENTER)
						draw.SimpleText(ATMPanel.Verified.Num, "JupiterOut_S20",0, 0 , Color(0,255,255,255),TEXT_ALIGN_CENTER)
						draw.SimpleText(ATMPanel.Verified.Name, "JupiterOut_S20",0, 30 , Color(0,255,255,255),TEXT_ALIGN_CENTER)
					end
				end
			end

		cam.End3D2D()
		
		if LDist < 50 then
			local Light = DynamicLight( self:EntIndex() )
			if Light then
				Light.Pos = self:GetPos() + self:GetForward()*15 + self:GetUp()*55
				Light.r = 255
				Light.g = 180
				Light.b = 0
				Light.Brightness = 5
				Light.Size = 100 + math.sin(CurTime()*3)*5
				Light.Decay = 5
				Light.DieTime = CurTime() + 0.2
			end
		end
end