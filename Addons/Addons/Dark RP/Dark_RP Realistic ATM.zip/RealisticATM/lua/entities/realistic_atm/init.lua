AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "atm_core.lua" )

include('shared.lua')
include('atm_core.lua')


function ENT:SpawnFunction( ply, tr )

	if ( !tr.Hit ) then return end
	
	local SpawnPos = tr.HitPos + tr.HitNormal * 16
	
	local ent = ents.Create( "realistic_atm" )
		ent:SetPos( SpawnPos )
		ent:Spawn()
	return ent
	
end

function ENT:Initialize( )
	self.Entity:SetModel("models/perp2/bank_atm/bank_atm.mdl")
	self.Entity:PhysicsInit(SOLID_VPHYSICS)
	self.Entity:SetMoveType(MOVETYPE_NONE)
	self.Entity:SetSolid(SOLID_VPHYSICS)
	
	self.Entity:SetUseType(SIMPLE_USE)
	
	------ For DarkRP : Not to server to remove atm when you leave the server
	timer.Simple(1,function()
		if self and self:IsValid() then
			self.SID = nil
			self.FPPOwnerID = nil
		end
	end)
	-------------------------------------------------------------
end

function ENT:Use( activator, caller )
	if ( activator:IsPlayer() ) then
		Open_ATMPanel(activator)
	end
end

function ENT:PhysgunPickup(ply) -- for DarkRP : Allows Owner can move ATM
	if ply:GetNWString("usergroup") == "owner" or ply:GetNWString("usergroup") == "superadmin" then 
		return true
	end
end

function ENT:CanTool(ply, trace, mode) -- for DarkRP : Allows Only Owner to remove ATM. 
	if ply:GetNWString("usergroup") == "owner" or ply:GetNWString("usergroup") == "superadmin" then 
		return true 
	else
		return false
	end
end