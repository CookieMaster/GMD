ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Radar Sensor"
ENT.Author = "Kunit"
ENT.Spawnable = false
ENT.AdminSpawnable = false
