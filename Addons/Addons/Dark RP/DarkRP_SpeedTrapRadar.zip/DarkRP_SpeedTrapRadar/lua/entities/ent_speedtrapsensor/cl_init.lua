include( 'shared.lua' )
 
ENT.RenderGroup = RENDERGROUP_BOTH

local Laser = Material( "cable/redlaser" )

function ENT:Draw( )
    self.Entity:DrawModel( )
	
	local pos = self:GetPos()
	local pos2 = self:GetPos()
	local pos2s = self:GetPos()
	pos2s:Add(Vector(0,0,17.5))
	pos2:Add(self:GetForward() * 400)
	pos2:Add(Vector(0,0,17.5))
	
	pos:Add(self:GetForward() * 5)
	render.SetMaterial( Laser )
	render.DrawBeam( pos2s, pos2, 1, 1, 1, Color( 255, 0, 0, 150 ) ) 
	
	pos:Add(Vector(0,0,30))
	
	local ang = self:GetAngles()

	local addang = Angle(0, 90, 90)
	local newang = Angle(ang.p + addang.p,ang.y + addang.y,ang.r + addang.r)
	local newang2 = newang
	
	local speed = self:GetNWInt("CarSpeed")
	
	newang:RotateAroundAxis(ang:Up(), 180)  
	cam.Start3D2D( pos, newang, 0.3 )
			draw.RoundedBox( 0, -50, 0, 100, 20, Color( 0, 0, 0, 150 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
			draw.DrawText(math.ceil(speed).." MPH", "TargetID", 0, 0, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	cam.End3D2D()

end
