NLR = {}
NLR.Timer = 180 -- How long does it usually NLR
NLR.Screen = 20 -- > Lighter < Darker
NLR.FreezeTimer = 5 -- How long does it usually Freeze
NLR.Punishment = "Freeze" -- Enter your punishment ("Freeze", "Kick", "Ban")
NLR.BanTime = 60 -- Ban length in minutes
NLR.Reason = "NLR" -- Reason kick/ban
NLR.Immunity = "nil" -- (admins and super admins = "Admin" | super admins = "SuperAdmin")
NLR.Radius = 1000

if SERVER then
util.AddNetworkString("NLR.ActionPlayer") 
util.AddNetworkString("NLR.Report") 
function NLR.StartDeath( ply, weapon, killer )
if !IsValid(ply) then return end
if !IsValid(killer) then return end
//if ply == killer then return end
//if !killer:IsPlayer() then return end
if NLR.Immunity == "Admin" then
	if ply:IsAdmin() then
		return
	end
elseif NLR.Immunity == "SuperAdmin" then
	if ply:IsSuperAdmin() then
		return
	end
end
ply.NLRDeath = true
ply:SendLua("LocalPlayer().DeathPos = LocalPlayer():GetPos()")
end
hook.Add( "PlayerDeath", "NLR.StartDeath", NLR.StartDeath )

function NLR.StartSpawn( ply )
if NLR.Immunity == "Admin" then
	if ply:IsAdmin() then
		return
	end
elseif NLR.Immunity == "SuperAdmin" then
	if ply:IsSuperAdmin() then
		return
	end
end
timer.Simple(1, function()
ply:SendLua("LocalPlayer().SpawnPos = LocalPlayer():GetPos()")
ply:SendLua("LocalPlayer().NLRTimer = math.floor(CurTime() + NLR.Timer)")
end)
timer.Simple(NLR.Timer, function()
if IsValid(ply) then
	ply.NLRDeath = false
	ply:Freeze(false)
	ply:SendLua("LocalPlayer().DeathPos = false")
	ply:SendLua("LocalPlayer().SpawnPos = false")
	ply:SendLua("LocalPlayer().NLR = false")
	ply:SendLua("LocalPlayer().freeze = false")
end
end)
end
hook.Add( "PlayerSpawn", "NLR.StartSpawn", NLR.StartSpawn )


function NLR.ActionPlayer()
local ent = net.ReadEntity()
local name = ent:Nick()
if ent.NLRDeath then
if NLR.Punishment == "Freeze" then
ent:Freeze(true)
elseif NLR.Punishment == "Kick" then
RunConsoleCommand("Fadmin", "kick", ent:Nick(), NLR.Reason)
elseif NLR.Punishment == "Ban" then
RunConsoleCommand("Fadmin", "ban", ent:Nick(), NLR.BanTime, NLR.Reason)
end
for k,v in pairs(player.GetAll()) do
if v:IsAdmin() then
net.Start("NLR.Report")
net.WriteString(name)
net.Send(v)
end
end
end
end
net.Receive("NLR.ActionPlayer",NLR.ActionPlayer)

end

if CLIENT then

function NLR.Report()
local name = net.ReadString()
chat.AddText(Color(255,0,0), "[NLR] ", Color(255,255,255), "The player ", Color(0,255,0), name, Color(255,255,255), " has broken a rule NLR")
end
net.Receive("NLR.Report", NLR.Report)
 
hook.Add( "Think", "NLR.Think", function()
if LocalPlayer():Alive() then
if !LocalPlayer().SpawnPos then return end
if LocalPlayer().DeathPos then
if LocalPlayer().SpawnPos:Distance(LocalPlayer().DeathPos) < NLR.Radius then 
	LocalPlayer().DeathPos = false
	LocalPlayer().SpawnPos = false
	return
end
LocalPlayer().NLRTime = math.floor(LocalPlayer().NLRTimer - CurTime())
	if LocalPlayer().DeathPos:Distance(LocalPlayer():GetShootPos()) < NLR.Radius then
		LocalPlayer().NLR = true
		if !LocalPlayer().time then
			LocalPlayer().time = NLR.FreezeTimer
			timer.Create("NLR.FreezeTimer", 1, NLR.FreezeTimer, function() LocalPlayer().time = LocalPlayer().time - 1 end)
		elseif LocalPlayer().time <= 0 then 
				if !LocalPlayer().freeze then
					LocalPlayer().freeze = true
					net.Start("NLR.ActionPlayer")
					net.WriteEntity(LocalPlayer())
					net.SendToServer()
				end
			end
	else
		LocalPlayer().NLR = false
		LocalPlayer().time = false
		LocalPlayer().freeze = false
		timer.Destroy("NLR.FreezeTimer")
	end
end
end
end)

hook.Add( "PostDrawTranslucentRenderables", "NLR.PostDrawTranslucentRenderables", function()
if LocalPlayer().DeathPos then
render.SetMaterial( Material("models/shadertest/shader3") )
render.DrawSphere( LocalPlayer().DeathPos, NLR.Radius, 100, 100, Color(30, 30, 230, 255) )
render.DrawSphere( LocalPlayer().DeathPos, -1*NLR.Radius, 100, 100, Color(30, 30, 230, 255) )
render.SetMaterial( Material("models/props_combine/stasisshield_sheet") )
render.DrawSphere( LocalPlayer().DeathPos, NLR.Radius, 100, 100, Color(30, 30, 230, 255) )
render.DrawSphere( LocalPlayer().DeathPos, -1*NLR.Radius, 100, 100, Color(30, 30, 230, 255) )
end
end)

function NLR.RenderScreenspaceEffects()
if LocalPlayer():Alive() then
if !LocalPlayer().SpawnPos then return end
	local self = LocalPlayer()
if self.NLR then
	if LocalPlayer().time then
		if NLR.Punishment == "Freeze" then
			draw.DrawText("You're breaking a rule NLR!\n You will have been frozen in "..LocalPlayer().time.." seconds", "DermaLarge", ScrW() / 2 - 70, ScrH() - 83, Color(255, 255, 255, 255),TEXT_ALIGN_CENTER)
		elseif NLR.Punishment == "Kick" then
			draw.DrawText("You're breaking a rule NLR!\n You will have been kicked in "..LocalPlayer().time.." seconds", "DermaLarge", ScrW() / 2 - 70, ScrH() - 83, Color(255, 255, 255, 255),TEXT_ALIGN_CENTER)
		elseif NLR.Punishment == "Ban" then
			draw.DrawText("You're breaking a rule NLR!\n You will have been baned in "..LocalPlayer().time.." seconds", "DermaLarge", ScrW() / 2 - 70, ScrH() - 83, Color(255, 255, 255, 255),TEXT_ALIGN_CENTER)
		end	
		if LocalPlayer().NLRTime >= 0 then
			draw.DrawText("You have "..LocalPlayer().NLRTime.." seconds remaining in the NLR", "DermaLarge", ScrW() / 2 - 70, ScrH() - 113, Color(255, 255, 255, 255),TEXT_ALIGN_CENTER)
		end
	end
	color = math.Clamp(1.4 - ( ( 100 - NLR.Screen ) * 0.02 ), 0, 1.1)
	brightness = math.Clamp(0.6 - ( ( 100 - NLR.Screen ) * 0.01 ), -0.7, -0.05)
	bloom = math.Clamp(1.4 - ( ( 100 - NLR.Screen ) * 0.02 ), 0, 1)
	ColorModify = {}
	ColorModify["$pp_colour_brightness"] = -0.05
	ColorModify["$pp_colour_contrast"] = 1.1
	ColorModify["$pp_colour_addr"] = 0
	ColorModify["$pp_colour_addg"] = 0
	ColorModify["$pp_colour_addb"] = 0
	ColorModify["$pp_colour_mulr"] = 0
	ColorModify["$pp_colour_mulg"] = 0
	ColorModify["$pp_colour_mulb"] = 0
	ColorModify["$pp_colour_colour"] = color
	ColorModify["$pp_colour_brightness"] = brightness
	DrawColorModify(ColorModify)
end
end
end
hook.Add( "RenderScreenspaceEffects", "NLR.RenderScreenspaceEffects", NLR.RenderScreenspaceEffects )
end