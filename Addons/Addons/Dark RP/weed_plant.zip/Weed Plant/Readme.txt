Thanks For Downloading

These are only useable for darkrp.

Note: Darkrp folder is usually in the gamemodes folder.Also only the mob can spawn weed and weedplants.
The current limit for weed plants is 5 and seeds is 15. This can be changed anytime in the addentities file.

1. Place seed_weed and weed_plant into: darkrp\entities\entities

2. Place addentities into darkp\gamemode

3. Lastly copy and paste materials and models into garrysmod/garrysmod. (It will ask to replace the folder but it wont delete any other models or materials)

And it should work!!
Feel free to use this however you wish.
I do not claim credit on the models. Which are here http://www.garrysmod.org/downloads/?a=view&id=68156

--Proost

