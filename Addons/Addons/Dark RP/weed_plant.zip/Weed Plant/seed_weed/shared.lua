ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Weed Seed"
ENT.Author = "N/A"
ENT.Spawnable = false
ENT.AdminSpawnable = true