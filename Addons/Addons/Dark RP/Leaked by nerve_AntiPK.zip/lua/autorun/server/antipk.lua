-- Licensed under Creative Commons. See license.txt for more info.
-- Created by Phoenixf129. Sold on CoderHire.com
-- If you did not buy this, you don't have the legal right to run it. Nag over!

CreateConVar("apk_vehdmg", "1") -- Set to 0 to disable vehicle damage on players. 

local AntiPK_NoGhostEnts = {"player", "npc_police", "npc_citizen", "npc_buyer"} -- These entity classes do not get ghosted...
local AntiPK_NoTDamageEnts = {"prop_", "gmod_", "vending_", "bank_"} -- Entities that do NOT damage players. prop_ being all prop class. etc.
local AntiPK_NoRDamageEnts = {"npc_police", "npc_citizen", "npc_buyer", "npc_monk", "npc_crow"} -- Entities that DO NOT receive damage. For example an NPC seller or even an entity that is destroyable that you DO NOT want to be destroyable.

GhostedProps = {}

local function GhostableEntity(ent)
	return IsValid(ent)
	and not table.HasValue(AntiPK_NoGhostEnts, string.lower(ent:GetClass()))
end

local function CanGhost(ply, ent)
	return GhostableEntity(ent)
	and (not ent.CPPICanPhysgun or ent:CPPICanPhysgun(ply))
	and not ent.PhysgunDisabled
end

local function GhostProp(ent)
	if not IsValid(ent) then return end
	
	if GhostedProps[ent] == nil then
		ent.LastCollisionGroup = ent:GetCollisionGroup()
		ent:SetCollisionGroup( COLLISION_GROUP_WORLD )
		ent:SetRenderMode(4)
		local col = ent:GetColor()
		col.a = 178
		ent:SetColor(col)
	end
	
	if not GhostedProps[ent] then
		GhostedProps[ent] = true

		local ConTable = constraint.GetTable( ent )
		for _, con in ipairs( ConTable ) do
			if con.Type != "NoCollide" then
				for _, constrain in pairs( con.Entity ) do
					GhostProp(constrain.Entity)
				end
			end
		end
	end
end

local function CanToolGhosts(ply, trace, tool)
	for ent, picked_up in pairs(GhostedProps) do
		if trace.Entity == ent then
			if tool != "remover" then
				ply:PrintMessage(HUD_PRINTTALK, "[TOOLBLOCK] You cannot use tools on ghosted entities!")	
				return false
			end
		end
	end
end
hook.Add("CanTool", "CanToolGhosts", CanToolGhosts)

local function UnghostProp(ent)
	if not IsValid(ent) then return end

	if ent.justspawned then 
		return 
	end

	if ent:GetVelocity():Length() > 5 then -- If they're moving, they stay ghosted to prevent throwing, which should be prevented anyway.
		return
	end

	if GhostedProps[ent] == nil then return end
	
	GhostedProps[ent] = nil
	
	ent:SetCollisionGroup( ent.LastCollisionGroup or COLLISION_GROUP_NONE )
	local col = ent:GetColor()
	col.a = 255
	ent:SetColor(col)
end

local function DropProp(ent)
	if not IsValid(ent) then return end
	if GhostedProps[ent] == false then return end
	
	GhostedProps[ent] = false
	
	local phys = ent:GetPhysicsObject()
	
	timer.Simple(0.1, function() --Disables prop Velocity, preventing propthrowing using physgun.
		if IsValid(phys) then
			ent:GetPhysicsObject():SetVelocity( Vector(0,0,0) ) 
			ent:GetPhysicsObject():AddAngleVelocity(ent:GetPhysicsObject():GetAngleVelocity()*-1)
		end
	end)
		
	local ConTable = constraint.GetTable( ent )
	for _, con in ipairs( ConTable ) do
		if con.Type != "NoCollide" then
			for _, constrain in pairs( con.Entity ) do
				DropProp(constrain.Entity)
			end
		end
	end
end

local NextThink = 0
hook.Add( "Think", "Ghosted Props Think", function()
	
	if NextThink > CurTime() then return end

	for ent, picked_up in pairs(GhostedProps) do
		if IsValid(ent) then
			if not picked_up then
				local ents_inside = ents.FindInSphere(ent:GetPos(), ent:BoundingRadius())
				local player_inside
				for _,inside_ent in pairs(ents_inside) do
					if not inside_ent.rm_Ragdoll then -- Functionality for RagMod
						if (inside_ent:IsPlayer()) then 
							player_inside = true
							break
						end
					elseif inside_ent:GetClass() == "prop_ragdoll" then -- Stopping ragdolls from conflicting with AntPK's ghosting (Clipping)
						player_inside = true
						break
					end
				end
				if not player_inside then
					UnghostProp(ent)
				end
			end
		else
			GhostedProps[ent] = nil
		end
	end
	
	NextThink = CurTime() + 0.2
	
end)

hook.Add( "PhysgunPickup", "z-AntiPropPushPickup", function(ply, ent)
	if CanGhost(ply, ent) then
		GhostProp(ent)
	end
end)

hook.Add( "PlayerSpawnedProp", "z-AntiPropPushSpawn", function(ply, model, ent)
	ent.justspawned = true
	GhostProp(ent)
	timer.Simple(2, function() ent.justspawned = false end)
end)

hook.Add("PhysgunDrop", "z-AntiPropPushDrop", function(ply, ent)
	if CanGhost(ply, ent) then
		DropProp(ent)
	end
end)

hook.Add("OnPhysgunFreeze", "z-AntiPropPushFreezing", function(weapon, physobj, ent, ply)
	if CanGhost(ply, ent) then
		DropProp(ent)
	end
end)

-- Y NO PROP THATS BEING UNFROZEN?! WHY JUST THE PHYSGUN WEAPON AND PLAYER? I HAVE TO MAKE MY OWN TRACES NOW GARRY! :(
hook.Add("OnPhysgunReload", "z-AntiPropPushReload", function(physgun, ply)
	local tr = ply:GetEyeTraceNoCursor()
	local ent = tr.Entity
	
	if !IsValid(ent) then return end
	
	if CanGhost(ply, ent) then
		GhostProp(ent)
	end
end)

hook.Add( "EntityTakeDamage", "AntiPropKill", function(ent, dmginfo)
	local inflictor = dmginfo:GetInflictor()
	
	if GetConVarNumber("apk_vehdmg") == 0 then
		if inflictor:IsVehicle() then
			dmginfo:SetDamage(0)
		end
	end

	if table.HasValue(AntiPK_NoRDamageEnts, ent:GetClass()) then
		dmginfo:SetDamage(0)
	end
	
	local found
	for k, block in pairs(AntiPK_NoTDamageEnts) do
		if string.find(string.lower(inflictor:GetClass()), block) and inflictor:GetClass() != "prop_vehicle_jeep" then
			found = true
		end
	end
	
	if found then
		dmginfo:SetDamage(0)
	end
	
end)