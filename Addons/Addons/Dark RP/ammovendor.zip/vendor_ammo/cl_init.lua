include("shared.lua")

surface.CreateFont("ScoreboardHeader", {
	font = "coolvetica",
	size = 32,
	weight = 500,
	antialias = true
})

surface.CreateFont("ScoreboardSubtitle", {
	font = "coolvetica",
	size = 22,
	weight = 500,
	antialias = true
})

surface.CreateFont("ScoreboardText", {
	font = "Tahoma",
	size = 16,
	weight = 1000,
	antialias = true
})

function ENT:Initialize()
end

	local color = {					
		White = Color(255,255,255,255),
		Black = Color(0,0,0,255),
		LightGrey = Color(170,170,170,255),
		Grey = Color(150,150,150,255),
		DarkGrey = Color(130,130,130,255),
		DarkerGrey = Color(90,90,90,255),
		Clear = Color(0,0,0,0)
	} 
	
function ENT:Draw()
	self.Entity:DrawModel()
	
	local Pos = self:GetPos()
	local Ang = self:GetAngles()
	
	txt1 = "Ammunition"
	txt2 = "Vendor"
	txt3 = "Press 'e' on me!"
	
	surface.SetFont("HUDNumber5")
	local TextWidth = surface.GetTextSize(txt1)
	local TextWidth2 = surface.GetTextSize(txt2)
	local TextWidth3 = surface.GetTextSize(txt3)
	
	Ang:RotateAroundAxis( Ang:Up(), 90 )
	Ang:RotateAroundAxis( Ang:Forward(), 90 )
	
	--//  Machine Label  //--
	cam.Start3D2D(Pos + Ang:Up() * 21, Ang, 0.2)
		draw.RoundedBox( 0, -TextWidth*0.5-33, -150, TextWidth+20, 80, color.Black )
		draw.RoundedBox( 0, -TextWidth*0.5-33+4, -150+4, TextWidth+20-8, 80-8, color.White )
		
		draw.WordBox( 6, -TextWidth*0.5-28, -150, txt1, "HUDNumber5", color.Clear, color.Black )
		draw.WordBox( 6, -TextWidth2*0.5-28, -115, txt2, "HUDNumber5", color.Clear, color.Black )
	cam.End3D2D()
	
	--//  Hint Label  //--
	cam.Start3D2D( Pos + Ang:Up() * 21, Ang, 0.09 )																			
		draw.WordBox( 6, -TextWidth3*0.5-50, -140, txt3, "HUDNumber5", Color( 255, 255, 255, 105 ), color.Black )
	cam.End3D2D()	
end

usermessage.Hook( "BuyAmmo", function()
	local midx = ScrW()/2
	local midy = ScrH()/2
	local pwidth = 450
	local pheight = 350
	
	local frame = vgui.Create( "DFrame" )
	frame:SetSize( pwidth, pheight )
	frame:Center()
	frame:SetTitle( "" )
	frame:SetVisible( true )
	frame:SetDraggable( true )
	frame:ShowCloseButton( true )
	frame:MakePopup() 
	frame.btnMaxim:SetVisible( false )
	frame.btnMinim:SetVisible( false )
	frame.btnClose:SetVisible( true ) 
	
	  
	function frame:Paint( w, h ) 
		draw.RoundedBox( 0, 10, 28, w-20, h-62, color.Black )
		draw.RoundedBox( 0, 12, 28, w-24, h-62, color.LightGrey )
		draw.RoundedBoxEx( 8, w-39, 0, 37, 28, color.Black, false, true, false, true ) 
		draw.RoundedBoxEx( 8, 0, 0, w-39, 28, color.Black, true, false, true, false )
		draw.RoundedBoxEx( 6 ,2 ,2, w-39, 24, color.DarkerGrey, true, false, true, false ) 
		draw.RoundedBox( 8, 0, 316, w-2, 28, color.Black )
		draw.RoundedBox( 6, 2, 318, w-6, 24, color.DarkerGrey )
		draw.DrawText( "Ammunition Vendor", "ScoreboardSubtitle", 8, 4, color.Black ) 		
	end 
	 
	function frame.btnClose:Paint( w, h )
		draw.RoundedBoxEx( 6, 0, 2, 31, 24, color.DarkGrey, false, true, false, true ) 
		draw.DrawText( "X", "ScoreboardSubtitle", w/2, h/8, color.Black, TEXT_ALIGN_CENTER ) 
	end   
	
	local IconList = vgui.Create( "DPanelList", frame ) 
	IconList:EnableVerticalScrollbar( true ) 
 	IconList:EnableHorizontal( true ) 
 	IconList:SetPadding( 4 ) 
	IconList:SetPos( 15, 30 ) 
	IconList:SetSize( pwidth-30, pheight-66 )     
	
	for k,v in pairs( CustomAmmo ) do
		local bar = vgui.Create( "DPanel", IconList )
		bar:SetPos( 0, 0 )  
		bar:SetSize( 396, 70 ) 
		function bar:Paint( w, h )
			draw.RoundedBox( 4, 0,0 , w, h-5, color.Black )
			draw.RoundedBox( 4, 2,2 , w-4, h-9, color.DarkGrey )
			draw.RoundedBox( 0, 63, 0, 2, h-5, color.Black )
			draw.RoundedBox( 0, 63, 25, w-30, 2, color.Black )
			draw.RoundedBox( 0, 70, 32, w-77, 26, color.LightGrey )
 
			draw.DrawText(tostring(v["label"]),"ScoreboardHeader",70,0,color.Black)
			draw.DrawText(tostring(v["price"]) .. "$","ScoreboardHeader",392,0,color.Black,TEXT_ALIGN_RIGHT)
			draw.DrawText(tostring(v["desc"]),"ScoreboardText",78,37,color.Black)
		end
		local icon = vgui.Create( "SpawnIcon", bar )
		icon:SetModel( v["model"] )
		icon:SetPos( 4, 4 )
		icon:SetSize( 57, 57 )
		icon.DoClick = function() 
			local ammo = tostring( v["ammotype"] )
			local amount = v["amount"]
			local price = v["price"]
			RunConsoleCommand( "purchase_ammo", amount, ammo, price )
		end  
		function icon.Paint()	
			draw.RoundedBox( 4, 4, 4, 49, 49, color.Grey )	
		end
		IconList:AddItem( bar ) 
	end
end);

function ENT:Think()
end