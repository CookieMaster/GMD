ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Ammunition Vendor"
ENT.Author = "Koolaidmini"
ENT.Spawnable = true
ENT.AdminSpawnable = true

CustomAmmo = {
	["357"] = {
		["label"] = ".357 Ammunition",						-- Ammo Label
		["model"] = "models/Items/357ammo.mdl", 			-- Ammo Model
		["desc"] = "A box of (18) .357 rounds.", 			-- Description
		["amount"] = "18", 									-- Amount of ammo given
		["ammotype"] = "357",								-- The Entity
		["price"] = "299"									-- Purchase Price
	},
	[".45"] = {
		["label"] = ".45 Ammunition", 						-- Ammo Label
		["model"] = "models/Items/BoxMRounds.mdl", 			-- Ammo Model
		["desc"] = "A box of (20) .45 rounds.", 			-- Description
		["amount"] = "20", 									-- Amount of ammo given
		["ammotype"] = "SniperPenetratedRound", 			-- The Entity
		["price"] = "399"									-- Purchase Price
	},
	[".50"] = {
		["label"] = ".50 Ammunition",					 	-- Ammo Label
		["model"] = "models/Items/BoxMRounds.mdl", 			-- Ammo Model
		["desc"] = "A box of (20) .50 rounds.", 			-- Description
		["amount"] = "20", 									-- Amount of ammo given
		["ammotype"] = "CombineCannon", 					-- The Entity
		["price"] = "399"									-- Purchase Price
	},
	["4.6MM"] = {
		["label"] = "4.6MM Ammunition", 					-- Ammo Label
		["model"] = "models/Items/BoxSRounds.mdl", 			-- Ammo Model
		["desc"] = "A box of (20) 4.6MM rounds.", 			-- Description
		["amount"] = "20", 									-- Amount of ammo given
		["ammotype"] = "Gravity", 							-- The Entity
		["price"] = "299"									-- Purchase Price
	},
	["5.56MM"] = {
		["label"] = "5.56MM Ammunition", 					-- Ammo Label
		["model"] = "models/Items/BoxMRounds.mdl", 			-- Ammo Model
		["desc"] = "A box of (20) 5.56MM rounds.", 			-- Description
		["amount"] = "20", 									-- Amount of ammo given
		["ammotype"] = "AirboatGun", 						-- The Entity
		["price"] = "299"									-- Purchase Price
	},
	["5.7MM"] = {
		["label"] = "5.7MM Ammunition", 					-- Ammo Label
		["model"] = "models/Items/BoxSRounds.mdl", 			-- Ammo Model
		["desc"] = "A box of (20) 5.7MM rounds.", 			-- Description
		["amount"] = "20", 									-- Amount of ammo given
		["ammotype"] = "AlyxGun", 							-- The Entity
		["price"] = "299"									-- Purchase Price
	},
	["7.62MM"] = {
		["label"] = "7.62MM Ammunition", 					-- Ammo Label
		["model"] = "models/Items/BoxSRounds.mdl", 			-- Ammo Model
		["desc"] = "A box of (20) 7.62MM rounds.", 			-- Description
		["amount"] = "20", 									-- Amount of ammo given
		["ammotype"] = "StriderMinigun", 					-- The Entity
		["price"] = "299"									-- Purchase Price
	},
	["9MM"] = {
		["label"] = "9MM Ammunition", 						-- Ammo Label
		["model"] = "models/Items/BoxSRounds.mdl", 			-- Ammo Model
		["desc"] = "A box of (20) 9MM rounds.", 			-- Description
		["amount"] = "20", 									-- Amount of ammo given
		["ammotype"] = "Pistol", 							-- The Entity
		["price"] = "299"									-- Purchase Price
	},
	["CROSSBOW"] = {
		["label"] = " Crossbow Bolts", 						-- Ammo Label
		["model"] = "models/Items/CrossbowRounds.mdl",		-- Ammo Model
		["desc"] = "A box of (6) crossbow bolts.", 			-- Description
		["amount"] = "6", 									-- Amount of ammo given
		["ammotype"] = "XBowBolt",							-- The Entity
		["price"] = "499"									-- Purchase Price
	},
	["SHOTGUN"] = {
		["label"] = "Shotgun Ammunition", 					-- Ammo Label
		["model"] = "models/Items/BoxSRounds.mdl", 			-- Ammo Model
		["desc"] = "A box of (20) shotgun shells.", 		-- Description
		["amount"] = "20", 									-- Amount of ammo given
		["ammotype"] = "Buckshot", 							-- The Entity
		["price"] = "299"									-- Purchase Price
	}
}