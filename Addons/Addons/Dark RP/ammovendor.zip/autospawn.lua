if not SERVER then return end

///////////////////////////////////////////////////
//                                               //			DO NOT EDIT INSIDE THIS BOX.
//   To set the vendor in the position wanted,   //			THIS BOX IS JUST FOR INSTRUCTIONS.
//   move to the location you would like it to   //
//   spawn at.  Then, type "getpos" in your      //
//   console.  User the co-ordinates given to    //
//   correctly position your machine.            ///////////////////////////////////////
//											     									  //
//   You will see a line saying something along the lines of :						  // 
//   setpos 1090.584839 349.115417 -12735.968750;setang 9.503723 69.569496 0.000000   //
//																					  //
//   With this, use the first 3 values to set the : 								  //
//   ||   VendA:SetPos( Vector( 0, 0, 0 ) )   ||                                      //
//   Vector co-ordinates.  															  //
//																					  //
//   With this line : 																  //
//   ||   VendA:SetAngles( Angle(180,0,180) )   ||									  // 
//	            Only change this     ^     angle.                                     //
//																					  //
//   This will rotate the machine left and right.                                     //
//                                            										  //
//												 ///////////////////////////////////////
//   To remove the machine from its default      //
//   position, and delete it, open your    		 //
//   colsole (~), and type "RemoveVendor".       // 
//   											 // 
//   To spawn the vendor back in at its			 //
//   selected position, just open your console   //
//   (~) and type "SpawnVendor".                 // 
//												 // 
//   Note: You must be a super admin or above    //
//         to access the spawn/remove feature.   //                      
//												 //
///////////////////////////////////////////////////

function InitialVendor()					 /////////////////////////////////////////////
	VendA = ents.Create("vendor_ammo")	     //											//
	VendA:SetPos( Vector( 0, 0, 0 ) )		 //   <<  Edit this line for the position   //
	VendA:SetAngles( Angle(180,0,180) )		 //       position.							//
	VendA:Spawn()							 //											//
	VendA:DropToFloor()						 /////////////////////////////////////////////
	local phys = VendA:GetPhysicsObject()
	phys:EnableMotion(false)
	phys:Sleep()
end

function SpawnVendor(ply)
	if ply:IsSuperAdmin() then
		InitialVendor()
	end
end
	
function RemoveVendor(ply)
	if ply:IsSuperAdmin() then
		VendA:Remove()
	end
end

concommand.Add( "SpawnVendor", SpawnVendor )
concommand.Add( "RemoveVendor", RemoveVendor )

hook.Add("InitPostEntity", "InitialVendor", InitialVendor )