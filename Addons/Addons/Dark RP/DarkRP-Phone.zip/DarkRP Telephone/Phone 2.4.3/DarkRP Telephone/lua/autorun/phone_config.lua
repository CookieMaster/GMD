PHONE_EmergencyTeams = { -- These are the teams that will be used when somebody calls for emergency!
	"Civil Protection",
	"Civil Protection Chief" -- THE LAST LINE SHOULD NOT HAVE A COMMA AT THE END. BE AWARE OF THIS WHEN EDITING THIS!
}

WallpapersTable = { 
	{"Rain", "craphead_scripts/phone/backgrounds/phone_rain_bg.png", 100}, -- 0
	{"Drift Car", "craphead_scripts/phone/backgrounds/phone_car_bg.png", 100}, -- 1
	{"Grunge Apple", "craphead_scripts/phone/backgrounds/phone_apple_bg.png", 100}, -- 2
	{"Carbon Fiber", "craphead_scripts/phone/backgrounds/phone_stripes_bg.png", 0}, -- 3
	{"Abstract Stripes", "craphead_scripts/phone/backgrounds/phone_bluestripes_bg.png", 100}, -- 4
	{"Abstract Cubes", "craphead_scripts/phone/backgrounds/phone_cubes_bg.png", 100} -- 5
}

RingtonesTable = { 
	{"Marimba", "craphead_scripts/phone/ringtones/marimba.mp3", 0}, -- 0
	{"Mario", "craphead_scripts/phone/ringtones/mario.mp3", 350}, -- 1
	{"Tetris", "craphead_scripts/phone/ringtones/tetris.mp3", 125} -- 2
}

PHONE_DefaultBackground = 3 -- The default background on the phone.
PHONE_DefaultRingtone = 0 -- The default ringtone on the phone.
PHONE_ActivateButton = KEY_P -- The key on the players keyboard used to open the phone menu. Use KEY_NONE to disable this. [Defaut = KEY_P]
PHONE_ActivateCommand = "PHONE_OpenPhone" -- A console command to the open the phone. [Default = PHONE_OpenPhone]
PHONE_RingtoneRange = 20 -- The range that ringtone emits. [Default = 20]
PHONE_Website = "http://coderhire.com/home/index" -- The website that the website button on the phone will open in a Steam browser window in-game. Must have http:// infront of the link!
PHONE_UseTeamColors = true -- Weather or not to use team colors on names in the call menu on the phone. true/false option. [Default = true]
PHONE_PM_Price = 3 -- How much does it cost to send a private message. [Default = 3]
PHONE_PM_DisableDefaultPM = true -- If you want to disable /pm in DarkRP, set this to true. If not, set this to false. [Default = true]