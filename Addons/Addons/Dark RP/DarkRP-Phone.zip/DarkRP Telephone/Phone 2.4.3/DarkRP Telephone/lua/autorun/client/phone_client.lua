surface.CreateFont("PhoneFont1", {
    font = "Tahoma", 
    size = 15, 
    weight = 900
})

surface.CreateFont("PhoneFont2", {
    font = "Verdana", 
    size = 15, 
    weight = 600
})

surface.CreateFont("PhoneFont3", {
    font = "Trebuchet MS", 
    size = 18, 
    weight = 900
})

local PHONE = {}

function PHONE_OpenPhoneButton()
	if LocalPlayer():IsTyping() then return end
	
	if not gui.IsConsoleVisible() then
		if (input.IsKeyDown(PHONE_ActivateButton)) then
			if (!PHONE.LastActivated) then
				PHONE.LastActivated = true
				if not LocalPlayer().PhoneOpen then
					OpenPhoneMenu()
					LocalPlayer().PhoneOpen = true
				end
			end
		else 
			PHONE.LastActivated = nil 
		end
	end
end
hook.Add("Think", "PHONE_OpenPhoneButton", PHONE_OpenPhoneButton)

function PHONE_OpenPhoneCommand()
	if not LocalPlayer().PhoneOpen then
		OpenPhoneMenu()
		LocalPlayer().PhoneOpen = true
	end
end
concommand.Add(PHONE_ActivateCommand, PHONE_OpenPhoneCommand)

function PHONE_Background( um )	
	LocalPlayer().Background = um:ReadLong()
end
usermessage.Hook("PHONE_SetBackground", PHONE_Background)

function PHONE_Ringtone( um )	
	LocalPlayer().Ringtone = um:ReadLong()
end
usermessage.Hook("PHONE_SetRingtone", PHONE_Ringtone)

function PHONE_BeginCallingPlayer( player, emergency )
	CallingMenu(player, true)
	net.Start("PHONE_Initiate_Call")
		net.WriteString( player:EntIndex() )
		net.WriteString( emergency )
	net.SendToServer()
end

function IncomingCallListener( um )
	PHONE_CloseCurrentMenu()
	IncomingCallMenu( um:ReadEntity(), true, um:ReadString() )
end
usermessage.Hook("PHONE_IncomingCall", IncomingCallListener)

function PHONE_AcceptCall( caller )
	net.Start("PHONE_Accept_Call")
		net.WriteString( caller:EntIndex() )
	net.SendToServer()
	OnCallMenu(caller, true)
end

function DenyCall( caller )
	net.Start("PHONE_Deny_Call")
		net.WriteString( caller:EntIndex() )
	net.SendToServer()
end

function CallWasAccepted(um)
	receiver = um:ReadEntity()
	OnCallMenu(receiver, true)
	CallingFrame:Remove()
	PHONE_SoundHandler(false, 39, "craphead_scripts/phone/dialTone.wav")
end
usermessage.Hook("PHONE_CallWasAccepted", CallWasAccepted)

function CallDenied(um)
	CallingFrame:Remove()
	CallDeniedMenu(receiver, true)
	CallingFrame:Remove()
	PHONE_SoundHandler(false, 39, "craphead_scripts/phone/dialTone.wav")
end
usermessage.Hook("PHONE_CallWasDenied", CallDenied)

function HangUpListener(um)
	caller = um:ReadEntity()
	oncall = um:ReadString()
	
	if oncall == "1" then
		CallEndedMenu( caller, true )
		OnCallMenu( caller, false )
	else
		IncomingCallMenu( caller, false, "0" )
		CallEndedMenu( caller, true )
	end
end
usermessage.Hook("PHONE_HungUpRemote", HangUpListener)

function LineBusy(um)
	LineBusyMenu(um:ReadEntity(), true)
	CallingMenu(um:ReadEntity(), false)
end
usermessage.Hook( "PHONE_AlreadyOnCall", LineBusy )

function PHONE_SoundHandler(shouldPlay, length, sound)
    if (shouldPlay) then
        function playSound()
	        soundIsPlaying = true
	        surface.PlaySound(sound)
	        timer.Simple(length, function() soundIsPlaying = false end)
        end
		
        hook.Add("Think", "playRing", function()
	        if (functionOpen != true && soundIsPlaying != true) then
	         	functionOpen = true
	         	playSound()
			end
		end)
                     
    else
		functionOpen = false
		soundIsPlaying = false
		hook.Remove("Think", "playRing")
		RunConsoleCommand("stopsound")
	end
end

function PHONE_CloseCurrentMenu()
	if IsValid(LocalPlayer().FrameOpen) then
		LocalPlayer().FrameOpen:Remove()
	end
end

function OpenPhoneMenu()
	
	local PhoneMenu = vgui.Create( "DFrame" )
	PhoneMenu:SetSize( ScrW() * 0.155,ScrH() * 0.47 )
	PhoneMenu:SetPos( PhoneMenu:GetWide() / 0.19,PhoneMenu:GetTall()* 1.1 )
	PhoneMenu:SetTitle( "" )
	PhoneMenu:SetVisible( true )
	PhoneMenu:SetDraggable( false )
	PhoneMenu:ShowCloseButton( false )
	PhoneMenu.Paint = function(panel)
				draw.RoundedBox(8,1,1,PhoneMenu:GetWide()-2,PhoneMenu:GetTall()-2,Color(0,0,0,0))
	end
	//PhoneMenu:MakePopup()
	LocalPlayer().FrameOpen = PhoneMenu
	
	PhonePicture = vgui.Create( "DImage", PhoneMenu )
	PhonePicture:SetPos( ScrW() * -0.055, 0 )
	PhonePicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
	PhonePicture:SetImage( "craphead_scripts/phone/ocrp_phone.png" )

	BackgroundPicture = vgui.Create( "DImage", PhoneMenu )
	BackgroundPicture:SetPos( ScrW() * -0.055, 0 )
	BackgroundPicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
	BackgroundPicture:SetImage( WallpapersTable[(LocalPlayer().Background + 1) or PHONE_DefaultBackground][2] )

	MainMenuPicture = vgui.Create( "DImage", PhoneMenu )
	MainMenuPicture:SetPos( ScrW() * -0.055, 0 )
	MainMenuPicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
	MainMenuPicture:SetImage( "craphead_scripts/phone/menus/phone_mainmenu.png" )

	local ShutDownButton = vgui.Create("DButton")
	ShutDownButton:SetParent( PhoneMenu )
	ShutDownButton:SetSize( ScrW() * 0.025, ScrH() * 0.01 )
	ShutDownButton:SetPos( ScrW() * 0.095, ScrH() * 0.001 )
	ShutDownButton:SetDrawBackground(false)
	ShutDownButton.Paint = function(panel)
		draw.RoundedBox(8,1,1,ShutDownButton:GetWide()-2,ShutDownButton:GetTall()-2,Color(0,0,0,0))
	end
	ShutDownButton:SetText("")
	ShutDownButton.DoClick = function()
		PhoneMenu:Remove()
		LocalPlayer().PhoneOpen = false
		LocalPlayer().FrameOpen = nil
	end
	
	local HomeButton = vgui.Create("DButton") -- Close button in this case.
	HomeButton:SetParent( PhoneMenu )
	HomeButton:SetSize( ScrW() * 0.025, ScrH() * 0.05 )
	HomeButton:SetPos( ScrW() * 0.065, ScrH() * 0.4 )
	HomeButton:SetDrawBackground(false)
	HomeButton.Paint = function()
		draw.RoundedBox(8,1,1,HomeButton:GetWide()-2,HomeButton:GetTall()-2,Color(0,0,0,0))
	end
	HomeButton:SetText("")
	HomeButton.DoClick = function()
	    PhoneMenu:Remove()
		LocalPlayer().PhoneOpen = false
		LocalPlayer().FrameOpen = nil
	end
	
	local GroupsButton = vgui.Create("DButton")
	GroupsButton:SetParent( PhoneMenu )
	GroupsButton:SetSize( ScrW() * 0.025, ScrH() * 0.05 )
	GroupsButton:SetPos( ScrW() * 0.025, ScrH() * 0.34 )
	GroupsButton:SetDrawBackground(false)
	GroupsButton.Paint = function()
		draw.RoundedBox(8,1,1,GroupsButton:GetWide()-2,GroupsButton:GetTall()-2,Color(0,0,0,0))
	end
	GroupsButton:SetText("")
	GroupsButton.DoClick = function()
		PhoneMenu:Remove()
		OpenGroupsMenu()
	end
	
	local WebsiteButton = vgui.Create("DButton")
	WebsiteButton:SetParent( PhoneMenu )
	WebsiteButton:SetSize( ScrW() * 0.025, ScrH() * 0.05 )
	WebsiteButton:SetPos( ScrW() * 0.078, ScrH() * 0.34 )
	WebsiteButton:SetDrawBackground(false)
	WebsiteButton.Paint = function()
		draw.RoundedBox(8,1,1,WebsiteButton:GetWide()-2,WebsiteButton:GetTall()-2,Color(0,0,0,0))
	end
	WebsiteButton:SetText("")
	WebsiteButton.DoClick = function()
		PhoneMenu:Remove()
		LocalPlayer().PhoneOpen = false
		LocalPlayer().FrameOpen = nil
		gui.OpenURL(PHONE_Website)
	end
	
	local MessageButton = vgui.Create("DButton")
	MessageButton:SetParent( PhoneMenu )
	MessageButton:SetSize( ScrW() * 0.025, ScrH() * 0.05 )
	MessageButton:SetPos( ScrW() * 0.05, ScrH() * 0.34 )
	MessageButton:SetDrawBackground(false)
	MessageButton.Paint = function()
		draw.RoundedBox(8,1,1,MessageButton:GetWide()-2,MessageButton:GetTall()-2,Color(0,0,0,0))
	end
	MessageButton:SetText("")
	MessageButton.DoClick = function()
		GUI_PMMenu()
	end

	local SettingsButton = vgui.Create("DButton")
	SettingsButton:SetParent( PhoneMenu )
	SettingsButton:SetSize( ScrW() * 0.025, ScrH() * 0.05 )
	SettingsButton:SetPos( ScrW() * 0.025, ScrH() * 0.1 )
	SettingsButton:SetDrawBackground(false)
	SettingsButton.Paint = function()
		draw.RoundedBox(8,1,1,SettingsButton:GetWide()-2,SettingsButton:GetTall()-2,Color(0,0,0,0))
	end
	SettingsButton:SetText("")
	SettingsButton.DoClick = function()
		PhoneMenu:Remove()
		OpenSettingsMenu(true)
	end

end






function OpenGroupsMenu()

    local GroupsMenu = vgui.Create( "DFrame" )
    GroupsMenu:SetSize( ScrW() * 0.155,ScrH() * 0.47 )
	GroupsMenu:SetPos( GroupsMenu:GetWide() / 0.19,GroupsMenu:GetTall()* 1.1 )
    GroupsMenu:SetTitle( "" )
    GroupsMenu:SetVisible( true )
    GroupsMenu:SetDraggable( false )
    GroupsMenu:ShowCloseButton( false )
    GroupsMenu.Paint = function(panel)
                draw.RoundedBox(8,1,1,GroupsMenu:GetWide()-2,GroupsMenu:GetTall()-2,Color(0,0,0,0))
    end
    //GroupsMenu:MakePopup()
	LocalPlayer().FrameOpen = GroupsMenu
	
    PhonePicture = vgui.Create( "DImage", GroupsMenu )
	PhonePicture:SetPos( ScrW() * -0.055, 0 )
	PhonePicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
	PhonePicture:SetImage( "craphead_scripts/phone/ocrp_phone.png" )

    MainMenuPicture = vgui.Create( "DImage", GroupsMenu )
    MainMenuPicture:SetPos( ScrW() * -0.055, 0 )
	MainMenuPicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
    MainMenuPicture:SetImage( "craphead_scripts/phone/menus/phone_groupsmenu.png" )

    local ShutDownButton = vgui.Create("DButton")
    ShutDownButton:SetParent( GroupsMenu )
    ShutDownButton:SetSize( ScrW() * 0.025, ScrH() * 0.01 )
	ShutDownButton:SetPos( ScrW() * 0.095, ScrH() * 0.001 )
    ShutDownButton:SetDrawBackground(false)
    ShutDownButton.Paint = function(panel)
        draw.RoundedBox(8,1,1,ShutDownButton:GetWide()-2,ShutDownButton:GetTall()-2,Color(0,0,0,0))
    end
    ShutDownButton:SetText("")
    ShutDownButton.DoClick = function()
        GroupsMenu:Remove()
		LocalPlayer().PhoneOpen = false
		LocalPlayer().FrameOpen = nil
    end

    local BackButton = vgui.Create("DButton")
    BackButton:SetParent( GroupsMenu )
    BackButton:SetSize( ScrW() * 0.025, ScrH() * 0.025 )
    BackButton:SetPos( ScrW() * 0.025, ScrH() * 0.1 )
    BackButton:SetDrawBackground(false)
    BackButton.Paint = function()
        draw.RoundedBox(8,1,1,BackButton:GetWide()-2,BackButton:GetTall()-2,Color(0,0,0,0))
    end
    BackButton:SetText("")
    BackButton.DoClick = function()
        GroupsMenu:Remove()
        OpenPhoneMenu()
    end

    local CallAllButton = vgui.Create("DButton")
    CallAllButton:SetParent( GroupsMenu )
    CallAllButton:SetSize( ScrW() * 0.1, ScrH() * 0.022 )
    CallAllButton:SetPos( ScrW() * 0.025, ScrH() * 0.127 )
    CallAllButton:SetDrawBackground(false)
    CallAllButton.Paint = function()
        draw.RoundedBox(8,1,1,CallAllButton:GetWide()-2,CallAllButton:GetTall()-2,Color(0,0,0,0))
    end
    CallAllButton:SetText("")
    CallAllButton.DoClick = function()
        GroupsMenu:Remove()
        OpenCallMenu(player.GetAll(), true)
    end

    local CallOrgButton = vgui.Create("DButton")
    CallOrgButton:SetParent( GroupsMenu )
    CallOrgButton:SetSize( ScrW() * 0.105, ScrH() * 0.022 )
    CallOrgButton:SetPos( ScrW() * 0.025, ScrH() * 0.155 )
    CallOrgButton:SetDrawBackground(false)
    CallOrgButton.Paint = function()
        draw.RoundedBox(8,1,1,CallOrgButton:GetWide()-2,CallOrgButton:GetTall()-2,Color(0,0,0,0))
		surface.SetDrawColor(Color( 255, 255, 255, 255 ))
		surface.SetMaterial(Material("craphead_scripts/phone/icons/delete.png"))
		surface.DrawTexturedRect(ScrW() * 0.091, ScrH() * 0.0005, 20, 20)
    end
    CallOrgButton:SetText("")
    CallOrgButton.DoClick = function()
        --GroupsMenu:Remove()
        --OpenCallMenu(player.GetAll(), true)
		LocalPlayer():ChatPrint("This option is not available on your device.")
    end

    local CallBuddiesButton = vgui.Create("DButton")
    CallBuddiesButton:SetParent( GroupsMenu )
    CallBuddiesButton:SetSize( ScrW() * 0.105, ScrH() * 0.022 )
    CallBuddiesButton:SetPos( ScrW() * 0.025, ScrH() * 0.18 )
    CallBuddiesButton:SetDrawBackground(false)
    CallBuddiesButton.Paint = function()
        draw.RoundedBox(8,1,1,CallBuddiesButton:GetWide()-2,CallBuddiesButton:GetTall()-2,Color(0,0,0,0))
		surface.SetDrawColor(Color( 255, 255, 255, 255 ))
		surface.SetMaterial(Material("craphead_scripts/phone/icons/delete.png"))
		surface.DrawTexturedRect(ScrW() * 0.091, ScrH() * 0.0035, 20, 20)
    end
    CallBuddiesButton:SetText("")
    CallBuddiesButton.DoClick = function()
        --GroupsMenu:Remove()
        --OpenCallMenu(OCRP_Buddies, true)
		LocalPlayer():ChatPrint("This option is not available on your device.")
    end

    local CallSFButton = vgui.Create("DButton")
    CallSFButton:SetParent( GroupsMenu )
    CallSFButton:SetSize( ScrW() * 0.105, ScrH() * 0.022 )
    CallSFButton:SetPos( ScrW() * 0.025, ScrH() * 0.21 )
    CallSFButton:SetDrawBackground(false)
    CallSFButton.Paint = function()
		draw.RoundedBox(8,1,1,CallSFButton:GetWide()-2,CallSFButton:GetTall()-2,Color(0,0,0,0))
		surface.SetDrawColor(Color( 255, 255, 255, 255 ))
		surface.SetMaterial(Material("craphead_scripts/phone/icons/delete.png"))
		surface.DrawTexturedRect(ScrW() * 0.091, ScrH() * 0.0005, 20, 20)
    end
    CallSFButton:SetText("")
    CallSFButton.DoClick = function()
        --GroupsMenu:Remove()
        --OpenCallMenu(player.GetAll(), true)
		LocalPlayer():ChatPrint("This option is not available on your device.")
    end
	
	local EmergencyButton = vgui.Create("DButton")
    EmergencyButton:SetParent( GroupsMenu )
    EmergencyButton:SetSize( ScrW() * 0.1, ScrH() * 0.025 )
    EmergencyButton:SetPos( ScrW() * 0.025, ScrH() * 0.355 )
    EmergencyButton:SetDrawBackground(false)
    EmergencyButton.Paint = function()
        draw.RoundedBox(8,1,1,EmergencyButton:GetWide()-2,EmergencyButton:GetTall()-2,Color(0,0,0,0))
    end
    EmergencyButton:SetText("")
    EmergencyButton.DoClick = function()
		GroupsMenu:Remove()
		local PlayerFound = false
		local PlayersChecked = 0
		
		if table.HasValue( PHONE_EmergencyTeams, team.GetName( LocalPlayer():Team()) ) then
			LocalPlayer():ChatPrint("You can not use this feature as an emergency unit!")
			LocalPlayer().PhoneOpen = false
			LocalPlayer().FrameOpen = nil
			return
		end
		
		for k, v in pairs(player.GetAll()) do
			PlayersChecked = PlayersChecked + 1
			
			if table.HasValue( PHONE_EmergencyTeams, team.GetName( v:Team()) ) then
				PlayerFound = true
				PHONE_BeginCallingPlayer(v, "1")
				break
			end
			
			if PlayersChecked == #player.GetAll() then
				if not PlayerFound then
					LocalPlayer():ChatPrint("There are no emergency units available!")
					LocalPlayer().PhoneOpen = false
					LocalPlayer().FrameOpen = nil
				end
			end
		end
    end
end





function OpenCallMenu(SelectedContacts, shouldShow)
    if (!shouldShow && ContactsListFrame != nil) then
        ContactsListFrame:Remove()
    elseif (shouldShow) then
		local ContactsListFrame = vgui.Create( "DFrame" )
		ContactsListFrame:SetSize( ScrW() * 0.155,ScrH() * 0.47 )
		ContactsListFrame:SetPos( ContactsListFrame:GetWide() / 0.19,ContactsListFrame:GetTall()* 1.1 )
		ContactsListFrame:SetTitle( "" )
		ContactsListFrame:SetVisible( true )
		ContactsListFrame:SetDraggable( false )
		ContactsListFrame:ShowCloseButton( false )
		ContactsListFrame.Paint = function()
		draw.RoundedBox(8,1,1,ContactsListFrame:GetWide()-2,ContactsListFrame:GetTall()-2,Color(0,0,0,0))
		end
		//ContactsListFrame:MakePopup()
		LocalPlayer().FrameOpen = ContactsListFrame
		
		PhonePicture = vgui.Create( "DImage", ContactsListFrame )
		PhonePicture:SetPos( ScrW() * -0.055, 0 )
		PhonePicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
		PhonePicture:SetImage( "craphead_scripts/phone/ocrp_phone.png" )

		ContactsPicture = vgui.Create( "DImage", ContactsListFrame )
		ContactsPicture:SetPos( ScrW() * -0.055, 0 )
		ContactsPicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
		ContactsPicture:SetImage( "craphead_scripts/phone/menus/phone_contactsmenu.png" )

		local BackButton = vgui.Create("DButton")
		BackButton:SetParent( ContactsListFrame )
		BackButton:SetSize( ScrW() * 0.025, ScrH() * 0.025 )
		BackButton:SetPos( ScrW() * 0.025, ScrH() * 0.1 )
		BackButton:SetDrawBackground(false)
		BackButton.Paint = function()
			draw.RoundedBox(8,1,1,BackButton:GetWide()-2,BackButton:GetTall()-2,Color(0,0,0,0))
		end
		BackButton:SetText("")
		BackButton.DoClick = function()
			ContactsListFrame:Remove()
			OpenGroupsMenu()
		end

		local ShutDownButton = vgui.Create("DButton")
		ShutDownButton:SetParent( ContactsListFrame )
		ShutDownButton:SetSize( ScrW() * 0.025, ScrH() * 0.01 )
		ShutDownButton:SetPos( ScrW() * 0.095, ScrH() * 0.001 )
		ShutDownButton:SetDrawBackground(false)
		ShutDownButton.Paint = function()
			draw.RoundedBox(8,1,1,ShutDownButton:GetWide()-2,ShutDownButton:GetTall()-2,Color(0,0,0,0))
		end
		ShutDownButton:SetText("")
		ShutDownButton.DoClick = function()
			ContactsListFrame:Remove()
			LocalPlayer().PhoneOpen = false
			LocalPlayer().FrameOpen = nil
		end

		local HomeButton = vgui.Create("DButton")
		HomeButton:SetParent( ContactsListFrame )
		HomeButton:SetSize( ScrW() * 0.025, ScrH() * 0.05 )
		HomeButton:SetPos( ScrW() * 0.065, ScrH() * 0.4 )
		HomeButton:SetDrawBackground(false)
		HomeButton.Paint = function()
			draw.RoundedBox(8,1,1,HomeButton:GetWide()-2,HomeButton:GetTall()-2,Color(0,0,0,0))
		end
		HomeButton:SetText("")
			HomeButton.DoClick = function()
			ContactsListFrame:Remove()
			OpenPhoneMenu()
		end
				
		local PhoneScroll = vgui.Create( "DPanelList", ContactsListFrame )
		PhoneScroll:SetWide( ScrW() * 0.1275 )
		PhoneScroll:SetTall( ScrH() * 0.265 )
		PhoneScroll:SetPos( ScrW() * 0.005, ScrH() * 0.125 )
		PhoneScroll:SetSpacing( -8 )
		PhoneScroll:EnableVerticalScrollbar( true )
		PhoneScroll:EnableHorizontal( true )
		PhoneScroll.Paint = function()
	        --draw.RoundedBox(8,30,10,PhoneScroll:GetWide()-2,PhoneScroll:GetTall()-2,Color( 0, 0, 0, 200 ))
        end

        players = {}

        for k,v in pairs(SelectedContacts) do
			if v:Nick() != LocalPlayer():Nick() then
				local teamclr = team.GetColor( v:Team() )
				
				local PlayerList = vgui.Create( "DPanelList" )
				PlayerList:SetParent( PhoneScroll )
				//PlayerList:SetPos( ScrW() * 0.001, ScrH() * 0.115 )
				PlayerList:SetPos(0,0)
				PlayerList:SetWide( ScrW() * 0.125 )
				PlayerList:SetTall( ScrH() * 0.035 )
				PlayerList:SetSpacing( 5 )
				PlayerList:EnableVerticalScrollbar( true )
				PlayerList:EnableHorizontal( true )
				PlayerList.Paint = function()
					//draw.RoundedBox(8,30,10,PlayerList:GetWide()-2,PlayerList:GetTall()-2,Color( 200, 0, 0, 50 ))
				end
					
				players[k] = vgui.Create( "DButton", PlayerList)
				players[k]:SetPos( ScrW() * 0.02, ScrH() * 0.005) 
				players[k]:SetSize( ScrW() * 0.11, ScrH() * 0.02 ) 
				players[k]:SetText("")
				players[k].Paint = function()
					draw.RoundedBox(8,1,1,players[k]:GetWide()-2,players[k]:GetTall()-2,Color(0,0,0,0))
					if PHONE_UseTeamColors then
						surface.SetTextColor(  teamclr.r, teamclr.g, teamclr.b, 200 )
					else
						surface.SetTextColor(  0, 0, 0, 200 )
					end
					surface.SetTextPos( 10, 3 ) 
					surface.SetFont("PhoneFont1")
					surface.DrawText( v:Nick() )
				end
				players[k].DoClick = function ()      	         
					if v:Nick() == LocalPlayer():Nick() then
						LocalPlayer():ChatPrint("You cannot call yourself.")
					else
						PHONE_BeginCallingPlayer(v, "0")
						ContactsListFrame:Remove()
					end
				end
				PhoneScroll:AddItem( PlayerList )
			end
        end
    end
end





function CallingMenu(receiver, shouldShow)
    if (!shouldShow) then
        CallingFrame:Remove()
    elseif (shouldShow) then
        PHONE_SoundHandler(true, 39, "craphead_scripts/phone/dialTone.wav")
		
        CallingFrame = vgui.Create( "DFrame" )
		CallingFrame:SetSize( ScrW() * 0.155,ScrH() * 0.47 )
		CallingFrame:SetPos( CallingFrame:GetWide() / 0.19,CallingFrame:GetTall()* 1.1 )
		CallingFrame:SetTitle( "" )
		CallingFrame:SetVisible( true )
		CallingFrame:SetDraggable( false )
		CallingFrame:ShowCloseButton( false )
		CallingFrame.Paint = function()
			draw.RoundedBox(8,1,1,CallingFrame:GetWide()-2,CallingFrame:GetTall()-2,Color(0,0,0,0))
		end
		//CallingFrame:MakePopup()
		LocalPlayer().FrameOpen = CallingFrame

		PhoneImage = vgui.Create( "DImage", CallingFrame )
        PhoneImage:SetPos( ScrW() * -0.055, 0 )
		PhoneImage:SetSize(ScrW() * 0.262, ScrH() * 0.48)
        PhoneImage:SetImage( "craphead_scripts/phone/ocrp_phone.png" )

        MainMenuPicture = vgui.Create( "DImage", CallingFrame )
        MainMenuPicture:SetPos( ScrW() * -0.055, 0 )
		MainMenuPicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
        MainMenuPicture:SetImage( "craphead_scripts/phone/menus/phone_oncallmenu.png" )

        surface.SetFont( "PhoneFont2" )

        local x, y = surface.GetTextSize( receiver:Nick() )

        local CallingName = vgui.Create( "DLabel", CallingFrame )
        CallingName:SetText( receiver:Nick() )
        CallingName:SetPos( ( CallingFrame:GetWide() / 2.5 ) - ( x / 2 ), ScrH() * 0.11 ) 
        CallingName:SetFont( "PhoneFont2" )
        CallingName:SetTextColor( Color( 255, 255, 255, 255 ) ) 
        CallingName:SizeToContents()

        local whatwedo, y = surface.GetTextSize( "Calling..." )

        local WhatWeDo = vgui.Create( "DLabel", CallingFrame )
        WhatWeDo:SetText( "Calling..." )
        WhatWeDo:SetPos( ( CallingFrame:GetWide() / 2.4 ) - ( whatwedo / 2 ), ScrH() * 0.13  ) 
        WhatWeDo:SetFont( "PhoneFont2" )
        WhatWeDo:SetTextColor( Color( 255, 255, 255, 255 ) ) 
        WhatWeDo:SizeToContents()

        local CallersAvatar = vgui.Create( "AvatarImage", CallingFrame )
        CallersAvatar:SetPos( ScrW() * 0.1, ScrH() * 0.102 )
        CallersAvatar:SetSize( ScrW() * 0.028, ScrH() * 0.046 )
        CallersAvatar:SetPlayer( receiver, 32 )
		
		timer.Simple(1.5, function()
			local HangUpButton = vgui.Create("DButton")
			HangUpButton:SetParent( CallingFrame )
			HangUpButton:SetSize( ScrW() * 0.1, ScrH() * 0.05 )
			HangUpButton:SetPos( ScrW() * 0.026, ScrH() * 0.34 )
			HangUpButton:SetDrawBackground(false)
			HangUpButton.Paint = function()
				 draw.RoundedBox(8,1,1,HangUpButton:GetWide()-2,HangUpButton:GetTall()-2,Color(0,0,0,0))
			end
			HangUpButton:SetText("")
			HangUpButton.DoClick = function()
				CallingFrame:Remove()
				net.Start("PHONE_End_Call")
					net.WriteString( receiver:EntIndex() )
					net.WriteString( "0" )
				net.SendToServer()
				
				CallEndedMenu( receiver, true )
				
				PHONE_SoundHandler(false, 39, "craphead_scripts/phone/dialTone.wav")
				LocalPlayer().PhoneOpen = false
				LocalPlayer().FrameOpen = nil
			end
		end)
    end
end





function OnCallMenu(receiver, shouldShow)
	if (!shouldShow) then
	    OnCallFrame:Remove()
	elseif (shouldShow) then
        PHONE_SoundHandler(true, 39, "craphead_scripts/phone/dialTone.wav")
		
        OnCallFrame = vgui.Create( "DFrame" )
        OnCallFrame:SetSize( ScrW() * 0.155,ScrH() * 0.47 )
		OnCallFrame:SetPos( OnCallFrame:GetWide() / 0.19,OnCallFrame:GetTall()* 1.1 )
        OnCallFrame:SetTitle( "" )
        OnCallFrame:SetVisible( true )
        OnCallFrame:SetDraggable( false )
        OnCallFrame:ShowCloseButton( false )
        OnCallFrame.Paint = function()
                    draw.RoundedBox(8,1,1,OnCallFrame:GetWide()-2,OnCallFrame:GetTall()-2,Color(0,0,0,0))
        end
        --OnCallFrame:MakePopup()
		LocalPlayer().FrameOpen = OnCallFrame
		
        PhoneImage = vgui.Create( "DImage", OnCallFrame )
        PhoneImage:SetPos( ScrW() * -0.055, 0 )
		PhoneImage:SetSize(ScrW() * 0.262, ScrH() * 0.48)
		PhoneImage:SetImage( "craphead_scripts/phone/ocrp_phone.png" )

        MainMenuPicture = vgui.Create( "DImage", OnCallFrame )
        MainMenuPicture:SetPos( ScrW() * -0.055, 0 )
		MainMenuPicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
        MainMenuPicture:SetImage( "craphead_scripts/phone/menus/phone_oncallmenu.png" )

        surface.SetFont( "PhoneFont2" )
        local x, y = surface.GetTextSize( receiver:Nick() )

        local CallingName = vgui.Create( "DLabel", OnCallFrame )
        CallingName:SetText( receiver:Nick() )
        CallingName:SetPos( ( OnCallFrame:GetWide() / 2.5 ) - ( x / 2 ), ScrH() * 0.11  ) 
        CallingName:SetFont( "PhoneFont2" )
        CallingName:SetTextColor( Color( 255, 255, 255, 255 ) ) 
        CallingName:SizeToContents()

        local whatwedo, y = surface.GetTextSize( "Talking.." )

        local WhatWeDo = vgui.Create( "DLabel", OnCallFrame )
        WhatWeDo:SetText( "Talking..." )
        WhatWeDo:SetPos( ( OnCallFrame:GetWide() / 2.4 ) - ( whatwedo / 2 ), ScrH() * 0.13  ) 
        WhatWeDo:SetFont( "PhoneFont2" )
        WhatWeDo:SetTextColor( Color( 255, 255, 255, 255 ) ) 
        WhatWeDo:SizeToContents()

        local CallersAvatar = vgui.Create( "AvatarImage", OnCallFrame )
		CallersAvatar:SetPos( ScrW() * 0.1, ScrH() * 0.102 )
		CallersAvatar:SetSize( ScrW() * 0.028, ScrH() * 0.046 )
		CallersAvatar:SetPlayer( receiver, 32 )
		
		timer.Simple(1.5, function()
			local HangUpButton = vgui.Create("DButton")
			HangUpButton:SetParent( OnCallFrame )
			HangUpButton:SetSize( ScrW() * 0.1, ScrH() * 0.05 )
			HangUpButton:SetPos( ScrW() * 0.026, ScrH() * 0.34 )
			HangUpButton:SetDrawBackground(false)
			HangUpButton.Paint = function()
						draw.RoundedBox(8,1,1,HangUpButton:GetWide()-2,HangUpButton:GetTall()-2,Color(0,0,0,0))
			end
			HangUpButton:SetText("")
			HangUpButton.DoClick = function()
				OnCallFrame:Remove()
				if receiver:IsValid() then
					net.Start("PHONE_End_Call")
						net.WriteString( receiver:EntIndex() )
						net.WriteString( "1" )
					net.SendToServer()

					CallEndedMenu(receiver, true)
				else
					net.Start("PHONE_EndNotValid_Call")
					net.SendToServer()
					LocalPlayer().PhoneOpen = false
					LocalPlayer().FrameOpen = nil
				end
			end
		end)
	end
end





function CallDeniedMenu(receiver, shouldShow)
    if (!shouldShow) then
        LineBusyFrame:Remove()
    elseif (shouldShow) then
       PHONE_SoundHandler(true, 4, "craphead_scripts/phone/error.mp3")

		LineBusyFrame = vgui.Create( "DFrame" )
		LineBusyFrame:SetSize( ScrW() * 0.155,ScrH() * 0.47 )
		LineBusyFrame:SetPos( LineBusyFrame:GetWide() / 0.19,LineBusyFrame:GetTall()* 1.1 )
		LineBusyFrame:SetTitle( "" )
		LineBusyFrame:SetVisible( true )
		LineBusyFrame:SetDraggable( false )
		LineBusyFrame:ShowCloseButton( false )
		LineBusyFrame.Paint = function()
			draw.RoundedBox(8,1,1,LineBusyFrame:GetWide()-2,LineBusyFrame:GetTall()-2,Color(0,0,0,0))
		end
		//LineBusyFrame:MakePopup()
		LocalPlayer().FrameOpen = LineBusyFrame
		
		PhoneImage = vgui.Create( "DImage", LineBusyFrame )
		PhoneImage:SetPos( ScrW() * -0.055, 0 )
		PhoneImage:SetSize(ScrW() * 0.262, ScrH() * 0.48)
		PhoneImage:SetImage( "craphead_scripts/phone/ocrp_phone.png" )

		MainMenuPicture = vgui.Create( "DImage", LineBusyFrame )
		MainMenuPicture:SetPos( ScrW() * -0.055, 0 )
		MainMenuPicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
		MainMenuPicture:SetImage( "craphead_scripts/phone/menus/phone_oncallmenu.png" )

		surface.SetFont( "PhoneFont2" )
		local x, y = surface.GetTextSize( "Call Denied" )

		local LineIsBusy = vgui.Create( "DLabel", LineBusyFrame )
		LineIsBusy:SetText( "Call Denied" )
		LineIsBusy:SetPos( ( LineBusyFrame:GetWide() / 2 ) - ( x / 2 ), ScrH() * 0.12  ) 
		LineIsBusy:SetFont( "PhoneFont2" )
		LineIsBusy:SetTextColor( Color( 255, 255, 255, 255 ) ) 
		LineIsBusy:SizeToContents()

		timer.Simple(2, function()
			CallDeniedMenu(receiver, false)
			PHONE_SoundHandler(false, 4, "craphead_scripts/phone/error.mp3")
			LocalPlayer().PhoneOpen = false
			LocalPlayer().FrameOpen = nil
		end)
    end
end


function CallEndedMenu(receiver, shouldShow)
    if (!shouldShow) then
		--CallEndedFrame:Remove()
    elseif (shouldShow) then
        PHONE_SoundHandler(true, 4, "craphead_scripts/phone/error.mp3")
		PHONE_SoundHandler(false, 13, LocalPlayer().Ringtone)

        CallEndedFrame = vgui.Create( "DFrame" )
        CallEndedFrame:SetSize( ScrW() * 0.155,ScrH() * 0.47 )
		CallEndedFrame:SetPos( CallEndedFrame:GetWide() / 0.19,CallEndedFrame:GetTall()* 1.1 )
        CallEndedFrame:SetTitle( "" )
        CallEndedFrame:SetVisible( true )
		CallEndedFrame:SetDraggable( false )
        CallEndedFrame:ShowCloseButton( false )
        CallEndedFrame.Paint = function()
	        draw.RoundedBox(8,1,1,CallEndedFrame:GetWide()-2,CallEndedFrame:GetTall()-2,Color(0,0,0,0))
        end
		//CallEndedFrame:MakePopup()
		LocalPlayer().FrameOpen = CallEndedFrame
		
        PhoneImage = vgui.Create( "DImage", CallEndedFrame )
        PhoneImage:SetPos( ScrW() * -0.055, 0 )
		PhoneImage:SetSize(ScrW() * 0.262, ScrH() * 0.48)
        PhoneImage:SetImage( "craphead_scripts/phone/ocrp_phone.png" )

        MainMenuPicture = vgui.Create( "DImage", CallEndedFrame )
        MainMenuPicture:SetPos( ScrW() * -0.055, 0 )
		MainMenuPicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
        MainMenuPicture:SetImage( "craphead_scripts/phone/menus/phone_oncallmenu.png" )

        surface.SetFont( "PhoneFont2" )
        local x, y = surface.GetTextSize( receiver:Nick() )

        local CallingName = vgui.Create( "DLabel", CallEndedFrame )
        CallingName:SetText( receiver:Nick() )
        CallingName:SetPos( ( CallEndedFrame:GetWide() / 2.5 ) - ( x / 2 ), ScrH() * 0.11  ) 
        CallingName:SetFont( "PhoneFont2" )
        CallingName:SetTextColor( Color( 255, 255, 255, 255 ) ) 
        CallingName:SizeToContents()

        local whatwedo, y = surface.GetTextSize( "Call Ended" )

        local WhatWeDo = vgui.Create( "DLabel", CallEndedFrame )
        WhatWeDo:SetText( "Call Ended")
        WhatWeDo:SetPos( ( CallEndedFrame:GetWide() / 2.5 ) - ( whatwedo / 2 ), ScrH() * 0.13  ) 
        WhatWeDo:SetFont( "PhoneFont2" )
        WhatWeDo:SetTextColor( Color( 255, 255, 255, 255 ) ) 
        WhatWeDo:SizeToContents()

        local CallersAvatar = vgui.Create( "AvatarImage", CallEndedFrame )
		CallersAvatar:SetPos( ScrW() * 0.1, ScrH() * 0.102 )
		CallersAvatar:SetSize( ScrW() * 0.028, ScrH() * 0.046 )
		CallersAvatar:SetPlayer( receiver, 32 )

        timer.Simple(2, function() 
	        CallEndedFrame:Remove() 
			PHONE_SoundHandler(false, 4, "craphead_scripts/phone/error.mp3")
			LocalPlayer().PhoneOpen = false
			LocalPlayer().FrameOpen = nil
        end)
    end
end





function IncomingCallMenu(caller, shouldShow, emergency)

	if (!shouldShow) then
	    BeingCalledFrame:Remove()
	elseif (shouldShow) then
	    PHONE_SoundHandler(true, 13, LocalPlayer().Ringtone)
		
		if not LocalPlayer().PhoneOpen then
			LocalPlayer().PhoneOpen = true
		end
		
	    BeingCalledFrame = vgui.Create( "DFrame" )
	    BeingCalledFrame:SetSize( ScrW() * 0.155,ScrH() * 0.47 )
		BeingCalledFrame:SetPos( BeingCalledFrame:GetWide() / 0.19,BeingCalledFrame:GetTall()* 1.1 )
	    BeingCalledFrame:SetTitle( "" )
	    BeingCalledFrame:SetVisible( true )
		BeingCalledFrame:SetDraggable( false )
	    BeingCalledFrame:ShowCloseButton( false )
	    BeingCalledFrame.Paint = function()
	        draw.RoundedBox(8,1,1,BeingCalledFrame:GetWide()-2,BeingCalledFrame:GetTall()-2,Color(0,0,0,0))
	    end
	    //BeingCalledFrame:MakePopup()
		LocalPlayer().FrameOpen = BeingCalledFrame
		
	    PhoneImage = vgui.Create( "DImage", BeingCalledFrame )
	    PhoneImage:SetPos( ScrW() * -0.055, 0 )
		PhoneImage:SetSize(ScrW() * 0.262, ScrH() * 0.48)
	    PhoneImage:SetImage( "craphead_scripts/phone/ocrp_phone.png" )

	    MainMenuPicture = vgui.Create( "DImage", BeingCalledFrame )
	    MainMenuPicture:SetPos( ScrW() * -0.055, 0 )
		MainMenuPicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
	    MainMenuPicture:SetImage( "craphead_scripts/phone/menus/phone_incomingcallmenu.png" )

	    surface.SetFont( "PhoneFont2" )
	    local x, y = surface.GetTextSize( caller:Nick() )
		
		if emergency == "1" then
			local Emergency = vgui.Create( "DLabel", BeingCalledFrame )
			Emergency:SetText( "Emergency Call" )
			Emergency:SetPos( ( BeingCalledFrame:GetWide() / 2.5 ) - ( x / 2 ), ScrH() * 0.11  ) 
			Emergency:SetFont( "PhoneFont2" )
			Emergency:SetTextColor( Color( 200, 0, 0, 255 ) ) 
			Emergency:SizeToContents()
			
			local CalledBy = vgui.Create( "DLabel", BeingCalledFrame )
			CalledBy:SetText( caller:Nick() )
			CalledBy:SetPos( ( BeingCalledFrame:GetWide() / 2.4 ) - ( x / 2 ), ScrH() * 0.13  ) 
			CalledBy:SetFont( "PhoneFont2" )
			CalledBy:SetTextColor( Color( 255, 255, 255, 255 ) ) 
			CalledBy:SizeToContents()
		else
			local CalledBy = vgui.Create( "DLabel", BeingCalledFrame )
			CalledBy:SetText( caller:Nick() )
			CalledBy:SetPos( ( BeingCalledFrame:GetWide() / 2.4 ) - ( x / 2 ), ScrH() * 0.12  ) 
			CalledBy:SetFont( "PhoneFont2" )
			CalledBy:SetTextColor( Color( 255, 255, 255, 255 ) ) 
			CalledBy:SizeToContents()
		end

        local CallersAvatar = vgui.Create( "AvatarImage", BeingCalledFrame )
		CallersAvatar:SetPos( ScrW() * 0.1, ScrH() * 0.102 )
		CallersAvatar:SetSize( ScrW() * 0.028, ScrH() * 0.046 )
		CallersAvatar:SetPlayer( caller, 32 )
		
		timer.Simple(1.5, function()
			local DenyButton = vgui.Create("DButton")
			DenyButton:SetParent( BeingCalledFrame )
			DenyButton:SetSize( ScrW() * 0.05, ScrH() * 0.05 )
			DenyButton:SetPos( ScrW() * 0.026, ScrH() * 0.34 )
			DenyButton:SetDrawBackground(false)
			DenyButton.Paint = function()
				draw.RoundedBox(8,1,1,DenyButton:GetWide()-2,DenyButton:GetTall()-2,Color(0,0,0,0))
			end
			DenyButton:SetText("")
			DenyButton.DoClick = function()
				BeingCalledFrame:Remove()
				DenyCall(caller)
				PHONE_SoundHandler(false, 13, LocalPlayer().Ringtone)
				LocalPlayer().PhoneOpen = false
				LocalPlayer().FrameOpen = nil
			end
					
			local AcceptButton = vgui.Create("DButton")
			AcceptButton:SetParent( BeingCalledFrame )
			AcceptButton:SetSize( ScrW() * 0.05, ScrH() * 0.05 )
			AcceptButton:SetPos( ScrW() * 0.08, ScrH() * 0.34 )
			AcceptButton:SetDrawBackground(false)
			AcceptButton.Paint = function()
				draw.RoundedBox(8,1,1,AcceptButton:GetWide()-2,AcceptButton:GetTall()-2,Color(0,0,0,0))
			end
			AcceptButton:SetText("")
			AcceptButton.DoClick = function()
				BeingCalledFrame:Remove()
				PHONE_AcceptCall(caller)
				PHONE_SoundHandler(false, 13, LocalPlayer().Ringtone)
			end
		end)
	end
end





function LineBusyMenu(receiver, shouldShow)
    if (!shouldShow) then
        LineBusyFrame:Remove()
    elseif (shouldShow) then
        PHONE_SoundHandler(true, 4, "craphead_scripts/phone/error.mp3")
        LineBusyFrame = vgui.Create( "DFrame" )
        LineBusyFrame:SetSize( ScrW() * 0.155,ScrH() * 0.47 )
		LineBusyFrame:SetPos( LineBusyFrame:GetWide() / 0.19,LineBusyFrame:GetTall()* 1.1 )
        LineBusyFrame:SetTitle( "" )
        LineBusyFrame:SetVisible( true )
        LineBusyFrame:SetDraggable( false )
        LineBusyFrame:ShowCloseButton( false )
        LineBusyFrame.Paint = function()
			draw.RoundedBox(8,1,1,LineBusyFrame:GetWide()-2,LineBusyFrame:GetTall()-2,Color(0,0,0,0))
		end
        //LineBusyFrame:MakePopup()
		LocalPlayer().FrameOpen = LineBusyFrame
		
        PhoneImage = vgui.Create( "DImage", LineBusyFrame )
        PhoneImage:SetPos( ScrW() * -0.055, 0 )
		PhoneImage:SetSize(ScrW() * 0.262, ScrH() * 0.48)
        PhoneImage:SetImage( "craphead_scripts/phone/ocrp_phone.png" )

        MainMenuPicture = vgui.Create( "DImage", LineBusyFrame )
        MainMenuPicture:SetPos( ScrW() * -0.055, 0 )
		MainMenuPicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
        MainMenuPicture:SetImage( "craphead_scripts/phone/menus/phone_oncallmenu.png" )

        surface.SetFont( "PhoneFont2" )
        local x, y = surface.GetTextSize( "Line is busy" )

        local LineIsBusy = vgui.Create( "DLabel", LineBusyFrame )
        LineIsBusy:SetText( "Line is busy" )
        LineIsBusy:SetPos( ( LineBusyFrame:GetWide() / 2 ) - ( x / 2 ), ScrH() * 0.12 ) 
        LineIsBusy:SetFont( "PhoneFont2" )
        LineIsBusy:SetTextColor( Color( 255, 255, 255, 255 ) ) 
        LineIsBusy:SizeToContents()

        timer.Simple(2, function()
			LineBusyMenu(receiver, false)
	        PHONE_SoundHandler(false, 4, "craphead_scripts/phone/error.mp3")
			LocalPlayer().PhoneOpen = false
			LocalPlayer().FrameOpen = nil
		end)
    end
end





function OpenSettingsMenu(shouldShow)
	if (!shouldShow) then
	    SettingsFrame:Remove()
	elseif (shouldShow) then
		local SettingsFrame = vgui.Create( "DFrame" )
	    SettingsFrame:SetSize( ScrW() * 0.155,ScrH() * 0.47 )
		SettingsFrame:SetPos( SettingsFrame:GetWide() / 0.19,SettingsFrame:GetTall()* 1.1 )
	    SettingsFrame:SetTitle( "" )
	    SettingsFrame:SetVisible( true )
	    SettingsFrame:SetDraggable( false )
		SettingsFrame:ShowCloseButton( false )
	    SettingsFrame.Paint = function()
		    draw.RoundedBox(8,1,1,SettingsFrame:GetWide()-2,SettingsFrame:GetTall()-2,Color(0,0,0,0))
	    end
		LocalPlayer().FrameOpen = SettingsFrame
		
	    PhonePicture = vgui.Create( "DImage", SettingsFrame )
	    PhonePicture:SetPos( ScrW() * -0.055, 0 )
		PhonePicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
	    PhonePicture:SetImage( "craphead_scripts/phone/ocrp_phone.png" )

	    SettingsPicture = vgui.Create( "DImage", SettingsFrame )
	    SettingsPicture:SetPos( ScrW() * -0.055, 0 )
		SettingsPicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
	    SettingsPicture:SetImage( "craphead_scripts/phone/menus/phone_settingsmenu.png" )

	    local ShutDownButton = vgui.Create("DButton")
	    ShutDownButton:SetParent( SettingsFrame )
	    ShutDownButton:SetSize( ScrW() * 0.025, ScrH() * 0.01 )
		ShutDownButton:SetPos( ScrW() * 0.095, ScrH() * 0.001 )
	    ShutDownButton:SetDrawBackground(false)
	    ShutDownButton.Paint = function()
		    draw.RoundedBox(8,1,1,ShutDownButton:GetWide()-2,ShutDownButton:GetTall()-2,Color(0,0,0,0))
	    end
	    ShutDownButton:SetText("")
	    ShutDownButton.DoClick = function()
		    SettingsFrame:Remove()
			LocalPlayer().PhoneOpen = false
			LocalPlayer().FrameOpen = nil
	    end

	    local HomeButton = vgui.Create("DButton")
	    HomeButton:SetParent( SettingsFrame )
	    HomeButton:SetSize( ScrW() * 0.025, ScrH() * 0.05 )
		HomeButton:SetPos( ScrW() * 0.065, ScrH() * 0.4 )
	    HomeButton:SetDrawBackground(false)
	    HomeButton.Paint = function()
		    draw.RoundedBox(8,1,1,HomeButton:GetWide()-2,HomeButton:GetTall()-2,Color(0,0,0,0))
	    end
		HomeButton:SetText("")
		HomeButton.DoClick = function()
	        SettingsFrame:Remove()
	        OpenPhoneMenu()
		end

	    local RingtoneButton = vgui.Create("DButton")
	    RingtoneButton:SetParent( SettingsFrame )
	    RingtoneButton:SetSize( ScrW() * 0.1, ScrH() * 0.05 )
	    RingtoneButton:SetPos( ScrW() * 0.027, ScrH() * 0.14 )
	    RingtoneButton:SetDrawBackground(false)
	    RingtoneButton.Paint = function()
		    draw.RoundedBox(1,0,0,213,26,Color(0,0,0,0))
	    end
	    RingtoneButton:SetText("")
	    RingtoneButton.DoClick = function()
		    SettingsFrame:Remove()
		    OpenRingtoneMenu(true)
		end

	    local WallpaperButton = vgui.Create("DButton")
	    WallpaperButton:SetParent( SettingsFrame )
	    WallpaperButton:SetSize( ScrW() * 0.1, ScrH() * 0.05 )
	    WallpaperButton:SetPos( ScrW() * 0.027, ScrH() * 0.165 )
	    WallpaperButton:SetDrawBackground(false)
	    WallpaperButton.Paint = function()
		    draw.RoundedBox(1,0,0,213,26,Color(0,0,0,0))
	    end
	    WallpaperButton:SetText("")
	    WallpaperButton.DoClick = function()
		    SettingsFrame:Remove()
		    OpenWallpaperMenu(true)
	    end

		local VolumeMenu = vgui.Create("DButton")
	    VolumeMenu:SetParent( SettingsFrame )
	    VolumeMenu:SetSize( ScrW() * 0.1, ScrH() * 0.05 )
	    VolumeMenu:SetPos( ScrW() * 0.027, ScrH() * 0.19 )
	    VolumeMenu:SetDrawBackground(false)
	    VolumeMenu.Paint = function()
		    draw.RoundedBox(1,0,0,213,26,Color(0,0,0,0))
			surface.SetDrawColor(Color( 255, 255, 255, 255 ))
			surface.SetMaterial(Material("craphead_scripts/phone/icons/delete.png"))
			surface.DrawTexturedRect(ScrW() * 0.091, ScrH() * 0.0065, 16, 16)
	    end
	    VolumeMenu:SetText("")
	    VolumeMenu.DoClick = function()
		    LocalPlayer():ChatPrint("This option is not available on your device.")
		end
	end
end





function OpenWallpaperMenu(shouldShow)
	if (!shouldShow) then
	    WallpaperFrame:Remove()
	elseif (shouldShow) then
		local WallpaperFrame = vgui.Create( "DFrame" )
	    WallpaperFrame:SetSize( ScrW() * 0.155,ScrH() * 0.47 )
		WallpaperFrame:SetPos( WallpaperFrame:GetWide() / 0.19,WallpaperFrame:GetTall()* 1.1 )
	    WallpaperFrame:SetTitle( "" )
	    WallpaperFrame:SetVisible( true )
	    WallpaperFrame:SetDraggable( false )
	    WallpaperFrame:ShowCloseButton( false )
	    WallpaperFrame.Paint = function()
	      	draw.RoundedBox(8,1,1,WallpaperFrame:GetWide()-2,WallpaperFrame:GetTall()-2,Color(0,0,0,0))
	    end
		LocalPlayer().FrameOpen = WallpaperFrame
		
	    PhonePicture = vgui.Create( "DImage", WallpaperFrame )
	    PhonePicture:SetPos( ScrW() * -0.055, 0 )
		PhonePicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
	    PhonePicture:SetImage( "craphead_scripts/phone/ocrp_phone.png" )

	    WallpaperPicture = vgui.Create( "DImage", WallpaperFrame )
	    WallpaperPicture:SetPos( ScrW() * -0.055, 0 )
		WallpaperPicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
	    WallpaperPicture:SetImage( "craphead_scripts/phone/menus/phone_wallpapersmenu.png" )

	    local ShutDownButton = vgui.Create("DButton")
	    ShutDownButton:SetParent( WallpaperFrame )
	    ShutDownButton:SetSize( ScrW() * 0.025, ScrH() * 0.01 )
		ShutDownButton:SetPos( ScrW() * 0.095, ScrH() * 0.001 )
	    ShutDownButton:SetDrawBackground(false)
	    ShutDownButton.Paint = function()
	      	draw.RoundedBox(8,1,1,ShutDownButton:GetWide()-2,ShutDownButton:GetTall()-2,Color(0,0,0,0))
	    end
	    ShutDownButton:SetText("")
	    ShutDownButton.DoClick = function()
	      	WallpaperFrame:Remove()
			LocalPlayer().PhoneOpen = false
			LocalPlayer().FrameOpen = nil
	    end
									
		local BackButton = vgui.Create("DButton")
		BackButton:SetParent( WallpaperFrame )
		BackButton:SetSize( ScrW() * 0.025, ScrH() * 0.025 )
		BackButton:SetPos( ScrW() * 0.025, ScrH() * 0.1 )
		BackButton:SetDrawBackground(false)
		BackButton.Paint = function()
			draw.RoundedBox(8,1,1,BackButton:GetWide()-2,BackButton:GetTall()-2,Color(0,0,0,0))
		end
		BackButton:SetText("")
		BackButton.DoClick = function()
			WallpaperFrame:Remove()
			OpenSettingsMenu(true)
		end
									
	    local HomeButton = vgui.Create("DButton")
	    HomeButton:SetParent( WallpaperFrame )
	    HomeButton:SetSize( ScrW() * 0.025, ScrH() * 0.05 )
		HomeButton:SetPos( ScrW() * 0.065, ScrH() * 0.4 )
	    HomeButton:SetDrawBackground(false)
	    HomeButton.Paint = function()
	      	draw.RoundedBox(8,1,1,HomeButton:GetWide()-2,HomeButton:GetTall()-2,Color(0,0,0,0))
	    end
		HomeButton:SetText("")
		HomeButton.DoClick = function()
			WallpaperFrame:Remove()
			OpenPhoneMenu()
		end

		wallpaper = {}
									
	    for k,v in pairs(WallpapersTable) do
			wallpaper[k] = vgui.Create( "DButton", WallpaperFrame)
			wallpaper[k]:SetPos( ScrW() * 0.025, ScrH() * 0.1375 + ScrH() * 0.03*(k-1)) 
			wallpaper[k]:SetSize( ScrW() * 0.1, ScrH() * 0.025 ) 
			wallpaper[k]:SetText("")
			wallpaper[k]:SetToolTip("Purchase wallpaper: "..WallpapersTable[k][1])
			wallpaper[k].Paint = function()
				surface.SetTextColor( 0, 0, 0, 180 )
				surface.SetTextPos( 10, 3 ) 
				surface.SetFont("PhoneFont1")
				if WallpapersTable[k][3] > 0 then
					surface.DrawText( WallpapersTable[k][1] .." - $".. WallpapersTable[k][3] )
				else
					surface.DrawText( WallpapersTable[k][1] .." - Free" )
				end
				if (LocalPlayer().Background == k-1) then
					surface.SetDrawColor(Color( 255, 255, 255, 255 ))
					surface.SetMaterial(Material("craphead_scripts/phone/icons/phone_check_icon.png"))
					surface.DrawTexturedRect(ScrW() * 0.0925, ScrH() * 0.007, 13, 13)
				end
	      	    draw.RoundedBox(1,0,0,213,26,Color(0,0,0,0))
			end
			wallpaper[k].DoClick = function ()
				WallpaperFrame:Remove()
				LocalPlayer().Background = k - 1
				
				net.Start("PHONE_NewBackground")
					net.WriteDouble( k - 1 )
					net.WriteDouble( WallpapersTable[k][3] )
				net.SendToServer()
				
				OpenPhoneMenu()
			end
		end
	end
end

function OpenRingtoneMenu(shouldShow)
	if (!shouldShow) then
	    RingtoneFrame:Remove()
	elseif (shouldShow) then
		local RingtoneFrame = vgui.Create( "DFrame" )
	    RingtoneFrame:SetSize( ScrW() * 0.155,ScrH() * 0.47 )
		RingtoneFrame:SetPos( RingtoneFrame:GetWide() / 0.19,RingtoneFrame:GetTall()* 1.1 )
	    RingtoneFrame:SetTitle( "" )
	    RingtoneFrame:SetVisible( true )
	    RingtoneFrame:SetDraggable( false )
	    RingtoneFrame:ShowCloseButton( false )
	    RingtoneFrame.Paint = function()
	      	draw.RoundedBox(8,1,1,RingtoneFrame:GetWide()-2,RingtoneFrame:GetTall()-2,Color(0,0,0,0))
	    end
		LocalPlayer().FrameOpen = RingtoneFrame
		
	    PhonePicture = vgui.Create( "DImage", RingtoneFrame )
	    PhonePicture:SetPos( ScrW() * -0.055, 0 )
		PhonePicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
	    PhonePicture:SetImage( "craphead_scripts/phone/ocrp_phone.png" )

	    WallpaperPicture = vgui.Create( "DImage", RingtoneFrame )
	    WallpaperPicture:SetPos( ScrW() * -0.055, 0 )
		WallpaperPicture:SetSize(ScrW() * 0.262, ScrH() * 0.48)
	    WallpaperPicture:SetImage( "craphead_scripts/phone/menus/phone_ringtonesmenu.png" )

	    local ShutDownButton = vgui.Create("DButton")
	    ShutDownButton:SetParent( RingtoneFrame )
	    ShutDownButton:SetSize( ScrW() * 0.025, ScrH() * 0.01 )
		ShutDownButton:SetPos( ScrW() * 0.095, ScrH() * 0.001 )
	    ShutDownButton:SetDrawBackground(false)
	    ShutDownButton.Paint = function()
	      	draw.RoundedBox(8,1,1,ShutDownButton:GetWide()-2,ShutDownButton:GetTall()-2,Color(0,0,0,0))
	    end
	    ShutDownButton:SetText("")
	    ShutDownButton.DoClick = function()
	      	RingtoneFrame:Remove()
			LocalPlayer().PhoneOpen = false
			LocalPlayer().FrameOpen = nil
	    end
									
		local BackButton = vgui.Create("DButton")
		BackButton:SetParent( RingtoneFrame )
		BackButton:SetSize( ScrW() * 0.025, ScrH() * 0.025 )
		BackButton:SetPos( ScrW() * 0.025, ScrH() * 0.1 )
		BackButton:SetDrawBackground(false)
		BackButton.Paint = function()
			draw.RoundedBox(8,1,1,BackButton:GetWide()-2,BackButton:GetTall()-2,Color(0,0,0,0))
		end
		BackButton:SetText("")
		BackButton.DoClick = function()
			RingtoneFrame:Remove()
			OpenSettingsMenu(true)
		end
									
	    local HomeButton = vgui.Create("DButton")
	    HomeButton:SetParent( RingtoneFrame )
	    HomeButton:SetSize( ScrW() * 0.025, ScrH() * 0.05 )
		HomeButton:SetPos( ScrW() * 0.065, ScrH() * 0.4 )
	    HomeButton:SetDrawBackground(false)
	    HomeButton.Paint = function()
	      	draw.RoundedBox(8,1,1,HomeButton:GetWide()-2,HomeButton:GetTall()-2,Color(0,0,0,0))
	    end
		HomeButton:SetText("")
		HomeButton.DoClick = function()
			RingtoneFrame:Remove()
			OpenPhoneMenu()
		end

		ringtone = {}
		play = {}
		stopsound = {}
									
	    for k,v in pairs(RingtonesTable) do
			ringtone[k] = vgui.Create( "DButton", RingtoneFrame)
			ringtone[k]:SetPos( ScrW() * 0.025, ScrH() * 0.1375 + ScrH() * 0.03*(k-1)) 
			ringtone[k]:SetSize( ScrW() * 0.07, ScrH() * 0.025 ) 
			ringtone[k]:SetText("")
			ringtone[k]:SetToolTip("Purchase ringtone: "..RingtonesTable[k][1])
			ringtone[k].Paint = function()
				surface.SetTextColor( 0, 0, 0, 180 )
				surface.SetTextPos( 10, 3 ) 
				surface.SetFont("PhoneFont1")
				if RingtonesTable[k][3] > 0 then
					surface.DrawText( RingtonesTable[k][1] .." - $".. RingtonesTable[k][3] )
				else
					surface.DrawText( RingtonesTable[k][1] .." - Free" )
				end
				if (LocalPlayer().Ringtone == k - 1) then
					surface.SetDrawColor(Color( 255, 255, 255, 255 ))
					surface.SetMaterial(Material("craphead_scripts/phone/icons/phone_check_icon.png"))
					surface.DrawTexturedRect(ScrW() * 0.06, ScrH() * 0.007, 13, 13)
				end
	      	    draw.RoundedBox(1,0,0,ringtone[k]:GetWide(),ringtone[k]:GetTall(),Color(0,0,0,0))
			end
			ringtone[k].DoClick = function ()
				RingtoneFrame:Remove()
				LocalPlayer().Ringtone = k - 1
				
				net.Start("PHONE_NewRingtone")
					net.WriteDouble( k - 1 )
					net.WriteDouble( RingtonesTable[k][3] )
				net.SendToServer()
				
				OpenPhoneMenu()
			end
			
			play[k] = vgui.Create( "DButton", RingtoneFrame)
			play[k]:SetPos( ScrW() * 0.095, ScrH() * 0.1375 + ScrH() * 0.03*(k-1)) 
			play[k]:SetSize( ScrW() * 0.016, ScrH() * 0.025 ) 
			play[k]:SetText("")
			play[k]:SetToolTip("Listen to "..RingtonesTable[k][1])
			play[k].Paint = function()
				surface.SetTextColor( 0, 0, 0, 180 )
				surface.SetTextPos( 10, 3 ) 
				surface.SetFont("PhoneFont1")
				
				surface.SetDrawColor(Color( 255, 255, 255, 255 ))
				surface.SetMaterial(Material("craphead_scripts/phone/icons/sound.png"))
				surface.DrawTexturedRect(ScrW() * 0, ScrH() * 0.005, 16, 16)
				
	      	    draw.RoundedBox(1,0,0,play[k]:GetWide(),play[k]:GetTall(),Color(0,0,0,0))
			end
			play[k].DoClick = function ()
				RunConsoleCommand("play",RingtonesTable[k][2])
			end
			
			stopsound[k] = vgui.Create( "DButton", RingtoneFrame)
			stopsound[k]:SetPos( ScrW() * 0.11, ScrH() * 0.1375 + ScrH() * 0.03*(k-1)) 
			stopsound[k]:SetSize( ScrW() * 0.016, ScrH() * 0.025 ) 
			stopsound[k]:SetText("")
			stopsound[k]:SetToolTip("Stop listening to "..RingtonesTable[k][1])
			stopsound[k].Paint = function()
				surface.SetTextColor( 0, 0, 0, 180 )
				surface.SetTextPos( 10, 3 ) 
				surface.SetFont("PhoneFont1")
				
				surface.SetDrawColor(Color( 255, 255, 255, 255 ))
				surface.SetMaterial(Material("craphead_scripts/phone/icons/sound_mute.png"))
				surface.DrawTexturedRect(ScrW() * 0, ScrH() * 0.005, 16, 16)
				
	      	    draw.RoundedBox(1,0,0,stopsound[k]:GetWide(),stopsound[k]:GetTall(),Color(0,0,0,0))
			end
			stopsound[k].DoClick = function ()
				RunConsoleCommand("stopsound")
			end
		end
	end
end