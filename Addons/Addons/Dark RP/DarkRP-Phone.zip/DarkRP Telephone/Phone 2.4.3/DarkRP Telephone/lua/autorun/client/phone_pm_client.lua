function GUI_PMMenu( SenderName )

	local GUI_PM_Frame = vgui.Create("DFrame")
	GUI_PM_Frame:SetTitle("")
	GUI_PM_Frame:SetSize(320,185)
	GUI_PM_Frame:Center()
	GUI_PM_Frame.Paint = function(PhonePaint)
		-- Draw the menu background color.		
		draw.RoundedBox( 0, 0, 25, PhonePaint:GetWide(), PhonePaint:GetTall(), Color( 255, 255, 255, 150 ) )

		-- Draw the outline of the menu.
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0, 0, PhonePaint:GetWide(), PhonePaint:GetTall())
	
		draw.RoundedBox( 0, 0, 0, PhonePaint:GetWide(), 25, Color( 255, 255, 255, 200 ) )
		
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0, 0, PhonePaint:GetWide(), 25)

		-- Draw the top title.
		draw.SimpleText("Private Message", "PhoneFont1", 57.5,12.5, Color(70,70,70,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	GUI_PM_Frame:MakePopup()
	GUI_PM_Frame:ShowCloseButton(false)

	local GUI_Main_Exit = vgui.Create("DButton", GUI_PM_Frame)
	GUI_Main_Exit:SetSize(16,16)
	GUI_Main_Exit:SetPos(300,5)
	GUI_Main_Exit:SetText("")
	GUI_Main_Exit.Paint = function()
		surface.SetMaterial(Material("icon16/cross.png"))
		surface.SetDrawColor(200,200,0,200)
		surface.DrawTexturedRect(0,0,GUI_Main_Exit:GetWide(),GUI_Main_Exit:GetTall())
	end
	GUI_Main_Exit.DoClick = function()
		GUI_PM_Frame:Remove()
	end

	local GUI_Reciever_Label = vgui.Create("DLabel", GUI_PM_Frame)
	GUI_Reciever_Label:SetText("Receiver:")
	GUI_Reciever_Label:SetFont("PhoneFont1")
	GUI_Reciever_Label:SetColor(Color(70,70,70,255))
	GUI_Reciever_Label:SetPos(10,30)
	GUI_Reciever_Label:SizeToContents()
	
	local ReceiverList = vgui.Create( "DComboBox", GUI_PM_Frame)
	ReceiverList:SetPos(10,45)
	ReceiverList:SetSize( 300, 20 )
	for k, v in pairs(player.GetAll()) do
		ReceiverList:AddChoice(v:Nick())
	end
	
	--[[
	local GUI_Reciever_Entry = vgui.Create("DTextEntry", GUI_PM_Frame)
	GUI_Reciever_Entry:SetFont("PhoneFont3")
	GUI_Reciever_Entry:SetSize(300,25)
	GUI_Reciever_Entry:SetPos(10,45)
	if SenderName != nil then
		GUI_Reciever_Entry:SetText(SenderName)
		GUI_Reciever_Entry:SetEditable(false)
	else
		GUI_Reciever_Entry:SetEditable(true)
	end
	GUI_Reciever_Entry:SetUpdateOnType(true)
	--]]

	local GUI_Message_Label = vgui.Create("DLabel", GUI_PM_Frame)
	GUI_Message_Label:SetText("Message:")
	GUI_Message_Label:SetFont("PhoneFont1")
	GUI_Message_Label:SetColor(Color(70,70,70,255))
	GUI_Message_Label:SetPos(10,75)
	GUI_Message_Label:SizeToContents()

	local GUI_Message_Entry = vgui.Create("DTextEntry", GUI_PM_Frame)
	GUI_Message_Entry:SetFont("PhoneFont3")
	GUI_Message_Entry:SetSize(300,50)
	GUI_Message_Entry:SetPos(10,90)
	GUI_Message_Entry:SetEditable(true)
	GUI_Message_Entry:SetMultiline(true)
	GUI_Message_Entry:SetUpdateOnType(true)

	local GUI_SendButton = vgui.Create("DButton", GUI_PM_Frame)
	GUI_SendButton:SetSize(300,25)
	GUI_SendButton:SetPos(10,150)
	GUI_SendButton:SetText("")
	GUI_SendButton.DoClick = function()
	if GUI_Message_Entry:GetValue() == "" then
		LocalPlayer():ChatPrint("Please enter a message!")
		return
	end
	if ReceiverList:GetValue() == "" then
		LocalPlayer():ChatPrint("Please enter a receiver!")
		return
	end
	net.Start("PHONE_SendMessage")
		net.WriteString(LocalPlayer():Nick())
		net.WriteString(ReceiverList:GetValue())
		net.WriteString(GUI_Message_Entry:GetValue())
	net.SendToServer()
	GUI_PM_Frame:Remove()
	end
	GUI_SendButton.Paint = function(PhonePaint)
		draw.RoundedBox(8,1,1,PhonePaint:GetWide()-2,PhonePaint:GetTall()-2,Color(0, 0, 0, 130))

		local struc = {}
		struc.pos = {}
		struc.pos[1] = 150 -- x pos
		struc.pos[2] = 12.5 -- y pos
		struc.color = Color(70,70,70,255) -- Red
		struc.text = "Send Message" -- Text
		struc.font = "PhoneFont1" -- Font
		struc.xalign = TEXT_ALIGN_CENTER-- Horizontal Alignment
		struc.yalign = TEXT_ALIGN_CENTER -- Vertical Alignment
		draw.Text( struc )
	end

end





function GUI_MessageMenu(SenderName, TheMessage)
	
	local GUI_Message_Frame = vgui.Create("DFrame")
	GUI_Message_Frame:SetTitle("")
	GUI_Message_Frame:SetSize(320,185)
	GUI_Message_Frame:Center()
	GUI_Message_Frame.Paint = function(PhonePaint)
		-- Draw the menu background color.		
		draw.RoundedBox( 0, 0, 25, PhonePaint:GetWide(), PhonePaint:GetTall(), Color( 255, 255, 255, 150 ) )

		-- Draw the outline of the menu.
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0, 0, PhonePaint:GetWide(), PhonePaint:GetTall())
	
		draw.RoundedBox( 0, 0, 0, PhonePaint:GetWide(), 25, Color( 255, 255, 255, 200 ) )
		
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0, 0, PhonePaint:GetWide(), 25)

		-- Draw the top title.
		draw.SimpleText("Display Message", "PhoneFont1", 57.5,12.5, Color(70,70,70,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	GUI_Message_Frame:MakePopup()
	GUI_Message_Frame:ShowCloseButton(false)

	local GUI_Main_Exit = vgui.Create("DButton", GUI_Message_Frame)
	GUI_Main_Exit:SetSize(16,16)
	GUI_Main_Exit:SetPos(300,5)
	GUI_Main_Exit:SetText("")
	GUI_Main_Exit.Paint = function()
		surface.SetMaterial(Material("icon16/cross.png"))
		surface.SetDrawColor(200,200,0,200)
		surface.DrawTexturedRect(0,0,GUI_Main_Exit:GetWide(),GUI_Main_Exit:GetTall())
	end
	GUI_Main_Exit.DoClick = function()
		net.Start("PHONE_EmptyInbox")
		net.SendToServer()
		GUI_Message_Frame:Remove()
	end

	local GUI_Sender_Label = vgui.Create("DLabel", GUI_Message_Frame)
	GUI_Sender_Label:SetText("Sender:")
	GUI_Sender_Label:SetFont("PhoneFont1")
	GUI_Sender_Label:SetColor(Color(70,70,70,255))
	GUI_Sender_Label:SetPos(10,30)
	GUI_Sender_Label:SizeToContents()

	local GUI_Sender_Entry = vgui.Create("DTextEntry", GUI_Message_Frame)
	GUI_Sender_Entry:SetText(SenderName)
	GUI_Sender_Entry:SetEditable(false)
	GUI_Sender_Entry:SetFont("PhoneFont3")
	GUI_Sender_Entry:SetSize(300,25)
	GUI_Sender_Entry:SetPos(10,45)

	local GUI_Message_Label = vgui.Create("DLabel", GUI_Message_Frame)
	GUI_Message_Label:SetText("Message:")
	GUI_Message_Label:SetFont("PhoneFont1")
	GUI_Message_Label:SetColor(Color(70,70,70,255))
	GUI_Message_Label:SetPos(10,75)
	GUI_Message_Label:SizeToContents()

	local GUI_Message_Entry = vgui.Create("DTextEntry", GUI_Message_Frame)
	GUI_Message_Entry:SetFont("PhoneFont1")
	GUI_Message_Entry:SetSize(300,50)
	GUI_Message_Entry:SetPos(10,90)
	GUI_Message_Entry:SetText(TheMessage)
	GUI_Message_Entry:SetEditable(false)
	GUI_Message_Entry:SetMultiline(true)

	local GUI_ReplyButton = vgui.Create("DButton", GUI_Message_Frame)
	GUI_ReplyButton:SetSize(300,25)
	GUI_ReplyButton:SetPos(10,150)
	GUI_ReplyButton:SetText("")
	GUI_ReplyButton.DoClick = function()
		GUI_PMMenu( SenderName )
		net.Start("PHONE_EmptyInbox")
		net.SendToServer()
		GUI_Message_Frame:Remove()
	end
	GUI_ReplyButton.Paint = function(PhonePaint)
		draw.RoundedBox(8,1,1,PhonePaint:GetWide()-2,PhonePaint:GetTall()-2,Color(0, 0, 0, 130))

		local struc = {}
		struc.pos = {}
		struc.pos[1] = 150 -- x pos
		struc.pos[2] = 12.5 -- y pos
		struc.color = Color(70,70,70,255) -- Red
		struc.text = "Reply to ".. SenderName -- Text
		struc.font = "PhoneFont1" -- Font
		struc.xalign = TEXT_ALIGN_CENTER-- Horizontal Alignment
		struc.yalign = TEXT_ALIGN_CENTER -- Vertical Alignment
		draw.Text( struc )
	end
end





function GUI_MessageTempMenu(um)
	local SenderName = um:ReadString()
	local TheMessage = um:ReadString()


	local GUI_MessageTemp_Frame = vgui.Create("DFrame")
	GUI_MessageTemp_Frame:SetTitle("")
	GUI_MessageTemp_Frame:SetSize(ScrW() * 0.13,ScrH() * 0.11)
	GUI_MessageTemp_Frame:SetPos(GUI_MessageTemp_Frame:GetWide() / 0.152,GUI_MessageTemp_Frame:GetTall()* 3.5)
	GUI_MessageTemp_Frame.Paint = function(PhonePaint)
		-- Draw the menu background color.		
		draw.RoundedBox( 0, 0, 25, PhonePaint:GetWide(), PhonePaint:GetTall(), Color( 255, 255, 255, 150 ) )

		-- Draw the outline of the menu.
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0, 0, PhonePaint:GetWide(), PhonePaint:GetTall())
	
		draw.RoundedBox( 0, 0, 0, PhonePaint:GetWide(), 25, Color( 255, 255, 255, 200 ) )
		
		surface.SetDrawColor(0,0,0,255)
		surface.DrawOutlinedRect(0, 0, PhonePaint:GetWide(), 25)

		-- Draw the top title.
		draw.SimpleText("Message Received", "PhoneFont1", 62.5,12.5, Color(70,70,70,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	GUI_MessageTemp_Frame:ShowCloseButton(false)

	local GUI_Main_Exit = vgui.Create("DButton", GUI_MessageTemp_Frame)
	GUI_Main_Exit:SetSize(16,16)
	GUI_Main_Exit:SetPos(ScrW() * 0.12,ScrH() * 0.005)
	GUI_Main_Exit:SetText("")
	GUI_Main_Exit.Paint = function()
		surface.SetMaterial(Material("icon16/cross.png"))
		surface.SetDrawColor(200,200,0,200)
		surface.DrawTexturedRect(0,0,GUI_Main_Exit:GetWide(),GUI_Main_Exit:GetTall())
	end
	GUI_Main_Exit.DoClick = function()
		net.Start("PHONE_EmptyInbox")
		net.SendToServer()
		GUI_MessageTemp_Frame:Remove()
	end

	local GUI_Sender_Label = vgui.Create("DLabel", GUI_MessageTemp_Frame)
	GUI_Sender_Label:SetText("New message from:")
	GUI_Sender_Label:SetFont("PhoneFont1")
	GUI_Sender_Label:SetColor(Color(70,70,70,255))
	GUI_Sender_Label:SetPos(ScrW() * 0.005,ScrH() * 0.025)
	GUI_Sender_Label:SizeToContents()

	local GUI_Sender_Label2 = vgui.Create("DLabel", GUI_MessageTemp_Frame)
	GUI_Sender_Label2:SetText(SenderName)
	GUI_Sender_Label2:SetFont("PhoneFont3")
	GUI_Sender_Label2:SetColor(Color(70,70,70,255))
	GUI_Sender_Label2:SetSize(300,25)
	GUI_Sender_Label2:SetPos(ScrW() * 0.005,ScrH() * 0.04)

	local GUI_ViewButton = vgui.Create("DButton", GUI_MessageTemp_Frame)
	GUI_ViewButton:SetSize(ScrW() * 0.12,ScrH() * 0.0225)
	GUI_ViewButton:SetPos(ScrW() * 0.005,ScrH() * 0.08)
	GUI_ViewButton:SetText("")
	GUI_ViewButton.DoClick = function()
		GUI_MessageMenu( SenderName, TheMessage ) 
		GUI_MessageTemp_Frame:Remove()
	end
	GUI_ViewButton.Paint = function(PhonePaint)
		draw.RoundedBox(8,1,1,PhonePaint:GetWide()-2,PhonePaint:GetTall()-2,Color(0, 0, 0, 130))

		local struc = {}
		struc.pos = {}
		struc.pos[1] = ScrW() * 0.06 -- x pos
		struc.pos[2] = ScrH() * 0.01125 -- y pos
		struc.color = Color(70,70,70,255) -- Red
		struc.text = "View Message" -- Text
		struc.font = "PhoneFont1" -- Font
		struc.xalign = TEXT_ALIGN_CENTER-- Horizontal Alignment
		struc.yalign = TEXT_ALIGN_CENTER -- Vertical Alignment
		draw.Text( struc )
	end
end
usermessage.Hook("PHONE_MessageMenu", GUI_MessageTempMenu)