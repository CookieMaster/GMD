util.AddNetworkString("PHONE_SendMessage")

net.Receive("PHONE_SendMessage", function(length, ply)
local SenderName = net.ReadString()
local RecieverName = net.ReadString()
local TheMessage = net.ReadString()

local PlayerFound = false
local PlayersChecked = 0

    for k, v in pairs(player.GetAll()) do
        PlayersChecked = PlayersChecked + 1
        
        if v:Nick() == RecieverName then
            PlayerFound = true
			
			if not v.InboxFull then
				if ply:getDarkRPVar("money") >= PHONE_PM_Price then
					umsg.Start("PHONE_MessageMenu", v)
						umsg.String(SenderName)
						umsg.String(TheMessage)
					umsg.End()
					v.InboxFull = true
					
					ply:ChatPrint("Your message has been sent to ".. RecieverName ..".")
					ply:ChatPrint("You have been charged $3 for sending a private message.")
					ply:AddMoney(3 * -1)
					v:EmitSound("craphead_scripts/phone/message_received.wav", 100, 100)
				else
					ply:ChatPrint("It costs $"..PHONE_PM_Price.." to send a private message.")
				end
			else
				ply:ChatPrint("The person you are trying to send a message to does not have any more space in their inbox. Tell them to view their current message.")
			end
			
            break
        end
        
        if PlayersChecked == #player.GetAll() then
            if not PlayerFound then
                ply:ChatPrint("Invalid name!")
            end
        end
    end
end)

util.AddNetworkString("PHONE_EmptyInbox")

net.Receive("PHONE_EmptyInbox", function(length, ply)
ply.InboxFull = false
end)

function PM(ply, args)
	if PHONE_PM_DisableDefaultPM then
		ply:ChatPrint("DarkRP Telephone addon is installed on this server. Please use your telephone to PM somebody!")
	else
		local namepos = string.find(args, " ")
		if not namepos then return "" end

		local name = string.sub(args, 1, namepos - 1)
		local msg = string.sub(args, namepos + 1)
		if msg == "" then return "" end
		target = GAMEMODE:FindPlayer(name)

		if target then
			local col = team.GetColor(ply:Team())
			GAMEMODE:TalkToPerson(target, col, "(PM) "..ply:Nick(), Color(255,255,255,255), msg, ply)
			GAMEMODE:TalkToPerson(ply, col, "(PM) "..ply:Nick(), Color(255,255,255,255), msg, ply)
		else
			GAMEMODE:Notify(ply, 1, 4, DarkRP.getPhrase("could_not_find", "player: "..tostring(name)))
		end

		return ""
	end
end