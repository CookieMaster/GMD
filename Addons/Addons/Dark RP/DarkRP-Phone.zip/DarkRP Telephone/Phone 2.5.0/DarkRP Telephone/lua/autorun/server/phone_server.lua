function PHONE_HearVoice( ply1, ply2 )
	if (ply1.IsOnCallWith == ply2 && ply2.IsOnCallWith == ply1) then return true end
end
hook.Add("PlayerCanHearPlayersVoice", "PHONE_HearVoice", PHONE_HearVoice)

util.AddNetworkString("PHONE_NewBackground")
net.Receive("PHONE_NewBackground", function( lenght, ply )
	local background = net.ReadDouble()
	local price = net.ReadDouble()
	
	if not file.IsDir("craphead_scripts/phone_system", "DATA") then
		file.CreateDir("craphead_scripts/phone_system", "DATA")
	end
	
	if ply:getDarkRPVar("money") >= price then
		if price > 0 then
			ply:addMoney( price * -1 )
			ply:ChatPrint("You have changed your background. It costed $".. price)
		else
			ply:ChatPrint("You have changed your background. It was free!")
		end
		file.Write("craphead_scripts/phone_system/".. ply:UniqueID() .."_wallpaper.txt", background, "DATA")
	else
		ply:ChatPrint("You can not afford to pay for this background.")
	end
end)

util.AddNetworkString("PHONE_NewRingtone")
net.Receive("PHONE_NewRingtone", function( lenght, ply )
	local ringtone = net.ReadDouble()
	local price = net.ReadDouble()
	
	if not file.IsDir("craphead_scripts/phone_system", "DATA") then
		file.CreateDir("craphead_scripts/phone_system", "DATA")
	end
	
	if ply:getDarkRPVar("money") >= price then
		if price > 0 then
			ply:addMoney( price * -1 )
			ply:ChatPrint("You have changed your ringtone. It costed $".. price)
		else
			ply:ChatPrint("You have changed your ringtone. It was free!")
		end
		file.Write("craphead_scripts/phone_system/".. ply:UniqueID() .."_ringtone.txt", ringtone, "DATA")
		
		ply.Ringtone = RingtonesTable[ringtone + 1][2]
	else
		ply:ChatPrint("You can not afford to pay for this ringtone.")
	end
end)

function PHONE_InitSpawn( ply )
	timer.Simple(5, function()
		local background = file.Read("craphead_scripts/phone_system/".. ply:UniqueID() .."_wallpaper.txt", "DATA") or PHONE_DefaultBackground
		local ringtone = file.Read("craphead_scripts/phone_system/".. ply:UniqueID() .."_ringtone.txt", "DATA") or PHONE_DefaultRingtone
		
		umsg.Start("PHONE_SetBackground", ply)
			umsg.Long(background)
		umsg.End()
		
		umsg.Start("PHONE_SetRingtone", ply)
			umsg.Long(ringtone)
		umsg.End()
		
		ply.Ringtone = RingtonesTable[ringtone + 1][2]
	end)
end
hook.Add("PlayerInitialSpawn", "PHONE_InitSpawn", PHONE_InitSpawn)

util.AddNetworkString("PHONE_Initiate_Call")
util.AddNetworkString("PHONE_Accept_Call")
util.AddNetworkString("PHONE_Deny_Call")
util.AddNetworkString("PHONE_End_Call")
util.AddNetworkString("PHONE_EndNotValid_Call")

net.Receive("PHONE_Initiate_Call", function(lenght, caller)
	local receiver = player.GetByID(net.ReadString())
	local emergency = net.ReadString()
	
	if receiver.IsOnCallWith == nil and receiver.IncomingCall == nil and receiver.IsCalling == nil then
		receiver.IncomingCall = true
		caller.IsCalling = true
		
		umsg.Start("PHONE_IncomingCall", receiver)
			umsg.Entity(caller)
			umsg.String(emergency)
		umsg.End()
		
		receiver:EmitSound(receiver.Ringtone, PHONE_RingtoneRange, 100)
	else
		umsg.Start("PHONE_AlreadyOnCall", caller)
			umsg.Entity(receiver)
		umsg.End()
	end
end)

net.Receive("PHONE_Accept_Call", function(lenght, receiver)
	local caller = player.GetByID(net.ReadString())
	
	umsg.Start("PHONE_CallWasAccepted", caller)
		umsg.Entity(receiver)
	umsg.End()
	
	receiver.IncomingCall = nil
	caller.IsCalling = nil
	
	caller.IsOnCallWith = receiver
	receiver.IsOnCallWith = caller
	
	receiver:StopSound(receiver.Ringtone)
end)

net.Receive("PHONE_Deny_Call", function(lenght, receiver)
	local caller = player.GetByID(net.ReadString())
	
	umsg.Start("PHONE_CallWasDenied", caller)
		umsg.Entity(receiver)
	umsg.End()
	
	receiver.IncomingCall = nil
	caller.IsCalling = nil
	
	receiver:StopSound(receiver.Ringtone)
end)

net.Receive("PHONE_End_Call", function(lenght, caller, oncall)
	local receiver = player.GetByID(net.ReadString())
	local oncall = net.ReadString()
	
	umsg.Start("PHONE_HungUpRemote", receiver)
		umsg.Entity(caller)
		umsg.String(oncall)
	umsg.End()
	
	receiver.IncomingCall = nil
	caller.IsCalling = nil
	
	caller.IsOnCallWith = nil
	receiver.IsOnCallWith = nil
	
	receiver:StopSound(receiver.Ringtone)
end)

net.Receive("PHONE_EndNotValid_Call", function(lenght, caller)	
	caller.IsOnCallWith = nil
end)

function PHONE_AddDir(dir) // recursively adds everything in a directory to be downloaded by client
    local list = file.Find(dir.."/*", "DATA")
    for _, fdir in pairs(list) do
        if fdir != ".svn" then // don't spam people with useless .svn folders
            PHONE_AddDir(dir.."/"..fdir)
        end
    end
  
    for k,v in pairs(file.Find(dir.."/*", "GAME")) do
        resource.AddFile(dir.."/"..v)
    end
end

PHONE_AddDir("materials/craphead_scripts/phone") 
PHONE_AddDir("materials/craphead_scripts/phone/backgrounds") 
PHONE_AddDir("materials/craphead_scripts/phone/icons") 
PHONE_AddDir("materials/craphead_scripts/phone/menus") 
PHONE_AddDir("sound/craphead_scripts/phone") 
PHONE_AddDir("sound/craphead_scripts/phone/ringtones") 