

if SERVER then

	AddCSLuaFile()

	util.AddNetworkString("FreezeCamTTT")
	
	resource.AddFile("sound/freeze_camttt.wav")

	hook.Add("Initialize", "InitializeFreezecam", function()

		function GAMEMODE:PlayerDeath(victim, infl, attacker)
			self:PlayerSilentDeath(victim)
			victim:SetTeam(TEAM_SPEC)
			victim:Freeze(false)
			victim:SetRagdollSpec(true)
			victim:Spectate(OBS_MODE_IN_EYE)
			local rag_ent = victim.server_ragdoll or victim:GetRagdollEntity() 
			if not IsValid(attacker) or victim == attacker or not attacker:IsPlayer() or (IsValid(attacker) and attacker:IsPlayer() and not attacker:IsActive()) then
				victim:SetRagdollSpec(true)
				victim:SpectateEntity(rag_ent)
				victim:Spectate(OBS_MODE_IN_EYE)
			else
				local victim, attacker = victim, attacker
				victim:SetRagdollSpec(true) 
				victim:SpectateEntity(rag_ent)
				victim:Spectate(OBS_MODE_IN_EYE)
				timer.Simple(2, function()
					if not IsValid(victim) or not IsValid(attacker) then return end
					victim:SetRagdollSpec(false)
					net.Start("FreezeCamTTT")
					net.WriteString(attacker:Nick())
					net.Send(victim)
					victim:ConCommand("play freeze_camttt")
					victim:SpectateEntity( attacker )
					victim.Freezecam = true
					victim:Spectate( OBS_MODE_FREEZECAM )
					timer.Simple(4, function()
						if IsValid(victim) and victim:GetObserverMode() == OBS_MODE_FREEZECAM then
							victim.Freezecam = false
							victim:Spectate(OBS_MODE_ROAMING)
							victim:SpectateEntity(nil)
						end
					end)
				end)
			end
			victim:Flashlight(false)
			victim:Extinguish()
			SendUserMessage("plydied", victim)
			if HasteMode() and GetRoundState() == ROUND_ACTIVE then
				IncRoundEnd(GetConVar("ttt_haste_minutes_per_death"):GetFloat() * 60)
			end
		end
		
	end)
	
else

	surface.CreateFont("TrebuchetBig", { 
		font = "Trebuchet24", 
		size = 32 
	}) 

	net.Receive("FreezeCamTTT", function()
		local k = net.ReadString()
		if not k then k = "Unknown" end
		hook.Add("HUDPaint", "HUDPaintFreezeCam", function()
			if LocalPlayer():GetObserverMode() != OBS_MODE_FREEZECAM then
				hook.Remove("HUDPaint", "HUDPaintFreezeCam")
			else
				local w1, h1 = surface.GetTextSize("Killed by "..k );
				local textx = ScrW()/2
				local steamx = (ScrW()/2) - 32
				draw.SimpleTextOutlined("Killed by "..k, "TrebuchetBig", textx, ScrH()*0.75, Color(255, 10, 10, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(255, 255, 255, 255))
			end
		end)
	end)

end