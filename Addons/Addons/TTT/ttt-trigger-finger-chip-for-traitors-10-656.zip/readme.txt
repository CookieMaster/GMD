Place the 'traitorchip' folder in your addons directory.

Made by 
Therma (STEAM_0:0:15128120) &
The one-free man (STEAM_0:1:22177262)

How to change the amount of charges on the weapon:
Go into 'lua/sv_traitorchip.lua' and change 'TRAITORCHIP.Charges'

How to add a custom automatic weapon:
Go into 'lua/sv_traitorchip.lua' and add
TRAITORCHIP.AddAutomaticWeapon( weapon_class, amounts_of_shots )