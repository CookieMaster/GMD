	
	TRAITORCHIP.Charges = 8 -- The amount of charges you start with
	TRAITORCHIP.MaxPlaceDistance = 64 -- How far away can the player be to place the chip on the back of the victims head?
	
	-- TRAITORCHIP.AddAutomaticWeapon( weapon_class, amounts_of_shots )
	TRAITORCHIP.AddAutomaticWeapon( "weapon_zm_mac10", 6 ) -- Adds a custom automatic weapon with the amount of charges it shoots per click
	TRAITORCHIP.AddAutomaticWeapon( "weapon_ttt_m16", 6 )
	TRAITORCHIP.AddAutomaticWeapon( "weapon_zm_sledge", 8 )