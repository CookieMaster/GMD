-- HUD HUD HUD

local table = table
local surface = surface
local draw = draw
local math = math
local string = string

local GetTranslation = LANG.GetTranslation
local GetPTranslation = LANG.GetParamTranslation
local GetLang = LANG.GetUnsafeLanguageTable
local interp = string.Interp

-- Fonts
surface.CreateFont("TraitorState", {font = "Trebuchet24",
                                    size = 28,
                                    weight = 1000})
surface.CreateFont("TimeLeft",     {font = "Trebuchet24",
                                    size = 24,
                                    weight = 800})
surface.CreateFont("HealthAmmo",   {font = "Trebuchet24",
                                    size = 24,
                                    weight = 750})
surface.CreateFont("BFHUD16",   {font = "BFHud SemiBold",
                                    size = 16,
                                    weight = 50})
surface.CreateFont("BFHUD18",   {font = "BFHud SemiBold",
                                    size = 18,
                                    weight = 750})
surface.CreateFont("BFHUD20",   {font = "BFHud SemiBold",
                                    size = 20,
                                    weight = 750})
surface.CreateFont("BFHUD22",   {font = "BFHud SemiBold",
                                    size = 22,
                                    weight = 750})
surface.CreateFont("BFHUD24",   {font = "BFHud SemiBold",
                                    size = 24,
                                    weight = 750})
surface.CreateFont("BFHUD26",   {font = "BFHud SemiBold",
                                    size = 26,
                                    weight = 750})
surface.CreateFont("BFHUD28",   {font = "BFHud SemiBold",
                                    size = 28,
                                    weight = 750})
surface.CreateFont("BFHUD32",   {font = "BFHud SemiBold",
                                    size = 32,
                                    weight = 750})
surface.CreateFont("BFHUD36",   {font = "BFHud SemiBold",
                                    size = 36,
                                    weight = 750})
surface.CreateFont("BFHUD44",   {font = "BFHud SemiBold",
                                    size = 44,
                                    weight = 750})
surface.CreateFont("BFHUD60",   {font = "BFHud SemiBold",
                                    size = 60,
                                    weight = 750})
surface.CreateFont("BFHUD84",   {font = "BFHud SemiBold",
                                    size = 84,
                                    weight = 750})

-- Color presets
local bg_colors = {
   background_main = Color(0, 0, 10, 200),

   noround = Color(100,100,100,200),
   traitor = Color(200, 25, 25, 200),
   innocent = Color(25, 200, 25, 200),
   detective = Color(25, 25, 200, 200)
};

local health_colors = {
   border = COLOR_WHITE,
   background = Color(100, 25, 25, 222),
   fill = Color(200, 50, 50, 250)
};

local ammo_colors = {
   border = COLOR_WHITE,
   background = Color(17, 17, 18, 210),
   fill = bfhud.punchMeter
};


function RoundedBoxOutline( borderSize, x, y, w, h, color )
        x = math.Round( x )
        y = y
        w = math.Round( w )
        h = math.Round( h )
        borderSize = math.Round( borderSize )
        surface.SetDrawColor( color.r, color.g, color.b, color.a )
        surface.DrawRect( x, y, borderSize, h )
        surface.DrawRect( x + w, y, borderSize, h+borderSize )
        surface.DrawRect( x, y, w, borderSize )
        surface.DrawRect( x, y + h, w, borderSize )
end

-- Modified RoundedBox
local Tex_Corner8 = surface.GetTextureID( "gui/corner8" )
local function RoundedMeter( bs, x, y, w, h, color)
   surface.SetDrawColor(clr(color))
   surface.DrawRect( x+bs, y, w-bs*2, h )
   surface.DrawRect( x, y+bs, bs, h-bs*2 )
   surface.SetTexture( Tex_Corner8 )
   surface.DrawTexturedRectRotated( x + bs/2 , y + bs/2, bs, bs, 0 )
   surface.DrawTexturedRectRotated( x + bs/2 , y + h -bs/2, bs, bs, 90 )
   if w > 14 then
      surface.DrawRect( x+w-bs, y+bs, bs, h-bs*2 )
      surface.DrawTexturedRectRotated( x + w - bs/2 , y + bs/2, bs, bs, 270 )
      surface.DrawTexturedRectRotated( x + w - bs/2 , y + h - bs/2, bs, bs, 180 )
   else
      surface.DrawRect( x + math.max(w-bs, bs), y, bs/2, h )
   end
end

---- The bar painting is loosely based on:
---- http://wiki.garrysmod.com/?title=Creating_a_HUD

-- Paints a graphical meter bar
local function PaintBar(x, y, w, h, colors, value)
   -- Background
   -- slightly enlarged to make a subtle border
   draw.RoundedBox(0, x-1, y-1, w+2, h+2, colors.background)
   -- Fill
   local width = w * math.Clamp(value, 0, 1)
   if width > 0 then
      RoundedMeter(0, x, y, width, h, bfhud.punchMeterRight)
      local gradientTexture = surface.GetTextureID("gui/gradient"); -- No file types.
      surface.SetTexture(gradientTexture) -- So it draws in normal color.
      surface.SetDrawColor(colors.fill)
      surface.DrawTexturedRect(x, y, width, h)
   end
end

local roundstate_string = {
   [ROUND_WAIT]   = "round_wait",
   [ROUND_PREP]   = "round_prep",
   [ROUND_ACTIVE] = "round_active",
   [ROUND_POST]   = "round_post"
};

-- Returns player's ammo information
local function GetAmmo(ply)
   local weap = ply:GetActiveWeapon()
   if not weap or not ply:Alive() then return -1 end
   local ammo_inv = weap:Ammo1() or 0
   local ammo_clip = weap:Clip1() or 0
   local ammo_max = weap.Primary.ClipSize or 0
   return ammo_clip, ammo_max, ammo_inv
end

local function DrawBg(x, y, width, height, client)
   -- Traitor area sizes
   local th = 30
   local tw = 170
   -- Adjust for these
   y = y - th
   height = height + th
   -- main bg area, invariant
   -- encompasses entire area
   draw.RoundedBox(0, x, y, width, height, bfhud.hudBG)
end

local sf = surface
local dr = draw

local function ShadowedText(text, font, x, y, color, xalign, yalign)
   dr.SimpleText(text, font, x+2, y+2, COLOR_BLACK, xalign, yalign)
   dr.SimpleText(text, font, x, y, color, xalign, yalign)
end
local margin = 10

-- Paint punch-o-meter
local function PunchPaint(client)
   local L = GetLang()
   local punch = client:GetNWFloat("specpunches", 0)
   local width, height = 260, 30
   local x = ScrW() - width - margin
   local y = ScrH() - height - (2*margin) - 32
   PaintBar(x, y, width, height, ammo_colors, punch)
   local color = Color(255, 255, 255, 255)
   dr.SimpleText(L.punch_title, "BFHUD36", ScrW()-margin-width/2, y-5, color, TEXT_ALIGN_CENTER)
   dr.SimpleText(L.punch_help, "BFHUD22", ScrW()/2, margin-10, bfhud.text, TEXT_ALIGN_CENTER)
   local bonus = client:GetNWInt("bonuspunches", 0)
   if bonus != 0 then
      local text
      if bonus < 0 then
         text = interp(L.punch_bonus, {num = bonus})
      else
         text = interp(L.punch_malus, {num = bonus})
      end
      dr.SimpleText(text, "TabLarge", ScrW() / 2, y * 2, bfhud.text, TEXT_ALIGN_CENTER)
   end
end

local key_params = { usekey = Key("+use", "USE") }

local function SpecHUDPaint(client)
   local L = GetLang() -- for fast direct table lookups
   -- Draw round state
   local height  = 32
   local width   = 250
   local x       = ScrW() - width - margin
   local round_y = ScrH() - height - margin

   -- move up a little on low resolutions to allow space for spectator hints
   if ScrW() < 1000 then round_y = round_y - 15 end
   local time_x = x + 170
   local time_y = round_y + 1
   draw.RoundedBox(0, x-10, round_y, width+10, height, bfhud.hudBG)
   RoundedBoxOutline( 2, x + time_x - x, round_y, width-time_x+x, height-2, bfhud.boxBorder )
   local text = L[ roundstate_string[GAMEMODE.round_state] ]
   ShadowedText(string.upper(text), "TraitorState", x, round_y+1, bfhud.text)
   -- Draw round/prep/post time remaining
   local text = util.SimpleTime(math.max(0, GetGlobalFloat("ttt_round_end", 0) - CurTime()), "%02i:%02i")
   ShadowedText(text, "BFHUD28", time_x + margin + 2, time_y, bfhud.text)
   local tgt = client:GetObserverTarget()
   if IsValid(tgt) and tgt:IsPlayer() then
      local spectateWidth = string.len(tgt:Nick())*36
      draw.RoundedBox(0, (ScrW() / 2) - (spectateWidth/2), margin-2, spectateWidth, 35, bfhud.hudBG)
      RoundedBoxOutline( 2, (ScrW() / 2) - (spectateWidth/2), margin-2, spectateWidth, 35, bfhud.boxBorder )
      ShadowedText(tgt:Nick(), "BFHUD36", ScrW() / 2, margin-5, bfhud.text, TEXT_ALIGN_CENTER)
   elseif IsValid(tgt) and tgt:GetNWEntity("spec_owner", nil) == client then
      PunchPaint(client)
   else
      ShadowedText(string.upper(interp(L.spec_help, key_params)), "BFHUD18", ScrW() / 2, margin, bfhud.text, TEXT_ALIGN_CENTER)
   end
end

local ttt_health_label = CreateClientConVar("ttt_health_label", "0", true)

local function InfoPaint(client)
   local L = GetLang()

   local width = 228
   local height = 66

   local x = ScrW() - width - margin
   local y = ScrH() - height - margin
   bfhud.secretHudY = y -- Used for cl_wepswitch

   DrawBg(x, y, width, height, client)

   local bar_height = 30
   local bar_healthX = ScrW() - 2*margin - 90
   local bar_y = ScrH() - 2*(margin) - bar_height
   local barTextWidth = ScrW() - 3*margin + 3
   local creditText = ""
   local role = LocalPlayer():GetRole() or ROLE_INNOCENT

   -- Draw player name
   if bfhud.playerNamesCredits then
      if LocalPlayer():GetCredits() > 1 then
         creditText = "  ("..tostring(LocalPlayer():GetCredits()).." Credits)"
      elseif LocalPlayer():GetCredits() == 1 then
         creditText = "  ("..tostring(LocalPlayer():GetCredits()).." Credit)"
      else
         creditText = "  (No credits)"
      end
   end
   if bfhud.playerNames then
      if bfhud.secretWeaponUp == false then
         if role == 1 then
            draw.SimpleTextOutlined(client:Nick()..creditText, "BFHUD22", ScrW() - margin, y - 44, Color(255, 255, 255, 0), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER, 2, Color(255, 25, 0, 20))
            draw.SimpleText(client:Nick()..creditText, "BFHUD22", ScrW() - margin, y - 44, Color(255, 115, 130, 255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
         elseif role == 2 then
            draw.SimpleTextOutlined(client:Nick()..creditText, "BFHUD22", ScrW() - margin, y - 44, Color(255, 255, 255, 0), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER, 2, Color(50, 100, 215, 20))
            draw.SimpleText(client:Nick()..creditText, "BFHUD22", ScrW() - margin, y - 44, Color(160, 220, 255, 255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
         else
            draw.SimpleTextOutlined(client:Nick(), "BFHUD22", ScrW() - margin, y - 44, Color(255, 255, 255, 0), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER, 2, Color(25, 255, 25, 15))
            draw.SimpleText(client:Nick(), "BFHUD22", ScrW() - margin, y - 44, Color(221, 252, 174, 255), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
         end
      end
   end
   
   -- Draw health
   local health = math.max(0, client:Health())
   local health_y = bar_y + margin/2
   local healthColor = bfhud.text
   local extraHeight = 0
   RoundedBoxOutline( 2, bar_healthX, bar_y, 90, bar_height, bfhud.boxBorder )
   if client:Health() <= bfhud.damageRequired then
      healthColor = bfhud.textDamage
      surface.SetDrawColor( bfhud.textDamage )
  elseif client:Health() <= bfhud.damageWarningRequired then
	   healthColor = bfhud.textWarning
      surface.SetDrawColor( bfhud.textWarning )
   else
      surface.SetDrawColor( bfhud.text )
   end
   surface.DrawRect( barTextWidth - 70, health_y, 7, 22 )
   surface.DrawRect( barTextWidth - 77, health_y + 7, 22, 7 )
   draw.SimpleText(tostring(health), "BFHUD44", barTextWidth+6, health_y+8, healthColor, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER, 1)
   if ttt_health_label:GetBool() then
      local health_status = util.HealthToString(health)
      extraHeight = 4
      draw.SimpleText(L[health_status], "BFHUD16", barTextWidth - 38, y+19, healthColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
   else
      extraHeight = 0
   end

   -- Draw ammo
   if client:GetActiveWeapon().Primary then
      local ammo_clip, ammo_max, ammo_inv = GetAmmo(client)
      draw.SimpleText("000", "BFHUD84", barTextWidth - 83, y-49, Color(245,245,255,2), TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
      draw.SimpleText("/", "BFHUD28", barTextWidth - 52, y-29, bfhud.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
      draw.SimpleText("000", "BFHUD36", barTextWidth + 10, y-32, Color(245,245,255,2), TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
      if ammo_clip == 0 then
         bfhud.secretWeaponUp = true
         surface.SetDrawColor( bfhud.hudBG )
         surface.DrawRect( x, y - 53, 150, 23 )
         if ammo_inv == 0 then
            draw.SimpleText("NO AMMO", "BFHUD36", barTextWidth - 73, y-61, bfhud.textDanger, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
         else
            RoundedBoxOutline( 2, x + margin, y-52, bar_height-8, bar_height-8, bfhud.boxBorder )
            draw.SimpleText("R", "BFHUD32", x + margin + 4, y-58, bfhud.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_RIGHT, 1)
            draw.SimpleText("RELOAD", "BFHUD36", barTextWidth - 67, y-61, bfhud.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
         end
      else
         bfhud.secretWeaponUp = false
      end
      if ammo_clip != -1 then
         local ammo_y = health_y + bar_height + margin
         local text = string.format("%i + %02i", ammo_clip, ammo_inv)
         draw.SimpleText(ammo_clip, "BFHUD84", barTextWidth - 83, y-49, bfhud.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
         draw.SimpleText(ammo_inv, "BFHUD36", barTextWidth + 10, y-32, bfhud.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
      else
         if bfhud.dashes then
            draw.SimpleText("-", "BFHUD36", barTextWidth + 5, y-34, bfhud.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
            draw.SimpleText("-", "BFHUD36", barTextWidth - 14, y-34, bfhud.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
            draw.SimpleText("-", "BFHUD36", barTextWidth - 32, y-34, bfhud.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
            draw.SimpleText("-", "BFHUD84", barTextWidth - 95, y-53, bfhud.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
            draw.SimpleText("-", "BFHUD84", barTextWidth - 136, y-53, bfhud.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
            draw.SimpleText("-", "BFHUD84", barTextWidth - 177, y-53, bfhud.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
         else
            draw.SimpleText("1", "BFHUD84", barTextWidth - 83, y-49, bfhud.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
            draw.SimpleText("0", "BFHUD36", barTextWidth + 10, y-32, bfhud.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT, 1)
         end
      end
   end

   -- Draw traitor state
   local round_state = GAMEMODE.round_state
   local traitor_y = y - 30
   local text = nil
   local playerHudColour = bfhud.text
   if round_state == ROUND_ACTIVE then
      text = L[ client:GetRoleStringRaw() ]
   else
      text = L[ roundstate_string[round_state] ]
   end
   if bfhud.colourRole then
      if text == "Traitor" or text == "Detective" or text == "Innocent" then
         if role == 1 then
            playerHudColour = bfhud.roleColourT
            draw.SimpleText(string.upper(text), "BFHUD28", barTextWidth - 35, y+10 - extraHeight, playerHudColour, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
         elseif role == 2 then
            playerHudColour = bfhud.roleColourD
            draw.SimpleText(string.upper(text), "BFHUD24", barTextWidth - 35, y+10 - extraHeight, playerHudColour, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
         else
            playerHudColour = bfhud.roleColour
            draw.SimpleText(string.upper(text), "BFHUD26", barTextWidth - 35, y+10 - extraHeight, playerHudColour, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
         end
      else
         draw.SimpleTextOutlined(string.upper(text), "BFHUD20", barTextWidth - 35, y+10 - extraHeight, playerHudColour, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 0.1, Color(245, 245, 255, 255))
      end
   else
      playerHudColour = bfhud.text
      if text == "traitor" or text == "detective" or text == "innocent" then
         if role == 1 then
            draw.SimpleText(string.upper(text), "BFHUD22", barTextWidth - 35, y+10, playerHudColour, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
         elseif role == 2 then
            draw.SimpleText(string.upper(text), "BFHUD22", barTextWidth - 35, y+10, playerHudColour, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
         else
            draw.SimpleText(string.upper(text), "BFHUD22", barTextWidth - 35, y+10, playerHudColour, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
         end
      else
         draw.SimpleTextOutlined(string.upper(text), "BFHUD20", barTextWidth - 35, y+10, playerHudColour, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 0.1, Color(0, 0, 0, 200))
      end
   end

   -- Draw round time
   local is_haste = HasteMode() and round_state == ROUND_ACTIVE
   local is_traitor = client:IsActiveTraitor()
   local endtime = GetGlobalFloat("ttt_round_end", 0) - CurTime()
   local color = bfhud.text
   local rx = x + margin + 170
   local ry = traitor_y + 3
   RoundedBoxOutline( 2, x + margin, bar_y, width - 3*margin - 100, bar_height, bfhud.boxBorder )
   -- Time displays differently depending on whether haste mode is on,
   -- whether the player is traitor or not, and whether it is overtime.
   if is_haste then
      local hastetime = GetGlobalFloat("ttt_haste_end", 0) - CurTime()
      if hastetime < 0 then
         if (not is_traitor) or (math.ceil(CurTime()) % 7 <= 2) then
            -- innocent or blinking "overtime"
            text = L.overtime
            -- need to hack the position a little because of the font switch
            ry = ry + 5
            rx = rx - 3
         else
            -- traitor and not blinking "overtime" right now, so standard endtime display
            text  = util.SimpleTime(math.max(0, endtime), "%02i:%02i")
            color = bfhud.textDamage
         end
      else
         -- still in starting period
         local t = hastetime
         if is_traitor and math.ceil(CurTime()) % 6 < 2 then
            t = endtime
            color = bfhud.textDamage
         end
         text = util.SimpleTime(math.max(0, t), "%02i:%02i")
      end
   else
      -- bog standard time when haste mode is off (or round not active)
      text = util.SimpleTime(math.max(0, endtime), "%02i:%02i")
   end
   draw.SimpleText(text, "BFHUD22", x + margin + 50, health_y + 5 , color, TEXT_ALIGN_CENTER, TEXT_ALIGN_DOWN)
   if is_haste then
      dr.SimpleText(L.hastemode..":", "BFHUD18",  x + margin + 50, health_y - 6, bfhud.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_DOWN)
   else
      dr.SimpleText("TIME LEFT:", "BFHUD18",  x + margin + 50, health_y - 6, bfhud.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_DOWN)
   end
end

local function MinimapDetails(client)
   local y = ScrH() -  20
   local x = 10 
   if bfhud.minimapOn == true and bfhud_MapToggle:GetFloat() == 1 then
      x = x + bfhud.width + 10
      y = y - bfhud.height/2 -- Change this if you get loads of Traitors
   else
      y = y - 100 -- Change this if you get loads of Traitors
   end 
   local currentY = y + 15
   local traitorTable = {}
   local detectiveTable = {}
   local glow = (math.sin(RealTime())+1)*127.5
   local glowColorT = Color(4*(glow/5), (glow/4), (glow/4), 10)
   local glowColorD = Color(4*(glow/5), (glow/4), (glow/4), 10)
   local role = LocalPlayer():GetRole() or ROLE_INNOCENT
   local creditText = ""

   if role == 1 then
      for k,v in pairs(player.GetAll()) do
		if (v != LocalPlayer() and v:IsPlayer()) or (bfhud.selfPlayerNameByHud) then
			 if (v:GetRole() or ROLE_INNOCENT) == 1 then
				traitorTable[k] = v
			 end
		end
      end
      if table.Count(traitorTable) > 0 then
         dr.SimpleTextOutlined("Fellow Traitors:", "BFHUD22", x, y-5, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 0.5, Color(0, 0, 0, bfhud.mapPlayerColourDead.a))
         for i, j in pairs(traitorTable) do
            if j:Alive() then
               if bfhud.playerNamesCredits then
                  if j:GetCredits() > 1 then
                     creditText = "   ("..tostring(j:GetCredits()).." Credits)"
                  elseif j:GetCredits() == 1 then
                     creditText = "   ("..tostring(j:GetCredits()).." Credit)"
                  else
                     creditText = "   (No credits)"
                  end
               end
               draw.SimpleTextOutlined(j:Nick()..creditText, "BFHUD22", x, currentY, Color(255, 255, 255, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 2, Color(255, 25, 0, 20))
               draw.SimpleText(j:Nick()..creditText, "BFHUD22", x, currentY, Color(255, 115, 130, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            else
               dr.SimpleTextOutlined(j:Nick(), "BFHUD22", x, currentY, bfhud.mapPlayerColourDead, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, bfhud.mapPlayerColourDead.a))
            end
            currentY = currentY + 18
         end
      end
   else
      for k,v in pairs(player.GetAll()) do
   		if (v != LocalPlayer() and v:IsPlayer()) or (bfhud.selfPlayerNameByHud) then
   			 if (v:GetRole() or ROLE_INNOCENT) == 2 then
   				detectiveTable[k] = v
   			 end
   		end
      end
      if table.Count(detectiveTable) > 0 then
         dr.SimpleTextOutlined("Detectives:", "BFHUD22", x, y-5, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 0.5, Color(0, 0, 0, bfhud.mapPlayerColourDead.a))
         for i, j in pairs(detectiveTable) do
            local deadWhenConfirmed = false
            if bfhud.detectiveDeadWhenConfirmed then
               deadWhenConfirmed = j:GetNWBool("body_found", false)
            else
               deadWhenConfirmed = true
            end
            if j:Alive() or (not deadWhenConfirmed) then
               if bfhud.playerNamesCredits then
                  if j:GetCredits() > 1 then
                     creditText = "   ("..tostring(j:GetCredits()).." Credits)"
                  elseif j:GetCredits() == 1 then
                     creditText = "   ("..tostring(j:GetCredits()).." Credit)"
                  else
                     creditText = "   (No credits)"
                  end
               end
               draw.SimpleTextOutlined(j:Nick()..creditText, "BFHUD22", x, currentY, Color(255, 255, 255, 0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 2, Color(50, 100, 215, 20))
               draw.SimpleText(j:Nick()..creditText, "BFHUD22", x, currentY, Color(160, 220, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            else
               dr.SimpleTextOutlined(j:Nick(), "BFHUD22", x, currentY, bfhud.mapPlayerColourDead, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, bfhud.mapPlayerColourDead.a))
            end
            currentY = currentY + 18
         end
      end
   end
end

-- Paints player status HUD element in the bottom left
function GM:HUDPaint()
   local client = LocalPlayer()

   GAMEMODE:HUDDrawTargetID()
   MinimapDetails(client)

   MSTACK:Draw(client)

   if (not client:Alive()) or client:Team() == TEAM_SPEC then
      SpecHUDPaint(client)

      return
   end


   RADAR:Draw(client)
   TBHUD:Draw(client)
   WSWITCH:Draw(client)

   VOICE.Draw(client)
   DISGUISE.Draw(client)

   GAMEMODE:HUDDrawPickupHistory()

   -- Draw bottom left info panel
   InfoPaint(client)
end

-- Hide the standard HUD stuff
local hud = {"CHudHealth", "CHudBattery", "CHudAmmo", "CHudSecondaryAmmo"}
function GM:HUDShouldDraw(name)
   for k, v in pairs(hud) do
      if name == v then return false end
   end

   return true
end

