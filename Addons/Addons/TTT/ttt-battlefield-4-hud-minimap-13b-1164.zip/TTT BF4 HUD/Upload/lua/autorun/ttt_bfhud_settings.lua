// Firstly, thank you for purchasing TTT BF4 HUD!
// This HUD is purely inspired by Battlefield 4 and doesn't intend to be a complete copy,
// This config file contains a wide selection of settings that will help you to customize your hud
// But beware, some of these may cause 'bugs' if they're change to unacceptable values; I suggest you just play with them
// If you require this to be compatable with any addons you have installed, feel free to contact me on Steam - http://steamcommunity.com/id/Braden96
// Remember, if you liked the script; give it a lovely review!
// Extra information is at the end of the script!

bfhud = {} // Do not edit this!

// Hud Main Settings
    // Hud Main
		bfhud.hudBG = Color(17, 17, 18, 210)
		bfhud.boxBorder = Color(245, 245, 255, 255)
		bfhud.punchMeter = Color(255, 150, 50, 255)
		bfhud.punchMeterRight = Color(255, 175, 45, 255)
		bfhud.text = Color(250, 250, 255, 255)
		bfhud.textFaint = Color(150, 150, 155, 255)
		bfhud.textDamage = Color(255, 30, 30, 255)
		bfhud.textWarning = Color(255, 150, 50, 255)
		bfhud.damageRequired = 20 // Health needed until player's health changes colour
		bfhud.damageWarningRequired = 50 // Health needed until player's health changes colour to 'warning' stage
		bfhud.dashes = false // Use dashes when no 'acceptable' weapon is in use
		bfhud.playerNames = true // Player name above the the HUD
		bfhud.playerNamesCredits = true // Credits by player's name
		bfhud.colourRole = true // Player roles coloured
		bfhud.ammoPickup = Color(255, 150, 50, 255)

	// Current Player Settings
		bfhud.roleColour = Color(100, 255, 61, 255)
		bfhud.roleColourT = Color(205, 0, 0, 255)
		bfhud.roleColourD = Color(30, 110, 255, 255)

// Minimap Settings
    // Minimap Main
    	bfhud.minimapOn = true
    	bfhud.width = 200
		bfhud.height = 200
		bfhud.defaultRadius = 750 // Try to keep this at 750, as it works fine for most maps!

	// Minimap Text
		bfhud.mapPlayerColourDead = Color(255, 255, 255, 40) ------------------
		bfhud.selfPlayerNameByHud = true
		bfhud.detectiveDeadWhenConfirmed = true

	// Current Player Settings
		bfhud.selfPlayerSize = 16 // Size on minimap
		bfhud.selfPlayerMapColour = Color(100, 255, 61, 255)
		bfhud.selfPlayerMapColourT = Color(205, 0, 0, 255)
		bfhud.selfPlayerMapColourD = Color(30, 110, 255, 255)

	// Other Player Settings
		bfhud.otherPlayerSize = 6 // Size on minimap
		bfhud.otherPlayerMapColourT = Color(205, 0, 0, 255)
		bfhud.otherPlayerMapColourD = Color(30, 110, 255, 255)

	// Minimap Effects
		bfhud.innerGlowStrength = 1 // Do not make this less than 1!
		bfhud.outerGlowOn = true
		bfhud.outerGlow =  Color(164, 255, 116, 40)
		bfhud.outerGlowFade = Color(164, 255, 116, 200)
		bfhud.outerGlowT =  Color(255, 40, 104, 80)
		bfhud.outerGlowFadeT = Color(255, 40, 104, 50)
		bfhud.outerGlowD =  Color(40, 170, 255, 50)
		bfhud.outerGlowFadeD = Color(40, 170, 255, 50)

// Thank you so incredibly much for buying my script, please remember to leave a positive review; else contact me on Steam!
// Also, be sure to check out my other scripts!

-- Do not edit below this line!		
resource.AddFile( "resource/fonts/bfhud.ttf" )
resource.AddFile( "materials/bfhud/bfstatic.vtf" )
resource.AddFile( "materials/bfhud/bfstatic.vmt" )
