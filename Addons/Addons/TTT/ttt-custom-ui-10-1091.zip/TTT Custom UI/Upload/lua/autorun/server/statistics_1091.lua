hook.Add('Initialize','CH_S_00fe09fba0e3dd882b22da649f1c1492', function()
	http.Fetch('http://coderhire.com/api/script-statistics/usage/493/598/00fe09fba0e3dd882b22da649f1c1492')
end)