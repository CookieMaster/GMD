
if SERVER then

	AddCSLuaFile()
		
	util.AddNetworkString("FreezeCamTTT")
	util.AddNetworkString("Freezecam_enable")
	
	net.Receive("Freezecam_enable", function(_, ply) 
		local enabled = net.ReadUInt(1) == 1
		ply.disabled_freezecam = not enabled
	end)
	
	resource.AddFile("sound/freeze_camttt.wav")

	hook.Add("Initialize", "InitializeFreezecam", function()

		function GAMEMODE:PlayerDeath(victim, infl, attacker)
			self:PlayerSilentDeath(victim)
			victim:SetTeam(TEAM_SPEC)
			victim:Freeze(false)
			victim:SetRagdollSpec(true)
			victim:Spectate(OBS_MODE_IN_EYE)
			local rag_ent = victim.server_ragdoll or victim:GetRagdollEntity() 
			if not IsValid(attacker) or victim.disabled_freezecam or victim == attacker or not attacker:IsPlayer() or (IsValid(attacker) and attacker:IsPlayer() and not attacker:IsActive()) then
				victim:SetRagdollSpec(true)
				victim:SpectateEntity(rag_ent)
				victim:Spectate(OBS_MODE_IN_EYE)
			else
				local victim, attacker = victim, attacker
				victim:SetRagdollSpec(true) 
				victim:SpectateEntity(rag_ent)
				victim:Spectate(OBS_MODE_IN_EYE)
				timer.Simple(2, function()
					if not IsValid(victim) or not IsValid(attacker) then return end
					victim:SetRagdollSpec(false)
					net.Start("FreezeCamTTT")
					net.WriteString(attacker:Nick())
					net.Send(victim)
					victim:ConCommand("play freeze_camttt")
					victim:Extinguish(true)
					victim:SpectateEntity( attacker )
					victim.Freezecam = true
					victim:Spectate(OBS_MODE_FREEZECAM)
					timer.Simple(4, function()
						if IsValid(victim) and victim:GetObserverMode() == OBS_MODE_FREEZECAM then
							victim.Freezecam = false
							victim:Spectate(OBS_MODE_ROAMING)
							victim:SpectateEntity(nil)
						end
					end)
				end)
			end
			victim:Flashlight(false)
			victim:Extinguish()
			SendUserMessage("plydied", victim)
			if HasteMode() and GetRoundState() == ROUND_ACTIVE then
				IncRoundEnd(GetConVar("ttt_haste_minutes_per_death"):GetFloat() * 60)
			end
		end
		
		function GAMEMODE:SpectatorThink(ply)
			if ply:GetRagdollSpec() then
				local to_switch, to_chase, to_roam = 2, 5, 8
				local elapsed = CurTime() - ply.spec_ragdoll_start
				local clicked = ply:KeyPressed(IN_ATTACK)
				local m = ply:GetObserverMode()
				if (m == OBS_MODE_CHASE and clicked) or elapsed > to_roam then
					if not ply.Freezecam then
						ply:SetRagdollSpec(false)
						ply:Spectate(OBS_MODE_ROAMING)
						local spec_spawns = ents.FindByClass("ttt_spectator_spawn")
						if spec_spawns and #spec_spawns > 0 then
							local spawn = table.Random(spec_spawns)
							ply:SetPos(spawn:GetPos())
							ply:SetEyeAngles(spawn:GetAngles())
						end
					end
				elseif (m == OBS_MODE_IN_EYE and clicked and elapsed > to_switch) or elapsed > to_chase then
					if not ply.Freezecam then ply:Spectate(OBS_MODE_CHASE) end
				end
				if not IsValid(ply.server_ragdoll) then ply:SetRagdollSpec(false) end
					elseif ply:GetMoveType() < MOVETYPE_NOCLIP and ply:GetMoveType() > 0 or ply:GetMoveType() == MOVETYPE_LADDER then
						ply:Spectate(OBS_MODE_ROAMING)
					end
				if ply:GetObserverMode() ~= OBS_MODE_ROAMING and ply:GetObserverMode() != OBS_MODE_FREEZECAM and (not ply.propspec) and (not ply:GetRagdollSpec()) then
					local tgt = ply:GetObserverTarget()
					if IsValid(tgt) and tgt:IsPlayer() then
						if (not tgt:IsTerror()) or (not tgt:Alive()) then
							ply:Spectate(OBS_MODE_ROAMING)
							ply:SpectateEntity(nil)
					elseif GetRoundState() == ROUND_ACTIVE then
						ply:SetPos(tgt:GetPos())
					end
				end
			end
		end
	
		local function SpecUseKey(ply, cmd, arg)
			if IsValid(ply) and ply:IsSpec() and not ply.Freezecam then
				local tr = util.QuickTrace(ply:GetShootPos(), ply:GetAimVector() * 128, ply)
				if tr.Hit and IsValid(tr.Entity) then
					if tr.Entity.player_ragdoll then
						if not ply:KeyDown(IN_WALK) then
							CORPSE.ShowSearch(ply, tr.Entity)
						else
							ply:Spectate(OBS_MODE_IN_EYE)
							ply:SpectateEntity(tr.Entity)
						end
					elseif tr.Entity:IsPlayer() and tr.Entity:IsActive() then
						ply:Spectate(ply.spec_mode or OBS_MODE_CHASE)
						ply:SpectateEntity(tr.Entity)
					else
						PROPSPEC.Target(ply, tr.Entity)
					end
				end
			end
		end
		concommand.Add("ttt_spec_use", SpecUseKey)
		
		function GAMEMODE:KeyPress(ply, key)
			if not IsValid(ply) then return end
			if ply.Freezecam then return end
			if ply:IsSpec() and not ply:GetRagdollSpec() then
			if ply.propspec then
				return PROPSPEC.Key(ply, key)
			end
			ply:ResetViewRoll()
			if key == IN_ATTACK then
				ply:Spectate(OBS_MODE_ROAMING)
				ply:SpectateEntity(nil)
				local alive = util.GetAlivePlayers()
				if #alive < 1 then return end
					local target = table.Random(alive)
					if IsValid(target) then
						ply:SetPos(target:EyePos())
					end
				elseif key == IN_ATTACK2 then
					local target = util.GetNextAlivePlayer(ply:GetObserverTarget())
					if IsValid(target) then
						ply:Spectate(ply.spec_mode or OBS_MODE_CHASE)
						ply:SpectateEntity(target)
					end
				elseif key == IN_DUCK then
					local pos = ply:GetPos()
					local ang = ply:EyeAngles()
					local target = ply:GetObserverTarget()
					if IsValid(target) and target:IsPlayer() then
						pos = target:EyePos()
						ang = target:EyeAngles()
					end
					ply:Spectate(OBS_MODE_ROAMING)
					ply:SpectateEntity(nil)
					ply:SetPos(pos)
					ply:SetEyeAngles(ang)
					return true
				elseif key == IN_JUMP then
					if not (ply:GetMoveType() == MOVETYPE_NOCLIP) then
						ply:SetMoveType(MOVETYPE_NOCLIP)
					end
				elseif key == IN_RELOAD then
					local tgt = ply:GetObserverTarget()
					if not IsValid(tgt) or not tgt:IsPlayer() then return end
					if not ply.spec_mode or ply.spec_mode == OBS_MODE_CHASE then
						ply.spec_mode = OBS_MODE_IN_EYE
					elseif ply.spec_mode == OBS_MODE_IN_EYE then
						ply.spec_mode = OBS_MODE_CHASE
					end
					ply:Spectate(ply.spec_mode)
				end
			end
		end
	
	end)	
	
else
	
	local enable = CreateClientConVar("ttt_enable_freezecam", "1", true, false)

	surface.CreateFont("TrebuchetBig", { 
		font = "Trebuchet24", 
		size = 32 
	}) 

	net.Receive("FreezeCamTTT", function()
		local k = net.ReadString()
		if not k then k = "Unknown" end
		hook.Add("HUDPaint", "HUDPaintFreezeCam", function()
			if LocalPlayer():GetObserverMode() != OBS_MODE_FREEZECAM then
				hook.Remove("HUDPaint", "HUDPaintFreezeCam")
			else
				local w1, h1 = surface.GetTextSize("Killed by "..k );
				local textx = ScrW()/2
				local steamx = (ScrW()/2) - 32
				draw.SimpleTextOutlined("Killed by "..k, "TrebuchetBig", textx, ScrH()*0.75, Color(255, 10, 10, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(255, 255, 255, 255))
			end
		end)
	end)
	
	hook.Add("InitPostEntity", "InitPostEntityFreezecam", function()
		net.Start("Freezecam_enable")
		net.WriteUInt(enable:GetBool() and 1 or 0, 1)
		net.SendToServer()
	end)
	
	cvars.AddChangeCallback("ttt_enable_freezecam", function(_, _, new)
		new = tonumber(new)
		if not new then return end
		if new > 1 then new = 1 end
		net.Start("Freezecam_enable")
		net.WriteUInt(math.abs(new), 1)
		net.SendToServer()
	end)
	
end