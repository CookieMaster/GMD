ENT.Type			= "anim"
ENT.Spawnable		= false
ENT.AdminSpawnable  = true

ENT.PrintName		= "Chicken"
ENT.Author			= "Phoenixf129"
ENT.Contact    		= ""
ENT.Purpose 		= "Chicken"
ENT.Instructions 	= "Chicken"
ENT.Projectile		= true
ENT.Icon			= "vgui/ttt/icon_gpi_chicken.vmt"
ENT.CanPickup		= true
ENT.AllowPropspec 	= false
ENT.IsPoisoned 		= false