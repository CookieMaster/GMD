hook.Add('Initialize','CH_S_314eab59443cfb089913d0a94f713f8f', function()
	http.Fetch('http://coderhire.com/api/script-statistics/usage/493/546/314eab59443cfb089913d0a94f713f8f')
end)