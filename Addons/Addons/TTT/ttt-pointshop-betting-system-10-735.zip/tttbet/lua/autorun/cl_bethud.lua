
AddCSLuaFile( "betconfig.lua" )
if CLIENT then
	surface.CreateFont( "rank",
			{
			font = "ScoreboardText",
			size = 18,
			weight = 400
			})
end
local function SpecHUDPaints(client)



	local margin = 10
    local height  = 32
    local width   = 250
	local x       = ScrW() - margin
    local round_y = ScrH() - height - margin
	local teambet = client:GetNWString("TeamBet")
	local betamount = client:GetNWInt("betammount")
	local teamt = gettrcount()
	local teami = getincount()
	local teambetT = (gettrcount() - getincount())
	local teambetI = (getincount() - gettrcount()) 
	winamm = 0
	if bethud == "on" then
		if GetRoundState() == ROUND_ACTIVE or GetRoundState() == ROUND_POST then	
			draw.RoundedBox(8, x - 280, round_y - 120, width + 20, height * 4, Color(0,0,0,255))
			draw.DrawText("-- All bets -- ","rank",x + margin - 245, round_y - 40, COLOR_WHITE)			
			draw.DrawText("T: "..teamt,"rank",x + margin - 240, round_y - 20, Color(255,0,0,255))
			draw.DrawText("Team you bet on: "..teambet,"rank",x + margin - 260, round_y - 100, COLOR_WHITE)
			draw.DrawText("Amount you bet: "..betamount,"rank",x + margin - 260, round_y - 80, COLOR_WHITE)
			draw.DrawText("I: "..teami,"rank",x + margin - 200, round_y - 20, Color(0,255,0,255))
			plyCount = table.Count(player.GetAll())
		
			if wintyp == "odds" then
				if teambet == "Traitor" then
					if teambetT < 1 then
						winamm = 1 * betamount

					elseif teambetT >= 1 then
						winamm = teambetT * betamount

					end
				elseif teambet == "Innocent" then
					if teambetI < 1 then
						winamm = 1 * betamount

					elseif teambetI >= 1 then
						winamm = teambetI * betamount

					end
				end
			elseif wintyp == "percent" then
				winamm = winper * betamount

			
				
			end
				draw.DrawText("Amount you could win: "..winamm,"rank",x + margin - 260, round_y - 60, COLOR_WHITE)
			if plyCount < pcount then
				draw.DrawText("Not enough people to bet.","rank",x + margin - 260, round_y - 120, Color(255,0,0,255))

			elseif client:GetNWInt("bettime") == 1 and client:GetNWInt("youbet") == 0 and plyCount >= pcount then
				draw.DrawText("It is too late to bet now.","rank",x + margin - 260, round_y - 120, Color(255,0,0,255))

			elseif client:GetNWInt("youbet") == 1 and plyCount >= pcount then
				draw.DrawText("You have already bet.","rank",x + margin - 260, round_y - 120, Color(255,0,0,255))

			elseif client:GetNWInt("youbet") == 0 and plyCount >= pcount then
				draw.DrawText("Type !bet to start betting points!","rank",x + margin - 260, round_y - 120, Color(150,150,0,255))
			
			elseif GetRoundState() != ROUND_ACTIVE and plyCount >= pcount then
				draw.DrawText("Please wait to bet.","rank",x + margin - 260, round_y - 120, Color(150,150,0,255))

			end
		else
			draw.RoundedBox(8, x - 280, round_y - 120, width + 20, height * 4, Color(0,0,0,255))
			draw.DrawText("Please wait for round to start.","rank",x + margin - 260, round_y - 120, Color(255,0,0,255))
			draw.DrawText("-- All bets -- ","rank",x + margin - 245, round_y - 40, COLOR_WHITE)			
			draw.DrawText("T: "..teamt,"rank",x + margin - 240, round_y - 20, Color(255,0,0,255))
			--draw.DrawText("Team you bet on: "..teambet,"rank",x + margin - 260, round_y - 100, COLOR_WHITE)
			--draw.DrawText("Amount you bet: "..betamount,"rank",x + margin - 260, round_y - 80, COLOR_WHITE)
			draw.DrawText("I: "..teami,"rank",x + margin - 200, round_y - 20, Color(0,255,0,255))		
		end
	else return end	
		
end
	
function paintit()
	local client = LocalPlayer()
		if (not client:Alive()) or client:Team() == TEAM_SPEC then
			SpecHUDPaints(client)

		return
		end
end		
hook.Add("HUDPaint", "paintit", paintit)
