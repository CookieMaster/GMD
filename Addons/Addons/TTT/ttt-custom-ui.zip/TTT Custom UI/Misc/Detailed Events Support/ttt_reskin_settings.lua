// Place this somewhere inside your main ttt_reskin_settings.lua
// Detailed Events
	// DE Main
		tttreskin.debg = Color(34, 34, 34, 255) // 6Aa
		tttreskin.debgtop = Color(64, 64, 64, 255) // 6Ab

	// DE Load Button
		tttreskin.deloadbtnborder = Color(89, 166, 67, 255) //6Ba
		tttreskin.deloadbtnshine = Color(134, 208, 118, 255) // 6Bb
		tttreskin.deloadbtngrdtop = Color(106, 196, 81, 255) // 6Bc
		tttreskin.deloadbtngrdbtm = Color(88, 164, 67, 255) // 6Bd
		tttreskin.deloadbtntext = Color(255, 255, 255, 255) // 6Be
		tttreskin.deloadbtntexthover = Color(0, 0, 0, 255) // 6Bf

	// DE Clear Button
		tttreskin.declearbtnborder = Color(192, 73, 61, 255) // 6Ca
		tttreskin.declearbtnshine = Color(237, 128, 121, 255) // 6Cb
		tttreskin.declearbtngrdtop = Color(233, 96, 86, 255) // 6Cc
		tttreskin.declearbtngrdbtm = Color(185, 56, 42, 255) // 6Cd
		tttreskin.declearbtntext = Color(255, 255, 255, 255) // 6Ce
		tttreskin.declearbtntexthover = Color(0, 0, 0, 255) // 6Cf

	// DE Search Button
		tttreskin.desearchbtnborder = Color(89, 166, 67, 255) // 6Da
		tttreskin.desearchbtnshine = Color(134, 208, 118, 255) // 6Db
		tttreskin.desearchbtngrdtop = Color(106, 196, 81, 255) // 6Dc
		tttreskin.desearchbtngrdbtm = Color(88, 164, 67, 255) // 6Dd
		tttreskin.desearchbtntext = Color(255, 255, 255, 255) // 6De
		tttreskin.desearchbtntexthover = Color(0, 0, 0, 255) // 6Df

	// DE RDM Button
		tttreskin.derdmbtnborder = Color(171, 61, 203, 255) //6Ea
		tttreskin.derdmbtnshine = Color(217, 121, 248, 255) // 6Eb
		tttreskin.derdmbtngrdtop = Color(208, 85, 245, 255) // 6Ec
		tttreskin.derdmbtngrdbtm = Color(163, 42, 197, 255) // 6Ed
		tttreskin.derdmbtntext = Color(255, 255, 255, 255) // 6Ee
		tttreskin.derdmbtntexthover = Color(0, 0, 0, 255) // 6Ef

	// DE Refresh Button
		tttreskin.derefreshbtnborder = Color(222, 152, 0, 255) //6Fa
		tttreskin.derefreshbtnshine = Color(249, 196, 100, 255) // 6Fb
		tttreskin.derefreshbtngrdtop = Color(248, 181, 50, 255) // 6Fc
		tttreskin.derefreshbtngrdbtm = Color(244, 150, 0, 255) // 6Fd
		tttreskin.derefreshbtntext = Color(255, 255, 255, 255) // 6Fe
		tttreskin.derefreshbtntexthover = Color(0, 0, 0, 255) // 6Ff