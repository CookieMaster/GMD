-- HUD HUD HUD

local table = table
local surface = surface
local draw = draw
local math = math
local string = string

local points = {}
points[240] = 86
points[239] = 87
points[238] = 88
points[237] = 89
points[236] = 90
points[235] = 90
points[234] = 90
points[233] = 90
points[232] = 91
points[231] = 91
points[230] = 91
points[229] = 92
points[228] = 92
points[227] = 92
points[226] = 93
points[225] = 93
points[224] = 93
points[223] = 94
points[222] = 95
points[221] = 95
points[220] = 95
points[219] = 95
points[218] = 96
points[217] = 96
points[216] = 97
points[215] = 97
points[214] = 97
points[213] = 97
points[212] = 98
points[211] = 98
points[210] = 98
points[209] = 99
points[208] = 99
points[207] = 100
points[206] = 100
points[205] = 100
points[204] = 100
points[203] = 101
points[202] = 101
points[201] = 102
points[200] = 102
points[199] = 102
points[198] = 103
points[197] = 103
points[196] = 103
points[195] = 103
points[194] = 104
points[193] = 104
points[192] = 105
points[191] = 105
points[190] = 105
points[189] = 105
points[188] = 105
points[187] = 105
points[186] = 105
points[185] = 105
points[184] = 105
points[183] = 105
points[182] = 105
points[181] = 105
points[180] = 105
points[179] = 106
points[178] = 106
points[177] = 107
points[176] = 107
points[175] = 107
points[174] = 107
points[173] = 107
points[172] = 107
points[171] = 107
points[170] = 107
points[169] = 107
points[168] = 107
points[167] = 107
points[166] = 107
points[165] = 107
points[164] = 107
points[163] = 106
points[162] = 106
points[161] = 106
points[160] = 106
points[159] = 106
points[158] = 106
points[157] = 106
points[156] = 106
points[155] = 106
points[154] = 106
points[153] = 105
points[152] = 105
points[151] = 105
points[150] = 105
points[149] = 105
points[148] = 105
points[147] = 105
points[146] = 104
points[145] = 104
points[144] = 104
points[143] = 104
points[142] = 104
points[141] = 104
points[140] = 104
points[139] = 104
points[138] = 104
points[137] = 104
points[136] = 104
points[135] = 104
points[134] = 104
points[133] = 104
points[132] = 104
points[131] = 103
points[130] = 103
points[129] = 103
points[128] = 103
points[127] = 103
points[126] = 103
points[125] = 103
points[124] = 103
points[123] = 103
points[122] = 102
points[121] = 102
points[120] = 102
points[119] = 101
points[118] = 101
points[117] = 101
points[116] = 101
points[115] = 101
points[114] = 101
points[113] = 101
points[112] = 101
points[111] = 101
points[110] = 101
points[109] = 101
points[108] = 101
points[107] = 101
points[106] = 101
points[105] = 101
points[104] = 101
points[103] = 101
points[102] = 101
points[101] = 101
points[100] = 101
points[99] = 101
points[98] = 101
points[97] = 101
points[96] = 101
points[95] = 101
points[94] = 101
points[93] = 101
points[92] = 101
points[91] = 101
points[90] = 101
points[89] = 101
points[88] = 101
points[87] = 101
points[86] = 101
points[85] = 101
points[84] = 101
points[83] = 101
points[82] = 101
points[81] = 101
points[80] = 102
points[79] = 102
points[78] = 102
points[77] = 102
points[76] = 102
points[75] = 102
points[74] = 102
points[73] = 102
points[72] = 102
points[71] = 102
points[70] = 103
points[69] = 103
points[68] = 103
points[67] = 103
points[66] = 103
points[65] = 103
points[64] = 103
points[63] = 103
points[62] = 103
points[61] = 104
points[60] = 104
points[59] = 104
points[58] = 104
points[57] = 104
points[56] = 104
points[55] = 105
points[54] = 105
points[53] = 105
points[52] = 105
points[51] = 105
points[50] = 105
points[49] = 105
points[48] = 106
points[47] = 106
points[46] = 106
points[45] = 106
points[44] = 107
points[43] = 107
points[42] = 107
points[41] = 108
points[40] = 108
points[39] = 109
points[38] = 109
points[37] = 109
points[36] = 109
points[35] = 109
points[34] = 110
points[33] = 110
points[32] = 110
points[31] = 110
points[30] = 110
points[29] = 110
points[28] = 111
points[27] = 112
points[26] = 113
points[25] = 113
points[24] = 114
points[23] = 114
points[22] = 115
points[21] = 115
points[20] = 116
points[19] = 116
points[18] = 116
points[17] = 117
points[16] = 117
points[15] = 118
points[14] = 119
points[13] = 119
points[12] = 119
points[11] = 120
points[10] = 121
points[9] = 121
points[8] = 122
points[7] = 123
points[6] = 124
points[5] = 124
points[4] = 124
points[3] = 125
points[2] = 125
points[1] = 126

local GetTranslation = LANG.GetTranslation
local GetPTranslation = LANG.GetParamTranslation
local GetLang = LANG.GetUnsafeLanguageTable
local interp = string.Interp

-- Fonts
surface.CreateFont("TraitorState", {font = "Trebuchet24",
                                    size = 28,
                                    weight = 1000})
surface.CreateFont("TimeLeft",     {font = "Trebuchet24",
                                    size = 24,
                                    weight = 800})
surface.CreateFont("HealthAmmo",   {font = "Trebuchet24",
                                    size = 24,
                                    weight = 750})

surface.CreateFont("Turnpike",   {font = "Turnpike",
                                    size = 24,
                                    weight = 700})

-- Color presets
local bg_colors = {
   background_main = Color(0, 0, 10, 200),

   noround = Color(100,100,100,200),
   traitor = Color(200, 25, 25, 200),
   innocent = Color(25, 200, 25, 200),
   detective = Color(25, 25, 200, 200)
};

local health_colors = {
   border = COLOR_WHITE,
   background = Color(100, 25, 25, 222),
   fill = Color(200, 50, 50, 250)
};

local ammo_colors = {
   border = COLOR_WHITE,
   background = Color(20, 20, 5, 222),
   fill = Color(205, 155, 0, 255)
};


-- Modified RoundedBox
local Tex_Corner8 = surface.GetTextureID( "gui/corner8" )
local function RoundedMeter( bs, x, y, w, h, color)
   surface.SetDrawColor(clr(color))

   surface.DrawRect( x+bs, y, w-bs*2, h )
   surface.DrawRect( x, y+bs, bs, h-bs*2 )

   surface.SetTexture( Tex_Corner8 )
   surface.DrawTexturedRectRotated( x + bs/2 , y + bs/2, bs, bs, 0 )
   surface.DrawTexturedRectRotated( x + bs/2 , y + h -bs/2, bs, bs, 90 )

   if w > 14 then
      surface.DrawRect( x+w-bs, y+bs, bs, h-bs*2 )
      surface.DrawTexturedRectRotated( x + w - bs/2 , y + bs/2, bs, bs, 270 )
      surface.DrawTexturedRectRotated( x + w - bs/2 , y + h - bs/2, bs, bs, 180 )
   else
      surface.DrawRect( x + math.max(w-bs, bs), y, bs/2, h )
   end

end

---- The bar painting is loosely based on:
---- http://wiki.garrysmod.com/?title=Creating_a_HUD

-- Paints a graphical meter bar
local function PaintBar(x, y, w, h, colors, value)
   -- Background
   -- slightly enlarged to make a subtle border
   draw.RoundedBox(8, x-1, y-1, w+2, h+2, colors.background)

   -- Fill
   local width = w * math.Clamp(value, 0, 1)

   if width > 0 then
      RoundedMeter(8, x, y, width, h, colors.fill)
   end
end

local roundstate_string = {
   [ROUND_WAIT]   = "round_wait",
   [ROUND_PREP]   = "round_prep",
   [ROUND_ACTIVE] = "round_active",
   [ROUND_POST]   = "round_post"
};

-- Returns player's ammo information
local function GetAmmo(ply)
   local weap = ply:GetActiveWeapon()
   if not IsValid(weap) or not ply:Alive() then return -1 end

   local ammo_inv = weap:Ammo1()
   local ammo_clip = weap:Clip1()
   local ammo_max = weap.Primary.ClipSize

   return ammo_clip, ammo_max, ammo_inv
end

local function DrawBg(x, y, width, height, client)
   -- Traitor area sizes
   local th = 30
   local tw = 170

   -- Adjust for these
   y = y - th
   height = height + th

   -- main bg area, invariant
   -- encompasses entire area
   draw.RoundedBox(8, x, y, width, height, bg_colors.background_main)

   -- main border, traitor based
   local col = bg_colors.innocent
   if GAMEMODE.round_state != ROUND_ACTIVE then
      col = bg_colors.noround
   elseif client:GetTraitor() then
      col = bg_colors.traitor
   elseif client:GetDetective() then
      col = bg_colors.detective
   end

   draw.RoundedBox(8, x, y, tw, th, col)
end

local sf = surface
local dr = draw

local function ShadowedText(text, font, x, y, color, xalign, yalign)

   dr.SimpleText(text, font, x+2, y+2, COLOR_BLACK, xalign, yalign)

   dr.SimpleText(text, font, x, y, color, xalign, yalign)
end

local margin = 10

-- Paint punch-o-meter
local function PunchPaint(client)
   local L = GetLang()
   local punch = client:GetNWFloat("specpunches", 0)

   local width, height = 200, 25
   local x = ScrW() / 2 - width/2
   local y = margin/2 + height

   PaintBar(x, y, width, height, ammo_colors, punch)

   local color = bg_colors.background_main

   dr.SimpleText(L.punch_title, "HealthAmmo", ScrW() / 2, y, color, TEXT_ALIGN_CENTER)

   dr.SimpleText(L.punch_help, "TabLarge", ScrW() / 2, margin, COLOR_WHITE, TEXT_ALIGN_CENTER)

   local bonus = client:GetNWInt("bonuspunches", 0)
   if bonus != 0 then
      local text
      if bonus < 0 then
         text = interp(L.punch_bonus, {num = bonus})
      else
         text = interp(L.punch_malus, {num = bonus})
      end

      dr.SimpleText(text, "TabLarge", ScrW() / 2, y * 2, COLOR_WHITE, TEXT_ALIGN_CENTER)
   end
end

local key_params = { usekey = Key("+use", "USE") }

local function SpecHUDPaint(client)
   local L = GetLang() -- for fast direct table lookups

   -- Draw round state
   local x       = margin
   local height  = 32
   local width   = 250
   local round_y = ScrH() - height - margin

   -- move up a little on low resolutions to allow space for spectator hints
   if ScrW() < 1000 then round_y = round_y - 15 end

   local time_x = x + 170
   local time_y = round_y + 4

   draw.RoundedBox(8, x, round_y, width, height, bg_colors.background_main)
   draw.RoundedBox(8, x, round_y, time_x - x, height, bg_colors.noround)

   local text = L[ roundstate_string[GAMEMODE.round_state] ]
   ShadowedText(text, "TraitorState", x + margin, round_y, COLOR_WHITE)

   -- Draw round/prep/post time remaining
   local text = util.SimpleTime(math.max(0, GetGlobalFloat("ttt_round_end", 0) - CurTime()), "%02i:%02i")
   ShadowedText(text, "TimeLeft", time_x + margin, time_y, COLOR_WHITE)

   local tgt = client:GetObserverTarget()
   if IsValid(tgt) and tgt:IsPlayer() then
      ShadowedText(tgt:Nick(), "TimeLeft", ScrW() / 2, margin, COLOR_WHITE, TEXT_ALIGN_CENTER)

   elseif IsValid(tgt) and tgt:GetNWEntity("spec_owner", nil) == client then
      PunchPaint(client)
   else
      ShadowedText(interp(L.spec_help, key_params), "TabLarge", ScrW() / 2, margin, COLOR_WHITE, TEXT_ALIGN_CENTER)
   end
end

local ttt_health_label = CreateClientConVar("ttt_health_label", "0", true)

local sin,cos,rad = math.sin,math.cos,math.rad;

local circleCache = {}
function generateCircle(x,y,radius,quality)

   if (!circleCache[radius]) then 
      local circle = {};
      local tmp = 0;
      for i=1,quality do
         tmp = rad(i*360)/quality
         circle[i] = {x = x + cos(tmp)*radius,y = y + sin(tmp)*radius};
      end
      circleCache[radius] = circle
      return circle;
   end
   
   return circleCache[radius]
end

local mBullets = Material("thud/bullets.png")
local mGradient = Material("thud/grad.png")
local mHealth = Material("thud/health.png")
local mMedic = Material("thud/health_medic.png")
local mRing = Material("thud/health_ring.png")
local mJuice = Material("thud/health_juice.png")
local mWhite = CreateMaterial("healthBG", "UnlitGeneric", {["$basetexture"] = "vgui/white"})
local rtSave1 = render.GetScreenEffectTexture(0)
local rtSave = render.GetScreenEffectTexture(1)
local mCopy = Material("pp/copy")

local mWick = Material("thud/wick.png")
local mRound = Material("thud/round.png")

local sparks = {}

local function InfoPaint(client)
   
   mWhite:SetVector("$color", Vector(59/255, 50/255, 50/255))

   local width = 512
   local height = 128
   local margin = 2
   local x = margin
   local y = ScrH() - margin - height

   local col = bg_colors.innocent
   if GAMEMODE.round_state != ROUND_ACTIVE then
      col = bg_colors.noround
   elseif client:GetTraitor() then
      col = bg_colors.traitor
   elseif client:GetDetective() then
      col = bg_colors.detective
   end
   surface.SetDrawColor(col)
   surface.SetMaterial(mGradient)
   surface.DrawTexturedRect(x + 64, y+6, 380, 48-6)

   surface.SetDrawColor(Color(0, 0, 0))
   draw.RoundedBoxEx(6, x + 64, y+48, 380, 80, Color(0, 0, 0), false, true, false, true)

   local pad = 6


   function bezierCalc(t)
      local num = math.ceil((t/100) * 240)
      return num, points[num]
   end

   function drawSmoke(x, y)
      if (!smokes) then
         smokes = {}
      end
      if (#smokes <= 24) then
         local smoke = {}
         smoke.dir = Vector(math.Rand(-1, 1), math.Rand(-1, 1), 0)
         smoke.vel = math.random(0, 15)
         local c = math.Rand(0, 180)
         smoke.color = Color(c, c, c)
         smoke.startTime = CurTime()
         smoke.endTime = CurTime() + math.Rand(0, 0.25)
         smoke.lifeTime = smoke.endTime - smoke.startTime
         local s = math.Rand(6, 12)
         smoke.size = Vector(s, s, 0)
         table.insert(smokes, smoke)
      end

      for k, smoke in pairs(smokes) do
         if (!smoke.pos) then
            smoke.pos = Vector(x, y, 0)
         end

         local vel = smoke.vel * FrameTime()
         smoke.pos = smoke.pos + Vector(smoke.dir.x * vel, smoke.dir.y * vel, 0)

         surface.SetMaterial(mRound)
         surface.SetDrawColor(smoke.color)
         surface.DrawTexturedRect(smoke.pos.x - 3, smoke.pos.y - 3, smoke.size.x, smoke.size.y)

         if (CurTime() >= smoke.endTime) then
            smokes[k] = nil
         end
      end
   end

   function drawSparks(x, y)
      if (#sparks <= 24) then
         local spark = {}
         spark.dir = Vector(math.Rand(-1, 1), math.Rand(-1, 1), 0)
         spark.vel = math.random(50, 100)
         local c = math.Rand(0, 1)
         if (c >= 0.5) then
            spark.color = Color(math.random(200, 250), math.random(200, 200), 75)
         else
            spark.color = Color(math.random(225, 250), math.random(50, 150), 0)
         end
         spark.startTime = CurTime()
         spark.endTime = CurTime() + math.Rand(0, 0.25)
         spark.lifeTime = spark.endTime - spark.startTime
         spark.size = Vector(math.Rand(3, 9), math.Rand(3, 9))
         table.insert(sparks, spark)
      end

      for k, spark in pairs(sparks) do
         if (!spark.pos) then
            spark.pos = Vector(x, y, 0)
         end

         local vel = spark.vel * FrameTime()
         spark.pos = spark.pos + Vector(spark.dir.x * vel, spark.dir.y * vel, 0)

         surface.SetMaterial(mRound)
         surface.SetDrawColor(spark.color)
         surface.DrawTexturedRect(spark.pos.x - 3, spark.pos.y - 3, spark.size.x, spark.size.y)

         if (CurTime() >= spark.endTime) then
            sparks[k] = nil
         end
      end
   end

   -- Haste Mode shit by Spencer
   local is_haste = HasteMode() and GAMEMODE.round_state == ROUND_ACTIVE

   /*if is_haste then
      if (not hasteStart) then
         hasteStart = CurTime()
      end
      hasteEnd = GetGlobalFloat("ttt_haste_end", 0)
      hasteTotal = hasteEnd-hasteStart
      hasteTime = hasteEnd - CurTime()

      hastePercent = (hasteTime/hasteTotal)*100
      
      local lx, ly = x + 64, y - 120
      local hx, hy = bezierCalc(hastePercent)

      surface.SetDrawColor(Color(255, 255, 255))
      surface.SetMaterial(mWick)

      render.SetScissorRect(lx, ly, lx + hx, ly + 128, true)
      surface.DrawTexturedRect(lx, ly, 256, 128)
      render.SetScissorRect(0, 0, 0, 0, false)
      

      drawSmoke(lx + hx, ly + hy)
      drawSparks(lx + hx, ly + hy)
   else
      hasteStart = false
   end*/

   --End HAste mode fcuckin high as shit right now :)



   surface.SetDrawColor(Color(70, 70, 70))
   draw.RoundedBox(6, x + 128 + pad, y + 48 + pad, 380 - 64 - pad*2, 80/2 - pad*1.5, Color(70, 70, 70))
   draw.RoundedBox(6, x + 128 + pad + 32, y + 48 + (80/2 - pad*1.5) + pad*2, 380 - 64 - pad*2 - 32, 80/2 - pad*1.5, Color(70, 70, 70))

   surface.SetMaterial(mBullets)
   surface.SetDrawColor(Color(255, 255, 255))
   surface.DrawTexturedRect(x + 128 + pad - 8, y + 48 + (80/2 - pad*1.5) + pad*2, 32, 32)




   /** START SPENCER'S TTT HUD CODE **/

   -- This function renders the grey background, red health fill, and juice animation items
   local ratio = (128/100)*client:Health() - 16
   local function renderJuice() 
      cam.Start2D()
         -- Boring solid background
         render.SetMaterial(mWhite)
         render.DrawScreenQuad() 

         -- Solid health below juice
         surface.SetDrawColor(Color(150, 0, 0))
         surface.SetMaterial(mHealth)
         render.SetScissorRect(x, y + 128 - ratio, x+128, y+128, true)
             surface.DrawTexturedRect(x+2, y+2, 124, 124)
         render.SetScissorRect(0, 0, 0, 0, false)

         --Two juices
         surface.SetMaterial(mJuice)
         surface.SetDrawColor(Color(255, 0, 0, 255))
         surface.DrawTexturedRect(x + math.sin(RealTime()*0.75)*48 - 64, y - 16 + 128 - ratio, 256, 16)
         surface.SetMaterial(mJuice)
         surface.SetDrawColor(Color(150, 0, 0, 255))
         surface.DrawTexturedRect(x + math.cos(RealTime()*0.5)*-30 - 64, y - 16 + 128 - ratio + 5, 256, 11)
      cam.End2D()
   end
   
   local renderTarget = render.GetRenderTarget() --Backup our rendertarget
   render.CopyRenderTargetToTexture(rtSave1) -- Copy the current unedited view to a texture for later
   render.OverrideDepthEnable( true, false ) -- disable Depth because non-screen buffers don't like depth either.. or something

   renderJuice() -- Render our juice and other things that should be clipped within the circle
   
   render.CopyRenderTargetToTexture(rtSave) -- Copy the juice stuff into a texture


   render.SetStencilEnable(true) -- Enable the stencil, time to do some snipping >:)
      render.ClearStencil()

      render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_ALWAYS) --Always overwrite
      render.SetStencilFailOperation(STENCILOPERATION_KEEP)
      render.SetStencilZFailOperation(STENCILOPERATION_REPLACE)
      render.SetStencilPassOperation(STENCILOPERATION_REPLACE)
      render.SetStencilWriteMask(1) --No interfearance!
      render.SetStencilReferenceValue(2) 
         --ALL PIXELS: refvalue = 2
         render.SetMaterial(mWhite)
         render.DrawScreenQuad()

      render.SetStencilReferenceValue(1)
         --Just the circle poly: revalue = 1
         surface.SetMaterial(mWhite)
         local polyStruct = generateCircle(x + 64, y + 64, 62, 30)
         surface.DrawPoly(polyStruct)
   render.SetStencilEnable(false) -- We're done here.

   render.SetRenderTarget(renderTarget) -- Revert back, again.
   
   mCopy:SetTexture("$basetexture", rtSave1) -- We want to draw the original view again, the stuff above was purely for saving to textures
   render.SetMaterial(mCopy)
   render.DrawScreenQuad()


   --Time to draw the inner-circle shit
   render.SetStencilEnable(true)
      render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_EQUAL)
      render.SetStencilPassOperation(STENCILOPERATION_REPLACE)
      render.SetStencilReferenceValue(1)
      render.SetStencilWriteMask(0);
      render.SetStencilTestMask(1); -- Only write to the pixels with a reference value of 1 (with our bitmask!)

         mCopy:SetTexture("$basetexture", rtSave) -- Write our saved "juice shit" texture to the screen!
         render.SetMaterial(mCopy)
         render.DrawScreenQuad() -- DRAW! :D

      render.ClearStencil() -- Cleanup, we don't want other shitty mod editors to have to deal with our shit because i'm a nice coder.
   render.SetStencilEnable(false) --Goodbye stencils
   render.OverrideDepthEnable( false, false ) -- Our complicated rendering is over, cleanup depth


   --All this shit defines the color for the "+" medic symbol, then draws it
   local red = math.max(0, math.sin(RealTime()*5)*100)
   if (client:Health() <= 25 and client:Health() > 0) then
      surface.SetDrawColor(Color(155+red, 155-red, 155-red))
   else
      surface.SetDrawColor(COLOR_WHITE)
   end   
   surface.SetMaterial(mMedic) --Drawing it
   surface.DrawTexturedRect(x, y-8, 128, 128)


   --Draw our pretty border black ring :D
   surface.SetDrawColor(Color(0, 0, 0))
   surface.SetMaterial(mRing)
   surface.DrawTexturedRect(x, y, 128, 128)


   /* DONE WITH JUICE CIRLCE, PHEW */





   // Ammo
   if (client:Alive()) then
      local ammo_clip, ammo_max, ammo_inv = GetAmmo(client)
      if ammo_clip != -1 then
         surface.SetDrawColor(Color(175, 125, 50, 255))
         if ((380 - 64 - pad*2 - 32)*(ammo_clip/ammo_max) >= 6) then
            draw.RoundedBox(6, x + 128 + pad + 32, y + 48 + (80/2 - pad*1.5) + pad*2, (380 - 64 - pad*2 - 32)*(ammo_clip/ammo_max), 80/2 - pad*1.5, Color(175, 125, 50))
         else
            //draw.RoundedBoxEx(6, x + 128 + pad + 32, y + 48 + (80/2 - pad*1.5) + pad*2, (380 - 64 - pad*2 - 32)*(ammo_clip/ammo_max), 80/2 - pad*1.5, Color(175, 125, 50), true, false, true, false)
         end

         local text = string.format("%i + %02i", ammo_clip, ammo_inv)
         draw.SimpleText(text, "Turnpike", x + 128 + pad*2 + 32 + 4, y + 48 + (80/2 - pad*1.5) + pad*2 + 4, COLOR_WHITE, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
      end


      local L = LANG.GetUnsafeLanguageTable()
         
      //Round state

       -- Draw round time
      local is_haste = HasteMode() and round_state == ROUND_ACTIVE
      local is_traitor = client:IsActiveTraitor()  
      local round_state = GAMEMODE.round_state
      local text = "ROUND_STATE"
      if round_state == ROUND_ACTIVE then
         text = L[ client:GetRoleStringRaw() ] or text
      else
         text = L[ roundstate_string[round_state] ] or text
      end 


      /* OVERTIME AND TIME SHIT.. UGH */
      local endtime = GetGlobalFloat("ttt_round_end", 0) - CurTime()
      local timetext

      if is_haste then
         local hastetime = GetGlobalFloat("ttt_haste_end", 0) - CurTime()
         if hastetime < 0 then
            if (not is_traitor) or (math.ceil(CurTime()) % 7 <= 2) then
               timetext = "OVERTIME"
            else
               timetext = util.SimpleTime(math.max(0, endtime), "%02i:%02i")
            end
         else
            local t = hastetime
            if is_traitor and math.ceil(CurTime()) % 6 < 2 then
               t = endtime
            end
            
            timetext = util.SimpleTime(math.max(0, endtime), "%02i:%02i")
         end         
      else
         timetext = util.SimpleTime(math.max(0, endtime), "%02i:%02i")
      end

      text = text.." ("..timetext..")"

      draw.SimpleText(text, "Turnpike", x+124, y+16, COLOR_BLACK, TEXT_ALIGN_LEFT)


      /* DONE OVERTIME AND TIEM SHIT */

      //Health!
      local health = math.max(0, client:Health())
      draw.SimpleText(tostring(health), "Turnpike", x+64, y + 96, COLOR_WHITE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
      local health_status = util.HealthToString(health)
      draw.SimpleText(L[health_status], "Turnpike", x + 128 + pad*2, y + 48 + pad + 4, COLOR_WHITE, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
   end 
end

-- Paints player status HUD element in the bottom left
function GM:HUDPaint()
   local client = LocalPlayer()

   GAMEMODE:HUDDrawTargetID()

   MSTACK:Draw(client)

   if (not client:Alive()) or client:Team() == TEAM_SPEC then
      SpecHUDPaint(client)

      return
   end


   RADAR:Draw(client)
   TBHUD:Draw(client)
   WSWITCH:Draw(client)

   VOICE.Draw(client)
   DISGUISE.Draw(client)

   GAMEMODE:HUDDrawPickupHistory()

   -- Draw bottom left info panel
   InfoPaint(client)
end

-- Hide the standard HUD stuff
local hud = {"CHudHealth", "CHudBattery", "CHudAmmo", "CHudSecondaryAmmo"}
function GM:HUDShouldDraw(name)
   for k, v in pairs(hud) do
      if name == v then return false end
   end

   return true
end

