include( "shared.lua" )

net.Receive( "TurretConfig", function()
	local turret = net.ReadEntity()
	local fireuponisnotfireupon = tobool(net.ReadString())
	local fireuponlist = net.ReadTable()
	local guardingprop = tobool(net.ReadString())
	
	local Frame = vgui.Create( "DFrame" )
	Frame:SetSize(400,250)
	Frame:Center()
	Frame:SetTitle("Turret Configuration")
	Frame:SetDraggable(false)
	Frame:MakePopup()
	Frame.Paint = function(self)
		draw.RoundedBox( 4, 0, 0, self:GetWide(), self:GetTall(), Color(0,0,0,200) )
		draw.RoundedBoxEx( 4, 0, 0, self:GetWide(), 25, Color(0,0,0,150), true, true )
		draw.DrawText( "Ammo: "..turret.dt.ammo.."/255", "Trebuchet18", 20, 30, Color(255,255,255,150) )
	end
	
	local FireUponIsNotFireUpon = vgui.Create( "DCheckBoxLabel", Frame )
	FireUponIsNotFireUpon:SetPos(10,60)
	FireUponIsNotFireUpon:SetText( "\"Fire Upon\" is \"Don't Fire Upon\"" )
	FireUponIsNotFireUpon:SetValue(0)
	FireUponIsNotFireUpon:SizeToContents()
	
	FireUponIsNotFireUpon.OnChange = function(self,value)
		net.Start( "SetConfig" )
			net.WriteEntity( turret )
			net.WriteString( "fireuponisnotfireupon" )
			net.WriteString( tostring(value) )
		net.SendToServer()
	end
	
	if fireuponisnotfireupon then
		FireUponIsNotFireUpon:SetValue(1)
	end
	
	local FireUponList = vgui.Create( "DPanelList", Frame )
	FireUponList:EnableVerticalScrollbar(true)
	FireUponList:SetSize(150,Frame:GetTall()-60)
	FireUponList:SetPos(Frame:GetWide()-FireUponList:GetWide()-10,30)
	FireUponList.Paint = function(self)
		draw.RoundedBoxEx( 4, 0, 0, self:GetWide(), self:GetTall(), Color(255,255,255,255), true, true )
	end
	
	FireUponList.BuildList = function()
		for k, v in pairs( FireUponList:GetItems() ) do
			FireUponList:RemoveItem(v)
		end
		
		local FireUponHeader = vgui.Create( "DPanel" )
		FireUponHeader:SetSize(FireUponList:GetWide(),20)
		FireUponHeader.Paint = function(self)
			draw.RoundedBoxEx( 4, 0, 0, self:GetWide(), self:GetTall(), Color(200,200,200,200), true, true )
			
			if FireUponIsNotFireUpon:GetChecked() then
				draw.DrawText( "Don't Fire Upon", "Trebuchet18", self:GetWide()/2, 2, Color(0,0,0,200), TEXT_ALIGN_CENTER )
			else
				draw.DrawText( "Fire Upon", "Trebuchet18", self:GetWide()/2, 2, Color(0,0,0,200), TEXT_ALIGN_CENTER )
			end
		end
		
		FireUponList:AddItem(FireUponHeader)
		
		for k, v in pairs( fireuponlist ) do
			if IsValid(v) then
				local FireUponPlayer = vgui.Create( "DPanel" )
				FireUponPlayer:SetSize(FireUponList:GetWide(),20)
				FireUponPlayer.Paint = function(self)
					if !IsValid(v) then return end
					
					draw.DrawText( v:Name(), "Trebuchet18", 5, 2, Color(0,0,0,200) )
				end
				
				FireUponList:AddItem(FireUponPlayer)
			end
		end
	end
	
	FireUponList:BuildList()
	
	local AddFireUponButton = vgui.Create( "DButton", Frame )
	AddFireUponButton:SetSize(150,20)
	AddFireUponButton:SetText("Add / Remove Player")
	AddFireUponButton:SetPos(Frame:GetWide()-AddFireUponButton:GetWide()-10,FireUponList:GetTall()+30)
	AddFireUponButton.Paint = function(self)
		draw.RoundedBoxEx( 4, 0, 0, AddFireUponButton:GetWide(), AddFireUponButton:GetTall(), Color(255,255,255,255), false, false, true, true )
		draw.RoundedBoxEx( 4, 0, 0, AddFireUponButton:GetWide(), AddFireUponButton:GetTall(), Color(200,200,200,200), false, false, true, true )
	end
	
	local function AddToList( ply )
		if !IsValid(ply) then return end
		
		if table.HasValue( fireuponlist, ply ) then
			table.remove( fireuponlist, table.KeyFromValue( fireuponlist, ply ) )
		else
			table.insert( fireuponlist, ply )
		end
		
		FireUponList:BuildList()
		
		net.Start( "SetConfig" )
			net.WriteEntity( turret )
			net.WriteString( "fireuponlist" )
			net.WriteTable( fireuponlist )
		net.SendToServer()
	end
	
	AddFireUponButton.DoClick = function(self)
		local Menu = DermaMenu()
		
		for k, v in pairs( player.GetAll() ) do
			if v != LocalPlayer() then
				if !table.HasValue( fireuponlist, v ) then
					Menu:AddOption( v:GetName(), function() AddToList(v) end ):SetIcon( "icon16/add.png" )
				else
					Menu:AddOption( v:GetName(), function() AddToList(v) end ):SetIcon("icon16/delete.png")
				end
			end
		end
		
		Menu:Open()
	end
	
	local GuardingProp = vgui.Create( "DCheckBoxLabel", Frame )
	GuardingProp:SetPos(10,90)
	GuardingProp:SetText( "Guarding Prop" )
	GuardingProp:SetValue(0)
	GuardingProp:SizeToContents()
	
	GuardingProp.OnChange = function(self,value)
		net.Start( "SetConfig" )
			net.WriteEntity( turret )
			net.WriteString( "guardingprop" )
			net.WriteString( tostring(value) )
		net.SendToServer()
	end
	
	if guardingprop then
		GuardingProp:SetValue(1)
	end
	
	local ClearGuardProp = vgui.Create( "DButton", Frame )
	ClearGuardProp:SetPos(15,130)
	ClearGuardProp:SetSize(75,17)
	ClearGuardProp:SetText("Clear Guard")
	ClearGuardProp.Paint = function(self)
		draw.RoundedBox( 4, 0, 0, self:GetWide(), self:GetTall(), Color(255,255,255,255) )
		draw.RoundedBox( 4, 0, 0, self:GetWide(), self:GetTall(), Color(200,200,200,200) )
	end
	
	ClearGuardProp.DoClick = function()
		net.Start( "SetConfig" )
			net.WriteEntity( turret )
			net.WriteString( "guardingprop" )
			net.WriteEntity( nil )
		net.SendToServer()
	end
	
	local SetGuardProp = vgui.Create( "DButton", Frame )
	SetGuardProp:SetPos(15,110)
	SetGuardProp:SetSize(75,17)
	SetGuardProp:SetText("Set to Guard")
	SetGuardProp.Paint = function(self)
		draw.RoundedBox( 4, 0, 0, self:GetWide(), self:GetTall(), Color(255,255,255,255) )
		draw.RoundedBox( 4, 0, 0, self:GetWide(), self:GetTall(), Color(200,200,200,200) )
	end
	
	SetGuardProp.DoClick = function()
		Frame:Hide()
		
		GAMEMODE:AddNotify( "Press 'E' while looking at a prop to guard", 0, 6 )
		hook.Add( "KeyPress", tostring(turret:EntIndex()).."_SetGuard", function( ply, key )
			if ply != LocalPlayer() then return end
			
			if key == IN_USE and ply:GetEyeTrace().Entity:GetClass() == "prop_physics" then
				if ply:GetEyeTrace().Entity:GetPos():Distance(turret:GetPos()) < 200 then
					hook.Remove( "KeyPress", tostring(turret:EntIndex().."_SetGuard" ) )
					GAMEMODE:AddNotify( "Your turret is now guarding this prop", 0, 6 )
					
					net.Start( "SetConfig" )
						net.WriteEntity( turret )
						net.WriteString( "guardprop" )
						net.WriteEntity( ply:GetEyeTrace().Entity )
					net.SendToServer()
				else
					GAMEMODE:AddNotify( "This prop is too far away to guard", 0, 6 )
				end
			end
		end)
	end
end)