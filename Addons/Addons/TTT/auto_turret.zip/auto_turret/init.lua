include( "shared.lua" )

AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )

util.AddNetworkString( "SetConfig" )
util.AddNetworkString( "TurretConfig" )

function ENT:Initialize()
	self:SetModel( "models/props_c17/TrapPropeller_Engine.mdl" )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetUseType( SIMPLE_USE )
	self:SetRenderMode( RENDERGROUP_BOTH )
	self:SetHealth(255)
	self:DropToFloor()
	
	self.dt.ammo = 50
	self.fireuponisnotfireupon = false
	self.fireuponlist = {}
	self.guardingprop = false
	
	self.Turret = ents.Create( "prop_dynamic_override" )
	self.Turret:SetParent(self)
	self.Turret:SetModel("models/weapons/w_smg1.mdl")
	self.Turret:SetPos(self:GetPos()+self:GetAngles():Up()*20)
	self.Turret:SetRenderMode( RENDERGROUP_BOTH )
	self.Turret:Spawn()
	
	local phys = self:GetPhysicsObject()
	if IsValid(phys) then
		phys:EnableMotion(false)
	end
	
	
end

function ENT:OnRemove()
	if IsValid(self.Turret) then
		self.Turret:Remove()
	end
	
	local effect = EffectData()
	effect:SetStart(self:GetPos())
	effect:SetOrigin(self:GetPos())
	effect:SetScale(1)
	
	util.Effect("Explosion",effect)
end

function ENT:Think()
	self.Turret:SetColor(Color(255,self.dt.ammo,self.dt.ammo,255))
	self:SetColor(Color(255,self:Health(),self:Health(),255))
	
	self:DropToFloor()
	
	if self.dt.ammo <= 0 or ( self.NextFire and self.NextFire >= CurTime() ) then return end
	self.NextFire = CurTime()+0.25
	
	local target
	
	if self.guardingprop then
		if !IsValid(self.guardprop) then return end
		if self.guardprop:GetPos():Distance(self:GetPos()) > 200 then return end
		
		local min, max = self.guardprop:GetCollisionBounds()
		
		for k, v in pairs( ents.FindInBox(self.guardprop:GetPos() + min*1.25,self.guardprop:GetPos() + max*1.25) ) do
			if v:IsPlayer() and v!= self.dt.owning_ent then
				if (table.HasValue(self.fireuponlist,v) and !self.fireuponisnotfireupon) or (!table.HasValue(self.fireuponlist,v) and self.fireuponisnotfireupon) then
					local nofire = false
					for k, spawn in pairs( ents.FindByClass("info_player_start") ) do
						if spawn:GetPos():Distance(v:GetPos()) < 100 then
							nofire = true
						end
					end
					
					local min, max = v:GetCollisionBounds()
					
					local tracedata = {}
					tracedata.start = self.Turret:GetPos()
					tracedata.endpos = v:GetPos()+v:GetAngles():Up()*(max.z/2)
					tracedata.filter = self.Turret
					local trace = util.TraceLine(tracedata)
					
					if trace.Entity == v and !nofire then
						target = v
					end
				end
			end
		end
	else
		for k, v in pairs( ents.FindInSphere( self:GetPos(), 200 ) ) do
			if v:IsPlayer() and v != self.dt.owning_ent then
				if (table.HasValue(self.fireuponlist,v) and !self.fireuponisnotfireupon) or (!table.HasValue(self.fireuponlist,v) and self.fireuponisnotfireupon) then
					if !IsValid(target) or v:GetPos():Distance(self:GetPos()) < target:GetPos():Distance(self:GetPos()) then
						local nofire = false
						for k, spawn in pairs( ents.FindByClass("info_player_start") ) do
							if spawn:GetPos():Distance(v:GetPos()) < 100 then
								nofire = true
							end
						end
						
						local min, max = v:GetCollisionBounds()
						
						local tracedata = {}
						tracedata.start = self.Turret:GetPos()
						tracedata.endpos = v:GetPos()+v:GetAngles():Up()*(max.z/2)
						tracedata.filter = self.Turret
						local trace = util.TraceLine(tracedata)
						
						if trace.Entity == v and !nofire then
							target = v
						end
					end
				end
			end
		end
	end
	
	if !IsValid(target) then return end
	
	local min, max = target:GetCollisionBounds()
	self.Turret:SetAngles( ( (target:GetPos()+target:GetAngles():Up()*(max.z/2)) - self.Turret:GetPos()):Angle() )
	
	local bullet = {}
	bullet.Num = 1
	bullet.Src = self.Turret:GetPos()
	bullet.Dir = self.Turret:GetAngles():Forward()
	bullet.Spread = Vector(0.05,0.05,0)
	bullet.Tracer = 1
	bullet.Force = 2
	bullet.Damage = 5
	
	self.Turret:FireBullets( bullet )
	self.dt.ammo = self.dt.ammo - 1
end

function ENT:AcceptInput( name, activator, caller )
	if activator == self.dt.owning_ent then
		net.Start( "TurretConfig" )
			net.WriteEntity( self )
			net.WriteString( tostring(self.fireuponisnotfireupon) )
			net.WriteTable( self.fireuponlist )
			net.WriteString( tostring(self.guardingprop) )
		net.Send( activator )
	end
end

function ENT:Touch( ent )
	if self.dt.ammo >= 255 then return end
	
	if ent:GetClass() == "spawned_weapon" and !ent.weaponclass then
		for k, v in pairs( GAMEMODE.AmmoTypes ) do
			if v.ammoType == "smg1" and string.lower(ent:GetModel()) == string.lower(v.model) then
				ent:Remove()
				self.dt.ammo = math.Clamp( self.dt.ammo + v.amountGiven, 0, 255 )
				
				break
			end
		end
	end
end

function ENT:OnTakeDamage( dmginfo )
	self:SetHealth( self:Health()-dmginfo:GetDamage() )
	if self:Health() <= 0 then
		self:Remove()
	end
end

net.Receive( "SetConfig", function( len, ply )
	local turret = net.ReadEntity()
	
	if !IsValid(turret) then return end
	if turret:GetClass() != "auto_turret" then return end
	
	if turret.dt.owning_ent != ply then return end
	
	local config = net.ReadString()
	
	if config == "fireuponisnotfireupon" then
		turret.fireuponisnotfireupon = tobool(net.ReadString())
	elseif config == "fireuponlist" then
		turret.fireuponlist = net.ReadTable()
	elseif config == "guardingprop" then
		turret.guardingprop = tobool(net.ReadString())
	elseif config == "guardprop" then
		local prop = net.ReadEntity()
		
		if !IsValid(prop) then
			turret.guardprop = nil
			
			return
		end
		
		if prop:GetPos():Distance(turret:GetPos()) > 200 then return end
		
		turret.guardprop = prop
	end
end)