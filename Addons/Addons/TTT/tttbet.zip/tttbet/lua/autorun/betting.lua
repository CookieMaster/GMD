------- Team betting system 1.0 -------
AddCSLuaFile( "betconfig.lua" )

local Player = FindMetaTable("Player")



if SERVER then
	 
	function GambleRequest( ply )
			if ply:GetPData("youbet") == 1 then return end
			if ply:SetNWInt("bettime") == 1 then return end
			if GetRoundState() != ROUND_ACTIVE then return end
				
				teamname = ply:GetPData("TeamBet")
				ply.BetAmount = tonumber( ply:GetPData("betammount"))
				PlyPoints = tonumber(ply:PS_GetPoints())
					if PlyPoints < ply.BetAmount then
						ply:PS_Notify(" you need more points ")
						ply:SetPData("youbet", 0)
						ply:SetNWInt("youbet", 0)
						ply:SetPData("TeamBet", "none")
						ply:SetPData("betammount", 0)
						ply:SetNWInt("youbet", 0)
						ply:SetNWString("TeamBet", "none")
						ply:SetNWInt("betammount", 0)
					end
					if PlyPoints >= ply.BetAmount then
						if ply.BetAmount <= maximumbet then
	
							ply:SetPData("youbet", 1)
							ply:SetNWInt("youbet", 1)
							ply:SetNWInt("bettime", 1)
							ply:PS_TakePoints( ply.BetAmount )
							ply:PS_Notify(" you bet " ..ply.BetAmount.. " on " ..teamname.. " to win!" )
							if ply:GetNWString("TeamBet") == "Traitor" then
								SetGlobalInt("traitorbet",GetGlobalInt("traitorbet")+1)
							elseif ply:GetNWString("TeamBet") == "Innocent" then
								SetGlobalInt("innobet",GetGlobalInt("innobet")+1)
							end	
						else	
							ply:PS_Notify("Max bet is "..maximumbet.." !")
							ply:PS_Notify("Please bet again.")							
							ply:SetPData("youbet", 0)
							ply:SetNWInt("youbet", 0)
							ply:SetPData("TeamBet", "none")
							ply:SetPData("betammount", 0)
							ply:SetNWInt("youbet", 0)
							ply:SetNWString("TeamBet", "none")
							ply:SetNWInt("betammount", 0)
						end
					end

	end
		concommand.Add("GambleRequest", GambleRequest)

		function GamblePrizes( wintype )

			
			for k,v in pairs( player.GetAll() ) do

				if v:GetPData("youbet") == 0 then return end
					if wintype == WIN_INNOCENT or wintype == WIN_TIMELIMIT then
						if (v:GetPData("TeamBet") == "Innocent" ) then
							if wintyp == "odds" then
								if gettrcount() < 1 then
									v:PS_GivePoints( ( v:GetPData("betammount" )* 1))
									v:PS_Notify(" You got "..tonumber( v:GetPData("betammount" )* 1).." back.")
								else
									v:PS_GivePoints( ( v:GetPData("betammount" )* getincount()))
									v:PS_Notify(" You won "..tonumber( v:GetPData("betammount" )* getincount()).." !")
								end
							elseif wintyp == "percent" then
								v:PS_GivePoints( ( v:GetPData("betammount" )* winper))
								v:PS_Notify(" You won "..tonumber( v:GetPData("betammount" )* winper).." !")
							end					
						elseif (v:GetPData("TeamBet") == "Traitor" ) then
							v:PS_Notify(" You lost "..tonumber( v:GetPData("betammount" )).." points!")
						end
				elseif wintype == WIN_TRAITOR then 
						if v:GetPData("TeamBet") == "Traitor" then
							if wintyp == "odds" then
								if getincount() < 1 then
									v:PS_GivePoints( ( v:GetPData("betammount" )* 1))
									v:PS_Notify(" You got "..tonumber( v:GetPData("betammount" )* 1).." back.")
								else
									v:PS_GivePoints( ( v:GetPData("betammount" )* gettrcount()))
									v:PS_Notify(" You won "..tonumber( v:GetPData("betammount" )* gettrcount()).." !")
								end
							elseif wintyp == "percent" then
								v:PS_GivePoints( ( v:GetPData("betammount" )* winper))
								v:PS_Notify(" You won "..tonumber( v:GetPData("betammount" )* winper).." !")
							end					
						
						elseif (v:GetPData("TeamBet") == "Innocent" ) then
							v:PS_Notify(" You lost "..tonumber( v:GetPData("betammount" )).." points!")
						end
				end
					
			
			end
			
			BetPrizesGiven = true
		end
		
		hook.Add( "TTTEndRound", "GambleShit", GamblePrizes )
		function ResetPrizesGiven()

			BetPrizesGiven = false
			for k,v in pairs( player.GetAll() ) do
				v:SetPData("youbet", 0)
				v:SetPData("TeamBet", "none")
				v:SetPData("betammount", 0)
				v:SetNWInt("youbet", 0)
				v:SetNWString("TeamBet", "none")
				v:SetNWInt("betammount", 0)
				v:SetNWInt("bettime", 0)
				SetGlobalInt("traitorbet", 0 )
				SetGlobalInt("innobet", 0 )

			end
			Msg( "A new round has started and all the betting system is reset. \n" )
		end
		hook.Add( "TTTBeginRound", "ResetPrizesGiven", ResetPrizesGiven )
		
		


function PlayerBet( ply, _, args )

		ply:SetPData("betammount", args[1])
		ply:SetNWInt("betammount", args[1])
end

concommand.Add( "PlayerBet", PlayerBet )

function TraitorBet(ply, _, Traitor)
	ply:SetPData( "TeamBet", "Traitor" )
	ply:SetNWString( "TeamBet", "Traitor" )

end
concommand.Add( "TraitorBet", TraitorBet )
function InnoBet(ply, _, Innocent)
	ply:SetPData( "TeamBet", "Innocent" )
	ply:SetNWString( "TeamBet", "Innocent" )

end

concommand.Add( "InnoBet", InnoBet )



end
if CLIENT then


		function betting()
			local BettingPanel = vgui.Create( "DFrame" )
			--BettingPanel:SetPos( 500,200 )
			BettingPanel:Center()
			BettingPanel:SetSize( 200, 200 )
			BettingPanel:SetTitle( "Betting panel" )
			BettingPanel:SetVisible( true )
			BettingPanel:SetDraggable( true )
			BettingPanel:ShowCloseButton( false)
			BettingPanel.Paint = function() draw.RoundedBox(4,0,0,BettingPanel:GetWide(),BettingPanel:GetTall(),Color(0,0,0,200)) end
			BettingPanel:MakePopup()
			local CloseButton = vgui.Create( "DButton", BettingPanel )
			CloseButton:SetText( "X" )
			CloseButton:SetPos( 185, 5)
			CloseButton:SetSize( 12, 13 )
			CloseButton.DoClick = function ()
				if IsValid(CloseButton ) then
					BettingPanel:SetVisible( false )
				end
			end
			local TeamSheet = vgui.Create( "DPanel", BettingPanel ) 
			TeamSheet:SetPos( 0, 0 )
			TeamSheet:SetSize( BettingPanel:GetWide() - 25, BettingPanel:GetTall() - 25 )
			TeamSheet:SetVisible( true )

			TeamSheet.Paint = function()
			local SomeMessage = "What team you betting on?" 
			surface.SetFont( "default" )
			surface.SetTextColor( 255, 255, 255, 255 )
			surface.SetTextPos( 35, 30 )
			surface.DrawText( SomeMessage )
			
			end
			
			local BettingSheet = vgui.Create( "DPanel", BettingPanel ) 
			BettingSheet:SetPos( 0, 0 )
			BettingSheet:SetSize( BettingPanel:GetWide() - 25, BettingPanel:GetTall() - 25 )
			BettingSheet:SetVisible( false )

			BettingSheet.Paint = function()
			local SomeMessage = "How much will you bet?" 
			surface.SetFont( "default" )
			surface.SetTextColor( 255, 255, 255, 255 )
			surface.SetTextPos( 45, 30 )
			surface.DrawText( SomeMessage )
			
			end
			ConBox = vgui.Create("DTextEntry", BettingPanel)
			ConBox:SetPos(60, 100)  -- position of the box on the frame x , y
			ConBox:SetSize(80, 20) -- size of the box
			ConBox:SetVisible( false )
			ConBox:SetNumeric(true)
			----------------------------------------------------------------------------------------------------------
			SubmitPoints = vgui.Create("DButton", BettingPanel)  
			SubmitPoints:SetPos(75, 120)  -- position of the button on the frame
		   	SubmitPoints:SetSize(50, 30)  -- size of the button
			SubmitPoints:SetVisible( false )
		   	SubmitPoints:SetText("Bet")  -- text on the button
		   	SubmitPoints.DoClick = function () -- what happens when you click the button
				if ConBox:GetValue() >= "1" then
						if LocalPlayer():GetNWInt("bettime") != 1 then 
					
								BettingPanel:SetVisible( false )
								RunConsoleCommand("PlayerBet", ConBox:GetValue())
								RunConsoleCommand("GambleRequest")

						end
					
						
				
				end
			end
			-------------------------------------------------------------------------------------------------------------
			DermaImage = vgui.Create( "DImageButton", BettingPanel )
			DermaImage:SetPos( 100, 100 )
			DermaImage:SetImage( "VGUI/ttt/icon_traitor.vmt" ) -- Set your .vtf image
			DermaImage:SetSize( 50, 50 )
			DermaImage.DoClick = function ()
				if LocalPlayer():GetNWInt("bettime") != 1 then
					DermaImage:SetVisible( true )
					DermaImageI:SetVisible( false )
					DermaImage:SetPos( 75, 50 )
					TeamSheet:SetVisible( false )
					SubmitPoints:SetVisible( true )
					BettingSheet:SetVisible( true )
					ConBox:SetVisible( true )
					RunConsoleCommand("TraitorBet")
				end
			end	
			DermaImageI = vgui.Create( "DImageButton", BettingPanel )
			DermaImageI:SetPos( 50, 100 )
			DermaImageI:SetImage( "VGUI/ttt/icon_inno.vmt" ) -- Set your .vtf image
			DermaImageI:SetSize( 50, 50 )
			DermaImageI.DoClick = function ()
				if LocalPlayer():GetNWInt("bettime") != 1 then
					DermaImageI:SetVisible( true )
					DermaImageI:SetPos( 75, 50 )
					DermaImage:SetVisible( false )
					TeamSheet:SetVisible( false )
					SubmitPoints:SetVisible( true )
					BettingSheet:SetVisible( true )
					ConBox:SetVisible( true )
					RunConsoleCommand("InnoBet")
				end
			end
		end
	

	local teambetT = (GetGlobalInt("traitorbet") - GetGlobalInt("innobet"))
	local teambetI = (GetGlobalInt("innobet") - GetGlobalInt("traitorbet")) 

concommand.Add("zzz", betting)

end
	
function PlayerSaid( ply, txt)

	plyCount = table.Count(player.GetAll())   
		
	if plyCount < pcount then return end
		if(ply:IsValid() and txt:sub(1, 4) == "!bet") then
			if ply:IsSpec() then
				if ply:GetNWInt("youbet") == 1 or ply:GetNWInt("bettime") == 1 then return end
					if GetRoundState() == ROUND_ACTIVE then
						ply:ConCommand("zzz")
						return(false)
					end
				
			end
		end
	
end
hook.Add( "PlayerSay", "PlayerSaid", PlayerSaid )

	hook.Add( "TTTBeginRound", "TTTbettimer", function()
        timer.Create("TTTbettimer",timebet, 1, function()
			for k,v in pairs(player.GetAll()) do
				if v:GetNWInt("youbet") == 0 then
					v:SetNWInt("bettime", 1)
				end
			end
        end)
	end )
	
	function getincount()
		incount = 0
		for k, v in pairs(player.GetAll()) do
			if v:GetNWString("TeamBet") == "Innocent" then
				incount = incount+1
			end
		end
		return tonumber(incount)
	end	
	
	function gettrcount()
		trcount = 0
		for k, v in pairs(player.GetAll()) do
			if v:GetNWString("TeamBet") == "Traitor" then
				trcount = trcount+1
			end
		end
		return tonumber(trcount)
	end		
		
