
wintyp = "percent" -- odds or percent , just replace inside ""
winper = 2 -- what percent they win.
pcount = 1 -- least ammount of people needed.
timebet = 350 -- time in seconds after round starts for betting to close.
maximumbet = 5000 -- max points that can be bet at a time.
bethud = "on" -- Set hud on or off by placing on or off in ""
