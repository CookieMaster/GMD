CATEGORY.Name = 'Hats, Heads and Masks'
CATEGORY.Icon = 'emoticon_smile'
CATEGORY.AllowedEquipped = 2
CATEGORY.Desc = "Hats to wear!"
CATEGORY.BackgroundColor = Color( 96, 169, 23, 255 )