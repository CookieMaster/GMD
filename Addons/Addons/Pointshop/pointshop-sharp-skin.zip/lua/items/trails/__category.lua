CATEGORY.Name = 'Trails'
CATEGORY.Icon = 'rainbow'
CATEGORY.Desc = "Trails behind you!"
CATEGORY.BackgroundColor = Color( 244, 114, 208, 255 )