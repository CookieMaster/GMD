CATEGORY.Name = 'Powerups'
CATEGORY.Icon = 'star'
CATEGORY.Desc = "Various powerups."
CATEGORY.BackgroundColor = Color( 240, 163, 10, 255 )