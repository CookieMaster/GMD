CATEGORY.Name = 'Accessories'
CATEGORY.Icon = 'add'
CATEGORY.Desc = "Miscelaneous accessories for your player."
CATEGORY.BackgroundColor = Color( 118, 96, 138, 255 )