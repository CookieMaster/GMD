CATEGORY.Name = 'Player Models'
CATEGORY.Icon = 'user'
CATEGORY.Desc = "Change your player's model!"
CATEGORY.BackgroundColor = Color( 130, 90, 44, 255 )
