CATEGORY.Name = 'Followers'
CATEGORY.Icon = 'emoticon_smile'
CATEGORY.AllowedEquipped = 1
CATEGORY.Order = 1
CATEGORY.Desc = "Models following you around!"
CATEGORY.BackgroundColor = Color( 150, 150, 150, 255 )