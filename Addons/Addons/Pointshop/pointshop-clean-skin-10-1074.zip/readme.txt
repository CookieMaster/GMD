To install:
	Take all the files in the folder name clean_skin and replace them with the files in your pointshop
	under lua/vgui.
	
	If you want to change the color of the purple top bar, open DPointShopMenu and change the color of the
	first 2 lines at the top.

	If you want to use the diamond mask for player avatar then you can go to line 469 and change PointshopMaskCircle
	to PointshopMaskDiamond. 