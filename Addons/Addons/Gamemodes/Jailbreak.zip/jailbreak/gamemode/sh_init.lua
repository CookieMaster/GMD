-- Code is ripped from PrisonBreak2, a gamemode by NewBee

JB = GM; -- rather than calling gmod.GetGamemode() 100 times;

JB.Name = "JailBreak";
JB.Author = "_NewBee (Excl), Clark (Aide)";
JB.Version = "ALPHA 1";
JB.util = {}
JB.debug = true;

--Debugprinting
function JB:DebugPrint(...)
	if not JB.debug then return end
	
	Msg("["..JB.Name.." debug] "); print(...);
end
JB:DebugPrint("Initializing "..JB.Name..", a _NewBee gamemode.")
JB:DebugPrint("Created by "..JB.Author.."; version "..JB.Version);


local function JBInclude(file, folder, run)
	local p = run or "sh";
	if string.Left(file, 2) and (not run) then p = string.Left(file, 2) end	
	if p == "sh" then
		JB:DebugPrint("Including file: "..folder..file);
		include(folder..file);
		if SERVER then
			AddCSLuaFile(folder..file);
		end
	elseif p == "sv" and SERVER then
		JB:DebugPrint("Including file: "..folder..file);
		include(folder..file);
	elseif p == "cl" then
		if CLIENT then
			JB:DebugPrint("Including file: "..folder..file);
			include(folder..file);
		elseif SERVER then
			AddCSLuaFile(folder..file);
		end
	end
end



--Automate including
local function JBInitVGUI()
	for k,v in pairs(file.Find("JailBreak/gamemode/vgui/*.lua","LUA" )) do
		JBInclude(v, "vgui/", "cl");
	end
end

local function JBInitUtil()
	for k,v in pairs(file.Find("JailBreak/gamemode/util/*.lua","LUA" )) do
		JBInclude(v, "util/");
	end
end

--In strict order :3
JBInitUtil();
JBInitVGUI();

if SERVER then

	AddCSLuaFile("core/sh_characters.lua")
	AddCSLuaFile("core/sh_entity_meta.lua")
	AddCSLuaFile("core/sh_guardprops.lua")
	AddCSLuaFile("core/sh_hooks.lua")
	AddCSLuaFile("core/sh_lastrequests.lua")
	AddCSLuaFile("core/sh_lastrequests_core.lua")
	AddCSLuaFile("core/sh_player_meta.lua")
	AddCSLuaFile("core/sh_quickcommands.lua")
	AddCSLuaFile("core/sh_rounds.lua")
	AddCSLuaFile("core/sh_spawnmenupos.lua")
	AddCSLuaFile("core/sh_teams.lua")

	AddCSLuaFile("core/cl_helpmenu.lua")
	AddCSLuaFile("core/cl_hud.lua")
	AddCSLuaFile("core/cl_mapvotes.lua")
	AddCSLuaFile("core/cl_notifications.lua")
	AddCSLuaFile("core/cl_objectives.lua")
	AddCSLuaFile("core/cl_panels.lua")
	AddCSLuaFile("core/cl_player_hooks.lua")
	AddCSLuaFile("core/cl_quickcommand.lua")
	AddCSLuaFile("core/cl_scoreboard.lua")
	AddCSLuaFile("core/cl_spawnmenu.lua")
	AddCSLuaFile("core/cl_spectators.lua")
	AddCSLuaFile("core/cl_teamchangemenu.lua")
	AddCSLuaFile("core/cl_warden.lua")
	AddCSLuaFile("core/cl_weapondrawing.lua")
	AddCSLuaFile("core/cl_weaponselection.lua")
	
	include("core/sv_console.lua")
	include("core/sv_hooks.lua")
	include("core/sv_mapconfig.lua")
	include("core/sv_mapvotes.lua")
	include("core/sv_player_cmds.lua")
	include("core/sv_player_hooks.lua")
	include("core/sv_player_meta.lua")
	include("core/sv_resource.lua")
	include("core/sv_warden.lua")

end
include("core/sh_characters.lua")
include("core/sh_entity_meta.lua")
include("core/sh_guardprops.lua")
include("core/sh_hooks.lua")
include("core/sh_lastrequests.lua")
include("core/sh_lastrequests_core.lua")
include("core/sh_player_meta.lua")
include("core/sh_quickcommands.lua")
include("core/sh_rounds.lua")
include("core/sh_spawnmenupos.lua")
include("core/sh_teams.lua")
if CLIENT then

	include("core/cl_helpmenu.lua")
	include("core/cl_hud.lua")
	include("core/cl_mapvotes.lua")
	include("core/cl_notifications.lua")
	include("core/cl_objectives.lua")
	include("core/cl_panels.lua")
	include("core/cl_player_hooks.lua")
	include("core/cl_quickcommand.lua")
	include("core/cl_scoreboard.lua")
	include("core/cl_spawnmenu.lua")
	include("core/cl_spectators.lua")
	include("core/cl_teamchangemenu.lua")
	include("core/cl_warden.lua")
	include("core/cl_weapondrawing.lua")
	include("core/cl_weaponselection.lua")

end