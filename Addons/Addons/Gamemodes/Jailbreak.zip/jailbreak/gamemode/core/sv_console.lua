-- sv_console

RunConsoleCommand("sv_alltalk", 1);