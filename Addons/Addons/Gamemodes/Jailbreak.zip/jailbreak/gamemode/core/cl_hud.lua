local tblFonts = { }
tblFonts["DebugFixed"] = {
    font = "Courier New",
    size = 10,
    weight = 500,
    antialias = true,
}
 
tblFonts["DebugFixedSmall"] = {
    font = "Courier New",
    size = 7,
    weight = 500,
    antialias = true,
}
 
tblFonts["DefaultFixedOutline"] = {
    font = "Lucida Console",
    size = 10,
    weight = 0,
    outline = true,
}
 
tblFonts["MenuItem"] = {
    font = "Tahoma",
    size = 12,
    weight = 500,
}
 
tblFonts["Default"] = {
    font = "Tahoma",
    size = 13,
    weight = 500,
}
 
tblFonts["TabLarge"] = {
    font = "Tahoma",
    size = 13,
    weight = 700,
    shadow = true,
}
 
tblFonts["DefaultBold"] = {
    font = "Tahoma",
    size = 13,
    weight = 1000,
}
 
tblFonts["DefaultUnderline"] = {
    font = "Tahoma",
    size = 13,
    weight = 500,
    underline = true,
}
 
tblFonts["DefaultSmall"] = {
    font = "Tahoma",
    size = 1,
    weight = 0,
}
 
tblFonts["DefaultSmallDropShadow"] = {
    font = "Tahoma",
    size = 11,
    weight = 0,
    shadow = true,
}
 
tblFonts["DefaultVerySmall"] = {
    font = "Tahoma",
    size = 10,
    weight = 0,
}
 
tblFonts["DefaultLarge"] = {
    font = "Tahoma",
    size = 16,
    weight = 0,
}
 
tblFonts["UiBold"] = {
    font = "Tahoma",
    size = 12,
    weight = 1000,
}
 
tblFonts["MenuLarge"] = {
    font = "Verdana",
    size = 15,
    weight = 600,
    antialias = true,
}
 
tblFonts["ConsoleText"] = {
    font = "Lucida Console",
    size = 10,
    weight = 500,
}
 
tblFonts["Marlett"] = {
    font = "Marlett",
    size = 13,
    weight = 0,
    symbol = true,
}
 
tblFonts["Trebuchet24"] = {
    font = "Trebuchet MS",
    size = 24,
    weight = 900,
}
 
tblFonts["Trebuchet22"] = {
    font = "Trebuchet MS",
    size = 22,
    weight = 900,
}
 
tblFonts["Trebuchet20"] = {
    font = "Trebuchet MS",
    size = 20,
    weight = 900,
}
 
tblFonts["Trebuchet19"] = {
    font = "Trebuchet MS",
    size = 19,
    weight = 900,
}
 
tblFonts["Trebuchet18"] = {
    font = "Trebuchet MS",
    size = 18,
    weight = 900,
}
 
tblFonts["HUDNumber"] = {
    font = "Trebuchet MS",
    size = 40,
    weight = 900,
}
 
tblFonts["HUDNumber1"] = {
    font = "Trebuchet MS",
    size = 41,
    weight = 900,
}
 
tblFonts["HUDNumber2"] = {
    font = "Trebuchet MS",
    size = 42,
    weight = 900,
}
 
tblFonts["HUDNumber3"] = {
    font = "Trebuchet MS",
    size = 43,
    weight = 900,
}
 
tblFonts["HUDNumber4"] = {
    font = "Trebuchet MS",
    size = 44,
    weight = 900,
}
 
tblFonts["HUDNumber5"] = {
    font = "Trebuchet MS",
    size = 45,
    weight = 900,
}
 
tblFonts["HudHintTextLarge"] = {
    font = "Verdana",
    size = 14,
    weight = 1000,
    antialias = true,
    additive = true,
}
 
tblFonts["HudHintTextSmall"] = {
    font = "Verdana",
    size = 11,
    weight = 0,
    antialias = true,
    additive = true,
}
 
tblFonts["CenterPrintText"] = {
    font = "Trebuchet MS",
    size = 18,
    weight = 900,
    antialias = true,
    additive = true,
}
 
tblFonts["DefaultFixed"] = {
    font = "Lucida Console",
    size = 10,
    weight = 0,
}
 
tblFonts["DefaultFixedDropShadow"] = {
    font = "Lucida Console",
    size = 10,
    weight = 0,
    shadow = true,
}
 
tblFonts["CloseCaption_Normal"] = {
    font = "Tahoma",
    size = 16,
    weight = 500,
}
 
tblFonts["CloseCaption_Italic"] = {
    font = "Tahoma",
    size = 16,
    weight = 500,
    italic = true,
}
 
tblFonts["CloseCaption_Bold"] = {
    font = "Tahoma",
    size = 16,
    weight = 900,
}
 
tblFonts["CloseCaption_BoldItalic"] = {
    font = "Tahoma",
    size = 16,
    weight = 900,
    italic = true,
}
 
tblFonts["TargetID"] = {
    font = "Trebuchet MS",
    size = 22,
    weight = 900,
    antialias = true,
}
 
tblFonts["TargetIDSmall"] = {
    font = "Trebuchet MS",
    size = 18,
    weight = 900,
    antialias = true,
}
 
tblFonts["BudgetLabel"] = {
    font = "Courier New",
    size = 14,
    weight = 400,
    outline = true,
}
 
 
for k,v in SortedPairs( tblFonts ) do
    surface.CreateFont( k, tblFonts[k] );
 
    --print( "Added font '"..k.."'" );
end

local nodrawWeps = {"CHudDeathNotice", "CHudHealth", "CHudBattery", "CHudAmmo", "CHudSecondaryAmmo", "CHudCrosshair", "CHudDamageIndicator"}
function JB:HUDShouldDraw(name)
	if table.HasValue(nodrawWeps, name) then
		return false;
	end
	return true;
end


local clamp,sin,cos,rad =math.Clamp,math.sin,math.cos,math.rad;
local deg2rad = math.pi / 180;
local screenpos = Vector( 90, 90, 0 );
local portraitpos = screenpos;
local displayportrait = false;
local pos;
local target;
local ang;
local newpos;
local fov = 85;
local CharacterPortrait;
local h_old = 0;
local h_color = Color(200,0,0);
local x_id = 135;
local y_id = 40;
local x_info = x_id+15;
local y_info = y_id+24;
local x_team,y_team = x_info,y_info + 2;
-- Poly stuff...
local circle = {}
for i=1,15 do
	circle[i] = {x = portraitpos.x + cos(rad(i*360)/15)*60,y = portraitpos.y + sin(rad(i*360)/15)*60};
end

local idpanel = {{x=x_id,y=y_id},{x=x_id+170,y=y_id},{x=x_id+180,y=y_id+10},{x=x_id+180,y=y_id+23},{x=x_id+15,y=y_id+23}}
local idpanel_outline = {{x=x_id-1,y=y_id-1},{x=x_id+170.5,y=y_id-1},{x=x_id+181,y=y_id+9.5},{x=x_id+181,y=y_id+24},{x=x_id+15-2,y=y_id+24}}
local teampanel_outline = {{x=x_team-1,y=y_team-1},{x=x_team+140,y=y_team},{x=x_team+140,y=y_team+10.5},{x=x_team+130,y=y_team+21},{x=x_team,y=y_team+21}}

local ammopanel = {{x=ScrW()-160,y=y_id},{x=ScrW()-40,y=y_id},{x=ScrW()-40,y=y_id+23},{x=ScrW()-170,y=y_id+23},{x=ScrW()-170,y=y_id+10}}
local ammopanel_outline = {{x=ScrW()-160,y=y_id-1},{x=ScrW()-39,y=y_id-1},{x=ScrW()-39,y=y_id+24},{x=ScrW()-171,y=y_id+24},{x=ScrW()-171,y=y_id+10}}

local av = {{x=169,y=89},{x=x_id+180,y=89},{x=x_id+180,y=106},{x=x_id+163,y=123},{x=169,y=123}}
local av_outline = {{x=168,y=88},{x=x_id+181,y=88},{x=x_id+181,y=106},{x=x_id+163,y=124},{x=168,y=124}}

local tri = {{x=ScrW()/2,y=ScrH()/2},{x=ScrW()/2+18,y=ScrH()/2-9},{x=ScrW()/2+18,y=ScrH()/2+9}}
local tri_outline = {{x=ScrW()/2-1,y=ScrH()/2},{x=ScrW()/2+19,y=ScrH()/2-10},{x=ScrW()/2+19,y=ScrH()/2+10}}
local function CreateCharPortrait()
	local m;
	if LocalPlayer() and LocalPlayer():IsValid() then
		m = LocalPlayer():GetModel() or "models/Humans/Group02/Male_04.mdl";
	else
		m = "models/Humans/Group02/Male_04.mdl"
	end
	
	if CharacterPortrait and CharacterPortrait:IsValid() then
		CharacterPortrait:Remove();
	end
	
	CharacterPortrait = ClientsideModel(m, RENDERGROUP_OPAQUE);
	CharacterPortrait:SetNoDraw( true )
	local bone = CharacterPortrait:LookupBone("ValveBiped.Bip01_Head1");

	if bone then
		pos, ang = CharacterPortrait:GetBonePosition( bone )
		local target = CharacterPortrait:GetPos()+Vector(0,0,66)
		local newpos = ang:Forward() * 2 + ang:Right() * 10 + ang:Up() * 13
		pos = target + newpos
		ang = (target-pos):Angle()
		fov = 85
	else
		CharacterPortrait:SetAngles( Angle( 0, 180, 0 ) )
		local mn, mx = CharacterPortrait:GetRenderBounds()
		local size = 0
		size = math.max( size, math.abs(mn.x) + math.abs(mx.x) )
		size = math.max( size, math.abs(mn.y) + math.abs(mx.y) )
		size = math.max( size, math.abs(mn.z) + math.abs(mx.z) )
		size = size * (1 - ( size / 900 ))
		ang = Angle( 25, 40, 0 )
		pos = CharacterPortrait:GetPos() + ang:Forward() * size * -15 + (mn + mx) * 0.5
		fov = 10
	end
end
CreateCharPortrait()
timer.Create( "RefreshPortrait", 5, 0, function()
	CreateCharPortrait()
end)

local function DisplayCharPortrait( bool )
	if bool then
		portraitpos = Vector( Lerp( 0.2, portraitpos.x, screenpos.x ), screenpos.y, screenpos.z )
		for i=1,15 do
			circle[i] = {x = portraitpos.x + cos(rad(i*360)/15)*60,y = portraitpos.y + sin(rad(i*360)/15)*60}
		end
		displayportrait = true
	else
		portraitpos = Vector( Lerp( 0.2, portraitpos.x, -500 ), screenpos.y, screenpos.z )
		if portraitpos.x < 0 then
			displayportrait = false
		end
	end
end


function DrawPartialCircle( x, y, radius, linewidth, startangle, endangle, aa )
	-- Thanks for getting me started on how to do this python1320 <3
    aa = aa or 1;
    startangle = clamp( startangle or 0, 0, 360 );
    endangle = clamp( endangle or 360, 0, 360 );
     
    if endangle < startangle then
        local temp = endangle;
        endangle = startangle;
        startangle = temp;
    end

    for i=startangle, endangle, aa do
        local _i = i * deg2rad;         
        surface.DrawTexturedRectRotated(cos( _i ) * (radius - linewidth) + x,sin( _i ) * (radius - linewidth) + y, linewidth, aa*2, -i );
    end
end

hook.Add( "Think", "JBDisplayPortrait",function()
	local localplayer = LocalPlayer()
	if (localplayer:Team() ~= TEAM_PRISONER and localplayer:Team() ~= TEAM_GUARD) then return end

	DisplayCharPortrait( true );
end)

local wAv;
local awP;

local count = 0;
local count_start = CurTime();
local count_g = 200;
local color_r = 0
local count_cir = 360
local count_title = "No title set."
function JB:HUDStartTimer(t,n)
	count = t;
	count_start = CurTime();
	count_g = 200;
	color_r = 0
	count_cir = 360
	count_title = n;
end
hook.Add("HUDPaint","JBCircleHealthDisplay", function()
	local localplayer = LocalPlayer();
	local w = JB.wardenPlayer;
	if not localplayer or not localplayer:IsValid() or (localplayer:Team() ~= TEAM_PRISONER and localplayer:Team() ~= TEAM_GUARD) then
		if wAv and wAv:IsValid() then
			wAv:Remove();
		end
		 return 
	end
	
	if (not wAv or not wAv:IsValid()) and w and w:IsValid() then
		wAv = vgui.Create("AvatarImage", frame)
		wAv:SetPos(170,90)
		wAv:SetSize(32, 32)
		wAv:SetPlayer(w, 32 )
		awP = w;
	elseif wAv and wAv:IsValid() and (not w or not w:IsValid()) then
		wAv:Remove();
	end

	if awP ~= w and wAv and wAv:IsValid() and w and w:IsValid() then
		wAv:SetPlayer(w,32)
		awP = w;
	end


	surface.SetTexture(surface.GetTextureID("vgui/background_texture"));
    surface.SetDrawColor(0,0,0,255);
    if w and w:IsValid() then
    surface.DrawPoly(av_outline);
	end
	surface.DrawPoly(idpanel_outline);
	surface.DrawPoly(ammopanel_outline);
	surface.DrawRect(ScrW()-171,y_id+23,132,18)
	surface.DrawRect(x_info, y_info, 166,17);
	surface.DrawRect(x_id+183, y_id+10, 4,31);
	surface.DrawRect(x_id+189, y_id+10, 4,31);
	surface.DrawRect(ScrW()-170-6, y_id+10, 4,31);
	surface.DrawRect(ScrW()-170-6-6, y_id+10, 4,31);
	
	--surfavce.DrawPoly(teampanel_outline);
	
	surface.SetDrawColor(200,200,200,200);
	if w and w:IsValid() then
	surface.DrawPoly(av)
	local t = "Warden"
	if not w:Alive() then
		t = t.." (dead)"
	end
	draw.SimpleText(t, "DefaultBold", 205,90,Color(0,0,0),0,0);

	draw.SimpleText(JB.wardenPlayer:Nick(), "Default", 205,105,Color(0,0,0),0,0);
	end
    surface.DrawPoly(idpanel);
    draw.SimpleText(localplayer:Nick(), "TargetID", 160,41,Color(0,0,0),0,0);
	surface.DrawPoly(ammopanel);

	

	surface.SetDrawColor( 230,230,230,200 );

	surface.DrawRect(ScrW()-170,y_id+24,130,16)

	surface.DrawRect(x_info, y_info, 165,16);
	if localplayer:Team() == TEAM_GUARD then
		local s= "Guard";
		if JB.wardenPlayer and JB.wardenPlayer == localplayer then
			s= "Warden";
		end
		draw.SimpleText(s, "Default", x_info+12, y_info+1,Color(0,0,0));
	elseif localplayer:Team() == TEAM_PRISONER then
		local c = "Loading..."; 
		if localplayer.character then
			c = localplayer.character.name.." \""..localplayer.character.nick.."\" "..localplayer.character.surname;
		end
		draw.SimpleText(c, "Default", x_info+12, y_info+1,Color(0,0,0));
	end

	local ammo = "none";
	if LocalPlayer():GetActiveWeapon() and LocalPlayer():GetActiveWeapon().Primary and LocalPlayer():GetActiveWeapon().Primary.ClipSize and LocalPlayer():GetActiveWeapon():Clip1() >= 0 then
		ammo = LocalPlayer():GetActiveWeapon():Clip1().."/"..LocalPlayer():GetAmmoCount(LocalPlayer():GetActiveWeapon().Ammo);
	end
	local credits = LocalPlayer():GetCredits() or 0
	draw.SimpleText(credits, "Default", ScrW()-50, y_info+1,Color(0,0,0),2);

	draw.SimpleText("Credits:", "DefaultBold", ScrW()-160, y_info+1,Color(0,0,0));

	draw.SimpleText(JB:RoundTimeToString(), "TargetID", ScrW()-50, 41,Color(0,0,0),2);

	surface.SetDrawColor( 100,100,100, 150 );
	
	
	render.ClearStencil();
	render.SetStencilEnable( true );
	render.SetStencilFailOperation( STENCILOPERATION_KEEP );
	render.SetStencilZFailOperation( STENCILOPERATION_REPLACE );
	render.SetStencilPassOperation( STENCILOPERATION_REPLACE );
	render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_ALWAYS );
	render.SetStencilReferenceValue( 1 );
	if displayportrait then
		surface.SetDrawColor( 0,0,0, 155 );
		surface.DrawPoly( circle );
	end
	render.SetStencilCompareFunction( STENCILCOMPARISONFUNCTION_EQUAL );
	render.SetStencilPassOperation( STENCILOPERATION_REPLACE );
	cam.Start3D( pos, ang, fov, portraitpos.x-80,portraitpos.y-80 , 150 , 150 );
		cam.IgnoreZ( true );
		render.SuppressEngineLighting( true );
		render.SetLightingOrigin( CharacterPortrait:GetPos() );
		render.ResetModelLighting( 1,1,1 );
		render.SetColorModulation( 1,1,1 );
		render.SetBlend( 1 );
		render.SetLightingOrigin( CharacterPortrait:GetPos() );
			CharacterPortrait:DrawModel();
		render.SuppressEngineLighting( false );
		cam.IgnoreZ( false );
	cam.End3D();
	render.SetStencilEnable( false );
	
	if h_old > localplayer:Health() then
		h_old = h_old-1;
	elseif h_old < localplayer:Health() then
		h_old = h_old+1;
	end
	
	local add = 0
	if h_old < 30 then
		add = 50*math.sin(CurTime()*4);
	end
	
	surface.SetTexture(surface.GetTextureID("HUD/HUD_RED1"));	
	surface.SetDrawColor(Color( 0,0,0,255) );
	DrawPartialCircle( portraitpos.x, portraitpos.y, 77, 13, 0, 360, 6 );
	surface.SetDrawColor(Color( 200,0,0,255) );
	DrawPartialCircle( portraitpos.x, portraitpos.y, 74, 10, 0, 360, 6 );
	surface.SetDrawColor( Color(0,200,0,255 )); -- health-color translations, yay!
	DrawPartialCircle( portraitpos.x, portraitpos.y, 74, 10, 0, h_old/100*360, 6 );


	-- Timers.
	local n = (count_start+count) - CurTime();

	if n < 0 then return end

	count_g = (n/count)*200;
	count_r = (1-(n/count))*200

	count_cir = (n/count)*360

	surface.SetDrawColor(Color(10,10,10,255));
	DrawPartialCircle( ScrW()/2-37, ScrH()/2, 60 ,12, 0, 360, 2 );
	surface.SetDrawColor(Color(count_r,count_g,0,255));
	DrawPartialCircle( ScrW()/2-37, ScrH()/2, 59 ,11, 0, count_cir, 2 );

	surface.SetDrawColor(Color(0,0,0,255));
	surface.DrawPoly(tri_outline);
	surface.SetDrawColor(Color(200,200,200,255));
	surface.DrawPoly(tri);

	draw.SimpleTextOutlined(math.Round(n), "HUDNumber5", ScrW()/2-37, ScrH()/2,Color(255,255,255),1,1,1,Color(0,0,0));
	draw.SimpleTextOutlined(count_title, "TargetID", ScrW()/2+25, ScrH()/2,Color(255,255,255),0,1,1,Color(0,0,0));

end);

/*
Eagle Predator Heads-Up Display
Version 1.3
� Night-Eagle 2007
gmail sedhdi

Console commands:
ehud_unit
	MPH or KM/H
*/



ephud = {}
ephud.maxammo = {}
ephud.shownames = true
ephud.lastang = Angle(0,0,0)
ephud.lasthealth = 0
ephud.lastflicker = 1
ephud.flicker = 1
ephud.flickerend = CurTime()
ephud.hudlag = 1
ephud.white = surface.GetTextureID("humanhead") //vgui/white
ephud.white = surface.GetTextureID("vgui/white")
ephud.quarter256h = surface.GetTextureID("client/quarter256h")

for i=12, 64 do
	surface.CreateFont("lcd"..i, {name = "lcd"..i, size = i, weight = 2, additive = false, antialias = true})
end
ephud.font12 = "lcd12"
ephud.font24 = "lcd24"
ephud.font36 = "lcd36"

ephud.usrskipright = false

function ephud.rect(x,y,w,h,orx,ory,u1,v1,u2,v2)
	local ox = orx or ScrW()*.5
	local oy = ory or ScrH()*.5
	u1 = u1 or 0
	u2 = u2 or 1
	v1 = v1 or 0
	v2 = v2 or 1
	
	//surface.SetTexture(tex)
	//surface.SetDrawColor(0,0,255,150*hf.a)
	
	local points = {
		{
			x=x,
			y=y,
			u=u1,
			v=v1,
		},
		{
			x=x+w,
			y=y,
			u=u2,
			v=v1,
		},
		{
			x=x+w,
			y=y+h,
			u=u2,
			v=v2,
		},
		{
			x=x,
			y=y+h,
			u=u1,
			v=v2,
		},
	}
	for k,v in ipairs(points) do
		v.x = (v.x-ox)
		v.y = (v.y-oy)
		
		v.x = v.x*(1+math.sin(v.y/(ScrW()))^2)
		v.y = v.y*(1+math.sin(v.x/(ScrH()))^2)
		
		v.x = v.x+ox
		v.y = v.y+oy
	end
	
	surface.DrawPoly(points)
end

function ephud.DrawRect(x,y,w,h,uix,uiy,ow,oh)
	ix = uix - 1
	iy = uiy - 1
	ixt = ix
	iyt = iy
	local dx = w/uix
	local dy = h/uiy
	for ix = 0,ix do
		for iy = 0,iy do
			ephud.rect(x+ix*dx,y+iy*dy,dx,dy,ow,oh,ix/math.max(ixt,1),iy/math.max(iyt,1))
		end
	end
end

function ephud.DrawText(ox,oy,text,font,x,y,color,xalign)
	ox = ox or ScrW()*.5
	oy = oy or ScrH()*.5
	
	x = x-ox
	y = y-oy
	
	x = x*(1+math.sin(y/(ScrW()))^2)
	y = y*(1+math.sin(x/(ScrH()))^2)
	
	x = x+ox
	y = y+oy
	
	draw.DrawText(text,font,x,y,color,xalign)
end

function ephud.load()
	function ephud.draw()
		if not LocalPlayer() or not LocalPlayer():IsValid() or (LocalPlayer():Team() ~= TEAM_PRISONER and LocalPlayer():Team() ~= TEAM_GUARD) then
			return
		end
		//Start get vars
		if not (LocalPlayer():IsValid() or LocalPlayer():Alive()) then return end
		//EHUD Compat
		
		local SWEP = LocalPlayer():GetActiveWeapon()
		local val = {}
		val.crx = .5*ScrW()
		val.cry = .5*ScrH()
		if SWEP:IsValid() then
			val.clip1type = SWEP:GetPrimaryAmmoType() or ""
			val.clip1 = tonumber(SWEP:Clip1()) or 0
			val.clip1left = LocalPlayer():GetAmmoCount(val.clip1type)
			val.clip2type = SWEP:GetSecondaryAmmoType() or ""
			val.clip2 = tonumber(SWEP:Clip2()) or 0
			val.clip2left = LocalPlayer():GetAmmoCount(val.clip2type)
			
			//LEGACY, REMOVE
			if type(SWEP:GetTable().mode) == "string" and type(SWEP:GetTable().data) == "table" and type(SWEP:GetTable().data[SWEP:GetTable().mode]) == "table" then
				val.firemode = SWEP:GetTable().data[SWEP:GetTable().mode].label or ""
			elseif SWEP:GetNWInt("firemode") then
				val.firemode = SWEP:GetNWInt("firemode")
			end
			
		else
			val.clip1 = 0
			val.clip1left = 0
			val.clip2 = 0
			val.clip2left = 0
			val.firemode = ""
		end
		if not ephud.maxammo[SWEP] then
			ephud.maxammo[SWEP] = val.clip1
		elseif val.clip1 > ephud.maxammo[SWEP] then
			ephud.maxammo[SWEP] = val.clip1
		end
		
		val.clip1max = tonumber(ephud.maxammo[SWEP]) or 1
		
		if SWEP:IsValid() then
			for k,v in pairs(SWEP:GetTable().huddata or {}) do
				val[k] = v
			end
		end
		
		//EHUD Compass
		// Compass
		val.pitch = LocalPlayer():EyeAngles()
		val.pitch, val.yaw, val.roll = LocalPlayer():EyeAngles().p, LocalPlayer():EyeAngles().y, LocalPlayer():EyeAngles().r
		// Vehicle + Compass
		if LocalPlayer():InVehicle() then
			local veh = LocalPlayer():GetVehicle()
			local vang = veh:EyeAngles()
			val.pitch, val.yaw, val.roll = val.pitch + vang.pitch, val.yaw + vang.yaw, val.roll + vang.roll
			
			val.vehicle = 1
			val.vehiclespeed = veh:GetVelocity():Length()
		else
			val.vehicle = 0
			val.vehiclespeed = -1
		end
		// More compass
		val.compass = math.Round((val.yaw+90)/90)
		if val.compass == 1 or val.compass == -3 then
			val.compass = "E"
		elseif val.compass == 2 or val.compass == -2 then
			val.compass = "N"
		elseif val.compass == 3 or val.compass == -1 then
			val.compass = "W"
		else
			val.compass = "S"
		end
		
		//Range finder
		do
			local trace = util.TraceLine({
				start = LocalPlayer():GetShootPos(),
				endpos = LocalPlayer():GetShootPos() + LocalPlayer():EyeAngles():Forward() * 40960,
				filter = LocalPlayer()
				})
			val.distance = trace.Fraction * 40960
		end
		
		//Team color
		local tcol = team.GetColor(LocalPlayer():Team())
		
		
		//End get vars
		--
		//Draw the HUD and get more vars
		
		//HUD lag
		local hl = {}
		hl.la = ephud.lastang
		hl.ca = LocalPlayer():EyeAngles()
		
		if hl.la.y < -90 and hl.ca.y > 90 then
			hl.la.y = hl.la.y + 360
		elseif hl.la.y > 90 and hl.ca.y < -90 then
			hl.la.y = hl.la.y - 360
		end
		
		hl.x = 0
		hl.y = 0
		hl.nm = 1/ephud.hudlag --Lag speed Default is 1/10, my new default is 1/5
		hl.na = Angle((hl.ca.p*hl.nm+hl.la.p)/(hl.nm+1),(hl.ca.y*hl.nm+hl.la.y)/(hl.nm+1), 0)
		ephud.lastang = hl.na
		
		//HUD flicker
		local hf = {}
		hf.ch = LocalPlayer():Health()+LocalPlayer():Armor()
		hf.lh = ephud.lasthealth
		hf.a = ephud.lastflicker
		
		if hf.ch < hf.lh then
			hf.a = math.Clamp(((hf.lh - hf.ch)/100)*(math.random(1,20)/10),0,1)
			ephud.flicker = hf.a
			if ephud.flickerend < CurTime() then
				ephud.flickerend = CurTime()+(hf.lh-hf.ch)/4
			else
				ephud.flickerend = ephud.flickerend+(hf.lh-hf.ch)/15
			end
			ephud.flickerend = math.Min(ephud.flickerend,CurTime()+2)
		elseif CurTime() < ephud.flickerend then
			hf.a = math.random(math.Max((1-ephud.flickerend+CurTime())*100,0),100)/100
		else
			hf.a = 1
		end
		
		ephud.lasthealth = hf.ch
		
		//Global
		surface.SetTexture(ephud.white)
		surface.SetDrawColor(0,0,255,150*hf.a)
		local yorigin = ScrH()*.5+64
		
		//Left
		surface.SetTexture(ephud.white)
		surface.SetDrawColor(0,0,0,150*hf.a)
		ephud.DrawRect(hl.x + 64,hl.y + ScrH()-252,256,56,16,1,nil,yorigin)
		
		local var
		local HP
		local imax
		//Health
		HP = math.Clamp(LocalPlayer():Health(),0,1000000000)
		var = math.Clamp(LocalPlayer():Health(),0,100)
		surface.SetDrawColor(255,0,0,150*hf.a)
		ephud.DrawRect(hl.x + 72,hl.y + ScrH()-244,240*var/100,16,16,1,nil,yorigin)
		surface.SetDrawColor(255,0,0,30*hf.a)
		ephud.DrawRect(hl.x + 72+(240*var/100),hl.y + ScrH()-244,240*(1-(var/100)),16,16,1,nil,yorigin)
		ephud.DrawText(nil,yorigin,HP,"lcd36",hl.x + 72,hl.y + ScrH()-252,Color(255,255,255,255*hf.a),0)
		
		//Armor
		var = math.Clamp(LocalPlayer():Armor(),0,100)
		surface.SetDrawColor(135,206,255,150*hf.a)
		ephud.DrawRect(hl.x + 72,hl.y + ScrH()-220,240*var/100,16,16,1,nil,yorigin)
		surface.SetDrawColor(135,206,255,30*hf.a)
		ephud.DrawRect(hl.x + 72+(240*var/100),hl.y + ScrH()-220,240*(1-(var/100)),16,16,1,nil,yorigin)
		if LocalPlayer():Armor() and LocalPlayer():Armor() > 0 then
			ephud.DrawText(nil,yorigin,LocalPlayer():Armor(),"lcd36",hl.x + 72,hl.y + ScrH()-228,Color(255,255,255,255*hf.a),0)
		end
		
		
		//Right
		if not ephud.usrskipright then
			surface.SetTexture(ephud.white)
			surface.SetDrawColor(0,0,0,150*hf.a)
			ephud.DrawRect(hl.x + ScrW()-320,hl.y + ScrH()-252,256,56,16,1,nil,yorigin)
		end
		
		//Secondary Ammo
		
		ephud.usrskipright = true
		
		
		
		if val.clip2left > 0 then
			surface.SetDrawColor(255,0,0,255*hf.a)
			ephud.DrawRect(hl.x + ScrW()-312+(232*(CurTime()*val.clip2left*.1%1)),hl.y + ScrH()-244,8,16,3,1,nil,yorigin)
			ephud.DrawText(nil,yorigin,val.clip2left,"lcd36",hl.x + ScrW()-306,hl.y + ScrH()-246.5,Color(255,255,255,255*hf.a),0)
			ephud.usrskipright = false
		end
		
		//Offset: -6,+6
		
		//Primary Ammo
		if val.clip1 > 0 then
			surface.SetDrawColor(30,200,30,150*hf.a)
			ephud.DrawRect(hl.x + ScrW()-312+(240*(1-val.clip1/val.clip1max)),hl.y + ScrH()-220,240*val.clip1/val.clip1max,16,16,1,nil,yorigin)
		end
		surface.SetDrawColor(0,255,0,30*hf.a) 
		ephud.DrawRect(hl.x + ScrW()-312,hl.y + ScrH()-220,240*(1-(val.clip1/val.clip1max)),16,16,1,nil,yorigin)
		if val.clip1 >= 0 then
			ephud.DrawText(nil,yorigin,val.clip1,"lcd36",hl.x + ScrW()-74,hl.y + ScrH()-226,Color(255,255,255,255*hf.a),2)
			if val.clip1 == 0 then
				surface.SetDrawColor(30,200,30,255*hf.a)
				ephud.DrawRect(hl.x + ScrW()-312+(232*(CurTime()*50*.1%1)),hl.y + ScrH()-220,8,16,3,1,nil,yorigin)
			end
			if val.clip1left > 0 then
				--ephud.DrawText(nil,origin,val.clip1left,"lcd36",hl.x + ScrW()-270,hl.y + ScrH()-248,Color(255,255,255,255*hf.a),2)
			end
			ephud.usrskipright = false
		elseif val.clip1left > 0 then
			surface.SetDrawColor(30,200,30,255*hf.a)
			ephud.DrawRect(hl.x + ScrW()-312+(232*(CurTime()*val.clip1left*.1%1)),hl.y + ScrH()-220,8,16,3,1,nil,yorigin)
			ephud.DrawText(nil,yorigin,val.clip1left,"lcd36",hl.x + ScrW()-80,hl.y + ScrH()-226,Color(255,255,255,255*hf.a),2)
			ephud.usrskipright = false
		end
		
		
	end
	
	hook.Add("HUDPaint","ephud.draw",ephud.draw)
	
	
	function ephud.HideHUD(name)
		if name == "CHudHealth" then return false end
		if name == "CHudBattery" then return false end
		if name == "CHudAmmo" then return false end
		if name == "CHudSecondaryAmmo" then return false end
	end
	hook.Add("HUDShouldDraw","ephud.HideHUD",ephud.HideHUD)
end
ephud.load()
