-- sh_entity_meta
-- entity metafunctions.
local Weapon = FindMetaTable("Weapon")

function Weapon:IsPrimary()
	return (string.Left(self:GetClass(), 10) == "jb_primary");
end

function Weapon:IsSecondary()
	return (string.Left(self:GetClass(), 12) == "jb_secondary");
end