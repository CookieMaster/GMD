ENT.Type             = "anim"
ENT.Base             = "base_anim"

function ENT:Draw()
   -- self:DrawModel();
end
