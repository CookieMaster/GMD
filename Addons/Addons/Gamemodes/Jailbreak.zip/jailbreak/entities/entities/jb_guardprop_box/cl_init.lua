ENT.Type             = "anim"
ENT.Base             = "base_anim"
ENT.PrintName            = "Bouncy Ball"

function ENT:Draw()
    self:DrawModel();
end
