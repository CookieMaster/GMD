ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "excl_previews"
ENT.Author			= "excl (_NewBee)"
ENT.AutomaticFrameAdvance = true
ENT.Spawnable			= false
ENT.AdminSpawnable		= false

