ENT.Type             = "anim"
ENT.Base             = "base_anim"
ENT.PrintName            = "Bouncy Ball"

function ENT:Initialize()
    local i = math.random( 0, 3 )
    
    if ( i == 0 ) then
         self.Color = Color( 255, 0, 0, 255 )
    elseif ( i == 1 ) then
        self.Color = Color( 0, 255, 0, 255 )
    elseif ( i == 2 ) then
        self.Color = Color( 255, 255, 0, 255 )
    else
        self.Color = Color( 0, 0, 255, 255 )
    end
        
    self.LightColor = Vector( 0, 0, 0 )
        
    self.MatBall = Material( "sprites/sent_ball" )
    
end

function ENT:Draw()
    
    local pos = self.Entity:GetPos()
    local vel = self.Entity:GetVelocity()
        
    render.SetMaterial( self.MatBall )
    
    local lcolor = render.GetLightColor( self:GetPos() ) * 2
    
    lcolor.x = self.Color.r * math.Clamp( lcolor.x, 0, 1 )
    lcolor.y = self.Color.g * math.Clamp( lcolor.y, 0, 1 )
    lcolor.z = self.Color.b * math.Clamp( lcolor.z, 0, 1 )
        
    if ( vel:Length() > 1 ) then
    
        for i = 1, 10 do
        
            local col = Color( lcolor.x, lcolor.y, lcolor.z, 200 / i )
            render.DrawSprite( pos + vel*(i*-0.005), 8, 8, col )
            
        end
    
    end
        
    render.DrawSprite( pos, 8, 8, Color( lcolor.x, lcolor.y, lcolor.z, 255 ) )
    
end
