-- Shared
-- Voice Visualizer Init

-- Client Files
AddCSLuaFile("vv/cl_init.lua")

-- Include
if CLIENT then
    include("vv/cl_init.lua")
end