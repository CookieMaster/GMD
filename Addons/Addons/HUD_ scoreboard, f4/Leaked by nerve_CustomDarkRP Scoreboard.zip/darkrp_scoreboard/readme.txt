Go in DarkRP/gamemode/fadmin/cl_ interface/ open cl_ scoreboard.lua and at the top
FROM
CreateClientConVar("FAdmin_IsScoreboard", 1, true, false) -- Set if it's a scoreboard or not

TO
CreateClientConVar("FAdmin_IsScoreboard", 0, false, false) -- Set if it's a scoreboard or not

Open init.lua and add this line AddCSLuaFile("cl_scoreboard.lua") preferable anywhere after line 43 so you keep everything organized.

Open cl_ init.lua and add this line include("cl_scoreboard.lua") preferable anywhere after line 60 so you keep everything organized.

Inside darkrp_scoreboard there will be a materials folder inside that will be boowman folder copy the folder and paste it in darkrp/content/materials/ Also make sure it is added in the fastdl so people will download it when they join.

You will also have to add the bg5.png in fastdl so people that join will download the material. use resource.AddFile("materials/boowman/bg5.png")