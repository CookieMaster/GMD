
-- RANKS --
local grad = Material("gui/gradient.png")
local grad_down = Material("gui/gradient_down.png")
local grad_up = Material("gui/gradient_up.png")
local mut = Material("icon32/muted.png")
local unmut = Material("icon32/unmuted.png")
local backbeh = Material("boowman/bg5.png","noclamp")
local serversettings = Material("icon64/tool.png")
local playersettings = Material("icon64/playermodel.png")
-- RANKS -- 

-- RULES -- 
// If in the rule tab you see only the rule number like 13) that mean the rule is to 
// long and try to keep it at 97 character.
local rules = {
"Do not expect an admin to take any action for any situation without substantial proof!",
"Do not disrespect/harass/threaten/flame any players.",
"Do not spam chat, microphone, or radio commands! This includes using a voice changer. ",
"If more than one person asks you to stop playing music or anything on HLDJ or anything then stop.",
"Do not be a smart ass/troll. Zero-tolerance for trolling/smartass.",
"English only.",
"Do not apply other server rules to this server!",
"Do not argue with an admin.",
"Do not advertise other gaming websites/servers.",
"Do not tell an admin how to do their job.",
"Do not impersonate an admin or any player.",
"Do not hack/exploit.",
"Do not spray nude/pornographic/disgusting/nasty sprays or anything similar deemed as inappropriate by an admin.",
"Do not abuse the votekick/voteban.",
"Do not evade ban, mute, gag, or silence.",
"Do not ghost. (Tell alive players useful information to better there odds, etc.)",
"Do not spam-drop weapons.",
"Do not team kill/attack.",
"Do not mislead players with incorrect rules.",
"Do not request an admins assistance in unnecessary situations; only rule breaking.",
"Do not encourage/antagonize rule breaking.",
}

surface.CreateFont( "Commands", {
	font = "Arial Narrow",
	size = 30,
	weight = 700,
} )

surface.CreateFont( "Options", {
	font = "Arial Narrow",
	size = 25,
	weight = 700,
} )

surface.CreateFont( "SBTitle", {
	font = "Arial Narrow",
	size = 50,
	weight = 500,
	antialias = true
} )

surface.CreateFont( "News", {
	font = "Arial Narrow",
	size = 20,
	weight = 700,
	antialias = true,
	outline = true
} )

surface.CreateFont( "Text", {
	font = "Arial Narrow",
	size = 20,
	weight = 600,
} )

surface.CreateFont( "Info", {
	font = "Arial Narrow",
	size = 20,
	weight = 600,
} )

surface.CreateFont( "Infosmall", {
	font = "Arial Narrow",
	size = 17,
	weight = 600,
} )

surface.CreateFont( "Show", {
	font = "Arial",
	size = 15,
	weight = 600,
} )

local Menu = {}

local function formatNumber(n)
	n = tonumber(n)
	if (!n) then
		return 0
	end
	if n >= 1e14 then return tostring(n) end
    n = tostring(n)
    sep = sep or ","
    local dp = string.find(n, "%.") or #n+1
	for i=dp-4, 1, -3 do
		n = n:sub(1, i) .. sep .. n:sub(i+1)
    end
    return n
end

local function GetTextHeight(font, str)
	surface.SetFont(font)
	local w, h = surface.GetTextSize(str)
	return h
end

function plcommandbtn(parent,x,y,text,command,...)

local over = Color(51,51,51,255)		
local btn = vgui.Create("DButton",parent)
	btn:SetPos(x,y)
	btn:SetSize(130,35)
	btn:SetFont("Commands")
	btn:SetTextColor(Color(255,255,255))
	btn:SetText(text)
	btn.Paint = function()
			draw.RoundedBox(0,0,0,btn:GetWide(),btn:GetTall(),over)
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,btn:GetWide(),btn:GetTall())
	end
	local cmdArgs = {...}
	btn.DoClick = function()
		surface.PlaySound("buttons/button9.wav")
		RunConsoleCommand(command,unpack(cmdArgs))
	end
	btn.OnCursorEntered = function()
		over = Color(80,80,80,255)
	end
	btn.OnCursorExited = function()
		over = Color(51,51,51,255)
	end	
	return btn
end

function sboxcommandslid(parent,x,y,text,sboxcom)

	local svbg = vgui.Create("DPanel",parent)
		svbg:SetPos(x,y)
		svbg:SetSize(parent:GetWide()/2.3,25)
		
	local com = vgui.Create( "DNumSlider",svbg)
		com:DockMargin(20,0,2,0)
		com:SetText(text)	
		com:Dock(FILL)
		com:SetConVar(sboxcom)
		com:SetMin(0)
		com:SetMax(256)
		com:SetDecimals(0)
		com:GetValue()
		com.Label:SizeToContents( )
		com.Label:SetTextColor(Color(0,0,0,255))	
end

function svcomcheck(parent,y,text,com)

	local check = vgui.Create("DCheckBoxLabel", parent)
		check:SetPos(5,y)
		check:SetText(text)
		check:SetConVar(com)
		check:GetValue()
		check:SizeToContents()	
			
end

hook.Add('ScoreboardShow','DarkRPSCoreboard', function()

gui.EnableScreenClicker(true)
		
	if IsValid(LocalPlayer()) then
	
local bgcolor = Color(19,26,26,255)
	bg = vgui.Create("DFrame")
		bg:SetPos(ScrW()/2-350,ScrH()/2-250)
		bg:SetSize(700,450)
		bg:SetTitle("")
		bg:ShowCloseButton(false)
		bg:SetDraggable(false)
		bg:MakePopup()	
		bg.Paint = function()
			draw.RoundedBox(0,0,0,bg:GetWide(),bg:GetTall(),bgcolor)
		end
	
	config = vgui.Create("DFrame")
		config:SetPos(ScrW()/2-350,ScrH()/2-302)
		config:SetSize(700,50)
		config:SetTitle("")
		config:ShowCloseButton(false)
		config:SetDraggable(false)
		config:SetVisible(false)
		config:MakePopup()
		config.Paint = function()
			draw.RoundedBox(0,0,0,config:GetWide(),config:GetTall(),Color(0,0,0,200))			
			
			surface.SetMaterial(backbeh)
			surface.SetDrawColor(255,255,255,200)
			surface.DrawTexturedRectUV( 0, 0, config:GetWide(), config:GetTall(), 0, 0, config:GetWide()/32, config:GetTall()/32 )

			draw.RoundedBox(0,0,0,config:GetWide(),config:GetTall(),Color(0,0,0,200))			
			
			surface.SetDrawColor(0,0,0)
			surface.DrawOutlinedRect(0,0,config:GetWide(),config:GetTall())
		
		end
local colop = Color(255,255,255)
	local options = vgui.Create("DButton",bg)
		options:SetPos(2,2)
		options:SetSize(bg:GetWide()-4,25)
		options:SetFont("Options")
		options:SetTextColor(Color(255,255,255))
		options:SetText('')
		options.Paint = function()
			draw.RoundedBox(0,0,0,options:GetWide(),options:GetTall(),Color(37,104,134,200))
		if config:IsVisible() then
			draw.DrawText("Shrink Options","Options",options:GetWide()/2,0,colop,TEXT_ALIGN_CENTER)
		else
			draw.DrawText("Expand Options","Options",options:GetWide()/2,0,colop,TEXT_ALIGN_CENTER)
		end
		end 
		options.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			if config:IsVisible() then
				if IsValid(config) then
					config:SetVisible(false)
				end	
			else
				if IsValid(config) then
					config:SetVisible(true)
				end
			end
		end	
		options.OnCursorEntered = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			colop = Color(128,128,128)
		end
		options.OnCursorExited = function()
			colop = Color(255,255,255)
		end
		
//***********\\
--Players Tab--
//***********\\	

local plydarkblue = Color(37,104,137,0)	
	local btnplayers = vgui.Create("DButton",config)
		btnplayers:SetPos(5,5)
		btnplayers:SetSize(config:GetWide()/4-10,config:GetTall()-10)
		btnplayers:SetFont("Commands")
		btnplayers:SetTextColor(Color(255,255,255))
		btnplayers:SetText("Players")
		btnplayers.Paint = function()
			if plylist:IsVisible() then
				draw.RoundedBox(0,0,0,btnplayers:GetWide(),btnplayers:GetTall(),Color(37,104,137,200))
			else	
				draw.RoundedBox(0,0,0,btnplayers:GetWide(),btnplayers:GetTall(),plydarkblue)
			end
		end
		btnplayers.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			print(LocalPlayer():GetName().." clicked on the players button.")
			if IsValid(plylist) or IsValid(shows) then
				plylist:SetVisible(true)
				shows:SetVisible(true)
			end
			if IsValid(webbg) then
				webbg:SetVisible(false)
			end
			if IsValid(helpbg) then
				helpbg:SetVisible(false)
			end	
			if IsValid(rulbg)then
				rulbg:SetVisible(false)
			end
			if IsValid(playersbg) then
				playersbg:SetVisible(false)
			end	
			if IsValid(serverbg) then
				serverbg:SetVisible(false)
			end	
			if IsValid(buttonsbg) then
				buttonsbg:SetVisible(false)
			end
			bgcolor = Color(19,26,26,255)
		end
		btnplayers.OnCursorEntered = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			plydarkblue = Color(37,104,137,100)	
		end		
		btnplayers.OnCursorExited = function()
			plydarkblue = Color(0,0,0,0)
		end
		
	shows = vgui.Create("DPanel",bg)
		shows:SetPos(2,29)
		shows:SetSize(bg:GetWide()-4,15)
		shows.Paint = function()
			draw.RoundedBox(0,0,0,shows:GetWide(),shows:GetTall(),Color(64,64,64,250))
			draw.RoundedBox(0,0,0,shows:GetWide(),shows:GetTall()/2,Color(128,128,128,150))
			draw.DrawText("Name/Rank","Show",50,0,Color(255,255,255),TEXT_ALIGN_LEFT)
			draw.DrawText("Job","Show",shows:GetWide()/2+50,0,Color(255,255,255),TEXT_ALIGN_CENTER)
			if plylist.VBar:IsVisible() then	
				draw.DrawText("K/D","Show",shows:GetWide()-115,0,Color(255,255,255),TEXT_ALIGN_CENTER)
				draw.DrawText("Ping","Show",shows:GetWide()-50,0,Color(255,255,255),TEXT_ALIGN_RIGHT)	
			else	
				draw.DrawText("K/D","Show",shows:GetWide()-100,0,Color(255,255,255),TEXT_ALIGN_CENTER)
				draw.DrawText("Ping","Show",shows:GetWide()-32,0,Color(255,255,255),TEXT_ALIGN_RIGHT)	
			end
		end	
		
	plylist = vgui.Create("DScrollPanel",bg)
		plylist:SetPos(2,47)
		plylist:SetSize(bg:GetWide()-4,bg:GetTall()-50)
		plylist:SetPadding(5)
		plylist.Paint = function()
			draw.RoundedBox(0,0,0,plylist:GetWide(),plylist:GetTall(),Color(50,150,50,0))
		end
	
local plys = player.GetAll()
table.sort(plys, function(a, b) return a:Team() > b:Team() end)
	
for k,pl in pairs(plys) do
local mo = formatNumber(pl.DarkRPVars.money) or 0	
local over = Color(0,0,0,0)	
local slujba = pl:getDarkRPVar("job") or "Unemployed"

	local row = vgui.Create("DButton",plylist)
		row:SetPos(0,k*45-45)
		row:SetSize(plylist:GetWide(),40)
		row:SetText('')
		row.Paint = function()
			draw.RoundedBox(0,0,0,row:GetWide(),row:GetTall(),over)	
			draw.RoundedBox(0,2,2,row:GetWide()-4,row:GetTall()-4,Color(50,50,50,200))
		local rank = "User"
		if pl:IsUserGroup("owner") then rank = "Owner"end
		if pl:IsUserGroup("superadmin") then rank = "Super Admin"end
		if pl:IsUserGroup("admin") then rank = "Admin"end
		if pl:IsUserGroup("moderator") then rank = "Moderator"end
		if pl:IsUserGroup("user") then rank = "User"end

			draw.DrawText(pl:Nick(),"Info",50,2,Color(255,255,255),TEXT_ALIGN_LEFT)
			draw.DrawText(rank,"Info",50,20,Color(255,255,255),TEXT_ALIGN_LEFT)
			draw.DrawText(slujba,"Info",row:GetWide()/2+50,2,Color(255,255,255),TEXT_ALIGN_CENTER)
			if LocalPlayer():GetNWString("usergroup") == "superadmin" or LocalPlayer():GetNWString("usergroup") == "admin" then		
				draw.DrawText("$"..mo,"Info",row:GetWide()/2+50,20,Color(255,255,255),TEXT_ALIGN_CENTER)
			end			
			if plylist.VBar:IsVisible() then
				draw.DrawText(pl:Frags().."/ "..pl:Deaths(),"Info",row:GetWide()-115,10,Color(255,255,255),TEXT_ALIGN_CENTER)
				draw.DrawText(pl:Ping(),"Info",row:GetWide()-55,10,Color(255,255,255),TEXT_ALIGN_RIGHT)
			else
				draw.DrawText(pl:Frags().."/ "..pl:Deaths(),"Info",row:GetWide()-100,10,Color(255,255,255),TEXT_ALIGN_CENTER)
				draw.DrawText(pl:Ping(),"Info",row:GetWide()-40,10,Color(255,255,255),TEXT_ALIGN_RIGHT)
			end	
		end
		row.DoClick = function()
		surface.PlaySound("buttons/button9.wav")
			local options = DermaMenu()
			options:AddOption("Copy SteamID", function() SetClipboardText(pl:SteamID()) surface.PlaySound("buttons/button9.wav") end):SetImage("icon16/tag_blue.png")
			options:AddOption("Copy Name", function() SetClipboardText(pl:Nick()) surface.PlaySound("buttons/button9.wav") end):SetImage("icon16/user_edit.png")
			options:AddOption("Copy Rank Name", function() SetClipboardText(pl:GetNWString("usergroup")) surface.PlaySound("buttons/button9.wav") end):SetImage("icon16/shield.png")
			options:AddSpacer()
			options:AddOption("Open Profile", function() pl:ShowProfile() surface.PlaySound("buttons/button9.wav") end):SetImage("icon16/world.png")
			options:AddSpacer()
		if LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin() then
			if IsValid(pl) then
				local adminop,subimg = options:AddSubMenu("Quick Admin Options")
					subimg:SetImage("icon16/lorry.png")
					adminop:AddOption("Kick", function() RunConsoleCommand("ulx","kick",pl:Nick(),"You were kicked by "..LocalPlayer():Nick()) surface.PlaySound("buttons/button9.wav") end):SetImage("icon16/door_out.png")
					adminop:AddOption("Ban", function() RunConsoleCommand("ulx","ban",pl:Nick(),60,"You were banned by "..LocalPlayer():Nick()) surface.PlaySound("buttons/button9.wav") bg:Close() end):SetImage("icon16/delete.png")
					adminop:AddSpacer()
					adminop:AddOption("Spectate", function() RunConsoleCommand("ulx","spectate",pl:Nick()) surface.PlaySound("buttons/button9.wav") end):SetImage("icon16/zoom.png")
					adminop:AddSpacer()
				options:Open()
				end
			end
		end
		row.OnCursorEntered = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			over = Color(37,104,134,255)
		end	
	
		row.OnCursorExited = function()
			over = Color(0,0,0,0)
		end	
		
	local plicon = vgui.Create("SpawnIcon",row)
		plicon:SetPos(7,-1)
		plicon:SetSize(40,40)
		plicon:SetModel(pl:GetModel())
		plicon:SetToolTip('')
	
	local mute = vgui.Create("DImageButton",row)
		mute:SetPos(row:GetWide()-50,4)
		mute:SetSize(50,32)
		mute:SetToolTip("Mute "..pl:GetName()..".")	
		mute:SetColor(255,255,255,255)
		mute.DoClick = function()
			surface.PlaySound( "buttons/button17.wav" )	
			pl:SetMuted(pl:IsMuted())
		end
		mute.Paint = function()
			draw.RoundedBox(0,0,0,mute:GetWide(),mute:GetTall(),Color(0,0,0,0))
		local x,y = 0,0
		if plylist.VBar:IsVisible() then
			x = 0
		else
			x = 18
		end
			if ( pl:IsMuted() ) then
				surface.SetMaterial(mut)
				surface.SetDrawColor(225,255,255,255)
				surface.DrawTexturedRect(x,y,32,32)
			else
				surface.SetMaterial(unmut)
				surface.SetDrawColor(225,255,255,255)
				surface.DrawTexturedRect(x,y,32,32)
			end
		end
		
function row:Think() 
	if not IsValid(pl) then 
		self:Remove()
		plicon:Remove()
		mute:Remove() 		
	end	
end

//**********\\
-- Help Tab --
//**********\\	

local helpdarkblue = Color(37,104,137,0)	
	local btnhelp = vgui.Create("DButton",config)
		btnhelp:SetPos(config:GetWide()/2-175,5)
		btnhelp:SetSize(config:GetWide()/4-10,config:GetTall()-10)
		btnhelp:SetFont("Commands")
		btnhelp:SetTextColor(Color(255,255,255))
		btnhelp:SetText("Help")
		btnhelp.Paint = function()
			if helpbg:IsVisible() then
				draw.RoundedBox(0,0,0,btnhelp:GetWide(),btnhelp:GetTall(),Color(37,104,137,100))
			else	
				draw.RoundedBox(0,0,0,btnhelp:GetWide(),btnhelp:GetTall(),helpdarkblue)
			end
		end
		btnhelp.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			print(LocalPlayer():GetName().." clicked on the help button.")
			if IsValid(helpbg) then
				helpbg:SetVisible(true)
			end			
			if IsValid(webbg) then
				webbg:SetVisible(false)
			end	
			if IsValid(rulbg)then
				rulbg:SetVisible(false)
			end
			if IsValid(playersbg) then
				playersbg:SetVisible(false)
			end	
			if IsValid(serverbg) then
				serverbg:SetVisible(false)
			end	
			if IsValid(buttonsbg) then
				buttonsbg:SetVisible(false)
			end			
			if IsValid(plylist) or IsValid(shows) then
				plylist:SetVisible(false)
				shows:SetVisible(false)
			end
			bgcolor = Color(19,26,26,250)
		end
		btnhelp.OnCursorEntered = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			helpdarkblue = Color(37,104,137,100)	
		end		
		btnhelp.OnCursorExited = function()
			helpdarkblue = Color(0,0,0,0)
		end
		
	helpbg = vgui.Create("DScrollPanel",bg)
		helpbg:SetPos(2,29)
		helpbg:SetSize(bg:GetWide()-4,bg:GetTall()-31)
		helpbg:SetPadding(5)
		helpbg:SetVisible(false)
		helpbg.Paint = function()
			draw.RoundedBox(0,0,0,helpbg:GetWide(),helpbg:GetTall(),Color(19,35,35,50))
			
			surface.SetMaterial(backbeh)
			surface.SetDrawColor(255,255,255,50)
			surface.DrawTexturedRectUV( 0, 0, bg:GetWide()-4, bg:GetTall()-31, 0, 0, (bg:GetWide()-4)/32, (bg:GetTall()-31)/32 )		
		end	

local LabelIndex = 0
local yoffset = 0

for k, v in pairs(GAMEMODE:getHelpCategories()) do	

	local helptxt = vgui.Create("DLabel", helpbg)
			helptxt:SetPos( 5, yoffset )
			helptxt.OrigY = yoffset
			helptxt:SetFont("GModToolSubtitle")
			helptxt:SetTextColor( Color(255,255,255,255))
			helptxt:SetText(v.name)
			helptxt:SizeToContents()
			
	surface.SetFont("ChatFont")

		local labelh = GetTextHeight("ChatFont", "A")
		local index = 0
		local labelCount = table.Count(v.labels)
		
		for i, label in pairs(v.labels) do
		
			local labelw = surface.GetTextSize(label)
			LabelIndex = LabelIndex + 1
		
			local helptxt = vgui.Create("DLabel", helpbg)
				helptxt:SetText(label)
				helptxt:SetFont("ChatFont")
				helptxt.OrigY = yoffset + 25 + index * labelh
				helptxt:SetPos(5, yoffset + 25 + index * labelh)
				helptxt:SetWidth(labelw)			
				helptxt:SetTextColor( Color(255,255,255,255))
				helptxt:SizeToContents()
			
			index = index + 1
			
		end
	local cath = GetTextHeight("GModToolSubtitle", "A")
	yoffset = yoffset + (cath + 15) + labelCount * labelh	
end

//***********\\
-- Rules Tab --
//***********\\	

local ruldarkblue = Color(0,0,0,0)		
	local btnrules = vgui.Create("DButton",config)
		btnrules:SetPos(config:GetWide()/2,5)
		btnrules:SetSize(config:GetWide()/4-10,config:GetTall()-10)
		btnrules:SetFont("Commands")
		btnrules:SetTextColor(Color(255,255,255))
		btnrules:SetText("Rules")
		btnrules.Paint = function()
			if rulbg:IsVisible() then
				draw.RoundedBox(0,0,0,btnrules:GetWide(),btnrules:GetTall(),Color(37,104,137,100))
			else	
				draw.RoundedBox(0,0,0,btnrules:GetWide(),btnrules:GetTall(),ruldarkblue)
			end
		end
		btnrules.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			print(LocalPlayer():GetName().." clicked on the rules button.")
			if IsValid(rulbg)then
				rulbg:SetVisible(true)
			end
			if IsValid(webbg) then
				webbg:SetVisible(false)
			end
			if IsValid(helpbg) then
				helpbg:SetVisible(false)
			end	
			if IsValid(playersbg) then
				playersbg:SetVisible(false)
			end	
			if IsValid(serverbg) then
				serverbg:SetVisible(false)
			end	
			if IsValid(buttonsbg) then
				buttonsbg:SetVisible(false)
			end			
			if IsValid(plylist) or IsValid(shows) then
				plylist:SetVisible(false)
				shows:SetVisible(false)
			end
			bgcolor = Color(19,26,26,250)
		end
		btnrules.OnCursorEntered = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			ruldarkblue = Color(37,104,137,100)	
		end		
		btnrules.OnCursorExited = function()
			ruldarkblue = Color(0,0,0,0)
		end
		
	rulbg = vgui.Create("DScrollPanel",bg)
		rulbg:SetPos(2,29)
		rulbg:SetSize(bg:GetWide()-4,bg:GetTall()-31)
		rulbg:SetPadding(5)
		rulbg:SetVisible(false)
		rulbg.Paint = function()
			draw.RoundedBox(0,0,0,rulbg:GetWide(),rulbg:GetTall(),Color(19,35,35,50))
			surface.SetMaterial(backbeh)
			surface.SetDrawColor(255,255,255,50)
			surface.DrawTexturedRectUV( 0, 0, bg:GetWide()-4, bg:GetTall()-31, 0, 0, (bg:GetWide()-4)/32, (bg:GetTall()-31)/32 )		
		end
y = 5
for k,rul in pairs(rules) do	
	text = k..": "..rul
	if #rul > 97 then
		text = k.." :"
	end
	local rulestxt = vgui.Create("DLabel", rulbg)
			rulestxt:SetPos( 5, y )
			rulestxt:SetFont("ChatFont")
			rulestxt:SetTextColor( Color(255,255,255,255))
			rulestxt:SetText(text)
			rulestxt:SizeToContents()
	y = y + 20
end
//***********\\
-- Admin Tab --
//***********\\	
		
if LocalPlayer():GetNWString('usergroup') == 'superadmin' or LocalPlayer():GetNWString('usergroup') == 'admin' then

local admindarkblue = Color(0,0,0,0)		
	local btnadmin = vgui.Create("DButton",config)
		btnadmin:SetPos(config:GetWide()-config:GetWide()/4,5)
		btnadmin:SetSize(config:GetWide()/4-10,config:GetTall()-10)
		btnadmin:SetFont("Commands")
		btnadmin:SetTextColor(Color(255,255,255))
		btnadmin:SetText("Admin")
		if LocalPlayer():GetNWString('usergroup') == 'user' or LocalPlayer():GetNWString('usergroup') == 'user' then
			btnadmin:SetVisible(false)
		else
			btnadmin:SetVisible(true)
		end
		btnadmin.Paint = function()
			if buttonsbg:IsVisible() then
				draw.RoundedBox(0,0,0,btnadmin:GetWide(),btnadmin:GetTall(),Color(37,104,137,100))
			else	
				draw.RoundedBox(0,0,0,btnadmin:GetWide(),btnadmin:GetTall(),admindarkblue)
			end
		end
		btnadmin.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			print(LocalPlayer():GetName().." clicked on the admin button.")	
			if IsValid(playersbg) then
				playersbg:SetVisible(true)
			end					
			if IsValid(buttonsbg) then
				buttonsbg:SetVisible(true)
			end				
			if IsValid(helpbg) then
				helpbg:SetVisible(false)
			end			
			if IsValid(webbg) then
				webbg:SetVisible(false)
			end
			if IsValid(rulbg)then
				rulbg:SetVisible(false)
			end
			if IsValid(plylist) or IsValid(shows) then
				plylist:SetVisible(false)
				shows:SetVisible(false)
			end	
			if IsValid(serverbg) then
				serverbg:SetVisible(false)
			end		
			bgcolor = Color(19,26,26,250)			
		end
		btnadmin.OnCursorEntered = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			admindarkblue =  Color(37,104,137,100)	
		end		
		btnadmin.OnCursorExited = function()
			admindarkblue = Color(0,0,0,0)
		end
			
	buttonsbg = vgui.Create("DPanel",bg)
		buttonsbg:SetPos(2,29)
		buttonsbg:SetSize(bg:GetWide()-4,55)
		buttonsbg:SetVisible(false)
		buttonsbg.Paint = function()
			draw.RoundedBox(0,0,0,buttonsbg:GetWide(),buttonsbg:GetTall(),Color(200,75,75,50))
			
			surface.SetMaterial(backbeh)
			surface.SetDrawColor(255,255,255,50)
			surface.DrawTexturedRectUV( 0, 0, buttonsbg:GetWide(), buttonsbg:GetTall(), 0, 0, buttonsbg:GetWide()/32, buttonsbg:GetTall()/32 )				
		end	
		
// Players Button/Commands/Admins	

	playersbg = vgui.Create("DPanel",bg)
		playersbg:SetPos(2,87)
		playersbg:SetSize(bg:GetWide()-4,bg:GetTall()-89)
		playersbg:SetVisible(false)
		playersbg.Paint = function()
			draw.RoundedBox(0,0,0,playersbg:GetWide(),playersbg:GetTall(),Color(25,25,25,50))
		end
		
	local players = vgui.Create("DButton",buttonsbg)
		players:SetPos(5,0)
		players:SetSize(55,55)
		players:SetToolTip("Use Commands on Players")
		players:SetText("")
		players.Paint = function()
			surface.SetMaterial(playersettings)
			surface.SetDrawColor(255,255,255,255)
			surface.DrawTexturedRect(0,0,players:GetWide(),players:GetTall())
		end		
		players.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			if IsValid(playersbg) then
				playersbg:SetVisible(true)
			end					
			if IsValid(serverbg) then
				serverbg:SetVisible(false)
			end		
		end
		players.OnCursorEntered = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			players.Paint = function()
				surface.SetMaterial(playersettings)
				surface.SetDrawColor(255,255,255,255)
				surface.DrawTexturedRect(10,10,players:GetWide()/1.5,players:GetTall()/1.5)
			end
		end		
		players.OnCursorExited = function()
			players.Paint = function()
				surface.SetMaterial(playersettings)
				surface.SetDrawColor(255,255,255,255)
				surface.DrawTexturedRect(0,0,players:GetWide(),players:GetTall())
			end
		end
local none = "Nobody Selected"
	local plycomlist = vgui.Create("DFrame",playersbg)
		plycomlist:SetPos(5,3)
		plycomlist:SetSize(playersbg:GetWide()/2.7,playersbg:GetTall()-6)
		plycomlist:SetTitle('')
		plycomlist:SetDraggable(false)
		plycomlist:ShowCloseButton(false)
		plycomlist.Paint = function()
			draw.RoundedBox(0,0,0,plycomlist:GetWide(),plycomlist:GetTall(),Color(37,104,134,200))
			
			surface.SetMaterial(backbeh)
			surface.SetDrawColor(255,255,255,150)
			surface.DrawTexturedRectUV( 0, 0, plycomlist:GetWide(), 25, 0, 0, plycomlist:GetWide()/32, 25/32 )
			
			surface.SetMaterial(backbeh)
			surface.SetDrawColor(255,255,255,150)
			surface.DrawTexturedRectUV( 0, plycomlist:GetTall()-25, plycomlist:GetWide(), 25, 0, 0, plycomlist:GetWide()/32, 25/32 )
			
			draw.DrawText("Player List","Info",plycomlist:GetWide()/2,5,Color(255,255,255),TEXT_ALIGN_CENTER)			
			
			draw.DrawText(none,"Info",plycomlist:GetWide()/2,plycomlist:GetTall()-25,Color(255,255,255),TEXT_ALIGN_CENTER)			
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,plycomlist:GetWide(),plycomlist:GetTall())
		end
		
	local plycomlist2 = vgui.Create("DScrollPanel",plycomlist)
		plycomlist2:SetPos(2,27)
		plycomlist2:SetSize(plycomlist:GetWide()-4,plycomlist:GetTall()-54)
		plycomlist2:SetPadding(5)
		plycomlist2.Paint = function()
			draw.RoundedBox(0,0,0,plycomlist2:GetWide(),plycomlist2:GetTall(),Color(0,0,0,0))
		end	
				
	local plycommands = vgui.Create("DFrame",playersbg)
		plycommands:SetPos(playersbg:GetWide()-playersbg:GetWide()/1.63,3)
		plycommands:SetSize(playersbg:GetWide()/1.65,playersbg:GetTall()-6)
		plycommands:SetTitle('')
		plycommands:SetDraggable(false)
		plycommands:ShowCloseButton(false)
		plycommands.Paint = function()
			draw.RoundedBox(0,0,0,plycommands:GetWide(),plycommands:GetTall(),Color(37,104,134,200))
			
			surface.SetMaterial(backbeh)
			surface.SetDrawColor(255,255,255,150)
			surface.DrawTexturedRectUV( 0, 0, plycommands:GetWide(), 25, 0, 0, plycommands:GetWide()/32, 25/32 )
			
			draw.DrawText("Commads","Info",plycommands:GetWide()/2,5,Color(255,255,255),TEXT_ALIGN_CENTER)			
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,plycommands:GetWide(),plycommands:GetTall())
		end
		
	plycommands2 = vgui.Create("DScrollPanel",plycommands)
		plycommands2:SetPos(2,27)
		plycommands2:SetSize(plycommands:GetWide()-4,plycommands:GetTall()-29)
		plycommands2:SetPadding(5)
		plycommands2:SetVisible(false)
		plycommands2.Paint = function()
			draw.RoundedBox(0,0,0,plycommands2:GetWide(),plycommands2:GetTall(),Color(0,0,0,0))
		end
		
local pllist = player.GetAll()
table.sort(pllist, function(a, b) return a:Nick() < b:Nick() end)

for k,v in pairs(player.GetAll()) do

local hover = Color(37,60,60,0)
	local rowcom = vgui.Create("DButton",plycomlist2)
		rowcom:SetPos(0,k*28-28)
		rowcom:SetSize(plycomlist2:GetWide(),25)
		rowcom:SetText('')
		rowcom.Paint = function()
			draw.RoundedBox(0,2,0,rowcom:GetWide()-4,rowcom:GetTall(),Color(64,64,64,240))
			draw.DrawText(v:Nick(),"Info",10,2,Color(255,255,255),TEXT_ALIGN_LEFT)
			surface.SetDrawColor(hover)
			surface.DrawOutlinedRect(0,0,rowcom:GetWide(),rowcom:GetTall())
		end
		rowcom.DoClick = function()	
			if IsValid(plycommands2) then
				plycommands2:SetVisible(true)			
			end
			
local overkick = Color(51,51,51,255)		
	local kick = vgui.Create("DButton",plycommands2)
		kick:SetPos(6,5)
		kick:SetSize(130,35)
		kick:SetFont('Commands')
		kick:SetTextColor(Color(255,255,255))
		kick:SetText('Kick')
		kick.Paint = function()
			draw.RoundedBox(0,0,0,kick:GetWide(),kick:GetTall(),overkick)
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,kick:GetWide(),kick:GetTall())
		end
		kick.DoClick = function()	
			surface.PlaySound("buttons/button9.wav")		
		local reportmsg = vgui.Create( "DFrame" )
			reportmsg:SetPos(ScrW() / 2 - 200, ScrH() / 2 - 120)
			reportmsg:SetSize(400,100)
			reportmsg:SetTitle("")
			reportmsg:SetVisible(true)
			reportmsg:SetDraggable(false)
			reportmsg:SetBackgroundBlur(true)
			reportmsg:ShowCloseButton(true)
			reportmsg:MakePopup()	
			
		
		local tellad = vgui.Create("DLabel",reportmsg)
			tellad:SetPos(reportmsg:GetWide()/2-100,22)
			tellad:SetFont("Text")
			tellad:SetText("Enter the reason for kicking him.")
			tellad:SizeToContents()		
		
		story = vgui.Create("DTextEntry",reportmsg)
			story:SetPos(10,42)
			story:SetTall(20)
			story:SetWide(reportmsg:GetWide()-20)
			story:RequestFocus()	

			
		local accept = vgui.Create("DButton",reportmsg)
			accept:SetPos(100,65)
			accept:SetSize(80,30)
			accept:SetImage('icon16/accept.png')	
			accept:SetText('Accept')
			accept.DoClick = function()
				if IsValid(reportmsg) then
					reportmsg:Close()
				end		
				AlertMessage = story:GetValue()	
				RunConsoleCommand("ulx","kick",v:Nick(),AlertMessage)	
			end
		
		local cancel = vgui.Create("DButton",reportmsg)
			cancel:SetPos(230,65)
			cancel:SetSize(80,30)
			cancel:SetImage('icon16/cross.png')	
			cancel:SetText('Cancel')
			cancel.DoClick = function()
				if IsValid(reportmsg) then
					reportmsg:Close()
				end
			end
		end
		kick.OnCursorEntered = function()
			overkick = Color(80,80,80,255)
		end
		kick.OnCursorExited = function()
			overkick = Color(51,51,51,255)
		end
		
local overban = Color(51,51,51,255)		
	local ban = vgui.Create("DButton",plycommands2)
		ban:SetPos(6,45)
		ban:SetSize(130,35)
		ban:SetFont('Commands')
		ban:SetTextColor(Color(255,255,255))
		ban:SetText('Ban')	
		ban.Paint = function()
			draw.RoundedBox(0,0,0,ban:GetWide(),ban:GetTall(),overban)
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,ban:GetWide(),ban:GetTall())
		end
		ban.DoClick = function()
			surface.PlaySound("buttons/button9.wav")			
		local reportmsg = vgui.Create( "DFrame" )
			reportmsg:SetPos(ScrW() / 2 - 200, ScrH() / 2 - 120)
			reportmsg:SetSize(400,100)
			reportmsg:SetTitle("")
			reportmsg:SetVisible(true)
			reportmsg:SetDraggable(false)
			reportmsg:SetBackgroundBlur(true)
			reportmsg:ShowCloseButton(true)
			reportmsg:MakePopup()	
				
		local tellad = vgui.Create("DLabel",reportmsg)
			tellad:SetPos(reportmsg:GetWide()/2-100,22)
			tellad:SetFont("Text")
			tellad:SetText("Enter the reason for banning him.")
			tellad:SizeToContents()		
		
		story = vgui.Create("DTextEntry",reportmsg)
			story:SetPos(10,42)
			story:SetTall(20)
			story:SetWide(reportmsg:GetWide()-20)
			story:RequestFocus()	
			
		local accept = vgui.Create("DButton",reportmsg)
			accept:SetPos(100,65)
			accept:SetSize(80,30)
			accept:SetImage('icon16/accept.png')	
			accept:SetText('Accept')
			accept.DoClick = function()
				if IsValid(reportmsg) then
					reportmsg:Close()
				end		
				AlertMessage = story:GetValue()	
				RunConsoleCommand("ulx","ban",v:Nick(),60,"For 1 hours with reason "..AlertMessage)	
			end
		
		local cancel = vgui.Create("DButton",reportmsg)
			cancel:SetPos(230,65)
			cancel:SetSize(80,30)
			cancel:SetImage('icon16/cross.png')	
			cancel:SetText('Cancel')
			cancel.DoClick = function()
				if IsValid(reportmsg) then
					reportmsg:Close()
				end
			end
		end
		ban.OnCursorEntered = function()
			overban = Color(80,80,80,255)
		end
		ban.OnCursorExited = function()
			overban = Color(51,51,51,255)
		end
	
	plcommandbtn(plycommands2,6,85,'Freeze',"ulx","freeze",v:Nick())
	plcommandbtn(plycommands2,6,125,'Un Freeze',"ulx","unfreeze",v:Nick())
	plcommandbtn(plycommands2,6,165,'God',"ulx","god",v:Nick())
	plcommandbtn(plycommands2,6,205,'Un God',"ulx","ungod",v:Nick())
	plcommandbtn(plycommands2,6,245,'Jail',"ulx","jail",v:Nick())
	plcommandbtn(plycommands2,6,285,'Un Jail',"ulx","unjail",v:Nick())
	
	plcommandbtn(plycommands2,144,5,'Teleport',"ulx","teleport",v:Nick())
	plcommandbtn(plycommands2,144,45,'Bring',"ulx","bring",v:Nick())
	plcommandbtn(plycommands2,144,85,'Goto',"ulx","goto",v:Nick())
	plcommandbtn(plycommands2,144,125,'Strip',"ulx","strip",v:Nick())
	plcommandbtn(plycommands2,144,165,'Cloak',"ulx","cloak",v:Nick())
	plcommandbtn(plycommands2,144,205,'Un Cloak',"ulx","uncloak",v:Nick())
	plcommandbtn(plycommands2,144,245,'Slay',"ulx","slay",v:Nick())
	plcommandbtn(plycommands2,144,285,'Slap',"ulx","slap",v:Nick())
	
	plcommandbtn(plycommands2,280,5,'Mute',"ulx","mute",v:Nick())
	plcommandbtn(plycommands2,280,45,'Un Mute',"ulx","unmute",v:Nick())
	plcommandbtn(plycommands2,280,85,'Spectate',"ulx","spectate",v:Nick())

local oversetteam = Color(51,51,51,255)		
	local setteam = vgui.Create("DButton",plycommands2)
		setteam:SetPos(280,125)
		setteam:SetSize(130,35)
		setteam:SetFont('Commands')
		setteam:SetTextColor(Color(255,255,255))
		setteam:SetText('Set Team')	
		setteam.Paint = function()
			draw.RoundedBox(0,0,0,setteam:GetWide(),setteam:GetTall(),oversetteam)
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,setteam:GetWide(),setteam:GetTall())
		end
		setteam.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
		local menu = DermaMenu()
		local Title = vgui.Create("DLabel",bntsetteam)
		Title:SetText("  Teams:\n")
		Title:SetFont("UiBold")
		Title:SizeToContents()
		Title:SetTextColor(color_black)
			menu:AddPanel(Title)
			for k,pls in SortedPairsByMemberValue(team.GetAllTeams(), "Name") do
				menu:AddOption(pls.Name, function() RunConsoleCommand("_FAdmin", "setteam", v:Nick(), k) end)
			end
			menu:Open()
		end
		setteam.OnCursorEntered = function()
			oversetteam = Color(80,80,80,255)
		end
		setteam.OnCursorExited = function()
			oversetteam = Color(51,51,51,255)
		end	
		
		none = v:Nick()
		end	// End Do Click
		rowcom.OnCursorEntered = function()
			hover = Color(255,255,255,255)	
		end		
		rowcom.OnCursorExited = function()
			hover = Color(255,255,255,0)	
		end	
		
function rowcom:Think() 
	if not IsValid(v) then 
		self:Remove()
		if IsValid(plycommands2) then
			plycommands2:SetVisible(false)			
		end
	end	
end
end
		
// Server Button/Commands/Admins
	
	serverbg = vgui.Create("DPanel",bg)
		serverbg:SetPos(2,87)
		serverbg:SetSize(bg:GetWide()-4,bg:GetTall()-89)
		serverbg:SetVisible(false)
		serverbg.Paint = function()
			draw.RoundedBox(0,0,0,serverbg:GetWide(),serverbg:GetTall(),Color(25,25,25,50))
		end	
		
	local server = vgui.Create("DButton",buttonsbg)
		server:SetPos(buttonsbg:GetWide()-60,0)
		server:SetSize(55,55)
		server:SetToolTip("Change Server Settings")
		server:SetText("")
		server.Paint = function()
			surface.SetMaterial(serversettings)
			surface.SetDrawColor(255,255,255,255)
			surface.DrawTexturedRect(0,0,server:GetWide(),server:GetTall())
		end	
		server.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			if IsValid(serverbg) then
				serverbg:SetVisible(true)
			end	
			if IsValid(playersbg) then
				playersbg:SetVisible(false)
			end				
		end
		server.OnCursorEntered = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			server.Paint = function()
				surface.SetMaterial(serversettings)
				surface.SetDrawColor(255,255,255,255)
				surface.DrawTexturedRect(10,10,server:GetWide()/1.5,server:GetTall()/1.5)
			end
		end		
		server.OnCursorExited = function()
			server.Paint = function()
				surface.SetMaterial(serversettings)
				surface.SetDrawColor(255,255,255,255)
				surface.DrawTexturedRect(0,0,server:GetWide(),server:GetTall())
			end
		end		

// First Sbox Commands
	
	local sboxcommands = vgui.Create("DPanel",serverbg)
		sboxcommands:SetPos(5,2)
		sboxcommands:SetSize(serverbg:GetWide()/3.5,serverbg:GetTall()/2.05)
		sboxcommands.Paint = function()
			draw.RoundedBox(0,0,0,sboxcommands:GetWide(),sboxcommands:GetTall(),Color(37,104,134,200))
			
			surface.SetMaterial(backbeh)
			surface.SetDrawColor(255,255,255,150)
			surface.DrawTexturedRectUV( 0, 0, sboxcommands:GetWide(), 25, 0, 0, sboxcommands:GetWide()/32, 25/32 )
			
			draw.DrawText("Sbox Commands","Info",sboxcommands:GetWide()/2,5,Color(255,255,255),TEXT_ALIGN_CENTER)			
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,sboxcommands:GetWide(),sboxcommands:GetTall())
		end
	
	local sboxcom = vgui.Create("DScrollPanel",sboxcommands)
		sboxcom:SetPos(0,25)
		sboxcom:SetSize(sboxcommands:GetWide(),sboxcommands:GetTall()-25)		
	
	svcomcheck(sboxcom,5,"Enable/Disable Godmode","sbox_godmode")	
	svcomcheck(sboxcom,30,"Enable/Disable Noclip","sbox_noclip")	
	svcomcheck(sboxcom,55,"Enable/Disable PvP Damage","sbox_playershurtplayers")	
	svcomcheck(sboxcom,80,"Spawn With Weapons","sbox_weapons")	
	svcomcheck(sboxcom,105,"Limited Physgun","physgun_limited")	

// Server Commands

	local svcommands = vgui.Create("DPanel",serverbg)
		svcommands:SetPos(5,serverbg:GetTall()/2.3+25)
		svcommands:SetSize(serverbg:GetWide()/3.5,serverbg:GetTall()/2.05)
		svcommands.Paint = function()
			draw.RoundedBox(0,0,0,svcommands:GetWide(),svcommands:GetTall(),Color(37,104,134,200))
			
			surface.SetMaterial(backbeh)
			surface.SetDrawColor(255,255,255,150)
			surface.DrawTexturedRectUV( 0, 0, svcommands:GetWide(), 25, 0, 0, svcommands:GetWide()/32, 25/32 )
			
			draw.DrawText("Server Commands","Info",svcommands:GetWide()/2,5,Color(255,255,255),TEXT_ALIGN_CENTER)
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,svcommands:GetWide(),svcommands:GetTall())
		end	
		
	local svcom = vgui.Create("DScrollPanel",svcommands)
		svcom:SetPos(0,25)
		svcom:SetSize(svcommands:GetWide(),svcommands:GetTall()-25)	

	svcomcheck(svcom,5,"Allow CSLua","sv_allowcslua")
	svcomcheck(svcom,30,"Enable Voice Chat","sv_voiceenable")
	svcomcheck(svcom,55,"Disable AI","ai_disabled")
	svcomcheck(svcom,80,"AI Ignore Players","ai_ignoreplayers")
	svcomcheck(svcom,105,"Enable All Talk","sv_alltalk")
	svcomcheck(svcom,130,"Kick Player for Lua Errors","sv_kickerrornum")
		
// More Sbox Commands

	local sboxcommands2 = vgui.Create("DFrame",serverbg)
		sboxcommands2:SetPos(serverbg:GetWide()/3.5+10,3)
		sboxcommands2:SetSize(serverbg:GetWide()-serverbg:GetWide()/3.5-10,serverbg:GetTall()-6)
		sboxcommands2:SetTitle('')
		sboxcommands2:SetDraggable(false)
		sboxcommands2:ShowCloseButton(false)
		sboxcommands2.Paint = function()
			draw.RoundedBox(0,0,0,sboxcommands2:GetWide(),sboxcommands2:GetTall(),Color(37,104,134,200))
			
			surface.SetMaterial(backbeh)
			surface.SetDrawColor(255,255,255,150)
			surface.DrawTexturedRectUV( 0, 0, sboxcommands2:GetWide(), 25, 0, 0, sboxcommands2:GetWide()/32, 25/32 )
			
			draw.DrawText("Sbox Commands","Info",sboxcommands2:GetWide()/2,5,Color(255,255,255),TEXT_ALIGN_CENTER)			
			surface.SetDrawColor(0,0,0,255)
			surface.DrawOutlinedRect(0,0,sboxcommands2:GetWide(),sboxcommands2:GetTall())
		end
		
	local sboxcom2 = vgui.Create("DScrollPanel",sboxcommands2)
		sboxcom2:SetPos(0,25)
		sboxcom2:SetSize(sboxcommands2:GetWide(),sboxcommands2:GetTall()-25)

// First Row
	sboxcommandslid(sboxcom2,20,10,"Max Props",'sbox_maxprops')
	sboxcommandslid(sboxcom2,20,40,"Max Ballons",'sbox_maxballoons')
	sboxcommandslid(sboxcom2,20,70,"Max Dynamite",'sbox_maxdynamite')
	sboxcommandslid(sboxcom2,20,100,"Max Emitters",'sbox_maxemitters')
	sboxcommandslid(sboxcom2,20,130,"Max Lamps",'sbox_maxlamps')
	sboxcommandslid(sboxcom2,20,160,"Max NPCs",'sbox_maxnpcs')
	sboxcommandslid(sboxcom2,20,190,"Max Ragdolls",'sbox_maxragdolls')
	sboxcommandslid(sboxcom2,20,220,"Max Spawners",'sbox_maxspawners')
	sboxcommandslid(sboxcom2,20,250,"Max Turrets",'sbox_maxturrets')
	sboxcommandslid(sboxcom2,20,280,"Max Wheels",'sbox_maxwheels')

// Second Row

	sboxcommandslid(sboxcom2,sboxcom2:GetWide()-(sboxcom2:GetWide()/2.3+20),10,"Max Buttons",'sbox_maxbuttons')
	sboxcommandslid(sboxcom2,sboxcom2:GetWide()-(sboxcom2:GetWide()/2.3+20),40,"Max Effects",'sbox_maxeffects')
	sboxcommandslid(sboxcom2,sboxcom2:GetWide()-(sboxcom2:GetWide()/2.3+20),70,"Max HoverBalls",'sbox_maxhoverballs')
	sboxcommandslid(sboxcom2,sboxcom2:GetWide()-(sboxcom2:GetWide()/2.3+20),100,"Max Lights",'sbox_maxlights')
	sboxcommandslid(sboxcom2,sboxcom2:GetWide()-(sboxcom2:GetWide()/2.3+20),130,"Max Sents",'sbox_maxsents')
	sboxcommandslid(sboxcom2,sboxcom2:GetWide()-(sboxcom2:GetWide()/2.3+20),160,"Max Thrusters",'sbox_maxthrusters')
	sboxcommandslid(sboxcom2,sboxcom2:GetWide()-(sboxcom2:GetWide()/2.3+20),190,"Max Vehicles",'sbox_maxvehicles')
	
			end	// End Checking for admin button			
		end // End Players For Loop
	end // Check if it's valid
end) // End Scoreboard

hook.Add( 'ScoreboardHide', 'HideMe', function()
		gui.EnableScreenClicker(false)
		if bg and IsValid(bg) then
			bg:Remove()
		end
		if IsValid(plylist) then
			plylist:Remove()
		end
		if IsValid(shows) then
			shows:Remove()
		end
		if IsValid(webbg) then	
			webbg:Remove()
		end
		if IsValid(rulbg) then
			rulbg:Remove()
		end
		if IsValid(config) then
			config:Close()	
		end		
end)

timer.Simple(0.2, function()
	
	function GAMEMODE.ScoreboardShow()
	end

	function GAMEMODE.ScoreboardHide()
	end
end)
