if not CLIENT then return end

--The URL to your forums
SCOREBOARDADMIN_FORUMS = ""

--The URL to your Steam group
SCOREBOARDADMIN_STEAMGROUP = ""

--Commands in the user menu (each command has an icon and text, groups have a table of commands and commands have a function they run on click)
SCOREBOARDADMIN_USERCOMMANDS =
{
	{ text = "User", icon="user.png", commands = 
		{ { text = "View Profile", icon = "information.png", func = function(nick, id, id64) gui.OpenURL("http://steamcommunity.com/profiles/" .. id64) end }, { text = "Copy Steam ID", icon = "table_go.png", func = function(nick, id) SetClipboardText( id ) chat.AddText(Color(0, 255, 0), Format("Copied \"%s\" to clipboard.", id)) end  }, { text = "Copy Name", icon = "user_go.png", func = function(nick) SetClipboardText( nick ) chat.AddText(Color(0, 255, 0), Format("Copied \"%s\" to clipboard.", nick)) end  } } 
	},
	{},
	{ text = "PM", icon = "comment.png", func = function(nick) OpenCommandDialog({"ulx", "psay", nick}, Format("Enter your private message for %s...", nick)) end }
}

--Commands in the admin menu
SCOREBOARDADMIN_ADMINCOMMANDS =
{
	{ text = "User", icon="user.png", commands = 
		{ { text = "View Profile", icon = "information.png", func = function(nick, id, id64) gui.OpenURL("http://steamcommunity.com/profiles/" .. id64) end }, { text = "Copy Steam ID", icon = "table_go.png", func = function(nick, id) SetClipboardText( id ) chat.AddText(Color(0, 255, 0), Format("Copied \"%s\" to clipboard.", id)) end  }, { text = "Copy Name", icon = "user_go.png", func = function(nick) SetClipboardText( nick ) chat.AddText(Color(0, 255, 0), Format("Copied \"%s\" to clipboard.", nick)) end  } } 
	},
	{},
	{ text = "Gag", icon = "sound_mute.png" },
	{ text = "Mute", icon = "keyboard_delete.png", func = function(nick) RunConsoleCommand("ulx", "mute", nick) end },
	{ text = "Unmute", icon = "keyboard_add.png", func = function(nick) RunConsoleCommand("ulx", "unmute", nick) end },
	{},
	{ text = "PM", icon = "comment.png", func = function(nick) OpenCommandDialog({"ulx", "psay", nick}, Format("Enter your private message for %s...", nick)) end },
	{ text = "Chat", icon = "comments.png", func = function(nick) RunConsoleCommand("ulx", "chat", nick) end },
	{},
	{ text = "Slay", icon = "cross.png", func = function(nick) RunConsoleCommand("ulx", "slay", nick) end },
	{ text = "Teleport", icon="arrow_undo.png", commands = 
		{ { text = "Bring", icon = "arrow_left.png", func = function(nick) RunConsoleCommand("ulx", "bring", nick) end }, { text = "Teleport", icon = "arrow_down.png", func = function(nick) RunConsoleCommand("ulx", "teleport", nick) end }, { text = "Goto", icon = "arrow_right.png", func = function(nick) RunConsoleCommand("ulx", "goto", nick) end } } 
	},
	{},
	{ text = "Kick", icon = "door_out.png", func = function(nick) OpenCommandDialog( { "ulx", "kick", nick } , Format("Enter your reason for kicking %s...", nick ) ) end },
	{ text = "Ban", icon = "delete.png", func = function(nick) OpenBanDialog(nick) end }
}

--Which groups should access the admin menu, others will use the user menu
SCOREBOARDADMIN_ADMINGROUPS = { "moderator", "admin", "superadmin", "owner" }