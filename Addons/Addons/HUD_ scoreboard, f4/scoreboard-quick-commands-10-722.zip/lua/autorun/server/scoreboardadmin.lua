util.AddNetworkString("cl_getdisconnecters")
util.AddNetworkString("sv_senddisconnecters")

recentDisconnecters = {}

hook.Add("PlayerDisconnected", "TrackDisconnecters", function( ply )
	table.insert(recentDisconnecters, { ply:Nick(), ply:SteamID() })
	
	if #recentDisconnecters > 10 then
		table.remove(recentDisconnecters, 1)
	end
end)

net.Receive("cl_getdisconnecters", function( len, client )
	net.Start("sv_senddisconnecters")
		net.WriteTable(recentDisconnecters)
	net.Send(client)
end)