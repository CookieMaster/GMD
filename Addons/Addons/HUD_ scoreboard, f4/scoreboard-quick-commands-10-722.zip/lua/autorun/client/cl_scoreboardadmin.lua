function RightClickRow(ply)
	local menu = DermaMenu()
	local admin = PlayerInGroups(SCOREBOARDADMIN_ADMINGROUPS, LocalPlayer())
	local header = menu:AddOption(admin and "Admin Menu" or "User Menu")
	header:SetTextInset(10, 0)
	header.OnCursorEntered = function() end
	header.PaintOver = function() surface.SetDrawColor(0, 0, 0, 50) surface.DrawRect(0, 0, header:GetWide(), header:GetTall()) end
	menu:AddSpacer()
	menu:AddSpacer()
	
	if admin then --admin
		menu = PopulateMenu(menu, SCOREBOARDADMIN_ADMINCOMMANDS, ply)
	else --user
		menu = PopulateMenu(menu, SCOREBOARDADMIN_USERCOMMANDS, ply)
	end
	
	menu:Open()
end

function PopulateMenu(menu, commands, ply)
	for _,command in ipairs(commands) do
		if command.text == nil then menu:AddSpacer() continue end
	
		local row 
		if command.commands == nil then
			if command.text == "Gag" then
				if ply:IsMuted() then
					row = menu:AddOption("Ungag", function() RunConsoleCommand("ulx", "ungag", ply:Nick()) end)
					command.icon = "sound.png"
				else
					row = menu:AddOption("Gag", function() RunConsoleCommand("ulx", "gag", ply:Nick()) end)
					command.icon = "sound_mute.png"
				end
			elseif command.text == "Chat" and PCHAT == nil then continue 
			else
				row = menu:AddOption(command.text, function() command.func(ply:Nick(), ply:SteamID(), ply:SteamID64()) end)
			end
		else
			sub, row = menu:AddSubMenu(command.text)
			sub = PopulateMenu(sub, command.commands, ply)
		end
		row:SetIcon("icon16/" .. command.icon)
		row:SetTextInset(0, 0)
	end

	return menu
end

function OpenUserFunctions()
	local menu = DermaMenu()
	local header = menu:AddOption("User Functions")
	header:SetTextInset(10, 0)
	header.OnCursorEntered = function() end
	header.PaintOver = function() surface.SetDrawColor(0, 0, 0, 50) surface.DrawRect(0, 0, header:GetWide(), header:GetTall()) end
	menu:AddSpacer()
	menu:AddSpacer()
	
	local row = menu:AddOption("Message Admins", function() OpenCommandDialog({"ulx", "asay"}, "Enter your message to the admins...") end)
	row:SetIcon("icon16/shield.png")
	
	menu:AddSpacer()

	row = menu:AddOption("Print Damagelog", function() RunConsoleCommand("ttt_print_damagelog") end)
	row:SetIcon("icon16/application_xp_terminal.png")
	
	if sceneDummies != nil then
		row = menu:AddOption("Show Damagelog", function() RunConsoleCommand("ttt_show_damagelog") end)
		row:SetIcon("icon16/application_view_detail.png")
		
		row = menu:AddOption("Show Last Damagelog", function() RunConsoleCommand("ttt_show_lastdamagelog") end)
		row:SetIcon("icon16/application_side_contract.png")
	end
	
	menu:AddSpacer()
	
	sub, row = menu:AddSubMenu("Votemap")
	for _,map in pairs(ulx.votemaps) do
		local row = sub:AddOption(map, function() RunConsoleCommand("ulx", "votemap", map) end)
		row:SetTextInset(10, 0)
	end
	row:SetIcon("icon16/map_add.png")
	
	menu:AddSpacer()
	
	if SCOREBOARDADMIN_FORUMS != "" then
		row = menu:AddOption("View Forums", function() gui.OpenURL(SCOREBOARDADMIN_FORUMS) end)
		row:SetIcon("icon16/house.png")
	end
	
	if SCOREBOARDADMIN_STEAMGROUP != "" then
		row = menu:AddOption("Steam Group", function() gui.OpenURL(SCOREBOARDADMIN_STEAMGROUP) end)
		row:SetIcon("icon16/group.png")
	end
	
	menu:Open()	
end

function OpenAdminFunctions()
	local menu = DermaMenu()
	local header = menu:AddOption("Admin Functions")
	header:SetTextInset(10, 0)
	header.OnCursorEntered = function() end
	header.PaintOver = function() surface.SetDrawColor(0, 0, 0, 50) surface.DrawRect(0, 0, header:GetWide(), header:GetTall()) end
	menu:AddSpacer()
	menu:AddSpacer()
	
	local row = menu:AddOption("Ban by Steam ID", function() OpenBanIDDialog() end)
	row:SetIcon("icon16/delete.png")
	
	menu:AddSpacer()
	
	row = menu:AddOption("Gag All", function() RunConsoleCommand("ulx", "gag", "*") end)
	row:SetIcon("icon16/sound_mute.png")
	
	row = menu:AddOption("Ungag All", function() RunConsoleCommand("ulx", "ungag", "*") end)
	row:SetIcon("icon16/sound.png")
	
	menu:AddSpacer()
	
	row = menu:AddOption("Mute All", function() RunConsoleCommand("ulx", "mute", "*") end)
	row:SetIcon("icon16/keyboard_delete.png")
	
	row = menu:AddOption("Unmute All", function() RunConsoleCommand("ulx", "unmute", "*") end)
	row:SetIcon("icon16/keyboard.png")
	
	menu:AddSpacer()
	
	sub, row = menu:AddSubMenu("Change Map")
	for _,map in pairs(ulx.maps) do
		local row = sub:AddOption(map, function() RunConsoleCommand("ulx", "map", map) end)
		row:SetTextInset(10, 0)
	end
	row:SetIcon("icon16/map_go.png")
	
	menu:Open()	
end

function PlayerInGroups(groups, ply)
	if #groups == 0 then return true end
	for _,group in pairs(groups) do
		if ply:IsUserGroup(group) then return true end
	end
	return false
end

function OpenCommandDialog( cmd, prompt )
	local w,h = 400,60

	local frame = vgui.Create("DFrame")
	frame:SetSize(w, h)
	frame:SetTitle(prompt)
	frame:Center()
	frame.btnMaxim:SetVisible(false)
	frame.btnMinim:SetVisible(false)
	
	local text = vgui.Create("DTextEntry", frame)
	text:StretchToParent(5, 29, 5, 5)
	text.OnEnter = function()
		if #cmd == 3 then
			RunConsoleCommand( cmd[1], cmd[2], cmd[3], text:GetValue() )
		elseif #cmd == 2 then
			RunConsoleCommand( cmd[1], cmd[2], text:GetValue() )
		end
		frame:Remove()
		gui.EnableScreenClicker(false)
		GAMEMODE.ForcedMouse = false
	end
	text:RequestFocus()
	
	frame:MakePopup()
end

local discframe
local function OpenDisconnecterDialog( box )
	if discframe == nil or not discframe:IsVisible() then
		local w,h = 200,200
	
		discframe = vgui.Create("DFrame")
		discframe:SetSize(w, h)
		discframe:SetTitle("Recent Disconnecters")
		discframe:Center()
		discframe.btnMaxim:SetVisible(false)
		discframe.btnMinim:SetVisible(false)
		
		discframe.listview = vgui.Create("DListView", discframe)
		discframe.listview:StretchToParent(5, 29, 5, 30)
		discframe.listview:SetMultiSelect(false)
		discframe.listview:AddColumn("Name")
		discframe.listview:AddColumn("SteamID")
		
		discframe.btn = vgui.Create("DButton", discframe)
		discframe.btn:StretchToParent(5, 29 + discframe.listview:GetTall(), 5, 5)
		discframe.btn:SetText("Use Selected SteamID")
		discframe.btn.DoClick = function()
			local id = discframe.listview:GetSelectedLine()  != nil and discframe.listview:GetLine( discframe.listview:GetSelectedLine()  ):GetValue(2) or "No line selected!"
			box:SetValue( id )
			discframe:Remove()
		end
		
		discframe:MakePopup()
		
		net.Start("cl_getdisconnecters")
		net.SendToServer()
	end
end

net.Receive("sv_senddisconnecters", function()
	local discon = net.ReadTable()
	
	if discframe.listview != nil then
		for i = #discon, 1, -1 do
			info = discon[i]
			discframe.listview:AddLine(info[1], info[2])
		end
	end
end)

function OpenBanIDDialog( id )
	local w,h = 250,120
	
	local frame = vgui.Create("DFrame")
	frame:SetSize(w, h)
	frame:SetTitle("Banning by Steam ID...")
	frame:Center()
	frame.btnMaxim:SetVisible(false)
	frame.btnMinim:SetVisible(false)
	
	local int = "minute(s)"
	local timedropdown = vgui.Create("DComboBox", frame)
	timedropdown:SetValue(int)
	timedropdown:AddChoice("minute(s)")
	timedropdown:AddChoice("hour(s)")
	timedropdown:AddChoice("day(s)")
	timedropdown:AddChoice("week(s)")
	timedropdown:AddChoice("year(s)")
	timedropdown.OnSelect = function(ind, value, data)
		int = data
	end
	timedropdown:StretchToParent((frame:GetWide() / 2) + 2, 29, 5, 0)
	timedropdown:SetTall(25)
	timedropdown:SetPos(frame:GetWide() / 2 + 2, 29)
	
	local timebox = vgui.Create("DTextEntry", frame)
	timebox:SetValue("1")
	timebox:StretchToParent(5, 29, (frame:GetWide() / 2) + 2, 0)
	timebox:SetTall(25)
	
	local idbox = vgui.Create("DTextEntry", frame)
	idbox:SetValue("SteamID")
	idbox:SetPos(5, 29 + 5 + timebox:GetTall())
	idbox:SetSize(timebox:GetWide(), timebox:GetTall())
	if id != nil then
		idbox:SetText(id)
	end
	
	local recentbtn = vgui.Create("DButton", frame)
	recentbtn:SetText("Recent Disconnecters")
	recentbtn:SetPos(frame:GetWide() / 2 + 2, 29 + 5 + timebox:GetTall())
	recentbtn:SetSize(timebox:GetWide(), timebox:GetTall())
	recentbtn.DoClick = function()
		OpenDisconnecterDialog( idbox )
	end
	
	local reasonbox = vgui.Create("DTextEntry", frame)
	reasonbox.OnEnter = function()
		local time = timebox:GetValue()
		if time != 0 then
			if int == "hour(s)" then
				time = time .. "h"
			elseif int == "day(s)" then
				time = time .. "d"
			elseif int == "week(s)" then
				time = time .. "w"
			elseif int == "year(s)" then
				time = time .. "y"
			end
		end
		RunConsoleCommand("ulx", "banid", idbox:GetValue(), time, reasonbox:GetValue())
		frame:Remove()
	end
	reasonbox:StretchToParent(5, 29 + 5 + timebox:GetTall() + 5 + idbox:GetTall(), 5, 5)
	reasonbox:RequestFocus()
	
	frame:MakePopup()
end

function OpenBanDialog( nick )
	local w,h = 250,90
	
	local frame = vgui.Create("DFrame")
	frame:SetSize(w, h)
	frame:SetTitle("Banning " .. nick .. "...")
	frame:Center()
	frame.btnMaxim:SetVisible(false)
	frame.btnMinim:SetVisible(false)
	
	local int = "minute(s)"
	local timedropdown = vgui.Create("DComboBox", frame)
	timedropdown:SetValue(int)
	timedropdown:AddChoice("minute(s)")
	timedropdown:AddChoice("hour(s)")
	timedropdown:AddChoice("day(s)")
	timedropdown:AddChoice("week(s)")
	timedropdown:AddChoice("year(s)")
	timedropdown.OnSelect = function(ind, value, data)
		int = data
	end
	timedropdown:StretchToParent((frame:GetWide() / 2) + 2, 29, 5, 0)
	timedropdown:SetTall(25)
	timedropdown:SetPos(frame:GetWide() / 2 + 2, 29)
	
	local timebox = vgui.Create("DTextEntry", frame)
	timebox:SetValue("0")
	timebox:StretchToParent(5, 29, (frame:GetWide() / 2) + 2, 0)
	timebox:SetTall(25)
	
	local reasonbox = vgui.Create("DTextEntry", frame)
	reasonbox.OnEnter = function()
		local time = timebox:GetValue()
		if time != 0 then
			if int == "hour(s)" then
				time = time .. "h"
			elseif int == "day(s)" then
				time = time .. "d"
			elseif int == "week(s)" then
				time = time .. "w"
			elseif int == "year(s)" then
				time = time .. "y"
			end
		end
		RunConsoleCommand("ulx", "ban", nick, time, reasonbox:GetValue())
		frame:Remove()
	end
	reasonbox:StretchToParent(5, 29 + 5 + timebox:GetTall(), 5, 5)
	reasonbox:RequestFocus()
	
	frame:MakePopup()
end