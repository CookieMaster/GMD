INSTALLATION
------------
Copy the included folders in to your "garrysmod" directory. If your TTT sb_team.lua or sb_main.lua or DarkRP cl_controls.lua files are modified then contact me and I can merge them. Visit the settings file at /lua/autorun/scoreboardadmin_settings.lua to set your forums and Steam group URLs and customize anything else you need.

SUPPORT
------------
This addon was made by me, spykr, and will be supported and updated as long as it remains on CoderHire.
You can contact me on:
Steam (www.steamcommunity.com/id/spykr)
CoderHire (www.coderhire.com/profile/view/598)
Lockdown Gaming (www.lockdowngaming.org/forums/member.php?action=profile&uid=1)
