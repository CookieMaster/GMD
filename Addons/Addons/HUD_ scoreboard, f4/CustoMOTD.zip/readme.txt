1. Paste boo_motd in addons and it should work without problems.

3.How to add people on the contact page.
	- Open admins.html file
	- Go on http://steamidfinder.com/ there type your steamid.
	- You can find your steamid by going on a server and type in console status then find yourself and copy the steamid.
	- Then under the banner will be 4 options: Generate forum signature |  Add to Friends |  TF2 Items |  TF2 Stats
	- Click on " Generate forum signature " 
	- Copy the HTML for Websites.
	- It will look like this after you copy it and paste it in the file
<a href="http://steamprofile.com/" target="_blank"><img src="http://badges.steamprofile.com/profile/default/steam/76561198027129673.png" border="0" alt="Steamprofile badge by Steamprofile.com"></a>

	- You will have to organize it.
		- Press enter when the image start <img it should look like this
		- Press enter before closing the url </a>
		- Remove from the first line  target="_blank"
		- And to redirect it on that player steam page in the url which is http://steamprofile.com/ add id/ the player custom URL,
			if he have one if not just enter the Community URL which are a bunch of numbers.
<a href="http://steamprofile.com/" target="_blank">
<img src="http://badges.steamprofile.com/profile/default/steam/76561198027129673.png" border="0" alt="Steamprofile badge by Steamprofile.com">
</a>
	
	- Upload the admins.html file on your ftp and paste the link in boo_mod/lua/menu/gui_motd.lua
	- Open config.lua line 19 should be adminlink change the url with the one thats admins.html on.
	- That's how you add custom admins.
	


3.How to add text on the motd page.
	- Open motd.lua (located in boo_motd/menu/custom_motd folder)
	- Start writing inside what you want to be showed on the page.
	
4.How to add text on the rules page.
	- Open rules.lua (located in boo_motd/menu/custom_motd folder)
	- Start writing your rules.
	
5.FastDL
	- Paste the download.lua file in garrysmod/lua/autorun/server that has to be made on the server not on client.
	- Paste materials folder in <gamemode name>/content/
		and
	- Paste materials folder in garrysmod/ on the server not client.
	
6.To configure the motd open gui_motd.lua and at the top you have some things you can change.
