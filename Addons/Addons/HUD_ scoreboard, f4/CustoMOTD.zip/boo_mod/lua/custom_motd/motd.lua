MOTDLIST = [[
Updates

13.07.05 07.05.13

NEW Workshop addons can be downloaded when joining a server
NEW Added resource.AddWorkshop( workshopid )
FIX Fixed fonts being invisible on resolution change 
FIX Fixed crash when starting map 
FIX Fixed sound.PlayURL not always calling the callback properly 
UPT Banned 1,500 cheaters
]]