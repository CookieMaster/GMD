RULESLIST = [[General
_____________________________________________________________________________ 
1. It is advisable to buy property to stay in. This way, you wont be arrested when there is a Lockdown in effect.
2. You should try to obtain a gun liscense so you can buy bigger weapons without the police harassing you.
3. You may own a handgun without a license, as long as you use it for self-defense.
4. Do not RDM? other players. You might get banned.
5. If you want to keep a shipment of weapons or printers, make sure they're out of sight.

Citizen 
_____________________________________________________________________________
6. Try to stay out of other player's way.
7. You can set a custom job title, but beware of the server rules regarding jobs.
8. You cannot be demoted, but do not use that as an excuse to break rules. You are not immune to bans from the server.
9. Obey all laws set by the Mayor?.
10. You are not above the law. Yo?u can be arrested for breaking the rules.
11. Do not abuse your standard-issue handgun or arrest/unarrest batons, as well as your stun stick.
12. You don't need a gun liscense to own heavier weapons. In fact, it is advised to aquire heavier weapons to raid and protect the city. weapons to raid and protect the city.
13. Although some servers ban the use of weapons other than Standard Issue.
14. Do not abuse the want/unwant system. You may get demoted or banned.
15. The police do not work with theives.
16. Allow prisoners to make bail at your discretion.
17. You shouldn't own money printers.
18. You may take bribes but if caught you will be arrested.
19. You also may arrest people who give you bribes.

Police Chief 
_____________________________________________________________________________
20. Do not abuse goes double for you.
21. You have the ability to set the jail area on most servers.
22. You should lead the Police, not just farm the paycheck and do nothing.
23. Accompany the mayor to meetings with shady underground characters and the Mob.
24. You can help better arm the rest of the force by cooporating with a local gun dealer to sell shipments to the Police.
25. You can also cooporate with a medic/doctor to give discounted/free healing to wounded cops.

Police Chief 
_____________________________________________________________________________
20. Do not abuse goes double for you.
21. You have the ability to set the jail area on most servers.
22. You should lead the Police, not just farm the paycheck and do nothing.
23. Accompany the mayor to meetings with shady underground characters and the Mob.
24. You can help better arm the rest of the force by cooporating with a local gun dealer to sell shipments to the Police.
25. You can also cooporate with a medic/doctor to give discounted/free healing to wounded cops.]]