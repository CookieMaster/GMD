//	   Images 
//	Used in Motd
local grad_down = Material("gui/gradient_down.png")
local grad_up = Material("gui/gradient_up.png")
local grad = Material("gui/gradient.png")

//	   Colors 
//	Used in Motd	

	-- MOTD
motd_color = {
	background = Color(25,25,25,175),
	background2 = Color(31,142,213,250),	
	gradient = Color(255,255,255,50),
	back_clicked = Color(39,103,135,175),
	grad_clicked = Color(255,255,255,0)
}

rules_color = {
	background = Color(25,25,25,175),
	background2 = Color(31,142,213,250),	
	gradient = Color(255,255,255,50),
	back_clicked = Color(39,103,135,175),
	grad_clicked = Color(255,255,255,0)
}

website_color = {
	background = Color(25,25,25,175),
	background2 = Color(31,142,213,250),	
	gradient = Color(255,255,255,50),
	back_clicked = Color(39,103,135,175),
	grad_clicked = Color(255,255,255,0)
}

donate_color = {
	background = Color(25,25,25,175),
	background2 = Color(31,142,213,250),	
	gradient = Color(255,255,255,50),
	back_clicked = Color(39,103,135,175),
	grad_clicked = Color(255,255,255,0)
}

admin_color = {
	background = Color(25,25,25,175),
	background2 = Color(31,142,213,250),	
	gradient = Color(255,255,255,50),
	back_clicked = Color(39,103,135,175),
	grad_clicked = Color(255,255,255,0)
}

group_color = {
	background = Color(25,25,25,175),
	background2 = Color(31,142,213,250),	
	gradient = Color(255,255,255,50),
	back_clicked = Color(39,103,135,175),
	grad_clicked = Color(255,255,255,0)
}

accept_color = {
	background = Color(25,25,25,175),
	background2 = Color(31,142,213,250),
	gradient = Color(255,255,255,50),
	back_clicked = Color(39,103,135,175),
	grad_clicked = Color(255,255,255,0)
}

disconnect_color = {
	background = Color(25,25,25,175),
	background2 = Color(31,142,213,250),
	gradient = Color(255,255,255,50),
	back_clicked = Color(39,103,135,175),
	grad_clicked = Color(255,255,255,0)
}

function paint(name,color,text,texture)

	name.Paint = function()
		surface.SetDrawColor(color.gradient)
		surface.SetMaterial(grad_down)
		surface.DrawTexturedRect(1,1,name:GetWide()-1,name:GetTall())
	draw.RoundedBox(0,0,0,name:GetWide(),name:GetTall(),color.background)
	draw.RoundedBox(0,0,0,name:GetWide(),3,Color(128,128,128,50))	
	draw.DrawText(text,"General",name:GetWide()/2-25,name:GetTall()/2-12,color_white,TEXT_ALIGN_LEFT)
		surface.SetDrawColor(255,255,255,255)
		surface.SetMaterial(texture)
		surface.DrawTexturedRect(name:GetWide()/7-10,name:GetTall()/2-32,64,64)	
	end
	name.OnCursorEntered = function()
		surface.PlaySound("garrysmod/ui_return.wav")
		color.gradient = Color(255,255,255,125)			
	end
	name.OnCursorExited = function()
		surface.PlaySound("garrysmod/ui_return.wav")
		color.gradient = Color(255,255,255,50)			
	end
end

function Buttons()
/*-------------
Motd Button
--------------*/
	btnmotd = vgui.Create("BoButton",bg)
		btnmotd:SetSize(bg:GetWide()-1,bg:GetTall()/10)
		btnmotd:SetPos(-1,bg:GetTall()/9)
		paint(btnmotd,motd_color,BO.TxtMotd,BO.ImgMotd)
		btnmotd.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			btnmotd:SetDisabled(true)
			btnrules:SetDisabled(false)
			btnwebsite:SetDisabled(false)
			btndonate:SetDisabled(false)
			btnadmin:SetDisabled(false)
			btngroup:SetDisabled(false)
			
			if IsValid(motd) then motd:SetVisible(true) end			
			if IsValid(rules) then rules:SetVisible(false) end
			if IsValid(website) then website:SetVisible(false) end
			if IsValid(donate) then donate:SetVisible(false) end	
			if IsValid(adminbg) then adminbg:SetVisible(false) end	
			if IsValid(group) then group:SetVisible(false) end
			
			motd_color.background2 = motd_color.background2
			rules_color.background = Color(25,25,25,175)
			website_color.background = Color(25,25,25,175)
			donate_color.background = Color(25,25,25,175)
			admin_color.background = Color(25,25,25,175)	
			group_color.background = Color(25,25,25,175)			
		end
		
/*-------------
Rules Button
--------------*/

	btnrules = vgui.Create("BoButton",bg)
		btnrules:SetSize(bg:GetWide()-1,bg:GetTall()/10)
		btnrules:SetPos(-1,bg:GetTall()/4.8)
		paint(btnrules,rules_color,BO.TxtRules,BO.ImgRules)
		btnrules.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			btnrules:SetDisabled(true)
			btnmotd:SetDisabled(false)	
			btnwebsite:SetDisabled(false)
			btndonate:SetDisabled(false)
			btnadmin:SetDisabled(false)
			btngroup:SetDisabled(false)
			
			if IsValid(rules) then rules:SetVisible(true) end
			if IsValid(motd) then motd:SetVisible(false) end
			if IsValid(website) then website:SetVisible(false) end
			if IsValid(donate) then donate:SetVisible(false) end	
			if IsValid(adminbg) then adminbg:SetVisible(false) end	
			if IsValid(group) then group:SetVisible(false) end
			
			rules_color.background = rules_color.background2
			motd_color.background = Color(25,25,25,175)
			website_color.background = Color(25,25,25,175)
			donate_color.background = Color(25,25,25,175)
			admin_color.background = Color(25,25,25,175)
			group_color.background = Color(25,25,25,175)			
		end	 -- End Rules DoClick

/*-------------
How To play Button
--------------*/		

	btngroup = vgui.Create("BoButton",bg)
		btngroup:SetSize(bg:GetWide()-1,bg:GetTall()/10)
		btngroup:SetPos(-1,bg:GetTall()/3.25)
		paint(btngroup,group_color,BO.TxtGroup,BO.ImgGroup)	
		btngroup.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			btngroup:SetDisabled(true)
			btnmotd:SetDisabled(false)
			btnrules:SetDisabled(false)
			btnwebsite:SetDisabled(false)
			btndonate:SetDisabled(false)	
			
			if IsValid(group) then group:SetVisible(true) end					
			if IsValid(motd) then motd:SetVisible(false) end			
			if IsValid(rules) then rules:SetVisible(false) end
			if IsValid(website) then website:SetVisible(false) end
			if IsValid(donate) then donate:SetVisible(false) end	
			if IsValid(adminbg) then adminbg:SetVisible(false) end	
			
			group_color.background = group_color.background2
			motd_color.background = Color(25,25,25,175)
			rules_color.background = Color(25,25,25,175)
			website_color.background = Color(25,25,25,175)
			donate_color.background = Color(25,25,25,175)	
			admin_color.background = Color(25,25,25,175)
		end
		
/*-------------
Donate Button
--------------*/	

	btndonate = vgui.Create("BoButton",bg)
		btndonate:SetSize(bg:GetWide()-1,bg:GetTall()/10)
		btndonate:SetPos(-1,bg:GetTall()/2.47)
		paint(btndonate,donate_color,BO.TxtDonate,BO.ImgDonate)	
		btndonate.DoClick = function()
		gui.EnableScreenClicker(true)	
			surface.PlaySound("buttons/button9.wav")
			btndonate:SetDisabled(true)
			btnmotd:SetDisabled(false)
			btnrules:SetDisabled(false)
			btnwebsite:SetDisabled(false)
			btnadmin:SetDisabled(false)	
			btngroup:SetDisabled(false)		
			
			if IsValid(donate) then donate:SetVisible(true) end		
			if IsValid(motd) then motd:SetVisible(false) end
			if IsValid(rules) then rules:SetVisible(false) end
			if IsValid(website) then website:SetVisible(false) end
			if IsValid(adminbg) then adminbg:SetVisible(false) end
			if IsValid(group) then group:SetVisible(false) end
			
			donate_color.background = donate_color.background2
			motd_color.background = Color(25,25,25,175)
			rules_color.background = Color(25,25,25,175)
			website_color.background = Color(25,25,25,175)
			admin_color.background = Color(25,25,25,175)
			group_color.background = Color(25,25,25,175)
		end
		
/*-------------
Admin Button
--------------*/		

	btnadmin = vgui.Create("BoButton",bg)
		btnadmin:SetSize(bg:GetWide()-1,bg:GetTall()/10)
		btnadmin:SetPos(-1,bg:GetTall()/1.99)
		paint(btnadmin,admin_color,BO.TxtContact,BO.ImgContact)	
		btnadmin.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			btnadmin:SetDisabled(true)
			btnmotd:SetDisabled(false)
			btnrules:SetDisabled(false)
			btnwebsite:SetDisabled(false)
			btndonate:SetDisabled(false)	
			btngroup:SetDisabled(false)
			
			if IsValid(adminbg) then adminbg:SetVisible(true) end			
			if IsValid(motd) then motd:SetVisible(false) end			
			if IsValid(rules) then rules:SetVisible(false) end
			if IsValid(website) then website:SetVisible(false) end
			if IsValid(donate) then donate:SetVisible(false) end	
			if IsValid(group) then group:SetVisible(false) end	
			
			admin_color.background = admin_color.background2
			motd_color.background = Color(25,25,25,175)
			rules_color.background = Color(25,25,25,175)
			website_color.background = Color(25,25,25,175)
			donate_color.background = Color(25,25,25,175)	
			group_color.background = Color(25,25,25,175)
		end
		
/*-------------
WebSite Button
--------------*/

	btnwebsite = vgui.Create("BoButton",bg)
		btnwebsite:SetSize(bg:GetWide()-1,bg:GetTall()/10)
		btnwebsite:SetPos(-1,bg:GetTall()/1.68)
		paint(btnwebsite,website_color,BO.TxtWebSite,BO.ImgWeb)	
		btnwebsite.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			btnwebsite:SetDisabled(true)
			btnmotd:SetDisabled(false)
			btnrules:SetDisabled(false)
			btndonate:SetDisabled(false)
			btnadmin:SetDisabled(false)
			btngroup:SetDisabled(false)
			
			if IsValid(website) then website:SetVisible(true) end
			if IsValid(motd) then motd:SetVisible(false) end
			if IsValid(rules) then rules:SetVisible(false) end
			if IsValid(donate) then donate:SetVisible(false) end	
			if IsValid(adminbg) then adminbg:SetVisible(false) end	
			if IsValid(group) then group:SetVisible(false) end
			
			website_color.background = website_color.background2
			motd_color.background = Color(25,25,25,175)
			rules_color.background = Color(25,25,25,175)
			donate_color.background = Color(25,25,25,175)
			admin_color.background = Color(25,25,25,175)
			group_color.background = Color(25,25,25,175)			
		end

/*------------------------
Disconnect/Accept Button
-------------------------*/
closeat = CurTime()+BO.WaitTime
remaining = math.Round(closeat-CurTime())

if BO.TxtRemain == true then
	remain = vgui.Create("DLabel",bottom)
		remain:SetPos(15,15)
		remain:SetFont("General")
		remain:SetTextColor(color_white)
		remain:SetText(BO.TxtRemaining..""..remaining)	
		remain:SizeToContents()
		remain.Think = function()
			remaining = math.Round(closeat-CurTime())
			if remaining <= 0 then
				remaining = 0 
			end
			if remaining >= 10 then
				remain:SetText(BO.TxtRemaining..":"..remaining)		
			elseif remaining < 10 then
				remain:SetText(BO.TxtRemaining..":0"..remaining)
			elseif remaining <= 0 then
				remain:SetText(BO.TxtRemaining..":02")
			end
			remain:SizeToContents()	
		end
else
	BO.WaitTime = 0
end
		
	btnaccept = vgui.Create("BoButton",bg)
		btnaccept:SetSize(bg:GetWide()-1,bg:GetTall()/10)
		btnaccept:SetPos(0,bg:GetTall()/1.1)
		btnaccept:SetVisible(false)
			timer.Simple(BO.WaitTime, function()
			if IsValid(btnaccept) then btnaccept:SetVisible(true) end
			if IsValid(close) then close:SetVisible(true) end
			end)
		if closeat <= 0 then
			if IsValid(btnaccept) then btnaccept:SetVisible(true) end
			if IsValid(close) then close:SetVisible(true) end
		end
		btnaccept.Paint = function(self)
			surface.SetDrawColor(accept_color.gradient)
			surface.SetMaterial(grad_down)
			surface.DrawTexturedRect(1,1,self:GetWide()-2,self:GetTall())
		draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),accept_color.background)
		draw.RoundedBox(0,0,0,self:GetWide(),3,Color(128,128,128,50))	
		draw.DrawText(BO.TxtAgree,"General",self:GetWide()/2-25,self:GetTall()/2-12,color_white,TEXT_ALIGN_LEFT)
			surface.SetDrawColor(255,255,255,255)
			surface.SetMaterial(BO.ImgAgree)
			surface.DrawTexturedRect(self:GetWide()/7,self:GetTall()/2-32,64,64)	
		end
		btnaccept.OnCursorEntered = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			accept_color.gradient = Color(255,255,255,125)			
		end
		btnaccept.OnCursorExited = function()
			surface.PlaySound("garrysmod/ui_return.wav")
			accept_color.gradient = Color(255,255,255,50)			
		end
		btnaccept.DoClick = function()
			surface.PlaySound("buttons/button9.wav")
			gui.EnableScreenClicker(false)	
			if IsValid(bg) then bg:Close() end
			if IsValid(motd) then motd:SetVisible(false) end
			if IsValid(rules) then rules:SetVisible(false) end
			if IsValid(website) then website:SetVisible(false) end
			if IsValid(donate) then donate:SetVisible(false) end	
			if IsValid(adminbg) then adminbg:SetVisible(false) end	
			
			motd_color.background = Color(25,25,25,175)
			rules_color.background = Color(25,25,25,175)
			website_color.background = Color(25,25,25,175)
			donate_color.background = Color(25,25,25,175)	
			admin_color.background = Color(25,25,25,175)
		end
	if BO.WaitTime != 0 then	
		btndisconnect = vgui.Create("BoButton",bg)
			btndisconnect:SetSize(bg:GetWide()-1,bg:GetTall()/10)
			btndisconnect:SetPos(-1,bg:GetTall()/1.1)
			btndisconnect:SetVisible(true)
				timer.Simple(BO.WaitTime, function() 
					if IsValid(btndisconnect) then btndisconnect:SetVisible(false) end
				end)
			if closeat <= 0 then
				if IsValid(btndisconnect) then btndisconnect:SetVisible(false) end
			end
			paint(btndisconnect,disconnect_color,BO.TxtDiscconect,BO.ImgDiscconect)
			btndisconnect.DoClick = function()
				RunConsoleCommand("disconnect")
				chat.AddText(Color(200,50,50),LocalPlayer(),Color(255,255,255)," declined the rules and he was kicked.")
			end
	end
end