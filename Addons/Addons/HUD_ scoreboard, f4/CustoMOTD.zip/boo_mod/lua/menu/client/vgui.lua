--[[---------------------------------------------------------
		CUSTOM BUTTON
-----------------------------------------------------------]]
 
local grad_down = Material("gui/gradient_down.png")
local grad_circ = Material("vgui/entities/circlegrad.png")
local gradcol = Color(255,255,255,50)
local bgcol = Color(25,25,25,175)

local bgstar = Color(104,195,250,0)
local BUTTON = {}

--[[---------------------------------------------------------
		BUTTON INITIALIZE
-----------------------------------------------------------]]

function BUTTON:Init()
	
	self:SetTall(75)
	self:SetMouseInputEnabled(true)
	
	self:SetText("")
	self:SetFont("DermaDefault")
	self:SetTextColor(Color(255,255,255))
end

vgui.Register( "BoButton", BUTTON, "DButton" )

--[[---------------------------------------------------------
		CUSTOM FRAME
-----------------------------------------------------------]]
local grad = Material("gui/gradient.png")

local PANEL = {}

--[[---------------------------------------------------------
		BUTTON INITIALIZE
-----------------------------------------------------------]]

function PANEL:Init()

	self:SetSize(ScrW()/1.4,ScrH()/1.3)
	self:SetPos(ScrW()/2-ScrW()/3+100,ScrH()/2-ScrH()/3-50)	
	self:SetMouseInputEnabled(true)	
	self:SetTitle("")
	self:SetDraggable(false)
	self:ShowCloseButton(false)
	self:SetBackgroundBlur(true)
	self:SetVisible(false)
	
end

function PANEL:Paint()

	draw.RoundedBoxEx(8,0,0,self:GetWide(),30,Color(25,25,25,240),true,true,false,false)
	draw.RoundedBox(0,0,30,self:GetWide(),self:GetTall()-30,Color(25,25,25,220))
	surface.SetDrawColor(0,0,0,255)
	surface.DrawOutlinedRect(0,30,self:GetWide(),self:GetTall()-30)
	surface.SetDrawColor(Color(31,142,213,250))
	surface.SetMaterial(grad)
	surface.DrawTexturedRect(1,28,self:GetWide()-2,4)	
	
end

vgui.Register( "BoFrame", PANEL, "DFrame" )