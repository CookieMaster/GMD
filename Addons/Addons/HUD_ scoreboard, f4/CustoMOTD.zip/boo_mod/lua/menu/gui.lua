//	   Images 
//	Used in Motd
local grad_down = Material("gui/gradient_down.png")
local grad_up = Material("gui/gradient_up.png")
local grad = Material("gui/gradient.png")

-- 	   Fonts 
-- 	Used in Motd
surface.CreateFont( "Names", {
	font = "SquareFont",
	size = 45, 
	weight = 500,
	shadow = true
} )

surface.CreateFont( "General", {
	font = "SquareFont",
	size = 25, 
	weight = 600,
	shadow = true
} )

surface.CreateFont( "Top", {
	font = "TargetID",
	size = 15, 
	weight = 700,
	shadow = true
} )

function indent( message, nbrChar, first )
    if string.find(message,"<color=" ) then
                nbrChar = nbrChar + 25
        end
    local strTbl = string.Explode( "", message )
    for i=nbrChar,#strTbl,nbrChar do
        if strTbl[i] == " " then
            strTbl[i] = "\n"
        else
            for k=i,1,-1 do             
                if strTbl[k] == " " then
                    strTbl[k] = "\n"
                    break
                end
            end
        end
    end
	if first then
		return string.Explode("\n", table.concat(strTbl))
	else
		return table.concat(strTbl)
	end
 
end

net.Receive('open_menu', function() 
gui.EnableScreenClicker(true)

	bg = vgui.Create("DFrame")
		bg:SetSize(ScrW()/5.5,ScrH())
		bg:SetPos(0,0)
		bg:SetTitle("")
		bg:SetDraggable(false)
		bg:ShowCloseButton(false)
		bg:SetBackgroundBlur(true)
		bg.Paint = function(self)
			if ( self.m_bBackgroundBlur ) then
				Derma_DrawBackgroundBlur( self, self.m_fCreateTime )
			end	
				surface.SetDrawColor(255,255,255,50)
				surface.SetMaterial(grad_down)
				surface.DrawTexturedRect(1,1,self:GetWide()-2,self:GetTall())
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall(),Color(25,25,25,175))			
			draw.RoundedBox(0,0,0,self:GetWide(),self:GetTall()/9,Color(55,55,55,255))
				surface.SetDrawColor(255,255,255,50)
				surface.SetMaterial(grad_down)
				surface.DrawTexturedRect(1,1,self:GetWide()-2,50)
			draw.DrawText(BO.TxtOptions,"Names",self:GetWide()/2,35,color_white,TEXT_ALIGN_CENTER)
				surface.SetDrawColor(0,0,0,255)
				surface.DrawOutlinedRect(-1,0,self:GetWide()+1,self:GetTall())
		end
/*---------------------------
		Close Button
---------------------------*/	
if BO.CloseButton == true then
local closebtn = Color(199,80,80,255)	
	close = vgui.Create("DButton",bg)
		close:SetSize(45,20)
		close:SetPos(bg:GetWide()-50,0)
		close:SetFont("TargetID")
		close:SetText("X")
		close:SetVisible(false)
		close:SetTextColor(Color(255,255,255))
		close.Paint = function()
			draw.RoundedBoxEx(0,0,0,close:GetWide(),close:GetTall(),closebtn)
		end
		close.DoClick = function()
gui.EnableScreenClicker(false)	
			if IsValid(bg) then bg:Close() end	
			if IsValid(top) then top:Close() end	
			if IsValid(motd) then motd:Close() end	
			if IsValid(rules) then rules:Close() end	
			if IsValid(website) then website:Close() end	
			if IsValid(donate) then donate:Close() end	
			if IsValid(donlink) then donlink:Close() end	
			if IsValid(link) then link:Close() end	
			if IsValid(adminbg) then adminbg:Close() end	
			if IsValid(group) then group:Close() end	

			motd_color.background = Color(25,25,25,175)
			rules_color.background = Color(25,25,25,175)
			website_color.background = Color(25,25,25,175)
			donate_color.background = Color(25,25,25,175)	
			admin_color.background = Color(25,25,25,175)
			group_color.background = Color(25,25,25,175)
		end
		close.OnCursorEntered = function()
			closebtn = Color(230,65,65,255)
		end
		close.OnCursorExited = function()
			closebtn = Color(199,80,80,255)
		end	
end
	bottom = vgui.Create("DPanel",bg)
		bottom:SetSize(bg:GetWide(),bg:GetTall()/3)
		bottom:SetPos(0,bg:GetTall()/1.44)
		bottom.Paint = function()
			surface.SetDrawColor(255,255,255,50)
			surface.SetMaterial(grad_down)
			surface.DrawTexturedRect(1,1,bottom:GetWide()-2,bottom:GetTall())
			draw.RoundedBox(0,0,0,bottom:GetWide()-1,bottom:GetTall(),Color(25,25,25,175))
			draw.RoundedBox(0,0,1,bottom:GetWide()-1,3,Color(128,128,128,50))
		end
		
/*---------------------------
Create all the buttons Button
---------------------------*/

	if IsValid(Buttons()) then
		Buttons()
	end
	
/*---------------------------
	Create MOTD Page
---------------------------*/

	motd = vgui.Create("BoFrame")
		motd:MakePopup()
		
	local title = vgui.Create("DLabel",motd)
		title:SetPos(5,2)
		title:SetFont("General")
		title:SetTextColor(color_white)
		title:SetText("Message of the day")
		title:SizeToContents()
		
if BO.MotdHTMLPage == false then	
	
	local motdbg = vgui.Create("DScrollPanel",motd)
		motdbg:SetSize(motd:GetWide()-6,motd:GetTall()-35)
		motdbg:SetPos(3,32)
		motdbg.Paint = function()
			draw.RoundedBox(0,0,0,motdbg:GetWide(),motdbg:GetTall(),Color(0,0,0,0))
		end
		
motdtexts = string.Explode("\n", MOTDLIST)
	local id = 1
		for k,v in pairs(motdtexts) do      	   
			for a,b in pairs( indent(v, BO.maxcharacters, true)) do
				local motdtext = vgui.Create("DLabel",motdbg)
					motdtext:SetFont("ChatFont")
					motdtext:SetTextColor(color_white)
					motdtext:SetText(b)
					motdtext:SetPos(10 ,15 * id)
					motdtext:SizeToContents()
				id = id + 1
			end    
		end	
		
elseif BO.MotdHTMLPage == true then

	local mlink = vgui.Create("HTML",motd)
		mlink:SetSize(motd:GetWide()-2,motd:GetTall()-33)
		mlink:SetPos(1,32)
		mlink:OpenURL(BO.motdlink)

	local mcontrol = vgui.Create("DHTMLControls",motd)
		mcontrol:SetSize(motd:GetWide(),35)
		mcontrol:SetHTML(mlink)
		mcontrol.BackButton:SetVisible(false)
		mcontrol.ForwardButton:SetVisible(false)
		mcontrol.RefreshButton:SetVisible(false)
		mcontrol.AddressBar:SetValue(BO.motdlink)
		mcontrol.HomeButton.DoClick = function() 
			mlink:OpenURL(BO.motdlink)
		end
		mcontrol.StopButton.DoClick = function()
			if IsValid(motd) then
				motd:SetVisible(false)
			end
		end			
end		
/*---------------------------
	Create RULES Page
---------------------------*/

	rules = vgui.Create("BoFrame")
		rules:MakePopup()
	
	local title = vgui.Create("DLabel",rules)
		title:SetPos(5,2)
		title:SetFont("General")
		title:SetTextColor(color_white)
		title:SetText("Rules")
		title:SizeToContents()

if BO.RulesHTMLPage == false then

	local rulesbg = vgui.Create("DScrollPanel",rules)
		rulesbg:SetSize(rules:GetWide()-6,rules:GetTall()-35)
		rulesbg:SetPos(3,32)
		rulesbg.Paint = function()
			draw.RoundedBox(0,0,0,rulesbg:GetWide(),rulesbg:GetTall(),Color(0,0,0,0))
		end
		
rulestexts = string.Explode("\n", RULESLIST)
	local id = 1
		for k,v in pairs(rulestexts) do      	   
			for a,b in pairs( indent(v, BO.maxcharacters, true)) do
				local rultext = vgui.Create("DLabel",rulesbg)
					rultext:SetFont("TargetID")
					rultext:SetTextColor(color_white)
					rultext:SetText(b)
					rultext:SetPos(5 ,15 * id)
					rultext:SizeToContents()
				id = id + 1
			end    
		end	
		
elseif BO.RulesHTMLPage == true then

	local rlink = vgui.Create("HTML",rules)
		rlink:SetSize(rules:GetWide()-2,rules:GetTall()-33)
		rlink:SetPos(1,32)
		rlink:OpenURL(BO.ruleslink)

	local rcontrol = vgui.Create("DHTMLControls",rules)
		rcontrol:SetSize(rules:GetWide(),35)
		rcontrol:SetHTML(rlink)
		rcontrol.BackButton:SetVisible(false)
		rcontrol.ForwardButton:SetVisible(false)
		rcontrol.RefreshButton:SetVisible(false)
		rcontrol.AddressBar:SetValue(BO.ruleslink)
		rcontrol.HomeButton.DoClick = function() 
			rlink:OpenURL(BO.ruleslink)
		end
		rcontrol.StopButton.DoClick = function()
			if IsValid(rules) then
				rules:SetVisible(false)
			end
		end			
end	
/*---------------------------
	Create SteamGroup Page
---------------------------*/

	group = vgui.Create("BoFrame")
		group:MakePopup()
	
	local title = vgui.Create("DLabel",group)
		title:SetPos(5,2)
		title:SetFont("General")
		title:SetTextColor(color_white)
		title:SetText("Steam Group")
		title:SizeToContents()

	local glink = vgui.Create("HTML",group)
		glink:SetSize(group:GetWide()-2,group:GetTall()-33)
		glink:SetPos(1,32)
		glink:OpenURL(BO.grouplink)

	local gcontrol = vgui.Create("DHTMLControls",group)
		gcontrol:SetSize(group:GetWide(),35)
		gcontrol:SetHTML(glink)
		gcontrol.BackButton:SetVisible(false)
		gcontrol.ForwardButton:SetVisible(false)
		gcontrol.RefreshButton:SetVisible(false)
		gcontrol.AddressBar:SetValue(BO.grouplink)
		gcontrol.HomeButton.DoClick = function() 
			glink:OpenURL(BO.grouplink)
		end
		gcontrol.StopButton.DoClick = function()
			if IsValid(group) then
				group:SetVisible(false)
			end
		end	
		
/*---------------------------
	Create WebSite Page
---------------------------*/

	website = vgui.Create("BoFrame")
		website:MakePopup()
		
	local link = vgui.Create("HTML",website)
		link:SetSize(website:GetWide()-2,website:GetTall()-33)
		link:SetPos(1,32)
		link:OpenURL(BO.websitelink)

	local control = vgui.Create("DHTMLControls",website)
		control:SetSize(website:GetWide(),35)
		control:SetHTML(link)
		control.BackButton:SetVisible(false)
		control.ForwardButton:SetVisible(false)
		control.RefreshButton:SetVisible(false)
		control.AddressBar:SetValue(BO.websitelink)
		control.HomeButton.DoClick = function() 
			link:OpenURL(BO.websitelink)
		end
		control.StopButton.DoClick = function()
			if IsValid(website) then
				website:SetVisible(false)
			end
		end	
		
/*---------------------------
	Create Donation Page
---------------------------*/

	donate = vgui.Create("BoFrame")
		donate:MakePopup()
		
	local donlink = vgui.Create("HTML",donate)
		donlink:SetSize(donate:GetWide()-2,donate:GetTall()-33)
		donlink:SetPos(1,32)
		donlink:OpenURL(BO.donatelink)

	local doncontrol = vgui.Create("DHTMLControls",donate)
		doncontrol:SetSize(donate:GetWide(),35)
		doncontrol:SetHTML(donlink)
		doncontrol.BackButton:SetVisible(false)
		doncontrol.ForwardButton:SetVisible(false)
		doncontrol.RefreshButton:SetVisible(false)
		doncontrol.AddressBar:SetValue(BO.donatelink)
		doncontrol.HomeButton.DoClick = function() 
			donlink:OpenURL(BO.donatelink)
		end
		doncontrol.StopButton.DoClick = function()
			if IsValid(donate) then
				donate:SetVisible(false)
			end
		end

/*---------------------------
	Create Admin Page
---------------------------*/

	adminbg = vgui.Create("BoFrame")
		adminbg:MakePopup()
		
	local admlink = vgui.Create("HTML",adminbg)
		admlink:SetSize(adminbg:GetWide()-2,adminbg:GetTall()-33)
		admlink:SetPos(1,32)
		admlink:OpenURL(BO.adminlink)

	local admcontrol = vgui.Create("DHTMLControls",adminbg)
		admcontrol:SetSize(adminbg:GetWide(),35)
		admcontrol:SetHTML(admlink)
		admcontrol.BackButton:SetVisible(false)
		admcontrol.ForwardButton:SetVisible(false)
		admcontrol.RefreshButton:SetVisible(false)
		admcontrol.AddressBar:SetValue(BO.adminlink)
		admcontrol.HomeButton.DoClick = function() 
			admlink:OpenURL(BO.adminlink)
		end
		admcontrol.StopButton.DoClick = function()
			if IsValid(adminbg) then
				adminbg:SetVisible(false)
			end
		end	
end)