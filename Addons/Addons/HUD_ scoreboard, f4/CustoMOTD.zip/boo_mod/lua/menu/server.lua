
util.AddNetworkString('open_menu')

function PlayerJoin(ply)
	net.Start('open_menu')
	net.Send(ply)
end
hook.Add( "PlayerInitialSpawn", "playerInitialSpawn", PlayerJoin )

function OpenCommandWithChat(ply,text)
	if string.sub(text,1,5) == "!motd" then
		net.Start('open_menu')
		net.Send(ply)
	end
end
hook.Add("PlayerSay", "ConToOpenMotd", OpenCommandWithChat)