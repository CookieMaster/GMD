include("client/buttons.lua")
include("gui.lua")

BO = BO or {}

-- Enable/Disable
BO.MotdHTMLPage = true					// True/False : True if you want to use HTML page instead of text and false if you want to use text.
BO.RulesHTMLPage = false					// True/False : True if you want to use HTML page instead of text and false if you want to use text.
BO.CloseButton = true					// True/False : True if you want to see the close button and false if you don't.

BO.TxtRemain = true					// True/False : True if you want to see the text and false if you don't.

-- Links
BO.motdlink = "https://www.paypal.com/uk/webapps/mpp/home"			// Set Motd Link
BO.ruleslink = "http://google.com"									// Set Rules Link
BO.grouplink = "http://steamcommunity.com"							// Set SteamGroup Link
BO.websitelink = "http://coderhire.com"								// Set WebSite Link
BO.donatelink = "http://steamcommunity.com/id/boowman"				// Set Donate Link
BO.adminlink = "http://loading.pixub.com/loading/admins.html"		// Set Admin Link

-- Other
BO.WaitTime = 25					// Set the wait time until the player can press accept. If BO.TxtRemain is set to false this will automatically be set to 0.
BO.maxcharacters = 132				// Set Max Characters for a row.

-- Button Text Name
BO.TxtMotd = "Motd"					// Set First Button Name							
BO.TxtRules = "Rules"				// Set Second Button Name
BO.TxtGroup = "Steam Group"			// Set First Button Name
BO.TxtWebSite = "Web-Site"			// Set Third Button Name
BO.TxtDonate = "Donate"				// Set Fourth Button Name
BO.TxtContact = "Contact"			// Set First Button Name
BO.TxtAgree = "I AGREE!"			// Set Fifth Button Name
BO.TxtDiscconect = "Disconnect"		// Set Sixth Button Name
BO.TxtOptions = "OPTIONS"			// Set the title name
BO.TxtRemaining = "Remaining: 00"	// Set the Remaining name

-- Button Icons
BO.ImgMotd = Material("vgui/entities/motd.png")
BO.ImgRules = Material("vgui/entities/rules.png")
BO.ImgWeb = Material("vgui/entities/web.png")
BO.ImgDonate = Material("vgui/entities/donate.png")
BO.ImgContact = Material("vgui/entities/contact.png")
BO.ImgGroup = Material("vgui/entities/group.png")
BO.ImgAgree = Material("vgui/entities/home.png")
BO.ImgDiscconect = Material("vgui/entities/discc.png")