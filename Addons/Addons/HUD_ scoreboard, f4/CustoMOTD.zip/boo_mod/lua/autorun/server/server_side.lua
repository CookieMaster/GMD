	AddCSLuaFile("autorun/client/client_side.lua")
	
	AddCSLuaFile("menu/client/vgui.lua")
	AddCSLuaFile("menu/client/buttons.lua")
	
	AddCSLuaFile("menu/gui.lua")
	AddCSLuaFile("menu/config.lua")
	
	AddCSLuaFile("custom_motd/motd.lua")
	AddCSLuaFile("custom_motd/rules.lua")

	include("menu/server.lua")