	include("menu/client/vgui.lua")
	include("menu/client/buttons.lua")
	
	include("menu/gui.lua")
	include("menu/config.lua")
	
	include("custom_motd/motd.lua")
	include("custom_motd/rules.lua")