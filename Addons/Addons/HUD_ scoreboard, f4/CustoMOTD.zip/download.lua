
resource.AddFile("materials/vgui/entities/contact.png")
resource.AddFile("materials/vgui/entities/discc.png")
resource.AddFile("materials/vgui/entities/donate.png")
resource.AddFile("materials/vgui/entities/home.png")
resource.AddFile("materials/vgui/entities/motd.png")
resource.AddFile("materials/vgui/entities/rules.png")
resource.AddFile("materials/vgui/entities/web.png")
resource.AddFile("materials/vgui/entities/group.png")
resource.AddFile("materials/vgui/entities/circlegrad.png")


resource.AddFile("resource/fonts/Square")
resource.AddFile("resource/fonts/Square.ttf")