Thank you for buying this script!

All you have to do is go in to scoreboarddonatesystem\lua\autorun edit the top of the scoreboard.lua and upload the scoreboarddonatesystem folder to your 
server addons folder. If you want to use custom rank names/colors then follow the instruction below before uploading this addon to your server.

If you decide to use custom rank names/colors then go into the scoreboard.lua file, set CustomRankEnabled to true and then copy sb_row to gamemodes/terrortown/gamemode/vgui . If you don't do both of these things this script will not work correctly!

If you need any help or run in to any problems feel free to PM Android on Steam at http://steamcommunity.com/profiles/76561198066595656