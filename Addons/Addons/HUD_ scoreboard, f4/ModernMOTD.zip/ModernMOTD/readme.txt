Thanks for purchasing ModernMOTD!
-----------------------------------------
There's not much here, since ModernMOTD was built from the ground up to be super configurable and easy to customize!

Installation
---------------
Unzip the download, and put ModernMOTD into the addons folder
If you use FastDL on your server, add the materials/resource/sound folders to your FastDL directory
Resources inside the addon are added automatically

Configuration
--------------
Configure core MOTD settings, text, colors etc.  -- lua/sh_modernconfig.lua
Configure MOTD Tabs add,modify,remove tabs etc. -- lua/cl_addtabs.lua
Configure MOTD Server List/Portal add,modify,remove servers etc. -- lua/cl_addservers.lua

Need more help?
Steam: http://steamcommunity.com/id/chuteuk/
Skype: Chuteuk