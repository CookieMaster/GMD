-- HUD HUD HUD

local table = table
local surface = surface
local draw = draw
local math = math
local string = string

local GetTranslation = LANG.GetTranslation
local GetPTranslation = LANG.GetParamTranslation
local GetLang = LANG.GetUnsafeLanguageTable
local interp = string.Interp

-- Fonts
surface.CreateFont("TraitorState", {font = "Trebuchet24",
                                    size = 28,
                                    weight = 1000})
surface.CreateFont("TimeLeft",     {font = "Trebuchet24",
                                    size = 24,
                                    weight = 800})
surface.CreateFont("HealthAmmo",   {font = "Trebuchet24",
                                    size = 24,
                                    weight = 750})
									
surface.CreateFont( "ilya_ttt_misc", {font = "Calibri",size = 15,weight = 1} )
									
function surface.DrawTrapezoid( x, y, w, h, col, a)
	local t = {
		{ x = x, y = y, u = 0, v = 0},
		{ x = x+w, y = y, u = 1, v = 0},
		{ x = x+w+a, y = y+h, u = 0, v = 1},
		{ x = x+a, y = y+h, u = 1, v = 1}
	}
	
	surface.SetMaterial(Material("vgui/white"))
	surface.SetDrawColor(col)
	surface.DrawPoly(t)
end

function surface.GetFullTextSize( font, text)
	surface.SetFont(font)
	return surface.GetTextSize(text)
end

									
-- Color presets
local bg_colors = {
   background_main = Color(0, 0, 10, 200),

   noround = Color(100,100,100,200),
   traitor = Color(232, 100, 100),
   innocent = Color(100, 232, 162),
   detective = Color(100, 142, 232)
};

local health_colors = {
   border = COLOR_WHITE,
   background = Color(100, 25, 25, 222),
   fill = Color(200, 50, 50, 250)
};

local ammo_colors = {
   border = COLOR_WHITE,
   background = Color(20, 20, 5, 222),
   fill = Color(205, 155, 0, 255)
};


-- Modified RoundedBox
local Tex_Corner8 = surface.GetTextureID( "gui/corner8" )
local function RoundedMeter( bs, x, y, w, h, color)
   surface.SetDrawColor(clr(color))

   surface.DrawRect( x+bs, y, w-bs*2, h )
   surface.DrawRect( x, y+bs, bs, h-bs*2 )

   surface.SetTexture( Tex_Corner8 )
   surface.DrawTexturedRectRotated( x + bs/2 , y + bs/2, bs, bs, 0 )
   surface.DrawTexturedRectRotated( x + bs/2 , y + h -bs/2, bs, bs, 90 )

   if w > 14 then
      surface.DrawRect( x+w-bs, y+bs, bs, h-bs*2 )
      surface.DrawTexturedRectRotated( x + w - bs/2 , y + bs/2, bs, bs, 270 )
      surface.DrawTexturedRectRotated( x + w - bs/2 , y + h - bs/2, bs, bs, 180 )
   else
      surface.DrawRect( x + math.max(w-bs, bs), y, bs/2, h )
   end

end

---- The bar painting is loosely based on:
---- http://wiki.garrysmod.com/?title=Creating_a_HUD

-- Paints a graphical meter bar
local function PaintBar(x, y, w, h, colors, value)
   -- Background
   -- slightly enlarged to make a subtle border
   draw.RoundedBox(8, x-1, y-1, w+2, h+2, colors.background)

   -- Fill
   local width = w * math.Clamp(value, 0, 1)

   if width > 0 then
      RoundedMeter(8, x, y, width, h, colors.fill)
   end
end

local roundstate_string = {
   [ROUND_WAIT]   = "round_wait",
   [ROUND_PREP]   = "round_prep",
   [ROUND_ACTIVE] = "round_active",
   [ROUND_POST]   = "round_post"
};

-- Returns player's ammo information
local function GetAmmo(ply)
   local weap = ply:GetActiveWeapon()
   if not weap or not ply:Alive() then return -1 end

   local ammo_inv = weap:Ammo1()
   local ammo_clip = weap:Clip1()
   local ammo_max = weap.Primary.ClipSize

   return ammo_clip, ammo_max, ammo_inv
end

local function DrawBg(x, y, width, height, client)
   -- Traitor area sizes
   local th = 30
   local tw = 170

   -- Adjust for these
   y = y - th
   height = height + th

   -- main bg area, invariant
   -- encompasses entire area
   draw.RoundedBox(8, x, y, width, height, bg_colors.background_main)

   -- main border, traitor based
   local col = bg_colors.innocent
   if GAMEMODE.round_state != ROUND_ACTIVE then
      col = bg_colors.noround
   elseif client:GetTraitor() then
      col = bg_colors.traitor
   elseif client:GetDetective() then
      col = bg_colors.detective
   end

   draw.RoundedBox(8, x, y, tw, th, col)
end

local sf = surface
local dr = draw

local function ShadowedText(text, font, x, y, color, xalign, yalign)

   dr.SimpleText(text, font, x+2, y+2, COLOR_BLACK, xalign, yalign)

   dr.SimpleText(text, font, x, y, color, xalign, yalign)
end

local margin = 10

-- Paint punch-o-meter
local function PunchPaint(client)
   local L = GetLang()
   local punch = client:GetNWFloat("specpunches", 0)

   local width, height = 200, 25
   local x = ScrW() / 2 - width/2
   local y = margin/2 + height

   surface.DrawTrapezoid( x-22, y-1, width+4, height+2, ammo_colors.background, 40)
   width = width * math.Clamp(punch, 0, 1)
   surface.DrawTrapezoid( x-20, y, width, height, ammo_colors.fill, 39)

   local color = bg_colors.background_main

   dr.SimpleText(L.punch_title, "HealthAmmo", ScrW() / 2, y, color, TEXT_ALIGN_CENTER)

   dr.SimpleText(L.punch_help, "TabLarge", ScrW() / 2, margin, COLOR_WHITE, TEXT_ALIGN_CENTER)

   local bonus = client:GetNWInt("bonuspunches", 0)
   if bonus != 0 then
      local text
      if bonus < 0 then
         text = interp(L.punch_bonus, {num = bonus})
      else
         text = interp(L.punch_malus, {num = bonus})
      end

      dr.SimpleText(text, "TabLarge", ScrW() / 2, y * 2, COLOR_WHITE, TEXT_ALIGN_CENTER)
   end
end

local key_params = { usekey = Key("+use", "USE") }

local function SpecHUDPaint(client)
   local L = GetLang() -- for fast direct table lookups 
 
   -- Draw round state
   local x       = margin
   local height  = 32
   local width   = 250
   local round_y = ScrH() - height - margin
   local pos_fix = 20

   -- move up a little on low resolutions to allow space for spectator hints
   if ScrW() < 1000 then round_y = round_y - 15 end

   local time_x = x + 170
   local time_y = round_y + 4
   
   surface.DrawTrapezoid( x, round_y, width, height, bg_colors.background_main, 40)
   surface.DrawTrapezoid( x, round_y, time_x - x, height, bg_colors.noround, 40)

   local text = L[ roundstate_string[GAMEMODE.round_state] ]
   ShadowedText(text, "TraitorState", x + margin + pos_fix, round_y, COLOR_WHITE)

   -- Draw round/prep/post time remaining
   local text = util.SimpleTime(math.max(0, GetGlobalFloat("ttt_round_end", 0) - CurTime()), "%02i:%02i")
   ShadowedText(text, "TimeLeft", time_x + margin + pos_fix, time_y, COLOR_WHITE)

   local tgt = client:GetObserverTarget()
   if IsValid(tgt) and tgt:IsPlayer() then
      ShadowedText(tgt:Nick(), "TimeLeft", ScrW() / 2, margin + pos_fix, COLOR_WHITE, TEXT_ALIGN_CENTER)

   elseif IsValid(tgt) and tgt:GetNWEntity("spec_owner", nil) == client then
      PunchPaint(client)
   else
      ShadowedText(interp(L.spec_help, key_params), "TabLarge", ScrW() / 2, margin, COLOR_WHITE, TEXT_ALIGN_CENTER)
   end

end

local ttt_health_label = CreateClientConVar("ttt_health_label", "0", true)

local SWEP_names = {
	["weapon_zm_improvised"] = "Crowbar",	
	["weapon_zm_carry"] = "Magneto-Stick",	
	["weapon_ttt_unarmed"] = "Holster",	
	["weapon_ttt_ak47"] = "AK-47",	
	["weapon_ttt_aug"] = "AUG",	
	["weapon_zm_mac10"] = "Mac10",	
	["weapon_ttt_44mag"] = ".44 Magnum",	
	["weapon_ttt_beacon"] = "Beacon",	
	["weapon_zm_revolver"] = "Deagle",	
	["weapon_ttt_l96aw"] = "L96A1",	
	["weapon_ttt_m16"] = "M16",	
	["weapon_ttt_g3sg1"] = "G3SG1",	
	["weapon_ttt_ump"] = "UMP",	
	["weapon_zm_rifle"] = "Rifle",	
	["weapon_ttt_p90"] = "P90",	
	["weapon_ttt_870"] = "Remington 870",	
	["weapon_zm_sledge"] = "HUGE-249",	
	["weapon_ttt_870"] = "Remington 870",	
	["weapon_ttt_mp5"] = "MP5",	
	["weapon_ttt_galil"] = "Galil",	
	["weapon_ttt_sg550"] = "SG550",	
	["weapon_zm_shotgun"] = "Shotgun",	
	["weapon_zm_pistol"] = "Pistol",	
	["weapon_ttt_glock"] = "Glock",	
	["weapon_ttt_smokegrenade"] = "Smoke Grenade",	
	["weapon_zm_molotov"] = "Incendiary Grenade",	
	["weapon_ttt_confgrenade"] = "Discombobulator"
}

local TTTHUD = {}

function TTTHUD:Paint( w, h )
	local ply = LocalPlayer()
	if not ply:IsValid() then return end
	if (not ply:Alive()) or ply:Team() == TEAM_SPEC then return end
	
	local round_state = GAMEMODE.round_state
	local endtime = GetGlobalFloat("ttt_round_end", 0) - CurTime()
	local SWEP = ply:GetActiveWeapon()
	local is_haste = HasteMode() and round_state == ROUND_ACTIVE
	local is_traitor = ply:IsActiveTraitor()
	
	local swepname = swepname or ""
	local clip1 = clip1 or 0
	local clip1left = clip1left or 0
	
	if SWEP:IsValid() then
		local clip1type = SWEP:GetPrimaryAmmoType() or ""
		clip1 = tonumber(SWEP:Clip1()) or 0
		clip1left = ply:GetAmmoCount(clip1type)
		swepname = SWEP_names[SWEP:GetClass()] or "UNKNOWN"
	else
		clip1 = 0
		clip1left = 0
		swepname = "NOTHING"
	end
	if clip1 == -1 then clip1 = 0 end
	
	local col = Color(210,210,210)
	local role = "Innocent"
	
	if ply:GetRole() == ROLE_TRAITOR then
		col = bg_colors.traitor
		role = "Traitor"
	elseif ply:GetRole() == ROLE_DETECTIVE then
		col = bg_colors.detective
		role = "Detective"
	else
		col = bg_colors.innocent
	end
	
	local COL = Color(255,255,255)
	local text = ""
	if is_haste then
		local hastetime = GetGlobalFloat("ttt_haste_end", 0) - CurTime()
		if hastetime < 0 then
			if (not is_traitor) or (math.ceil(CurTime()) % 7 <= 2) then
				text = "OVERTIME"
			else
				text = string.ToMinutesSecondsMilliseconds(math.Round(endtime, 2))
				COL = Color(255,100,100)
			end
		else
			local t = hastetime
			if is_traitor and math.ceil(CurTime()) % 6 < 2 then
				t = endtime
				COL = Color(255,100,100)
			end
			text = string.ToMinutesSecondsMilliseconds(math.Round(t, 2))
		end
	else
		text = string.ToMinutesSecondsMilliseconds(math.Round(endtime, 2))
	end
	
	
	-- time
	local ww, hh = surface.GetFullTextSize( "ilya_ttt_misc", text)
	surface.DrawTrapezoid( 120, h-115+53, ww+19, 16, Color(25,25,25), 15)
	surface.DrawTrapezoid( 123, h-114+53, ww+15, 14, Color(40,40,40), 14)
	draw.SimpleText(text, "ilya_ttt_misc", 136, h-108+53, COL, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	
	-- ammo
	if clip1left > 0 or clip1 > 0 then
		local str = clip1 .. " / " .. clip1left
		local ww, hh = surface.GetFullTextSize( "ilya_ttt_misc", str)
		surface.DrawTrapezoid( 230, h-115+53, ww+19, 16, Color(25,25,25), 15)
		surface.DrawTrapezoid( 233, h-114+53, ww+15, 14, Color(40,40,40), 14)
		draw.SimpleText(str, "ilya_ttt_misc", 246, h-108+53, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	-- bg
	surface.DrawTrapezoid( 60, h-100, 300, 40, Color(25,25,25), 40)
	surface.DrawTrapezoid( 62, h-99, 296, 38, Color(40,40,40), 39)
	
	-- health
	surface.DrawTrapezoid( 62, h-99, Lerp(ply:Health()/100, 0, 296), 38, col, 39)
	surface.DrawTrapezoid( 383-40, h-75, 40, 14, Color(25,25,25), 14)
	draw.SimpleText(ply:Health() .. "%", "ilya_ttt_misc", 383-40+15, h-69, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	
	-- role
	local ww, hh = surface.GetFullTextSize( "ilya_ttt_misc", role)
	surface.DrawTrapezoid( 80, h-115, ww+19, 16, Color(25,25,25), 15)
	surface.DrawTrapezoid( 83, h-114, ww+15, 14, Color(40,40,40), 14)
	draw.SimpleText(role, "ilya_ttt_misc", 96, h-108, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	
	-- weapon
	local ww, hh = surface.GetFullTextSize( "ilya_ttt_misc", swepname)
	surface.DrawTrapezoid( 200, h-115, ww+19, 16, Color(25,25,25), 15)
	surface.DrawTrapezoid( 203, h-114, ww+15, 14, Color(40,40,40), 14)
	draw.SimpleText(swepname, "ilya_ttt_misc", 216, h-108, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

end
vgui.Register("ttt_hud_ilya", TTTHUD)

local ttt_hud = vgui.Create("ttt_hud_ilya")
ttt_hud:SetSize( ScrW(), ScrH() )

local PCalcT = {}
PCalcT.VS 	 = 0
PCalcT.WT 	 = 0
PCalcT.Air	 = 0

-- Paints player status HUD element in the bottom left
function GM:HUDPaint()
   local client = LocalPlayer()

   GAMEMODE:HUDDrawTargetID()

   MSTACK:Draw(client)

   if (not client:Alive()) or client:Team() == TEAM_SPEC then
      SpecHUDPaint(client)
      return
   end


   RADAR:Draw(client)
   TBHUD:Draw(client)
   WSWITCH:Draw(client)

   VOICE.Draw(client)
   DISGUISE.Draw(client)

   GAMEMODE:HUDDrawPickupHistory()
end

-- Hide the standard HUD stuff
local hud = {"CHudHealth", "CHudBattery", "CHudAmmo", "CHudSecondaryAmmo"}
function GM:HUDShouldDraw(name)
   for k, v in pairs(hud) do
      if name == v then return false end
   end

   return true
end

