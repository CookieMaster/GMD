Link to (unlisted) video tutorial: http://www.youtube.com/watch?v=keS8g2cP8LA
720p HD and fullscreen! I hope this helps.

Thanks for purchasing my addon!

Contact me at any time for support or issues:
http://steamcommunity.com/id/thejackool

If you don't want to watch the video, here are some quick tips:
> The "servermenu" folder is an addon! Put it in your server's addons\ folder, then restart the server
> lua\autorun\menu_settings.lua contains the extra customization
> lua\server_pages\ contains the pages. 1 will display on the very left, 2 next, etc.
> Almost everything has    // comments    that you can read and learn from
> Contact me for help if you can't be arsed to watch a video :)