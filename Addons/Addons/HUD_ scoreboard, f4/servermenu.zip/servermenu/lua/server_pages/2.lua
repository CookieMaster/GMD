local ServerPage = {}

ServerPage.Name = "MOTD" // The name of the page. This will show in the buttons at the top.
ServerPage.Icon = "servermenu/ico_motd.png" // The icon of the page. You can type "" for no icon.
ServerPage.Type = "html" // The type of page. You can choose "text", "command", "url", and "html"
ServerPage.Data = [[
<font color="white">
	<h2>The best MOTD ever</h2>
	Remember that the background of the server menu is black when using straight up HTML! You can change that in the settings though.
</font>
]] // The data. For "text" this is just text you want to display. For "command" type a console command. For "url" type a url. For "HTML" type html. Look at all the example pages
ServerPage.Accept = "Click here to accept the rules." // If this page should have an "Accept" button, choose the text for it here. If not, set this to    ServerPage.Accept = false


SM_SH.AddPage(ServerPage.Name,ServerPage.Icon,ServerPage.Type,ServerPage.Data,ServerPage.Accept)