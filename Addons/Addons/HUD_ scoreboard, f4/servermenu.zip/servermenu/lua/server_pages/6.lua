local ServerPage = {}

ServerPage.Name = "Kill Me" // The name of the page. This will show in the buttons at the top.
ServerPage.Icon = "" // The icon of the page. You can type "" for no icon.
ServerPage.Type = "command" // The type of page. You can choose "text", "command", "url", and "html"
ServerPage.Data = "kill" // The data. For "text" this is just text you want to display. For "command" type a console command. For "url" type a url. For "HTML" type html. Look at all the example pages
ServerPage.Accept = false


SM_SH.AddPage(ServerPage.Name,ServerPage.Icon,ServerPage.Type,ServerPage.Data,ServerPage.Accept)