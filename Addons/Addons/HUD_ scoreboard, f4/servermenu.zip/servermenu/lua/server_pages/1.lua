local ServerPage = {}

ServerPage.Name = "Rules" // The name of the page. This will show in the buttons at the top.
ServerPage.Icon = "servermenu/ico_rules.png" // The icon of the page. You can type "" for no icon.
ServerPage.Type = "text" // The type of page. You can choose "text", "command", "url", and "html"
ServerPage.Data = [[
These are the rules. This is an example
___________________________________________________________________
1) Please respect the admins
2) Please respect other players
3) Don't use exploits
4) Don't micspam
5) Don't troll this server
___________________________________________________________________
Have fun!
___________________________________________________________________
]] // The data. For "text" this is just text you want to display. For "command" type a console command. For "url" type a url. For "HTML" type html. Look at all the example pages
ServerPage.Accept = "Click here to accept the rules." // If this page should have an "Accept" button, choose the text for it here. If not, set this to    ServerPage.Accept = false


SM_SH.AddPage(ServerPage.Name,ServerPage.Icon,ServerPage.Type,ServerPage.Data,ServerPage.Accept)