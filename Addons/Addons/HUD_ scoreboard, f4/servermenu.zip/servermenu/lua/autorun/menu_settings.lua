
/* ----------------------
  -- Script created by --
  ------- Jackool -------
  -- for CoderHire.com --
  -----------------------
  
  This product has lifetime support and updates.
  
  Having troubles? Contact Jackool at any time:
  http://steamcommunity.com/id/thejackool
*/

// Don't edit this part!!!!! ----------------------------
local SM = {} // Do not edit
SM_SH = {} // Do not edit

local ScreenScale = ScreenScale  // Do not edit
if !ScreenScale then ScreenScale = function(s) return s end end // Do not edit
// Edit below this line -------------------------------------


// Simple stuff you can edit: =========================================

SM_SH.Title = "Server Name"
SM_SH.TitleClr = Color(255,255,255,200)

SM_SH.BottomBar = true // Should the black bottom bar with scrolling text be enabled
SM_SH.BottomBarText = "Read the rules. Check out our website today at www.servername.com!" // Text for scrolling bottom bar (attached to pages)
SM_SH.BottomBarSpeed = .25 // How fast the text scrolls. The higher the number, the faster the scrolling

SM_SH.ChatCommand = "!motd" // Chat command to open the menu
SM_SH.F1Key = true // If these are set to true, f1-f4 will open the menu.
SM_SH.F2Key = false
SM_SH.F3Key = false
SM_SH.F4Key = false
SM_SH.KeyClose = true // Should the player be able to press the above keys to also close the menu, not just open?

SM_SH.ForceAccept = true // Force the player to click an "Accept" button for their first join (no close button in top right)
SM_SH.AcceptTime = 20 // If forcing is on, how long must they wait before they can press accept?

SM_SH.WebsiteControls = true // Should the player be able to press back/forward in the web browsers?

SM_SH.SlideTime = .6 // How much time the top bar takes to slide out (seconds)
SM_SH.PageSlide = .5 // How much time it takes for pages to slide in or out

SM_SH.ButtonWoosh = true // When you hover buttons, should they have the "woosh" sound

// More complex stuff you can edit:  ===================================

SM_SH.DefaultPage = 1 // Which page it starts on. 1 = first page (default is rules (pg 1) as start page)

SM_SH.PageWidth = 80 // How wide pages should be (percentage, so 80 means 80%)
SM_SH.PageSpace = 40 // How much space should be on the top and bottom of pages

// Sound effects. Set it to "" for no sound.
SM_SH.MenuSound = "servermenu/menu_woosh.wav" // Sound that plays when the menu slides downards
SM_SH.HoverSound = "servermenu/button_woosh.wav" // Sound that plays when you hover over a page button
SM_SH.ClickSound = "servermenu/button_click.wav" // Sound that plays when you click a page button

SM_SH.AcceptTall = 32 // How tall the accept button is
SM_SH.BarSize = .08
SM_SH.CloseSpace = 8 // How much space should be left around the close button
SM_SH.CloseBG = "servermenu/close_bg.png" // Close button background
SM_SH.BarBG = "servermenu/bar_bg.png" // Top bar background
SM_SH.ButtonBG = "servermenu/button_bg.png" // Page button background
SM_SH.PageBG = "servermenu/page_bg.png" // Background of pages (the ones that slide up/down)

SM_SH.PageButColor = Color(200,200,200) // Color of the page button backgrounds
SM_SH.PageSelectColor = Color(0,221,255,200) // Color for the button when page is open
SM_SH.PageTxtColor = Color(255,255,255,200) // What color the font is for the page buttons
SM_SH.ButtonSpace = 6 // How much space between each page button
SM_SH.PageTopSpace = 0 // How much space on the top and bottom of the page buttons
SM_SH.PageTextSpace = 6 // How much space to the left and right of the text on a page button

function SM_LoadFonts() // Don't edit this line, edit fonts below:

	// Font settings!
	SM_SH.TitleFont = {
		font = "Arial",
		size = ScreenScale(ScrW()*.2/string.len(SM_SH.Title)),
		weight = 800,
		scanlines = 0,
		antialias = true,
		shadow = true,
		outline = true
	}

	// Page button fonts
	SM_SH.ButtonFont = {
		font = "Arial",
		size = ScreenScale(13),
		weight = 800,
		scanlines = 0,
		antialias = true,
		shadow = true,
		outline = false
	}

	// The font for the scrolling-text bar at the bottom
	SM_SH.BarFont = {
		font = "Arial",
		size = 20,
		weight = 800,
		scanlines = 0,
		antialias = true,
		shadow = true,
		outline = false
	}

	// Title fonts
	SM_SH.PageTitles = {
		font = "Arial",
		size = ScreenScale(16),
		weight = 800,
		scanlines = 0,
		antialias = true,
		shadow = true,
		outline = false
	}

	// Text page fonts
	SM_SH.TextFont = {
		font = "Arial",
		size = ScreenScale(11),
		weight = 800,
		scanlines = 0,
		antialias = true,
		shadow = true,
		outline = false
	}

end

if CLIENT then SM_LoadFonts() end

// |----------------------------------------------------------------------------
// | Don't edit below this line!!! ---------------------------------------------
// | You might break something.    ---------------------------------------------
// |----------------------------------------------------------------------------
SM_SH.Pages = {}
function SM_SH.AddPage(Name,Icon,Type,Data,Accept)
	local ID = table.Count(SM_SH.Pages)+1
	for k,v in pairs(SM_SH.Pages) do if Name == v.Name then ID = k break end end
	
	SM_SH.Pages[ID] = {}
	SM_SH.Pages[ID].Name = Name
	SM_SH.Pages[ID].Ico = Material(Icon)
	SM_SH.Pages[ID].Type = Type
	SM_SH.Pages[ID].Data = Data
	SM_SH.Pages[ID].Acc = Accept
	
	if SERVER and Icon and Icon != "" then resource.AddFile("materials/" .. Icon) end
end

local Pages = file.Find("server_pages/*.lua","LUA")
for k,v in pairs(Pages) do
	include("server_pages/" .. v)
	if SERVER then AddCSLuaFile("server_pages/" .. v) end
end

if CLIENT then include("servermenu/cl_servermenu.lua") else include("servermenu/sv_servermenu.lua") end

// STOP. you've violated the law by scrolling this far down. jokes :)