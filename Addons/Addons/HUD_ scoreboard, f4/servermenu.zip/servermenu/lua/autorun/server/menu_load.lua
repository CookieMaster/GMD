AddCSLuaFile("servermenu/cl_servermenu.lua")
include("servermenu/sv_servermenu.lua")