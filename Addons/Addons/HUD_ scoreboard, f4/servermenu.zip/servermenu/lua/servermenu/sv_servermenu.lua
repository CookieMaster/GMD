
/* ----------------------
  -- Script created by --
  ------- Jackool -------
  -- for CoderHire.com --
  -----------------------
  
  This product has lifetime support and updates.
  
  Having troubles? Contact Jackool at any time:
  http://steamcommunity.com/id/thejackool
*/
AddCSLuaFile("servermenu/cl_servermenu.lua")

if SM_SH.CloseBG != "" then resource.AddFile("materials/" .. SM_SH.CloseBG) end
if SM_SH.BarBG != "" then resource.AddFile("materials/" .. SM_SH.BarBG) end
if SM_SH.ButtonBG != "" then resource.AddFile("materials/" .. SM_SH.ButtonBG) end
if SM_SH.PageBG != "" then resource.AddFile("materials/" .. SM_SH.PageBG) end

if SM_SH.MenuSound != "" then resource.AddFile("sound/" .. SM_SH.MenuSound) end
if SM_SH.HoverSound != "" then resource.AddFile("sound/" .. SM_SH.HoverSound) end
if SM_SH.ClickSound != "" then resource.AddFile("sound/" .. SM_SH.ClickSound) end

util.AddNetworkString("SM_OpenMenu")

if SM_SH.F1Key then
	hook.Add("ShowHelp","For Server Menu F1",function(ply) net.Start("SM_OpenMenu") net.Send(ply) end)
end

if SM_SH.F2Key then
	hook.Add("ShowTeam","For Server Menu F2",function(ply) net.Start("SM_OpenMenu") net.Send(ply) end)
end

if SM_SH.F3Key then
	hook.Add("ShowSpare1","For Server Menu F3",function(ply) net.Start("SM_OpenMenu") net.Send(ply) end)
end

if SM_SH.F4Key then
	hook.Add("ShowSpare2","For Server Menu F4",function(ply) net.Start("SM_OpenMenu") net.Send(ply) end)
end

