------ DO NOT EDIT THIS SCRIPT IF YOU DON'T KNOW HOW TO CODE --------
/* ----------------------
  -- Script created by --
  ------- Jackool -------
  -- for CoderHire.com --
  -----------------------
  
  This product has lifetime support and updates.
  
  Having troubles? Contact Jackool at any time:
  http://steamcommunity.com/id/thejackool
*/

// Localize stuff to keep the script running fast
local SM,SM_SH,draw,surface,timer,string,math,table,Derma_DrawBackgroundBlur,CurTime = {},SM_SH,draw,surface,timer,string,math,table,Derma_DrawBackgroundBlur,CurTime

function SM.EstablishFonts()
surface.CreateFont( "SM_ServerTitle", SM_SH.TitleFont )
surface.CreateFont( "SM_PageButton", SM_SH.ButtonFont )
surface.CreateFont( "SM_BarFont", SM_SH.BarFont )
surface.CreateFont( "SM_PageTitles", SM_SH.PageTitles )
surface.CreateFont( "SM_TextFont", SM_SH.TextFont )
end
SM.EstablishFonts()


surface.CreateFont( "SM_Accept", {
	font = "Arial",
	size = SM_SH.AcceptTall-8,
	weight = 800,
	antialias = true,
	shadow = true,
	outline = false
})

SM.PageBG = Material(SM_SH.PageBG)
function SM.OpenPage(ID)
	if !SM.FirstOpen then SM.FirstOpen = CurTime() end
	if SM.Opening then return end
	if SM.CurPage and SM.CurPage.ID == ID then return end
	
	local Pg = SM_SH.Pages[ID]
	
	if SM.CurPage then
		SM.CurPage:MoveTo(ScrW()*.5-(SM.CurPage:GetWide()*.5),-SM.CurPage:GetTall(),SM_SH.PageSlide)
		SM.Opening = true
		timer.Simple(SM_SH.PageSlide,function()
			SM.Opening = false
			SM.CurPage:Remove()
			SM.CurPage = nil
			SM.OpenPage(ID)
		end)
		return
	end
	if SM_SH.MenuSound and SM_SH.MenuSound != "" then LocalPlayer():EmitSound(SM_SH.MenuSound,85) end
	
	local PageW,PageH = (.01*SM_SH.PageWidth)*ScrW(),ScrH()-((SM_SH.BarSize <= 1 and SM_SH.BarSize*ScrH()) or SM_SH.BarSize)-(SM_SH.PageSpace*2)
	local BlurTime = CurTime()+SM_SH.PageSlide
	
	SM.CurPage = vgui.Create("EditablePanel")
	SM.CurPage.ID = ID
	SM.CurPage:SetSize(PageW,PageH)
	SM.CurPage:SetPos(ScrW()*.5-(PageW*.5),-PageH)
	SM.CurPage:MoveTo(ScrW()*.5-(PageW*.5),((SM_SH.BarSize <= 1 and SM_SH.BarSize*ScrH()) or SM_SH.BarSize)+SM_SH.PageSpace,SM_SH.PageSlide,0)
	SM.CurPage.Paint = function(s,w,h)
		Derma_DrawBackgroundBlur(s,BlurTime)
		
		surface.SetDrawColor( 255, 255, 255, 255 )
			surface.SetMaterial( SM.PageBG )
		surface.DrawTexturedRect( 0, 0, w, h )
	end
	SM.CurPage:MakePopup()
	SM.CurPage:SetZPos(-9)
	
	local Title = vgui.Create("DLabel",SM.CurPage)
	Title:SetPos(6,4)
	Title:SetFont("SM_PageTitles")
	Title:SetText(Pg.Name)
	Title.Paint = function(s,w,h) draw.RoundedBox(0,0,0,w,h,Color(60,60,60,150)) end
	Title:SizeToContents()
	
	local Content
	local ContH = SM.CurPage:GetTall()-25-Title:GetTall()-8
	if Pg.Type == "text" then
		Content = vgui.Create("DPanelList",SM.CurPage)
		Content:SetSpacing(8)
		Content:SetPadding(8)
		Content:EnableVerticalScrollbar(true)
		
		surface.SetFont("SM_TextFont")
		local ____,TxtH = surface.GetTextSize("W")
		
		local Txt = vgui.Create("DTextEntry",Content)
		Txt:SetFont("SM_TextFont")
		Txt:SetEditable(false)
		Txt:SetMultiline(true)
		Txt:SetText(Pg.Data)
		Txt:SetPos(8,8)
		Content:AddItem(Txt)
		Txt:SetTall((table.Count(string.Explode("\n",Pg.Data))+1)*TxtH)
		Txt:SetDrawBackground(false)
		Txt:SetTextColor(Color(225,255,255))
		Txt:SetKeyboardInputEnabled(false)
		Txt:SetMouseInputEnabled(false)
		function Txt:SetText(a,b,c) return false end
	elseif Pg.Type == "url" then
		Content = vgui.Create("HTML",SM.CurPage)
		Content:OpenURL(Pg.Data)
		
		if SM_SH.WebsiteControls then
			local Controls = vgui.Create("DHTMLControls",SM.CurPage)
			Controls:SetHTML(Content)
			Controls:SetPos(Title:GetWide()+12,4)
			Controls:SetSize(PageW-Title:GetWide()-14,Title:GetTall())
			Controls.AddressBar:Remove()
		end
	elseif Pg.Type == "html" then
		Content = vgui.Create("DHTML",SM.CurPage)
		Content:SetHTML(Pg.Data)
	end
	
	Content:SetPos(4,Title:GetTall()+4)
	Content:SetSize(SM.CurPage:GetWide()-8,ContH)
	
	if Pg.Acc and !SM.Accepted then
		local Accept = vgui.Create("DButton")
		Accept:SetParent(SM.CurPage)
		Accept:SetPos(0,PageH-SM_SH.AcceptTall)
		Accept:SetSize(PageW,SM_SH.AcceptTall)
		Accept:SetText("")
		Accept.Paint = function(s,w,h)
			local Extr,Timeleft = "",math.Round(SM_SH.AcceptTime-(CurTime()-SM.FirstOpen))
			if (CurTime()-SM.FirstOpen) < SM_SH.AcceptTime then Extr = " (" .. Timeleft .. " second" .. (Timeleft > 1 and "s" or "") .. ")" end
			local Fade = (s.Hover and math.Clamp((CurTime()-s.Hover)/.2,0,1)) or (s.Out and 1-math.Clamp((CurTime()-s.Out)/.2,0,1)) or 0
			draw.RoundedBox(0,0,0,w,h,Color(150-(Fade*40),150-(Fade*40),150-(Fade*40),200))
			draw.SimpleTextOutlined(Pg.Acc .. Extr, "SM_Accept", w*.5, h*.5, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 0)
		end
		Accept.OnCursorEntered = function(s) s.Hover = CurTime() end
		Accept.OnCursorExited = function(s) s.Out = CurTime() s.Hover = nil end
		Accept.DoClick = function(s,w,h)
			if (CurTime()-SM.FirstOpen) > SM_SH.AcceptTime then
				SM.Accepted = true
				SM.TopBar:Close()
			end
		end
		SM.TopBar.Accept = Accept
	elseif SM_SH.BottomBar then
		surface.SetFont("SM_BarFont")
		local TxtPos,__ = surface.GetTextSize(SM_SH.BottomBarText)
		if !SM.TxtPos then SM.TxtPos = PageW+10 end
		
		local BBar = vgui.Create("DPanel",SM.CurPage)
		BBar:SetPos(0,PageH-25)
		BBar:SetSize(PageW,25)
		BBar.Paint = function(s,w,h)
			SM.TxtPos = SM.TxtPos-SM_SH.BottomBarSpeed
			if SM.TxtPos <= -TxtPos then SM.TxtPos = PageW+25 end
			
			draw.RoundedBox(0,0,0,w,h,Color(0,0,0,40))
			draw.RoundedBox(0,0,2,w,h-4,Color(255,255,255,20))
			draw.SimpleTextOutlined(SM_SH.BottomBarText, "SM_BarFont", SM.TxtPos, h*.5, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 0)
		end
	end
end

SM.CloseBG = Material(SM_SH.CloseBG)
SM.BarBG = Material(SM_SH.BarBG)
SM.ButtonBG = Material(SM_SH.ButtonBG)
function SM.OpenMenu()
	if SM.TopBar and SM.TopBar:IsValid() then if SM_SH.KeyClose then SM.TopBar:Close() end return end
	
	if !SM.OldScrW then SM.OldScrW = ScrW() elseif SM.OldScrW != ScrW() then SM_LoadFonts() SM.EstablishFonts() end
	local B,Title = {},SM_SH.Title
	local BarW,BarH = ScrW(),(SM_SH.BarSize <= 1 and ScrH()*SM_SH.BarSize) or SM_SH.BarSize
	
	surface.SetFont("SM_ServerTitle")
	local TitleWide,TitleTall = surface.GetTextSize(Title)
	
	// Top bar ------------------------------------------
	local DrawBars = math.ceil(ScrW()/512)
	B.Bar = vgui.Create("DPanel")
	B.Bar:SetSize(BarW,BarH)
	B.Bar:SetPos(0,-BarH)
	B.Bar:MoveTo(0,0,SM_SH.SlideTime,0,.2)
	B.Bar:SetDrawOnTop(true)
	B.Bar:SetZPos(-10)
	B.Bar.Paint = function(s,w,h)
		for i=0,DrawBars-1 do
			surface.SetDrawColor( 255, 255, 255, 245 )
				surface.SetMaterial( SM.BarBG )
			surface.DrawTexturedRect( i*512, 0, 512, h )
		end
		draw.SimpleTextOutlined(SM_SH.Title, "SM_ServerTitle", 5, h*.5, SM_SH.PageTxtColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 0)
		
		draw.RoundedBox(0,0,h-2,w,2,Color(0,0,0,200))
	end
	B.Bar:MakePopup()
	SM.TopBar = B.Bar
	
	
	function B.Bar:Close()
		if self.Closing then return end
		B.Bar:MoveTo(ScrW()*.5-(self:GetWide()*.5),-(self:GetTall()),SM_SH.SlideTime,0,.2)
		self.Closing = true
		if SM.CurPage then
			SM.Opening = true
			SM.CurPage:MoveTo(ScrW()*.5-(SM.CurPage:GetWide()*.5),-(SM.CurPage:GetTall()),SM_SH.SlideTime)
		end
		timer.Simple((SM_SH.SlideTime > SM_SH.PageSlide and SM_SH.SlideTime) or SM_SH.PageSlide,function()
			if SM.CurPage then
				SM.CurPage:Remove()
				SM.CurPage = nil
				SM.Opening = false
			end
			B.Bar:Remove()
		end)
	end
	
	// F-key closing
	if SM_SH.KeyClose then
		local ThisOpen = CurTime()
		function B.Bar:Think()
			local OpenTime = (CurTime()-ThisOpen)
			if (!SM_SH.ForceAccept or SM.Accepted or (OpenTime > SM_SH.AcceptTime)) and !self.Closing and OpenTime > 3.5 then
				if (SM_SH.F1Key and input.IsKeyDown(KEY_F1)) or (SM_SH.F2Key and input.IsKeyDown(KEY_F2)) or (SM_SH.F3Key and input.IsKeyDown(KEY_F3)) or (SM_SH.F4Key and input.IsKeyDown(KEY_F4)) then
					if self.Accept and self.Accept:IsValid() then self.Accept:DoClick() else B.Bar:Close() end
				end
			end
		end
	end
	
	if !SM_SH.ForceAccept or SM.Accepted then
		local CloseSize = (BarH-SM_SH.CloseSpace*2)
		B.Close = vgui.Create("DButton",B.Bar)
		B.Close:SetSize(CloseSize,CloseSize)
		B.Close:SetPos(BarW-SM_SH.CloseSpace-CloseSize,SM_SH.CloseSpace)
		B.Close:SetText("")
		B.Close.Paint = function(s,w,h)
			local Fade = (s.Hover and math.Clamp((CurTime()-s.Hover)/.2,0,1)) or (s.Out and 1-math.Clamp((CurTime()-s.Out)/.2,0,1)) or 0
			surface.SetDrawColor( 255, 255, 255, 150+(Fade*100) )
				surface.SetMaterial( SM.CloseBG )
			surface.DrawTexturedRect( 0, 0, w, h )
			
			draw.RoundedBox(0,0,0,w,h,Color(Fade*255,Fade*255,Fade*255,Fade*20))
			draw.RoundedBox(0,0,h-2,w,2,Color(0,0,0,200))
		end
		B.Close.DoClick = function()
			B.Bar:Close()
		end
		B.Close.OnCursorEntered = function(s) s.Hover = CurTime() end
		B.Close.OnCursorExited = function(s) s.Out = CurTime() s.Hover = nil end
	end
	
	// Bar buttons (for pages) ---------------------------------
	local LeftSpace = 5+TitleWide+25 // Space on the left that is occupied by the title
	local ButtonSpace = 0
	
	for k,v in pairs(SM_SH.Pages) do
		// Get the size for this button's text
		surface.SetFont("SM_PageButton")
		local PWide,PTall = surface.GetTextSize(v.Name)
		PWide = PWide+(SM_SH.PageTextSpace*2)
		if v.Ico then PWide = PWide+BarH-(SM_SH.PageTopSpace*2) end
		
		// Make the button
		local But,BGs,Clr = vgui.Create("DButton",B.Bar),math.ceil(PWide/100),SM_SH.PageButColor
		But:SetPos(LeftSpace+ButtonSpace,SM_SH.PageTopSpace)
		But:SetSize(PWide,BarH-(SM_SH.PageTopSpace*2))
		But:SetText("")
		But.Paint = function(s,w,h)
			local Fade = (s.Hover and math.Clamp((CurTime()-s.Hover)/.2,0,1)) or (s.Out and 1-math.Clamp((CurTime()-s.Out)/.2,0,1)) or 0
			local Clr2
			if SM.CurPage and SM.CurPage.ID == k then Clr2 = SM_SH.PageSelectColor else Clr2 = Color(Clr.r+(Fade*100), Clr.g+(Fade*100), Clr.b+(Fade*100), 255) end
			
			for i=0,BGs-1 do
				
				surface.SetDrawColor( Clr2.r, Clr2.g, Clr2.b, Clr2.a )
					surface.SetMaterial( SM.ButtonBG )
				surface.DrawTexturedRect( i*100, 0, 100, h )
			end
			draw.RoundedBox(0,0,0,2,h,Color(0,0,0,200))
			draw.RoundedBox(0,w-2,0,2,h,Color(0,0,0,200))
			draw.RoundedBox(0,0,h-4,w,4,Color(0,0,0,100))
			
			if v.Ico then
				surface.SetDrawColor( 255, 255, 255, 150+(Fade*100) )
					surface.SetMaterial( v.Ico )
				surface.DrawTexturedRect( SM_SH.PageTextSpace, SM_SH.PageTextSpace, (h-SM_SH.PageTextSpace*2), (h-SM_SH.PageTextSpace*2) )
			end
			draw.SimpleTextOutlined(v.Name, "SM_PageButton", (v.Ico and h) or w*.49, h*.5, SM_SH.PageTxtColor, (v.Ico and TEXT_ALIGN_LEFT) or TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 0)
		end
		But.OnCursorEntered = function(s) s.Hover = CurTime() if SM_SH.HoverSound and SM_SH.HoverSound != "" then LocalPlayer():EmitSound(SM_SH.HoverSound,40) end end
		But.OnCursorExited = function(s) s.Out = CurTime() s.Hover = nil end
		But.DoClick = function(s)
			s.Hover = CurTime()
			if SM_SH.ClickSound and SM_SH.ClickSound != "" then LocalPlayer():EmitSound("servermenu/button_click.wav",100) end
			if v.Type == "command" then RunConsoleCommand(v.Data) else SM.OpenPage(k) end
		end
		
		ButtonSpace = ButtonSpace+PWide+SM_SH.ButtonSpace
	end
	
	if SM_SH.DefaultPage and SM_SH.Pages[SM_SH.DefaultPage] then
		SM.OpenPage(SM_SH.DefaultPage)
	end
end
net.Receive("SM_OpenMenu",SM.OpenMenu)

SM.CMDLen = string.len(SM_SH.ChatCommand)
hook.Add("OnPlayerChat","For servermenu (by Jackool) command",function(ply, text)
	if string.sub(string.lower(text),0,SM.CMDLen) == SM_SH.ChatCommand then if ply == LocalPlayer() then SM.OpenMenu() end return true end
end)

hook.Add("InitPostEntity","Servermenu",function()
	timer.Simple(2,function() SM.OpenMenu() end)
end)