<?php
// You can get a Steam API Key by visiting http://steamcommunity.com/dev/apikey
$SteamAPIKey = "YOURSTEAMAPIKEY";
if (!isset($_GET["steamid"])) {
	die(" We didnt get a steam api key, make sure that it looks like this.www.domain.com/loading/index.php?steamid=%s");
}

$steamid64 = $_GET["steamid"];

$url = "http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key=" . $SteamAPIKey . "&steamids=" . $steamid64;
$json = file_get_contents($url);
$table2 = json_decode($json, true);
$table = $table2["response"]["players"][0];
?>
<!-- Start of our HTML file -->
<!-- Made from twitter bootstrap -->
<!-- Some help from CaptainMcMarcus -->
<!-- Made by BlackmanCuldesac -->
<!-- If you are reading this from the browser and are trying to steal this have fun getting the php coding -->
<!DOCTYPE html>
<html>
<head>
<link media="all" href="http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/2.2.2/css/bootstrap.min.css" rel="stylesheet"></link><!--More css its external do not touch this -->
<link media="all" href="http://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/2.2.2/css/bootstrap-responsive.min.css" rel="stylesheet"></link><!--More css its external do not touch this -->
<link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'><!-- some fonts -->
<link href='http://fonts.googleapis.com/css?family=Freckle+Face' rel='stylesheet' type='text/css'><!-- some fonts -->
<link rel="stylesheet" href="loading.css" media="all"/><!-- Link to the main css -->
<script type="text/javascript" src="scripts/counter.js"></script><!-- script so we can get the download counter working -->
<script type="text/javascript">
	//Changes volume of song. 0.5=50% 1=100% volume 
	$('.audio').prop("volume", 0.2);
	</script>
<style>
header { 
    height: 10px;<!-- Gives us some space from the top -->
}
</style>
</head>
<body>
<header></header>
<header></header>
<header></header>
<header></header>
<title>Receiving 1337 hackz...</title><!-- Lets add a title to the tab in the browser if you want change to anything you want-->
	
<div class="row-fluid">
<div class="span12">
<div class="span3 offset1" style="text-align: justify;">
<div class="well">

<!-- Here you can edit the first block -->
<h4 style="text-align: center;">Welcome to the Server!</h4>
</div>

<?php
//PHP Code for the avatar display, it's probably best to leave all of this alone
                	echo "<div class=\"well\">";
					echo "<div style=\"text-align: center;\">";
						echo "<img src=\"" . $table["avatarfull"] . "\" />";
					echo "</div>";			
				echo "</div>";
//PHP for the steam name dont touch this
			echo "<div style=\"text-align: center;\"class=\"well\">";
                	echo "<h4>" . $table["personaname"] . "</h4>";
				echo "</div>";
// PHP for the steam id dont touch this
				echo "<div style=\"text-align: center;\"class=\"well\">";
                	echo "<h4>" . $steamid64 . "</h4>";
                echo"</div>";
				
?>

<!-- Now edit stop -->
<!-- DONT TOUCH ANYTHING UNDER THIS LINE -->
            <div style="text-align: center;" id="download-box">
            	<div class="well"  alt="Download"</div>
                <div id="files">
            		<h4>Connecting</h4><!-- You may changed this to say something but not too long.This is the default text shown in the download box when we are waiting for the download number -->
				</div>
			</div>
		</div>
	</div>
	
	
<!-- You may now start editing again -->
<div class="span7 well">
<div class="row" style="padding-top: -10px; padding-bottom: -150px;">
<div class="span3 offset1" style="text-align: center;">											
<h1>Your server name</h1><!-- Change this to your server name -->
</div>
</div>


<div class="row" style=" margin-top: -75px; margin-bottom: 15px;">
<div class="span7 offset3" style="text-align: justify;">
		
		<h4 style="margin-left: -150px;">Your server name and General Rules</h4><!-- Make this say anything that you want but make sure its no to big or it wll go off the page or overlap-->
		<ul><!--Change some rules in in between the <li> tags -->
		<li style="align-left;" >Don't RDM or NLR.</li>
		<li>Don't Hack or Exploit in any way.</li>
		<li>Always /advert Raid, Mug and Carjack.</li>
		<li>Ask the Staff for help if needed!</li>
		<li>Read the rules or risk being banned.</li>
		<li>Donations help us keep the server running!</li>
		<li>Domainname.org is our website.</li>
		<li>We hope you have a flawless experience!</li>
		</ul>
		<h4 style="margin-left: -150px;">Your Server staff Staff and Donator's</h4><!-- Make this anything that you want. -->
		<dl>
		<dt>Owner(s)</dt><!-- You can add staff in between all of the dd tags just replace the name. -->
		<dd>Chris -- BlackmanCuldesac</dd>
		<dt>SuperAdmin(s)</dt>
		<dd>Killer kanda -- Tom -- Damien -- Ninja Mittens -- AlienWareX59</dd>
		<dt>Admin(s)</dt>
		<dd>Captain Chilled Frost -- Christian -- xMajorxPwnx </dd>
		<dt>Moderator(s)</dt>
		<dd>Captain Derpy Jon -- Skelly -- OutCaskit</dd>
		<dt>Donator(s)</dt>
		<dd>Fo Casper -- D4NNY -- E.C.H.O -- Mr.Walrus -- Thrussn</dd><!-- It would be best not to add anymore dt or dd tags.-->
		</dl>
		</ul>
</div>
	</div><!-- These are closing off some forgotten tags above. -->
		</div>
			</div>
	
<!-- THIS IS THE MUSIC SCRIPT --><!-- Change the music.ogg to the ogg that you converted and put it in the loading folder-->
<!--Remove the comment tags-->
<!--
  <audio class="audio" autoplay autobuffer="autobuffer">
    	<source src="Bullseye.ogg" type="audio/ogg">
    </audio>     
   
<!-- Closes off the document -->
</body>
</html>