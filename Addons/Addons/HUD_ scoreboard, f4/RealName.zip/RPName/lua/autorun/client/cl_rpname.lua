local communityName = "Community name here"

Blacklist = {"fuck", "dick", "shit", "fag", "homo", "dickface", "face", "cum", "admin", "anus", "arse", "arsehole", "ass", "assbag", "assfuck", "asshole", "assshole", "assshit", "shit"}

Models = {  "models/player/Group01/Female_01.mdl",
			"models/player/Group01/Female_02.mdl",
			"models/player/Group01/Female_03.mdl",
			"models/player/Group01/Female_04.mdl",
			"models/player/Group01/Female_06.mdl",
			"models/player/group01/male_01.mdl",
			"models/player/Group01/Male_02.mdl",
			"models/player/Group01/male_03.mdl",
			"models/player/Group01/Male_04.mdl",
			"models/player/Group01/Male_05.mdl",
			"models/player/Group01/Male_06.mdl",
			"models/player/Group01/Male_07.mdl",
			"models/player/Group01/Male_08.mdl",
			"models/player/Group01/Male_09.mdl"
		}
function rpMenu()
	local SetNamePanel = vgui.Create( "DFrame" )
	SetNamePanel:SetPos( (ScrW() / 2) - 250, (ScrH() / 2) - 150)
	SetNamePanel:SetSize( 500, 380 )
	SetNamePanel:SetTitle("Welcome to " ..communityName)
	SetNamePanel:SetVisible( true )
	SetNamePanel:SetDraggable( true )
	SetNamePanel:ShowCloseButton( false )
	SetNamePanel:MakePopup()
	SetNamePanel.Paint = function()
		draw.RoundedBox( 8, 0, 0, SetNamePanel:GetWide(), SetNamePanel:GetTall(), Color( 0, 0, 0, 190 ) )
	end

	local welcomeLabel = vgui.Create("DLabel", SetNamePanel)
	welcomeLabel:SetPos( 115,40 )
	welcomeLabel:SetColor(Color(255,255,255,255))
	welcomeLabel:SetText("Enter Below your roleplay name and choose your model")
	welcomeLabel:SizeToContents()

	local firstnameOK, lastnameOK
	local firstnameLabel = vgui.Create("DLabel", SetNamePanel)
	firstnameLabel:SetPos( 70,80 )
	firstnameLabel:SetColor(Color(255,255,255,255))
	firstnameLabel:SetText("First Name")

	local allowdLabel = vgui.Create("DLabel", SetNamePanel)
	allowdLabel:SetPos( 20,250 )
	allowdLabel:SetColor(Color(255,255,255,255))
	allowdLabel:SetText(" ")

	local firstnameImage = vgui.Create( "DImage", SetNamePanel)
	firstnameImage:SetPos(180, 102)
	firstnameImage:SetSize( 16,16 )

	function wordcheck(str)
		for k,v in pairs(Blacklist) do
			if string.match(str, v) then
				return true
			else
				return false
			end
		end
	end
	local firstName = vgui.Create("DTextEntry", SetNamePanel)
	firstName:SetSize( 150,20 ) 
	firstName:SetPos( 20,100 )
	firstName.OnTextChanged = function(text)
		if string.match(firstName:GetValue(),"%d") or string.match(firstName:GetValue(),"%s") or string.match(firstName:GetValue(),"%p") or table.HasValue( Blacklist, string.lower(firstName:GetValue()) ) or wordcheck(string.lower(firstName:GetValue())) then
			firstName:SetHighlightColor(Color(255,0,0,200))
			allowdLabel:SetText("This name is not allowd!")
			firstnameImage:SetImage( "notgood.png" )
			firstnameImage:SetVisible(true)
			allowdLabel:SizeToContents()
			allowdLabel:SetColor(Color(255,0,0))
			firstnameOK = false
		else
			firstName:SetHighlightColor(Color(0,255,0,200))
			allowdLabel:SetText(" ")
			if firstName:GetValue() != "" then
				firstnameImage:SetImage( "check.png" )
				firstnameImage:SetVisible(true)
				firstnameOK = true
			else
				firstnameImage:SetVisible(false)
				firstnameOK = false
			end
		end
	end

	local lastnameLabel = vgui.Create("DLabel", SetNamePanel)
	lastnameLabel:SetPos(70,130)
	lastnameLabel:SetColor(Color(255,255,255,255))
	lastnameLabel:SetText("Last Name")

	local lastnameImage = vgui.Create( "DImage", SetNamePanel)
	lastnameImage:SetPos(180, 152)
	lastnameImage:SetSize( 16,16 ) 

	local lastName = vgui.Create("DTextEntry", SetNamePanel)
	lastName:SetSize( 150,20 ) 
	lastName:SetPos( 20,150 )
	lastName.OnTextChanged = function(text)
		if string.match(lastName:GetValue(),"%d") or string.match(lastName:GetValue(),"%s") or string.match(lastName:GetValue(),"%p") or table.HasValue( Blacklist, string.lower(firstName:GetValue()) ) or wordcheck(string.lower(lastName:GetValue())) then
			lastName:SetHighlightColor(Color(255,0,0,200))
			allowdLabel:SetText("This name is not allowd!")
			allowdLabel:SizeToContents()
			lastnameImage:SetImage( "notgood.png" )
			lastnameImage:SetVisible(true);
			allowdLabel:SetColor(Color(255,0,0))
			lastnameOK = false
		else
			lastName:SetHighlightColor(Color(0,255,0,200))
			if lastName:GetValue() != "" then
				lastnameImage:SetImage( "check.png" )
				lastnameImage:SetVisible(true)
				lastnameOK = true
			else
				lastnameImage:SetVisible(false)
				lastnameOK = false
			end
			allowdLabel:SetText(" ")
		end
	end

	local nameLabel = vgui.Create("DLabel", SetNamePanel)
	nameLabel:SetPos( 20,180 )
	nameLabel:SetColor(Color(255,255,255,255))
	nameLabel:SetText("The first letter of your last name and your first name\nhas to be a capital letter, numbers are not allowed.\n\nHave Fun!")
	nameLabel:SizeToContents()

	local modelView = vgui.Create( "DModelPanel", SetNamePanel )
	modelView:SetSize( 200,200 )
	modelView:SetPos(280, 80)
	modelView:SetModel( Models[1] )
	modelView:SetFOV(50)

	local modelCounter = 1
	
	local backwardButton = vgui.Create( "DButton", SetNamePanel )
	backwardButton:SetSize( 50, 50 )
	backwardButton:SetPos( 325, 280 )
	backwardButton:SetText( "<--" )
	backwardButton.DoClick = function( button )
		modelCounter = modelCounter - 1
		if modelCounter == -1 or modelCounter == 0 then
			modelCounter = table.Count(Models)
		end
		modelView:SetModel( Models[modelCounter] )
	end

	local forwardButton = vgui.Create( "DButton", SetNamePanel )
	forwardButton:SetSize( 50, 50 )
	forwardButton:SetPos( 390, 280 )
	forwardButton:SetText( "-->" )
	forwardButton.DoClick = function( button )
		modelCounter = modelCounter + 1
		if modelCounter == (table.Count(Models) + 1) then
			modelCounter = 1
		end
		modelView:SetModel( Models[modelCounter] )
	end

	local doneButton = vgui.Create( "DButton", SetNamePanel )
	doneButton:SetSize( 100, 25 )
	doneButton:SetPos( 200, 350 )
	doneButton:SetText( "Done!" )
	doneButton.DoClick = function( button )
		LocalPlayer():ConCommand('rpname_set "'..firstName:GetValue()..' '..lastName:GetValue()..'" "'..Models[modelCounter]..'"')
		SetNamePanel:SetVisible(false)
	end
	function SetNamePanel:Think()
		if lastnameOK and firstnameOK == true then
			doneButton:SetDisabled( false )
		else
			doneButton:SetDisabled( true )
		end
	end
end
net.Receive( "rpnameMenu", rpMenu )