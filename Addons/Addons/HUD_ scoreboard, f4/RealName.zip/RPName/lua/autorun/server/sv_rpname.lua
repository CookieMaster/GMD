AddCSLuaFile("../client/cl_rpname.lua")
resource.AddFile( "materials/check.png" )
resource.AddFile( "materials/notgood.png" )

util.AddNetworkString("rpnameMenu")

function rpname(pl)
	if pl:Name() == pl:SteamName() then
		print(pl:SteamName())
		net.Start( "rpnameMenu" )
		net.Send( pl )
	end
end
hook.Add( "PlayerSpawn", "rpnameSpawn", rpname )

function rpnameSet(pl, cmd, arg)
	pl:SetRPName(arg[1])
	pl:SetModel(arg[2])
end
concommand.Add( "rpname_set", rpnameSet )