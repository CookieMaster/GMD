ILSB = ILSB or {}

-- The width scale of the scoreboard out of 1
ILSB['ScaleWidth'] = 0.6

-- The height scale of the scoreboard out of 1
ILSB['ScaleHeight'] = 0.7

-- The background color of the scoreboard
ILSB['BGColor'] = Color(255,255,255)

-- These are the main colors used, some for edge highlights and shading
ILSB['MainColors'] = {
	_main = Color(68,76,99),
	_dark = Color(61,67,91),
	_shade = Color(48,55,74),
	_shadea = Color(48,55,74,150),
	_bright = Color(78,86,109),
	_lgrey = Color(228,232,233),
	_lgreya = Color(228,232,233,100),
	_lviolet = Color(135,142,168),
	_grad = Color(61,68,87)
}

-- Here you can add custom ranks for specific ranks, or steam IDs
function ILSB:GetPlayerTag( ply )
	if ply:IsSuperAdmin() then
		return "SUPERADMIN" end
	if ply:IsAdmin() then
		return "ADMIN" end
	if ply:SteamID() == "" then
		return "ILYA" end
	
	-- return what you want to call normal users here
	return "USER"
end

-- Here you may add what players have access to see the admin commands.
-- If they can see it, they still cant use them if they are not a high enough
-- rank.
function ILSB:HasAccessToAdminButtons( ply )
	if ply:IsAdmin() then
		return true end
		
	return false
end

-- Colors used by the graph page
ILSB['GraphColors'] = {
	_teamlight = Color(255, 242, 242),
	_teamdark = Color(255, 130, 130),
	_moneylight = Color(230, 248, 252),
	_moneydark = Color(2, 182, 223)
}

-- Font settings for the MOTD page
ILSB['FontSettings'] = {
	font = 'calibri',
	size = 20,
	thickness = 1,
	color = Color(170,170,170)
}

-- The text for your MOTD page
ILSB['MOTD'] = [[
Your server name here
MOTD
                                                                          WELCOME!!!!!!!
RULES------

1. hi
2. hi how are you doing 
3. Whats gucci dawg. 
4. Versace versace versace versace
5. yolo
6.
...
]]

/* 
	------------------------------------------------------
						Adding Pages
	------------------------------------------------------
*/

/*
	---------- Layout ----------
	
	*****text page
	['name of page'] = {
		Type = "text",
		Text = [[
		Put You Text
		Here
		and 
		stuff
		]]
	}
	
	*****website page
	['name of page'] = {
		Type = "web",
		URL = "linktowebsite.com"
	}
*/

ILSB['ExtraPages'] = {
	
	-- You can remove the pages below if you don't want to have any extra pages.
	
	['Rule List'] = {	
		Type = "text",
		Text = [[
GENERAL                                            ROLEPLAY

1. No hax                                          1. Have Fun
2. No RDM                                        2. Don't be a dick
3. No cats                                         3. No cats





EXTRA

1. Blah
2. Blah 
3. More blah
]]
	},
	
	['Our Website'] = {
		Type = "web",
		URL = "www.google.com"
	},
}

-- If you need any help with anything, message me on steam or on coderhire. :)