
ILSB = ILSB or {}

surface.CreateFont('SB_motdfont', { font = ILSB['FontSettings'].font, size = ILSB['FontSettings'].size, weight = ILSB['FontSettings'].thickness })

function ILSB:DrawMOTD( parent )
	self.TitleText:SetText("MOTD")
	
	local text = ILSB:Text( 0, 0, parent:GetWide(), parent:GetTall(), ILSB['MOTD'], "SB_motdfont", ILSB['FontSettings'].color, parent)
	text:SetAutoStretchVertical(true)
	text:SetWrap(true)
end

function ILSB:DrawExtraTab( parent, _type, _string, name )
	self.TitleText:SetText(name)
	
	if _type == "text" then
		local text = ILSB:Text( 0, 0, parent:GetWide(), parent:GetTall(), _string, "SB_motdfont", ILSB['FontSettings'].color, parent)
		text:SetAutoStretchVertical(true)
		text:SetWrap(true)
	else
		ILSB.vgui[#ILSB.vgui+1] = vgui.Create( "HTML", parent)
		ILSB.vgui[#ILSB.vgui]:SetPos( 0, 0 )
		ILSB.vgui[#ILSB.vgui]:SetSize( parent:GetWide(), parent:GetTall() )
		ILSB.vgui[#ILSB.vgui]:OpenURL( _string )
	end
end