
ILSB = ILSB or {}

function ILSB:PlayerSettings( parent )
	self.TitleText:SetText("Player Settings")
	
	ILSB:DrawNiceCheckBox( 10, 10, "sb_draw_circular_masks", "Draw Circular Player Masks", parent)
	ILSB:DrawNiceCheckBox( 10, 40, "sb_draw_team_color", "Draw Job Color", parent)
	ILSB:DrawNiceCheckBox( 10, 70, "sb_draw_job", "Draw Player Job", parent)
	ILSB:DrawNiceCheckBox( 10, 100, "sb_draw_deaths", "Draw Player Deaths", parent)
	ILSB:DrawNiceCheckBox( 10, 130, "sb_draw_kills", "Draw Player Kills", parent)
	ILSB:DrawNiceCheckBox( 10, 160, "sb_draw_ping", "Draw Player Ping", parent)
end