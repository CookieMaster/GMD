
ILSB = ILSB or {}
ILSB.vgui = ILSB.vgui or {}

function ILSB:Box( x, y, w, h, c, p)
	ILSB.vgui[#ILSB.vgui+1] = VGUIRect( x, y, w, h )
	ILSB.vgui[#ILSB.vgui]:SetColor(c)
	ILSB.vgui[#ILSB.vgui]:SetParent(p)
	return ILSB.vgui[#ILSB.vgui]
end

function ILSB:Button( x, y, w, h, p, pp)
	ILSB.vgui[#ILSB.vgui+1] = vgui.Create( "DButton", p)
	ILSB.vgui[#ILSB.vgui]:SetPos( x, y )
	ILSB.vgui[#ILSB.vgui]:SetSize( w, h )
	ILSB.vgui[#ILSB.vgui]:SetText("")
	ILSB.vgui[#ILSB.vgui]:SetDrawBackground(false)
	if pp then
		ILSB.vgui[#ILSB.vgui].Paint = pp
	end
	return ILSB.vgui[#ILSB.vgui]
end

function ILSB:Avatar( x, y, w, h, ply, p)
	ILSB.vgui[#ILSB.vgui+1] = vgui.Create( "AvatarImage", p)
	ILSB.vgui[#ILSB.vgui]:SetPos( x, y )
	ILSB.vgui[#ILSB.vgui]:SetSize( w, h )
	ILSB.vgui[#ILSB.vgui]:SetPlayer( ply, w )
	return ILSB.vgui[#ILSB.vgui]
end

function ILSB:Text( x, y, w, h, tt, f, c, p)
	ILSB.vgui[#ILSB.vgui+1] = vgui.Create( "DLabel", p)
	ILSB.vgui[#ILSB.vgui]:SetPos( x, y )
	ILSB.vgui[#ILSB.vgui]:SetSize( w, h )
	ILSB.vgui[#ILSB.vgui]:SetText(tt)
	ILSB.vgui[#ILSB.vgui]:SetFont(f)
	ILSB.vgui[#ILSB.vgui]:SetColor(c)
	surface.SetFont(f)
	local ww, hh = surface.GetTextSize(tt)
	return ILSB.vgui[#ILSB.vgui], ww, hh
end

function ILSB:Scroll( x, y, w, h, p)
	ILSB.vgui[#ILSB.vgui+1] = vgui.Create( "DScrollPanel", p)
    ILSB.vgui[#ILSB.vgui]:SetSize( w, h)
    ILSB.vgui[#ILSB.vgui]:SetPos( x, y )
	ILSB.vgui[#ILSB.vgui].VBar.Paint = function( s, w, h )
		draw.RoundedBox( 0, 3, 13, 8, h-24, Color(0,0,0,70))
	end
	ILSB.vgui[#ILSB.vgui].VBar.btnUp.Paint = function( s, w, h ) end
	ILSB.vgui[#ILSB.vgui].VBar.btnDown.Paint = function( s, w, h ) end
	ILSB.vgui[#ILSB.vgui].VBar.btnGrip.Paint = function( s, w, h )
		draw.RoundedBox( 0, 5, 0, 4, h+22, Color(0,0,0,70))
	end
	return ILSB.vgui[#ILSB.vgui]
end

function ILSB:TextEntry( x, y, w, h, p, dt )
	ILSB.vgui[#ILSB.vgui+1] = vgui.Create("DFrame", p)
	ILSB.vgui[#ILSB.vgui]:SetSize(w, h)
	ILSB.vgui[#ILSB.vgui]:SetPos( x, y )
	ILSB.vgui[#ILSB.vgui]:MakePopup()
	ILSB.vgui[#ILSB.vgui]:SetDraggable(false)
	ILSB.vgui[#ILSB.vgui]:SetTitle("")
	ILSB.vgui[#ILSB.vgui]:ShowCloseButton(false)
	ILSB.vgui[#ILSB.vgui].Paint = function() end
	local dframe = ILSB.vgui[#ILSB.vgui]
	
	ILSB.vgui[#ILSB.vgui+1] = vgui.Create( "DTextEntry", dframe )
	ILSB.vgui[#ILSB.vgui]:SetText("")
	ILSB.vgui[#ILSB.vgui]:SetSize(w, h)
	ILSB.vgui[#ILSB.vgui]:SetPos(0, 0)
	ILSB.vgui[#ILSB.vgui].Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(230,230,230))
		draw.RoundedBox( 0, 1, 1, w-2, h-2, Color(255,255,255))
		s:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
	end
	ILSB.vgui[#ILSB.vgui].OnLoseFocus = function(t)
		dframe:KillFocus()
	end
	
	return ILSB.vgui[#ILSB.vgui], dframe
end

function ILSB:Info()

end

surface.CreateFont('SB_Checkbox', { font = 'calibri', size = 18, weight = 1 })
function ILSB:DrawNiceCheckBox( x, y, c, t, p)
	local btn = ILSB:Button( x, y, 300, 20, p, function( s, w, h )
		surface.SetMaterial(Material("vgui/white"))
		surface.SetDrawColor(ILSB['MainColors']._main)
		surface.DrawPoly(ILSB:GenCircle( 10, h/2, 10, 360))
		surface.SetMaterial(Material("vgui/white"))
		surface.SetDrawColor(color_white)
		surface.DrawPoly(ILSB:GenCircle( 10, h/2, 8, 360))
		s.State = s.State or 0
		if s.State == 1 then
			surface.SetMaterial(Material("vgui/white"))
			surface.SetDrawColor(ILSB['MainColors']._main)
			surface.DrawPoly(ILSB:GenCircle( 10, h/2, 6, 360))
		end
		draw.SimpleText(t, "SB_Checkbox", 30, h/2, Color(170,170,170), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end)
	btn.State = math.Clamp(GetConVarNumber(c), 0, 1)
	btn.DoClick = function(s)
		if s.State == 0 then
			s.State = 1
		else
			s.State = 0
		end
		RunConsoleCommand(c, s.State)
	end
end

ILSB.Icons = { -- Just cause I hate making clients DL shit
	[0] = function( w, h )
		draw.RoundedBox( 0, w/2-5, h/2, 11, 1, color_white)
		draw.RoundedBox( 0, w/2, h/2-5, 1, 11, color_white)
	end,
	
	[1] = function( w, h )
		draw.RoundedBox( 0, w/2-5, h/2-5, 10, 10, color_white)
		draw.RoundedBox( 0, w/2-4, h/2-4, 8, 8, ILSB['MainColors']._main)
	end,
	
	[2] = function( w, h )
		surface.SetMaterial(Material('vgui/white'))
		surface.SetDrawColor(Color(255,255,255))
		surface.DrawTexturedRectRotated( w/2, h/2, 10, 10, 45 )
		surface.SetMaterial(Material('vgui/white'))
		surface.SetDrawColor(ILSB['MainColors']._main)
		surface.DrawTexturedRectRotated( w/2, h/2, 8, 8, 45 )
	end
}