
ILSB = ILSB or {}

local cos, sin, pi = math.cos, math.sin, math.pi

surface.CreateFont('SB_player_name', { font = "calibri", size = 24, weight = 1 })
surface.CreateFont('SB_player_steam', { font = "coolvetica", size = 12, weight = 1 })
surface.CreateFont('SB_player_title', { font = "calibri", size = 23, weight = 1 })
surface.CreateFont('SB_player_lower', { font = "calibri", size = 18, weight = 1 })
surface.CreateFont('SB_button_text', { font = "calibri", size = 18, weight = 1 })

local function CleanButton( w, h, text, col1, e )
	local _col = color_white
	if e then _col = Color(240,240,240) end
	surface.SetMaterial(Material("vgui/white"))
	surface.SetDrawColor(col1)
	surface.DrawPoly(ILSB:GenCircle( w/2, h/2, w/2, 360))
	surface.SetMaterial(Material("vgui/white"))
	surface.SetDrawColor(_col)
	surface.DrawPoly(ILSB:GenCircle( w/2, h/2, w/2-2, 360))
	draw.SimpleText(text, "SB_button_text", w/2, h/2, col1, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

local function AddPlayerButton( x, y, text, parent, doclick)
	local btn = ILSB:Button( x, y, 70, 70, parent, function( s, w, h ) 
		CleanButton( w, h, text, ILSB['MainColors']._main, s.s ) 
	end)
	btn.OnCursorEntered = function(s) s.s = true end
	btn.OnCursorExited = function(s) s.s = false end
	btn.DoClick = doclick
end

local function OpenKickMenu( ply )
	Derma_StringRequest( 
		"Kick " .. ply:Nick() , 
		"Reason for kicking " .. ply:Nick(),
		"",
		function( text ) 
			 RunConsoleCommand("ulx", "kick", ply:Nick(), text)
		end,
		function() end
	)
end

local function OpenJailMenu( ply )
	Derma_StringRequest( 
		"Jail " .. ply:Nick() , 
		"Jail length for " .. ply:Nick(),
		"",
		function( text ) 
			if not string.match( length, "[%d]" ) then
				chat.AddText(color_white, "Jail length must be a number!")
				return 
			end
			RunConsoleCommand("ulx", "jail", ply:Nick(), text)
		end,
		function() end
	)
end

local function OpenBanMenu( ply )
	Derma_StringRequest( 
		"Ban Length of" .. ply:Nick() , 
		"Ban Length for " .. ply:Nick(),
		"",
		function( length ) 
			if not string.match( length, "[%d]" ) then
				chat.AddText(color_white, "Ban length must be a number!")
				return 
			end
			 Derma_StringRequest( 
				"Ban Reason " .. ply:Nick() , 
				"Reason for banning " .. ply:Nick(),
				"",
				function( text ) 
					RunConsoleCommand("ulx", "ban", ply:Nick(), tonumber(length), text)
				end,
				function() end
			)
		end,
		function() end
	)
end

local function OpenTeamMenu( ply )
	local team_menu = DermaMenu() 
	for _, t in pairs(team.GetAllTeams())do
		team_menu:AddOption( t.Name, function() RunConsoleCommand("_FAdmin", "setteam", ply:UserID(), _) end )
	end
	team_menu:AddOption( "Close", function() end )
	team_menu:Open()
end

function ILSB:OpenPlayer( parent, ply )
	if not IsValid(ply) then
		ILSB:Page( 0 )
		ILSB.CurTab = 0
		return
	end
	
	self.TitleText:SetText(ply:Nick())
	ILSB:Avatar( 5, 5, 64, 64, ply, parent)
	local a = ILSB:Box( 5, 5, 64, 64, Color(255,255,255), parent)
	a.Paint = function( s, w, h )
		for a = 1, 13 do -- For extra aa
			surface.SetMaterial(Material('vgui/white'))
			surface.SetDrawColor(Color(255,255,255))
				for i = 0, 360, a do
				local _i = i * pi/180;         
				surface.DrawTexturedRectRotated(cos(_i)*(39)+w/2, sin(_i)*(39)+h/2, 17, a*2, -i )
			end
		end
	end
	
	ILSB:Text( 80, 10, 200, 20, ply:Nick(), "SB_player_name", Color(170,170,170), parent)
	ILSB:Text( 83, 30, 200, 20, "(" .. ply:SteamID() .. ")", "SB_player_steam", Color(170,170,170), parent)
	
	ILSB:Text( 5, 90, 200, 20, "JOB: ", "SB_player_title", Color(170,170,170), parent)
	ILSB:Text( 15, 110, 200, 20, team.GetName(ply:Team()), "SB_player_lower", Color(170,170,170), parent)
	
	ILSB:Text( 5, 150, 200, 20, "MONEY: ", "SB_player_title", Color(170,170,170), parent)
	ILSB:Text( 15, 170, 200, 20, "$" .. string.Comma(ply:getDarkRPVar("money")), "SB_player_lower", Color(170,170,170), parent)
	
	ILSB:Text( 5, 210, 200, 20, "DEATHS: ", "SB_player_title", Color(170,170,170), parent)
	ILSB:Text( 15, 230, 200, 20, ply:Deaths(), "SB_player_lower", Color(170,170,170), parent)
	
	ILSB:Text( 5, 270, 200, 20, "KILLS: ", "SB_player_title", Color(170,170,170), parent)
	ILSB:Text( 15, 290, 200, 20, ply:Frags(), "SB_player_lower", Color(170,170,170), parent)
	
	ILSB:Text( 5, 330, 200, 20, "HEALTH: ", "SB_player_title", Color(170,170,170), parent)
	ILSB:Text( 15, 350, 200, 20, ply:Health() .. "%", "SB_player_lower", Color(170,170,170), parent)
	
	ILSB:Text( 5, 390, 200, 20, "ARMOR: ", "SB_player_title", Color(170,170,170), parent)
	ILSB:Text( 15, 410, 200, 20, ply:Armor() .. "%", "SB_player_lower", Color(170,170,170), parent)
	
	ILSB:Text( 5, 450, 200, 20, "RANK: ", "SB_player_title", Color(170,170,170), parent)
	ILSB:Text( 15, 470, 200, 20, ILSB:GetPlayerTag( ply ), "SB_player_lower", Color(170,170,170), parent)
	
	local btn = ILSB:Button( 230, 20, 100, 20, parent, function( s, w, h ) 
		draw.SimpleText("Copy SteamID", "SB_button_text", w/2, h/2, ILSB['MainColors']._main, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end)
	btn.DoClick = function() SetClipboardText(ply:SteamID()) end
	
	local btn = ILSB:Button( 360, 20, 100, 20, parent, function( s, w, h ) 
		draw.SimpleText("Copy Name", "SB_button_text", w/2, h/2, ILSB['MainColors']._main, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end)
	btn.DoClick = function() SetClipboardText(ply:Nick()) end
	
	local btn = ILSB:Button( 490, 20, 100, 20, parent, function( s, w, h ) 
		draw.SimpleText("Steam Profile", "SB_button_text", w/2, h/2, ILSB['MainColors']._main, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end)
	btn.DoClick = function() ply:ShowProfile() end
	
	-- admin functions
	
	if ILSB:HasAccessToAdminButtons( LocalPlayer() ) then
		AddPlayerButton( 220, 90+70, "Kick", parent, function() OpenKickMenu( ply ) end)
		AddPlayerButton( 220+90, 90+70, "Ban", parent, function() OpenBanMenu( ply ) end)
		AddPlayerButton( 220+180, 90+70, "Freeze", parent, function() RunConsoleCommand("ulx", "freeze", ply:Nick()) end)
		AddPlayerButton( 220+270, 90+70, "Un-Freeze", parent, function() RunConsoleCommand("ulx", "unfreeze", ply:Nick()) end)
		AddPlayerButton( 220+360, 90+70, "Mute", parent, function() RunConsoleCommand("ulx", "mute", ply:Nick()) end)
		AddPlayerButton( 220, 180+70, "Un-Mute", parent, function() RunConsoleCommand("ulx", "unmute", ply:Nick()) end)
		AddPlayerButton( 220+90, 180+70, "Set Team", parent, function() OpenTeamMenu( ply ) end)
		AddPlayerButton( 220+180, 180+70, "Jail", parent, function() OpenJailMenu( ply ) end)
		AddPlayerButton( 220+270, 180+70, "Strip Weps", parent, function() RunConsoleCommand("ulx", "strip", ply:Nick()) end)
		AddPlayerButton( 220+360, 180+70, "Gag", parent, function() RunConsoleCommand("ulx", "gag", ply:Nick()) end)
		AddPlayerButton( 220, 270+70, "Un-Gag", parent, function() RunConsoleCommand("ulx", "ungag", ply:Nick()) end)
		AddPlayerButton( 220+90, 270+70, "Go To", parent, function() RunConsoleCommand("ulx", "goto", ply:Nick()) end)
		AddPlayerButton( 220+180, 270+70, "Bring Here", parent, function() RunConsoleCommand("ulx", "bring", ply:Nick()) end)
		AddPlayerButton( 220+270, 270+70, "Slap", parent, function() RunConsoleCommand("ulx", "slap", ply:Nick()) end)
	end
end