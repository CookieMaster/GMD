
ILSB = ILSB or {}

local cos, sin, pi = math.cos, math.sin, math.pi

surface.CreateFont('SB_playername', { font = 'calibri', size = 19, weight = 1 })
surface.CreateFont('SB_playerping', { font = 'calibri', size = 19, weight = 1 })
surface.CreateFont('SB_playersteam', { font = 'coolvetica', size = 12, weight = 1 })
surface.CreateFont('SB_playerpingsmall', { font = 'coolvetica', size = 13, weight = 1 })

function ILSB:DrawPlayers( parent )
	self.TitleText:SetText("Player List")
	for _, ply in pairs(player.GetAll())do
		local width = parent:GetWide()
		if #player.GetAll()*52 > width then width = parent:GetWide()-20 end
		local btn = ILSB:Button( 0, (_-1)*52, width, 50, parent, function( s, w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color(218,222,223) )
			draw.RoundedBox( 0, 1, 1, w-2, h-2, Color(250,250,250) )
			draw.SimpleText(ply:Nick(), "SB_playername", 50, 15, Color(190,190,190), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(ILSB:GetPlayerTag( ply ), "SB_playersteam", 50, 32, Color(190,190,190), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			
			if GetConVarNumber("sb_draw_ping") == 1 then
				draw.SimpleText(ply:Ping(), "SB_playerping", w-50, h/2-5, Color(190,190,190), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText("PING", "SB_playerpingsmall", w-50, h/2+10, Color(190,190,190), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			
			if GetConVarNumber("sb_draw_deaths") == 1 then
				draw.SimpleText(ply:Deaths(), "SB_playerping", w-120, h/2-5, Color(190,190,190), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText("DEATHS", "SB_playerpingsmall", w-120, h/2+10, Color(190,190,190), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			
			if GetConVarNumber("sb_draw_kills") == 1 then
				draw.SimpleText(ply:Frags(), "SB_playerping", w-190, h/2-5, Color(190,190,190), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText("KILLS", "SB_playerpingsmall", w-190, h/2+10, Color(190,190,190), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
			
			if GetConVarNumber("sb_draw_job") == 1 then
				draw.SimpleText(string.upper(team.GetName(ply:Team())), "SB_playerping", w-250, h/2-5, Color(190,190,190), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
				draw.SimpleText("ROLE", "SB_playerpingsmall", w-250, h/2+10, Color(190,190,190), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			
			if GetConVarNumber("sb_draw_team_color") == 1 then
				draw.RoundedBox( 0, w-6, 1, 5, h-2, team.GetColor(ply:Team()) )
			end
		end)
		btn.DoClick = function()
			if IsValid(ply) then
				ILSB.CurTab = 4
				ILSB.SelectedPlayer = ply
				ILSB:Page( 4, ILSB.SelectedPlayer )
			end
		end
		ILSB:Avatar( 7, 50/2-16, 32, 32, ply, btn)
		local a = ILSB:Box( 7, 50/2-16, 32, 32, Color(250,250,250), btn)
		a.Paint = function( s, w, h )
			if GetConVarNumber("sb_draw_circular_masks") == 1 then
				for a = 1, 13 do -- For extra aa
					surface.SetMaterial(Material('vgui/white'))
					surface.SetDrawColor(Color(250,250,250))
						for i = 0, 360, a do
						local _i = i * pi/180;         
						surface.DrawTexturedRectRotated(cos(_i)*(24)+w/2, sin(_i)*(24)+h/2, 14, a*2, -i )
					end
				end
			end
		end
	end
end