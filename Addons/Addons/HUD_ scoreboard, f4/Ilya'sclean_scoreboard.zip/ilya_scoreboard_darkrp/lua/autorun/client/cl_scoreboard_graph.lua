
ILSB = ILSB or {}

surface.CreateFont('SB_graphname', { font = 'calibri', size = 16, weight = 1 })
surface.CreateFont('SB_graphinfo', { font = 'calibri', size = 16, weight = 1 })

local white_tex = surface.GetTextureID("vgui/white")

function ILSB:DrawGraph( parent )
	self.TitleText:SetText("Server Statistics")
	local width = parent:GetWide()-5
	
	
	local _Gap = (width-10)/#team.GetAllTeams()
	local _Size = 10
	bg_1 = ILSB:Box( 0, 0, width, parent:GetTall()/2-30, color_white, parent)
	bg_1.Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(225,227,231) )
		draw.RoundedBox( 0, 2, 2, w-4, h-4, Color(208,213,217) )
		draw.RoundedBox( 0, 3, 3, w-6, h-6, Color(255,255,255) )
	end
	for _, t in ipairs(team.GetAllTeams())do
		local __Size = Lerp(team.NumPlayers(_)/#player.GetAll(), 0, bg_1:GetTall()-6)
		ILSB:Button( 9+(_-1)*_Gap, math.max((bg_1:GetTall()-3)-__Size, 3), _Size, __Size, parent, function( s, w, h)
			s.height = s.height or h*2
			s.height = math.max(s.height - 6, 0)
			draw.RoundedBox( 0, 0, s.height, w, h, ILSB['GraphColors']._teamdark )
			draw.RoundedBox( 0, 1, s.height+1, w-2, h-1, ILSB['GraphColors']._teamlight )
		end)
	end	
	ILSB:Text( 6, 6, 200, 10, "Player Jobs", "SB_graphname", Color(170,170,170,180), bg_1)
	for _, t in ipairs(team.GetAllTeams())do
		local btn = ILSB:Button( 10+(_-1)*_Gap, parent:GetTall()/2-20, 8, 8, parent, function( s, w, h)
			draw.RoundedBox( 0, 0, 0, w, h, ILSB['MainColors']._main )
			draw.RoundedBox( 0, 1, 1, w-2, h-2, color_white )
			if _ == LocalPlayer():Team() then
				draw.RoundedBox( 0, 2, 2, w-4, h-4, ILSB['MainColors']._main )
			end
		end)
		btn.OnCursorEntered = function(s)
			s.b = ILSB:Box( gui.MouseX()-75, gui.MouseY()-80, 150, 70, Color(55, 57, 66))
			s.b.Paint = function( s, w, h )
				draw.RoundedBox( 0, 0, 0, w, h-10, s:GetColor() )
				surface.SetMaterial(Material('vgui/white'))
				surface.SetDrawColor(Color(55, 57, 66))
				surface.DrawPoly({
					{ x = w/2-10, y = h-10},
					{ x = w/2+10, y = h-10},
					{ x = w/2, y = h}
				})
				draw.SimpleText(team.GetName(_), "SB_graphinfo", w/2, h/2-10, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText(team.NumPlayers(_) .. " Players", "SB_graphinfo", w/2, h/2+2, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		btn.OnCursorExited = function(s)
			s.b:Remove()
		end
		btn.Think = function(s)
			if IsValid(s.b) then
				s.b:SetPos(gui.MouseX()-75, gui.MouseY()-80)
			end
		end
	end
	
	----------------------------------------------------------------------------------------
	
	local _Gap = (width-10)/#player.GetAll()
	local _Eco = 0
	for _, mon in pairs(player.GetAll())do if IsValid(mon) then _Eco = _Eco + mon:getDarkRPVar("money") end end
	bg_2 = ILSB:Box( 0, parent:GetTall()/2, width, parent:GetTall()/2-30, color_white, parent)
	bg_2.Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(225,227,231) )
		draw.RoundedBox( 0, 2, 2, w-4, h-4, Color(208,213,217) )
		draw.RoundedBox( 0, 3, 3, w-6, h-6, Color(255,255,255) )
	end
	for _, ply in ipairs(player.GetAll())do
		local __Size = Lerp(ply:getDarkRPVar("money")/_Eco, 0, bg_1:GetTall()-6)
		ILSB:Button( 9+(_-1)*_Gap, math.max(((bg_2:GetTall()*2+30)-3)-__Size, 3), _Size, __Size, parent, function( s, w, h)
			s.height = s.height or h*2
			s.height = math.max(s.height - 6, 0)
			draw.RoundedBox( 0, 0, s.height, w, h, ILSB['GraphColors']._moneydark )
			draw.RoundedBox( 0, 1, s.height+1, w-2, h-1, ILSB['GraphColors']._moneylight )
		end)
	end
	ILSB:Text( 6, 6, 200, 10, "Economy", "SB_graphname", Color(140,140,140,200), bg_2)
	ILSB:Text( 6, 18, 200, 10, "Total Eco: " .. string.Comma(_Eco), "SB_graphname", Color(140,140,140,180), bg_2)
	for _, ply in pairs(player.GetAll())do
		local btn = ILSB:Button( 10+(_-1)*_Gap, parent:GetTall()-20, 8, 8, parent, function( s, w, h)
			draw.RoundedBox( 0, 0, 0, w, h, ILSB['MainColors']._main )
			draw.RoundedBox( 0, 1, 1, w-2, h-2, color_white )
			if ply == LocalPlayer() then
				draw.RoundedBox( 0, 2, 2, w-4, h-4, ILSB['MainColors']._main )
			end
		end)
		btn.OnCursorEntered = function(s)
			s.b = ILSB:Box( gui.MouseX()-75, gui.MouseY()-80, 150, 70, Color(55, 57, 66))
			s.b.Paint = function( s, w, h )
				draw.RoundedBox( 0, 0, 0, w, h-10, s:GetColor() )
				surface.SetMaterial(Material('vgui/white'))
				surface.SetDrawColor(Color(55, 57, 66))
				surface.DrawPoly({
					{ x = w/2-10, y = h-10},
					{ x = w/2+10, y = h-10},
					{ x = w/2, y = h}
				})
				draw.SimpleText(ply:Nick(), "SB_graphinfo", w/2, h/2-10, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText("$" .. string.Comma(ply:getDarkRPVar("money")), "SB_graphinfo", w/2, h/2+2, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end
		btn.OnCursorExited = function(s)
			s.b:Remove()
		end
		btn.Think = function(s)
			if IsValid(s.b) then
				s.b:SetPos(gui.MouseX()-75, gui.MouseY()-80)
			end
		end
	end
	
end