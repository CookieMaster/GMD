
ILSB = ILSB or {}
ILSB.vgui = ILSB.vgui or {}
ILSB.CurTab = 0
ILSB.SelectedPlayer = LocalPlayer()

surface.CreateFont('SB_rpname', { font = 'coolvetica', size = 12, weight = 1 })
surface.CreateFont('SB_pagetitle', { font = 'calibri', size = 35, weight = 1 })
surface.CreateFont('SB_topname', { font = 'calibri', size = 13})
surface.CreateFont('SB_topextraname', { font = 'calibri', size = 20})
surface.CreateFont('SB_playercount', { font = 'calibri', size = 23})
surface.CreateFont('SB_playercountlower', { font = 'calibri', size = 16})

local grad_down = surface.GetTextureID( "vgui/gradient_down" )
local grad_up = surface.GetTextureID( "vgui/gradient_up" )
local grad_left = surface.GetTextureID( "gui/center_gradient" )

timer.Simple(1, function()
	hook.Remove("ScoreboardShow", "FAdmin_scoreboard")
	hook.Remove("ScoreboardHide", "FAdmin_scoreboard")
end)

local sin, cos, rad, pi = math.sin, math.cos, math.rad, math.pi
function ILSB:GenCircle( x, y, radius, quality)
    local circle = {}
    local tmp = 0
    for i = 1, quality do
        tmp = rad(i*360)/quality
        circle[i] = {x = x + cos(tmp)*radius,y = y + sin(tmp)*radius}
    end
    return circle
end

function ILSB:CircleOutline( w, c, x, y )
	surface.SetMaterial(Material("vgui/white"))
	surface.SetDrawColor(color_white)
	surface.DrawPoly(ILSB:GenCircle( x, y, w/2, 360))
	surface.SetMaterial(Material("vgui/white"))
	surface.SetDrawColor(c)
	surface.DrawPoly(ILSB:GenCircle( x, y, w/2-2, 360))
end

function ILSB:Page( page, ply, _type, _string, name )
	if IsValid(self.MainScroll) then self.MainScroll:Remove() end
	self.MainScroll = ILSB:Scroll( 198+5, 68+5, self.BG:GetWide()-(198+10), self.BG:GetTall()-(68+10), self.BG) 
	if page == 0 then
		ILSB:DrawPlayers( self.MainScroll )
	elseif page == 1 then
		ILSB:DrawGraph( self.MainScroll )
	elseif page == 2 then
		ILSB:DrawMOTD( self.MainScroll )
	elseif page == 3 then
		ILSB:PlayerSettings( self.MainScroll )
	elseif page == 4 then
		if not IsValid(ply) then ply = LocalPlayer() ILSB.SelectedPlayer = LocalPlayer() end
		ILSB:OpenPlayer( self.MainScroll, ply )
	elseif page == 5 then
		ILSB:DrawExtraTab( self.MainScroll, _type, _string, name )
	end
end

function ILSB:Sidebar()
	self.SideBG = ILSB:Box( 0, 0, 198, ScrH()*ILSB['ScaleHeight'], ILSB['MainColors']._main, self.BG)
	
	-- top divider
	ILSB:Box( 0, 66, 198, 4, ILSB['MainColors']._dark, self.SideBG)
	ILSB:Box( 0, 66, 198, 1, ILSB['MainColors']._shade, self.SideBG)
	ILSB:Box( 0, 66+4, 198, 1, ILSB['MainColors']._bright, self.SideBG)
	
	local fix_pos = 0
	
	if table.Count(ILSB['ExtraPages']) > 0 then
		ILSB:Text( 5, 85, 198, 25, "Extras", "SB_topextraname", ILSB['MainColors']._lviolet, self.SideBG)
		
		local _i = 1
		for _, page in pairs(ILSB['ExtraPages'])do
			local btn = ILSB:Button( 0, 66+_i*41, 198, 40, self.SideBG, function( s, w, h )
				draw.RoundedBox( 0, 0, 0, w, h, Color(53,61,80, s.a or 0) )
				draw.RoundedBox( 0, 0, 0, 4, h, Color(0,181,249, s.a or 0) )
				draw.SimpleText( _, "SB_topname", 20, h/2, Color(255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end)
			btn.OnCursorEntered = function(s) s.s = true end
			btn.OnCursorExited = function(s) s.s = false end
			btn.Think = function(s)
				if ILSB.CurTab == 5 and self.TitleText:GetText() == _ then 
					s.a = 255 
				elseif s.s then
					s.a = 100
				else
					s.a = 0
				end
			end
			btn.DoClick = function()
				local str = page.URL
				if page.Type == "text" then
					str = page.Text
				end
				ILSB.CurTab = 5
				ILSB:Page( 5, nil, page.Type, str, _ )
			end
			_i = _i + 1
		end
	
		ILSB:Box( 0, 70+(table.Count(ILSB['ExtraPages'])+1)*41, 198, 4, ILSB['MainColors']._dark, self.SideBG)
		ILSB:Box( 0, 70+(table.Count(ILSB['ExtraPages'])+1)*41, 198, 1, ILSB['MainColors']._shade, self.SideBG)
		ILSB:Box( 0, 70+(table.Count(ILSB['ExtraPages'])+1)*41+4, 198, 1, ILSB['MainColors']._bright, self.SideBG)
	else
		fix_pos = 50
	end
	
	local OnlineAdmins = {}
	for _, ply in pairs(player.GetAll())do
		if ILSB:HasAccessToAdminButtons( ply ) then
			table.insert(OnlineAdmins, ply)
		end
	end
	
	if #OnlineAdmins > 0 then
		local start = (120+(table.Count(ILSB['ExtraPages'])+1)*41)-fix_pos
		local scrl = ILSB:Scroll( 0, start, 198, self.SideBG:GetTall()-(start+46), self.SideBG)
		ILSB:Text( 5, (85+(table.Count(ILSB['ExtraPages'])+1)*41)-fix_pos, 198, 25, "Admins Online", "SB_topextraname", ILSB['MainColors']._lviolet, self.SideBG)
		
		for _, admin in pairs(OnlineAdmins)do
			local ava = ILSB:Avatar( 5, (_-1)*40, 32, 32, admin, scrl)
			local a = ILSB:Box( 5, (_-1)*40, 32, 32, Color(250,250,250), scrl)
			a.Paint = function( s, w, h )
				for a = 1, 13 do -- For extra aa
					surface.SetMaterial(Material('vgui/white'))
					surface.SetDrawColor(ILSB['MainColors']._main)
					for i = 0, 360, a do
						local _i = i * pi/180;         
						surface.DrawTexturedRectRotated(cos(_i)*(24)+w/2, sin(_i)*(24)+h/2, 14, a*2, -i )
					end
				end
			end
			local btn = ILSB:Button( 0, (_-1)*40, 198, 40, scrl, function( s, w, h )
				draw.SimpleText( admin:Nick(), "SB_topname", 45, 10, Color(230,230,230), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText( ILSB:GetPlayerTag( admin ), "SB_topname", 45, 22, Color(124,132,155), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end)
			btn.DoClick = function( s, w, h )
				if IsValid(admin) then
					ILSB.CurTab = 4
					ILSB.SelectedPlayer = admin
					ILSB:Page( 4, ILSB.SelectedPlayer )
				end
			end
			
			scrl:AddItem(ava)
			scrl:AddItem(a)
			scrl:AddItem(btn)
		end
	end
	
	-- top 3 buttons
	for i, o in pairs({"Players", "Graph", "MOTD"}) do
		local btn = ILSB:Button( 66*(i-1), 0, 66, 66, self.SideBG, function( s, w, h )
			draw.RoundedBox( 0, 0, 0, w, h, ILSB['MainColors']._main )
			if (i-1) != 0 then
				draw.RoundedBox( 0, 0, 0, 1, h, ILSB['MainColors']._shade )
			end
			draw.RoundedBox( 0, w-1, 0, 1, h, ILSB['MainColors']._bright )
			local c = ILSB['MainColors']._grad
			surface.SetDrawColor( Color(c.r,c.g,c.b,s.a) )
			surface.SetTexture( grad_down )
			surface.DrawTexturedRect( 0, 0, w, h )
			ILSB:CircleOutline( w*0.4, ILSB['MainColors']._main, w/2, h/2 )
			ILSB.Icons[(i-1)]( w, h )
			draw.SimpleText(o, "SB_topname", w/2, h-10, Color(255,255,255,50), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end)
		btn.OnCursorEntered = function(s) s.s = true end
		btn.OnCursorExited = function(s) s.s = false end
		btn.Think = function(s)
			s.a = s.a or 0
			if (i-1) == ILSB.CurTab then
				s.a = 220
			elseif s.s then
				s.a = math.min( s.a + 3, 220 )
			else
				s.a = math.max( s.a - 3, 0 )
			end
		end
		btn.DoClick = function()
			ILSB.CurTab = (i-1)
			ILSB:Page( ILSB.CurTab )
		end
	end

	-- bottom stuff	
	local gr = ILSB:Box( 0, ScrH()*ILSB['ScaleHeight']-49, 198, 4, ILSB['MainColors']._main, self.BG)
	gr.Paint = function( s, w, h )
		surface.SetDrawColor( ILSB['MainColors']._shadea )
		surface.SetTexture( grad_up )
		surface.DrawTexturedRect( 0, 0, w, 4 )
	end
	local d = ILSB:Box( 0, ScrH()*ILSB['ScaleHeight']-45, 148, 45, ILSB['MainColors']._main, self.BG)
	d.Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, ILSB['MainColors']._main )
		draw.RoundedBox( 0, 0, 0, w, 1, ILSB['MainColors']._bright )
		draw.RoundedBox( 0, w-1, 0, 1, h, ILSB['MainColors']._bright )
	end
	ILSB:Avatar( 7, 45/2-16, 32, 32, LocalPlayer(), d)
	local a = ILSB:Box( 7, 45/2-16, 32, 32, ILSB['MainColors']._main, d)
	a.Paint = function( s, w, h )
		for a = 1, 13 do -- For extra aa
			surface.SetMaterial(Material('vgui/white'))
			surface.SetDrawColor(ILSB['MainColors']._main)
			for i = 0, 360, a do
				local _i = i * math.pi/180;         
				surface.DrawTexturedRectRotated(math.cos(_i)*(24)+w/2, math.sin(_i)*(24)+h/2, 14, a*2, -i )
			end
		end
	end
	local h = ILSB:Box( 47, 10, 90, 10, ILSB['MainColors']._main, d)
	h.Paint = function( s, w, h )
		local hl = Lerp(LocalPlayer():Health()/100, 0, w)
		draw.RoundedBox( 0, 0, 0, w, h, ILSB['MainColors']._dark )
		draw.RoundedBox( 0, 0, 0, hl, h, ILSB['MainColors']._bright)
	end
	ILSB:Text( 48, 25, 90, 15, LocalPlayer():Nick(), "SB_rpname", ILSB['MainColors']._lviolet, d)
	local btn = ILSB:Button( 148, ScrH()*ILSB['ScaleHeight']-45, 50, 45, self.SideBG, function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, ILSB['MainColors']._main )
		draw.RoundedBox( 0, 0, 0, w, 1, ILSB['MainColors']._bright )
		draw.RoundedBox( 0, 0, 0, 1, h, ILSB['MainColors']._shade )
		surface.SetDrawColor( ILSB['MainColors']._lviolet )
		surface.SetMaterial( Material("icon16/cog.png") )
		surface.DrawTexturedRect( w/2-8, h/2-8, 16, 16 )
	end)
	btn.DoClick = function()
		ILSB.CurTab = 3
		ILSB:Page( ILSB.CurTab )
	end
	
	-- slight gradient right to left
	local ss = ILSB:Box( 198-5, 0, 5, ScrH()*ILSB['ScaleHeight'], ILSB['MainColors']._shadea, self.BG)
	ss.Paint = function( s, w, h )
		surface.SetDrawColor( ILSB['MainColors']._shadea )
		surface.SetTexture( grad_left )
		surface.DrawTexturedRect( 0, 0, w, h )
	end
	
	--ILSB['ExtraPages']
	local extra, _string = "", ""
	if table.Count(ILSB['ExtraPages']) > 0 then 
		extra = table.GetFirstKey( ILSB['ExtraPages'] ) 
		if ILSB['ExtraPages'][extra].Type == "text" then
			_string = ILSB['ExtraPages'][extra].Text
		else
			_string = ILSB['ExtraPages'][extra].URL
		end
	end
	ILSB:Page( ILSB.CurTab, ILSB.SelectedPlayer, ILSB['ExtraPages'][extra].Type, _string, extra )
end

function ILSB:Draw()
	self.BG = ILSB:Box( ScrW()/2-((ScrW()*ILSB['ScaleWidth'])/2), ScrH()/2-((ScrH()*ILSB['ScaleHeight'])/2), ScrW()*ILSB['ScaleWidth'], ScrH()*ILSB['ScaleHeight'], ILSB['BGColor'])
	self.TitleText = ILSB:Text( 210, 3, 300, 60, "nil", "SB_pagetitle", Color(200,200,200), self.BG)
	self.PlayerCount = ILSB:Text( self.BG:GetWide()-80, 3, 300, 60, "0/"..game.MaxPlayers(), "SB_playercount", Color(200,200,200), self.BG)
	self.PlayerCount.Think = function(s)
		s:SetText(#player.GetAll() .. "/" .. game.MaxPlayers())
	end
	ILSB:Text( self.BG:GetWide()-80, 20, 300, 60, "PLAYERS", "SB_playercountlower", Color(200,200,200), self.BG)
	ILSB:Box( 198, 66, ScrW()*ILSB['ScaleWidth']-198, 1, ILSB['MainColors']._lgrey, self.BG)
	local g = ILSB:Box( 198, 67, ScrW()*ILSB['ScaleWidth']-198, 4, ILSB['MainColors']._lgrey, self.BG)
	g.Paint = function( s, w, h )
		surface.SetDrawColor( ILSB['MainColors']._lgreya )
		surface.SetTexture( grad_down )
		surface.DrawTexturedRect( 0, 0, w, h )
	end
	ILSB:Sidebar()
	return true
end

function ILSB:Remove()
	for _, elem in pairs(ILSB.vgui)do
		elem:Remove()
	end
end

hook.Add("ScoreboardHide", "Ilya_Scoreboard", function()
	ILSB:Remove()
	gui.EnableScreenClicker(false)
	return true
end)

hook.Add("ScoreboardShow", "Ilya_Scoreboard", function()
	ILSB:Draw()
	gui.EnableScreenClicker(true)
	return true
end)
