
-- If should draw player team colors
CreateClientConVar("sb_draw_team_color", 0, true, false)

CreateClientConVar("sb_draw_circular_masks", 0, true, false)

CreateClientConVar("sb_draw_deaths", 1, true, false)

CreateClientConVar("sb_draw_kills", 1, true, false)

CreateClientConVar("sb_draw_ping", 1, true, false)

CreateClientConVar("sb_draw_job", 1, true, false)
