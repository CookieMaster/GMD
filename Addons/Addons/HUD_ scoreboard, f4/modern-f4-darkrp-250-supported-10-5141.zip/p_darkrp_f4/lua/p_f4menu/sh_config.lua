PF4.devmode = true;


PF4.center_width = 0.6
PF4.sidebar_width = ( 1 - PF4.center_width ) / 2; -- DON'T EDIT THIS.
PF4.sidebar_padding = 50 -- in pixels.
PF4.menu_height = 0.7

PF4.corner_size = 40;
PF4.header_size = 60;

PF4.open_anim_time = 0.3;
PF4.time_switchtab = 0.3;
PF4.time_showinfo = 0.2;

-- NAV BAR
PF4.navbar_textheight = 28;
PF4.navbar_linepadding = 20;
PF4.navbar_defaultcol = Color( 255, 255, 255, 0 );
PF4.navbar_hovercol = Color( 255, 255, 255, 40 );
PF4.navbar_selectedcol = Color( 255, 255, 255, 50 );

-- COLORS 
PF4.transbg_dark = Color( 0, 0, 0, 220 ) -- the semi transparent black background color.



-- TABS

-- JOB TAB
PF4.jobicon_bgcol = Color( 0, 0, 0, 100 ); -- background for job icons on the main list.
PF4.jobtab_IconTitleSize = 20;
PF4.jobtab_DescFontSize = 16;
PF4.jobtab_PlayerCountSize = 32;
PF4.jobtab_DescAnimTime = 0.3;
PF4.jobtab_iconhover = Color( 255, 255, 255, 5 );
PF4.jobtab_hoveranimtime = 0.1;

PF4.jobtab_info_iconbg = Color( 255, 255, 255, 10 );
PF4.jobtab_info_mdlbutSize = 128;
PF4.jobtab_info_changeteamSize = 64;

-- SHOP TAB
PF4.shoptab_ItemTitleSmallSize = 20;
PF4.shoptab_CostSize = 20;
PF4.shoptab_BuyItemSize = 50;

-- COMMANDS TAB
PF4.commandstab_CommandHeight = 30;
PF4.commandstab_FontHeight = 22

timer.Simple( 0, function( )
	local version = string.Explode( '.', GAMEMODE.Version or '0.0.0' );
	local vNum = 0;
	for k,v in ipairs( version )do
		vNum = vNum * 10 + tonumber( v );
	end
	PF4.version = vNum;
end);