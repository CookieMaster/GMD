local TABINFO = TABINFO;

-- TESTING PURPOSES ONLY.
TABINFO.name = 'Shop';
TABINFO.index = 2;

local itemCache = {};

local function GetNewList( parent, title, color )
	local ListWrapper = vgui.Create('DSizeToContents', parent );
	ListWrapper:SetWide( parent:GetWide() );
	ListWrapper:Dock( TOP );
	ListWrapper:DockMargin( 0, 10, 0, 0 );

	-- LABEL.
	local lbl = vgui.Create("DLabel", ListWrapper );
	lbl:SetColor( color );
	lbl:SetText( title );
	lbl:SetFont( 'PF4_EntShopCatTitle' );
	lbl:SizeToContents( )
	lbl:Dock( TOP );

	function lbl:Paint( w, h )
		surface.SetDrawColor( 255, 255, 255, 20 );
		surface.DrawRect( 0, 0, w, h );
	end


	local List   = vgui.Create( "DIconLayout", ListWrapper );
	List:SetWide( parent:GetWide() )
	List:SetSpaceY( 5 )
	List:SetSpaceX( 5 )
	List:Dock( TOP );

	function List:Paint( )
	end

	return List;
end

local function ListAddItem( parent, itemtbl, clipper, w, h )
	local item;
	if( itemCache[ tostring( itemtbl )] )then
		item = itemCache[ tostring( itemtbl ) ];
		item:SetSize( w, h );
		item.clipper = clipper
	else
		item = vgui.Create('pf4_shopicon');
		item:SetSize( w, h );
		item.clipper = clipper
		item:SetItem( itemtbl );
	end
	parent:Add( item );

	return item;
end

-- BUY ACTIONS
local function SAY_COMMAND( self )
	LocalPlayer():ConCommand( 'say ' .. self.command .. '\n' );
end

local function CON_COMMAND( self )
	LocalPlayer():ConCommand( self.command .. '\n' );
end

TABINFO.build = function( self, w, h )
	local scroller = vgui.Create( 'DScrollPanel', self );
	scroller:SetSize( self:GetSize() );
	scroller:SetPos( 0, 0 );
	
	-- MODIFY THE SCROLLBAR
	local scrollbar = scroller.VBar;
	local scrollbar_bg = Color( 255, 255, 255, 100 );
	local scrollbar_grip = Color( 255, 255, 255, 20 );
	function scrollbar:Paint( w, h ) end
	function scrollbar.btnGrip:Paint( w, h )
		draw.RoundedBox( 4, 3, 0, w-6, h, scrollbar_grip );
	end
	function scrollbar.btnUp:Paint() end
	function scrollbar.btnDown:Paint() end

	self.scroller = scroller;
end


TABINFO.update = function( self, w, h )
	local start = SysTime( );

	local scroller = self.scroller;
	scroller:Clear();

	local size_w = self:GetWide() / 8 - 7;
	local size_h = size_w * 1.2

	local list_AmmoPistols = GetNewList( scroller, 'AMMO / PISTOLS', color_white );

			-- ADD SINGLE WEAPONS
			for k,v in pairs(CustomShipments) do
				if (v.seperate) then
					local item = ListAddItem( list_AmmoPistols, { 
							model = v.model,
							name = v.name,
							price = v.price,
							action = SAY_COMMAND,
							command = "/buy " .. v.name,
							color = color_white,
							o = v
						}, scroller, size_w, size_h );
				end
			end

			-- ADD AMMO
			for k,v in pairs(GAMEMODE.AmmoTypes) do
				if not v.customCheck or v.customCheck(LocalPlayer()) then
					local item = ListAddItem( list_AmmoPistols, { 
							model = v.model,
							name = v.name,
							price = v.price,
							action = SAY_COMMAND,
							command = "/buyammo " .. v.ammoType,
							color = color_white,
							o = v
						}, scroller, size_w, size_h );
				end
			end

	local list_Entities = GetNewList( scroller, 'ENTITIES', color_white );
			for k,v in pairs(DarkRPEntities) do
				if not v.allowed or (type(v.allowed) == "table" and table.HasValue(v.allowed, LocalPlayer():Team()))
					and (not v.customCheck or (v.customCheck and v.customCheck(LocalPlayer()))) then
					local cmdname = string.gsub(v.ent, " ", "_")
					
					local item = ListAddItem( list_Entities, { 
							model = v.model,
							name = v.name,
							price = v.price,
							action = SAY_COMMAND,
							command = PF4.version < 250 and v.cmd or ( '/'..v.cmd ),
							color = color_white,
							o = v
						}, scroller, size_w, size_h );
				end
			end


	local list_Shipments = GetNewList( scroller, 'SHIPMENTS', color_white );
			for k,v in pairs(CustomShipments) do
				if not v.noship and table.HasValue(v.allowed, LocalPlayer():Team())
					and (not v.customCheck or (v.customCheck and v.customCheck(LocalPlayer()))) then
					local item = ListAddItem( list_Shipments, { 
							model = v.model,
							name = v.name,
							price = v.price,
							action = SAY_COMMAND,
							command = '/buyshipment '..v.name,
							color = color_white,
							o = v
						}, scroller, size_w, size_h );
				end
			end


	print("UPDATED SHOP TAB IN: ".. ( SysTime() - start ));
	return self;
end
