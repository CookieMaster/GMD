local TABINFO = TABINFO;

-- TESTING PURPOSES ONLY.
TABINFO.name = 'Jobs';
TABINFO.index = 1;

local function check_CanJoinTeam( v )
	-- check to make sure we're aloud.
	local nodude = true
	if v.admin == 1 and not LocalPlayer():IsAdmin() then
		nodude = false
	end
	if v.admin > 1 and not LocalPlayer():IsSuperAdmin() then
		nodude = false
	end
	if v.customCheck and not v.customCheck(LocalPlayer()) then
		nodude = false
	end

	if (type(v.NeedToChangeFrom) == "number" and LocalPlayer():Team() ~= v.NeedToChangeFrom) or (type(v.NeedToChangeFrom) == "table" and not table.HasValue(v.NeedToChangeFrom, LocalPlayer():Team())) then
		nodude = false
	end

	if nodude then
		return true;
	else
		return false;
	end
end



TABINFO.build = function( self, w, h )
	local scroller = vgui.Create( 'DScrollPanel', self );
	scroller:SetSize( self:GetSize() );
	scroller:SetPos( 0, 0 );

	-- MODIFY THE SCROLLBAR
	local scrollbar = scroller.VBar;
	local scrollbar_bg = Color( 255, 255, 255, 100 );
	local scrollbar_grip = Color( 255, 255, 255, 20 );
	function scrollbar:Paint( w, h ) end
	function scrollbar.btnGrip:Paint( w, h )
		draw.RoundedBox( 4, 3, 0, w-6, h, scrollbar_grip );
	end
	function scrollbar.btnUp:Paint() end
	function scrollbar.btnDown:Paint() end

	
	local List   = vgui.Create( "DIconLayout", scroller );
	List:SetPos( 2, 2 );
	List:SetSize( self:GetWide() - 4, self:GetTall() - 4 );
	List:SetSpaceY( 5 )
	List:SetSpaceX( 5 )

	self.scroller = scroller;
	self.list = List;
end


TABINFO.update = function( self, w, h )
	local start = SysTime( );

	local scroller, List = self.scroller, self.list;

	List:Clear( );

	-- build the job icons.
	local itemH = (self:GetTall() - 4)/3 - 5;
	local itemW = itemH * 0.8; -- items are slightly narrower than they are tall.
	itemW = math.floor( self:GetWide() / math.floor( self:GetWide() / itemW ) - 5);


	for k,v in pairs( RPExtraTeams )do
		if( check_CanJoinTeam( v ) )then
			v.teamid = k;

			local icon = vgui.Create('pf4_jobicon');
			icon:SetSize( itemW, itemH );
			icon.clipper = scroller;
			icon:SetJob( v );
			icon.TAB = TABINFO;

			List:Add( icon );
		end
	end

	print("UPDATED JOBS TAB IN: ".. ( SysTime() - start ));

	return self;
end
