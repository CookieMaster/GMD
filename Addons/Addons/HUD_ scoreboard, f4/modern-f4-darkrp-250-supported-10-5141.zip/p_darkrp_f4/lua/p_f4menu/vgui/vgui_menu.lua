local PANEL = {}

-- WRAPPER PANEL FOR THE SUB PANELS

function PANEL:Init()
	PF4.menu = self;

	self:SetPos( 0, 0 );
	self:SetSize( ScrW(), ScrH() );

	-- CENTER PANEL
	-- NAVIGATION
	self.center = vgui.Create( 'pf4_menu_center', self );
	self.nav = vgui.Create( 'pf4_sidenav', self );
	self.sideinfo = vgui.Create( 'pf4_menu_info', self );

	-- LOAD TABS.
	for k,v in SortedPairs( PF4.menu_tabs )do
		self:BuildTab( v );
	end

	print( PF4.menu_tabs[ 1 ] );
	self:OpenTab( PF4.menu_tabs[ 1 ] )

	self.nav:AddOption( 'close', function()
		self:Hide( PF4.time_switchtab );
	end, true ) 
end

function PANEL:BuildTab( tab )
	self.nav:AddOption( tab.name, function()
		if( tab.button )then
			tab.button( );
		else
			self:OpenTab( tab );
		end
	end )
	if( tab.button )then return end;
	local workarea = self.center:GetWorkarea( tab.name );
	tab.build( workarea, workarea:GetSize() );
end

function PANEL:OpenTab( tab )
	-- first we must update the tab.
	local p_tab = self.center:GetWorkarea( tab.name );

	-- then display it.
	self.center:SwitchToWorkarea( tab.name, PF4.time_switchtab, nil, function( )
		-- wait a lil bit to update it.
		if( tab.update )then
			tab.update( p_tab );
		end

		self.center.Title:SetText( tab.name );
		self.center.Title:SizeToContents( );
	end );
end

-- show and hide
local hasReleasedF4;
function PANEL:Show()
	hasReleasedF4 = false;

	self:SetVisible( true );
	self:MakePopup();

	RestoreCursorPosition();

	for k,v in pairs( self:GetChildren() )do
		if( v.Show )then v:Show( PF4.open_anim_time ) end
	end
end

function PANEL:Hide()
	for k,v in pairs( self:GetChildren() ) do
		if( v.Hide )then v:Hide( PF4.open_anim_time ) end
	end

	RememberCursorPosition()

	timer.Simple( PF4.open_anim_time, function()
		self:SetVisible( false );
	end)
end

function PANEL:Think()
	if input.IsKeyDown(KEY_F4) and hasReleasedF4 then
		self:Hide( );
	elseif not input.IsKeyDown(KEY_F4) then
		hasReleasedF4 = true
	end
end

function PANEL:Paint( w, h )
	-- invisible.
end

vgui.Register( "pf4_menu", PANEL, 'DPanel' );

