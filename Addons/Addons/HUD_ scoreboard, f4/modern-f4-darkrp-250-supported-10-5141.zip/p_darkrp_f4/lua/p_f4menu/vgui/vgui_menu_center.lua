local PANEL = {}

function PANEL:Init()
	self:SetWidth( PF4.center_width * self:GetParent():GetWide() );
	self:SetHeight( PF4.menu_height * self:GetParent():GetTall() );
	self:SetPos( ( self:GetParent():GetWide() - self:GetWide() ) / 2, ( self:GetParent():GetTall() - self:GetTall() ) / 2 );

	self.startx, self.starty = self:GetPos();

	self.contentarea = vgui.Create( 'DPanel', self );
	function self.contentarea:Paint() end

	self.contentarea:SetPos( 0, PF4.header_size )
	self.contentarea:SetSize( self:GetWide(), self:GetTall() - PF4.header_size * 2 );


	self.storagearea = vgui.Create('DPanel', self );
	self.storagearea:SetVisible( false );


	self.workareas = {}
	self.activearea = nil;


	-- THE TITLE TEXT LIK A BAWS
	self.Title = Label( '[UNKNOWN]', self );
	self.Title:SetFont( 'PF4_PanelHeader' );
	self.Title:SizeToContents( );
	self.Title:SetPos( PF4.corner_size, ( PF4.header_size - self.Title:GetTall() ) / 2 );
end

function PANEL:GetWorkarea( index )
	local panel = self.workareas[ index ]
	if( panel )then return panel end

	local newPanel = vgui.Create('DPanel', self.storagearea );
	newPanel:SetSize( self.contentarea:GetSize() );
	newPanel:SetPos( 0, 0 );

	self.workareas[ index ] = newPanel;

	function newPanel:Paint( ) end

	return newPanel;
end

function PANEL:OpenWorkarea( index )
	print( "OPENING: "..index );
	if( self.activearea )then
		self.activearea:SetParent( self.storagearea );
		self.activearea:SetZPos( 1 );
	end

	local panel = self.workareas[ index ];
	self.activearea = panel;
	
	if( not panel )then return end

	panel:SetParent( self.contentarea );
	panel:SetZPos( 100 );

	self:InvalidateLayout( );
	self:InvalidateChildren( );
	print("OPENED!");
end

function PANEL:Show( time, cback )
	self:SetPos( self.startx, -self:GetTall() );
	self:MoveTo( self.startx, self.starty, time, 0.1, 1, cback );
end

function PANEL:Hide( time, cback )
	--self:SetPos( self.startx, self.starty );
	self:MoveTo( self.startx, self:GetParent():GetTall(), time, 0, 1, cback );
end

function PANEL:SwitchToWorkarea( index, time, cback, cbackhalf )
	self:Hide( time / 2, function( )
		if( cbackhalf )then cbackhalf( ) end

		self:OpenWorkarea( index );
		self:Show( time / 2, cback )
	end)
	self:GetParent().sideinfo:Hide( time );
end

function PANEL:PaintOver( w, h )

end

vgui.Register( "pf4_menu_center", PANEL, 'PF4_BasePanel' );