local hovercolor = PF4.jobtab_iconhover


local PANEL = {}
function PANEL:Init()
	-- not much to do here.
	-- go away.
end



local function DModelPanel_PaintFix(self, w, h )

	if ( !IsValid( self.Entity ) ) then return end
	
	local x, y = self:LocalToScreen( 0, 0 )	

	local superParent = self.clipper; -- doing stuff like this makes me want to scream inside, but there isn't really another way
					-- that would actually be worth the time and effort.
	local px, py = superParent:LocalToScreen();
	local pw, ph = superParent:GetSize();

	render.SetScissorRect( math.max( px, x ), math.max( py, y ), math.min(px + pw, x + pw ), math.min( py + ph, y + ph ), true );
	
	self:LayoutEntity( self.Entity )
	
	local ang = self.aLookAngle
	if ( !ang ) then
		ang = (self.vLookatPos-self.vCamPos):Angle()
	end
	
	local w, h = self:GetSize()
	cam.Start3D( self.vCamPos, ang, self.fFOV, x, y, w, h, 5, 4096 )
	
	render.SuppressEngineLighting( true )
	render.SetLightingOrigin( self.Entity:GetPos() )
	render.ResetModelLighting( self.colAmbientLight.r/255, self.colAmbientLight.g/255, self.colAmbientLight.b/255 )
	render.SetColorModulation( self.colColor.r/255, self.colColor.g/255, self.colColor.b/255 )
	render.SetBlend( self.colColor.a/255 )
	
	for i=0, 6 do
		local col = self.DirectionalLight[ i ]
		if ( col ) then
			render.SetModelLighting( i, col.r/255, col.g/255, col.b/255 )
		end
	end
	
	self.Entity:DrawModel();

	render.SuppressEngineLighting( false )
	cam.End3D()
	
	self.LastPaint = RealTime()

	render.SetScissorRect( 0, 0, 0, 0, false );
end

function PANEL:SetItem( table )
	self.item = table;

	-- MODEL ICON
	local icon = vgui.Create( "DModelPanel", self )
	icon:SetModel( table.model )

	icon:SetSize( self:GetSize() );
	icon:SetCamPos( Vector( 50, 50, 30 ) );
	icon:SetLookAt( Vector( 0, 0, 5 ) );
	icon:SetFOV( 30 );
	icon.Paint = DModelPanel_PaintFix;
	icon.clipper = self.clipper;
	icon:SetMouseInputEnabled( false );
	function icon:LayoutEntity( ) end

	self.icon = icon;

	-- JOB LABEL
	local labelPanel = vgui.Create('DPanel', self );
	labelPanel:SetWide( self:GetWide() );
	labelPanel:SetTall( PF4.shoptab_ItemTitleSmallSize );
	function labelPanel:Paint( w, h )
		surface.SetDrawColor( table.color.r, table.color.g, table.color.b, 30 )
		surface.DrawRect( 0, 0, w, h );
	end

	local label = Label( table.name, labelPanel );
	label:SetFont( 'PF4_ShopItemTitleSmall' );
	label:SetColor( color_white );
	label:SizeToContents();
	label:SetPos( (labelPanel:GetWide() - label:GetWide() ) / 2, ( labelPanel:GetTall() - label:GetTall() ) / 2 );

	labelPanel:Dock( BOTTOM );

	-- HOVER PANEL OVERLAY
	self.hoverOverlay = vgui.Create( 'DPanel', self );
	self.hoverOverlay:Dock( FILL );
	self.hoverOverlay:SetAlpha( 0 );
	self.hoverOverlay:MoveToBack( );

	local max_players = table.max;
	local col_SemiTrans = Color( 255, 255, 255, 200 );

	local textCost =  '$'..table.price ;
	if( table.o.amount )then
		textCost = textCost .. ' / ' .. table.o.amount;
	end
	if( table.o.amountGiven )then
		textCost = textCost .. ' / ' .. table.o.amountGiven;
	end

	function self.hoverOverlay:Paint( w, h )
		if( self:GetAlpha() == 0 )then return end

		surface.SetDrawColor( hovercolor )
		surface.DrawRect( 0, 0, w, h );


		draw.SimpleText( textCost, 'PF4_ShopItemCost', w - 5, 5, col_SemiTrans, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM )
	end

	self.hoverOverlay:SetMouseInputEnabled( false );
end

local bgcol = PF4.jobicon_bgcol
function PANEL:Paint( w, h )
	local jobC = self.item.color;
	surface.SetDrawColor( jobC.r, jobC.g, jobC.b, 30 )
	--surface.DrawRect( 0, 0, w, h );
	surface.DrawOutlinedRect( 0, 0, w, h );

	local mx, my = gui.MouseX(), gui.MouseY();
	local px, py = self:LocalToScreen( 0, 0 );
end

function PANEL:OnMouseReleased()
	local table = self.item
	local parent = self;

	print( table.name );
	PrintTable( table );

	-- GENERATE THE ITEM INFO
	self = PF4.menu.sideinfo:GetNewSpace( )

	-- CREATE THE ICON
	local icon = vgui.Create( "DModelPanel", self )
	icon:SetModel( table.model )

	icon:SetSize( self:GetWide(), self:GetTall() / 2 );
	icon:SetCamPos( Vector( 50, 50, 20 ) );
	icon:SetLookAt( Vector( 0, 0, 5 ) );
	icon:SetFOV( 33 );
	icon.clipper = self.clipper;
	icon:SetMouseInputEnabled( false );
	icon:Dock( TOP );

	-- pretty colors
	local colorLine = vgui.Create( 'DPanel', icon );
	colorLine:SetSize( self:GetWide(), 8 );
	colorLine:Dock( BOTTOM );
	colorLine:SetAlpha( 100 );
	function colorLine:Paint( w, h ) surface.SetDrawColor( table.color ); surface.DrawRect( 0, 0, w, h ); end

	if( table.price )then
		local m = Label( 'COST: '..table.price, self );
		m:Dock( TOP );
		m:DockMargin( 5, 5, 0, 10 );
		m:SetFont( 'PF4_ShopItemInfo' );
	end

	if( table.o.max )then
		local m = Label( 'SPAWN LIMIT: '..table.o.max, self );
		m:Dock( TOP );
		m:DockMargin( 5, 5, 0, 0 );
		m:SetFont( 'PF4_ShopItemInfo' );
	end

	-- DISPLAYING GENARIC ITEM INFO.
	if( table.o.entity and weapons.Get( table.o.entity ))then
		local wep = weapons.Get( table.o.entity );
		if( wep.Primary )then
			if( wep.Primary.Damage )then
				local m = Label( 'DAMAGE: '..wep.Primary.Damage, self );
				m:Dock( TOP );
				m:DockMargin( 5, 5, 0, 0 );
				m:SetFont( 'PF4_ShopItemInfo' );
			end
			if( wep.Primary.ClipSize )then
				local m = Label( 'CLIP SIZE: '..wep.Primary.ClipSize, self );
				m:Dock( TOP );
				m:DockMargin( 5, 5, 0, 0 );
				m:SetFont( 'PF4_ShopItemInfo' );
			end
			if( wep.Primary.Delay )then
				local m = Label( 'RPM: '..math.floor(60 / wep.Primary.Delay), self );
				m:Dock( TOP );
				m:DockMargin( 5, 5, 0, 0 );
				m:SetFont( 'PF4_ShopItemInfo' );
			elseif( wep.Primary.RPM )then
				local m = Label( 'RPM: '..wep.Primary.RPM, self );
				m:Dock( TOP );
				m:DockMargin( 5, 5, 0, 0 );
				m:SetFont( 'PF4_ShopItemInfo' );
			end
			if( wep.Primary.NumShots and wep.Primary.NumShots > 1 )then
				local m = Label( 'BUCKSHOT: '..wep.Primary.NumShots, self );
				m:Dock( TOP );
				m:DockMargin( 5, 5, 0, 0 );
				m:SetFont( 'PF4_ShopItemInfo' );
			end
		end
	end

	if( table.amountGiven )then
		local m = Label( 'AMOUNT: '..table.amountGiven, self );
		m:Dock( TOP );
		m:DockMargin( 5, 5, 0, 0 );
		m:SetFont( 'PF4_ShopItemInfo' );
	end

	local buyButton = vgui.Create('DButton', self );
	buyButton:SetSize( self:GetWide(), PF4.shoptab_BuyItemSize )
	buyButton:Dock( BOTTOM );
	buyButton:SetFont( 'PF4_ButtBuyItem' );
	buyButton:SetTextColor( color_white );
	buyButton:SetText( 'BUY ITEM' );
	function buyButton:Paint( w, h )
		if( self:IsHovered() )then
			if( input.IsMouseDown( MOUSE_LEFT ))then
				surface.SetDrawColor( 240, 255, 240, 30 );				
			else
				surface.SetDrawColor( 255, 255, 255, 30 );		
			end
		else
			surface.SetDrawColor( 255, 255, 255, 20 );
		end

		surface.DrawRect( 0, 0, w, h );
	end

	function buyButton:DoClick( )
		table.action( table );
	end

	PF4.menu.sideinfo:SetDisplay( table.name, self, PF4.time_showinfo )
end

function PANEL:OnCursorEntered( )
	self.hoverOverlay:AlphaTo( 255, PF4.jobtab_hoveranimtime, 0 );
	self.icon:SetFOV( 28 );
end

function PANEL:OnCursorExited( )
	self.hoverOverlay:AlphaTo( 0, PF4.jobtab_hoveranimtime, 0 );
	self.icon:SetFOV( 30 );
end

vgui.Register( "pf4_shopicon", PANEL, 'DPanel' );