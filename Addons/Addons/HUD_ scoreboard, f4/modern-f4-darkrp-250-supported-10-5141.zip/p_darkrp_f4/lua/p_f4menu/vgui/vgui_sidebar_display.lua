local PANEL = {}

function PANEL:Init()
	-- this will make itself a bit too wide to clip off part of the panel.
	self:SetWidth( PF4.sidebar_width * self:GetParent():GetWide() - PF4.sidebar_padding + PF4.corner_size );
	self:SetHeight( PF4.menu_height * self:GetParent():GetTall() );
	self:SetPos( self:GetParent():GetWide() - self:GetWide() + PF4.corner_size, ( self:GetParent():GetTall() - self:GetTall() ) / 2 );

	self.storagearea = vgui.Create( 'DPanel' );
	self.storagearea:SetVisible( false );

	self.contentarea = vgui.Create( 'DPanel', self );
	self.contentarea:SetSize( self:GetWide() - PF4.corner_size, self:GetTall() - PF4.header_size * 2 );
	self.contentarea:SetPos( 0, PF4.header_size );
	function self.contentarea:Paint( ) end

	self.header = Label( '[UNTITLED]', self );
	self.header:SetFont( 'PF4_PanelHeader' );
	self.header:SizeToContents( );
	self.header:SetPos( PF4.corner_size, ( PF4.header_size - self.header:GetTall() ) / 2 ); 

	self.startx, self.starty = self:GetPos();

	self.showing = true;
end

function PANEL:GetNewSpace( )
	local newPanel = vgui.Create('DPanel', self.storagearea );
	newPanel:SetSize( self.contentarea:GetSize() );
	newPanel:SetPos( 0, 0 );
	function newPanel:Paint( ) end

	return newPanel;
end

function PANEL:Show( time, cback )
	if( self.showing )then if( cback )then cback(); end return end;

	self:SetPos( self:GetParent():GetWide(), self.starty );
	self:MoveTo( self.startx, self.starty, time, 0, 1, cback );

	self.showing = true;
end

function PANEL:Hide( time, cback )
	if( not self.showing )then if( cback )then cback(); end return end;

	self:SetPos( self.startx, self.starty );
	self:MoveTo( self:GetParent():GetWide(), self.starty, time, 0, 1, cback );

	self.showing = false;
end

function PANEL:SetDisplay( newTitle, panel, time, cback )
	self:Hide( time/2, function()

		self.contentarea:Clear();
		panel:SetParent( self.contentarea );
		self.header:SetText( newTitle );
		self.header:SizeToContents( );
		timer.Simple( time/2, function()
			self:Show( time/2, cback );
		end)
	end)
end

vgui.Register( "pf4_menu_info", PANEL, 'PF4_BasePanel' );