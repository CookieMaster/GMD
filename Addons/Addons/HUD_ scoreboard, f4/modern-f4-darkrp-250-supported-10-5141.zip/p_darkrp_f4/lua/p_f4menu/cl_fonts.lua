surface.CreateFont( "PF4_NavLabel",
	{
		font      = "Michroma",
		size      = PF4.navbar_textheight,
		weight    = 700
	})

surface.CreateFont( "PF4_PanelHeader",
	{
		font      = "Michroma",
		size      = PF4.header_size * 0.5,
		weight    = 700
	})

surface.CreateFont( "PF4_IconTitleFont",
	{
		font      = "Michroma",
		size      = PF4.jobtab_IconTitleSize * 0.8,
		weight    = 300
	})

surface.CreateFont( "PF4_JobDescFont",
	{
		font      = "coolvetica",
		size      = PF4.jobtab_DescFontSize,
		weight    = 50
	})


surface.CreateFont( "PF4_HugeArrowFont",
	{
		font      = "Michroma",
		size      = PF4.jobtab_info_mdlbutSize,
		weight    = 600
	})

surface.CreateFont( "PF4_PlayerCount",
	{
		font      = "Michroma",
		size      = PF4.jobtab_PlayerCountSize,
		weight    = 600
	})


surface.CreateFont( "PF4_ButtChangeTeam",
	{
		font      = "Michroma",
		size      = PF4.jobtab_info_changeteamSize * 0.8,
		weight    = 400
	})


-- ENTS SHOP
surface.CreateFont( "PF4_EntShopCatTitle",
	{
		font      = "Michroma",
		size      = 20,
		weight    = 800
	})

surface.CreateFont( "PF4_ShopItemTitleSmall",
	{
		font      = "Michroma",
		size      = PF4.shoptab_ItemTitleSmallSize * 0.8,
		weight    = 300
	})

surface.CreateFont( "PF4_ShopItemCost",
	{
		font      = "Michroma",
		size      = PF4.shoptab_CostSize,
		weight    = 600
	})
surface.CreateFont( "PF4_ShopItemInfo",
	{
		font      = "Michroma",
		size      = 25,
		weight    = 600
	})

surface.CreateFont( "PF4_ButtBuyItem",
	{
		font      = "Michroma",
		size      = PF4.shoptab_BuyItemSize * 0.8,
		weight    = 400
	})

surface.CreateFont( "PF4_CommandFont",
	{
		font      = "Michroma",
		size      = PF4.commandstab_FontHeight,
		weight    = 800
	})