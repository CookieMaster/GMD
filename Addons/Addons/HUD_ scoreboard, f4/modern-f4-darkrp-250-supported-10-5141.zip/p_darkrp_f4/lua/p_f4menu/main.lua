PF4 = {}

if(SERVER)then
	AddCSLuaFile( 'sh_config.lua' );
	AddCSLuaFile( 'cl_fonts.lua' );

	resource.AddSingleFile( 'resource/fonts/Michroma.ttf')
end
include( 'sh_config.lua' );
if(CLIENT)then include( 'cl_fonts.lua' ); end

-- start off by loading all VGUI panels
print( '[PF4] Loading VGUI');

if(SERVER)then
	AddCSLuaFile( 'vgui/vgui_jobicon.lua' );
	AddCSLuaFile( 'vgui/vgui_menu.lua' );
	AddCSLuaFile( 'vgui/vgui_menu_center.lua' );
	AddCSLuaFile( 'vgui/vgui_sexybase.lua' );
	AddCSLuaFile( 'vgui/vgui_shopicon.lua' );
	AddCSLuaFile( 'vgui/vgui_sidebar_display.lua' );
	AddCSLuaFile( 'vgui/vgui_sidebar_nav.lua' );
else
	include( 'vgui/vgui_jobicon.lua' );
	include( 'vgui/vgui_menu.lua' );
	include( 'vgui/vgui_menu_center.lua' );
	include( 'vgui/vgui_sexybase.lua' );
	include( 'vgui/vgui_shopicon.lua' );
	include( 'vgui/vgui_sidebar_display.lua' );
	include( 'vgui/vgui_sidebar_nav.lua' );
end



/*=================================
   			TAB LOADING SYSTEM
  =================================*/

-- PROPERTIES:
--[[
	* name      - the title for the tab
	* index     - the order in the list. uses table.SortByMember( 'index' )
	* genTab    - function to generate the panel.
	* updateTab - update the tab content etc.
]]

local function includeTab( path )
	_G.TABINFO = { };
	
	-- load the file.
	if( SERVER )then
		AddCSLuaFile( path );
	else
		include( path );
	end

	-- retrieve the table.
	local tab = _G.TABINFO;

	-- unload the table.
	_G.TABINFO = nil;

	-- return the table.
	return tab;
end

local function loadTabs()
	local fol = "p_f4menu/tabs/"

	local files = file.Find(fol .. "tab_*.lua", "LUA")
	PrintTable( files );

	local tabs = {};
	for _, file in SortedPairs(files, true) do
		table.insert( tabs, includeTab( fol..file ) );
	end
	table.SortByMember( tabs, 'index', function( a, b ) return a < b end )
	return tabs;
end

print( '[PF4] Loading Tabs');
PF4.menu_tabs = loadTabs( );






/*================================
  NOW THAT EVERYTHING IS LOADED...
  ================================ */
if( CLIENT )then
	local function tryInject( )
		if( not RPExtraTeams )then return end
		if( not IsValid( LocalPlayer() ) or not LocalPlayer().Team )then
			timer.Simple( 1, tryInject );
			return
		end
		local menu = vgui.Create('pf4_menu');
		menu:SetVisible( false );
		
		GAMEMODE.ShowSpare2 = function()
			menu:Show();
		end
	end
	timer.Simple( 0, function()
		tryInject();
	end);
end 