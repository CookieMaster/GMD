local hovercolor = PF4.jobtab_iconhover


local PANEL = {}
function PANEL:Init()
	-- not much to do here.
	-- go away.
end



local function DModelPanel_PaintFix(self, w, h )

	if ( !IsValid( self.Entity ) ) then return end
	
	local x, y = self:LocalToScreen( 0, 0 )	

	local superParent = self.clipper; -- doing stuff like this makes me want to scream inside, but there isn't really another way
					-- that would actually be worth the time and effort.
	local px, py = superParent:LocalToScreen();
	local pw, ph = superParent:GetSize();

	render.SetScissorRect( math.max( px, x ), math.max( py, y ), math.min(px + pw, x + pw ), math.min( py + ph, y + ph ), true );
	
	self:LayoutEntity( self.Entity )
	
	local ang = self.aLookAngle
	if ( !ang ) then
		ang = (self.vLookatPos-self.vCamPos):Angle()
	end
	
	local w, h = self:GetSize()
	cam.Start3D( self.vCamPos, ang, self.fFOV, x, y, w, h, 5, 4096 )
	
	render.SuppressEngineLighting( true )
	render.SetLightingOrigin( self.Entity:GetPos() )
	render.ResetModelLighting( self.colAmbientLight.r/255, self.colAmbientLight.g/255, self.colAmbientLight.b/255 )
	render.SetColorModulation( self.colColor.r/255, self.colColor.g/255, self.colColor.b/255 )
	render.SetBlend( self.colColor.a/255 )
	
	for i=0, 6 do
		local col = self.DirectionalLight[ i ]
		if ( col ) then
			render.SetModelLighting( i, col.r/255, col.g/255, col.b/255 )
		end
	end
	
	self.Entity:DrawModel();

	render.SuppressEngineLighting( false )
	cam.End3D()
	
	self.LastPaint = RealTime()

	render.SetScissorRect( 0, 0, 0, 0, false );
end

local iconCache = {};
function PANEL:SetJob( table )
	self.job = table;

	-- MODEL ICON
	local icon;
	if( iconCache[ tostring( self.job) ] )then
		icon = iconCache[ tostring( self.job ) ];
	else
		icon = vgui.Create( "DModelPanel", self )
		icon:SetModel( type( table.model ) == 'table' and table.model[math.random( 1, #table.model )] or table.model )
	end

	icon:SetSize( self:GetSize() );
	icon:SetCamPos( Vector( 30, 10, 60 ) );
	icon:SetLookAt( Vector( 0, 0, 55 ) );
	icon.Paint = DModelPanel_PaintFix;
	icon.clipper = self.clipper;
	icon:SetMouseInputEnabled( false );
	function icon:LayoutEntity( ) end
	self.icon = icon;

	-- JOB LABEL
	local labelPanel = vgui.Create('DPanel', self );
	labelPanel:SetWide( self:GetWide() );
	labelPanel:SetTall( PF4.jobtab_IconTitleSize );
	function labelPanel:Paint( w, h )
		surface.SetDrawColor( table.color.r, table.color.g, table.color.b, 100 )
		surface.DrawRect( 0, 0, w, h );
	end

	local label = Label( table.name, labelPanel );
	label:SetFont( 'PF4_IconTitleFont' );
	label:SetColor( color_white );
	label:SizeToContents();
	label:SetPos( (labelPanel:GetWide() - label:GetWide() ) / 2, ( labelPanel:GetTall() - label:GetTall() ) / 2 );

	labelPanel:Dock( BOTTOM );

	-- HOVER PANEL OVERLAY
	self.hoverOverlay = vgui.Create( 'DPanel', self );
	self.hoverOverlay:Dock( FILL );
	self.hoverOverlay:SetAlpha( 0 );
	self.hoverOverlay:MoveToBack( );

	local max_players = table.max;
	local col_SemiTrans = Color( 255, 255, 255, 200 );
	function self.hoverOverlay:Paint( w, h )
		if( self:GetAlpha() == 0 )then return end

		surface.SetDrawColor( hovercolor )
		surface.DrawRect( 0, 0, w, h );

		local player_count = #team.GetPlayers( table.teamid )

		draw.SimpleText( player_count..'/'..( max_players <= 0 and '∞' or max_players ), 'PF4_PlayerCount', w - 5, 5, col_SemiTrans, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM )
	end

	self.hoverOverlay:SetMouseInputEnabled( false );
end

local bgcol = PF4.jobicon_bgcol
function PANEL:Paint( w, h )
	local jobC = self.job.color;
	surface.SetDrawColor( jobC.r, jobC.g, jobC.b, 60 )
	--surface.DrawRect( 0, 0, w, h );
	surface.DrawOutlinedRect( 0, 0, w, h );

	local mx, my = gui.MouseX(), gui.MouseY();
	local px, py = self:LocalToScreen( 0, 0 );
end

function PANEL:OnMouseReleased()
	local table = self.job
	local parent = self;

	

	-- GENERATE THE JOB INFO
	self = PF4.menu.sideinfo:GetNewSpace( )

		-- MODEL ICON
		local iconWrapper = vgui.Create('DPanel', self );
		iconWrapper:SetSize( self:GetWide(), self:GetWide() );
		local col_wrapperBG = Color( table.color.r, table.color.g, table.color.b, 10 );
		function iconWrapper:Paint( w, h )
			surface.SetDrawColor( col_wrapperBG );

			surface.DrawRect( 0, 0, w, h );
		end

		local icon = vgui.Create( "DModelPanel", self )

		icon:SetSize( self:GetWide(), self:GetWide() );
		icon:Dock( TOP );
		icon:SetCamPos( Vector( 30, 0, 60 ) );
		icon:SetLookAt( Vector( 0, 0, 55 ) );

		icon:SetMouseInputEnabled( true );
		function icon:LayoutEntity( ) end


		-- pretty colors
		local jobColorLine = vgui.Create( 'DPanel', icon );
		jobColorLine:SetSize( self:GetWide(), 8 );
		jobColorLine:Dock( BOTTOM );
		function jobColorLine:Paint( w, h ) surface.SetDrawColor( table.color ); surface.DrawRect( 0, 0, w, h ); end

		
		if( type( table.model ) == 'table' )then
			local mdlindex = math.random( 1, #table.model );
			icon:SetModel( table.model[ mdlindex ] );
			

			-- button bar.
			local butBar = vgui.Create( 'DPanel', icon );
			function butBar:Paint() end
			butBar:SetSize( self:GetWide(), PF4.jobtab_info_mdlbutSize );
			butBar:Dock( BOTTOM );

			-- create buttons.
			local butNext = vgui.Create('DButton', butBar );
			butNext:SetText( '>' );
			butNext:SetFont( 'PF4_HugeArrowFont' );
			butNext:Dock( RIGHT );

			function butNext:DoClick( )
				mdlindex = mdlindex + 1;
				if( mdlindex > #( table.model ) )then
					mdlindex = 1;
				end
				icon:SetModel( table.model[ mdlindex ] );
				icon.mdl = table.model[ mdlindex ];
			end
			function butNext:Paint( ) end

			local butPrev = vgui.Create('DButton', butBar );
			butPrev:SetText( '<' );
			butPrev:SetFont('PF4_HugeArrowFont');
			butPrev:Dock( LEFT );
			function butPrev:DoClick( )
				mdlindex = mdlindex - 1;
				if( mdlindex == 0 )then
					mdlindex = #( table.model );
				end
				icon:SetModel( table.model[ mdlindex ] );
				icon.mdl = table.model[ mdlindex ];
			end
			function butPrev:Paint( ) end
		else
			icon:SetModel( table.model );
			icon.mdl = table.model;
		end

		-- ADD THE JOB DESCRIPTION.
		local desc = vgui.Create('DLabel', self );
		desc:SetText( table.description );
		desc:SetWrap( true );
		desc:SetTextColor( color_white );
		desc:SetWide( self:GetWide() - 10 );
		desc:SetAutoStretchVertical( true );
		desc:DockMargin( 5, 5, 5, 5 );
		desc:Dock( TOP );

		-- ADD THE JOIN TEAM BUTTON.
		local change_team = vgui.Create("DButton" , self)
		change_team:SetFont( 'PF4_ButtChangeTeam' );
		change_team:SetSize( self:GetWide(), PF4.jobtab_info_changeteamSize );
		change_team:Dock( BOTTOM );
		change_team:SetColor( color_white );

		if( table.vote )then
			change_team:SetText( 'Start Vote')
			function change_team:DoClick()
				RunConsoleCommand("rp_playermodel",  icon.mdl );
				RunConsoleCommand("_rp_ChosenModel",  icon.mdl );

				LocalPlayer():ConCommand("say /vote"..table.command..'\n')
				PF4.menu:OpenTab( parent.TAB );
			end
		else
			change_team:SetText( 'Change Team')
			function change_team:DoClick()
				RunConsoleCommand("rp_playermodel", icon.mdl );
				RunConsoleCommand("_rp_ChosenModel", icon.mdl );

				LocalPlayer():ConCommand("say /"..table.command.."\n")
				PF4.menu:OpenTab( parent.TAB );
			end
		end

		local changeteam_bgCol = Color( table.color.r, table.color.g, table.color.b, 100 );
		function change_team:Paint( w, h )
			changeteam_bgCol.a = self.Hovered and 120 or 50

			surface.SetDrawColor( changeteam_bgCol );
			surface.DrawRect( 0, 0, w, h );

			surface.SetDrawColor( 255, 255, 255, 30 );
			surface.DrawOutlinedRect( 0, 0, w, h );
			surface.DrawOutlinedRect( 1, 1, w - 2, h - 2 );

		end

	PF4.menu.sideinfo:SetDisplay( table.name, self, PF4.time_showinfo )
end

function PANEL:OnCursorEntered( )
	self.hoverOverlay:AlphaTo( 255, PF4.jobtab_hoveranimtime, 0 );
	self.icon:SetFOV( self.icon:GetFOV() - 2 );
end

function PANEL:OnCursorExited( )
	self.hoverOverlay:AlphaTo( 0, PF4.jobtab_hoveranimtime, 0 );
	self.icon:SetFOV( self.icon:GetFOV( ) + 2 );
end

vgui.Register( "pf4_jobicon", PANEL, 'DPanel' );


