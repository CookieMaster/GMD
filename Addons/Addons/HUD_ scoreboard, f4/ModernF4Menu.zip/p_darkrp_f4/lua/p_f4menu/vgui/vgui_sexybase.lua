local cs = PF4.corner_size -- the corner size in a local var to speed stuff up.
local hs = PF4.header_size -- the size of the header zone.
local surface = surface;


local PANEL = {}

local panel_background = { {}, {}, {}, {}, {}, {}, {}, {} }
local background_color = PF4.transbg_dark;

local matBlurScreen = Material( "pp/blurscreen" )
local blur_scale = 5;

function PANEL:Paint( w, h )
	local scrw, scrh = ScrW(), ScrH();

	local panelx, panely = self:LocalToScreen();


	panel_background[1].x = cs;
	panel_background[1].y = 0;
	panel_background[1].u = (panelx + panel_background[1].x) / scrw;
	panel_background[1].v = (panely + panel_background[1].y) / scrh;

	panel_background[2].x = w-cs;
	panel_background[2].y = 0;
	panel_background[2].u = (panelx + panel_background[2].x) / scrw;
	panel_background[2].v = (panely + panel_background[2].y) / scrh;

	panel_background[3].x = w;
	panel_background[3].y = cs;
	panel_background[3].u = (panelx + panel_background[3].x) / scrw;
	panel_background[3].v = (panely + panel_background[3].y) / scrh;

	panel_background[4].x = w;
	panel_background[4].y = h - cs;
	panel_background[4].u = (panelx + panel_background[4].x) / scrw;
	panel_background[4].v = (panely + panel_background[4].y) / scrh;

	panel_background[5].x = w - cs;
	panel_background[5].y = h;
	panel_background[5].u = (panelx + panel_background[5].x) / scrw;
	panel_background[5].v = (panely + panel_background[5].y) / scrh;

	panel_background[6].x = cs;
	panel_background[6].y = h;
	panel_background[6].u = (panelx + panel_background[6].x) / scrw;
	panel_background[6].v = (panely + panel_background[6].y) / scrh;

	panel_background[7].x = 0;
	panel_background[7].y = h - cs;
	panel_background[7].u = (panelx + panel_background[7].x) / scrw;
	panel_background[7].v = (panely + panel_background[7].y) / scrh;

	panel_background[8].x = 0;
	panel_background[8].y = cs;
	panel_background[8].u = (panelx + panel_background[8].x) / scrw;
	panel_background[8].v = (panely + panel_background[8].y) / scrh;

	render.SetScissorRect( 0, 0, 0, 0, false );
	-- draw background blur effect like a baws.
	surface.SetMaterial( matBlurScreen );
	surface.SetDrawColor( 255, 255, 255, 255 );
	for i=0.6, 1.4, 0.1 do
		matBlurScreen:SetFloat( "$blur", blur_scale * i )
		render.UpdateScreenEffectTexture()
		surface.DrawPoly( panel_background )
	end

	-- draw black overlay for added swag.
	draw.NoTexture();
	surface.SetDrawColor( background_color );
	surface.DrawPoly( panel_background );

	render.SetScissorRect( 0, 0, panelx + w, panely + hs, true );
	surface.DrawPoly( panel_background );

	render.SetScissorRect( 0, panely + h - hs, scrw, scrh, true );
	surface.DrawPoly( panel_background );

	render.SetScissorRect( 0, 0, 0, 0, false );

	if( self.PaintOver )then
		self:PaintOver( w, h );
	end
end

vgui.Register('PF4_BasePanel', PANEL, 'DPanel' );