local PANEL = {}

function PANEL:Init()
	
	-- general layout / size calc.
	self:SetWidth( PF4.sidebar_width * self:GetParent():GetWide() - PF4.sidebar_padding + PF4.corner_size );
	self:SetHeight( PF4.menu_height * self:GetParent():GetTall() );
	self:SetPos( - PF4.corner_size, ( self:GetParent():GetTall() - self:GetTall() ) / 2 );

	-- build content area.
	self.content = vgui.Create( 'DPanel', self );
	self.content.Paint = function() end;
	self.content:SetPos( PF4.corner_size, PF4.header_size );
	self.content:SetSize( self:GetWide() - PF4.corner_size, self:GetTall() - PF4.header_size * 2 );


	-- for animations.
	self.startx, self.starty = self:GetPos();
end

function PANEL:Show( time, cback )
	self:SetPos( - self:GetWide(), self.starty );
	self:MoveTo( self.startx, self.starty, time, 0, 1, cback );
end

function PANEL:Hide( time, cback )
	self:SetPos( self.startx, self.starty );
	self:MoveTo( - self:GetWide(), self.starty, time, 0, 1, cback );
end

-- appearance customization for buttons.
local function _catTitle_Paint( self, w, h )
	local alphagoal = nil;
	if( self:GetParent().selected == self )then
		alphagoal = 15;
	elseif( self:IsHovered() )then
		alphagoal = 23;
		if( input.IsMouseDown( MOUSE_LEFT ) )then
			alphagoal = alphagoal + 20;
		end
	else
		alphagoal = 0;
	end

	self.alpha = Lerp( FrameTime() * 10, self.alpha or 0, alphagoal );
	surface.SetDrawColor( 200, 200, 200, self.alpha );
	surface.DrawRect( 0, 0, w, h );
end

function PANEL:AddOption( title, action, justAButton )
	
	local catTitle = vgui.Create( 'DPanel', self.content );
	catTitle:Dock( TOP );
	catTitle:SetSize( self.content:GetWide(), PF4.navbar_textheight + PF4.navbar_linepadding * 2 );
	catTitle.Paint = _catTitle_Paint;
	catTitle.OnMouseReleased = function()
		if( not justAButton )then
			self.content.selected = catTitle;
		end
		action( );
	end


	local title = Label( title, catTitle );
	title:SetFont('PF4_NavLabel');
	title:SizeToContents();
	title:Center();
end

vgui.Register( "pf4_sidenav", PANEL, 'PF4_BasePanel' );