-- TESTING PURPOSES ONLY.
TABINFO.name = 'Commands';
TABINFO.index = 2;

local commands = {};

local function AskPlayer( cback, filterFunc, converter )
	local Menu = DermaMenu()
	for k,v in pairs( player.GetAll() )do
		if( not filterFunc or filterFunc( v ) )then
			Menu:AddOption( v:Name( ), function( ) cback( converter and converter( v ) or '"'..v:SteamID()..'"' ) end );
		end
	end
	Menu:Open( );
end

local function AskNumber( title, message, cback )
	Derma_StringRequest( title, message, '', function( str )
		local n = tonumber( str );
		if( not n )then
			Derma_Message( "'"..str.."' is not a valid number.", 'error', 'close' );
			return ;
		end
		cback( n );
	end, function() end )
end

local function AskString( title, message, cback )
	Derma_StringRequest( title, message, '', function( str )
		cback( str );
	end, function() end )
end

local function NewNumberQuery( title, message )
	return function( cback )
		AskNumber( title, message, cback );
	end
end

local function NewStringQuery( title, message )
	return function( cback )
		AskString( title, message, cback );
	end
end

local function NewPlayerQuery( filterFunc, converter )
	if( filterFunc or converter )then
		return function( cback )
			return AskPlayer( cback, filterFunc, converter );
		end
	else
		return AskPlayer ;
	end
end

local function BuildCommand( cmd, next, nextNext, ... )
	if( next == nil )then
		print( cmd );
		LocalPlayer():ConCommand( cmd..'\n' );
		LocalPlayer():ConCommand( string.gsub( cmd, 'darkrp ','darkrp /')..'\n' );
		return ;
	end
	local args = {...};

	if( type( next ) == 'function' )then
		next( function( new )
			if( new == nil )then return end;
			BuildCommand( cmd..' '..new, nextNext, unpack( args ) );
		end);
	else
		BuildCommand( cmd .. ' ' .. next, nextNext, ... );
	end
end

function MakeFunction( func, ... )
	local args = {...};
	return function( )
		func( unpack( args ) );
	end
end


local button_default = Color( 200, 200, 200, 100 );
local button_hovered = Color( 255, 255, 255, 100 );
local button_pressed = Color( 200, 255, 200, 140 );

local c;
local button_paint = function( self, w, h )
	if( self:IsHovered( ) )then
		if( input.IsMouseDown( MOUSE_LEFT ) )then
			c = button_pressed;
		else
			c = button_hovered;
		end
	else
		c = button_default;
	end
	draw.RoundedBox( 4, 0, 0, w, h, c );
end

local function CommandButton( parent, text, doClick )
	local b = vgui.Create('DButton', parent );
	b.Paint = button_paint;
	b:SetTextColor( color_black );
	b:SetFont( 'PF4_CommandFont' );
	b:SetText( text );
	b.DoClick = doClick;
	b:DockMargin( 0, 4, 0, 0 );
	return b;
end

local function HeaderLine( parent, text, color )
	local b = vgui.Create('DButton', parent );
	b:SetTextColor( color_black );
	b:SetFont( 'PF4_CommandFont' );
	b:SetText( text );
	function b:Paint( w, h )
		draw.RoundedBox( 4, 0, 0, w, h, color );
	end
	b:DockMargin( 0, 8, 0, 0 );
	return b;
end

local commands = {};

TABINFO.build = function( self, w, h )
	local s = vgui.Create('DScrollPanel', self );
	s:Dock( FILL );
	local scrollbar = s.VBar;
	local scrollbar_bg = Color( 255, 255, 255, 100 );
	local scrollbar_grip = Color( 255, 255, 255, 20 );
	function scrollbar:Paint( w, h ) end
	function scrollbar.btnGrip:Paint( w, h )
		draw.RoundedBox( 4, 3, 0, w-6, h, scrollbar_grip );
	end
	function scrollbar.btnUp:Paint() end
	function scrollbar.btnDown:Paint() end

	self:DockPadding( 10, 10, 10, 10 );

	self.s = s;
end

TABINFO.update = function( self, w, h )
	local s = self.s;
	s:Clear( );

	-- CITIZEN OPTIONS.
		HeaderLine( s, 'CITIZEN', Color( 0, 100, 0 ) ):Dock( TOP );
		CommandButton( s, 'Custom Job', MakeFunction( BuildCommand, 'darkrp job', NewStringQuery('Custom Job', 'Enter your custom job title.') ) ):Dock( TOP );
		CommandButton( s, 'Roleplay Name', MakeFunction( BuildCommand, 'darkrp rpname', NewStringQuery('Change Name', 'Enter your new RP name') ) ):Dock( TOP );
		CommandButton( s, 'Drop Money', MakeFunction( BuildCommand, 'darkrp dropmoney', NewNumberQuery( 'Drop Money', 'Amount to drop:' )) ):Dock( TOP );
		CommandButton( s, 'Give Money', MakeFunction( BuildCommand, 'darkrp give', NewNumberQuery( 'Give Money', 'Amount to give:' )) ):Dock( TOP );
		CommandButton( s, 'Drop Weapon', MakeFunction( BuildCommand, 'darkrp drop' ) ):Dock( TOP );
		CommandButton( s, 'Sleep / Wakeup', MakeFunction( BuildCommand, 'darkrp sleep' ) ):Dock( TOP );
		CommandButton( s, 'Request Gun LIscence', MakeFunction( BuildCommand, 'darkrp requestlicense' ) ):Dock( TOP );
		CommandButton( s, 'Sell All Doors', MakeFunction( BuildCommand, 'darkrp unownalldoors' ) ):Dock( TOP );
		CommandButton( s, 'DEMOTE', MakeFunction( BuildCommand, 'darkrp demote', NewPlayerQuery( nil, function( ply ) return ply:UserID() end ), NewStringQuery('Demote', 'Please enter a reason.') ) ):Dock( TOP );

	if( ( LocalPlayer().isCP and LocalPlayer():isCP() ) or ( LocalPlayer().IsCP and LocalPlayer():IsCP()) )then
		HeaderLine( s, 'POLICE', Color( 50, 50, 200 ) ):Dock( TOP );
		CommandButton( s, 'Search Warrant', MakeFunction( BuildCommand, 'darkrp warrant', NewPlayerQuery( ), NewStringQuery( 'Reason', 'Please enter a reason' )) ):Dock( TOP );
		CommandButton( s, 'Wanted for Arrest', MakeFunction( BuildCommand, 'darkrp wanted', NewPlayerQuery( function( ply ) return not ply.DarkRPVars.wanted end ), NewStringQuery( 'Reason', 'Please enter a reason' )) ):Dock( TOP );
		CommandButton( s, 'Unwant for Arrest', MakeFunction( BuildCommand, 'darkrp unwanted', NewPlayerQuery( function( ply ) return ply.DarkRPVars.wanted end ) ) ):Dock( TOP );
		
		if TEAM_CHIEF and LocalPlayer():Team() == TEAM_CHIEF and GAMEMODE.Config and GAMEMODE.Config.chiefjailpos or LocalPlayer():IsAdmin() then
			CommandButton( s, 'Set Jail Pos', MakeFunction( BuildCommand, 'darkrp jailpos' ) ):Dock( TOP );
			CommandButton( s, 'Add Jail Pos', MakeFunction( BuildCommand, 'darkrp addjailpos' ) ):Dock( TOP );
			CommandButton( s, 'Give Gun Liscence', MakeFunction( BuildCommand, 'darkrp givelicense' ) ):Dock( TOP );
		end
	end

	if( TEAM_MAYOR and LocalPlayer():Team() == TEAM_MAYOR )then
		HeaderLine( s, 'MAYOR', Color( 200, 5, 0 ) ):Dock( TOP );
		CommandButton( s, 'Start Lockdown', MakeFunction( BuildCommand, 'darkrp lockdown' ) ):Dock( TOP );
		CommandButton( s, 'Stop Lockdown', MakeFunction( BuildCommand, 'darkrp unlockdown' ) ):Dock( TOP );
		CommandButton( s, 'Start Lottery', MakeFunction( BuildCommand, 'darkrp lottery' ) ):Dock( TOP );
		CommandButton( s, 'Give Gun Liscence', MakeFunction( BuildCommand, 'darkrp givelicense' ) ):Dock( TOP );
		CommandButton( s, 'Place Laws', MakeFunction( BuildCommand, 'darkrp placelaws' ) ):Dock( TOP );
		CommandButton( s, 'Add a law.', MakeFunction( BuildCommand, 'darkrp addlaw', NewStringQuery( 'Add a law.', 'Enter the law you would like to add.') ) ):Dock( TOP );
		CommandButton( s, 'Remove a law.', MakeFunction( BuildCommand, 'darkrp removelaw', NewStringQuery( 'Remove a law.', 'Enter the number of the law to remove.') ) ):Dock( TOP );
	end

	if( LocalPlayer():IsAdmin( ) )then
		HeaderLine( s, 'ADMIN', Color( 200, 200, 9 ) ):Dock( TOP );
		CommandButton( s, 'Set Jail Pos', MakeFunction( BuildCommand, 'darkrp jailpos' ) ):Dock( TOP );
		CommandButton( s, 'Add Jail Pos', MakeFunction( BuildCommand, 'darkrp addjailpos' ) ):Dock( TOP );

		CommandButton( s, 'Force Arrest', MakeFunction( BuildCommand, 'rp_arrest', NewPlayerQuery( function( p ) return not p.DarkRPVars.Arrested end ), NewNumberQuery( 'Arrest', 'enter arrest time.' ) ) ):Dock( TOP );
		CommandButton( s, 'UnArrest', MakeFunction( BuildCommand, 'rp_unarrest', NewPlayerQuery( function( p ) return p.DarkRPVars.Arrested end ) ) ):Dock( TOP );
	end
end