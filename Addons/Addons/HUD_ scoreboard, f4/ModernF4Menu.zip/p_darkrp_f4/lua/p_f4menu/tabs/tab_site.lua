local TABINFO = TABINFO;

-- TESTING PURPOSES ONLY.
TABINFO.name = 'Website';
TABINFO.index = 1000;
TABINFO.siteurl = 'http://www.tpsgaming.com/';

TABINFO.button = function( self )
	gui.OpenURL( TABINFO.siteurl );
end