MsgC(Color( 0, 0, 200 ),   '=====================================================\n= ');
MsgC(Color( 0, 200, 255 ), 'Loaded Animated F4 menu V2.0.0 by thelastpenguin™ ');
MsgC(Color( 0, 0, 200 ),   '=\n=====================================================\n\n');



if(SERVER)then
	AddCSLuaFile();
	AddCSLuaFile( 'p_f4menu/main.lua' );
end

include( 'p_f4menu/main.lua' );