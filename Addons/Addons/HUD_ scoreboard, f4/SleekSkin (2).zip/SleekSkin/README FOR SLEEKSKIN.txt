Config is inside the "darkrp" folder, called sh_config.lua

Good luck, add me on Steam if you need some help.