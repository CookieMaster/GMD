// server side apple
AddCSLuaFile( "cl_chat_tags.lua"  )