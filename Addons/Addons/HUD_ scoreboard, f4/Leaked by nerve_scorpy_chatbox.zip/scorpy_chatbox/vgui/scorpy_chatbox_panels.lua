--[[Ripped by wuat
File:lua/scorpy_chatbox/vgui/scorpy_chatbox_panels.lua]]--

local CG = {};
CG.Tabs = {};
local MESSAGE_PANEL = {}
local meta = FindMetaTable( "Player" ) function meta:ChatPrint( str) return self:PrintMessage( HUD_PRINTTALK, str ) end

CreateConVar("ssc_avatars", 1, {FCVAR_REPLICATED, FCVAR_SERVER_CAN_EXECUTE}, "Enable or Disable Avatars, Replaces with Rank images" )

function MESSAGE_PANEL:Init()
	self.NrLines = 0
	
	self:SetMouseInputEnabled(false)
	self:SetKeyboardInputEnabled(false)
	self:SetPaintBackgroundEnabled( false )
	self:SetPaintBorderEnabled( false )
	
	self.TextPanel = vgui.Create("RichLabel", self)
	self.TextPanel:SetFont("ChatFont")
	self.TextPanel:SetDefaultColor(Color(220,220,220))
	
	self.Icon = vgui.Create("DImage", self)
	self.Icon:SetSize(16, 16)
end

function MESSAGE_PANEL:PerformLayout()
	self.Icon:SetPos(30 - self.Icon:GetWide(), 0)
		
	self.TextPanel:SetWidth(self:GetWide() - 30 - 10)
	self.TextPanel:SetPos(30 + 5, 0)
	self.TextPanel:InvalidateLayout(true)
	self.NrLines = #self.TextPanel.Lines

	self:SetTall( math.Max( self.Icon:GetTall(), self.TextPanel:GetTall() ) )
	self.TextPanel:CenterVertical()
end

function MESSAGE_PANEL:Show()
	self.Hidden = false
	self:SetVisible(true)
end

function MESSAGE_PANEL:Hide()
	self.Hidden = true
	timer.Simple(0.30, function()
		if self.Hidden then
			self:SetVisible(false)
		end
	end)
end

function MESSAGE_PANEL:MoveToS(x, y)
	if self.TargetX != x or self.TargetY != y then
		self:MoveTo(x, y, 0.25 )
	end
	self.TargetX, self.TargetY = x, y
end

function MESSAGE_PANEL:SetMessage(contents, icon)
	for _,item in ipairs(contents) do
		if type(item) == "string" then
			self.TextPanel:AddText(item)
		elseif type(item) == "table" then
			self.TextPanel:AddColor(item)
		elseif type(item) == "Player" then
			self.TextPanel:AddPlayer(item)
			icon = icon or item
		end
	end
	
	if not icon then
		local match
		for _, ply in pairs( player.GetAll() ) do
			local name = ply:Name()
			if string.find(self.TextPanel.Text, name..": ", 1, true) then
				if not match or match:len() < name:len() then
					match = name
					icon = ply
				end
			end
		end
		if not match then
			if string.find(self.TextPanel.Text, "Console: ", 1, true) then
				icon = "icon16/application_xp_terminal.png"
			end
		end
	end
	
	if type(icon) == "Player" then
		if GetConVarNumber("ssc_avatars") == 1 then
			self.Icon.Avatar = vgui.Create("AvatarImage", self.Icon)
			self.Icon.Avatar:SetPlayer(icon)
			self.Icon.Avatar:SetSize(16,16)
			icon = "icon16/user.png"
		else
			if icon:IsSuperAdmin() then
				icon = "icon16/shield.png"
			elseif icon:IsAdmin() then
				icon = "icon16/star.png"
			else
				icon = "icon16/user.png"
			end
		end
	end
	
	icon = icon or "icon16/information.png"
	
	self.Icon:SetImage(icon)
end

local MessagePanel = vgui.RegisterTable(MESSAGE_PANEL, "Panel")


local TEXT_ENTRY_PANEL = {}

function TEXT_ENTRY_PANEL:Init()
	self:SetAllowNonAsciiCharacters(true)
	self.m_bLoseFocusOnClickAway = false
end

function TEXT_ENTRY_PANEL:Paint() derma.SkinHook( "Paint", "TextEntry", self ) end

function TEXT_ENTRY_PANEL:OnTextChanged()
	gamemode.Call( "ChatTextChanged", self:GetValue() )
end

function TEXT_ENTRY_PANEL:AllowInput()
	if string.len(self:GetValue()) >= 126 then
		surface.PlaySound("Resource/warning.wav")
		return true
	end
end

function TEXT_ENTRY_PANEL:OnKeyCodeTyped( code )
	local chatbox = self:GetParent()
	local text = self:GetValue()
	if code == KEY_ENTER then
		if string.Trim(text) != "" then
			local match = string.match(text, "^!%s*(.+)$")
			if chatbox.TeamChat then
				RunConsoleCommand("say_team", text)
			else
				RunConsoleCommand("say", text)
			end
		end
		chatbox:Close()
	elseif code == KEY_ESCAPE then
		chatbox:Close()
		timer.Simple(0, function() RunConsoleCommand("cancelselect") end)
	end
end

local ChatboxTextEntry = vgui.RegisterTable(TEXT_ENTRY_PANEL, "DTextEntry")

local CHATBOX_PANEL = {}

function CHATBOX_PANEL:Init()
	self.IsOpen = false
	self.TeamChat = false
	self.FirstOpen = true
	self.Messages = {}
	self.Lines = {}
	self.RecentMessages = {}
	self.ButtonsList = {}
	self.ShowLines = 10
	
	self:SetPaintBackgroundEnabled( false )
	self:SetPaintBorderEnabled( false )
	self:DockPadding(8, 8, 8, 8)
	self:SetSize(500, 32)
	self.x = -self:GetWide()
	
	self.ChatTypeLabel = vgui.Create("DLabel", self)
	self.ChatTypeLabel:SetTextColor(Color(255, 255, 255, 255))
	self.ChatTypeLabel:SetFont("DefaultBold")
	self.ChatTypeLabel:Dock(LEFT)
	self.ChatTypeLabel:DockMargin(0, 0, 4, 0)
	
	self.TextEntry = vgui.CreateFromTable(ChatboxTextEntry, self)
	self.TextEntry:Dock(FILL)
	
	self.ScrollBar = vgui.Create( "DVScrollBar" )
	function self.ScrollBar.GetParent() return self end
	
	self.CGDropdown = vgui.Create("Panel")
	self.CGDropdown:SetVisible(false)
	self.CGDropdown:DockPadding(8, 4, 8, 4)
	function self.CGDropdown:Paint() derma.SkinHook( "Paint", "CGDropdown", self ) end
	
	self.CG_URL = vgui.Create("DLabel", self.CGDropdown)
	self.CG_URL:SetTextColor(Color(255, 255, 255, 255))
	self.CG_URL:SetText("World Dominance") --Phoenix says you must change this to your community title or web url!
	self.CG_URL:SizeToContentsX()
	self.CG_URL:Dock(LEFT)
end

function CHATBOX_PANEL:Paint() derma.SkinHook( "Paint", "InputPanel", self ) end

function CHATBOX_PANEL:PerformLayout()
	self.y = ScrH() - 140 - self:GetTall() - self.CGDropdown:GetTall()
	
	self.ScrollBar:SetSize(16, self.ShowLines*draw.GetFontHeight("ChatFont"))
	self.ScrollBar:SetPos( self:GetWide() - 16, self.y - 16 - self.ScrollBar:GetTall() )
	self.ScrollBar:SetUp( self.ShowLines, #self.Lines )
	
	self.CGDropdown:SetSize(self:GetWide() - 40, 24)
	self.CGDropdown:SetPos(20, self.IsOpen and self.y + self:GetTall() or self.y)
end

function CHATBOX_PANEL:OnVScroll()
	self:SetRecentMessages()
end

function CHATBOX_PANEL:OnScrollbarAppear()
	if not self.IsOpen then
		self.ScrollBar:SetAlpha(0)
	end
end

-- These are examples. You can add/remove these if you wish, but remove the buttons too!
concommand.Add("loadsite", function()
	gui.OpenURL("http://worlddominance.org/")
end)

concommand.Add("loadsite_donate", function()
	gui.OpenURL("http://worlddominance.org/forums/donations.php")
end)

function CHATBOX_PANEL:Open(team_chat)
	if self.IsOpen then return end
	self.IsOpen = true
	gamemode.Call("StartChat")
	
	self.TeamChat = team_chat
	self.ChatTypeLabel:SetText(team_chat and "Say (Team):" or "Say:")
	self.ChatTypeLabel:SizeToContentsX()
	self:InvalidateLayout(true)
	
	self:SetMouseInputEnabled(true)
	self:SetKeyboardInputEnabled(true)
	self:MakePopup()
	self.TextEntry:RequestFocus()
	
	if self.FirstOpen then
		self:SetSkin("ScorpyChatbox")
		self.CGDropdown:SetSkin("ScorpyChatbox")
		self.ScrollBar:SetSkin("ScorpyChatbox")
		
		--Add Custom Buttons here ;)
		--self.AddCGButton(Name, Image, Description, Command)
		--Images can be found here: http://www.glua.me/bin/?path=/materials/icon16
		
		--Examples
		self:AddCGButton("Website", "icon16/world_go.png", "World Dominance Website", "loadsite")
		self:AddCGButton("Donate", "icon16/coins.png", "Donate for benefits!", "loadsite_donate")
		self:AddCGButton("Shop", "icon16/emoticon_smile.png", "Open Pointshop", "ps_shop")
		
		
		self.FirstOpen = false
	end
	
	for _,btn in pairs(self.ButtonsList) do
		btn:SetVisible(true)
	end
	self.CGDropdown:InvalidateLayout(true)
	
	self:SetRecentMessages()
	
	self:MoveTo( 0, self.y, 0.25, 0, 1)
	timer.Simple(0.30, function()
		if self.IsOpen then
			self.CGDropdown:SetVisible(true)
			self.CGDropdown:MoveTo( self.CGDropdown.x, self.y + self:GetTall(), 0.25)
			self.ScrollBar:AlphaTo(255, 0.25)
		end
	end)
end

function CHATBOX_PANEL:Close()
	if not self.IsOpen then return end
	self.IsOpen = false
	gamemode.Call("FinishChat")
	
	self:SetMouseInputEnabled(false)
	self:SetKeyboardInputEnabled(false)
	self.TextEntry:SetText("")
	gamemode.Call( "ChatTextChanged", "" )
	
	self.ScrollBar:SetScroll(self.ScrollBar.CanvasSize)
	self:SetRecentMessages()
	
	self.ScrollBar:AlphaTo(0, 0.25)
	self.CGDropdown:MoveTo( self.CGDropdown.x, self.y, 0.25, 0, 1)
	timer.Simple(0.30, function()
		if not self.IsOpen then
			self.CGDropdown:SetVisible(false)
			self:MoveTo( -self:GetWide(), self.y, 0.25)
		end
	end)
end

function CHATBOX_PANEL:AddMessage(contents, icon)
	local msg = vgui.CreateFromTable(MessagePanel)
	msg:SetMessage(contents, icon)
	msg:SetWidth(self:GetWide() - 16)
	msg:InvalidateLayout(true)
	msg:SetPos(0, self.y)
	local index = table.insert(self.Messages, msg)
	
	for i = 1, msg.NrLines do
		table.insert(self.Lines, index)
	end
	
	self.ScrollBar:SetUp( self.ShowLines, #self.Lines )
	
	if not self.IsOpen or self.CurrentMessage == #self.Messages - 1 then
		self.ScrollBar:SetScroll(self.ScrollBar.CanvasSize)
		self:SetRecentMessages()
	end
	
	timer.Simple(10, function()
		msg.Expired = true
		if not self.IsOpen then
			msg:Hide()
			msg:MoveToS(-msg:GetWide(), msg.TargetY)
		end
	end)
	
	chat.PlaySound()
end

function CHATBOX_PANEL:SetRecentMessages()
	local offset_line = math.floor(self.ScrollBar:GetScroll()) + math.Min(self.ShowLines, #self.Lines)
	local i = self.Lines[offset_line]
	if not i then return end
	self.CurrentMessage = i
	
	local new_recent_messages = {}
	local y = self.y - 16
	local nr_lines = 0
	while nr_lines < self.ShowLines and i >= 1 do
		local msg = self.Messages[i]
		nr_lines = nr_lines + msg.NrLines
		y = y - msg:GetTall()
		if self.IsOpen or not msg.Expired then
			msg:Show()
		else
			msg:Hide()
		end
		msg:MoveToS(msg.Hidden and -msg:GetWide() or 0, y)
		table.insert(new_recent_messages, msg)
		i = i - 1
	end
	
	for _, msg in pairs(self.RecentMessages) do
		if not table.HasValue(new_recent_messages, msg) then
			msg:MoveToS(-msg:GetWide(), msg.TargetY)
			msg:Hide()
		end
	end
	
	self.RecentMessages = new_recent_messages
end

function CHATBOX_PANEL:AddCGButton(name, icon, description, command)
	local btn = vgui.Create("DImageButton", self.CGDropdown)
	btn:SetSize(16,16)
	btn:SetImage(icon)
	btn:SetTooltip(name)
	if description and description !="" then
		btn:SetTooltip(name.." - "..description)
	end
	btn.Name = name
	btn.Command = command
	function btn.DoClick(btn)
		LocalPlayer():ConCommand(btn.Command)
		self:Close()
	end
	btn:DockMargin(2,0,0,0)
	btn:Dock(RIGHT)
	table.insert(self.ButtonsList, btn)
end

vgui.Register( "ScorpyChatbox", CHATBOX_PANEL, "EditablePanel")