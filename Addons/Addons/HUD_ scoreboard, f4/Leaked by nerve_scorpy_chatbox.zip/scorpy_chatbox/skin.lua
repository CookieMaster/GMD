--[[Ripped by wuat
File:lua/scorpy_chatbox/skin.lua]]--

local SKIN = {}

SKIN.PrintName 		= "World Dominance"
SKIN.Author 		= "World Dominance"
SKIN.DermaVersion	= 1

SKIN.BGColor = Color(0, 0, 0, 255)
SKIN.OutlineColor = Color(0, 160, 255, 255)
SKIN.FGColor = Color(255, 255, 255, 255)

SKIN.OutlineGlow = 100

SKIN.TextEntryTextColor = Color( 0, 0, 0, 255 )
SKIN.TextEntryHighlightColor = Color( 0, 180, 255, 255 )
SKIN.TextEntryCursorColor = Color( 0, 0, 0, 255 )

function SKIN:PaintInputPanel(panel)
	local outline = 3
	draw.RoundedBoxEx( 12, 0, 0, panel:GetWide(), panel:GetTall(), self.OutlineColor, false, true, false, true )
	draw.RoundedBoxEx( 12, 0, outline, panel:GetWide() - outline, panel:GetTall() - outline*2, self.BGColor, false, true, false, true )
end

function SKIN:PaintTextEntry(panel)
	draw.RoundedBoxEx( 8, 0, 0, panel:GetWide(), panel:GetTall(), self.FGColor, false, true, false, true )

	panel:DrawTextEntryText( self.TextEntryTextColor, self.TextEntryHighlightColor, self.TextEntryCursorColor )
end

function SKIN:PaintVScrollBar( panel ) end

function SKIN:PaintSysButton( panel )
	local outline = 2
	draw.RoundedBoxEx( 4, 0, 0, panel:GetWide(), panel:GetTall(), self.OutlineColor, false, false, false, false )
	draw.RoundedBoxEx( 4, outline, outline, panel:GetWide() - outline*2, panel:GetTall() - outline*2, self.BGColor, false, false, false, false )
end

function SKIN:PaintScrollBarGrip( panel )
	local outline = 2
	draw.RoundedBoxEx( 4, 0, 0, panel:GetWide(), panel:GetTall(), self.OutlineColor, false, false, false, false )
	draw.RoundedBoxEx( 4, outline, outline, panel:GetWide() - outline*2, panel:GetTall() - outline*2, self.BGColor, false, false, false, false )
end

function SKIN:PaintCGDropdown(panel)
	local outline = 2
	draw.RoundedBoxEx( 8, 0, 0, panel:GetWide(), panel:GetTall(), self.OutlineColor, false, false, true, true )
	draw.RoundedBoxEx( 8, outline, 0, panel:GetWide() - outline*2, panel:GetTall() - outline, self.BGColor, false, false, true, true )
end

derma.DefineSkin( "ScorpyChatbox", "Scorpy's Simple Chatbox - Skin", SKIN )