--[[Ripped by wuat
File:lua/scorpy_chatbox/cl_init.lua]]--

include("scorpy_chatbox/skin.lua")
include("scorpy_chatbox/vgui/rich_label.lua")
include("scorpy_chatbox/vgui/scorpy_chatbox_panels.lua")

local Chatbox

local CG = {};

local meta = FindMetaTable( "Player" ) function meta:ChatPrint( str) return self:PrintMessage( HUD_PRINTTALK, str ) end

CG.Chatbox = Chatbox

hook.Add("InitPostEntity", "Scorpy's Simple Chatbox - Init", function() 
	Chatbox = vgui.Create("ScorpyChatbox")
end)

local oldChatAddText = chat.AddText
function chat.AddText(...)
	oldChatAddText(...)
	
	Chatbox = Chatbox or vgui.Create("ScorpyChatbox")
	Chatbox:AddMessage({...})
end

net.Receive("PrintDatMessage", function( len )
	local stuff = net.ReadString()
	chat.AddText( stuff )
end)

local oldHookCall = hook.Call
function hook.Call(name, gm, ...)
	local ret = oldHookCall(name, gm, ...)
	
	if name == "ChatText" and not ret then
		local arg = {...}
		local text, message_type = arg[3], arg[4]
		if message_type == "chat" then return end
		local icon
		local tab = {}
		
		if message_type == "joinleave" then
			icon = "icon16/world.png"
			table.insert(tab, Color(0, 255, 120))
		end
		
		table.insert(tab, text)
		
		Chatbox = Chatbox or vgui.Create("ScorpyChatbox")
		Chatbox:AddMessage(tab, icon)
	end
	
	return ret
end

hook.Add("HUDShouldDraw", "Scorpy's Simple Chatbox - Hide Default", function(name)
	if name=="CHudChat" then
		return false
	end
end)

hook.Add("PlayerBindPress", "Scorpy's Simple Chatbox - Open", function(ply, bind, pressed)
	if string.find(bind, "messagemode2") then
		Chatbox:Open(true)
		return true
	elseif string.find(bind, "messagemode") then
		Chatbox:Open(false)
		return true
	end
end)

usermessage.Hook("SSC - PM", function(um)
	local ply = um:ReadEntity()
	local target = um:ReadEntity()
	local text = um:ReadString()
	local tab = {}
	
	table.insert( tab, Color( 0, 200, 200 ) )
	table.insert( tab, "(PRIVATE" )
	if target != LocalPlayer() then
		table.insert( tab, " to "..target:Name() )
	end
	table.insert( tab, ") " )
	
	table.insert( tab, ply )
	
	table.insert( tab, Color( 255, 255, 255 ) )
	table.insert( tab, ": "..text )
	
	chat.AddText( unpack(tab) )
end)