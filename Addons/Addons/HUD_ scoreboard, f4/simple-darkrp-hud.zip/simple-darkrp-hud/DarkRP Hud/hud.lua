/*---------------------------------------------------------------------------
HUD ConVars
---------------------------------------------------------------------------*/
local ConVars = {}
local HUDWidth
local HUDHeight

CreateClientConVar("weaponhud", 0, true, false)

local function ReloadConVars()
	ConVars = {
		background = {0,0,0,100},
		Healthbackground = {0,0,0,200},
		Healthforeground = {140,0,0,180},
		HealthText = {255,255,255,200},
		Job1 = {0,0,150,200},
		Job2 = {0,0,0,255},
		salary1 = {0,150,0,200},
		salary2 = {0,0,0,255}
	}

	for name, Colour in pairs(ConVars) do
		ConVars[name] = {}
		for num, rgb in SortedPairs(Colour) do
			local CVar = GetConVar(name..num) or CreateClientConVar(name..num, rgb, true, false)
			table.insert(ConVars[name], CVar:GetInt())

			if not cvars.GetConVarCallbacks(name..num, false) then
				cvars.AddChangeCallback(name..num, function() timer.Simple(0,ReloadConVars) end)
			end
		end
		ConVars[name] = Color(unpack(ConVars[name]))
	end


	HUDWidth = (GetConVar("HudW") or  CreateClientConVar("HudW", 240, true, false)):GetInt()
	HUDHeight = (GetConVar("HudH") or CreateClientConVar("HudH", 115, true, false)):GetInt()

	if not cvars.GetConVarCallbacks("HudW", false) and not cvars.GetConVarCallbacks("HudH", false) then
		cvars.AddChangeCallback("HudW", function() timer.Simple(0,ReloadConVars) end)
		cvars.AddChangeCallback("HudH", function() timer.Simple(0,ReloadConVars) end)
	end
end
ReloadConVars()

local function formatNumber(n)
	n = tonumber(n)
	if (!n) then
		return 0
	end
	if n >= 1e14 then return tostring(n) end
    n = tostring(n)
    sep = sep or ","
    local dp = string.find(n, "%.") or #n+1
	for i=dp-4, 1, -3 do
		n = n:sub(1, i) .. sep .. n:sub(i+1)
    end
    return n
end


local Scrw, Scrh, RelativeX, RelativeY
/*---------------------------------------------------------------------------
HUD Seperate Elements
---------------------------------------------------------------------------*/

/*---------------------------------------------------------
Hiding The Normal HUD
---------------------------------------------------------*/
local function HUD_HideHUD( name )
if (name == "CHudSuitPower" or name == "CHudHealth" or name == "CHudBattery" or name == "CHudAmmo" or name == "CHudSecondaryAmmo") then
return false
end
end
hook.Add( "HUDShouldDraw", "HUD_HideHUD", HUD_HideHUD)

/*---------------------------------------------------------
Recreation GMod 13 Font
---------------------------------------------------------*/

surface.CreateFont("HUD_Font", {
    font = "Trebuchet MS", 
    size = 22, 
    weight = 900
})

/*---------------------------------------------------------
The HUD
---------------------------------------------------------*/
local function DrawNewHUD()
local PlyTeam = LocalPlayer().DarkRPVars.job or "ERROR"
local PlyHealth = LocalPlayer():Health() or "ERROR"
local PlyArmour = LocalPlayer():Armor() or "ERROR"
local PlySalary = LocalPlayer().DarkRPVars.salary or "ERROR"
local PlyWallet = formatNumber(LocalPlayer().DarkRPVars.money) or "ERROR"
local PlyPing = LocalPlayer():Ping() or "ERROR"
local TopColor = Color(60,60,60,225)
--local ScreenLocation = true // INFO: This setting changes whatever the line draws in the top of the screen, or in the bottom. Setting it to 'true' puts it at the top, setting it to 'false' puts it in the bottom.
-- Currently not added. Will possibly be added in the future.

if !LocalPlayer():Alive() then return end
if (LocalPlayer():GetActiveWeapon() == NULL) then return end

--Top Box
draw.RoundedBox( 0, 0, 0, ScrW(), ScreenScale(13), TopColor )

--Player Name Box
draw.RoundedBox( 6, ScreenScale(555), ScreenScale(16), ScreenScale(80), ScreenScale(12), TopColor )
draw.SimpleText( "Name: "..LocalPlayer():Nick(), "HUD_Font", ScreenScale(595), ScreenScale(22), Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

--Name Stuff
draw.SimpleText( "Garry's Mod Community", "HUD_Font", ScreenScale(55), ScreenScale(6), Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

--Health Stuff

surface.SetDrawColor(255,255,255,255)
surface.SetMaterial(Material("icon16/heart.png"))
surface.DrawTexturedRect(ScreenScale(113), ScreenScale(3.7),ScreenScale(5),ScreenScale(5))

draw.SimpleText( "Health: "..PlyHealth, "HUD_Font", ScreenScale(135), ScreenScale(6), Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

--Armor Stuff
surface.SetDrawColor(255,255,255,255)
surface.SetMaterial(Material("icon16/shield.png"))
surface.DrawTexturedRect(ScreenScale(178), ScreenScale(3.7),ScreenScale(5),ScreenScale(5))
draw.SimpleText( "Armor: "..PlyArmour, "HUD_Font", ScreenScale(200), ScreenScale(6), Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

--Salary Stuff
surface.SetDrawColor(255,255,255,255)
surface.SetMaterial(Material("icon16/money_add.png"))
surface.DrawTexturedRect(ScreenScale(247), ScreenScale(3.7),ScreenScale(5),ScreenScale(5))
draw.SimpleText( "Salary: "..PlySalary, "HUD_Font", ScreenScale(269), ScreenScale(6), Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

draw.SimpleText( "Money: $"..PlyWallet, "HUD_Font", ScreenScale(350), ScreenScale(6), Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

--Job Stuff
draw.SimpleText( "Job: "..PlyTeam, "HUD_Font", ScreenScale(420), ScreenScale(6), Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )


--Ammo Text
local Weapon = LocalPlayer():GetActiveWeapon()
local Ammo1 = Weapon:Clip1()
local Ammo2 = LocalPlayer():GetAmmoCount(Weapon:GetPrimaryAmmoType())

if Ammo1 >= 0 then
draw.SimpleText( "Ammo: "..Ammo1.." | "..Ammo2, "HUD_Font", ScreenScale(500), ScreenScale(6), Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
else
draw.SimpleText( "Ammo: N/A", "HUD_Font", ScreenScale(500), ScreenScale(6), Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
end

draw.SimpleText( "Ping: "..PlyPing, "HUD_Font", ScreenScale(570), ScreenScale(6), Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )

end

local Page = Material("icon16/page_white_text.png")
local function GunLicense()
	if LocalPlayer().DarkRPVars.HasGunlicense then
		surface.SetMaterial(Page)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawTexturedRect(RelativeX + HUDWidth, ScrH() - 34, 32, 32)
	end
end

local function JobHelp()
	local Helps = {"Cop", "Mayor", "Admin", "Boss"}

	for k,v in pairs(Helps) do
		if LocalPlayer().DarkRPVars["help"..v] then
			draw.RoundedBox(10, 10, 140, 590, 194, Color(0, 0, 0, 255))
			draw.RoundedBox(10, 12, 142, 586, 190, Color(51, 58, 51, 200))
			draw.RoundedBox(10, 12, 142, 586, 20, Color(0, 0, 70, 200))
			draw.DrawText(v.." Help", "DarkRPHUD1", 30, 142, Color(255,0,0,255),0)
			draw.DrawText(string.format(LANGUAGE[v:lower().."help"], GAMEMODE.Config.jailtimer), "DarkRPHUD1", 30, 165, Color(255,255,255,255),0)
		end
	end
end

local function Agenda()
	local DrawAgenda, AgendaManager = DarkRPAgendas[LocalPlayer():Team()], LocalPlayer():Team()
	if not DrawAgenda then
		for k,v in pairs(DarkRPAgendas) do
			if table.HasValue(v.Listeners or {}, LocalPlayer():Team()) then
				DrawAgenda, AgendaManager = DarkRPAgendas[k], k
				break
			end
		end
	end
	if DrawAgenda then
		draw.RoundedBox(10, 10, 140, 460, 110, Color(0, 0, 0, 155))
		draw.RoundedBox(10, 12, 142, 456, 106, Color(51, 58, 51,100))
		draw.RoundedBox(10, 12, 142, 456, 20, Color(0, 0, 70, 100))

		draw.DrawText(DrawAgenda.Title, "DarkRPHUD1", 30, 142, Color(255,0,0,255),0)

		local AgendaText = ""
		for k,v in pairs(team.GetPlayers(AgendaManager)) do
			if not v.DarkRPVars then continue end
			AgendaText = AgendaText .. (v.DarkRPVars.agenda or "")
		end
		draw.DrawText(string.gsub(string.gsub(AgendaText, "//", "\n"), "\\n", "\n"), "DarkRPHUD1", 30, 165, Color(255,255,255,255),0)
	end
end

local VoiceChatTexture = surface.GetTextureID("voice/icntlk_pl")
local function DrawVoiceChat()
	if LocalPlayer().DRPIsTalking then
		local chbxX, chboxY = chat.GetChatBoxPos()

		local Rotating = math.sin(CurTime()*3)
		local backwards = 0
		if Rotating < 0 then
			Rotating = 1-(1+Rotating)
			backwards = 180
		end
		surface.SetTexture(VoiceChatTexture)
		surface.SetDrawColor(ConVars.Healthforeground)
		surface.DrawTexturedRectRotated(ScrW() - 100, chboxY, Rotating*96, 96, backwards)
	end
end

local function LockDown()
	local chbxX, chboxY = chat.GetChatBoxPos()
	if util.tobool(GetConVarNumber("DarkRP_LockDown")) then
		local cin = (math.sin(CurTime()) + 1) / 2
		local chatBoxSize = math.floor(ScrH() / 4)
		draw.DrawText(LANGUAGE.lockdown_started, "ScoreboardSubtitle", chbxX, chboxY + chatBoxSize, Color(cin * 255, 0, 255 - (cin * 255), 255), TEXT_ALIGN_LEFT)
	end
end

local Arrested = function() end

usermessage.Hook("GotArrested", function(msg)
	local StartArrested = CurTime()
	local ArrestedUntil = msg:ReadFloat()

	Arrested = function()
		if CurTime() - StartArrested <= ArrestedUntil and LocalPlayer().DarkRPVars.Arrested then
		draw.DrawText(string.format(LANGUAGE.youre_arrested, math.ceil(ArrestedUntil - (CurTime() - StartArrested))), "DarkRPHUD1", ScrW()/2, ScrH() - ScrH()/12, Color(255,255,255,255), 1)
		elseif not LocalPlayer().DarkRPVars.Arrested then
			Arrested = function() end
		end
	end
end)

local AdminTell = function() end

usermessage.Hook("AdminTell", function(msg)
	local Message = msg:ReadString()

	AdminTell = function()
		draw.RoundedBox(4, 10, 10, ScrW() - 20, 100, Color(0, 0, 0, 200))
		draw.DrawText(LANGUAGE.listen_up, "GModToolName", ScrW() / 2 + 10, 10, Color(255, 255, 255, 255), 1)
		draw.DrawText(Message, "ChatFont", ScrW() / 2 + 10, 80, Color(200, 30, 30, 255), 1)
	end

	timer.Simple(10, function()
		AdminTell = function() end
	end)
end)

/*---------------------------------------------------------------------------
Drawing the HUD elements such as Health etc.
---------------------------------------------------------------------------*/
local function DrawHUD()
	Scrw, Scrh = ScrW(), ScrH()
	RelativeX, RelativeY = 0, Scrh

	--Background
	--draw.RoundedBox(6, 0, Scrh - HUDHeight, HUDWidth, HUDHeight, ConVars.background)

	DrawNewHUD()
	GunLicense()
	Agenda()
	JobHelp()
	DrawVoiceChat()
	LockDown()

	Arrested()
	AdminTell()
end

/*---------------------------------------------------------------------------
Entity HUDPaint things
---------------------------------------------------------------------------*/
local function DrawPlayerInfo(ply)
	local pos = ply:EyePos()

	pos.z = pos.z + 10 -- The position we want is a bit above the position of the eyes
	pos = pos:ToScreen()
	pos.y = pos.y - 50 -- Move the text up a few pixels to compensate for the height of the text

	if GAMEMODE.Config.showname and not ply.DarkRPVars.wanted then
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x + 1, pos.y + 1, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x, pos.y, team.GetColor(ply:Team()), 1)
		draw.DrawText(DarkRP.getPhrase("health", ply:Health()), "DarkRPHUD2", pos.x + 1, pos.y + 21, Color(0, 0, 0, 255), 1)
		draw.DrawText(DarkRP.getPhrase("health", ply:Health()), "DarkRPHUD2", pos.x, pos.y + 20, Color(255,255,255,200), 1)
	end

	if GAMEMODE.Config.showjob then
		local teamname = team.GetName(ply:Team())
		draw.DrawText(ply.DarkRPVars.job or teamname, "DarkRPHUD2", pos.x + 1, pos.y + 41, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply.DarkRPVars.job or teamname, "DarkRPHUD2", pos.x, pos.y + 40, Color(255, 255, 255, 200), 1)
	end

	if ply.DarkRPVars.HasGunlicense then
		surface.SetMaterial(Page)
		surface.SetDrawColor(255,255,255,255)
		surface.DrawTexturedRect(pos.x-16, pos.y + 60, 32, 32)
	end
end

local function DrawWantedInfo(ply)
	if not ply:Alive() then return end

	local pos = ply:EyePos()
	if not pos:RPIsInSight({localplayer, ply}) then return end

	pos.z = pos.z + 14
	pos = pos:ToScreen()

	if GAMEMODE.Config.showname then
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x + 1, pos.y + 1, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x, pos.y, team.GetColor(ply:Team()), 1)
	end

	local wantedText = DarkRP.getPhrase("wanted", tostring(ply:getDarkRPVar("wantedReason")))

	draw.DrawText(wantedText, "DarkRPHUD2", pos.x, pos.y - 40, Color(255, 255, 255, 200), 1)
	draw.DrawText(wantedText, "DarkRPHUD2", pos.x + 1, pos.y - 41, Color(255, 0, 0, 255), 1)
end

/*---------------------------------------------------------------------------
The Entity display: draw HUD information about entities
---------------------------------------------------------------------------*/
local function DrawEntityDisplay()
	local shootPos = LocalPlayer():GetShootPos()
	local aimVec = LocalPlayer():GetAimVector()

	for k, ply in pairs(player.GetAll()) do
		if not ply:Alive() then continue end
		local hisPos = ply:GetShootPos()

		ply.DarkRPVars = ply.DarkRPVars or {}
		if ply.DarkRPVars.wanted then DrawWantedInfo(ply) end

		if GAMEMODE.Config.globalshow and ply ~= LocalPlayer() then
			DrawPlayerInfo(ply)
		-- Draw when you're (almost) looking at him
		elseif not GAMEMODE.Config.globalshow and hisPos:Distance(shootPos) < 400 then
			local pos = hisPos - shootPos
			local unitPos = pos:GetNormalized()
			if unitPos:Dot(aimVec) > 0.95 then
				local trace = util.QuickTrace(shootPos, pos, LocalPlayer())
				if trace.Hit and trace.Entity ~= ply then return end
				DrawPlayerInfo(ply)
			end
		end
	end

	local tr = LocalPlayer():GetEyeTrace()

	if tr.Entity:IsOwnable() and tr.Entity:GetPos():Distance(LocalPlayer():GetPos()) < 200 then
		tr.Entity:DrawOwnableInfo()
	end
end

/*---------------------------------------------------------------------------
Zombie display
---------------------------------------------------------------------------*/
local function DrawZombieInfo()
	if not LocalPlayer().DarkRPVars.zombieToggle then return end
	for x=1, LocalPlayer().DarkRPVars.numPoints, 1 do
		local zPoint = LocalPlayer().DarkRPVars["zPoints".. x]
		if zPoint then
			zPoint = zPoint:ToScreen()
			draw.DrawText("Zombie Spawn (" .. x .. ")", "DarkRPHUD2", zPoint.x, zPoint.y - 20, Color(255, 255, 255, 200), 1)
			draw.DrawText("Zombie Spawn (" .. x .. ")", "DarkRPHUD2", zPoint.x + 1, zPoint.y - 21, Color(255, 0, 0, 255), 1)
		end
	end
end

/*---------------------------------------------------------------------------
Actual HUDPaint hook
---------------------------------------------------------------------------*/
function GM:HUDPaint()
	DrawHUD()
	DrawZombieInfo()
	DrawEntityDisplay()

	self.BaseClass:HUDPaint()
end