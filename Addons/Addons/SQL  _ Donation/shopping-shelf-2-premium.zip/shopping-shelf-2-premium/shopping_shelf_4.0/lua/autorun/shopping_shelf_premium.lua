sh_SS = {}
sh_SS.Config =
{
	UseCashRegistry = true,	-- Use cash registry that stores money from bought items or send money right to shelf owner?
	RobTime			= 30,		-- Amount of time in seconds it takes to rob a cash registry
}

sh_SS.Sellables = {}

sh_SS.Sellables['spawned_weapon'] = 
{ 
	itemName = 'Weapon', 
	itemShelfPos = Vector(0, 0, 0), 
	itemShelfAng = Angle(0, 0, 90),
	iconCamPos = Vector(15, 0, 15), 
	iconLookAt = Vector(0, 0, 3), 
	vars = { 'weaponclass' } 
}

sh_SS.Sellables['spawned_food'] = 
{ 
	itemName = 'Food', 
	itemShelfPos = Vector(0, 0, 7), 
	itemShelfAng = Angle(0, 90, 0),
	iconCamPos = Vector(15, 0, 15), 
	iconLookAt = Vector(0, 0, 3) 
}

sh_SS.Sellables['ng_cooler'] = 
{ 
	itemName = 'Cooler', 
	itemShelfPos = Vector(0, 0, 2.5), 
	itemShelfAng = Angle(0, 90, 0),
	iconCamPos = Vector(20, 0, 20), 
	iconLookAt = Vector(0, 0, 3) 
}

sh_SS.Sellables['ng_tuner'] = 
{ 
	itemName = 'Tuner', 
	itemShelfPos = Vector(0, -4, 1), 
	itemShelfAng = Angle(0, 90, 0),
	iconCamPos = Vector(10, 0, 10), 
	iconLookAt = Vector(0, 0, 1) 
}

sh_SS.Sellables['ng_overclocker'] = 
{ 
	itemName = 'Overclocker', 
	itemShelfPos = Vector(0, -4, 1), 
	itemShelfAng = Angle(0, 90, 0),
	iconCamPos = Vector(10, 0, 10), 
	iconLookAt = Vector(0, 0, 1) 
}