include("shared.lua")

function ENT:Initialize()
	self.IsPackage = true
end

function ENT:Draw()
	self:DrawModel()
end

local function DrawPackageInfo()
	if LocalPlayer():GetEyeTrace().Entity.IsPackage then
		local Package = LocalPlayer():GetEyeTrace().Entity

		local Dist = LocalPlayer():GetPos():Distance(Package:GetPos())
		local Pos = Package:GetPos():ToScreen()
		if not Package.dt.owning_ent then return end
		if Dist < 300 then
			draw.SimpleTextOutlined( "Shopping package (Use to Unpack)", "DermaDefaultBold", Pos.x, Pos.y, Color(142, 235, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255) )
			draw.SimpleTextOutlined( "Owned by "..Package.dt.owning_ent:Nick(), "DermaDefaultBold", Pos.x, Pos.y+15, Color(255, 190, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255) )
		end
	end
end
hook.Add( "HUDPaint", "DrawPackageInfo", DrawPackageInfo )