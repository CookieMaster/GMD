AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

util.AddNetworkString('NET_SS_StoredMoney')
util.AddNetworkString('NET_CR_RobInfo')
util.AddNetworkString('NET_SS_CashRegOpenMenu')

util.AddNetworkString('NET_CR_TakeStoredMoney')
util.AddNetworkString('NET_CR_StartRobing')

local sv_CR = {}

function ENT:Initialize()
	self:SetModel("models/props_c17/cashregister01a.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)

	local phys = self:GetPhysicsObject()
	phys:Wake()

	self.IsBusy = false

	self.IsCashRegistry = true
	self.StoredMoney = 0
	self.Rober = nil
	self.RobProgress = 0
end

function ENT:Use( activator, caller )
	if self.IsBusy == true then return end
	net.Start('NET_SS_CashRegOpenMenu')
		net.WriteEntity( self )
	net.Send( caller )
end

function ENT:UpdateStoredMoney()
	net.Start('NET_SS_StoredMoney')
		net.WriteEntity(self)
		net.WriteInt(self.StoredMoney, 16)
	net.Broadcast()
end

function ENT:UpdateRobInfo()
	net.Start('NET_CR_RobInfo')
		net.WriteEntity( self )
		net.WriteEntity( self.Rober )
		net.WriteInt( self.RobProgress, 16 )
	net.Broadcast()
end

function sv_CR.AllowGrabs( person, ent )
	if ent.IsPackage == true then
		if person != ent.dt.owning_ent then
			return false
		else
			return true
		end
	end
end
hook.Add('GravGunPickupAllowed', 'AlolwGrabs', sv_CR.AllowGrabs)

function sv_CR.TakeStoredMoney( person )
	local Registry = net.ReadEntity()
	local Person = net.ReadEntity()

	if Registry.IsBusy == true then return end
	if Person != Registry.dt.owning_ent then return end
	if Registry.StoredMoney <= 0 then return end

	local Amount = Registry.StoredMoney
	Registry.IsBusy = true
	Person:AddMoney(Registry.StoredMoney)
	Registry.StoredMoney = 0
	Registry.IsBusy = false

	GAMEMODE:Notify( Person, 2, 5, "You have taken $"..Amount.." from the cash registry")

	Registry:UpdateStoredMoney()
end
net.Receive('NET_CR_TakeStoredMoney', sv_CR.TakeStoredMoney)

function ENT:Think()
	self:RobbingTimer()
end

local TimePerProgress = sh_SS.Config.RobTime / 10
function ENT:RobbingTimer()
	if self.Rober == nil then return end
	if self.Rober:GetPos():Distance(self:GetPos()) > 75 then
		self.Rober = nil
		self.IsBusy = false
		self:UpdateRobInfo()
	end
	if self.RobingCalled + TimePerProgress > CurTime() then return end

	if self.RobProgress < 100 then
		self.RobProgress = self.RobProgress + 10
		self:UpdateRobInfo()
		self.RobingCalled = CurTime()
	else
		local Amount = self.StoredMoney
		self.Rober:AddMoney(self.StoredMoney)
		self.StoredMoney = 0
		GAMEMODE:Notify( self.Rober, 2, 5, "You have stolen $"..Amount.." from the cash registry")
		self.Rober = nil
		self.IsBusy = false

		self:UpdateStoredMoney()
		self:UpdateRobInfo()
	end
end

function sv_CR.StartRobing( person )
	local Registry = net.ReadEntity()
	local Person = net.ReadEntity()

	if Registry.IsBusy == true then return end
	if Person == Registry.dt.owning_ent then return end
	if Registry.StoredMoney <= 0 then return end

	Registry.IsBusy = true
	Registry.Rober = Person
	Registry.RobProgress = 0
	Registry.RobingCalled = CurTime()

	Registry:UpdateRobInfo()

	GAMEMODE:Notify( Registry.Rober, 2, 5, "You are now trying to steal money from cash registry. Remain in it's range")
end
net.Receive('NET_CR_StartRobing', sv_CR.StartRobing)