include("shared.lua")

local cl_SS = {}
cl_SS.VGUI = {}
cl_SS.VGUI.CartItems = {}

function ENT:Initialize()
	self.IsShoppingShelf = true
	self.Space = 4
	self.Items = {}
	for i=1, self.Space do
		self.Items[i] = {itemClass, itemMdl, itemDummy, itemPrice, itemVars, itemDtVars}
	end
end

function ENT:Draw()
	self:DrawModel()
end

function ENT:Think()
end

function cl_SS.ReceiveInfo()
	local Shelf = net.ReadEntity()
	Shelf.Items = net.ReadTable()
end
net.Receive('NET_SS_ItemsInfo', cl_SS.ReceiveInfo)

function cl_SS.MoveItem( receiver, droppedPanelsTbl, IsDropped )
	if not IsDropped then return end
	if droppedPanelsTbl[1]:GetParent() == receiver then return end
	if droppedPanelsTbl[1].ItemTbl.itemPrice <= 0 then return end
	if receiver.ListName == "CartList" then
		droppedPanelsTbl[1]:SetBackgroundColor( Color( 92, 204, 204, 255 )  )
		droppedPanelsTbl[1]:SetParent(receiver)

		cl_SS.VGUI.CartItems[droppedPanelsTbl[1].ItemNum] = droppedPanelsTbl[1].ItemTbl
		cl_SS.VGUI.CartCost = cl_SS.VGUI.CartCost + droppedPanelsTbl[1].ItemTbl.itemPrice

		cl_SS.VGUI.TotalCostLabel:SetText("Total: $"..cl_SS.VGUI.CartCost)
		cl_SS.VGUI.TotalCostLabel:SizeToContents()

		if tonumber(cl_SS.VGUI.CartCost) > tonumber(LocalPlayer().DarkRPVars.money) then
			cl_SS.VGUI.TotalCostLabel:SetColor(Color( 205, 0, 0, 255 ) )
		else
			cl_SS.VGUI.TotalCostLabel:SetColor(Color( 255, 255, 255, 255 ) )
		end
	end
	if receiver.ListName == "ItemList" then
		droppedPanelsTbl[1]:SetBackgroundColor( Color( 20, 210, 0, 255 ) )
		droppedPanelsTbl[1]:SetParent(receiver)

		cl_SS.VGUI.CartItems[droppedPanelsTbl[1].ItemNum] = nil
		cl_SS.VGUI.CartCost = cl_SS.VGUI.CartCost - droppedPanelsTbl[1].ItemTbl.itemPrice

		cl_SS.VGUI.TotalCostLabel:SetText("Total: $"..cl_SS.VGUI.CartCost)
		cl_SS.VGUI.TotalCostLabel:SizeToContents()

		if tonumber(cl_SS.VGUI.CartCost) > tonumber(LocalPlayer().DarkRPVars.money) then
			cl_SS.VGUI.TotalCostLabel:SetColor(Color( 205, 0, 0, 255 ) )
		else
			cl_SS.VGUI.TotalCostLabel:SetColor(Color( 255, 255, 255, 255 ) )
		end
	end
end

function cl_SS.OpenMenu()
	cl_SS.VGUI.CartItems = {}
	cl_SS.VGUI.CartCost = 0

	local Shelf = net.ReadEntity()
	Shelf.Items = net.ReadTable()

	cl_SS.VGUI.Menu = vgui.Create('DFrame')
	cl_SS.VGUI.Menu:SetSize( 400, 200 )
	cl_SS.VGUI.Menu:Center()
	cl_SS.VGUI.Menu:MakePopup()
	cl_SS.VGUI.Menu:SetTitle( '.:Shopping Menu' )
	cl_SS.VGUI.Menu.lblTitle:SetFont('DermaDefaultBold')
	cl_SS.VGUI.Menu.Paint = function()
		draw.RoundedBox( 6, 0, 0, cl_SS.VGUI.Menu:GetWide(), cl_SS.VGUI.Menu:GetTall(), Color(255, 190, 0, 255) )
		draw.RoundedBox( 6, 1, 1, cl_SS.VGUI.Menu:GetWide()-2, cl_SS.VGUI.Menu:GetTall()-2, Color(35, 35, 35, 255) )

		surface.SetDrawColor( Color( 92, 204, 204, 255 ) )
		surface.DrawOutlinedRect( 5, 50, 190, 125 )

		surface.SetDrawColor( Color( 20, 210, 0, 255 ) )
		surface.DrawOutlinedRect( 205, 50, 190, 125 )
	end

	local CartLabel = vgui.Create("DLabel", cl_SS.VGUI.Menu)
	CartLabel:SetFont("DermaLarge")
	CartLabel:SetText("Cart")
	CartLabel:SetPos( 5, 24 )
	CartLabel:SetColor( Color( 92, 204, 204, 255 ) )
	CartLabel:SizeToContents()

	local ShelfLabel = vgui.Create("DLabel", cl_SS.VGUI.Menu)
	ShelfLabel:SetFont("DermaLarge")
	ShelfLabel:SetText("Shelf")
	ShelfLabel:SetPos( 205, 24 )
	ShelfLabel:SetColor( Color( 20, 210, 0, 255 ) )
	ShelfLabel:SizeToContents()

	local LeftPanel = vgui.Create("DPanel", cl_SS.VGUI.Menu)
	LeftPanel:SetSize( 190, 17 )
	LeftPanel:SetPos( 5, 179 )
	LeftPanel:SetBackgroundColor( Color( 92, 204, 204, 255 ) )

	cl_SS.VGUI.TotalCostLabel = vgui.Create("DLabel", LeftPanel)
	cl_SS.VGUI.TotalCostLabel:SetFont("DermaDefaultBold")
	cl_SS.VGUI.TotalCostLabel:SetText("Total: $0")
	cl_SS.VGUI.TotalCostLabel:SetColor( Color(255, 255, 255, 255) )
	cl_SS.VGUI.TotalCostLabel:SetPos( 2, 1 )
	cl_SS.VGUI.TotalCostLabel:SizeToContents()

	local CheckoutButton = vgui.Create("DButton", LeftPanel)
	CheckoutButton:SetSize(60, 15)
	CheckoutButton:SetText( 'Check Out' )
	CheckoutButton:SetPos( 129, 1 )
	--if Shelf.dt.owning_ent == LocalPlayer() then
	--	CheckoutButton:SetEnabled(false)
	--end
	CheckoutButton.DoClick = function()
		if tonumber(LocalPlayer().DarkRPVars.money) >= tonumber(cl_SS.VGUI.CartCost) then
			if table.Count(cl_SS.VGUI.CartItems) > 0 then
				net.Start( 'NET_SS_DoBuyTakeoff' )
					net.WriteEntity(LocalPlayer())
					net.WriteEntity(Shelf)
					net.WriteTable(cl_SS.VGUI.CartItems)
					net.WriteInt(cl_SS.VGUI.CartCost, 16)
				net.SendToServer()
				cl_SS.VGUI.Menu:Remove()
			end
		end
	end

	local RightPanel = vgui.Create("DPanel", cl_SS.VGUI.Menu)
	RightPanel:SetSize( 190, 17 )
	RightPanel:SetPos( 205, 179 )
	RightPanel:SetBackgroundColor( Color( 20, 210, 0, 255 ) )

	cl_SS.VGUI.TotalPriceLabel = vgui.Create("DLabel", RightPanel)
	cl_SS.VGUI.TotalPriceLabel:SetFont("DermaDefaultBold")
	cl_SS.VGUI.TotalPriceLabel:SetText("Total: $0")
	cl_SS.VGUI.TotalPriceLabel:SetColor( Color(255, 255, 255, 255) )
	cl_SS.VGUI.TotalPriceLabel:SetPos( 2, 1 )
	cl_SS.VGUI.TotalPriceLabel:SizeToContents()

	local CartScrollPanel = vgui.Create( "DScrollPanel", cl_SS.VGUI.Menu )
	CartScrollPanel:SetSize( 190, 125 )
	CartScrollPanel:SetPos( 5, 50 )

	local CartList = vgui.Create( "DIconLayout", CartScrollPanel )
	CartList:SetSize( 190, 125 )
	CartList:SetPos( 0, 0 )
	CartList:SetSpaceY( 1 )
	CartList:SetSpaceX( 0 )

	CartList.ListName = "CartList"
	CartList:Receiver( "ShopItems", cl_SS.MoveItem )

	local ItemScrollPanel = vgui.Create( "DScrollPanel", cl_SS.VGUI.Menu )
	ItemScrollPanel:SetSize( 190, 125 )
	ItemScrollPanel:SetPos( 205, 50 )

	local ItemList = vgui.Create( "DIconLayout", ItemScrollPanel )
	ItemList:SetSize( 190, 125 )
	ItemList:SetPos( 0, 0 )
	ItemList:SetSpaceY( 1 )
	ItemList:SetSpaceX( 0 )

	ItemList.ListName = "ItemList"
	ItemList:Receiver( "ShopItems", cl_SS.MoveItem )

	local TotalPrice = 0
	for i, itemTbl in pairs (Shelf.Items) do
		if itemTbl.itemClass != nil then
			local itemPanel = vgui.Create("DPanel", ItemList)
			itemPanel:SetSize(190, 30)
			itemPanel:SetBackgroundColor( Color( 20, 210, 0, 255 ) )
			itemPanel:Droppable("ShopItems" )
			itemPanel.ItemNum = i
			itemPanel.ItemTbl = itemTbl

			local ItemIconBg = vgui.Create("DPanel", itemPanel)
			ItemIconBg:SetSize(28, 28)
			ItemIconBg:SetPos(1, 1)
			ItemIconBg:SetBackgroundColor( Color( 255, 255, 255, 255 ) )

			local ItemNameLabel = vgui.Create("DLabel", itemPanel)
			ItemNameLabel:SetFont("DermaDefaultBold")
			ItemNameLabel:SetText( sh_SS.Sellables[itemTbl.itemClass].itemName )
			ItemNameLabel:SetPos(105, 0)
			ItemNameLabel:SetColor( Color(255, 255, 255, 255) )
			ItemNameLabel:SizeToContents()

			local ItemPriceLabel = vgui.Create("DLabel", itemPanel)
			ItemPriceLabel:SetFont("DermaDefaultBold")
			ItemPriceLabel:SetText( "$"..itemTbl.itemPrice )
			ItemPriceLabel:SetPos(105, 15)
			ItemPriceLabel:SetColor( Color(255, 255, 255, 255) )
			ItemPriceLabel:SizeToContents()

			local ItemIcon = vgui.Create("DModelPanel", ItemIconBg)
			ItemIcon:SetSize( 28, 28 )
			ItemIcon:SetModel(itemTbl.itemMdl)
			ItemIcon:SetLookAt( sh_SS.Sellables[itemTbl.itemClass].iconLookAt )
			ItemIcon:SetCamPos( sh_SS.Sellables[itemTbl.itemClass].iconCamPos )

			if Shelf.dt.owning_ent == LocalPlayer() then
				local SetPriceButton = vgui.Create("DNumberWang", itemPanel)
				SetPriceButton:SetSize(60, 20)
				SetPriceButton:SetPos(35, 5)
				SetPriceButton:SetText('Price')
				SetPriceButton.OnEnter = function( self )
					if type(self:GetValue()) == "number" and self:GetValue() > 0 then
						ItemPriceLabel:SetText( "$"..self:GetValue() )
						ItemPriceLabel:SizeToContents()
						net.Start('NET_SS_DoSetPrice')
							net.WriteEntity(Shelf)
							net.WriteInt( i, 16 )
							net.WriteInt( self:GetValue(), 16 )
						net.SendToServer()
						TotalPrice = TotalPrice + ( self:GetValue() - itemTbl.itemPrice )
						cl_SS.VGUI.TotalPriceLabel:SetText('Total: $'..TotalPrice)
						cl_SS.VGUI.TotalPriceLabel:SizeToContents()
						cl_SS.VGUI.Menu:SetTitle("(New prices applied, re-open the menu!")
						cl_SS.VGUI.Menu.lblTitle:SetColor(Color(255,0,0,255))
					end
				end
			end

			TotalPrice = TotalPrice + itemTbl.itemPrice

			cl_SS.VGUI.TotalPriceLabel:SetText('Total: $'..TotalPrice)
			cl_SS.VGUI.TotalPriceLabel:SizeToContents()
		end
	end
end
net.Receive('NET_SS_OpenMenu', cl_SS.OpenMenu)

function cl_SS.DrawShelfInfo()
	if LocalPlayer():GetEyeTrace().Entity.IsShoppingShelf then
		local Shelf = LocalPlayer():GetEyeTrace().Entity

		local Dist = LocalPlayer():GetPos():Distance(Shelf:GetPos())
		if Dist < 300 then
			for i, itemTbl in pairs (Shelf.Items) do
				if itemTbl.itemClass != nil and itemTbl.itemDummy != nil and itemTbl.itemPrice > 0 then
					if itemTbl.itemDummy:IsValid() then
						local Pos = itemTbl.itemDummy:GetPos():ToScreen()
						draw.SimpleTextOutlined( "$"..itemTbl.itemPrice, "DermaDefaultBold", Pos.x, Pos.y, Color(255, 190, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255) )
					end
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "DrawShelfInfo", cl_SS.DrawShelfInfo )