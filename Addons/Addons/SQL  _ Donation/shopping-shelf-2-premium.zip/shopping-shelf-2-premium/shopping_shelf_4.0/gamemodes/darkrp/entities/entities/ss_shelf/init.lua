AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

util.AddNetworkString('NET_SS_ItemsInfo')
util.AddNetworkString('NET_SS_OpenMenu')
util.AddNetworkString('NET_SS_DoBuyTakeoff')
util.AddNetworkString('NET_SS_DoSetPrice')

local sv_SS = {}

function ENT:Initialize()
	self:SetModel("models/props_c17/shelfunit01a.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)

	local phys = self:GetPhysicsObject()
	phys:Wake()

	self.CashRegistry = nil
	self.IsShoppingShelf = true
	self.Space = 8
	self.Items = {}
	for i=1, self.Space do
		self.Items[i] = {itemClass, itemMdl, itemDummy, itemPrice, itemVars, itemDtVars}
	end

	self.ShelfPos = {}
	self.ShelfPos[1] = { Pos = Vector(17, 7, 4) }
	self.ShelfPos[2] = { Pos = Vector(-18, 5, 4) }
	self.ShelfPos[3] = { Pos = Vector(17, 7, 24) }
	self.ShelfPos[4] = { Pos = Vector(-18, 5, 24) }
	self.ShelfPos[5] = { Pos = Vector(17, 7, 43) }
	self.ShelfPos[6] = { Pos = Vector(-18, 5, 43) }
	self.ShelfPos[7] = { Pos = Vector(17, 7, 60.5) }
	self.ShelfPos[8] = { Pos = Vector(-18, 5, 60.5) }
end

function ENT:HasRegistry()
	local cr_ents = ents.FindByClass( 'ss_cash_registry' )
	for i, ent in pairs (cr_ents) do
		if ent.dt.owning_ent == self.dt.owning_ent then
			self.CashRegistry = ent
			break
		end
	end

	if not self.CashRegistry then
		self.CashRegistry = nil
	end

	if self.CashRegistry != nil then
		local filter = player.GetAll()
		table.insert(filter, self)
		local td = {}
		td.start = self:GetPos()+Vector(0,0,15)
		td.endpos = self.CashRegistry:GetPos()
		td.filter = filter

		local t = util.TraceLine(td)
		if t.Entity then
			if t.Entity != self.CashRegistry then
				self.CashRegistry = nil
				return false
			else
				return true
			end
		end
	else
		return false
	end
end

function ENT:Use( activator, caller )
	if sh_SS.Config.UseCashRegistry == true then
		if self:HasRegistry() == false then 
			GAMEMODE:Notify( caller, 2, 5, "A cash registry is required for shelf to work. It has to be visible for shelf")
			return
		end
	end

	net.Start('NET_SS_OpenMenu')
		net.WriteEntity( self )
		net.WriteTable( self.Items )
	net.Send( caller )
end

function ENT:StartTouch( ent )
	if sh_SS.Config.UseCashRegistry == true then
		if self:HasRegistry() == false then 
			GAMEMODE:Notify( caller, 2, 5, "A cash registry is required for shelf to work. It has to be visible for shelf")
			return
		end
	end

	local IsSellable = false

	for item, itemTbl in pairs (sh_SS.Sellables) do
		if ent:GetClass() == item then
			IsSellable = true
			break
		end
	end
	if IsSellable == true then
		for shelf, shelfTbl in pairs (self.Items) do
			if shelfTbl.itemClass == nil then
				self.Items[shelf] = {}
				self.Items[shelf].itemClass = ent:GetClass()
				self.Items[shelf].itemMdl 	= ent:GetModel()
				self.Items[shelf].itemPrice	= 0

				if sh_SS.Sellables[ent:GetClass()].vars then
					self.Items[shelf].itemVars = {}
					for num, var in pairs (sh_SS.Sellables[ent:GetClass()].vars) do
						self.Items[shelf].itemVars[var] = ent[var]
					end
				end

				if sh_SS.Sellables[ent:GetClass()].dtvars then
					self.Items[shelf].itemDtVars = {}
					for num, var in pairs (sh_SS.Sellables[ent:GetClass()].dtvars) do
						self.Items[shelf].itemDtVars[var] = ent.dt[var]
					end
				end

				self.Items[shelf].itemDummy = ents.Create('prop_physics')
				self.Items[shelf].itemDummy:SetModel(ent:GetModel())
				self.Items[shelf].itemDummy:SetPos( LocalToWorld( self.ShelfPos[shelf].Pos+sh_SS.Sellables[ent:GetClass()].itemShelfPos, Angle(0, 0, 0), self:GetPos(), self:GetAngles() ) )
				self.Items[shelf].itemDummy:SetAngles( self:GetAngles() + sh_SS.Sellables[ent:GetClass()].itemShelfAng)
				self.Items[shelf].itemDummy:Spawn()
				self.Items[shelf].itemDummy:SetParent( self )

				ent:Remove()

					net.Start('NET_SS_ItemsInfo')
						net.WriteEntity( self )
						net.WriteTable( self.Items )
					net.Broadcast()
				break
			end
		end
	end
end

function sv_SS.SetPrice()
	local Shelf = net.ReadEntity()
	local i = net.ReadInt(16)
	local Price = net.ReadInt(16)

	if i > 0 then
		Shelf.Items[i].itemPrice = Price
	end

	net.Start('NET_SS_ItemsInfo')
		net.WriteEntity( Shelf )
		net.WriteTable( Shelf.Items )
	net.Broadcast()
end
net.Receive('NET_SS_DoSetPrice', sv_SS.SetPrice)

function sv_SS.BuyTakeOff()
	local Buyer = net.ReadEntity()
	local Shelf = net.ReadEntity()
	local CartList = net.ReadTable()
	local CartCost = net.ReadInt(16)

	if CartCost > tonumber(Buyer.DarkRPVars.money) then 
		GAMEMODE:Notify( Buyer, 2, 3, "You can't afford these items!")
		return
	end

	Buyer:AddMoney(-CartCost)

	local Package = ents.Create('ss_package')
	Package:SetPos(LocalToWorld( Vector(0, 50, 25), Angle(0, 0, 0), Shelf:GetPos(), Shelf:GetAngles() ))
	Package:Spawn()
	Package.Items = CartList
	Package.dt.owning_ent = Buyer

	for i, itemTbl in pairs (CartList) do
		Shelf.Items[i].itemDummy:Remove()
		Shelf.Items[i] = {itemClass, itemMdl, itemDummy, itemPrice, itemVars, itemDtVars}
	end

	if sh_SS.Config.UseCashRegistry == true then
		Shelf.CashRegistry.StoredMoney = Shelf.CashRegistry.StoredMoney + CartCost
		Shelf.CashRegistry:UpdateStoredMoney()
	else
		Shelf.dt.owning_ent:AddMoney(CartCost)
		GAMEMODE:Notify( Shelf.dt.owning_ent, 2, 3, "You made $"..CartCost.." from your sales")
	end

	GAMEMODE:Notify( Buyer, 2, 3, "You have bought few items for $"..CartCost..", they all got packed")
end
net.Receive('NET_SS_DoBuyTakeoff', sv_SS.BuyTakeOff)