AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

local ss_P = {}

function ENT:Initialize()
	self:SetModel("models/props_junk/cardboard_box001a.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)

	local phys = self:GetPhysicsObject()
	phys:Wake()

	self.IsPackage = true
	self.Items = {}
end


function ENT:Use( activator, caller )
	if self.dt.owning_ent != caller then return end

	for i, tb in pairs (self.Items) do
		local Ent = ents.Create(tb.itemClass)
		Ent:SetModel(tb.itemMdl)
		Ent:SetPos(self:GetPos())
		Ent:Spawn()
		if tb.itemVars then
			for var, value in pairs (tb.itemVars) do
				Ent[var] = value
			end
		end
		if tb.itemDtVars then
			for var, value in pairs (tb.itemDtVars) do
				Ent.dt[var] = value
			end
		end
	end
	self:Remove()
end

function ss_P.AllowGrabs( player, ent )
	if ent.IsPackage == true then
		if player != ent.dt.owning_ent then
			return false
		else
			return true
		end
	end
end
hook.Add('GravGunPickupAllowed', 'AlolwGrabs', ss_P.AllowGrabs)

