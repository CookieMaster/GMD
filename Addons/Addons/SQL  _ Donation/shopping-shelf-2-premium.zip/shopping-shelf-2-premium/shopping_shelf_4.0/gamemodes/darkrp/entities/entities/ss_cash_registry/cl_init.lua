include("shared.lua")

local cl_CR = {}

function ENT:Initialize()
	self.IsCashRegistry = true
	self.StoredMoney = 0
	self.Rober = nil
	self.RobProgress = 0
end

function ENT:Draw()
	self:DrawModel()

	local Pos = self:GetPos()
	local Ang = self:GetAngles()

	Ang:RotateAroundAxis( Ang:Forward(), 90)
	Ang:RotateAroundAxis( Ang:Right(), 180)
	
	cam.Start3D2D(Pos + Ang:Up() * -5.5, Ang, 0.077)
		draw.RoundedBox(0, -119, -149, 180, 40, Color( 92, 204, 204, 255 ) )
		draw.WordBox(2, -119, -145, "$"..self.StoredMoney, "DermaLarge", Color( 92, 204, 204, 255 ) , Color(255,255,255,255))
	cam.End3D2D()
end

function cl_CR.ReceiveInfo()
	local CashRegistry = net.ReadEntity()
	CashRegistry.StoredMoney = net.ReadInt(16)
end
net.Receive("NET_SS_StoredMoney", cl_CR.ReceiveInfo)

function cl_CR.ReceiveRobingInfo()
	local CashRegistry = net.ReadEntity()
	CashRegistry.Rober = net.ReadEntity()
	CashRegistry.RobProgress = net.ReadInt(16)
end
net.Receive("NET_CR_RobInfo", cl_CR.ReceiveRobingInfo)

function cl_CR.DrawRegistryInfo()
	if LocalPlayer():GetEyeTrace().Entity.IsCashRegistry then
		local Registry = LocalPlayer():GetEyeTrace().Entity

		local Dist = LocalPlayer():GetPos():Distance(Registry:GetPos())
		local Pos = Registry:GetPos():ToScreen()
		if Dist < 300 then
			draw.SimpleTextOutlined( "Cash Registry (Use to Open Menu)", "DermaDefaultBold", Pos.x, Pos.y, Color(142, 235, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255) )
			draw.SimpleTextOutlined( "Owned by "..Registry.dt.owning_ent:Nick(), "DermaDefaultBold", Pos.x, Pos.y+15, Color(255, 190, 0, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255) )
			if Registry.Rober != nil then
				if Registry.Rober:IsValid() then
					draw.SimpleTextOutlined( "Being robbed by "..Registry.Rober:Nick().." ("..Registry.RobProgress.."%)", "DermaDefaultBold", Pos.x, Pos.y+30, Color(255, 50, 50, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 255) )
				end
			end
		end
	end
end
hook.Add( "HUDPaint", "DrawRegistryInfo", cl_CR.DrawRegistryInfo )

function cl_CR.OpenMenu()
	local Registry = net.ReadEntity()

	local Menu = vgui.Create("DFrame")
	Menu:SetSize(180, 82)
	Menu:Center()
	Menu:MakePopup()
	Menu:SetTitle('Cash Registry')
	Menu.lblTitle:SetColor(Color(255,190, 0,255))
	Menu.lblTitle:SetFont('DermaDefaultBold')
	Menu.Paint = function()
		draw.RoundedBox( 6, 0, 0, Menu:GetWide(), Menu:GetTall(), Color(255, 190, 0, 255) )
		draw.RoundedBox( 6, 1, 1, Menu:GetWide()-2, Menu:GetTall()-2, Color(35, 35, 35, 255) )
	end

	local RobButton = vgui.Create('DButton', Menu)
	RobButton:SetPos( 5, 24 )
	RobButton:SetSize( 170, 25 )
	RobButton:SetText('Start robbing')
	RobButton.DoClick = function()
		net.Start('NET_CR_StartRobing')
			net.WriteEntity( Registry )
			net.WriteEntity( LocalPlayer() )
		net.SendToServer()
		Menu:Close()
	end

	local TakeMoneyButton = vgui.Create('DButton', Menu)
	TakeMoneyButton:SetPos( 5, 51 )
	TakeMoneyButton:SetSize( 170, 25 )
	TakeMoneyButton:SetText('Take stored money')
	TakeMoneyButton.DoClick = function()
		net.Start('NET_CR_TakeStoredMoney')
			net.WriteEntity( Registry )
			net.WriteEntity( LocalPlayer() )
		net.SendToServer()
		Menu:Close()
	end

	if Registry.dt.owning_ent == LocalPlayer() then
		--RobButton:SetEnabled(false)
	else
		TakeMoneyButton:SetEnabled(false)
	end
end
net.Receive('NET_SS_CashRegOpenMenu', cl_CR.OpenMenu)
