
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")


local PrintMore
function ENT:Initialize()
	self:SetModel("models/props/CS_militia/footlocker01_open.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType( SIMPLE_USE )
	local phys = self:GetPhysicsObject()
	phys:Wake()
end

function ENT:AcceptInput(name, activator, caller, data)
	if name == "Use" and IsValid(caller) and caller:IsPlayer() then
	if ! IsValid(self.dt.owning_ent) then return false end
		if(caller == self.dt.owning_ent and self:Getmoneys() > 0) then
			caller:ChatPrint("You take what money is still inside it. ($" .. self:Getmoneys() .. ")")
			caller:AddMoney(self:Getmoneys())
			self:Setmoneys(0)
		elseif(caller != self.dt.owning_ent) then
			caller:ChatPrint("You can't take money from this as you do not own it!")
		elseif(caller == self.dt.owning_ent and self:Getmoneys() <= 0) then
			caller:ChatPrint("There is no money inside it!")
		end
	end
end

function ENT:Touch(ent)
	if ent:GetClass() ~= "spawned_money" or self.hasMerged or ent.hasMerged then return end
	ent.hasMerged = true
	ent:Remove()
	self:Setmoneys(self:Getmoneys() + ent:Getamount())
	if IsValid(self.dt.owning_ent) then 
		self.dt.owning_ent:SendLua(
		[[
		chat.AddText(Color(255,69,0, 255),"Someone has placed $]] .. ent:Getamount() .. [[ Inside your donation box.")
		surface.PlaySound("UI/buttonclick.wav")
		]])
	end
end



function ENT:Think()
end

local function PlayerPickup(ply, ent)
	if(ent:GetClass() == "donation_box") then
		if !(ply == ent.dt.owning_ent) then return end
		return true
	end
end
 
hook.Add("PhysgunPickup", "Donationboxpickup", PlayerPickup)

local function UseTool(pl, tr, toolmode)
	local ent = tr.Entity
	if toolmode == "remover" and IsValid(ent) and ent:GetClass() == "donation_box" then
		if (pl == ent.dt.owning_ent or pl:IsAdmin()) then return true end
		return false
	end
end
 
hook.Add("CanTool", "UseToolDonationbox", UseTool)