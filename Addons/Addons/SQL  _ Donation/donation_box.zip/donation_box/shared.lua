ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Donation Box"
ENT.Author = "TCWilliamson / Cathy"
ENT.Spawnable = false
ENT.AdminSpawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("Int",0,"price")
	self:NetworkVar("Entity",1,"owning_ent")
	self:NetworkVar( "Float", 0, "moneys" );
end