include("shared.lua")

function ENT:Initialize()
end

function ENT:Draw()
	self:DrawModel()

	local Pos = self:GetPos()
	local Ang = self:GetAngles()

	local owner = self:Getowning_ent()
	owner = (IsValid(owner) and owner:Nick()) or "unknown"
	owner = "Donate to: " .. owner
	
	surface.SetFont("HUDNumber5")
	local TextWidth = surface.GetTextSize(owner)
	local TextWidth2 = surface.GetTextSize("Donations: $" .. self:Getmoneys())

	Ang:RotateAroundAxis(Ang:Up(), 90)
	Ang:RotateAroundAxis(Ang:Forward(), 76.5)

	cam.Start3D2D(Pos + (Ang:Right() * -20) + (Ang:Up() * -14.51) , Ang, 0.11)
		draw.DrawText( owner, "HUDNumber5", 0, -30, Color(255,255,255,255), TEXT_ALIGN_CENTER )
		draw.DrawText( "Donations: $" .. self:Getmoneys(), "HUDNumber5", 0, 0, Color(255,255,255,255), TEXT_ALIGN_CENTER )
	cam.End3D2D()
end

function ENT:Think()
end
