Hello, and thankyou for purchaseing this product!
you can contact me at thomas.williamson@thegeekgroup.org!

To install, place the entity along with the other entities in "garrysmod\garrysmod\gamemodes\DarkRP\entities\entities"
Then, next please place one of these in the AddEntities.lua and the bottom of it.




// for all players to have access:
AddEntity("Donation Box", {
	ent = "donation_box",
	model = "models/props/CS_militia/footlocker01_open.mdl",
	price = 100,
	max = 2,
	cmd = "/buydonationbox"
}) 

// for hobos only:
AddEntity("Donation Box", {
	ent = "donation_box",
	model = "models/props/CS_militia/footlocker01_open.mdl",
	price = 100,
	max = 2,
	cmd = "/buydonationbox",
	allowed = {TEAM_HOBO}
}) 


Thank you!