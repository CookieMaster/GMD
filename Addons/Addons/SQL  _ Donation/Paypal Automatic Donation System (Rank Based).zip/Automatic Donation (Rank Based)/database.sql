CREATE TABLE IF NOT EXISTS `unclaimed` (
  `steamid` varchar(30) NOT NULL,
  `rank` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;