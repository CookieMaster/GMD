AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/Items/combine_rifle_ammo01.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)

	local phys = self:GetPhysicsObject()
	phys:Wake()

	self.Upgrade = {}
	self.Upgrade.Name = 'Tuner (D)'
	self.Upgrade.Desc = 'I traded these for magic beans.'

	self.UpgradeMods = {}
	self.UpgradeMods['ExpMul'] = 0.5
	self.UpgradeMods['PrintSpeed'] = 10
end

function ENT:StartTouch( ent )
	if not ent.IsNgPrinter == true then return end

	local EmptySlot = nil
	for slot, upgrTbl in pairs (ent.Stats.Upgrades) do
		if upgrTbl.uName == nil then
			EmptySlot = slot
			break
		end
	end

	if EmptySlot != nil then
		for stat, value in pairs (self.UpgradeMods) do
			ent.Stats[stat] = ent.Stats[stat] + value
		end
		ent.Stats.Upgrades[EmptySlot] = { uClass = self:GetClass(), uName = self.Upgrade.Name, uModel = self:GetModel(), uDescription = self.Upgrade.Desc, uMods = self.UpgradeMods }
		ent:UpdateInfo()
		self:Remove()
	end

end