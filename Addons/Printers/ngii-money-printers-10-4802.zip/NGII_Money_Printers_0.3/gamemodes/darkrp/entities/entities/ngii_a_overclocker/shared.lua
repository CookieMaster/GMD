ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "NGII Class A Overclocker"
ENT.Author = "Netheous"
ENT.Spawnable = false
ENT.AdminSpawnable = false