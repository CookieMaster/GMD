AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

util.AddNetworkString('NGII_PrinterUpdate')
util.AddNetworkString('NGII_OpenMenu')
util.AddNetworkString('NGII_TakeMoney')
util.AddNetworkString('NGII_UninstallMod')

function ENT:Initialize()
	self:SetModel("models/props_lab/reciever01a.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)

	local phys = self:GetPhysicsObject()
	phys:Wake()

	self.IsNgPrinter = true
	self.Damage = 100

	self.Stats = {}
	self.Stats['Level']			= 1
	self.Stats['Experience']	= 0
	self.Stats['Temperature']	= 0
	self.Stats['StoredMoney']	= 0
	self.Stats['Cooling'] 		= -10
	self.Stats['PrintMul']		= sh_NGII.ExpTable[1].PrintMul
	self.Stats['PrintSpeed']	= sh_NGII.PrintDelay
	self.Stats['UpgradeSlots']	= 4
	self.Stats['StorageSize']	= 600
	self.Stats['ExpMul']		= 1
	self.Stats['Upgrades'] = {}
	for i=1, self.Stats.UpgradeSlots do
		self.Stats.Upgrades[i] = { uName = nil, uModel = nil, uDescription = nil, uMods = {} }
	end

	self:InitTimer()
end

function ENT:OnTakeDamage( dmg )
	self.Damage = self.Damage - dmg:GetDamage()
	if self.Damage <= 0 then
		self:Burn()
	end
end

function ENT:Use( activator, caller )
	if not self.dt.owning_ent:IsValid() then
		self:Remove()
		return
	end

	self:UpdateInfo()
	net.Start('NGII_OpenMenu')
		net.WriteEntity( self )
	net.Send( caller )
end

function ENT:InitTimer()
	if self.Stats.PrintSpeed <= 0 then
		self.Stats.PrintSpeed = 1
	end

	timer.Simple( self.Stats.PrintSpeed, function()
		if not self:IsValid() then return end
		self:InitTimer()
	end )

	if self.Stats.StoredMoney >= self.Stats.StorageSize then
		self.Stats.StoredMoney = self.Stats.StorageSize
		return
	end

	if self.Stats.Temperature >= 100 then
		self.Stats.Temperature = 100
		return
	end

	self:Print()
end

function ENT:Print()
	self.Stats.StoredMoney = self.Stats.StoredMoney + sh_NGII.PrintAmount * self.Stats.PrintMul

	if self.Stats.Level != #sh_NGII.ExpTable then
		self.Stats.Experience = self.Stats.Experience + (sh_NGII.ExpAmount * self.Stats.ExpMul)
		if self.Stats.Experience >= sh_NGII.ExpTable[self.Stats.Level].ExpReq then
			self.Stats.Level = self.Stats.Level + 1
			self.Stats.Experience = 0
			self.Stats.PrintMul = sh_NGII.ExpTable[self.Stats.Level].PrintMul
		end
	end

	self.Stats.Temperature = self.Stats.Temperature + (sh_NGII.HeatAmount - self.Stats.Cooling)

	if self.Stats.Temperature >= 100 then
		self.Stats.Temperature = 100
		self:Burn()
	end

	if self.Stats.StoredMoney >= self.Stats.StorageSize then
		self.Stats.StoredMoney = self.Stats.StorageSize
	end

	if self.Stats.Temperature < 0 then
		self.Stats.Temperature = 0
	end

	self:UpdateInfo()
end

function ENT:Burn()
	self:UpdateInfo()

	self:Ignite( 10, 5 )
	timer.Simple( 10, function()
		if not self:IsValid() then return end
		self:Remove()
	end)
end

function ENT:UpdateInfo()
	net.Start('NGII_PrinterUpdate')
		net.WriteEntity( self )
		net.WriteTable( self.Stats )
	net.Broadcast()
end

net.Receive('NGII_TakeMoney', function( TblSize )
	local Printer = net.ReadEntity()
	local Person = net.ReadEntity()

	if Printer.Stats.StoredMoney <= 0 then return end
	
	GAMEMODE:Notify(Person, 0, 4, "You have taken the stored money. $"..Printer.Stats.StoredMoney)

	Person:AddMoney(Printer.Stats.StoredMoney)
	Printer.Stats.StoredMoney = 0

	Printer:UpdateInfo()
end)

net.Receive('NGII_UninstallMod', function( TblSize )
	local Printer = net.ReadEntity()
	local UpgradeID = net.ReadInt( 16 )

	if Printer.Stats.Upgrades[UpgradeID].uClass == nil then return end
	
	for stat, value in pairs (Printer.Stats.Upgrades[UpgradeID].uMods) do
		Printer.Stats[stat] = Printer.Stats[stat] - value
	end

	local Upgrade = ents.Create(Printer.Stats.Upgrades[UpgradeID].uClass)
	Upgrade:SetPos(LocalToWorld( Vector( 25, 0, 15 ), Angle( 0, 0, 0 ), Printer:GetPos(), Printer:GetAngles()))
	Upgrade:Spawn()

	Printer.Stats.Upgrades[UpgradeID] = { uName = nil, uModel = nil, uDescription = nil, uMods = {} }

	Printer:UpdateInfo()
end)

hook.Add('PlayerDisconnected', 'PrinterRemoval', function( ply )
	local D_Printers = ents.FindByClass( "ng_d_printer" )
	for i, p in pairs (D_Printers) do
		if p.dt.owning_ent == ply then
			p:Remove()
			print('Printer owned by '..ply:Nick()..' has been removed due to disconnecting')
		end
	end
end)