ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "NGII Class B Tuner"
ENT.Author = "Netheous"
ENT.Spawnable = false
ENT.AdminSpawnable = false