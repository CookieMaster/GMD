ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "NGII Class B Overclocker"
ENT.Author = "Netheous"
ENT.Spawnable = false
ENT.AdminSpawnable = false