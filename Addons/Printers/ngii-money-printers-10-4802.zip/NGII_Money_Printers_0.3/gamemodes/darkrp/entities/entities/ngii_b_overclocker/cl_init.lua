include("shared.lua")

function ENT:Initialize()
end

function ENT:Draw()
	self:DrawModel()

	local Pos = self:GetPos()
	local Dist = Pos:Distance(LocalPlayer():GetPos())
	local Ang = self:GetAngles()

	if Dist > 300 then return end

	Ang:RotateAroundAxis( Ang:Up(), 90)
	--Ang:RotateAroundAxis( Ang:Forward(), 90)
	
	cam.Start3D2D(Pos + Ang:Up() * 1.5, Ang, 0.1)
		--Background
		surface.SetDrawColor( 0, 0, 0, 225 )
		surface.DrawRect( -50, 25, 100, 25 )
		draw.SimpleTextOutlined( "Overclocker (B)", "DermaDefaultBold", 0, 35, Color( 170, 0, 165, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
	cam.End3D2D()
end

function ENT:Think()
end