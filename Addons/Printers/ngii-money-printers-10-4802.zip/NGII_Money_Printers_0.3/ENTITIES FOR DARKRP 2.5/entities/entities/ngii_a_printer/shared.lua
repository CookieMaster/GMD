ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "NGII Class A Printer"
ENT.Author = "Netheous"
ENT.Spawnable = false
ENT.AdminSpawnable = false

function ENT:SetupDataTables()
	self:DTVar("Entity", 1, "owning_ent")
end