include("shared.lua")

local cl_NGII = {}

function ENT:Initialize()
	self.Stats = {}
	self.Stats['Level']			= 1
	self.Stats['Experience']	= 0
	self.Stats['Temperature']	= 0
	self.Stats['StoredMoney']	= 0
	self.Stats['Cooling'] 		= -20
	self.Stats['PrintMul']		= sh_NGII.ExpTable[1].PrintMul
	self.Stats['PrintSpeed']	= sh_NGII.PrintDelay
	self.Stats['UpgradeSlots']	= 5
	self.Stats['StorageSize']	= 800
	self.Stats['ExpMul']		= 1
	self.Stats['Upgrades'] = {}
	for i=1, self.Stats.UpgradeSlots do
		self.Stats.Upgrades[i] = { uName = nil, uModel = nil, uDescription = nil, uMods = {} }
	end
end

function cl_NGII.UninstallUpgrades( Receiver, DroppedPanels, isDropped )
	if not isDropped then return end

	net.Start( 'NGII_UninstallMod' )
		net.WriteEntity( DroppedPanels[1].PrinterEnt )
		net.WriteInt( DroppedPanels[1].UpgradeId, 16 )
	net.SendToServer()

	cl_NGII.Menu:Remove()
end

function ENT:Draw()
	self:DrawModel()

	local Pos = self:GetPos()
	local Dist = Pos:Distance(LocalPlayer():GetPos())
	local Ang = self:GetAngles()

	if Dist > 200 then return end

	Ang:RotateAroundAxis( Ang:Up(), 90)
	
	cam.Start3D2D(Pos + Ang:Up() * 7.9, Ang, 0.1)
		--Background
		surface.SetDrawColor( 35, 35, 35, 255 )
		surface.DrawRect( -109, -109, 219, 188 )
		surface.SetDrawColor( sh_NGII.ExpTable[self.Stats.Level].Clr )
		surface.DrawRect( -104, -104, 209, 30 )
		surface.DrawOutlinedRect( -104, -104, 209, 178 )
		--Info
		draw.SimpleTextOutlined( "Printer Lv."..self.Stats.Level.."", "DermaLarge", 0, -88, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Exp: "..self.Stats.Experience.."/"..sh_NGII.ExpTable[self.Stats.Level].ExpReq, "DermaDefaultBold", -95, -55, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Storage: "..self.Stats.StoredMoney.."/"..self.Stats.StorageSize, "DermaDefaultBold", -95, -15, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
		draw.SimpleTextOutlined( "Temperature: "..self.Stats.Temperature.."/100", "DermaDefaultBold", -95, 25, Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 1, Color( 0, 0, 0, 255 ) )
		--Bars
		surface.DrawOutlinedRect( -95, -50, 190, 15 )
		if self.Stats.Level != #sh_NGII.ExpTable then
			surface.DrawRect( -95, -50, (self.Stats.Experience / sh_NGII.ExpTable[self.Stats.Level].ExpReq) * 190, 15 )
		end

		surface.DrawOutlinedRect( -95, -10, 190, 15 )
		surface.DrawRect( -95, -10, (self.Stats.StoredMoney / self.Stats.StorageSize) * 190, 15 )

		if self.Stats.Temperature >= 70 then
			surface.SetDrawColor( Color( 235, 0, 0, 255 ) )
		end
		surface.DrawOutlinedRect( -95, 30, 190, 15 )
		surface.DrawRect( -95, 30, (self.Stats.Temperature / 100) * 190, 15 )
	cam.End3D2D()
end

function ENT:Think()
end

net.Receive('NGII_PrinterUpdate', function( TblSize )
	local Printer = net.ReadEntity()
	Printer.Stats = net.ReadTable()
end)

local StatsList = {}
StatsList['Storage'] 		= 'StorageSize'
StatsList['Cooling'] 		= 'Cooling'
StatsList['Print Mul'] 		= 'PrintMul'
StatsList['Print Delay']	= 'PrintSpeed'
StatsList['Upgrade Slots']	= 'UpgradeSlots'
StatsList['Exp Mul'] 		= 'ExpMul'

function cl_NGII.OpenMenu()
	local Printer = net.ReadEntity()

	cl_NGII.Menu = vgui.Create('DFrame')
	cl_NGII.Menu:SetSize( 300, 200 )
	cl_NGII.Menu:Center()
	cl_NGII.Menu:MakePopup()
	cl_NGII.Menu.lblTitle:SetFont('DermaDefaultBold')
	cl_NGII.Menu.lblTitle:SetColor(Color( 255, 209, 0, 255))
	cl_NGII.Menu.lblTitle:SetText('Owned by: '..Printer.dt.owning_ent:Nick())
	cl_NGII.Menu.btnMinim:Hide()
	cl_NGII.Menu.btnMaxim:Hide()
	cl_NGII.Menu.Paint = function( self )
		draw.RoundedBox( 4, 0, 0, self:GetWide(), self:GetTall(), sh_NGII.ExpTable[Printer.Stats.Level].Clr )
		draw.RoundedBox( 4, 1, 1, self:GetWide()-2, self:GetTall()-2, Color( 30, 30, 30, 255 ) )
	end

	local ModelBgPanel = vgui.Create('DPanel', cl_NGII.Menu)
	ModelBgPanel:SetPos( 5, 25 )
	ModelBgPanel:SetSize( 190, 170 )
	ModelBgPanel.Paint = function( self )
		draw.RoundedBox( 4, 0, 0, self:GetWide(), self:GetTall(), sh_NGII.ExpTable[Printer.Stats.Level].Clr )
		draw.RoundedBox( 4, 1, 1, self:GetWide()-2, self:GetTall()-2, Color( 30, 30, 30, 255 ) )
	end

	local ModelPanel = vgui.Create('DModelPanel', ModelBgPanel)
	ModelPanel:SetSize( 190, 170 )
	ModelPanel:SetModel( Printer:GetModel() )
	ModelPanel:SetCamPos( Vector( 45, 0, 20 ) )
	ModelPanel:SetLookAt( Vector( 0, 0, 0 ) )

	local TrashBoxImage = vgui.Create('DButton', ModelPanel)
	TrashBoxImage:SetImage('icon16/box.png')
	TrashBoxImage:SetSize( 25, 20 )
	TrashBoxImage:SetPos( 163, 148 )
	TrashBoxImage:SetText('')
	TrashBoxImage:Receiver( 'NGII_Upgrades', cl_NGII.UninstallUpgrades)

	local TakeMoneyBtn = vgui.Create('DButton', ModelPanel)
	TakeMoneyBtn:SetImage('icon16/money.png')
	TakeMoneyBtn:SetSize( 25, 20 )
	TakeMoneyBtn:SetPos( 2, 148 )
	TakeMoneyBtn:SetText('')
	TakeMoneyBtn.DoClick = function()
		net.Start('NGII_TakeMoney')
			net.WriteEntity( Printer )
			net.WriteEntity( LocalPlayer() )
		net.SendToServer()

		cl_NGII.Menu:Remove()
	end

	local StatsPanel = vgui.Create('DPanel', cl_NGII.Menu)
	StatsPanel:SetPos( 200, 25 )
	StatsPanel:SetSize( 95, 95 )
	StatsPanel.Paint = function( self )
		draw.RoundedBox( 4, 0, 0, self:GetWide(), self:GetTall(), Color( 75, 75, 75, 255 ))
		draw.RoundedBox( 4, 1, 1, self:GetWide()-2, self:GetTall()-2, Color( 30, 30, 30, 255 ) )
	end

	local i = 0
	for statName, statVar in pairs (StatsList) do
		local StatLabel = vgui.Create('DLabel', StatsPanel)
		StatLabel:SetText(statName..": "..Printer.Stats[statVar])
		StatLabel:SizeToContents()
		StatLabel:SetPos( 5, 2 + (i * 15) )

		i = i + 1
	end

	local UpgradesPanel = vgui.Create('DPanel', cl_NGII.Menu)
	UpgradesPanel:SetPos( 200, 125 )
	UpgradesPanel:SetSize( 95, 70 )
	UpgradesPanel.Paint = function( self )
		draw.RoundedBox( 4, 0, 0, self:GetWide(), self:GetTall(), Color( 75, 75, 75, 255 ) )
		draw.RoundedBox( 4, 1, 1, self:GetWide()-2, self:GetTall()-2, Color( 30, 30, 30, 255 ) )
	end

	local UpgradesLbl = vgui.Create('DLabel', UpgradesPanel)
	UpgradesLbl:SetText('Upgrades:')
	UpgradesLbl:SetFont('DermaDefaultBold')
	UpgradesLbl:SizeToContents()
	UpgradesLbl:SetPos( 5, 2 )

	local x, y = 0, 0
	for i=1, Printer.Stats.UpgradeSlots do
		local UpPnl = vgui.Create('DPanel', UpgradesPanel)
		UpPnl:SetPos( 4+(x*22), 22+(y*22) )
		UpPnl:SetSize( 21.25, 21.25 )
		UpPnl.Paint = function( self )
			draw.RoundedBox( 4, 0, 0, self:GetWide(), self:GetTall(), Color( 75, 75, 75, 255 ) )
			draw.RoundedBox( 4, 1, 1, self:GetWide()-2, self:GetTall()-2, Color( 30, 30, 30, 255 ) )
		end
		x = x + 1
		if i == 4 then
			x = 0
			y = 1
		end
		if Printer.Stats.Upgrades[i].uName != nil then
			local ModsString = "Mods: "
			for k, v in pairs (Printer.Stats.Upgrades[i].uMods) do
				ModsString = ModsString.."\n"..k..": "..v
			end

			local ModelPanel = vgui.Create('DModelPanel', UpPnl)
			ModelPanel.UpgradeId = i
			ModelPanel.PrinterEnt = Printer
			ModelPanel:SetSize( 21.25, 21.25 )
			ModelPanel:SetModel( Printer.Stats.Upgrades[i].uModel )
			ModelPanel:SetCamPos( Vector( 7, 0, 15 ) )
			ModelPanel:SetLookAt( Vector( 0, 0, 0 ) )
			ModelPanel:SetTooltip('Name: '..Printer.Stats.Upgrades[i].uName.."\nDesc: "..Printer.Stats.Upgrades[i].uDescription.."\n\n"..ModsString.."\n\n(DnD: Drop upgrade on the box icon to uninstall)")
			ModelPanel:Droppable( 'NGII_Upgrades' )
		end

	end
end
net.Receive('NGII_OpenMenu', cl_NGII.OpenMenu)