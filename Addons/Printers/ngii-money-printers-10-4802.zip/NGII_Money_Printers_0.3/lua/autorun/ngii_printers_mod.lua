sh_NGII = {}

sh_NGII.PrintAmount 	= 25 -- Money stored per print | default: 25 (gives around 1500 per 10 min for a very good upgraded printer)
sh_NGII.HeatAmount  	= 10  -- Heat gained per print
sh_NGII.ExpAmount		= 25  -- Experience gained per print
sh_NGII.PrintDelay		= 60  -- time after which printing happens | default: 60

--Last lvl should have req exp set to 0, to make it look nicier
sh_NGII.ExpTable = {}
sh_NGII.ExpTable[1]	= {ExpReq = 250, PrintMul = 1.00, Clr = Color( 0, 205, 0, 255 )} 	-- Green
sh_NGII.ExpTable[2]	= {ExpReq = 500, PrintMul = 1.25, Clr = Color( 55, 180, 205, 255 )} -- Blue
sh_NGII.ExpTable[3]	= {ExpReq = 750, PrintMul = 1.50, Clr = Color( 255, 230, 0, 255 )} 	-- Yellow
sh_NGII.ExpTable[4]	= {ExpReq = 1000, PrintMul = 1.75, Clr = Color( 170, 0, 165, 255 )} -- Purple
sh_NGII.ExpTable[5]	= {ExpReq = 0, PrintMul = 2.25, Clr = Color( 190, 50, 50, 255 )} 	-- Red