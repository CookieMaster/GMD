ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Money Printer Cooler"
ENT.Author = "DarkE"
ENT.Spawnable = false
ENT.AdminSpawnable = false
