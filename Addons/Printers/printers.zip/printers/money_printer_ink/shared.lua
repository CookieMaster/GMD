ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Money Printer Ink"
ENT.Author = "DarkE"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.InkAmount = 100
