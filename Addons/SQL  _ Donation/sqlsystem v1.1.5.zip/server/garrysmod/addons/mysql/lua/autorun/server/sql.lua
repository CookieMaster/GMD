 -- MySql Connection LUA --
 -- Made by [HK]ben --
 --  17/07/2013 --

require("mysqloo")
 
local ULX_HOST = ""  --MYSQL IP
local ULX_PORT = 3306 
local ULX_USERNAME = "" -- MYSQL username
local ULX_PASSWORD = "" --MYSQL password 
local ULX_DATABASE = ""  -- MYSQL database 

local db = mysqloo.connect(ULX_HOST, ULX_USERNAME, ULX_PASSWORD, ULX_DATABASE, ULX_PORT)

function db:onConnected()
	MsgN('[MySQL] MySQL database Connected!')
end
 

function db.onConnectionFailed( db, err )
   MsgN('[MySQL] MySQL database Connection Failed: ' .. err)
	Msg(err)
 end
 
 db:connect()

function SQLPlayerOnline ( ply )
if db:status()  == mysqloo.DATABASE_CONNECTED then

--------------------------------------------------------------------------------------------
local  loadq = db:query("SELECT `name`,`rank`,`point`,`expired`, `newrank`  FROM `users` WHERE steamid = '" .. ply:SteamID() .. "'")

	function loadq:onSuccess ( data )
		if data[1] then
			ply.name = data[1]["name"]
			ply.rank = data[1]["rank"]
			ply.point = data[1]["point"]
        	ply.expired = data[1]["expired"]
        	ply.newrank = data[1]["newrank"]
	     	nowtime = tostring(os.date("%Y-%m/%d %X") )
			
			if nowtime >= ply.expired and ply.expired != "0000-00-00 00:00:00" and ply.newrank != "" then
			timer.Simple(15, function()   
			local  expired = db:query("UPDATE   `users` SET expired ='0000-00-00 00:00:00' , lastupdate='"..nowtime.."', rank ='"..ply.newrank.."'  WHERE steamid = '" .. ply:SteamID() .. "'")
					function expired:onSuccess( data2)
						Msg("[MySQL]  " ..ply:Nick().. "'s rank expired. \n")
						ULib.ucl.addUser( ply:SteamID(), _, _, ply.newrank)
						ply:PrintMessage(HUD_PRINTTALK, "Your "..ply.rank.." expired , changing to "..ply.newrank.." now!")
					end
						function expired:onError( Q, E )
							Msg( "[MySQL] ERROR!!! " .. Q .. "\n" )
							Msg( "[MySQL] ERROR!!! " .. E .. "\n" )
					end
				expired:start()
			end)
			
			elseif ply.rank != ply:GetUserGroup() then
			timer.Simple(15, function()   
			ULib.ucl.addUser( ply:SteamID(), _, _, ply.rank)
			ply:PrintMessage(HUD_PRINTTALK, "You added to "..ply.rank.." now !")
			end)
			end
			
			if ply.name != ply:Nick() then
				local  name = db:query("UPDATE   `users` SET name='"..ply:Nick().."' WHERE steamid = '" .. ply:SteamID() .. "'")
					function name:onSuccess( data3)
						Msg("[MySQL] Updated " ..ply:SteamID().. " 's nick name. \n")
					end
					function name:onError( Q, E )
					Msg( "[MySQL] ERROR!!! " .. Q .. "\n" )
					Msg( "[MySQL] ERROR!!! " .. E .. "\n" )
					end
				name:start()
				end
					
			if ply.point != 0 then
				local  pointq = db:query("UPDATE   `users` SET point='0'  WHERE steamid = '" .. ply:SteamID() .. "'")
					
					function pointq:onSuccess( data4)
						timer.Simple(15, function()   
							ply:PS_Notify("You were awarded "..ply.point.." points from Server.")
							ply:PS_GivePoints(ply.point)
							Msg("[MySQL] Given "..ply.point.." points to "..ply:Nick().." . \n")
						end)
					end
					function pointq:onError( Q, E )
					Msg( "[MySQL] ERROR!!! " .. Q .. "\n" )
					Msg( "[MySQL] ERROR!!! " .. E .. "\n" )
					end
					pointq:start()
				end	
			
			local timeq = db:query("UPDATE `users` SET lastplayed='"..tostring(os.date("%Y-%m/%d %X") ).. "'  WHERE steamid='" .. ply:SteamID() .. "'")
						function timeq:onSuccess( data5)
						Msg( "[MySQL] Updated " ..ply:Nick().. " lastplayed time .\n" )
						end
						function timeq:onError( Q, E )
						Msg( "[MySQL] ERROR!!! " .. Q .. "\n" )
						Msg( "[MySQL] ERROR!!! " .. E .. "\n" )
						end
					timeq:start()
			
				return
				end
			end
		
		function loadq:onError( Q, E )
 			Msg( "[MySQL] ERROR!!! " .. Q .. "\n" )
 			Msg( "[MySQL] ERROR!!! " .. E .. "\n" )
			end
			
			loadq:start()
			end
  end


function SQLUpdate ( a,b ) 
local SteamID = a
local rank = b

if ULib.ucl.users[ SteamID ] and ULib.ucl.users[ SteamID ].name then
name = ULib.ucl.users[ SteamID ].name
name2 = name
else
name = SteamID
name2 = ""
end


if db:status()  == mysqloo.DATABASE_CONNECTED then

local  loadq3 = db:query("SELECT `lastplayed`,`lastupdate`,`rank` FROM `users` WHERE steamid = '" ..SteamID.. "'")
function loadq3:onSuccess ( data )
		if data[1] then
		lastplayed = data[1]["lastplayed"]
		lastupdate = data[1]["lastupdate"]
		srank = data[1]["rank"]
		
	local updateq = db:query("UPDATE `users` SET lastupdate='"..lastplayed.. "' , rank='"..rank.."' WHERE steamid = '" ..SteamID.. "'")
			
	function updateq:onSuccess( data6)
	Msg( "[MySQL] Updated " ..name.. "'s rank to database . \n" )
	end
	
	function updateq:onError( Q, E )
    Msg( "[MySQL] ERROR!!! " .. Q .. "\n" )
 	Msg( "[MySQL] ERROR!!! " .. E .. "\n" )
	end
				
	updateq:start()
			return
		end
	end
					
	function loadq3:onError( q, err, sql )
	Msg("[MySQL] Error\n")
	end
			
	loadq3:start()

	nowtime = tostring(os.date("%Y-%m/%d %X") )
	
 	local  Insertq = db:query("INSERT INTO `users` (`steamid`,`name`, `rank` ,`regtime` , `lastupdate`) SELECT '"..SteamID.."','"..name2.."', '"..rank.."','"..nowtime.."' ,'"..nowtime.."'  FROM `users` WHERE not exists ( SELECT * FROM `users` WHERE steamid = '" ..SteamID.. "') LIMIT 1")
 	function Insertq:onSuccess( data )
 		Msg ("[MySQL] Added " ..name.. " in to database . \n")
 			end
					
 				function Insertq:onError( Q, E )
 			Msg( "[MySQL] ERROR!!! " .. Q .. "\n" )
 			Msg( "[MySQL] ERROR!!! " .. E .. "\n" )
 					end
					
 		Insertq:start()
		
		end
 	end

function SQLRemove (a) 
local SteamID = a
if db:status()  == mysqloo.DATABASE_CONNECTED then

 	local  deleteq = db:query("DELETE FROM  `users` WHERE steamid = '" ..SteamID.. "' ")
 	function deleteq:onSuccess( data )
 	Msg ("[MySQL] Delete " ..SteamID.. " in database . \n")
 	end
					
 	function deleteq:onError( Q, E )
	Msg( "[MySQL] ERROR!!! " .. Q .. "\n" )
	Msg( "[MySQL] ERROR!!! " .. E .. "\n" )	
	end
			
    deleteq:start()			
			
		end
end

hook.Add("PlayerInitialSpawn", "SQLPlayerOnline", SQLPlayerOnline)
hook.Add("ULXAdduser", "SQLUpdate", SQLUpdate)
hook.Add("ULXRemoveuser", "SQLRemove", SQLRemove)
 
 
 
 
 
