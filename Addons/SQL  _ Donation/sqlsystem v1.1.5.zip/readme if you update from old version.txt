You don't need to install the system once again.
Just Follow this.

---------------------------------------------------------Update from 1.1 ---------------------------------------------------------

Update Website and LUA
1.go to \web\admin
2.select all files except config.php
3.upload to your web files

4.go to server\garrysmod\addons\mysql\lua\autorun\server
6.open sql.lua with text editor
7.go to yours game server   garrysmod\addons\mysql\lua\autorun\server
8.open mysql.lua with text editor
7.Copy MYSQL IP , username , database , password  to the new one
8. place sql.lus to your server.
9. delete mysql.lua

sql.lus is the new onw
mysql.lua is old onne

10. go to server\garrysmod\addons\ulx\lua\ulx\modules\sh
11. cut user.lua and paste that one in garrysmod\addons\ulx\lua\ulx\modules\sh

---------------------------------------------------------Update from 1.0 ---------------------------------------------------------
Update SQL
1. Go to your database (Phpmyadmin)
2.click users and Structure on the toolbar
3.Add 1 column after expired
4.Column : newrank Type: TEXT
5. GO
6. Then go to SQL
7. copy and paste
UPDATE `users` SET `newrank`=`rank` WHERE `id`=`id`
this Sql to textarea
8. Go

Update Website and LUA
1.go to \web\admin
2.select all files except config.php
3.upload to your web files

4.go to server\garrysmod\addons\mysql\lua\autorun\server
6.open sql.lua with text editor
7.go to yours game server   garrysmod\addons\mysql\lua\autorun\server
8.open mysql.lua with text editor
7.Copy MYSQL IP , username , database , password  to the new one
8. place sql.lus to your server.
9. delete mysql.lua

sql.lus is the new onw
mysql.lua is old onne

10. go to server\garrysmod\addons\ulx\lua\ulx\modules\sh
11. cut user.lua and paste that one in garrysmod\addons\ulx\lua\ulx\modules\sh




