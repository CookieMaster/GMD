﻿
<?php 

$ip = " "; // MYSQL IP
$name = " "; // MYSQL username
$pw = " "; //MYSQL password 
$db = " "; // MYSQL database

$username = "test"; // Your login username
$password = "123456"; //Your login password

$rankname = array( "Member" , "Vip" , "Top Vip" , "Operator",  "Admin" , "Superadmin" );  //Rank name eg: ("Member" , "Vip" , "Top Vip" , "Operator",  "Admin" , "Superadmin")
$ulxrank =     array( "member" , "vip" , "topvip" , "operator",  "admin" , "superadmin" );  //ULX rank eg: ("Member" , "Vip" , "Top Vip" , "Operator",  "Admin" , "Superadmin")


?>