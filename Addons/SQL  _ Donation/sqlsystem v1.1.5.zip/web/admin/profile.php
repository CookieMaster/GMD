﻿ <!DOCTYPE html>
<?php session_start(); ?>
    <html>
    <head>
    <title>Profile - Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link href="css/datetimepicker.css" rel="stylesheet" media="screen">
	<link rel="shortcut icon" href="favicon.ico" type="image/png">
	<script  type="text/javascript" src="js/jquery-2.0.3.min.js"></script> 
	<script type="text/javascript" src="js/jqBootstrapValidation.js"></script>
	<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
    </head>		
	<body>
	<script>
  $(function () { $("input,select,textarea").not("[type=submit]").jqBootstrapValidation(); } );
</script>
	<div class="container">
<?php

include("config.php");
if($_SESSION['username'] != null and $_SESSION['username'] == $username )
{
?>
<h3>
<a href="index.php">Home</a>
<a href="list.php">List</a>
<a href="adduser.php">Add User</a>
<a href="point.php">Points</a>
<a href="logout.php">Logout</a></h3>
<br>
<h2>Profile</h2><br>

<?php
 $id = $_GET[id];

if ($id != null){

$con = mysql_connect($ip,$name,$pw);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

 mysql_query("SET NAMES 'utf8'");
mysql_select_db( $db, $con);

$player = mysql_query("SELECT steamid,name,rank,lastplayed,regtime,expired,point,lastupdate,newrank  FROM users WHERE  id='".$id."' ");


if(mysql_num_rows($player) > 0) {
while($ml = mysql_fetch_assoc($player) ) {
?>
<form action="action.php" method="post">
<input type="hidden" name="form" value="1">
ID <?php echo $id; ?><br><br>
<input type="hidden" name="id" value="<?php echo $id; ?>">
<label>Steamid</label>
<input type="text" name="steamid" value="<?php echo $ml['steamid']; ?>" pattern="^STEAM_[0-5]:[01]:\d+$" required>
<p class="help-block">Change it carefully!</p>
<label>Name</label>
<input type="text" name="name" value="<?php echo $ml['name']; ?>" >
<p class="help-block">If empty then it will update when player join server!</p>
<label>Rank</label>
<select name="rank">
<?php 
for($i = 0; $i < count($ulxrank); ++$i) {
?>
<option value="<?php echo $ulxrank[$i]; ?>"<?php if($ml['rank'] == $ulxrank[$i]){echo " selected";} ?> ><?php echo $rankname[$i]; ?></option>
<?php
}
?>

</select> <br><br>
Last Played <br><?php echo $ml['lastplayed'] ?><br><br>
Regtime <br><?php echo $ml['regtime'] ?><br><br>
Lastupdate <br><?php echo $ml['lastupdate'] ?><br><br>
 <label>Expiry Date</label>
<div class="input-append date form_datetime" data-date-format="yyyy-mm-dd hh:ii:ss">
<input  type="text" name="expired" value="<?php echo $ml['expired'] ?>" readonly>
<span class="add-on"><i class="icon-remove"></i></span>
<span class="add-on"><i class="icon-th"></i></span>
</div>

<script type="text/javascript">
    $(".form_datetime").datetimepicker({
    format: "yyyy-mm-dd hh:ii:ss",
    autoclose: true,
    todayBtn: true,
	todayHighlight: true,
	startDate : "2013-08-01 00:00:00",
    pickerPosition: "bottom-left"
    });
</script>

<p class="help-block">If empty = "0000-00-00 00:00:00"</p>
<br>

 <label>Rank after expired</label>
 <select name="newrank">
<?php 
for($i = 0; $i < count($ulxrank); ++$i) {
?>
<option value="<?php echo $ulxrank[$i]; ?>"<?php if($ml['newrank'] == $ulxrank[$i]){echo " selected";} ?> ><?php echo $rankname[$i]; ?></option>
<?php
}
?>
</select> 
<p class="help-block">Ignore if no expired</p>
<br>

 <label>Points</label>
<input type="number" name="point" value="<?php echo $ml['point'] ?>" min="0">
<p class="help-block">How many points he/she will get when he join the server next time!  Max 32767</p><br>

<button type="submit" class="btn btn-success">Submit</button> <button type="reset"  class="btn btn-danger">Reset</button>
</form> 

<?php
}} else {
?>
Invalid ID!
<br><br>
<a href="list.php" class="btn btn-info">Back</a>

<?php
}
}
else
{
?>
Please select the player first!
<br><br>
<a href="list.php" class="btn btn-info">Back</a>  
<?php
}
mysql_close($con);
}
else
{
?>
<h3><a href="index.php">Home</a></h3>
<br>
<div class="alert alert-error">
  <strong>Please login in first!</strong></div>
<br>
<a href="index.php" class="btn btn-info">Go to Login</a> 
	<?php 	
}
?>

<br><br><br>
      <footer>
	  <hr><p>@2013 Play Forward - <?php echo date("Y-m-d H:i:s");?> </p>
      </footer>
    </div>
</body>
</html>