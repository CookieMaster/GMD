﻿ <!DOCTYPE html>
<?php session_start(); ?>
    <html>
    <head>
    <title>List - Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link rel="shortcut icon" href="favicon.ico" type="image/png">
    </head>		
	<body>
	<div class="container">
<?php

include("config.php");
if($_SESSION['username'] != null and $_SESSION['username'] == $username )
{
?>
<h3>
<a href="index.php">Home</a>
<a href="list.php">List</a>
<a href="adduser.php">Add User</a>
<a href="point.php">Points</a>
<a href="logout.php">Logout</a></h3>
<br>
<h2>List </h2><br>

<div class="row">
<div class="span8">
<a class="btn" href="list.php">All</a>
<?php 
for($i = 0; $i < count($ulxrank); ++$i) {
?>
 <a class="<?php if($i% 3 == '0'){ echo "btn btn-warning";}elseif($i% 2== '0'){ echo "btn btn-success";}else{ echo  "btn btn-danger";} ?>" href="list.php?rank=<?php echo $ulxrank[$i]; ?>"><?php echo $rankname[$i]; ?></a>
 <?php
}

?>
</div>
    <form class="form-search" action="list.php" method="get">
    <input type="text" name="search" class="input-medium search-query" placeholder="Name or Steamid">
    <button type="submit" class="btn">Search</button>
    </form>
	</div>
<br>
<?php

$rank = $_GET[rank];
$sort = $_GET[sort];
$search = $_GET[search];
$page = $_GET[page];

if(!isset($page)){
    $page=1; 
}

$con = mysql_connect($ip,$name,$pw);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

 mysql_query("SET NAMES 'utf8'");
mysql_select_db( $db, $con);

if($search !=null){
$sql = ("SELECT id,steamid,name,rank,lastplayed,expired  FROM users WHERE name like '".$search."' or steamid = '".$search."'");
$list = mysql_query($sql);
}else{
if($rank == null){ 
$filter = " rank";
}else {
$filter = " '".$rank."' ";
}



if($sort == null){ 
$sort = " id ";
}elseif($sort == "id"){ 
$sort = " id";
}elseif($sort == "name"){ 
$sort = " name";
}elseif($sort == "lastplayed"){ 
$sort = " lastplayed desc";
}elseif($sort == "expired"){ 
$sort = " expired  desc";
}else {
$sort = " id ";
}

$sqlpart = ("FROM users WHERE rank= ".$filter." ORDER BY ".$sort."");
$count = mysql_query("SELECT count(*) ".$sqlpart."");
$result = mysql_fetch_row($count); 
$pages = ceil($result[0]/15);
$startfrom = ($page-1)*15;

$sql = ("SELECT id,steamid,name,rank,lastplayed,expired ".$sqlpart." LIMIT ". $startfrom ." , 15 "); 
$list = mysql_query($sql);

}

if ($filter == " rank"){
$url = "list.php?sort=";
}else{
$url = "list.php?rank=".$rank."&sort=";
}

if($search !=null){
if(mysql_num_rows($list) == 0) {
?>
<div class="alert alert-error">
  <strong>No user found! Please check the name or use the full name to search! </strong></div>
<?php
}}

?>
<table class="table table-striped">
<tr><th><a href="<?php echo $url ?>id">#</a></th>
<th>Steamid</th>
<th><a href="<?php echo $url ?>name">Name</a></th>
<th>Rank</th>
<th><a href="<?php echo $url ?>lastplayed">lastplayed</a></th>
<th><a href="<?php echo $url ?>expired">expired</a></th><th></th></tr>
<?php
while($ml = mysql_fetch_assoc($list) ) {
?>
<tr><td><?php echo $ml['id'] ?></td>
<td><?php echo $ml['steamid'] ?></td>
<td><?php echo $ml['name'] ?></td>
<td><?php echo $ml['rank'] ?></td>
<td><?php echo $ml['lastplayed'] ?></td>
<td><?php echo $ml['expired'] ?></td>
<td><a href="profile.php?id=<?php echo $ml['id'] ?>">View</a></td>
</tr>
<?php
}
?>
</table>
<?php
if ($filter == " rank"and $sort == " id ") {
$url2 = "list.php?page=";
}elseif($sort == " id "){
$url2 = "list.php?rank=".$rank."&page=";
}elseif($filter == " rank"){
$url2 = "list.php?sort=".$_GET[sort]."&page=";
}else{
$url2 = "list.php?rank=".$rank."&sort=".$_GET[sort]."&page=";
}
?>
<div class="pagination pagination-centered">
<ul>
<?php
for($i=1;$i<=$pages;$i++) {
?>
 <li class="<?php if($page == $i){ echo "disabled";} ?>"><a href="<?php echo $url2; echo $i; ?>"><?php echo $i; ?></a></li>
<?php
}
echo " </ul></div>";
mysql_close($con);
}else{
?>
<h3><a href="index.php">Home</a></h3>
<br><br>
<div class="alert alert-error">
  <strong>Please login in first!</strong></div>
<br>
<a href="index.php" class="btn btn-info">Go to Login</a> 

	<?php 	
}
?>
<br><br><br>
      <footer>
	  <hr><p>@2013 Play Forward - <?php echo date("Y-m-d H:i:s");?> </p> 
      </footer>
    </div>
	
</body>
</html>