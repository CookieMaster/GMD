﻿ <!DOCTYPE html>
<?php session_start(); ?>
    <html>
    <head>
    <title>Index - Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link rel="shortcut icon" href="favicon.ico" type="image/png">
    </head>		
	<body>
	
	<div class="container">
	
<?php

include("config.php");
if($_SESSION['username'] != null and $_SESSION['username'] == $username )
{
?>
<h3>
<a href="index.php">Home</a>
<a href="list.php">List</a>
<a href="adduser.php">Add User</a>
<a href="point.php">Points</a>
<a href="logout.php">Logout</a></h3>
<br>
<h2>Home</h2><br>

<div class="row">
<div class="span4">
<div class="alert alert-success">
 <strong>Welcome back , <?php echo $_SESSION['username'] ;?> !</strong></div>
</div>
</div>
<?php
$con = mysql_connect($ip,$name,$pw);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_query("SET NAMES 'utf8'");
mysql_select_db( $db, $con);

?>

<div class="row">
<div class="span5">
<h3>Statistics </h3><br>
<div class="row">
<?php
for($i = 0; $i < count($ulxrank); ++$i) {
$rank = $ulxrank[$i];
$count = mysql_query("SELECT count(*) FROM users where rank='".$rank."'");
$number = mysql_fetch_row($count); 
?>

<div class="span1">
<h4><?php echo $rankname[$i]; ?></h4><h3><?php echo $number[0]; ?></h3> 
</div>

 <?php
}
echo "</div>";
echo "<br>";
$count = mysql_query("SELECT count(*) FROM users");
$number = mysql_fetch_row($count); 
echo "<h4>Total</h4>";
echo "<h3>".$number[0]."</h3><br><br>";

$join = mysql_query("SELECT count(*) FROM users WHERE lastplayed >= '".date("Y-m-d "). "00:00:00' ");
$result = mysql_fetch_row($join);
echo "<h4>Registered Players who had joined today</h4>";
echo "<h3>".$result[0]."</h3>";

?>
</div><div class="span6">
<h3>Lastplayed</h3><br>
<table class="table table-striped">
<tr>
<th>Name</th>
<th>Lastplayed</th></tr>
<?php
$lastplay = mysql_query("SELECT name , lastplayed FROM users ORDER BY lastplayed desc LIMIT 10");
while($ml = mysql_fetch_assoc($lastplay) ) {
?>
<tr><td><?php echo $ml['name'] ?></td>
<td><?php echo $ml['lastplayed'] ?></td></tr>

<?php
}
echo "</table></div></div>";
mysql_close($con);
}
else
{
?>

<h3><a href="index.php">Home</a></h3>
    <form class="form-horizontal" action="login.php" method="post">
	<fieldset>
	 <legend>Login</legend>
    <div class="control-group">
    <label class="control-label">Username</label>
    <div class="controls">
    <input type="text" name="username" placeholder="Username">
    </div>
    </div>
    <div class="control-group">
    <label class="control-label">Password</label>
    <div class="controls">
    <input type="password" name="password" placeholder="Password">
    </div>
    </div>
    <div class="control-group">
    <div class="controls">
    <button type="submit" class="btn btn-success">Login</button>
    </div>
    </div>
	</fieldset>
    </form>
	
	<?php 	
}
?>

<?php

 ?>
<br><br><br>
      <footer>
	  <hr><p>@2013 Play Forward - <?php echo date("Y-m-d H:i:s");?> </p>
      </footer>
    </div>

</div>
</body>
</html>