﻿ <!DOCTYPE html>
<?php session_start(); ?>
    <html>
    <head>
    <title>Give Points - Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link rel="shortcut icon" href="favicon.ico" type="image/png">
	<script  type="text/javascript" src="js/jquery-2.0.3.min.js"></script> 
	<script type="text/javascript" src="js/jqBootstrapValidation.js"></script>
    </head>		
	<body>
	<script>
  $(function () { $("input,select,textarea").not("[type=submit]").jqBootstrapValidation(); } );
</script>
	<div class="container">
<?php

include("config.php");
if($_SESSION['username'] != null and $_SESSION['username'] == $username )
{
?>
<h3>
<a href="index.php">Home</a>
<a href="list.php">List</a>
<a href="adduser.php">Add User</a>
<a href="point.php">Points</a>
<a href="logout.php">Logout</a></h3>
<br>
<h2>Points</h2><br>


<form action="action.php" method="post" >
<input type="hidden" name="form" value="3">
<label>Taget</label>
<select name="target" >
  <option value="all" >All</option>
  <?php 

for($i = 0; $i < count($ulxrank); ++$i) {
?>
<option value="<?php echo $ulxrank[$i]; ?>"><?php echo $rankname[$i]; ?></option>

<?php
}
?>
  
</select> <br><br>
<label>Point</label>
<input type="number" name="point" min="0" max="10000">
<p class="help-block">Max 10000</p>
<br>
<button type="submit" class="btn btn-success">Submit</button> <button type="reset"  class="btn btn-danger">Reset</button>
</form> 



<?php

}
else
{
?>
<h3><a href="index.php">Home</a></h3>
<br><br>
<div class="alert alert-error">
  <strong>Please login in first!</strong></div>
<br>
<a href="index.php" class="btn btn-info">Go to Login</a> 	
	<?php 	
}
?>
<br><br><br>
      <footer>
	  <hr><p>@2013 Play Forward - <?php echo date("Y-m-d H:i:s");?> </p>
      </footer>
    </div>
</body>
</html>