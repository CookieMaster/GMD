﻿ <!DOCTYPE html>
<?php session_start(); ?>
    <html>
    <head>
    <title>Logout - Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link rel="shortcut icon" href="favicon.ico" type="image/png">
    </head>		
	<body>
	<div class="container">
<?php
session_start(); 
       session_unset();
       session_destroy();
?>
<h3><a href="index.php">Home</a></h3>
<fieldset>
	 <legend>Logout</legend>
<div class="alert alert-success">
  <strong>Logout succeeded!</strong></div>
<br>
<a href="index.php" class="btn btn-info">Back</a>  
 </fieldset>

<br><br><br>
      <footer>
	  <hr><p>@2013 Play Forward - <?php echo date("Y-m-d H:i:s");?> </p>
      </footer>
    </div>
</div>
</body>
</html>