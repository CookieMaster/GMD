﻿ <!DOCTYPE html>
<?php session_start(); ?>
    <html>
    <head>
    <title>Login - Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link rel="shortcut icon" href="favicon.ico" type="image/png">
    </head>		
	<body>
	<div class="container">
<?php
 include("config.php");
$inputname = $_POST[username];  
$inputpw = $_POST[password];  

if ($inputname != $username) {
?>
<h3><a href="index.php">Home</a></h3>
<fieldset>
	 <legend>Login</legend>
<div class="alert alert-error">
  <strong>Login Failed!</strong> Wrong Username!</div>
<br>
<a href="index.php" class="btn  btn-info">Back</a>  
 </fieldset>
<?php
}elseif ($inputpw != $password){
?>
<h3><a href="index.php">Home</a></h3>
<fieldset>
	 <legend>Login</legend>
<div class="alert alert-error">
  <strong>Login Failed!</strong> Wrong Password!</div>
<br>
<a href="index.php" class="btn btn-info">Back</a>  
 </fieldset>
<?php
}
if ($inputname == $username and $inputpw == $password) {
?>
<h3>
<a href="index.php">Home</a>
<a href="list.php">List</a>
<a href="adduser.php">Add User</a>
<a href="point.php">Points</a>
<a href="logout.php">Logout</a></h3>
<fieldset>
	 <legend>Login</legend>
<div class="alert alert-success">
 <strong>Login succeeded!</strong></div>
 <a href="index.php" class="btn btn-info">Go to Work</a>  
 </fieldset>
<?php
$_SESSION['username'] = $username ;
}
?>
<br><br><br>
      <footer>
	  <hr><p>@2013 Play Forward - <?php echo date("Y-m-d H:i:s");?> </p>
      </footer>
    </div>
	
</div>
</body>
</html>
