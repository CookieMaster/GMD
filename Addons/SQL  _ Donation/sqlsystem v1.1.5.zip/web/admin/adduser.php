﻿ <!DOCTYPE html>
<?php session_start(); ?>
    <html>
    <head>
    <title>Add User - Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
	  <link href="css/datetimepicker.css" rel="stylesheet" media="screen">
	<link rel="shortcut icon" href="favicon.ico" type="image/png">
	<script  type="text/javascript" src="js/jquery-2.0.3.min.js"></script> 
	<script type="text/javascript" src="js/jqBootstrapValidation.js"></script>
	<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
    </head>		
	<body>
	<script>
  $(function () { $("input,select,textarea").not("[type=submit]").jqBootstrapValidation(); } );
</script>
	<div class="container">
<?php

include("config.php");
if($_SESSION['username'] != null and $_SESSION['username'] == $username )
{
?>
<h3>
<a href="index.php">Home</a>
<a href="list.php">List</a>
<a href="adduser.php">Add User</a>
<a href="point.php">Points</a>
<a href="logout.php">Logout</a></h3>
<br>
<h2>Add User</h2><br>

<form class="form-horizontal" action="action.php" method="post">
<input type="hidden" name="form" value="2">
<label>Steamid</label>
<input type="text" name="steamid" pattern="^STEAM_[0-5]:[01]:\d+$" value="STEAM_" required>
<p class="help-block"><a href="http://steamidfinder.com/">SteamID Finder</a>   Pattern 'STEAM_x:x:xxxxxxxx'</p>
<br>
<label>Name</label>
<input type="text" name="gname"> (Optional)<br><br>
<label>Rank</label>
<select name="rank">
<?php 

for($i = 0; $i < count($ulxrank); ++$i) {
?>
<option value="<?php echo $ulxrank[$i]; ?>"><?php echo $rankname[$i]; ?></option>

<?php
}
?>

<!---<option value="member">Member</option>
  <option value="vip" >Vip</option>
  <option value="topvip" >Top Vip</option>
  <option value="operator" >Operator</option>
  <option value="admin">Admin</option>
  <option value="superadmin"> Superadmin</option>--->
  
</select> <br><br>

<label>Expiry Date</label>
<div class="input-append date form_datetime" data-date-format="yyyy-mm-dd hh:ii:ss">
<input  type="text" name="expired" value="0000-00-00 00:00:00" readonly>
<span class="add-on"><i class="icon-remove"></i></span>
<span class="add-on"><i class="icon-th"></i></span>
</div> 
<p class="help-block">"0000-00-00 00:00:00" or empty = no expired</p>
<br><br>
<script type="text/javascript">
    $(".form_datetime").datetimepicker({
    format: "yyyy-mm-dd hh:ii:ss",
    autoclose: true,
    todayBtn: true,
	todayHighlight: true,
	startDate : "2013-08-01 00:00:00",
    pickerPosition: "bottom-left"
    });
</script>

 <label>Rank after expired</label>
 <select name="newrank">
<?php 

for($i = 0; $i < count($ulxrank); ++$i) {
?>
<option value="<?php echo $ulxrank[$i]; ?>"><?php echo $rankname[$i]; ?></option>

<?php
}
?>
</select>
<p class="help-block">Ignore if no expired</p>

<br>
<button type="submit" class="btn btn-success">Submit</button> <button type="reset"  class="btn btn-danger">Reset</button>
</form> 


<?php

}
else
{
?>
<h3><a href="index.php">Home</a></h3>
<br><br>
<div class="alert alert-error">
  <strong>Please login in first!</strong></div>
<br>
<a href="index.php" class="btn btn-info">Go to Login</a> 
	<?php 	
}
?>
<br><br><br>
      <footer>
	  <hr><p>@2013 Play Forward - <?php echo date("Y-m-d H:i:s");?> </p>
      </footer>
    </div>
</body>
</html>