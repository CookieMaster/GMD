﻿ <!DOCTYPE html>
<?php session_start(); ?>
    <html>
    <head>
    <title>Action - Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link rel="shortcut icon" href="favicon.ico" type="image/png">
    </head>		
	<body>
	<div class="container">
<?php

include("config.php");
if($_SESSION['username'] != null and $_SESSION['username'] == $username )
{
?>
<h3>
<a href="index.php">Home</a>
<a href="list.php">List</a>
<a href="adduser.php">Add User</a>
<a href="point.php">Points</a>
<a href="logout.php">Logout</a></h3>
<br>

<?php

$con = mysql_connect($ip,$name,$pw);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

 mysql_query("SET NAMES 'utf8'");
mysql_select_db( $db, $con);

 $form = $_POST[form];
 
 if($form == 1){
echo "<h2>Action - Edit Profile</h2><br>";


$id = $_POST[id];
$steamid = $_POST[steamid];
$gname = $_POST[name];
$rank = $_POST[rank];
$expired = $_POST[expired];
$point = $_POST[point];
$newrank = $_POST[newrank];

if($expired == null){
$expired = "0000-00-00 00:00:00";
}

if($expired == "0000-00-00 00:00:00"){
$newrank = $rank;
}


if($point < 0){
echo "<h4>Please enter a positive point value or 0 ! </h4>  ";
}else{


$update = ("UPDATE users SET steamid ='".$steamid."'  , name = '".$gname."', rank = '".$rank."', expired ='".$expired."', newrank = '".$newrank."', point = '".$point."', lastupdate = '".date("Y-m-d H:i:s")."' WHERE id = '".$id."' ");

if(mysql_query($update)){
    ?>
	<h3>ID <?php echo $id; ?> updated ! </h3>  <br>
	<h4>
Steamid : <?php echo $steamid; ?><br><br>
Name : <?php echo $gname; ?><br><br>
Rank : <?php echo $rank; ?><br><br>
Expired : <?php echo $expired; ?><br><br>
Rank after expired : <?php echo $newrank; ?><br><br>
Point : <?php echo $point; ?><br><br></h4>

	<?php
} else {
    echo "Error:".mysql_error();
}}
?>
<br>
<a href="list.php" class="btn btn-info">Back</a> 
	<?php 	


}elseif ($form == 2){
echo "<h2>Action - Add User</h2><br>";
$steamid = $_POST[steamid];
$gname = $_POST[name];
$rank = $_POST[rank];
$expired = $_POST[expired];
$newrank = $_POST[newrank];

if($expired == null){
$expired = "0000-00-00 00:00:00";
}

if($expired == "0000-00-00 00:00:00"){
$newrank = $rank;
}

$check = mysql_query("SELECT steamid FROM users WHERE  steamid = '".$steamid."'");

if(mysql_num_rows($check) == 0) {

$adduser = ("INSERT INTO users (steamid,name,rank,regtime,expired,newrank) VALUES ('".$steamid."','".$gname."','".$rank."','".date("Y-m-d H:i:s")."','".$expired."','".$newrank."')");

 if(mysql_query($adduser)){
 ?>
<h3>Added <?php echo $steamid; ?> to database ! </h3>  <br><br>
<h4>
Steamid : <?php echo $steamid; ?><br><br>
Name : <?php echo $gname; ?><br><br>
Rank : <?php echo $rank; ?><br><br>
Expired : <?php echo $expired; ?><br><br>
Rank after expired : <?php echo $newrank; ?><br><br></h4>
<br><br>
<?php
}else {
  echo "Error:".mysql_error();
}

}else{
?>
<h4>Sorry, Steamid exists!</h4>
<br><br>
<?php
}
?>
<br>
<a href="adduser.php" class="btn btn-info">Back</a> 
	<?php 	


}elseif ($form == 3){
 echo "<h2>Action - Give Points</h2><br>";
 
$target = $_POST[target];
$point = $_POST[point];

if($point <= 0){
echo "<h4>Please enter a positive value! </h4>  ";
}else{

if($target  == "all"){
$starget = "rank";
}else{
 $starget = "'".$target ."'";
 }
 
 $sql= ("UPDATE users SET point = point + ".$point." where rank = ".$starget."");
 
 if(mysql_query($sql)){
  if ($target == "all"){
   ?>
<h4>Given all registered players <?php echo $point; ?> points! </h4>  
<br><br>
<?php
}else{
for($i = 0; $i < count($ulxrank); ++$i) {
if($ulxrank[$i] == $target){
?>
<h4>Given All <?php echo $rankname[$i]; ?>  <?php echo $point; ?> points! </h4>  
<br><br>
<?php
}}}
}else {
  echo "Error:".mysql_error();
}}
 ?>
<br>
<a href="point.php" class="btn btn-info">Back</a> 
	<?php 	
}
mysql_close($con);
}
else
{
?>
<h3><a href="index.php">Home</a></h3>
<br><br>
<div class="alert alert-error">
  <strong>Please login in first!</strong></div>
<br>
<a href="index.php" class="btn btn-info">Go to Login</a> 
	<?php 	
}
?>
<br><br><br>
      <footer>
	  <hr><p>@2013 Play Forward - <?php echo date("Y-m-d H:i:s");?> </p>
      </footer>
    </div>
</body>
</html>