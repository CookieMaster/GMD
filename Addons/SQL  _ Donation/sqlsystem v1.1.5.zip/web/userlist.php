﻿ <!DOCTYPE html>
<?php session_start(); ?>
    <html>
    <head>
    <title>List</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
    <!-- Bootstrap -->
    <link href="admin/css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link rel="shortcut icon" href="favicon.ico" type="image/png">
    </head>		
	<body>
	
	<div class="container"><br>
<h3>
<a href="list.php">List</a>
<a href="admin">Admin Panel</a></h3>
<br>
<h2>List </h2><br>
<?php
include("admin/config.php");
?>
	 <div class="row"><div class="span10">
<a class="btn" href="list.php">All</a>

<?
for($i = 0; $i < count($ulxrank); ++$i) {
?>
 <a class="<?php if($i% 3 == '0'){ echo "btn btn-warning";}elseif($i% 2== '0'){ echo "btn btn-success";}else{ echo  "btn btn-danger";} ?>" href="list.php?rank=<?php echo $ulxrank[$i]; ?>"><?php echo $rankname[$i]; ?></a>
 <?php
}
?>
<br>
<br>

<?php
$rank = $_GET[rank];
$sort = $_GET[sort];
$search = $_GET[search];
$page = $_GET[page];

if(!isset($page)){
    $page=1; 
}

$con = mysql_connect($ip,$name,$pw);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

 mysql_query("SET NAMES 'utf8'");
mysql_select_db( $db, $con);

if($rank == null){ 
$filter = " rank";
}else {
$filter = " '".$rank."' ";
}

$sqlpart = ("FROM users WHERE rank= ".$filter." ORDER BY name ");
$count = mysql_query("SELECT count(*) ".$sqlpart."");
$result = mysql_fetch_row($count); 
$pages = ceil($result[0]/15);
$startfrom = ($page-1)*15;

$sql = ("SELECT name,rank,expired ".$sqlpart." LIMIT ". $startfrom ." , 15 "); 
$list = mysql_query($sql);


?>
<table class="table table-striped">
<tr>
<th>Name</th>
<th>Rank</th>
<th>expired</th></tr>
<?php
while($ml = mysql_fetch_assoc($list) ) {
?>
<tr>
<td><?php echo $ml['name'] ?></td>
<td><?php echo $ml['rank'] ?></td>
<td><?php echo $ml['expired'] ?></td>
</tr>
<?php
}
?>
</table>
<?php
if ($filter == " rank"){
$url2 = "list.php?page=";
}else{
$url2 = "list.php?rank=".$rank."&page=";
}
?>
<div class="pagination pagination-centered">
<ul>
<?php
for($i=1;$i<=$pages;$i++) {
?>
 <li class="<?php if($page == $i){ echo "disabled";} ?>"><a href="<?php echo $url2; echo $i; ?>"><?php echo $i; ?></a></li>
<?php
}
echo " </ul></div>";
mysql_close($con);
?>
<br><br><br>
      <footer>
	  <hr><p>@2013 Play Forward - <?php echo date("Y-m-d H:i:s");?> </p>
      </footer>
    </div>
	
</body>
</html>