ULX Rank MYSQL Connection + PHP Rank Management System v1.0.1

------ Authors ------
[HK]ben - Email : liu411hk@hotmail.com

------ Installation ------

Install Mysqloo (skip it if you have it )
1. Go to server 
2. Copy libmySQL.dll and libmysql.so.16 to the  same folder as srcds.exe(win) or srcds_run (linux)
3. Go to server\garrysmod\lua
4. Copy bin to garrysmod\lua

Import MySQL
1.Import users.sql to database

Install ULX Rank MySQL Connection
1. Go to server\garrysmod\addons\ulx\lua\ulx\modules\sh
2. Copy user.lua to garrysmod\addons\ulx\lua\ulx\modules\sh and replace the original one
3. Go to garrysmod\addons\mysql\lua\autorun\server
4. Open mysql.lua with text editor
5. Set MYSQL IP , username , database , password 
6. Go to server\garrysmod\addons
7. Copy mysql to garrysmod\addons
8. Run the server 

If you got 'MySQL database Connection Failed' ,that's mean something wrong in your setting.


Install PHP Rank Management System
1.Go to web/admin
2. Open config.php with text editor
3.Set up MySQL IP , username , database , password 
4.Change username and password
5.Change $rankname and $ulxrank.
eg.
$rankname = array( "Member" , "Vip" , "Top Vip" , "Operator",  "Admin" , "Superadmin" ); 
$ulxrank =     array( "member" , "vip" , "topvip" , "operator",  "admin" , "superadmin" );  

$rankname  is the rank name that you call.
$ulxrank  is the rank name that call in ulx

The sort of rankname and ulxrank must be same.

(E-mail me if you need help here)

6. Upload web/admin to your website
7. Login with your username and password
8. Go to List and check out there are any error

If you got 'Could not connect: Unknown MySQL server host ' ' (1)' ,that's mean something wrong in your setting.

Import Users data in SQL
You can import it using add user or you can send your user.txt to me then i can help you .

Finish!!!!!!!!!!


------ Web CSS ------
The website using bootstrap .  You can change the web style by changing the  bootstrap.min.css in admin\css.
You can get some free bootstrap in http://bootswatch.com/2/ .

------ Support ------
If you need a no pointshop version , please e-mail me! Remember to write down your name in CoderHire !

btw 
I am working on a auto-register system.
If you want to see it go to 
http://www.hkblackday.com/garrysmod/admin/demo/sign.php 

------ Credit ------

Drakehawke (Authors of MySQLOO v8 )- http://facepunch.com/showthread.php?t=1220537

jqBootstrapValidation - http://reactiveraven.github.io/jqBootstrapValidation/

DateTime Picker- http://www.malot.fr/bootstrap-datetimepicker/demo.php

Bootswatch: Free themes for Twitter - http://bootswatch.com/
