	function RewardForID( id, ply )
		if id == "1" then
			RunConsoleCommand( "ulx", "adduserid", "" .. ply:SteamID() .. "", "vip")
		elseif id == "2" then
			RunConsoleCommand( "ulx", "adduserid", "" .. ply:SteamID() .. "", "sausage")
		end
	end

	function PlayerConnect( ply )
		id64 = ply:SteamID64()
		data = { id = id64 }
		RANK_ID = ""
		http.Post( "http://yoursite.com/donate/inc/claim.php", data, function( body )
			RewardForID( body, ply )
			end, function(_)
				print("Error!" .. _)
			end)
		end
	hook.Add( "PlayerInitialSpawn", "AutoDonate", PlayerConnect )