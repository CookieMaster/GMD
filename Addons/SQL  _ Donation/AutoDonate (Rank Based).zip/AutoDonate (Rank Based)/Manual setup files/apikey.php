<?php
	$API_KEY = "";
?>