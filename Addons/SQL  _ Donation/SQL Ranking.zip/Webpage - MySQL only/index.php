<?php
	//CONFIGURABLE ITEMS START BELOW
	$mysql_host = ""; // Your MySQL host
	$mysql_database = ""; // Your MySQL database
	$mysql_user = ""; // Your MySQL username
	$mysql_password = ""; // Your MySQL user's password
	$mysql_table = "ranking_stats"; //This should be the same table you set in the LUA script.
	
	$defaultlimit = 15; //Default limit of players to show per page. It is recommended to keep this either 10, 15, 20, 25, or 30.
	$pagetitle = "Community Name|Rank Statistics"; // The page title. Use | to seperate header from sub-header
	$useimage = false; // Use image in the header instead of a title
	$imageurl = ""; // If you set useimage to true, you must set a image url to load in the header here.
	$centerheader = true; // Should it center the header? This is for both image headers and title headers.
?>
<!DOCTYPE html>
<html>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
	<head>
		<? echo "<title>" . $pagetitle . "</title>"?>
		<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-sortable.css" rel="stylesheet" media="screen">
		<link href="css/table.css" rel="stylesheet" media="screen">
		<link href="css/bootstrap.css" rel="stylesheet" media="screen">
		<script src="http://code.jquery.com/jquery.js"></script>
		<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
		<script src="js/bootstrap-sortable.js"></script>
	</head>
	<?php 
		function seconds_to_time($secs)
		{
			$dt = new DateTime('@' . $secs, new DateTimeZone('UTC'));
			return array('days'    => $dt->format('z'),
				'hours'   => $dt->format('G'),
				'minutes' => $dt->format('i'),
				'seconds' => $dt->format('s'));
		}

		echo "<body onload='sorter.size(" . $defaultlimit . ")'>"; 
		$pageheader = explode("|", $pagetitle, 2);
		if ($centerheader)
			echo "<center>";
			if ($useimage)
				echo "<img src='" . $imageurl . "'></img>";
			else
				echo array_key_exists ( 1, $pageheader ) ? "<div class='navbar navbar-default' style='margin-top:-1%;'><h1>" . $pageheader[0] . "<small><center>" . $pageheader[1] . "</center></small></h1></div>" : "<div class='well page-header' style='margin-top:-1%;'><h1>" . $pageheader[0] . "</h1></div>";
		if ($centerheader)
			echo "</center>";
		mysql_connect($mysql_host, $mysql_user, $mysql_password) or die(mysql_error()); 
		mysql_select_db($mysql_database) or die(mysql_error()); 

		$sql = "SELECT name,kills,headshots,deaths,plytime FROM $mysql_table ORDER BY kills DESC"; 
		$rs_result = mysql_query ($sql) or die(mysql_error()); 
		?> 
		<div id="tablewrapper"  style="width:80%; margin-left:10%;">
			<div id="search">
				<div id="tableheader" style="width:15%;float:right;">
					<div class="search">
						<input placeholder="Search..." class="form-control" type="text" id="query" onkeyup="sorter.search('query')" />
					</div>
				</div>
				<span class="glyphicon glyphicon-search" style="margin-top:8px;margin-right:4px;float:right;"></span>
			</div>
			<br /><br /><br />
			<div id="tablediv">
				<table cellpadding="0" cellspacing="0" border="0" id="table" class="tinytable table table-striped table-bordered table-condensed sortable">
					<thead>
						<tr>
							<th width=3% data-defaultsort="asc"><teehee>Rank&nbsp;&nbsp;&nbsp;</teehee></th>
							<th width=55%><teehee>Name</teehee></th>
							<th width=9%><teehee>Kills</teehee></th>
							<th width=8%><teehee>Headshots</teehee></th>
							<th width=9%><teehee>Deaths</teehee></th>
							<th width=4%><teehee>KDR&nbsp;&nbsp;&nbsp;</teehee></th>
							<th width=20%><teehee>Play Time</teehee></th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$rank = 1;
							while ($row = mysql_fetch_assoc($rs_result)) { 
						?> 
							<tr>
								<td><center><? echo $rank; $rank++; ?></center></td>
								<td><? echo $row["name"]; ?></td>
								<td><? echo $row["kills"]; ?></td>
								<td><? echo $row["headshots"]; ?></td>
								<td><? echo $row["deaths"]; ?></td>
								<td><center><? $kills = $row["kills"]; $deaths = $row["deaths"]; if ($deaths == 0) $kdr = 0; else $kdr = round($kills/$deaths,2); echo $kdr; ?></center></td>
								<td><? $timearray = seconds_to_time($row["plytime"]); $playtime = $timearray["days"] . "d " . $timearray["hours"] . "h " . $timearray["minutes"] . "m " . $timearray["seconds"] . "s"; echo $playtime; ?> 


							</tr>
						<?php 
						}; 
						?> 
					</tbody>
				</table>
			</div>
			<div id="tablefooter">
				<center><div id="controls">
					
					<div id="tablenav">
						<button type="button" class="btn btn-default btn-xs" width="16" height="16" alt="First Page" onclick="sorter.move(-1,true)">
							<span class="glyphicon glyphicon-backward" ></span>
						</button>
						
						<button type="button" class="btn btn-default btn-xs" width="16" height="16" alt="Previous Page" onclick="sorter.move(-1)">
							<span class="glyphicon glyphicon-chevron-left" ></span>
						</button>
						
						<button type="button" class="btn btn-default btn-xs" width="16" height="16" alt="Next Page" onclick="sorter.move(1)"> 
							<span class="glyphicon glyphicon-chevron-right" ></span>
						</button>
						
						<button type="button" class="btn btn-default btn-xs"  width="16" height="16" alt="Last Page" onclick="sorter.move(1,true)">
							<span class="glyphicon glyphicon-forward" ></span>
						</button>
					</div>
					<div id="perpage">
						<select onchange="sorter.size(this.value)">
							<option value="10">10</option>
							<option value="15" selected="selected">15</option>
							<option value="20">20</option>
							<option value="25">25</option>
							<option value="30">30</option>
						</select>
						<span>Players per page</span>
						<br /><br /><span class="details">
							<div>Players <span id="startrecord"></span>-<span id="endrecord"></span> out of <span id="totalrecords"></span></div>
						</span>
					</div>
					<div id="text">Displaying page <span id="currentpage"></span> of <span id="totalpages"></span></div>
				</div></center>
			</div>
		</div>
		<script type="text/javascript" src="js/table.js"></script>
		<script type="text/javascript">
		var sorter = new TINY.table.sorter('sorter','table',{
			headclass:'head',
			ascclass:'asc',
			descclass:'desc',
			evenclass:'evenrow',
			oddclass:'oddrow',
			evenselclass:'evenselected',
			oddselclass:'oddselected',
			paginate:true,
			<? echo "size:" .$defaultlimit."," ?>
			currentid:'currentpage',
			totalid:'totalpages',
			startingrecid:'startrecord',
			endingrecid:'endrecord',
			totalrecid:'totalrecords',
			hoverid:'selectedrow',
			navid:'tablenav',
			init:true
		});
	  </script>
	</body>
</html>