
--[[-------------------------------------------------------

		RankingSQL Module by Hipster Lettuce

---------------------------------------------------------]]

-- START OF CONFIGURABLE ITEMS --

local tablename = 'ranking_stats' -- Your SQL table name (this will be created automatically if it doesn't exist)
local saveafter = 50 -- After how many kills/deaths should the server process after doing a global save? (Player stats also save when they disconnect and when the server shutsdown/changes maps. This is for backup purposes.) Set this to 0 to disable it.
local TopCommandPageLimit = 4 -- How many players per page should be shown in the !top command.
local PlayTimeTimer = 5 -- How many seconds until the play time counter processes players. Keep this higher for less lag.
local BroadcastRank = true -- When a player uses the !rank command, everyone in the server will see their rank if this is set to true.

-- Top 3 HUD config
local ShowTop3InHUD = true -- Keep this as true if you want the Top 3 HUD to show.
local Top3Position = "top-middle" -- Position, can be "top-left", "top-middle", "top-right", "bottom-left", "bottom-middle", and "bottom-right" 

-- Edit this if you are using MySQL --
local UseMySQL = false -- If you want to use a MySQL database, set this as true. Otherwise, it will use SQLite (doesn't require anything to run)
local mysql_hostname = '' -- Your MySQL server address.
local mysql_username = '' -- Your MySQL username.
local mysql_password = '' -- Your MySQL password.
local mysql_database = '' -- Your MySQL database.
local mysql_port = 3306 -- Your MySQL port. Most likely is 3306 (default).

-- TTT configs, skip if you are not running TTT --
local TTT_SkipIllegalKills = true -- Ignore traitor VS traitor or innocent VS innocent kills or detective VS innocent
local TTT_SkipInactiveRounds = true -- Ignore kills before the round starts or after the round ends.

-- END OF CONFIGURABLE ITEMS. EDIT AT YOUR OWN RISK AFTER THIS POINT --

if SERVER then

	RankingSQL = {}
	RankingSQL.Logs = {}

	local datatable = {}
	local queue = {}
	local db = nil
	if ShowTop3InHUD then util.AddNetworkString( "RankingSQL_TopPlayers" ) end
	
	function RankingSQL.AddLog( sqltype, log )
		RankingSQL.Logs[#RankingSQL.Logs+1] = {os.date(), "[Ranking " .. sqltype .. "]: "..log}
		ServerLog("[Ranking " .. sqltype .. "]: "..log.."\n")
	end

	concommand.Add( "rankingsql_logs", function( ply, cmd, args )
		if IsValid(ply) then return end
		print("RankingSQL Logs:")
		for i=1,#RankingSQL.Logs do
			print(unpack(RankingSQL.Logs[i]))
		end
	end )

	if UseMySQL then

		require('mysqloo')

		db = mysqloo.connect(mysql_hostname, mysql_username, mysql_password, mysql_database, mysql_port)

		if not mysqloo then
			RankingSQL.AddLog("MySQL", "MySQLoo is not installed.")
			return nil
		end

		function RankingSQL.Query( str, callback )
			local q = db:query( str )

			if not q then
				table.insert( queue, { str, callback } )
				db:connect()
				return
			end
			
			function q:onSuccess( data )
				callback( data )
			end
			
			function q:onError( err )
				if db:status() == mysqloo.DATABASE_NOT_CONNECTED then
					table.insert( queue, { str, callback } )
					db:connect()
				return end
				
				RankingSQL.AddLog( "MySQL", "Error! Query failed: " .. err )
			end
			
			q:start();
			q:wait();
		end
		
		function db:onConnected()
			RankingSQL.AddLog( "MySQL", "Connected!")

			for k, v in pairs( queue ) do
				query( v[ 1 ], v[ 2 ] )
			end
			
			queue = {}

			RankingSQL.Initialize()
		end

		function db:onConnectionFailed(err)
			RankingSQL.AddLog( "MySQL", "Connection Failed, please check your settings: " .. err)
		end

		db:connect();
	end
	
	

	-- START OF SQL QUERIES --

	function RankingSQL.Initialize()
		if UseMySQL then
			RankingSQL.Query("CREATE TABLE IF NOT EXISTS `" .. tablename .. "` (`steamid` varchar(30) CHARACTER SET latin1 NOT NULL, `name` char(255) COLLATE utf8_unicode_ci NOT NULL, `kills` int(32) NOT NULL, `headshots` int(32) NOT NULL, `deaths` int(32) NOT NULL, `plytime` int(32) NOT NULL, PRIMARY KEY (`steamid`) )", function(data)
				RankingSQL.Query("SHOW COLUMNS FROM " .. tablename .. " WHERE field = 'plytime'", function(data)
					if not data and data[1] then
						RankingSQL.Query("ALTER TABLE " .. tablename .. " ADD plytime int(32) NOT NULL", function() end)
					end
				end)
				for k,v in pairs(player.GetAll()) do
					if IsValid(v) and v:IsPlayer() and not v:IsBot() then RankingSQL.Get(v) end
				end
				RankingSQL.AddLog( "MySQL", "Initialized.")
			end)
		else
			if (sql.TableExists(tablename)) then
				RankingSQL.AddLog( "SQLite", "Initialized.")
				for k,v in pairs(player.GetAll()) do
					if IsValid(v) and v:IsPlayer() and not v:IsBot() then RankingSQL.Get(v) end
				end
			else
				query = "CREATE TABLE IF NOT EXISTS " .. tablename .. " ( steamid varchar(255) NOT NULL, name char(255) NOT NULL, kills int(32) NOT NULL, headshots int(32) NOT NULL, deaths int(32) NOT NULL, plytime int(32) NOT NULL, PRIMARY KEY (steamid) )"
				result = sql.Query(query)
				if (sql.TableExists(tablename)) then
					RankingSQL.AddLog( "SQLite", "Initialized.")
				else
					RankingSQL.AddLog( "SQLite", "Unable to create table: " .. sql.LastError( result ) )
				end	
			end
		end
	end

	function RankingSQL.Save(ply)
		local steamid = ply:SteamID()
		local uniqueid = ply:UniqueID()
		local name = string.gsub(ply:GetName(), "'", "")

		if UseMySQL then
			RankingSQL.Query("INSERT INTO `" .. tablename .. "` (steamid, name, kills, headshots, deaths, plytime) VALUES ('" .. steamid .. "', '" .. name .. "', '" .. (datatable[uniqueid].kills or 0) .. "', '" .. (datatable[uniqueid].headshots or 0) .. "', '" .. (datatable[uniqueid].deaths or 0)  .. "', '" .. (datatable[uniqueid].plytime or 0) .. "') ON DUPLICATE KEY UPDATE name = VALUES(name), kills = VALUES(kills), headshots = VALUES(headshots), deaths = VALUES(deaths), plytime = VALUES(plytime)", function() end)
		else
			local saveQuery = sql.Query("INSERT OR REPLACE INTO " .. tablename .. " (steamid, name, kills, headshots, deaths, plytime) VALUES ('" .. steamid .. "', '" .. name .. "', '" .. (datatable[uniqueid].kills or 0) .. "', '" .. (datatable[uniqueid].headshots or 0) .. "', '" .. (datatable[uniqueid].deaths or 0) .. "', '" .. (datatable[uniqueid].plytime or 0) .. "')")
			if (sql.LastError(saveQuery) ~= nil) then
				RankingSQL.AddLog( "SQLite", "Unable to save player (" .. steamid .. "): " .. sql.LastError(saveQuery) )
			end
		end
	end

	function RankingSQL.Get( ply )
		if UseMySQL then
			RankingSQL.Query("SELECT kills,headshots,deaths,plytime FROM `" .. tablename .. "` WHERE steamid = '" .. ply:SteamID() .. "'", function(data)
				if data and data[1] then
					datatable[ply:UniqueID()] = {kills=data[1].kills, headshots = data[1].headshots, deaths=data[1].deaths, plytime=data[1].plytime}
				end
			end)
		else
			local dataQuery = sql.Query("SELECT kills,headshots,deaths,plytime FROM `" .. tablename .. "` WHERE steamid = '" .. ply:SteamID() .. "'")
			if (dataQuery) then
				for id, row in pairs( dataQuery ) do
					datatable[ply:UniqueID()] = {kills=row['kills'], headshots=row['headshots'], deaths=row['deaths'], plytime=row['plytime']}
				end
			end
		end
	end

	if not UseMySQL then RankingSQL.Initialize() end

	if ShowTop3InHUD then
		function RankingSQL.GetTopPlayers( ply, command, args )
			if UseMySQL then
				RankingSQL.Query("SELECT steamid,name,kills,headshots,deaths,ROUND(kills/deaths,2) AS kdr FROM `" .. tablename .. "` GROUP BY `steamid` ORDER BY `kills` DESC LIMIT 3", function(data)
					if data then
						local tableOfKills = {}
						for id, row in pairs( data ) do
							tableOfKills[id] = {steamid = row.steamid, name = row.name, kills = row.kills, headshots = row.headshots, deaths = row.deaths, kdr = row.kdr ~= "NULL" and row.kdr or 0}
						end
						net.Start( "RankingSQL_TopPlayers" )
							RankingSQL.TopPlayerTable = tableOfKills
							net.WriteTable{ tableOfKills }
						net.Send( ply )
					end
				end)
			else
				local topPlayersQuery = sql.Query("SELECT steamid,name,kills,headshots,deaths,ROUND(kills/deaths,2) AS kdr FROM `" .. tablename .. "` GROUP BY `steamid` ORDER BY `kills` DESC LIMIT 3")
				if (topPlayersQuery) then
					local tableOfKills = {}
					for id, row in pairs( topPlayersQuery ) do
						tableOfKills[id] = {steamid = row['steamid'], name = row['name'], kills = row['kills'], headshots = row['headshots'], deaths = row['deaths'], kdr = row['kdr'] ~= "NULL" and row['kdr'] or 0}
					end
					net.Start( "RankingSQL_TopPlayers" )
						RankingSQL.TopPlayerTable = tableOfKills
						net.WriteTable{ tableOfKills }
					net.Send( ply )
				end
			end
		end
		concommand.Add( "rakingsql_refreshtopplayers", RankingSQL.GetTopPlayers )
	end

	function RankingSQL.GetRank( ply, command, args )
		if not IsValid(ply) and ply:IsPlayer() then return end
		local kills = 0
		local headshots = 0
		local deaths = 0
		local rank = 0
		local plycount = 0
		local kdr = 0

		if UseMySQL then
			RankingSQL.Query("SELECT kills,headshots,deaths, 1 + (SELECT count( * ) FROM " .. tablename .. " a WHERE a.kills > b.kills ) AS rank, (SELECT count( * ) FROM " .. tablename .. ") AS plycount, ROUND(kills/deaths,2) AS kdr FROM " .. tablename .. " b WHERE steamid = '" .. ply:SteamID() .. "'", function(data)
				if data and data[1] then
					local result = data[1]
					kills = tonumber(result.kills)
					headshots = tonumber(result.headshots)
					deaths = tonumber(result.deaths)
					rank = tonumber(result.rank)
					plycount = tonumber(result.plycount or 0)
					kdr = tonumber(result.kdr or 0)
					if kdr == nil then kdr = 0 end
					local teamcol = team.GetColor(ply:Team())
					local normcol = Color(255,30,60,255)
					if BroadcastRank then
						for k, v in pairs(player.GetAll()) do
							SendText(v, teamcol, ply:Nick(), normcol, " is ranked " .. rank .. " out of " .. plycount .. " with " .. headshots .. (tonumber(headshots) > 1 and " headshots " or " headshot ") .. "and a KDR of " .. kdr .. " (".. kills .. "/" .. deaths ..")")
						end
					else
						SendText(ply, teamcol, ply:Nick(), normcol, " is ranked " .. rank .. " out of " .. plycount .. " with " .. headshots .. (tonumber(headshots) > 1 and " headshots " or " headshot ") .. "and a KDR of " .. kdr .. " (".. kills .. "/" .. deaths ..")")
					end
				else
					SendText(ply, "You are not tracked on the server yet.")
				end
			end);
		else
			local rankQuery = sql.Query("SELECT kills,headshots,deaths, 1 + (SELECT count( * ) FROM " .. tablename .. " a WHERE a.kills > b.kills ) AS rank, (SELECT count( * ) FROM " .. tablename .. ") AS plycount, ROUND(kills/deaths,2) AS kdr FROM " .. tablename .. " b WHERE steamid = '" .. ply:SteamID() .. "'")
			if (rankQuery) then
				local result = rankQuery[1]
				kills = tonumber(result['kills'])
				headshots = tonumber(result['headshots'])
				deaths = tonumber(result['deaths'])
				rank = tonumber(result['rank'])
				plycount = tonumber(result['plycount'] or 0)
				kdr = tonumber(result['kdr'] or 0)
				if kdr == nil then kdr = 0 end
				local teamcol = team.GetColor(ply:Team())
				local normcol = Color(255,30,60,255)
				if BroadcastRank then
					for k, v in pairs(player.GetAll()) do
						SendText(v, teamcol, ply:Nick(), normcol, " is ranked " .. rank .. " out of " .. plycount .. " with " .. headshots .. (tonumber(headshots) > 1 and " headshots " or " headshot ") .. "and a KDR of " .. kdr .. " (".. kills .. "/" .. deaths ..")")
					end
				else
					SendText(ply, teamcol, ply:Nick(), normcol, " is ranked " .. rank .. " out of " .. plycount .. " with " .. headshots .. (tonumber(headshots) > 1 and " headshots " or " headshot ") .. "and a KDR of " .. kdr .. " (".. kills .. "/" .. deaths ..")")
				end
			else
				SendText(ply, "You are not tracked on the server yet.")
			end
		end
	end
	concommand.Add( "ranksql_getrank", RankingSQL.GetRank )

	function RankingSQL.GetTopPage( ply, command, args )
		if not IsValid(ply) and ply:IsPlayer() then return end
		local page = tonumber(args[1])
		if page == nil or page < 1 then page = 1 end
		local pagelimit = (page - 1) * TopCommandPageLimit

		if UseMySQL then
			RankingSQL.Query("SELECT name,kills,1 + (SELECT count( * ) FROM " .. tablename .. " a WHERE a.kills > b.kills ) AS rank FROM `" .. tablename .. "` b GROUP BY `steamid` ORDER BY `kills` DESC LIMIT " .. pagelimit .. " , " .. TopCommandPageLimit, function(data)
				if data and data[1] then
					for id, row in pairs( data ) do
						SendText(ply, row.rank .. ". " .. row.name .. " with " .. row.kills .. " kills")
					end
				else
					SendText(ply, "No data found in this page.")
				end
			end);
		else
			local rankQuery = sql.Query("SELECT name,kills,1 + (SELECT count( * ) FROM " .. tablename .. " a WHERE a.kills > b.kills ) AS rank FROM `" .. tablename .. "` b GROUP BY `steamid` ORDER BY `kills` DESC LIMIT " .. pagelimit .. " , " .. TopCommandPageLimit)
			if rankQuery then
				for id, row in pairs( rankQuery ) do
					SendText(ply, row['rank'] .. ". " .. row['name'] .. " with " .. row['kills'] .. " kills")
				end
			else
				SendText(ply, "No data found in this page.")
			end
		end
	end
	concommand.Add( "ranksql_gettop", RankingSQL.GetTopPage )

	-- END OF SQL QUERIES --


	-- HOOKS START HERE --

	-- Headshot recognition using ScalePlayerDamage
	hook.Add("ScalePlayerDamage", "RankingSQL_DoScaleDamage", function(ply, HitGroup)
		if IsValid(ply) then ply.ranking_getlasthitgroup = HitGroup end
	end)

	local savenum = 0
	function RankingSQL.DoDeath( victim, weapon, killer ) 
		savenum = savenum + 1
		if IsValid(killer) and killer:IsPlayer() and not killer:IsBot() and killer ~= victim then
			--TTT Handling
			if( string.match(GetConVarString("gamemode"), "terrortown") ) then
				local VictimIsTraitor = victim:IsActiveTraitor()
				local VictimIsDetective = victim:IsActiveDetective()
				local VictimIsInnocent = !victim:IsActiveDetective() and !victim:IsActiveTraitor()
				local KillerIsTraitor = killer:IsActiveTraitor()
				local KillerIsDetective = killer:IsActiveDetective()
				local KillerIsInnocent = (!killer:IsActiveDetective() and !killer:IsActiveTraitor())

				if GetRoundState() ~= ROUND_ACTIVE and TTT_SkipInactiveRounds then return end
				if VictimIsTraitor and KillerIsTraitor and TTT_SkipIllegalKills then return end
				if VictimIsInnocent and KillerIsInnocent and TTT_SkipIllegalKills then return end
				if VictimIsDetective and KillerIsDetective and TTT_SkipIllegalKills then return end
				if VictimIsDetective and KillerIsInnocent and TTT_SkipIllegalKills then return end
				if VictimIsInnocent and KillerIsDetective and TTT_SkipIllegalKills then return end
			end

			local killerkills = 0
			local killerheadshots = 0
			if datatable[killer:UniqueID()] then
				if datatable[killer:UniqueID()].kills then
					killerkills = datatable[killer:UniqueID()].kills
				end
				if datatable[killer:UniqueID()].headshots then
					killerheadshots = datatable[killer:UniqueID()].headshots
				end
				killerkills = killerkills + 1
				if IsValid(victim) and victim.ranking_getlasthitgroup and victim.ranking_getlasthitgroup == HITGROUP_HEAD then
					killerheadshots = killerheadshots + 1
					datatable[killer:UniqueID()].headshots = killerheadshots
				end
				datatable[killer:UniqueID()].kills = killerkills
			else
				killerkills = killerkills + 1
				if IsValid(victim) and victim.ranking_getlasthitgroup and victim.ranking_getlasthitgroup == HITGROUP_HEAD then
					killerheadshots = killerheadshots + 1
					datatable[killer:UniqueID()].headshots = killerheadshots
				end
				datatable[killer:UniqueID()] = {}
				datatable[killer:UniqueID()].kills = killerkills
			end

			RankingSQL.Save(killer)
			if ShowTop3InHUD then
				local toptbl = RankingSQL.TopPlayerTable
				local killersteamid = killer:SteamID()
				if toptbl then
					if (toptbl[1] and toptbl[1].steamid == killersteamid) or (toptbl[2] and toptbl[2].steamid == killersteamid) or (toptbl[3] and toptbl[3].steamid == killersteamid) then
						for k, v in pairs(player.GetAll()) do
							RankingSQL.GetTopPlayers( v )
						end
					end
				else
					for k, v in pairs(player.GetAll()) do
						RankingSQL.GetTopPlayers( v )
					end
				end
			end
		end
		
		if IsValid(victim) and victim:IsPlayer() and not victim:IsBot() then
			local victimdeaths = 0
			if datatable[victim:UniqueID()] then
				if datatable[victim:UniqueID()].deaths then
					victimdeaths = datatable[victim:UniqueID()].deaths
				end
				victimdeaths = victimdeaths + 1
				datatable[victim:UniqueID()].deaths = victimdeaths
			else
				datatable[victim:UniqueID()] = {}
				victimdeaths = victimdeaths + 1
				datatable[victim:UniqueID()].deaths = victimdeaths
			end
		end

		if savenum >= saveafter then
			for k,v in pairs(player.GetAll()) do
				if IsValid(v) and v:IsPlayer() and not v:IsBot() then RankingSQL.Save(v) end
			end
			savenum = 0
		end
	end
	hook.Add( "PlayerDeath", "RankingSQL_DoDeath", RankingSQL.DoDeath )

	function RankingSQL.DoDisconnect( ply )
		RankingSQL.Save(ply)
	end
	hook.Add( "PlayerDisconnected", "RankingSQL_DoDisconnect", RankingSQL.DoDisconnect )

	function RankingSQL.DoShutdown()
		if SERVER then
			for k,v in pairs(player.GetAll()) do
				if IsValid(v) and v:IsPlayer() and not v:IsBot() then RankingSQL.Save(v) end
			end
		end
	end
	hook.Add( "ShutDown", "RankingSQL_DoShutdown", RankingSQL.DoShutdown )

	function RankingSQL.DoSpawn( ply )
		RankingSQL.Get( ply )
	end
	hook.Add( "PlayerInitialSpawn", "RankingSQL_DoSpawn", RankingSQL.DoSpawn )

	function RankingSQL.Commands( ply, text, public )
		if string.lower( string.sub( text, 1, 5) ) == "!rank" then
			ply:SendLua("RunConsoleCommand('ranksql_getrank')")
			return ""
		elseif string.lower( string.sub( text, 1, 5) ) == "/rank" then
			ply:SendLua("RunConsoleCommand('ranksql_getrank')")
			return ""
		elseif string.lower( string.sub( text, 1, 4) ) == "!top" then
			local args = string.Split(text, " ")
			local page = tonumber(args[2])
			if page == nil or page < 1 then page = 1 end
			ply:SendLua("RunConsoleCommand('ranksql_gettop', " .. page .. ")")
			return ""
		elseif string.lower( string.sub( text, 1, 4) ) == "/top" then
			local args = string.Split(text, " ")
			local page = tonumber(args[2])
			if page == nil or page < 1 then page = 1 end
			ply:SendLua("RunConsoleCommand('ranksql_gettop', " .. page .. ")")
			return ""
		end
	end
	hook.Add( "PlayerSay", "RankingSQL_Commands", RankingSQL.Commands)

	timer.Create( "RankingSQL_PlayTimeCounter", PlayTimeTimer, 0, function()
		for k,ply in pairs(player.GetAll()) do
			if IsValid(ply) and ply:IsPlayer() and not ply:IsBot() then
				local plytime = 0
				if datatable[ply:UniqueID()] then
					if datatable[ply:UniqueID()].plytime then
						plytime = datatable[ply:UniqueID()].plytime
					end
					datatable[ply:UniqueID()].plytime = plytime + PlayTimeTimer
				else
					datatable[ply:UniqueID()] = {}
					datatable[ply:UniqueID()].plytime = plytime + PlayTimeTimer
				end
			end
		end
	end)
	

	-- END OF HOOKS --

	-- SendText command (serverside AddChat) --

	function SendText( pl, ... )
		local t, k, v, s
		t = { ... }
		for k, v in ipairs( t ) do
			if type( v ) == "table" then
				if v.r and v.g and v.b then
					t[ k ] = string.format( "Color(%d,%d,%d,255)", tonumber( v.r ) or 255, tonumber( v.g ) or 255, tonumber( v.b ) or 255 )
				end
			else
				t[ k ] = string.format( "%q", tostring( v ) )
			end
		end
		s = "chat.AddText( %s )"
		pl:SendLua( s:format( table.concat( t, "," ) ) )
	end

	-- Top 3 HUD clientside code --
	
elseif CLIENT and ShowTop3InHUD then
	RankingSQL = {}

	net.Receive( "RankingSQL_TopPlayers", function( intMsgLen )
		local ply = LocalPlayer()
		tableRecieved = net.ReadTable()[1]
		RankingSQL.TopPlayerTable = tableRecieved
	end )

	RankingSQL.FontData = {
		["bigbold"] = {
			font 	= "DermaDefault",
			size 	= 14,
			weight 	= 700
		},
		["defaultbold"] = {
			font 	= "DermaDefault",
			size 	= 12,
			weight 	= 700
		},
		["default"] = {
			font 	= "DermaDefault",
			size 	= 12,
			weight 	= 500
		},
	}

	surface.CreateFont( "rankingsql_bigbold", 	RankingSQL.FontData.bigbold )
	surface.CreateFont( "rankingsql_defaultbold", RankingSQL.FontData.defaultbold )
	surface.CreateFont( "rankingsql_default", 	RankingSQL.FontData.default )

	function RankingSQL.DrawTopPlayerHUD()
		local w, h 	= 200, 80
		local x, y = ScrW()-(ScrW()/2)-(w/2), 0

		if     Top3Position == "top-left" then
			x, y = 0, 1
		elseif Top3Position == "top-middle" then
			x, y = ScrW()-(ScrW()/2)-(w/2), 1
		elseif Top3Position == "top-right" then
			x, y = ScrW()-w, 1
		elseif Top3Position == "bottom-left" then
			x, y = 0, ScrH()-h-1
		elseif Top3Position == "bottom-middle" then
			x, y = ScrW()-(ScrW()/2)-(w/2), ScrH()-h-1
		elseif Top3Position == "bottom-right" then
			x, y = ScrW()-w, ScrH()-h-1
		end

		local TEX_GRADIENT = surface.GetTextureID( "gui/gradient_down" )

		surface.SetDrawColor( 20, 20, 20, 120 )
		surface.DrawRect( x, y, w, h )
		
		surface.SetDrawColor( 0, 0, 0, 120 )
		surface.DrawRect( x, y, 1, h-1 )
		surface.DrawRect( x, y+h-1, w, 1 )
		surface.DrawRect( x, y-1, w, 1 )
		surface.DrawRect( x+w-1, y, 1, h-1 )
		
		surface.SetDrawColor( 200, 200, 200, 120 )
		surface.DrawRect( x+1, y, 1, h-2 )
		surface.DrawRect( x+1, y+h-2, w-2, 1 )
		surface.DrawRect( x+1, y, w-2, 1 )
		surface.DrawRect( x+1, y+h-63, w-2, 1 )
		surface.DrawRect( x+w-2, y, 1, h-2 )
		surface.DrawRect( x+w-60, y+18, 1, h-20 )
		
		surface.SetDrawColor( 0, 0, 0, 120 )
		surface.SetTexture( TEX_GRADIENT )
		surface.DrawTexturedRect( x+1, y, w-2, h*0.50 )
		
		surface.SetFont( "rankingsql_bigbold" )
		surface.SetTextColor( 255, 255, 255, 220 )
		
		local tw, th = surface.GetTextSize( "GBux" )
		surface.SetTextPos( x+w*0.50-tw*1.25, y+1 )
		surface.DrawText( "Top 3 Players" )
		
		local tableOfTopPlayers = RankingSQL.TopPlayerTable
		local isTableValid = tableOfTopPlayers ~= nil
		
		if not isTableValid then
			LocalPlayer():ConCommand("rakingsql_refreshtopplayers")
		end
		
		surface.SetFont( "rankingsql_defaultbold" )
		
		surface.SetTextPos( x+40, y+18 )
		surface.DrawText( "Name" )
		surface.SetTextPos( x+160, y+18 )
		surface.DrawText( "Kills" )

		surface.SetFont( "rankingsql_default" )
		surface.SetTextPos( x+8, y+32 )
		surface.DrawText( string.sub( ((isTableValid and tableOfTopPlayers[1] ~= nil and tableOfTopPlayers[1].name ~= nil and tableOfTopPlayers[1].name .. " ") or (isTableValid and "-") or "COULD NOT LOAD LIST"), 1, 28) )
		
		surface.SetTextPos( x+8, y+47 )
		surface.DrawText( string.sub( ((isTableValid and tableOfTopPlayers[2] ~= nil and tableOfTopPlayers[2].name ~= nil and tableOfTopPlayers[2].name .. " ") or (isTableValid and "-") or "COULD NOT LOAD LIST"), 1, 28) )
		
		surface.SetTextPos( x+8, y+62 )
		surface.DrawText( string.sub( ((isTableValid and tableOfTopPlayers[3] ~= nil and tableOfTopPlayers[3].name ~= nil and tableOfTopPlayers[3].name .. " ") or (isTableValid and "-") or "COULD NOT LOAD LIST"), 1, 28) )
		
		xNumPos1 = x+167
		xNumPos2 = x+167
		xNumPos3 = x+167

		if (isTableValid) then

			if tableOfTopPlayers[1] ~= nil then
				if tonumber(tableOfTopPlayers[1].kills) > 9999 then
					xNumPos1 = x + 158
				elseif tonumber(tableOfTopPlayers[1].kills) > 999 then
					xNumPos1 = x + 160
				elseif tonumber(tableOfTopPlayers[1].kills) > 99 then
					xNumPos1 = x + 162
				elseif tonumber(tableOfTopPlayers[1].kills) > 9 then
					xNumPos1 = x + 164
				end
			end

			if tableOfTopPlayers[2] ~= nil then
				if tonumber(tableOfTopPlayers[2].kills) > 9999 then
					xNumPos2 = x + 158
				elseif tonumber(tableOfTopPlayers[2].kills) > 999 then
					xNumPos2 = x + 160
				elseif tonumber(tableOfTopPlayers[2].kills) > 99 then
					xNumPos2 = x + 162
				elseif tonumber(tableOfTopPlayers[2].kills) > 9 then
					xNumPos2 = x + 164
				end
			end

			if tableOfTopPlayers[3] ~= nil then
				if tonumber(tableOfTopPlayers[3].kills) > 9999 then
					xNumPos3 = x + 158
				elseif tonumber(tableOfTopPlayers[3].kills) > 999 then
					xNumPos3 = x + 160
				elseif tonumber(tableOfTopPlayers[3].kills) > 99 then
					xNumPos3 = x + 162
				elseif tonumber(tableOfTopPlayers[3].kills) > 9 then
					xNumPos3 = x + 164
				end
			end
		end

		surface.SetTextPos( xNumPos1, y+32 )
		surface.DrawText( (isTableValid and tableOfTopPlayers[1] ~= nil and tableOfTopPlayers[1].kills) or "0" )
		surface.SetTextPos( xNumPos2, y+47 )
		surface.DrawText( (isTableValid and tableOfTopPlayers[2] ~= nil and tableOfTopPlayers[2].kills) or "0" )
		surface.SetTextPos( xNumPos3, y+62 )
		surface.DrawText( (isTableValid and tableOfTopPlayers[3] ~= nil and tableOfTopPlayers[3].kills) or "0" )
	end
	hook.Add( "HUDPaint", "RankingSQL_Top3PlayerHUD", RankingSQL.DrawTopPlayerHUD )

end