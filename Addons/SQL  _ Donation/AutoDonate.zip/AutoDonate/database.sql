-- phpMyAdmin SQL Dump
-- version 4.0.5
-- http://www.phpmyadmin.net

--
-- Table structure for table `donations_list`
--

CREATE TABLE IF NOT EXISTS `donations_list` (
  `community_id` varchar(35) NOT NULL,
  `steam_name` varchar(35) NOT NULL,
  `steam_id2` varchar(20) NOT NULL,
  `amount` int(5) NOT NULL,
  `date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `unclaimed`
--

CREATE TABLE IF NOT EXISTS `unclaimed` (
  `community_id` varchar(35) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;