	function PlayerConnect( ply )
		id64 = ply:SteamID64()
		data = { id = id64 }
		RANK_ID = ""
		http.Post( "http://yoursite.com/donate/inc/claim.php", data, function( body )
			if body == "secretphrase" then
				RunConsoleCommand( "ulx", "adduserid", "" .. ply:SteamID() .. "", "vip")
				end
			end, function(_)
				print("Error!" .. _)
			end)
		end
	hook.Add( "PlayerInitialSpawn", "AutoDonate", PlayerConnect )