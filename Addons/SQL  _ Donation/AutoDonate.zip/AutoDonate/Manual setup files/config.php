<?php
	/* Automatic Donation Script by AJ */ 
	/* MySQL Information */
	define('SQL_USER', 'user');
	define('SQL_PASS', 'password');
	define('SQL_DB', 'database');
	define('SQL_HOST', 'host');
	
	/* Miscellaneous Information */
	define('PAYPAL_EMAIL', 'email');
	define('SERVER_NAME', 'server');
	define('CURRENCY', 'currency');
	define('SECRET_PHRASE', 'phrase');
	?>