<?php
	$API_KEY = "";
	?>