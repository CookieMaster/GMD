<?php

ini_set('log_errors', true);
ini_set('error_log', dirname(__FILE__).'/ipn_errors.log');


// instantiate the IpnListener class
include('ipnlistener.php');
include('config.php');
$listener = new IpnListener();


$listener->use_sandbox = PAYPAL_SANDBOX;

try {
    $listener->requirePostMethod();
    $verified = $listener->processIpn();
} catch (Exception $e) {
    error_log($e->getMessage());
    exit(0);
}


if ($verified) {
    $pid = $_POST['item_number'];
	$tid = $_POST['txn_id'];
	$cid = $_POST['custom'];
	$price=$PRODUCTS[$pid]["price"];
	
	if ($_POST['payment_status'] == "Completed" && strtolower( $_POST['receiver_email'] ) == strtolower( PAYPAL_ID ) && doubleval( $_POST['mc_gross'] ) == $price && $_POST['mc_currency'] == PAYPAL_CURRENCY){

		$link = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
		if (!$link) {
			error_log("Can not connect to the database: " . mysqli_connect_error());
			exit(0);
		}

		$query = "CREATE TABLE IF NOT EXISTS `payments` ( `transactionid` varchar(125) NOT NULL, `productid` int(6) unsigned NOT NULL, `playerid` varchar(40) NOT NULL, `time` int(10) unsigned NOT NULL, `info` text NOT NULL, UNIQUE KEY `transactionid` (`transactionid`))";
		mysqli_query($link, $query);
		
		$query = "SELECT * FROM payments WHERE transactionid=?";
		$stmt = mysqli_stmt_init($link);
		if (mysqli_stmt_prepare($stmt, $query)) {
			mysqli_stmt_bind_param($stmt, "s", $tid);
			mysqli_stmt_execute($stmt);
			if(mysqli_stmt_fetch($stmt)){
				mysqli_stmt_close($stmt);	
				mysqli_close($link);
				die();
				error_log("Transaction id already exists in database {$tid}");
				exit(0);
			}
		}
		mysqli_stmt_close($stmt);	
		
		$authserver = bcsub($cid, '76561197960265728') & 1;
		$authid = (bcsub($cid, '76561197960265728')-$authserver)/2;
		$steamid = "STEAM_0:$authserver:$authid";
		
		
		$query = "INSERT INTO `payments` ( `productid`, `transactionid`, `playerid`, `time`, `info`) VALUES ( ?, ?, ?, UNIX_TIMESTAMP(), ?)";
		$stmt = mysqli_stmt_init($link);
		if (mysqli_stmt_prepare($stmt, $query)) {
			mysqli_stmt_bind_param($stmt, "isss", $pid, $tid, $steamid, $listener->getTextReport());
			mysqli_stmt_execute($stmt);
		}
		mysqli_stmt_close($stmt);
		
		
		foreach ( $PRODUCTS[$pid]["servers"] as $server => $data) {
			$dbtable = $SERVERS[$server]["dbtable"];
			$execute = json_encode($data["execute"]);
			$offline = $data["offline"] ? 1 : 0;
			
			$query = "CREATE TABLE IF NOT EXISTS `{$dbtable}` ( `orderid` MEDIUMINT NOT NULL AUTO_INCREMENT, `transactionid` varchar(125) NOT NULL, `playerid` varchar(40) NOT NULL, `execute` TEXT NOT NULL, `offline` TINYINT(1) UNSIGNED NOT NULL, PRIMARY KEY (orderid))";
			mysqli_query($link, $query);
			
			$query = "INSERT INTO `{$dbtable}` ( `transactionid`, `playerid`, `execute`, `offline`) VALUES ( ? ,?, ?, ?)";
			$stmt = mysqli_stmt_init($link);
			if (mysqli_stmt_prepare($stmt, $query)) {
				mysqli_stmt_bind_param($stmt, "sssi", $tid, $steamid, $execute, $offline);
				mysqli_stmt_execute($stmt);
			}
			mysqli_stmt_close($stmt);
		}
		mysqli_close($link);
		if(PAYPAL_SANDBOX){
			mail( "edgarasf123@gmail.com" , 'Product Completed', $error);
		}
	}else{
		$error = "ProductID = $pid\n";
		if($_POST['payment_status'] != "Completed" ){
			$error .= "Payment status is not completed ( payment_status = {$_POST['payment_status']} )\n";
		}
		if(strtolower( $_POST['receiver_email'] ) != strtolower( PAYPAL_ID )){
			$error .= "Seller email doesn't match ( ".PAYPAL_ID." != {$_POST['receiver_email']} )\n";
		}
		if(doubleval( $_POST['mc_gross'] ) != $price){
			$error .= "Prices doesn't match ( {$price} != {$_POST['mc_gross']} )\n";
		}
		if($_POST['mc_currency'] != PAYPAL_CURRENCY){
			$error .= "Currency doesn't match ( ".PAYPAL_CURRENCY." != {$_POST['mc_currency']} )\n";
		}
		$error .= $listener->getTextReport();
	    mail( PAYPAL_ID, 'Invalid Product Info', $error);
		if(PAYPAL_SANDBOX){
			mail( "edgarasf123@gmail.com" , 'Invalid Product', $error);
		}
    }
} else {
    mail( PAYPAL_ID , 'Invalid IPN Validation', $listener->getTextReport());
    if(PAYPAL_SANDBOX){
		mail( "edgarasf123@gmail.com" , 'Invalid IPN Validation', $listener->getTextReport());
	}
}
?>