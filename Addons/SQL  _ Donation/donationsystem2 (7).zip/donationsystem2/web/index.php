<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<?php
	include('config.php');
	$page = $_GET["page"] ?: "games"; // games, servers, products
	$pagegame = $_GET["game"];
	$pageserver = $_GET["server"];
	
	$backpage = "";
	$nextpage = "";
	
	switch ($page) {
		case "games":
			$nextpage = "servers";
			break;
		case "servers":
			$backpage = "games";
			$nextpage = "products";
			break;
		case "products":
			$backpage = "servers";
			$nextpage = "";
			break;
	}
	
?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <title>Donate</title>
 
        
 
        <link href='style.css' rel='stylesheet' type='text/css' />
        
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
		<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
  
		<script>
			var $fragment
			var $msg;
			
			var game;
			
			function enableNext(enable){
				if(enable){
					$(".button-next").removeClass("button-disabled").addClass("button-enabled");
				}else{
					$(".button-next").removeClass("button-enabled").addClass("button-disabled");
				}
			}
			function enableBack(enable){
				if(enable){
					$(".button-back").removeClass("button-disabled").addClass("button-enabled");
				}else{
					$(".button-back").removeClass("button-enabled").addClass("button-disabled");
				}
			}
			function next(){
				
				window.location.href=<?		
				switch ($page) {
					case "games":
						echo "\"".DONATE_URL."index.php?page=servers&game=\"+$('input:radio[name=game]:checked').val()";
						break;
					case "servers":
						echo "\"".DONATE_URL."index.php?page=products&game={$pagegame}&server=\"+$('input:radio[name=server]:checked').val()";
						break;
					case "products":
						echo "\"".DONATE_URL."order.php?pid=\"+id+\"&game={$pagegame}&server={$pageserver}\"";
						break;
				}
				?>;	
			}
			function back(){
				
				window.location.href=<?		
				switch ($page) {
					case "games":
						echo "\"\"";
						break;
					case "servers":
						echo "\"".DONATE_URL."index.php?page=games\"";
						break;
					case "products":
						echo "\"".DONATE_URL."index.php?page=servers&game={$pagegame}\"";
						break;
				}
				?>;	
			}
			
			$(document).ready(function() {
				
				$fragment = $("#fragment").buttonset();
				enableNext(false);
				enableBack(<? echo $page != "games" ? "true" : "false"; ?>);
				
				
				jQuery('#navigation').accordion({
					active: false,
					header: '.head',
					navigation: true,
					event: 'mouseover',
					fillSpace: true,
					animated: 'easeslide'
				});				
				
				
				$('.accordionButton').click(function() {
					if($(this).is('.on') != true) {
						id = $(this).attr( "id" );
						$('.accordionButton').removeClass('on');  
						$('.accordionContent').slideUp('normal');
			   
						if($(this).next().is(':hidden') == true) {
							$(this).addClass('on');		  
							$(this).next().slideDown('normal');
							enableNext(true);
						} 
					 }
				});
				$('.accordionContent').hide();
				
				
				
				
				
			});
			
		</script>
    </head>
    <body>
		<div id="tabs">
			<ul>
				<li><a href="#fragment-1"><div  class="numberCircle <? echo $page == "games" ? "active" : ""; ?>">1</div ><span>Games</span></a></li>
				<li><a href="#fragment-2"><div  class="numberCircle <? echo $page == "servers" ? "active" : ""; ?>">2</div ><span>Servers</span></a></li>
				<li><a href="#fragment-3"><div  class="numberCircle <? echo $page == "products" ? "active" : ""; ?>">3</div ><span>Products</span></a></li>
				<li><a href="#fragment-4"><div  class="numberCircle">4</div ><span>Checkout</span></a></li>
			</ul>
			
			<div id="fragment">
				<? 
				if($page == "games"){
					$count = 0;
					foreach ($GAMES as $gameid => $game) {
						if($game["display"]){
							$count++;
							?>
							<input type="radio" id="gradio<? echo $count; ?>" name="game" value="<? echo $gameid; ?>" onclick="enableNext(true);"/>
							<label for="gradio<? echo $count; ?>"><img src="<? echo $game["icon"]; ?>"/><span><? echo $game["name"]; ?></span></label>
							<?
						}
					}
				}elseif($page == "servers"){
					$count = 0;
					foreach ($GAMES[$pagegame]["servers"] as $serverid) {
						$count++;
						?>
						<input type="radio" id="gradio<? echo $count; ?>" name="server" value="<? echo $serverid; ?>" onclick="enableNext(true);"/>
						<label for="gradio<? echo $count; ?>"><img src="<? echo $SERVERS[$serverid]["icon"]; ?>"/><span><? echo $SERVERS[$serverid]["name"]; ?></span></label>
						<?
					}
				}elseif($page == "products"){
					?><div id="wrapper"><?
					foreach ($SERVERS[$pageserver]["products"] as $productid) {
						$count++;
						?>
						<div id="<? echo $productid; ?>" class="accordionButton"><? echo $PRODUCTS[$productid]["title"]; ?></div>
						<div id="c<? echo $productid; ?>" class="accordionContent">
							<? echo $PRODUCTS[$productid]["description"]; ?>
						</div>
						<?
					}
					
					?></div><?
				}
				?>
			</div>
			
			<div id="foot">
				<div class="selection-text"></div>
				<span class="button button-back"> 
					<a href="javascript:void(0)" onclick="back()">
						<span class="arrows">&#171;&nbsp;</span>Back
					</a>
				</span>    
				<span class="button button-next"> 
					<a href="javascript:void(0)" onclick="next()">
						Next<span class="arrows">&nbsp;&#187;</span>
					</a>
				</span>
			</div>
		</div>
    </body>
</html>