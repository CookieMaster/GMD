<?php

define("DB_HOST", "l"); // MySQL Server
define("DB_USERNAME", ""); // MySQL Username
define("DB_PASSWORD", ""); // MySQL Password
define("DB_DATABASE", ""); // MySQL Database. Not recommended to use same database that your server(s) use, but if you want you can

/*
To test donation system, enable sandbox and during purchase use following sandbox account:
email: edgarasf123-buyer@gmail.com
password: testtest1

When done testing switch sandbox off, and replace "realemail@example.com" with your email
*/
define("PAYPAL_CURRENCY", "USD"); // Currency for your system
define("PAYPAL_SANDBOX", true); // Sandbox mode
define("PAYPAL_ID", PAYPAL_SANDBOX ? "edgarasf123-facilitator@gmail.com" : "realemail@example.com"); // Replace realemail@example.com with your paypal login


define("STEAM_API", ""); // http://steamcommunity.com/dev/apikey
define("DONATE_URL", "http://example.com/donate/"); // Address where the system is located


$GAMES = array( // All games
	"gmod" => array( // GameID
		"name" => "Garry's mod", //Game name
		"icon" => "icons/gmod.png", //Game icon
		"display" => true, // Should display on front page
		"servers" => array("darkrp") // What servers does it have( defined in $SERVERS section), use ServerID
	)
);
$SERVERS = array( // All servers
	"darkrp" => array( // ServerID
		"name" => "MyServer DarkRP", // Server Name
		"icon" => "icons/gmod.png", // Server Icon
		"dbtable" => "darkrp_orders", // Server database
		"products" => array(1) // What products does this server have( defined in $PRODUCTS section ), use ProductID
	)
);
$PRODUCTS = array( // All products
	1 => array( // ProductID, must be numbers
		"title" => "Admin Donor", //Title that is displayed on third section(Products)
		"buytitle" => "DarkRP - Admin Donor", //Title that is displayed on fourth section(Checkout) and during PayPal purchase
				// Description is shown in third section when you select product, its in HTML
		"description" => " 
			<b>Price: <b style='color:green;'>$25</b></b>
			</br>
			<b>Features:</b><br/>
			<b>1.</b> You get to be donor admin<br/>
			<b>2.</b> 50,000 ingame cash<br/>
			<b>3.</b> 30,000 points<br/>
			<b>4.</b> Donor jobs<br/><br/>
			<b style='color:red;'>This rank is valid for 30 days and if abused it will be taken away.</b>",
		"price" => 10, // Price of your product
		"servers" => array( // Servers that this product going to be activated on
			"darkrp" => array( // ServerID
				"offline" => false, // Should ran when player is not connected? Not recommended 
				"execute" => array( // Execute certain commands, please refer to readme.html
					"rank" => array( "group" => "admin" , "duration" => 0),
					"darkrp_money" => 50000,
					"pointshop_points" => 30000,
					"print" => array( array(255,0,0) ,"You have bought Admin Donor!" ),
					"broadcast" => array( array(255,0,0) ,"%name% have bought Admin Donor!" ),
					"lua" => "ServerLog(PLAYER:Nick() .. ' bought admin donor\\n')" // <- Dont put comma at the end of array
				)
			)
		)
	)
);

// DONT TOUCH THIS
define("PAYPAL_URL", PAYPAL_SANDBOX ? "https://www.sandbox.paypal.com/cgi-bin/webscr" : "https://www.paypal.com/cgi-bin/webscr"   )
?>
