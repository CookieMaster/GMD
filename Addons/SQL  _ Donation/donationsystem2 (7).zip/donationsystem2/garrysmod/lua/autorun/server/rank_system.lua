local DB_HOST = ""
local DB_PORT = 3306
local DB_DATABASE = ""
local DB_USERNAME = ""
local DB_PASSWORD = ""
local DB_TABLE = ""

require("mysqloo")
if not mysqloo then
	Error("[RankSystem] No mysqloo was found")
	return nil
end
RankSystem = {}
RankSystem.players = {}

local queue = {} 
local db = mysqloo.connect( DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE, DB_PORT )

local function query( sql, callback ) -- If not connected, connect and repeat query
	local q = db:query( sql )
	if not q then	
		table.insert( queue, { sql, callback } )
		db:connect()
		return
	end
	function q:onSuccess( data )
		callback( data )
	end
	function q:onError( err )
		if db:status() == mysqloo.DATABASE_NOT_CONNECTED then
			table.insert( queue, { sql, callback } )
			db:connect()
			return
		end
		Error( "[RankSystem] Query Error:", err, " sql: ", sql, "\n" )
	end
	q:start()
end

local function getSteamID( ply )
	if type(ply) == "Player" then
		return string.upper( ply:SteamID() )
	elseif type(ply) == "string" then
		return string.upper( ply )
	end
	return nil
end

function db:onConnected()	
	ServerLog("[RankSystem] Connected to database\n")

	for k, v in pairs( queue ) do
		query( v[ 1 ], v[ 2 ] )
	end
	queue = {}
end
 
function db:onConnectionFailed( err )
    Error( "[RankSystem] Connection to database failed!\n" )
    Error( "[RankSystem] Error:", err, "\n" )
end
db:connect()


local function DatabaseLoad()
	query([[
	CREATE TABLE IF NOT EXISTS `]]..DB_TABLE..[[` (
	`steamid` varchar(40) NOT NULL,
	`rank` varchar(20) NOT NULL,
	`expire` INT UNSIGNED NOT NULL,
	UNIQUE KEY (`steamid`)) ]], function()	
		query("SELECT * FROM `"..DB_TABLE.."`", function(data)
			for _, plydata in pairs(data) do
				if type(plydata) == "table" then
					RankSystem.players[plydata.steamid] = {}
					RankSystem.players[plydata.steamid].rank = data.rank
					RankSystem.players[plydata.steamid].expire = tonumber(data.expire)
				end
			end
		end)
	end)
end
hook.Add( "Initialize", "RankSystemDatabaseLoad", DatabaseLoad )

function RankSystem.AddUser( ply, rank, duration )
	local steamid = getSteamID( ply )
	if steamid == nil then return end
	
	ULib.ucl.addUser( steamid, allows, denies, rank )

	RankSystem.players[steamid] = {}
	RankSystem.players[steamid].rank = rank
	if duration > 0 then
		RankSystem.players[steamid].expire = os.time()+duration
	else
		RankSystem.players[steamid].expire = 0
	end

	
	RankSystem.Save( steamid )
	
end
function RankSystem.RemoveUser( ply )
	local steamid = getSteamID( ply )
	if steamid == nil then return end
	if not RankSystem.players[steamid] then return end
	
	RankSystem.players[steamid] = nil
	ULib.ucl.removeUser( steamid )
	RankSystem.Save( steamid )
end
function RankSystem.Save( ply )
	local steamid = getSteamID( ply )
	if steamid == nil then return end
	
	if not RankSystem.players[steamid] then
		query("DELETE FROM `"..DB_TABLE.."` WHERE `steamid` = '" .. steamid .. "'",  function() end)
	else
		local plydata = RankSystem.players[steamid]
		query("INSERT INTO `"..DB_TABLE.."` VALUES (\"" ..steamid.. "\", \"" ..plydata.rank.. "\", " .. plydata.expire .. ") ON DUPLICATE KEY UPDATE `rank`=\""..plydata.rank.."\",`expire`="..plydata.expire.."", function() end)
	end
end


function RankSystem.AddTime( ply, t )
	local steamid = getSteamID( ply )
	if steamid == nil then return end
	if not RankSystem.players[steamid] then return end
	if type(t) != "number" then return end
	
	RankSystem.players[steamid].expire = RankSystem.players[steamid].expire + t
	RankSystem.Save( ply )
end
function RankSystem.SetTime( ply, t )
	local steamid = getSteamID( ply )
	if steamid == nil then return end
	if not RankSystem.players[steamid] then return end
	if type(t) != "number" then return end
	
	RankSystem.players[steamid].expire = os.time()+t
	RankSystem.Save( ply )
end
function RankSystem.GetExpireTime( ply )
	local steamid = getSteamID( ply )
	if steamid == nil then return end
	if not RankSystem.players[steamid] then return end
	
	return RankSystem.players[steamid].expire
end
function RankSystem.GetRank( ply )
	local steamid = getSteamID( ply )
	if steamid == nil then return end
	if not RankSystem.players[steamid] then return end
	
	return RankSystem.players[steamid].rank	
end


timer.Create( "RankSystemCheck", 60, 0, function()
	for steamid, plydata in pairs(RankSystem.players) do 
		if type(plydata) == "table" and type(plydata.expire) == "number" and plydata.expire > 0 and plydata.expire < os.time() then
			RankSystem.RemoveUser( steamid )
		end
	end
end)