local DB_HOST = ""
local DB_PORT = 3306
local DB_DATABASE = ""
local DB_USERNAME = ""
local DB_PASSWORD = ""
local DB_TABLE = ""

require("mysqloo")
if not mysqloo then
	Error("[RankSystem] No mysqloo was found")
	return nil
end
DonationSystem = {}
util.AddNetworkString( "DonationSystemColorChat" )
util.AddNetworkString( "DonationSystemConCommand" )

DonationSystem.OnlineCommands = {
	["rank"] = function( ply, args )
		local group = args["group"]
		local duration = args["duration"] or 0
		RankSystem.AddUser( ply, group, duration )
	end,
	["darkrp_money"] = function( ply, args )
		local succ, err = pcall( function() ply:AddMoney(tonumber(args)) end )
		if not succ then
			Error("[DonationSystem] Error executing darkrp_money command, Error: "..err.."\n")
		end	
	end,
	["pointshop_points"] = function( ply, args )
		local succ, err = pcall( function() ply:PS_GivePoints(tonumber(args)) end )
		if not succ then
			Error("[DonationSystem] Error executing pointshop_points command, Error: "..err.."\n")
		end	
	end,
	["print"] = function( ply, args )
		if type(args) == "string" then
			args = string.Replace( args, "%name%", tostring(ply:Name()) )
			args = string.Replace( args, "%steamid%", tostring(ply:SteamID()) )
			args = string.Replace( args, "%steamid64%", tostring(ply:SteamID()) )
			args = string.Replace( args, "%uniqueid%", tostring(ply:UniqueID()) )
			args = string.Replace( args, "%userid%", tostring(ply:UserID()) )
			net.Start( "DonationSystemColorChat" )
				net.WriteTable( {args} )
			net.Send( ply )
		elseif type(args) == "table" then
			for i=1,#args do
				if type(args[i]) == "table" then
					args[i] = Color(args[i][1],args[i][2],args[i][3])
				elseif type(args[i]) == "string" then
					args[i] = string.Replace( args[i], "%name%", tostring(ply:Name()) )
					args[i] = string.Replace( args[i], "%steamid%", tostring(ply:SteamID()) )
					args[i] = string.Replace( args[i], "%steamid64%", tostring(ply:SteamID()) )
					args[i] = string.Replace( args[i], "%uniqueid%", tostring(ply:UniqueID()) )
					args[i] = string.Replace( args[i], "%userid%", tostring(ply:UserID()) )
				end
			end
			net.Start( "DonationSystemColorChat" )
				net.WriteTable( args )
			net.Send( ply )
		end
	end,
	["broadcast"] = function( ply, args )
		if type(args) == "string" then
			args = string.Replace( args, "%name%", tostring(ply:Name()) )
			args = string.Replace( args, "%steamid%", tostring(ply:SteamID()) )
			args = string.Replace( args, "%steamid64%", tostring(ply:SteamID()) )
			args = string.Replace( args, "%uniqueid%", tostring(ply:UniqueID()) )
			args = string.Replace( args, "%userid%", tostring(ply:UserID()) )
			net.Start( "DonationSystemColorChat" )
				net.WriteTable( {args} )
			net.Broadcast( )
		elseif type(args) == "table" then
			for i=1,#args do
				if type(args[i]) == "table" then
					args[i] = Color(args[i][1],args[i][2],args[i][3])
				elseif type(args[i]) == "string" then
					args[i] = string.Replace( args[i], "%name%", tostring(ply:Name()) )
					args[i] = string.Replace( args[i], "%steamid%", tostring(ply:SteamID()) )
					args[i] = string.Replace( args[i], "%steamid64%", tostring(ply:SteamID()) )
					args[i] = string.Replace( args[i], "%uniqueid%", tostring(ply:UniqueID()) )
					args[i] = string.Replace( args[i], "%userid%", tostring(ply:UserID()))
				end
			end
			net.Start( "DonationSystemColorChat" )
				net.WriteTable( args )
			net.Broadcast( )
		end
	end,
	["broadcast_omit"] = function( ply, args )
		if type(args) == "string" then
			args = string.Replace( args, "%name%", tostring(ply:Name()) )
			args = string.Replace( args, "%steamid%", tostring(ply:SteamID()) )
			args = string.Replace( args, "%steamid64%", tostring(ply:SteamID()) )
			args = string.Replace( args, "%uniqueid%", tostring(ply:UniqueID()) )
			args = string.Replace( args, "%userid%", tostring(ply:UserID()) )
			net.Start( "DonationSystemColorChat" )
				net.WriteTable( {args} )
			net.SendOmit( ply )
		elseif type(args) == "table" then
			for i=1,#args do
				if type(args[i]) == "table" then
					args[i] = Color(args[i][1],args[i][2],args[i][3])
				elseif type(args[i]) == "string" then
					args[i] = string.Replace( args[i], "%name%", tostring(ply:Name()) )
					args[i] = string.Replace( args[i], "%steamid%", tostring(ply:SteamID()) )
					args[i] = string.Replace( args[i], "%steamid64%", tostring(ply:SteamID()) )
					args[i] = string.Replace( args[i], "%uniqueid%", tostring(ply:UniqueID()) )
					args[i] = string.Replace( args[i], "%userid%", tostring(ply:UserID()) )
				end
			end
			net.Start( "DonationSystemColorChat" )
				net.WriteTable( args )
			net.SendOmit( ply )
		end
	end,
	["lua"] = function( ply, args )
		local oldPLAYER = PLAYER
		PLAYER =  ply
		RunStringEx( args, "[DonationSystem] Lua:")
		PLAYER = oldPLAYER
	end,
	["server_console"] = function( ply, args )
		for i=1,#args do
			args[i] = string.Replace( args[i], "%name%", tostring(ply:Name()) )
			args[i] = string.Replace( args[i], "%steamid%", tostring(ply:SteamID()) )
			args[i] = string.Replace( args[i], "%steamid64%", tostring(ply:SteamID()) )
			args[i] = string.Replace( args[i], "%uniqueid%", tostring(ply:UniqueID()) )
			args[i] = string.Replace( args[i], "%userid%", tostring(ply:UserID()) )
		end
		RunConsoleCommand( unpack(args) )
	end,
	["client_console"] = function( ply, args )
		for i=1,#args do
			args[i] = string.Replace( args[i], "%name%", tostring(ply:Name()) )
			args[i] = string.Replace( args[i], "%steamid%", tostring(ply:SteamID()) )
			args[i] = string.Replace( args[i], "%steamid64%", tostring(ply:SteamID()) )
			args[i] = string.Replace( args[i], "%uniqueid%", tostring(ply:UniqueID()) )
			args[i] = string.Replace( args[i], "%userid%", tostring(ply:UserID()) )
		end
		net.Start( "DonationSystemConCommand" )
			net.WriteTable( args )
		net.Send( ply )
	end
}
DonationSystem.OfflineCommands = {
	["rank"] = function( steamid, args )
		local group = args["group"]
		local duration = args["duration"] or 0
		RankSystem.AddUser( steamid, group, duration )
	end,
	["broadcast"] = function( steamid, args )
		if type(args) == "string" then
			args = string.Replace( args, "%steamid%", tostring(steamid) )
			net.Start( "DonationSystemColorChat" )
				net.WriteTable( {args} )
			net.Broadcast( )
		elseif type(args) == "table" then
			for i=1,#args do
				if type(args[i]) == "table" then
					args[i] = Color(args[i][1],args[i][2],args[i][3])
				elseif type(args[i]) == "string" then
					args[i] = string.Replace( args[i], "%steamid%", tostring(steamid) )
				end
			end
			net.Start( "DonationSystemColorChat" )
				net.WriteTable( args )
			net.Broadcast( )
		end
	end,
	["lua"] = function( steamid, args )
		local oldSTEAMID = STEAMID
		STEAMID =  steamid
		RunStringEx( args, "[DonationSystem] Lua:")
		STEAMID = oldSTEAMID
	end,
	["server_console"] = function( steamid, args )
		for i=1,#args do
			args[i] = string.Replace( args[i], "%steamid%", tostring(steamid) )
		end
		RunConsoleCommand( unpack(args) )
	end
}


local queue = {} 
local db = mysqloo.connect( DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE, DB_PORT )
local function query( sql, callback ) -- If not connected, connect and repeat query
	local q = db:query( sql )
	if not q then	
		table.insert( queue, { sql, callback } )
		db:connect()
		return
	end
	function q:onSuccess( data )
		callback( data )
	end
	function q:onError( err )
		if db:status() == mysqloo.DATABASE_NOT_CONNECTED then
			table.insert( queue, { sql, callback } )
			db:connect()
			return
		end
		Error( "[DonationSystem] Query Error: ", err, " sql: ", sql, "\n" )
	end
	q:start()
end
function db:onConnected()	
	ServerLog("[DonationSystem] Connected to database\n")

	for k, v in pairs( queue ) do
		query( v[ 1 ], v[ 2 ] )
	end
	queue = {}
end
 
function db:onConnectionFailed( err )
    Error( "[DonationSystem] Connection to database failed!\n" )
    Error( "[DonationSystem] Error:", err, "\n" )
end
db:connect()


function DonationSystem.DatabaseCheck()
	query([[
	CREATE TABLE IF NOT EXISTS `]]..DB_TABLE..[[` (
	`orderid` MEDIUMINT NOT NULL AUTO_INCREMENT,
	`transactionid` varchar(125) NOT NULL,
	`playerid` varchar(40) NOT NULL,
	`execute` TEXT NOT NULL,
	`offline` TINYINT(1) UNSIGNED NOT NULL,
	PRIMARY KEY (orderid))
	]], function() end)
end
hook.Add( "Initialize", "DonationSystemDatabaseCheck", DonationSystem.DatabaseCheck )

hook.Add( "PlayerInitialSpawn", "DonationSystemPlayerJoin", function(ply)
	ply:SendLua( [[ net.Receive( "DonationSystemColorChat", function( len ) chat.AddText( unpack( net.ReadTable() ) ) end ) ]] )
	ply:SendLua( [[ net.Receive( "DonationSystemConCommand", function( len ) RunConsoleCommand( unpack( net.ReadTable() ) ) end ) ]] )
end)

function DonationSystem.CheckOffline()
	query("SELECT * FROM `" .. DB_TABLE .. "` WHERE `offline` = 1", function(orders)
		for orderid, orderdata in pairs(orders) do
			local execs = util.JSONToTable(orderdata.execute)
			for command, args in pairs(execs) do
				local succ, err = pcall( function() DonationSystem.OnlineCommands[command](orderdata.playerid,args) end )
				if not succ then
					Error("[DonationSystem] Error running offline command '"..command.."'. Error: "..err.."\n")
				end
			end		
			ServerLog("[DonationSystem] Activated offline order("..orderdata.orderid..") "..orderdata.transactionid.." for "..orderdata.playerid.."\n")
			query("DELETE FROM `" .. DB_TABLE .. "` WHERE `orderid` = '" .. orderdata.orderid .. "'",  function() end)
		end
	end)
end
function DonationSystem.CheckPlayer(ply)
	query("SELECT * FROM `" .. DB_TABLE .. "` WHERE `playerid` = \""..ply:SteamID().."\" AND `offline` = 0", function(orders)
		for orderid, orderdata in pairs(orders) do
			local execs = util.JSONToTable(orderdata.execute)
			for command, args in pairs(execs) do
				local succ, err = pcall( function() DonationSystem.OnlineCommands[command](ply,args) end )
				if not succ then
					Error("[DonationSystem] Error running online command '"..command.."'. Error: "..err.."\n")
				end
			end		
			ServerLog("[DonationSystem] Activated online order("..orderdata.orderid..") "..orderdata.transactionid.." for "..ply:Nick().."\n")
			query("DELETE FROM `" .. DB_TABLE .. "` WHERE `orderid` = '" .. orderdata.orderid .. "'",  function() end)
		end
	end)
end

timer.Create( "DonationSystemCheck", 30, 0, function() 
	for k, ply in pairs(player.GetAll()) do
		DonationSystem.CheckPlayer(ply)
	end
	DonationSystem.CheckOffline()
end )
hook.Add("PlayerInitialSpawn", "Donations_MySQL_Load", DonationSystem.CheckPlayer)
