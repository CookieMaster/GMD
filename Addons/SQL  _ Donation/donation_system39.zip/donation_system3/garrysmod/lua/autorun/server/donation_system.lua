
local DONATE_URL = "http://example.com/donate/"
local LINK_AUTH_KEY = ""
local SERVER_ID = ""


-------------------------------------------------------------
-- Leave everything bellow ----------------------------------
-------------------------------------------------------------
DonationSystem = {}
DonationSystem.Logs = {}
DonationSystem.linked = false



local function addlog( str )
	DonationSystem.Logs[#DonationSystem.Logs+1] = {os.date(),str}
	ServerLog("[DonationSystem] "..str.."\n")
end

local function link( tbl, func )
	local tbl = tbl or {}
	tbl["auth_key"] = LINK_AUTH_KEY
	tbl["serverid"] = SERVER_ID
	http.Post( DONATE_URL.."link.php", tbl, 
	function(body) -- Success
		local tbl = util.JSONToTable(body) or {}
		local status = tbl["status"] or "error"
		local result = tbl["result"] or "no result"
		func(status,result)
	end, 
	function(err) -- Failure
		func("error","failed to connect")
	end)
end

link({action="test"},function(status,result)
	if status == "ok" then
		addlog("Linked successfuly")
		DonationSystem.linked = true
	else
		addlog("Failed to link status:"..status.." result: "..result)
		DonationSystem.linked = false
	end
end)
concommand.Add( "ds_printlogs",function( ply,cmd,args,str )
	if IsValid(ply) then return end
	print("DonationSystem Logs:")
	for i=1,#DonationSystem.Logs do
		print(unpack(DonationSystem.Logs[i]))
	end
end )

concommand.Add( "ds_testlink",function( ply,cmd,args,str )
	if IsValid(ply) then return end
	link({action="test"},function(status,result)
		if status == "ok" then
			addlog("Linked successfuly")
			DonationSystem.linked = true
		else
			addlog("Failed to link status:"..status.." result: "..result)
			DonationSystem.linked = false
		end
	end)
end )

util.AddNetworkString( "DonationSystemColorChat" )
util.AddNetworkString( "DonationSystemConCommand" )

DonationSystem.Commands = {
	["darkrp_money"] = function( data, args, ply )
		if not IsValid(ply) then
			addlog("Error executing darkrp_money command, Error: player is not valid")
			return nil
		end
		local succ, err = pcall( function() ply:AddMoney(tonumber(args[1])) end )
		if not succ then
			addlog("Error executing darkrp_money command, Error: "..err)
		end	
	end,
	["pointshop_points"] = function( data, args, ply )
		if not IsValid(ply) then
			addlog("Error executing pointshop_points command, Error: player is not valid")
			return nil
		end
		local succ, err = pcall( function() ply:PS_GivePoints(tonumber(args[1])) end )
		if not succ then
			addlog("Error executing pointshop_points command, Error: "..err)
		end	
	end,
	["print"] = function( data, args, ply )
		if not IsValid(ply) then
			addlog("Error executing print command, Error: player is not valid")
			return nil
		end
		if type(args) == "table" then
			for i=1,#args do
				if type(args[i]) == "table" then
					args[i] = Color(args[i][1],args[i][3],args[i][5])
				elseif type(args[i]) == "string" then
					args[i] = string.Replace( args[i], "%gamename%", tostring(ply:Name()) )
					args[i] = string.Replace( args[i], "%name%", tostring(data.playername) )
					args[i] = string.Replace( args[i], "%orderid%", tostring(data.id) )
					args[i] = string.Replace( args[i], "%transactionid%", tostring(data.transactionid) )
					args[i] = string.Replace( args[i], "%packageid%", tostring(data.packageid) )
					args[i] = string.Replace( args[i], "%steamid%", tostring(ply:SteamID()) )
					args[i] = string.Replace( args[i], "%steamid64%", tostring(ply:SteamID64()) )
					args[i] = string.Replace( args[i], "%uniqueid%", tostring(ply:UniqueID()) )
					args[i] = string.Replace( args[i], "%userid%", tostring(ply:UserID()) )
				end
			end
			net.Start( "DonationSystemColorChat" )
				net.WriteTable( args )
			net.Send( ply )
		end
	end,
	["broadcast"] = function( data, args, ply )
		if type(args) == "table" then
			for i=1,#args do
				if type(args[i]) == "table" then
					args[i] = Color(args[i][1],args[i][3],args[i][5])
				elseif type(args[i]) == "string" then
					args[i] = string.Replace( args[i], "%name%", tostring(data.playername) )
					args[i] = string.Replace( args[i], "%orderid%", tostring(data.id) )
					args[i] = string.Replace( args[i], "%transactionid%", tostring(data.transactionid) )
					args[i] = string.Replace( args[i], "%packageid%", tostring(data.packageid) )
					args[i] = string.Replace( args[i], "%steamid%", tostring(data.playerid) )
					args[i] = string.Replace( args[i], "%uniqueid%", tostring(util.CRC("gm_" .. data.playerid .. "_gm")) )
					if IsValid(ply) then
						args[i] = string.Replace( args[i], "%steamid64%", tostring(ply:SteamID64()) )
						args[i] = string.Replace( args[i], "%gamename%", tostring(ply:Nick()) )
						args[i] = string.Replace( args[i], "%userid%", tostring(ply:UserID()) )
					end
				end
			end
			net.Start( "DonationSystemColorChat" )
				net.WriteTable( args )
			net.Broadcast( )
		end
	end,
	["broadcast_omit"] = function( data, args, ply )
		if type(args) == "table" then
			for i=1,#args do
				if type(args[i]) == "table" then
					args[i] = Color(args[i][1],args[i][3],args[i][5])
					
				elseif type(args[i]) == "string" then
					args[i] = string.Replace( args[i], "%name%", tostring(data.playername) )
					args[i] = string.Replace( args[i], "%orderid%", tostring(data.id) )
					args[i] = string.Replace( args[i], "%transactionid%", tostring(data.transactionid) )
					args[i] = string.Replace( args[i], "%packageid%", tostring(data.packageid) )
					args[i] = string.Replace( args[i], "%steamid%", tostring(data.playerid) )
					args[i] = string.Replace( args[i], "%uniqueid%", tostring(util.CRC("gm_" .. data.playerid .. "_gm")) )
					if IsValid(ply) then
						args[i] = string.Replace( args[i], "%steamid64%", tostring(ply:SteamID64()) )
						args[i] = string.Replace( args[i], "%gamename%", tostring(ply:Nick()) )
						args[i] = string.Replace( args[i], "%userid%", tostring(ply:UserID()) )
					end
				end
			end
			net.Start( "DonationSystemColorChat" )
				net.WriteTable( args )
				
			if IsValid(ply) then
				net.SendOmit( ply )
			else
				net.Broadcast( )
			end
		end
	end,
	["lua"] = function( data, args, ply )
		local oldPLAYER = PLAYER
		local oldSTEAMID = STEAMID
		local oldORDERDATA = ORDERDATA
		
		PLAYER =  ply
		STEAMID =  data.playerid
		ORDERDATA = data
		
		RunStringEx( args[1], "[DonationSystem] Lua: ")
		
		PLAYER = oldPLAYER
		STEAMID = oldSTEAMID
		ORDERDATA = oldORDERDATA
	end,
	["sv_cmd"] = function( data, args, ply )
		for i=1,#args do
			args[i] = string.Replace( args[i], "%name%", tostring(data.playername) )
			args[i] = string.Replace( args[i], "%orderid%", tostring(data.id) )
			args[i] = string.Replace( args[i], "%transactionid%", tostring(data.transactionid) )
			args[i] = string.Replace( args[i], "%packageid%", tostring(data.packageid) )
			args[i] = string.Replace( args[i], "%steamid%", tostring(data.playerid) )
			args[i] = string.Replace( args[i], "%uniqueid%", tostring(util.CRC("gm_" .. data.playerid .. "_gm")) )
			if IsValid(ply) then
				args[i] = string.Replace( args[i], "%steamid64%", tostring(ply:SteamID64()) )
				args[i] = string.Replace( args[i], "%gamename%", tostring(ply:Nick()) )
				args[i] = string.Replace( args[i], "%userid%", tostring(ply:UserID()) )
			end
		end
		RunConsoleCommand( unpack(args) )
	end,
	["disabled"] = function( data, args, ply ) end,
	["cl_cmd"] = function( data, args, ply )
		if not IsValid(ply) then
			addlog("Error executing cl_cmd command, Error: player is not valid")
			return nil
		end
		for i=1,#args do
			args[i] = string.Replace( args[i], "%name%", tostring(data.playername) )
			args[i] = string.Replace( args[i], "%orderid%", tostring(data.id) )
			args[i] = string.Replace( args[i], "%transactionid%", tostring(data.transactionid) )
			args[i] = string.Replace( args[i], "%packageid%", tostring(data.packageid) )
			args[i] = string.Replace( args[i], "%steamid%", tostring(data.playerid) )
			args[i] = string.Replace( args[i], "%uniqueid%", tostring(util.CRC("gm_" .. data.playerid .. "_gm")) )
			
			args[i] = string.Replace( args[i], "%steamid64%", tostring(ply:SteamID64()) )
			args[i] = string.Replace( args[i], "%gamename%", tostring(ply:Nick()) )
			args[i] = string.Replace( args[i], "%userid%", tostring(ply:UserID()) )
		end
		net.Start( "DonationSystemCmd" )
			net.WriteTable( args )
		net.Send( ply )
	end,
	["cancel"] = function( data, args,ply )
		link({action="execute",id=tostring(data.id)},
			function(status, result)
				if status == "ok" then
				else
					addlog("Error executing cancel command, status:"..status.." error:"..result)
				end
			end
		)
	end
}

hook.Add( "PlayerInitialSpawn", "DonationSystemPlayerJoin", function(ply)
	ply:SendLua( [[ net.Receive( "DonationSystemColorChat", function( len ) chat.AddText( unpack( net.ReadTable() ) ) end ) ]] )
	ply:SendLua( [[ net.Receive( "DonationSystemCmd", function( len ) RunConsoleCommand( unpack( net.ReadTable() ) ) end ) ]] )
end)

timer.Create( "DonationSystemCheck", 60, 0, function()
	if not DonationSystem.linked then 
		link({action="test"},function(status,result)
			if status == "ok" then
				addlog("Linked successfuly")
				DonationSystem.linked = true
			else
				addlog("Failed to link status:"..status.." result: "..result)
				DonationSystem.linked = false
			end
		end)
		return nil
	end
	
	
	
	link({action="fetch_commands",timeoffset=tostring(55)},
	function(status, result)
		if status == "ok" then 
			local commands = result
			local funcTime = os.time()
			
			local plyEnts = {}
			for _, ply in pairs(player.GetAll()) do
				if ply:TimeConnected() > 60 then -- Making sure player is fully initialised 
					plyEnts[ply:SteamID()] = ply
				end
			end
			
			local activateR = {}
			local cmdDataR = {}
			
			for _, commanddata in pairs(commands) do
				local ply = plyEnts[tostring(commanddata.playerid)]
				if IsValid(ply) or tonumber(commanddata.online) == 0 then
					activateR[#activateR+1]=commanddata.id
					cmdDataR[commanddata.id]=commanddata
				end
			end
			
			link({action="activate_array",data=util.TableToJSON(activateR)},
			function(status, result)
				if status == "ok" then
					for id, changed in pairs(result) do
						if tonumber(changed)>0 then
							if cmdDataR[id] != nil then
								timer.Simple( math.max(0,tonumber(cmdDataR[id].timeoffset)+funcTime-os.time()), function() 
									local commanddata = cmdDataR[id]
									local ply = plyEnts[tostring(commanddata.playerid)]
									if IsValid(ply) or tonumber(commanddata.online) == 0 then
										local args = commanddata.command
										local command = table.remove( args, 1 )
										local succ, err = pcall( function() DonationSystem.Commands[command](commanddata,args,ply) end )
										if succ then
											addlog("Activated command '"..command.."'("..id..")")
										else
											addlog("Error running command '"..command.."'. Error: "..err)
										end
									else
										link({action="deactivate",id=tostring(id)},function(status, result) end,
											function(status, result)
												addlog("Error deactivating commands, status:"..status.." result:"..result)
											end
										)	
									end
								end)
							else
								addlog("Error, command("..id..") missing data")
							end
						else
							addlog("Error, command("..id..") already was activated, status:"..status.." result:"..result)
						end
					end
				else
					addlog("Error activating commands, status:"..status.." result:"..result)
				end
			end)
		else
			addlog("Error fetching offline commands, status:"..status.." result:"..result)
		end
	end)
	
end )