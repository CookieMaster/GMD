<?php
include('config.php');
$paypal_id = PAYPAL_ID;
if(PAYPAL_SANDBOX){$paypal_id = PAYPAL_ID_SANDBOX;}

// Check if request valid
include('ipnlistener.php');
$listener = new IpnListener();
$listener->use_sandbox = PAYPAL_SANDBOX;
try {
    $listener->requirePostMethod();
    $verified = $listener->processIpn();
} catch (Exception $e) {
	die("error while validating data.");
}

if ($verified) {
    $pid = $_POST['item_number'];
	$tid = $_POST['txn_id'];
	$cid = $_POST['custom'];
	$price=$PACKAGES[$pid]["price"];
	
	if (	//Check if data match with package data
		$_POST['payment_status'] == "Completed"
		&& strtolower( $_POST['receiver_email'] ) == strtolower( $paypal_id )
		&& doubleval( $_POST['mc_gross'] ) == $price 
		&& $_POST['mc_currency'] == PAYPAL_CURRENCY)
		{
		echo "<center>Transaction was successful, you should receive your package soon.</center>";
	}else{
		if($_POST['payment_status'] == "Pending" ){
			if($_POST['pending_reason'] == "multi-currency"){
				echo "Transaction is pending, contact admin to resolve the problem.";
			}
		}else{
			echo "Transaction is not completed, contact admin to resolve this problem.<br><br>Transaction Report: <pre>".$listener->getTextReport()."</pre>";
		}
    }
}else{
	echo "invalid request";
}