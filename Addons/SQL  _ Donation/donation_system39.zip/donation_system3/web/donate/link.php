<?php
include('config.php');

$auth_key = $_REQUEST['auth_key'];
$serverid = $_REQUEST['serverid'];
$action = $_REQUEST['action'];

if($auth_key != LINK_AUTH_KEY){
	die(json_encode(array(status=>"error",result=>"invalid auth_key")));
}

if(!array_key_exists( $serverid, $SERVERS)){
	die(json_encode(array(status=>"error",result=>"invalid serverid")));
}

$link = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
if (!$link) {
	die(json_encode(array(status=>"error",result=>"can't connect to database")));
}
// Check if orders table exist
$query = "CREATE TABLE IF NOT EXISTS `commands` (
id MEDIUMINT NOT NULL AUTO_INCREMENT,
serverid varchar(40) NOT NULL,
packageid int(6) unsigned NOT NULL,
online TINYINT(1) UNSIGNED NOT NULL,
commandid int(6) unsigned NOT NULL,
delay INT UNSIGNED NOT NULL,
activatetime INT UNSIGNED NOT NULL,
command TEXT NOT NULL,
activated TINYINT(1) UNSIGNED NOT NULL,
transactionid varchar(125) NOT NULL,
playerid varchar(40) NOT NULL,
playername varchar(40) NOT NULL, 
PRIMARY KEY (id))";
mysqli_query($link, $query);
mysqli_close($link);

switch ($action) {
    case "test":
		echo json_encode(array(status=>"ok",result=>""));
        break;
    case "execute":
        $cmdid = intval($_REQUEST["id"]);
		$link = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
		if (!$link) {
			die( json_encode(array(status=>"error",result=>"can't connect to database")) );
		}
		$query = "SELECT command, transactionid, playerid FROM commands WHERE id=?";
		
		$stmt = mysqli_stmt_init($link);
		if (mysqli_stmt_prepare($stmt, $query)) {
			mysqli_stmt_bind_param($stmt, "i", $cmdid);
			mysqli_stmt_bind_result($stmt, $data_command, $tid, $playerid);
			mysqli_stmt_execute($stmt);
			
			if(mysqli_stmt_fetch($stmt)){
				$args = json_decode($data_command);
				$cmd = array_shift($args);
				switch ($cmd) {
					case "cancel":
						
						if(isset($args["includeself"])){ $d_excludeself = $args["excludeself"]; }else{ $d_excludeself = $args[0]; }
						if(isset($args["serverid"])){ $d_serverid = $args["serverid"]; }else{ $d_serverid = $args[1]; }
						if(isset($args["packageid"])){ $d_packageid = $args["packageid"]; }else{ $d_packageid = $args[2]; }
						if(isset($args["online"])){ $d_online = $args["online"]; }else{ $d_online = $args[3]; }
						if(isset($args["delay"])){ $d_delay = $args["delay"]; }else{ $d_delay = $args[4]; }
						if(isset($args["commandid"])){ $d_commandid = $args["commandid"]; }else{ $d_commandid = $args[5]; }
						
						
						if( count($args) >= 7 ){
							echo json_encode(array(status=>"error",result=>"arguments can't exceed 6"));
						}elseif( count($args) >= 1 && gettype($d_excludeself) != "boolean"){
							echo json_encode(array(status=>"error",result=>"invalid 'excludeself' argument(1), expected boolean, got ".gettype($d_excludeself).": ".$d_excludeself));
						}elseif( count($args) >= 2 && gettype($d_serverid) != "string"){
							echo json_encode(array(status=>"error",result=>"invalid 'serverid' argument(2), expected string, got ".gettype($d_serverid)));
						}elseif( count($args) >= 3 && !is_numeric($d_packageid) ){
							echo json_encode(array(status=>"error",result=>"invalid 'packageid' argument(3), expected number, got : ".$d_packageid));
						}elseif( count($args) >= 4 && gettype($d_online) != "boolean"){
							echo json_encode(array(status=>"error",result=>"invalid 'online' argument(4), expected boolean, got ".gettype($d_online).": ".$d_online));
						}elseif( count($args) >= 5 && !is_numeric($d_delay)){
							echo json_encode(array(status=>"error",result=>"invalid 'delay' argument(5), expected number, got ".gettype($d_delay).": ".$d_delay));
						}elseif( count($args) >= 6 && !is_numeric($d_commandid)){
							echo json_encode(array(status=>"error",result=>"invalid 'commandid' argument(6), expected number, got ".gettype($d_commandid).": ".$d_commandid));
						}else{ //All arguments are validated
							
							$query1 = "UPDATE commands SET activated=1 WHERE playerid = ?";
							if(count($args)>=1){
								if($d_excludeself){
									$query1 = $query1." AND transactionid <> ?";
								}else{
									$query1 = $query1." AND (transactionid <> ? OR 1)"; // A small hack
								}
							}
							if(count($args)>=2){$query1 = $query1." AND serverid = ?";}
							if(count($args)>=3){$query1 = $query1." AND packageid = ?";}
							if(count($args)>=4){$query1 = $query1." AND online = ?";}
							if(count($args)>=5){$query1 = $query1." AND delay = ?";}
							if(count($args)>=6){$query1 = $query1." AND commandid = ?";}
							
							$link1 = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
							$stmt1 = mysqli_stmt_init($link1);
							if (mysqli_stmt_prepare($stmt1, $query1)) {
								if(count($args)==0){mysqli_stmt_bind_param($stmt1, "i", $playerid);}
								elseif(count($args)==1){mysqli_stmt_bind_param($stmt1, "is", $playerid, $tid);}
								elseif(count($args)==2){mysqli_stmt_bind_param($stmt1, "iss", $playerid, $tid, $d_serverid);}
								elseif(count($args)==3){mysqli_stmt_bind_param($stmt1, "issi", $playerid, $tid, $d_serverid, $d_packageid);}
								elseif(count($args)==4){mysqli_stmt_bind_param($stmt1, "issii", $playerid, $tid, $d_serverid, $d_packageid, $d_online);}
								elseif(count($args)==5){mysqli_stmt_bind_param($stmt1, "issiii", $playerid, $tid, $d_serverid, $d_packageid, $d_online, $d_delay);}
								elseif(count($args)==6){mysqli_stmt_bind_param($stmt1, "issiiii", $playerid, $tid, $d_serverid, $d_packageid, $d_online, $d_delay, $d_commandid);}
								
								mysqli_stmt_execute($stmt1);
								echo json_encode(array(status=>"ok",result=>mysqli_affected_rows($link1)));
							}else{
								echo json_encode(array(status=>"error",result=>"couldn't execute sql query1 ".mysqli_error ( $link1 )));
							}
							mysqli_stmt_close($stmt1);
							mysqli_close($link1);
						}
						break;
					default:
						echo json_encode(array(status=>"error",result=>"no such command"));
						break;
				}
			}else{
				echo json_encode(array(status=>"error",result=>"no such command id was found"));
			}
		}else{
			echo json_encode(array(status=>"error",result=>"couldn't execute sql query ".mysqli_error ( $link )));
		}
		mysqli_stmt_close($stmt);	
		mysqli_close($link);
		
        break;
    case "activate_array":
		$cmds = json_decode($_REQUEST["data"]);
		$link = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
		if (!$link) {
			die( json_encode(array(status=>"error",result=>"can't connect to database")));
		}
		
		$result = array();
		foreach($cmds as $cmdid){
			$query = "UPDATE commands SET activated='1' WHERE id=?";
			$stmt = mysqli_stmt_init($link);
			if (mysqli_stmt_prepare($stmt, $query)) {
				mysqli_stmt_bind_param($stmt, "i", $cmdid);
				mysqli_stmt_execute($stmt);
				$result[$cmdid]=mysqli_affected_rows ( $link );
			}
			mysqli_stmt_close($stmt);
		}		
		mysqli_close($link);
		echo json_encode(array(status=>"ok",result=>$result));
		
        break; 
	
    case "activate":
        $cmdid = intval($_REQUEST["id"]);
		$link = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
		if (!$link) {
			die( json_encode(array(status=>"error",result=>"can't connect to database")));
		}
		$query = "UPDATE commands SET activated='1' WHERE id=?";
		$stmt = mysqli_stmt_init($link);
		if (mysqli_stmt_prepare($stmt, $query)) {
			mysqli_stmt_bind_param($stmt, "i", $cmdid);
			mysqli_stmt_execute($stmt);
			echo json_encode(array(status=>"ok",result=>mysqli_affected_rows ( $link )));
		}else{
			echo json_encode(array(status=>"error",result=>"couldn't execute sql query ".mysqli_error ( $link )));
		}
		mysqli_stmt_close($stmt);	
		mysqli_close($link);
        break; 
	
    case "deactivate":
        $cmdid = intval($_REQUEST["id"]);
		$link = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
		if (!$link) {
			die( json_encode(array(status=>"error",result=>"can't connect to database")));
		}
		$query = "UPDATE commands SET activated='0' WHERE id=?";
		$stmt = mysqli_stmt_init($link);
		if (mysqli_stmt_prepare($stmt, $query)) {
			mysqli_stmt_bind_param($stmt, "i", $cmdid);
			mysqli_stmt_execute($stmt);
			echo json_encode(array(status=>"ok",result=>mysqli_affected_rows ( $link )));
		}else{
			echo json_encode(array(status=>"error",result=>"couldn't execute sql query ".mysqli_error ( $link )));
		}
		mysqli_stmt_close($stmt);	
		mysqli_close($link);
        break;
    case "fetch_commands":
		$link = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
		if (!$link) {
			die( json_encode(array(status=>"error",result=>"can't connect to database")));
		}

	
		$timeoffset = time()+intval($_REQUEST['timeoffset']);
	
		$query = "
		SELECT 
			id, 
			packageid,
			delay,
			activatetime, 
			command,
			transactionid, 
			playerid, 
			playername,
			online
		FROM commands 
		WHERE 
			serverid = ?
			AND activatetime <= ?
			AND activated = 0";
		
			
		$stmt = mysqli_stmt_init($link);
		if (mysqli_stmt_prepare($stmt, $query)) {
			mysqli_stmt_bind_param($stmt, "si", $serverid,$timeoffset);
			
			mysqli_stmt_bind_result($stmt, 
				$data_id,
				$data_packageid,
				$data_delay,
				$data_activatetime,
				$data_command,
				$data_transactionid,
				$data_playerid,
				$data_playername,
				$data_online
			);
			mysqli_stmt_execute($stmt);
			$count = 0;
			$data = array();
			while(mysqli_stmt_fetch($stmt)){
				$data[$count] = array(
					id => $data_id,
					packageid => $data_packageid,
					delay => $data_delay,
					activatetime => $data_activatetime,
					command => json_decode($data_command),
					transactionid => $data_transactionid,
					playerid => $data_playerid,
					playername => $data_playername,
					timeoffset => max($data_activatetime-time(),0),
					online => $data_online
				);
				$count++;
			}
			echo json_encode(array(status=>"ok",result=>$data));
		}else{
			echo json_encode(array(status=>"error",result=>"couldn't execute sql query ".mysqli_error ( $link )));
		}
		mysqli_stmt_close($stmt);	
	
	mysqli_close($link);
		break;
    default:
		die(json_encode(array(status=>"error",result=>"unknown action")));
}