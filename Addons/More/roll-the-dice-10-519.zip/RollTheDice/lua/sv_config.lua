// Admin mod constants. Don't touch this. If you have a custom admin mod to add however..
ADMIN_ULX = 1
ADMIN_EVOLVE = 2

// Now for the ACTUAL options.
RTD.Config = {
	Disabled = false, -- Self-explanatory.

	Cooldown = 180, -- The default cooldown. 60 seconds = 1 minute
	PointShop_Cost = 10, -- If PointShop is active, should rolling the dice cost an amount of points?
	EnableHUD = true, -- Enable HUD display of the cooldown?
	
	AdminUsergroup = ADMIN_EVOLVE, -- From which admin mod's usergroups should we rely on? (see above and below)
}

// Custom settings for usergroups.
// Supports: ULX, Evolve
RTD.Usergroups = {
	[ADMIN_ULX] = {
		["admin"] = {
			Disabled = false,
			Cooldown = 0,
			PointShop_Cost = 0
		},
		["noob"] = {
			Disabled = true,
			Cooldown = 0,
			PointShop_Cost = 0
		},
	},
	[ADMIN_EVOLVE] = {
		["admin"] = {
			Disabled = false,
			Cooldown = 0,
			PointShop_Cost = 0
		},
		["noob"] = {
			Disabled = true,
			Cooldown = 0,
			PointShop_Cost = 0
		},
	}
}

concommand.Add("rtd_enable", function(ply, cmd, args)
	if (!ply:IsAdmin()) then return end
	
	local i = tonumber(args[1])
	if (!i) then
		RTD.Config.Disabled = not RTD.Config.Disabled
	else
		RTD.Config.Disabled = not util.tobool(i)
	end

	RTD:SendColoredChatMessage(ply, Color(0, 255, 100), "[RTD] ", color_white, (RTD.Config.Disabled and "Disabled" or "Enabled") .. " Roll The Dice.")
end)

-- Customize your function to check if players can RTD here
-- Returns: boolean <can rtd>, number <cooldown>
function RTD:CanRTD(ply)
	if (self.Config.Disabled) then
		self:SendColoredChatMessage(ply, Color(0, 255, 100), "[RTD] ", color_white, "Rolling the dice is disabled.")
		return false
	end

	local disabled = false
	local cooldown = self.Config.Cooldown
	local cost = self.Config.PointShop_Cost
	
	-- apply the individual usergroup settings; each admin mod has a different way of getting the usergroup, so..
	local usergroup
	local usrmode = self.Config.AdminUsergroup
	if (ULib ~= nil and usrmode == ADMIN_ULX) then
		usergroup = ULib.ucl.users[ply:SteamID()].group
	elseif (ply.EV_GetRank and usrmode == ADMIN_EVOLVE) then
		usergroup = ply:EV_GetRank()
	end
	
	if (usergroup and self.Usergroups[usrmode][usergroup]) then
		local usr = self.Usergroups[usrmode][usergroup]
		
		disabled = usr.Disabled or false
		cooldown = usr.Cooldown
		cost = usr.PointShop_Cost
	end

	if (disabled) then
		self:SendColoredChatMessage(ply, Color(0, 255, 100), "[RTD] ", color_white, "You are not allowed to roll the dice.")
		return false
	end
	
	-- ..then check if a cost should apply
	if (PS and cost > 0) then
		if (ply:PS_HasPoints(cost)) then
			ply:PS_TakePoints(cost)
			self:SendColoredChatMessage(ply, Color(0, 255, 100), "[RTD] ", color_white, "You have spent ", Color(0, 255, 255), cost .. " points ", color_white, "to roll the dice.")
			return true, cooldown
		else
			self:SendColoredChatMessage(ply, Color(0, 255, 100), "[RTD] ", color_white, "Rolling the dice costs ", Color(255, 0, 0), cost, color_white, " points. You cannot afford that!")
			return false
		end
	end

	return true, cooldown
end