RTD = {}

if (SERVER) then
	AddCSLuaFile("cl_rtd.lua")

	include("sv_rtd.lua")
	include("sv_config.lua")
else
	include("cl_rtd.lua")
end