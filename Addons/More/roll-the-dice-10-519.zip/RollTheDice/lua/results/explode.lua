RESULT.Name = "Explode"

function RESULT:Trigger(ply)
	local eff = EffectData()
	eff:SetStart(ply:GetPos())
	eff:SetOrigin(ply:GetPos())
	eff:SetScale(3)
	util.Effect("HelicopterMegaBomb", eff)
	
	ply:EmitSound("ambient/explosions/explode_1.wav")
	ply:Kill()
end

function RESULT:ShowMessage(ply)
	RTD:BroadcastMessageAboutPlayer(ply, "has ", Color(255, 0, 0), "exploded", color_white, "!")
end