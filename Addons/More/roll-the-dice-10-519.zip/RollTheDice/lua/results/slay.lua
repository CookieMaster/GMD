RESULT.Name = "Kill"

function RESULT:Trigger(ply)
	ply:Kill()
end

function RESULT:ShowMessage(ply)
	RTD:BroadcastMessageAboutPlayer(ply, "has been", Color(255, 0, 0), " slain", color_white, "!")
end