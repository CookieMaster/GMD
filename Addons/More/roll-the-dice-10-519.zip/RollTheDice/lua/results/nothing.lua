RESULT.Name = "Nothing"

function RESULT:Trigger(ply)
end

function RESULT:ShowMessage(ply)
	RTD:BroadcastMessageAboutPlayer(ply, "has received ", Color(0, 0, 255), "nothing", color_white, ".")
end