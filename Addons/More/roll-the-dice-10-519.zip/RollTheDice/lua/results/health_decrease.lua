RESULT.Name = "Health Increase"

function RESULT:Trigger(target)
	local i = math.Clamp(target:Health() - math.random(10, 30), 1, target:Health())

	target:SetHealth(i)
	RTD:BroadcastMessageAboutPlayer(target, "had their health ", Color(255, 0, 0), "decreased", color_white, " to ", Color(255, 0, 0), i, color_white, ".")
end

function RESULT:ShowMessage(ply)
end