RESULT.Name = "Health Increase"

function RESULT:Trigger(target)
	local i = 100 + math.random(20, 40)

	target:SetHealth(i)
	RTD:BroadcastMessageAboutPlayer(target, "had their health ", Color(0, 255, 0), "increased", color_white, " to ", Color(0, 255, 0), i, color_white, ".")
end

function RESULT:ShowMessage(ply)
end