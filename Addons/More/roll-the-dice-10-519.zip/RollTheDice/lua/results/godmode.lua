RESULT.Name = "Godmode"

function RESULT:Trigger(ply)
	ply:GodEnable()
	
	timer.Simple(15, function()
		if (ply and ply:IsValid()) then
			ply:GodDisable()
			ply:ChatPrint("God mode disabled.")
			RTD:SendColoredChatMessage(ply, "'s god mode has been disabled.")
		end
	end)
end

function RESULT:ShowMessage(ply)
	RTD:BroadcastMessageAboutPlayer(ply, "has been granted ", Color(0, 255, 0), "god mode", color_white, " for 15 seconds.")
end