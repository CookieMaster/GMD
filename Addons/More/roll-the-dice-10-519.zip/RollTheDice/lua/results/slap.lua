RESULT.Name = "Slap"

SLAP_SOUNDS = {
	"physics/body/body_medium_impact_hard1.wav",
	"physics/body/body_medium_impact_hard2.wav",
	"physics/body/body_medium_impact_hard3.wav",
	"physics/body/body_medium_impact_hard5.wav",
	"physics/body/body_medium_impact_hard6.wav",
	"physics/body/body_medium_impact_soft5.wav",
	"physics/body/body_medium_impact_soft6.wav",
	"physics/body/body_medium_impact_soft7.wav"
}

for k, v in pairs (SLAP_SOUNDS) do
	util.PrecacheSound(v)
end

function RESULT:Trigger(ply)
	ply:EmitSound(SLAP_SOUNDS[math.random(1, #SLAP_SOUNDS)])
	ply:SetLocalVelocity(Vector(math.random(0, 2500), math.random(0, 2500), 2500))
end

function RESULT:ShowMessage(ply)
	RTD:BroadcastMessageAboutPlayer(ply, "has been ", Color(0, 0, 255), "slapped hard", color_white, "!")
end