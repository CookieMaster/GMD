RESULT.Name = "Ignite"

function RESULT:Trigger(target)
	local i = math.random(15, 30)
	target:Ignite(i, 0)
end

function RESULT:ShowMessage(ply)
	RTD:BroadcastMessageAboutPlayer(ply, "has been ", Color(255, 0, 0), "set on fire", color_white, "!")
end