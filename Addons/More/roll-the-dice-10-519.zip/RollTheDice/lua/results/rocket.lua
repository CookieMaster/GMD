RESULT.Name = "Rocket"

function RESULT:Trigger(target)
	target:SetGroundEntity(NULL)
	target:SetVelocity(Vector(0, 0, 1000))
	target:EmitSound(Sound("weapons/rpg/rocketfire1.wav"))
	
	timer.Simple(1, function()
		if (!target or !target:IsValid()) then return end
	
		local effectdata = EffectData()
		effectdata:SetStart(target:GetPos())
		effectdata:SetOrigin(target:GetPos())
		effectdata:SetScale(3)
		util.Effect("HelicopterMegaBomb", effectdata)

		target:EmitSound("ambient/explosions/explode_1.wav", 100, 100)
		target:Kill()
	end)
end

function RESULT:ShowMessage(ply)
	RTD:BroadcastMessageAboutPlayer(ply, "has ", Color(255, 0, 0), "been rocketed", color_white, "!")
end