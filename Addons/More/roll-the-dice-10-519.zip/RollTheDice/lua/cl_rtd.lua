surface.CreateFont("DermaLarger",
{
	font		= "Roboto",
	size		= 64,
	antialias	= true,
	weight		= 500
})

hook.Add("HUDPaint", "DrawRTDCooldown", function()
	if (RTD_COOLDOWN) then 
		if (CurTime() >= RTD_COOLDOWN) then
			RTD_COOLDOWN = nil
			return
		end

		local x, y = 5, 5
		local w, h = 150, 60

		draw.RoundedBox(0, x, y, w, h, Color(0, 0, 0, 150))
		draw.SimpleText(string.ToMinutesSeconds(RTD_COOLDOWN - CurTime()), "DermaLarger", x + w * 0.5, y + h * 0.5, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end)

net.Receive("ReceiveColoredChatMessage", function()
	local msgtbl = net.ReadTable()
	chat.AddText(unpack(msgtbl))
end)