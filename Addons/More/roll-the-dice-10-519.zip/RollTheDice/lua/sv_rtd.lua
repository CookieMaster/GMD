RTD.Results = {}

util.AddNetworkString("ReceiveColoredChatMessage")

function RTD:LoadResults()
	local fil, _ = file.Find("results/*", "LUA")

	local i = 0
	for _, v in pairs (fil) do
		RESULT = {}
		
		include("results/" .. v)
		table.insert(RTD.Results, RESULT)
		
		RESULT = nil
		
		i = i + 1
	end
	
	print("Loaded " .. i .. " results")
end

function RTD:SendColoredChatMessage(ply, ...)
	local stuff = {...}
	
	for _, v in pairs (stuff) do
		if (type(v) == "number") then
			stuff[_] = tostring(v)
		end
	end
	
	net.Start("ReceiveColoredChatMessage")
		net.WriteTable(stuff)
	if (IsValid(ply)) then
		net.Send(ply)
	else
		net.Broadcast()
	end
end

function RTD:BroadcastMessageAboutPlayer(ply, ...)
	local stuff = {...}
	
	for _, v in pairs (stuff) do
		if (type(v) == "number") then
			stuff[_] = tostring(v)
		end
	end
	
	local teamcol = team.GetColor(ply:Team())
	local r, g, b = teamcol.r, teamcol.g, teamcol.b
	
	self:SendColoredChatMessage(nil, Color(0, 255, 100), "[RTD] ", Color(r, g, b), ply:Nick() .. " ", color_white, ...)
end

hook.Add("PlayerSay", "DoRTDCommands", function(ply, say, team)
	local text = say:lower()
	if (text == "rtd" or text == "!rtd" or text == "/rtd") then
		if (ply.RolledTheDice and ply.RolledTheDice > CurTime()) then
			RTD:SendColoredChatMessage(ply, Color(0, 255, 100), "[RTD] ", color_white, "You must wait ", Color(255, 255, 0), math.Round(ply.RolledTheDice - CurTime()), color_white, " more seconds before rolling the dice again!")
			return
		end
		
		local canrtd, cooldown = RTD:CanRTD(ply)
		if (!canrtd) then return end
		
		ply.RolledTheDice = CurTime() + cooldown
		if (RTD.Config.EnableHUD) then
			ply:SendLua("RTD_COOLDOWN = CurTime() + " .. cooldown)
		end
		
		local i = math.random(1, #RTD.Results)
		local result = RTD.Results[i]

		result:ShowMessage(ply)
		result:Trigger(ply)

		return "" 
	end
end)

RTD:LoadResults()