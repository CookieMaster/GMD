# Roll The Dice #

Test your players' luck!

## About ##

Rolling The Dice is typing a command (commonly rtd, !rtd or /rtd) which applies a random outcome (positive, negative or neutral) on the player; explode, rocket, change health..

## Features ##

+ Easily add outcomes. All you have to do is copy-paste another outcome file and edit it!
+ Add a cost for rolling the dice. This requires PointShop to be installed!
+ Disable RTD for specific usergroups; you can even add different costs and cooldowns. As of now, only 2 admin mods are supported: ULX and Evolve. More can be added on request.
+ Once rolling the dice, players are able to see the cooldown counter on the top-left corner of the screen.

Features missing or you'd like to see? Contact me for suggestions.

## Commands ##

+ rtd, /rtd or !rtd to roll the dice.
+ rtd_enable <1 or 0 or nothing> to toggle rolling the dice. This is ADMIN ONLY.

## Installation & Configuration ##

All you have to do is drag the RollTheDice folder into the addons folder of your Garry's Mod directory.
You shouldn't have to touch the lua files other than sv_config.lua to modify the settings.

## Contact ##

Steam: [http://www.steamcommunity.com/id/shendow](steamcommunity.com/id/shendow)  
E-Mail: [shenesis@gmail.com](mailto:shenesis@gmail.com)  
Facepunch: [Shenesis](http://facepunch.com/member.php?u=382492)  