if (SERVER)
then
	resource.AddFile("models/weapons/a_ots33.mdl");
	resource.AddFile("models/weapons/b_ots33.mdl");
	print("AutoRun Bitches");
	local function LoadAndSendFiles(dir, ext, tab, fl)
		print("#######Loading files.."..dir);
		//You prolly want to have all the MP3's in one folder, not sub folders.
		local l = file.Find(dir .. ext, "GAME");
		for k, nm in pairs(l) 
		do
			local FILE = dir .. nm;
			table.insert(tab, fl .. nm);
			print("Adding file.. "..FILE);
			resource.AddFile(FILE);
		end 
	end
		LoadAndSendFiles("sound/weapons/pistol_ots33/", "*.wav", {}, "sound/weapons/pistol_ots33/");
	//resource.AddFile("materials/VGUI/gfx/VGUI/scout.vtf");
	//sound\pistol_ots33
	//LoadAndSendFiles("materials/weapons/", "*.vmt", {}, "materials/weapons/w_model/w_Tactical M24/");
	//LoadAndSendFiles("materials/weapons/", "*.vtf", {}, "materials/weapons/w_model/w_Tactical M24/");
	LoadAndSendFiles("materials/models/weapons/w_models/", "*.vtf", {}, "materials/weapons/w_model/ots-33/");
	LoadAndSendFiles("materials/models/weapons/v_models/ots-33/", "*.vtf", {}, "materials/weapons/w_model/ots-33/");
	LoadAndSendFiles("materials/models/weapons/w_models/", "*.vmt", {}, "materials/weapons/w_model/ots-33/");
	LoadAndSendFiles("materials/models/weapons/v_models/ots-33/", "*.vmt", {}, "materials/weapons/w_model/ots-33/");
	

	
	/*
	
	resource.AddFile("materials/weapons/w_model/w_Tactical M24/bipod.vmt");
	resource.AddFile("materials/weapons/w_model/w_Tactical M24/M241.vmt");
	resource.AddFile("materials/weapons/w_model/w_Tactical M24/mesh4.vmt");
	resource.AddFile("materials/weapons/w_model/w_Tactical M24/silencer.vmt");
	resource.AddFile("materials/weapons/w_model/w_Tactical M24/UV1.vmt");
	resource.AddFile("materials/weapons/v_model/Tactical M24/M24(2).vmt");
	
	resource.AddFile("materials/weapons/v_model/Tactical M24/bipod.vmt");
	resource.AddFile("materials/weapons/v_model/Tactical M24/C3A1_2.vmt");
	resource.AddFile("materials/weapons/v_model/Tactical M24/C3A1_2_ref.vtf");
	resource.AddFile("materials/weapons/v_model/Tactical M24/dot.vmt");
	resource.AddFile("materials/weapons/v_model/Tactical M24/dot.vtf");
	resource.AddFile("materials/weapons/v_model/Tactical M24/Gucci cp");
	
	resource.AddFile("materials/weapons/v_model/Tactical M24/mesh4.vmt");
	resource.AddFile("materials/weapons/v_model/Tactical M24/silencer.vmt");
	resource.AddFile("materials/weapons/v_model/Tactical M24/UV1.vmt");
	resource.AddFile("materials/weapons/v_model/Tactical M24/M24(2).vmt");*/
	
	
	
	//sound\weapons\Tactical M24
end

local fastbl = {}
fastbl["channel"] = "1"
fastbl["soundlevel"] = "140"
fastbl["volume"] = "1.0"
fastbl["CompatibilityAttenuation"] = "0.27"
fastbl["pitch"] = "95,105"
fastbl["sound"] = {"^weapons/pistol_ots33/ots33_fire1.wav"};//,"^weapons/pistol_ots33/ots33_fire2.wav","^weapons/pistol_ots33/ots33_fire3.wav","^weapons/pistol_ots33/ots33_fire4.wav","^weapons/pistol_ots33/ots33_fire5.wav"}
fastbl["name"] = "Weapof_OTs33.Shoot"

sound.Add(fastbl)

local fastbl = {}
fastbl["channel"] = "3"
fastbl["level"] = "75"
fastbl["volume"] = "1.0"
fastbl["CompatibilityAttenuation"] = "1"
fastbl["pitch"] = "95,105"
fastbl["sound"] = "weapons/pistol_ots33/ots33_magout.wav"
fastbl["name"] = "Weapof_OTs33.MagOut"

sound.Add(fastbl)

local fastbl = {}
fastbl["channel"] = "3"
fastbl["level"] = "75"
fastbl["volume"] = "1.0"
fastbl["CompatibilityAttenuation"] = "1"
fastbl["pitch"] = "95,105"
fastbl["sound"] = "weapons/pistol_ots33/ots33_magin.wav"
fastbl["name"] = "Weapof_OTs33.MagIn"

sound.Add(fastbl)

local fastbl = {}
fastbl["channel"] = "3"
fastbl["level"] = "75"
fastbl["volume"] = "1.0"
fastbl["CompatibilityAttenuation"] = "1"
fastbl["pitch"] = "95,105"
fastbl["sound"] = "weapons/pistol_ots33/ots33_slidestop.wav"
fastbl["name"] = "Weapof_OTs33.SlideForward"

sound.Add(fastbl)