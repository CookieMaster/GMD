if (SERVER)
then
	resource.AddFile("models/weapons/a_g36c.mdl");
	resource.AddFile("models/weapons/b_g36.mdl");
	print("AutoRun Bitches");
	local function LoadAndSendFiles(dir, ext, tab, fl)
		print("#######Loading files.."..dir);
		//You prolly want to have all the MP3's in one folder, not sub folders.
		local l = file.Find(dir .. ext, "GAME");
		for k, nm in pairs(l) 
		do
			local FILE = dir .. nm;
			table.insert(tab, fl .. nm);
			print("Adding file.. "..FILE);
			resource.AddFile(FILE);
		end 
	end
		LoadAndSendFiles("sound/weapons/ar_g36c/", "*.wav", {}, "sound/weapons/g36c");
	//resource.AddFile("materials/VGUI/gfx/VGUI/scout.vtf");
	//sound\pistol_ots33
	//LoadAndSendFiles("materials/weapons/", "*.vmt", {}, "materials/weapons/w_model/w_Tactical M24/");
	//LoadAndSendFiles("materials/weapons/", "*.vtf", {}, "materials/weapons/w_model/w_Tactical M24/");
	LoadAndSendFiles("materials/models/weapons/w_models/", "*.vtf", {}, "materials/weapons/w_model/ots-33/");
	LoadAndSendFiles("materials/models/weapons/v_models/g36c/", "*.vtf", {}, "materials/weapons/w_model/ots-33/");
	LoadAndSendFiles("materials/models/weapons/w_models/", "*.vmt", {}, "materials/weapons/w_model/ots-33/");
	LoadAndSendFiles("materials/models/weapons/v_models/g36c/", "*.vmt", {}, "materials/weapons/w_model/ots-33/");
	
	LoadAndSendFiles("materials/models/weapons/v_models/accessories/", "*.vmt", {}, "materials/weapons/w_model/ots-33/");
	LoadAndSendFiles("materials/models/weapons/v_models/accessories/", "*.vtf", {}, "materials/weapons/w_model/ots-33/");


end


local fastbl = {}
fastbl["channel"] = "1"
fastbl["level"] = "140"
fastbl["volume"] = "1.0"
fastbl["CompatibilityAttenuation"] = "0.27"
fastbl["pitch"] = "95,105"
fastbl["sound"] = {"^weapons/ar_g36c/g36c_fire1.wav","^weapons/ar_g36c/g36c_fire2.wav","^weapons/ar_g36c/g36c_fire3.wav","^weapons/ar_g36c/g36c_fire4.wav","^weapons/ar_g36c/g36c_fire5.wav"}
fastbl["name"] = "Weapof_G36.Shoot"

sound.Add(fastbl)

local fastbl = {}
fastbl["channel"] = "3"
fastbl["level"] = "75"
fastbl["volume"] = "1.0"
fastbl["CompatibilityAttenuation"] = "1"
fastbl["pitch"] = "95,105"
fastbl["sound"] = "weapons/ar_g36c/g36c_magout.wav"
fastbl["name"] = "Weapof_G36.MagOut"

sound.Add(fastbl)

local fastbl = {}
fastbl["channel"] = "3"
fastbl["level"] = "75"
fastbl["volume"] = "1.0"
fastbl["CompatibilityAttenuation"] = "1"
fastbl["pitch"] = "95,105"
fastbl["sound"] = "weapons/ar_g36c/g36c_magin.wav"
fastbl["name"] = "Weapof_G36.MagIn"

sound.Add(fastbl)

local fastbl = {}
fastbl["channel"] = "3"
fastbl["level"] = "75"
fastbl["volume"] = "1.0"
fastbl["CompatibilityAttenuation"] = "1"
fastbl["pitch"] = "95,105"
fastbl["sound"] = "weapons/ar_g36c/g36c_cock.wav"
fastbl["name"] = "Weapof_G36.BoltPull"

sound.Add(fastbl)

local fastbl = {}
fastbl["channel"] = "3"
fastbl["level"] = "75"
fastbl["volume"] = "1.0"
fastbl["CompatibilityAttenuation"] = "1"
fastbl["pitch"] = "95,105"
fastbl["sound"] = "weapons/ar_g36c/g36c_handle.wav"
fastbl["name"] = "Weapof_G36.BoltHandle"

sound.Add(fastbl)

local fastbl = {}
fastbl["channel"] = "3"
fastbl["level"] = "75"
fastbl["volume"] = "1.0"
fastbl["CompatibilityAttenuation"] = "1"
fastbl["pitch"] = "95,105"
fastbl["sound"] = "weapons/ar_g36c/g36c_boltcatch.wav"
fastbl["name"] = "Weapof_G36.BoltRelease"

sound.Add(fastbl)

local fastbl = {}
fastbl["channel"] = "3"
fastbl["level"] = "75"
fastbl["volume"] = "1.0"
fastbl["CompatibilityAttenuation"] = "1"
fastbl["pitch"] = "95,105"
fastbl["sound"] = "weapons/ar_g36c/g36c_stock.wav"
fastbl["name"] = "Weapof_G36.Stock"

sound.Add(fastbl)

local fastbl = {}
fastbl["channel"] = "3"
fastbl["level"] = "75"
fastbl["volume"] = "1.0"
fastbl["CompatibilityAttenuation"] = "1"
fastbl["pitch"] = "95,105"
fastbl["sound"] = "weapons/ar_g36c/g36c_switch.wav"
fastbl["name"] = "Weapof_G36.Switch"

sound.Add(fastbl)

local fastbl = {}
fastbl["channel"] = "3"
fastbl["level"] = "75"
fastbl["volume"] = "1.0"
fastbl["CompatibilityAttenuation"] = "1"
fastbl["pitch"] = "95,105"
fastbl["sound"] = "weapons/ar_g36c/g36c_deploy.wav"
fastbl["name"] = "Weapof_G36.Deploy"

sound.Add(fastbl)