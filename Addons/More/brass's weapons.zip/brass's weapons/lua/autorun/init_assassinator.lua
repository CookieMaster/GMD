if (SERVER)
then
	resource.AddFile("models/weapons/a_m24.mdl");
	resource.AddFile("models/weapons/b_m24.mdl");
	
	local function LoadAndSendFiles(dir, ext, tab, fl)
		print("Loading files.."..dir);
		//You prolly want to have all the MP3's in one folder, not sub folders.
		local l = file.Find(dir .. ext, "GAME");
		for k, nm in pairs(l) 
		do
			local FILE = dir .. nm;
			table.insert(tab, fl .. nm);
			print("Adding file.. "..FILE);
			resource.AddFile(FILE);
		end
	end
	//resource.AddFile("materials/VGUI/gfx/VGUI/scout.vtf");
	//LoadAndSendFiles("materials/weapons/", "*.vmt", {}, "materials/weapons/w_model/w_Tactical M24/");
	//LoadAndSendFiles("materials/weapons/", "*.vtf", {}, "materials/weapons/w_model/w_Tactical M24/");
	LoadAndSendFiles("materials/models/weapons/w_models/", "*.vtf", {}, "materials/weapons/w_model/w_Tactical M24/");
	LoadAndSendFiles("materials/models/weapons/v_models/M24_SWS/", "*.vtf", {}, "materials/weapons/w_model/w_Tactical M24/");
	LoadAndSendFiles("materials/models/weapons/w_models/", "*.vmt", {}, "materials/weapons/w_model/w_Tactical M24/");
	LoadAndSendFiles("materials/models/weapons/v_models/M24_SWS/", "*.vmt", {}, "materials/weapons/w_model/w_Tactical M24/");
		LoadAndSendFiles("materials/models/weapons/v_models/hands/", "*.vmt", {}, "materials/weapons/w_model/w_Tactical M24/");
		LoadAndSendFiles("materials/models/weapons/v_models/hands/", "*.vtf", {}, "materials/weapons/w_model/w_Tactical M24/");
				LoadAndSendFiles("materials/models/weapons/v_models/accessories/", "*.vmt", {}, "materials/weapons/w_model/w_Tactical M24/");
		LoadAndSendFiles("materials/models/weapons/v_models/accessories/", "*.vtf", {}, "materials/weapons/w_model/w_Tactical M24/");
	//LoadAndSendFiles("materials/models/weapons/v_models/tactical_m24/", "*.vmt", {}, "materials/weapons/w_model/w_Tactical M24/");
	/*
	
	resource.AddFile("materials/weapons/w_model/w_Tactical M24/bipod.vmt");
	resource.AddFile("materials/weapons/w_model/w_Tactical M24/M241.vmt");
	resource.AddFile("materials/weapons/w_model/w_Tactical M24/mesh4.vmt");
	resource.AddFile("materials/weapons/w_model/w_Tactical M24/silencer.vmt");
	resource.AddFile("materials/weapons/w_model/w_Tactical M24/UV1.vmt");
	resource.AddFile("materials/weapons/v_model/Tactical M24/M24(2).vmt");
	
	resource.AddFile("materials/weapons/v_model/Tactical M24/bipod.vmt");
	resource.AddFile("materials/weapons/v_model/Tactical M24/C3A1_2.vmt");
	resource.AddFile("materials/weapons/v_model/Tactical M24/C3A1_2_ref.vtf");
	resource.AddFile("materials/weapons/v_model/Tactical M24/dot.vmt");
	resource.AddFile("materials/weapons/v_model/Tactical M24/dot.vtf");
	resource.AddFile("materials/weapons/v_model/Tactical M24/Gucci cp");
	
	resource.AddFile("materials/weapons/v_model/Tactical M24/mesh4.vmt");
	resource.AddFile("materials/weapons/v_model/Tactical M24/silencer.vmt");
	resource.AddFile("materials/weapons/v_model/Tactical M24/UV1.vmt");
	resource.AddFile("materials/weapons/v_model/Tactical M24/M24(2).vmt");*/
	
	
	
	//sound\weapons\Tactical M24
end