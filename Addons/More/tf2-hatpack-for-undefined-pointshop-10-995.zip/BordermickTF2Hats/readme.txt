Thank you for buying Bordermick's TF2 hat pack of coderhire.com!


This readme will explain how to install the hat pack and also how to edit the code to your liking.



How to install:

To install the TF2 hat pack all you need to do is drag the TF2 folder into your pointshop items directory.

Most people directories might look like this:

garrysmod/addons/pointshop-master/lua/items

You would drag the TF2 folder included in the .zip that you just downloaded into that items folder.

After thats done you should be all set. Just restart your server and you should have the hat pack installed.



How to make items admin/donator only:

If you want to make one of the hats donator/admin only all you have to do is open the .lua file that contains the code for that hat.

The directory to find the .lua file is:

garrysmod/addons/pointshop-master/lua/items/TF2/

Once you are in that file at the very bottom of the code add this:

ITEM.AllowedUserGroups = { "ulxgroup, ulxgroup, ulxgroup"

(ulxgroup stands for the group you want to allow access to buy this hat.)


Ex. If I wanted to give the B.M.O.C Hat access to the group "donator" and "vip" only I would go into the directory:

garrysmod/addons/pointshop-master/lua/items/TF2/

I would then open up the bmoc.lua file

under the very last line of code I would put:

ITEM.AllowedUserGroups = { "donator, vip"

I would then save the file and the hat would only be able to be bought by the people in the group donator and the group vip.



How to change the prices of hats:

If you want to change a price of a hat all you have to do is open the .lua file that contains the code for that hat.

The directory to find the .lua file is:

garrysmod/addons/pointshop-master/lua/items/TF2/

Once you are in that file you should see this:

ITEM.Price = 

All you have to do is change the price that is allready there and make it the price that you want it to be.

Ex. If I wanted to change the price of the Anger hat from 850 to 1500 I would go into the directory

garrysmod/addons/pointshop-master/lua/items/TF2/

I would open the anger.lua file

On the line of code that says:

ITEM.Price = 850

I would change the 850 to 1500 and then save the file. 
Yay I just successfully changed the price of a item.


WHENEVER YOU EDIT CODE RESTART YOUR SERVER FOR IT TO TAKE EFFECT!!


Hope you enjoy the TF2 Hat Pack By: Bordermick!


I also offer support for this so if you are having any problems please contact me on steam or on coderhire.

Steam: http://steamcommunity.com/id/Bordermick

Coderhire: http://coderhire.com/profile/view/1796