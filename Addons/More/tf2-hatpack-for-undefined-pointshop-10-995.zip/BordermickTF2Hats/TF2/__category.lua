CATEGORY.Name = 'TF2 Items'
CATEGORY.Icon = 'emoticon_smile'
CATEGORY.AllowedEquipped = 2
