I_Vis = {}

-- Use this file and the options in here to make
-- the voice box fit your needs and wants. If you
-- have any problems or have suggestions notify me
-- on coderhire or steam.

-- If you're using ttt you should set this to true.
I_Vis.VisIsTTT                       = false

-- Visualizer mode 
-- 0 = Nothing
-- 1 = Semi-Circles
-- 2 = Moving Bars
-- 3 = Pin point Bar Graph
-- 4 = Line graph
-- 5 = Simple wave
I_Vis.Visualizer                     = 2

-- You can change the color scheme for your visualizer here.
-- 0 = Use default color for the visualizer 
-- 1 = Use Colors depending on the player (Set Colors in GetPlayersColor below.)
-- 2 = Use a fade from red - green depending on the how loud the player is.
-- 3 = rainbow...
I_Vis.VisColorMode                   = 2

-- Controls the opacity of the visualizer.
I_Vis.VisualizerOpac                 = 100

-- Default color for the Visualizers
I_Vis.VisDefaultCol                  = Color(50,50,50,100)

-- Do you want to display player models on the panel? ( NOTE: This will replace avatar icons)
I_Vis.ShowPlayerModel                = false

------------------------------------------------------------------------------
----------------------------Main Color Settings-------------------------------
------------------------------------------------------------------------------

I_Vis.VisBorderColor                 = Color(40,40,40,255)

I_Vis.VisBGColor                     = Color(25,25,25,255)

I_Vis.VisNameColor                   = Color(160,160,160,120)

I_Vis.VisTagColor                    = Color(160,160,160,60)

I_Vis.VisSteamIDColor                = Color(160,160,160,10)

-- The avatar background color if a friend talks
I_Vis.vFriendColor 				   = Color(129,214,171)

-- The avatar background color if a non friend talks
I_Vis.vNotFriendColor                = Color(129,196,214)

------------------------------------------------------------------------------
------------Below Here You Can Edit Some More Advanced Settings---------------
------------------------------------------------------------------------------

-- This is the multiplier for player voices. Recommended to keep
-- at 300 or lower
I_Vis.VisMultiplier                  = 300

-- Controls how many circles there are in visualizer 1
I_Vis.VisAmountOfCircles             = 60

-- Controls the width of each bar on visualizer 2
I_Vis.Vis2Width 					   = 3

-- This will enable the gradient on the left side of the voice box. (true = yes, false = no)
I_Vis.UseGradient                    = false

------------------------------------------------------------------------------
--------Here You Can Enable And Set Player Tags For Groups Or a Person--------
------------------------------------------------------------------------------

-- Do you want to have custom tags for players?
I_Vis.UsePlayerTags                  = true

-- Here is where you may set them, to groups or individual players.
function GetTagForPlayer(ply)
	if ply:SteamID() == "STEAM_0:0:68825805" then -- Usage of steam IDs (please don't remove mine. :3)
		return "Developer" -- Developer tag for me.
		
	elseif ply:IsAdmin() then -- You can use user groups.
		return "Admin" -- Admins will have the tag Admin. 
		
	else
		return "" -- If you want you can set this to guest or w/e
		
	end
end

------------------------------------------------------------------------------
-----------Here You Can Set A Custom Color For A Player's Visualizer----------
------------------------------------------------------------------------------

-- This is where you can change who gets what colors when they talk. (Visualizer #2 and #4)
-- UsePlayers must be true.
function GetPlayersColor(ply)
	if ply:SteamID() == "STEAM_0:0:68825805" then -- Usage of steam IDs (please don't remove mine. :3 <3)
		return HSVToColor( math.sin(0.5*RealTime())*128+127, 1, 1 ) -- This is rainbow.
		
	elseif ply:IsAdmin() then -- You can use user groups.
		return Color(100,10,10,200) -- Admins will have a dark red color. 
		
	else
		return I_Vis.VisDefaultCol
		
	end
end

-- If you don't know what a specific function does, you can
-- message me on coderhire or steam and I'll explain the use of
-- it. All variables here in the config can be edited freely.

------------------------------------------------------------------------------
--------------------------------More Advanced---------------------------------
------------------------------------------------------------------------------

-- ADVANCED OPTIONS FOR VISUALIZER #4
I_Vis.VisLinWid                     = 1       -- Width of the line
I_Vis.VisUseRough                   = false	  -- Use Rough line
I_Vis.VisOpacity                    = 100     -- Opacity
I_Vis.Vis4Freq                      = 5       -- Frequency (set to 10 or higher for dotted line)

if SERVER then RunConsoleCommand("sv_kickerrornum", 0) end
