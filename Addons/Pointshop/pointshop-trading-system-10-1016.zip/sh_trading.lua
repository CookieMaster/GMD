PS.Trading = PS.Trading or {}
PS.Trading.RequestExpiryTime = 30 -- seconds
PS.Trading.TradeChatCommand = "!trade" -- !trade playername

PS.Trading.BannedUserGroups = { }

function PS.Trading:CanPlayerTrade(ply)
	local usergroup = ply:PS_GetUsergroup()
	return not table.HasValue(self.BannedUserGroups, usergroup)
end