local PANEL = {}

function PANEL:Init()
	self:SetWide(288)
	self:SetTall(080)

	self.Avatar = vgui.Create("AvatarImage", self)
	self.Avatar:SetSize(64, 64)
	self.Avatar:Dock(LEFT)
	self.Avatar:DockMargin(8, 8, 8, 8)

	self.AcceptButton = vgui.Create("DButton", self)
	self.AcceptButton:SetSize(96, 24)
	self.AcceptButton:SetPos(80, 48)
	self.AcceptButton:SetText("ACCEPT")
	self.AcceptButton.Paint = self.PaintAcceptButton
	self.AcceptButton.UpdateColours = self.UpdateButtonColours
	self.AcceptButton.DoClick = function()
		net.Start('PS.Trading_AcceptTradeRequest')
			net.WriteUInt(self.TradeData.id, 8)
		net.SendToServer()

		self:Close()
	end

	self.DeclineButton = vgui.Create("DButton", self)
	self.DeclineButton:SetSize(96, 24)
	self.DeclineButton:SetPos(184, 48)
	self.DeclineButton:SetText("DECLINE")
	self.DeclineButton.Paint = self.PaintDeclineButton
	self.DeclineButton.UpdateColours = self.UpdateButtonColours
	self.DeclineButton.DoClick = function()
		net.Start('PS.Trading_DeclineTradeRequest')
			net.WriteUInt(self.TradeData.id, 8)
		net.SendToServer()

		self:Close()
	end

	self.DebugCreate = CurTime()

	self:Dock(TOP)
	self:DockMargin(16, 16, 16, 0)
end

function PANEL:Setup(trade)
	self.TradeData = trade

	if trade.sender == LocalPlayer() then
		self.Avatar:SetPlayer(trade.recipient, 64)
		self.Text = trade.recipient:Nick() .. " pending trade."

		self.AcceptButton:SetVisible(false)
		self.DeclineButton:SetVisible(false)

		self.Pending = true
	else
		self.Avatar:SetPlayer(trade.sender, 64)
		self.Text = trade.sender:Nick() .. " wants to trade!"
	end
end

function PANEL:Paint(w, h)
	if ( self.DebugCreate + PS.Trading.RequestExpiryTime - CurTime() ) < 0 and !self.Closing then
		self:Close()
		self.Closing = true
	elseif !self.Closing then
		self.DeclineButton:SetText("DECLINE (" .. math.floor( self.DebugCreate + PS.Trading.RequestExpiryTime - CurTime() ) .. ")")
	end

	surface.SetDrawColor(40, 40, 40, 255)
	surface.DrawRect(0, 0, w, h)

	draw.DrawText(self.Text, "DermaDefault", 180, 18, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)

	if self.Pending then
		draw.DrawText("(" .. math.floor( self.DebugCreate + PS.Trading.RequestExpiryTime - CurTime() ) .. ")",
			"DermaDefault", 180, 44, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
	end
end

function PANEL:PaintAcceptButton(w, h)
	if self.Hovered then surface.SetDrawColor(88, 214, 141, 255)
	elseif self.Depressed then surface.SetDrawColor(39, 173, 96, 255)
	else surface.SetDrawColor(46, 204, 113, 255) end

	surface.DrawRect(0, 0, w, h)
end

function PANEL:PaintDeclineButton(w, h)
	if self.Hovered then surface.SetDrawColor(236, 112, 99, 255)
	elseif self.Depressed then surface.SetDrawColor(196, 65, 51, 255)
	else surface.SetDrawColor(231, 76, 60, 255) end

	surface.DrawRect(0, 0, w, h)
end

function PANEL:UpdateButtonColours()
	self:SetTextStyleColor(Color(255, 255, 255, 255 * (self.Depressed and 0.75 or 1)))
end

function PANEL:Close()
	self:AlphaTo(0, 0.25, 0, function() local pnl = self:GetParent() self:Remove() pnl:InvalidateLayout() end)
	self:SetMouseInputEnabled(false)
end

function PANEL:Declined()
	self:AlphaTo(0, 0.25, 5, function() local pnl = self:GetParent() self:Remove() pnl:InvalidateLayout() end)
	self.Text = self.TradeData.sender:Nick() .. " declined."

	self:SetMouseInputEnabled(false)
end

vgui.Register("DPointShopTradeNotification", PANEL)