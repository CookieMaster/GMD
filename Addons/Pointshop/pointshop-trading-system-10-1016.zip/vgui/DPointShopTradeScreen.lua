if ( system.IsOSX() ) then
	surface.CreateFont( "PSTradingDefault", {
		font		= "Helvetica",
		size		= 13,
		antialias	= false,
		weight		= 500
	})

	surface.CreateFont( "PSTradingDefaultBold", {
		font		= "Helvetica",
		size		= 13,
		antialias	= false,
		weight		= 800
	})

	surface.CreateFont( "PSTradingItemText", {
		font		= "Helvetica",
		size		= 11,
		antialias	= true,
		weight		= 500
	})
else
	surface.CreateFont( "PSTradingDefault", {
		font		= "Tahoma",
		size		= 13,
		antialias	= true,
		weight		= 500
	})

	surface.CreateFont( "PSTradingDefaultBold", {
		font		= "Tahoma",
		size		= 13,
		antialias	= false,
		weight		= 800
	})

	surface.CreateFont( "PSTradingItemText", {
		font		= "Tahoma",
		size		= 11,
		antialias	= true,
		weight		= 500
	})
end

surface.CreateFont( "PSTradingLarge", {
	font		= "Roboto",
	size		= 24,
	antialias	= true,
	weight		= 500
})

local PANEL = {}

function PANEL:Init()
	self:SetSize( math.Clamp( 1024, 0, ScrW() ), math.Clamp( 768, 0, ScrH() ) )
	self:SetPos((ScrW() / 2) - (self:GetWide() / 2), (ScrH() / 2) - (self:GetTall() / 2))
	
	-- remove our boring ol' derma design.
	self:ThemeInit()

	self.AcceptButton = vgui.Create("DButton", self)
	self.AcceptButton:SetSize(96, 24)
	self.AcceptButton:SetText("ACCEPT")
	self.AcceptButton.Paint = self.PaintAcceptButton
	self.AcceptButton.UpdateColours = self.UpdateButtonColours
	self.AcceptButton.DoClick = function()
		net.Start('PS.Trading_AcceptTrade')
			net.WriteUInt(self.TradeID, 8)
		net.SendToServer()
	end

	self.CancelButton = vgui.Create("DButton", self)
	self.CancelButton:SetSize(96, 24)
	self.CancelButton:SetText("CANCEL")
	self.CancelButton.Paint = self.PaintCancelButton
	self.CancelButton.UpdateColours = self.UpdateButtonColours
	self.CancelButton.DoClick = function()
		net.Start('PS.Trading_CancelTrade')
			net.WriteUInt(self.TradeID, 8)
		net.SendToServer()

		self:Close()
	end

	self.LeftContainer = vgui.Create("DPanel", self)
	self.RightContainer = vgui.Create("DPanel", self)

	self.LeftContainer:SetWide(432) -- 332 (3 wide), 432 (4 wide)
	self.LeftContainer:SetDrawBackground( false )
	self.RightContainer:SetDrawBackground( false )

	self.LeftContainer:Dock(LEFT)
	self.LeftContainer:DockMargin(0, 0, 0, 0)
	self.RightContainer:Dock(FILL)
	self.RightContainer:DockMargin(0, 0, 0, 32)

	self.LocalInventory = vgui.Create("DScrollPanel", self.LeftContainer)
	self.LocalInventory:Dock(FILL)
	self.LocalInventory:DockMargin(4, 4, 4, 4)

	self.LocalInventory.Paint = function(pnl, w, h)
		surface.SetDrawColor(54, 54, 54, 255)
		surface.DrawRect(0, 0, w, h)
	end
		
	local ShopCategoryTabLayout = vgui.Create('DIconLayout', self.LocalInventory)
	ShopCategoryTabLayout:Dock(FILL)
	ShopCategoryTabLayout:SetBorder(4)
	ShopCategoryTabLayout:SetSpaceX(4)
	ShopCategoryTabLayout:SetSpaceY(4)
		
	self.LocalInventory:AddItem(ShopCategoryTabLayout)

	local items = {}
	
	for _, i in pairs(PS.Items) do
		if not LocalPlayer():PS_HasItem(i.ID) then continue end
		table.insert(items, i)
	end
	
	table.SortByMember(items, "Name", function(a, b) return a > b end)

	for _, ITEM in pairs(items) do
		local model = vgui.Create('DPointShopItem')
		model:SetData(ITEM)
		model:SetSize(96, 96)
		model:SetBackgroundColor(Color(42, 42, 42, 255))

		model.PaintOver = function(pnl, w, h)
			surface.SetDrawColor(0, 0, 0, 125)
			surface.DrawRect(0, h - pnl.InfoHeight, w, pnl.InfoHeight)
	
			draw.SimpleText(pnl.Data.Name, "PSTradingItemText", w / 2, h - (pnl.InfoHeight / 2), Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawOutlinedRect(0, 0, w, h)
		end

		model.DoClick = function(pnl)
			net.Start('PS.Trading_AddItem')
				net.WriteUInt(self.TradeID, 8)
				net.WriteString(ITEM.ID)
			net.SendToServer()
		end
			
		ShopCategoryTabLayout:Add(model)
	end

	self.TradeChat = vgui.Create("DPanel", self.LeftContainer)
	self.TradeChat:SetTall(256)
	self.TradeChat:Dock(BOTTOM)
	self.TradeChat:DockMargin(4, 4, 4, 4)

	self.TradeChat.Paint = function(pnl, w, h)
		surface.SetDrawColor(54, 54, 54, 255)
		surface.DrawRect(0, 0, w, h)
	end

	self.TradeChat.TextContainer = vgui.Create("DPanel", self.TradeChat)
	self.TradeChat.TextContainer:Dock(BOTTOM)
	self.TradeChat.TextContainer:DockMargin(8, 8, 8, 8)
	self.TradeChat.TextContainer:SetDrawBackground(false)
	self.TradeChat.TextContainer:SetTall(24)

	self.TradeChat.TextEntry = vgui.Create("DTextEntry", self.TradeChat.TextContainer)
	self.TradeChat.TextEntry:Dock(FILL)
	self.TradeChat.TextEntry.Paint = function(pnl, w, h)
		surface.SetDrawColor(29, 29, 29, 255)
		surface.DrawRect(0, 0, w, h)
		pnl:DrawTextEntryText(Color(255, 255, 255), Color(30, 130, 255), Color(255, 255, 255))
	end
	self.TradeChat.TextEntry:SetFont( "PSTradingDefault" )
	self.TradeChat.TextEntry.OnKeyCodeTyped = function( pnl, code )
		if ( code == KEY_ENTER ) then
			if ( IsValid( pnl.Menu ) ) then pnl.Menu:Remove() end
			-- self:FocusNext() -- BAD GARRY, WHAT DO YOU THINK YOU ARE DOING.
			self:SendMessage()
		end
	end

	self.TradeChat.SendBtn = vgui.Create("DButton", self.TradeChat.TextContainer)
	self.TradeChat.SendBtn:Dock(RIGHT)
	self.TradeChat.SendBtn:SetWide(64)
	self.TradeChat.SendBtn:DockMargin(8, 0, 0, 0)
	self.TradeChat.SendBtn:SetText("SEND")
	self.TradeChat.SendBtn.Paint = function(pnl, w, h)
		if pnl.Hovered then surface.SetDrawColor(65, 91, 118, 255)
		elseif pnl.Depressed then surface.SetDrawColor(44, 62, 80, 255)
		else surface.SetDrawColor(52, 73, 94, 255) end

		surface.DrawRect(0, 0, w, h)
	end
	self.TradeChat.SendBtn.UpdateColours = self.UpdateButtonColours
	self.TradeChat.SendBtn.DoClick = function() self:SendMessage() end
	self.TradeChat.SendBtn:SetFont( "PSTradingDefault" )

	local HTML = [[<style type='text/css'>
		body{background:#262626;margin:0;padding:4px;overflow-x:hidden;overflow-y:scroll;}
		p{font-family: Tahoma, Verdana, Segoe, sans-serif;margin:0 2px;font-size:13px;color:white;}
		span.error{ color: #ff9494; }
		span.sender{ color: #80b4dc; }
		span.highlight { color: #b3dc80; }
		span.timestamp { font-size: 10px; color: #ccc; margin-right: 2px; }
		::-webkit-scrollbar { width: 15px; background-color: #555555; }
		::-webkit-scrollbar-track { background-color: #555555; }
		::-webkit-scrollbar-thumb { background-color: #333333; border: 1px solid transparent; background-clip: content-box; }
		::-webkit-scrollbar-thumb:hover { background-color: #282828; }
		::-webkit-scrollbar-button { background-color: #555555; cursor: pointer; }
		::-webkit-scrollbar-button:vertical{background-size:7px 6px; background-position:center; background-repeat:no-repeat;}
		::-webkit-scrollbar-button:vertical:increment {	background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAGCAMAAAA40HREAAAABlBMVEUAAAD///+l2Z/dAAAAAXRSTlMAQObYZgAAACBJREFUeNotxwEKAAAIwsDt/5+uRYIeIkU01m8T3LvEAAJMABaPPKbeAAAAAElFTkSuQmCC'); }
		::-webkit-scrollbar-button:vertical:decrement { background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAGCAMAAAA40HREAAAABlBMVEUAAAD///+l2Z/dAAAAAXRSTlMAQObYZgAAAB9JREFUeNotyoEJAAAMwjDz/9MbYkEKxTxSMFFtbTs5AgQAFpuowZoAAAAASUVORK5CYII='); }

	</style>]]
	self.TradeChat.ChatArea = vgui.Create("HTML", self.TradeChat)
	self.TradeChat.ChatArea:Dock(FILL)
	self.TradeChat.ChatArea:DockMargin(0, 0, 0, 0)
	self.TradeChat.ChatArea.FormatHTML = HTML
	self.TradeChat.ChatArea.ChatHTML = ""
	self.TradeChat.ChatArea:SetHTML(HTML)

	self.LocalOffers = vgui.Create("DPanel", self.RightContainer)
	self.LocalOffers:Dock(TOP)
	self.LocalOffers:DockMargin(4, 4, 4, 4)
	self.LocalOffers.Points = 0
	self.LocalOffers.Paint = function(pnl, w, h)
		surface.SetDrawColor(54, 54, 54, 255)
		surface.DrawRect(0, 0, w, h)

		local x = draw.SimpleText("Your Offerings:", "PSTradingLarge", 48, 24, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(pnl.Points .. " points", "PSTradingLarge", 48 + x + 4, 24, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	self.LocalOffers.Avatar = vgui.Create("AvatarImage", self.LocalOffers)
	self.LocalOffers.Avatar:SetPos(8, 8)
	self.LocalOffers.Avatar:SetSize(32, 32)
	self.LocalOffers.Avatar:SetPlayer(LocalPlayer(), 32)

	self.LocalOffers.Ready = vgui.Create("DButton", self.LocalOffers)
	self.LocalOffers.Ready:SetSize(96, 32)
	self.LocalOffers.Ready.Ready = false
	self.LocalOffers.Ready.DoClick = function(pnl)
		net.Start('PS.Trading_ToggleReady')
			net.WriteUInt(self.TradeID, 8)
		net.SendToServer()
	end
	self.LocalOffers.Ready.Paint = function(pnl, w, h)
		local paintFunc = pnl.Ready and self.PaintAcceptButton or self.PaintCancelButton
		paintFunc(pnl, w, h)

		if (pnl.Ready) then pnl:SetText("Ready")
			else pnl:SetText("Not Ready") end
	end
	self.LocalOffers.Ready.UpdateColours = self.UpdateButtonColours

	self.LocalOffers.SetPoints = vgui.Create("DButton", self.LocalOffers)
	self.LocalOffers.SetPoints:SetSize(96, 32)
	self.LocalOffers.SetPoints.Ready = false
	self.LocalOffers.SetPoints.DoClick = function(pnl)
		Derma_StringRequest( "Set Points", "Input the amount of points to give. ( You have " .. LocalPlayer():PS_GetPoints() .. " points. )", "",
			function( text )
				if (text:match("%W")) then return end
				net.Start('PS.Trading_SetPoints')
					net.WriteUInt(self.TradeID, 8)
					net.WriteUInt(tonumber(text), 32)
				net.SendToServer()
			end,
		 	function() end
		)


	end
	self.LocalOffers.SetPoints.Paint = function(pnl, w, h)
		if pnl.Hovered then surface.SetDrawColor(65, 91, 118, 255)
		elseif pnl.Depressed then surface.SetDrawColor(44, 62, 80, 255)
		else surface.SetDrawColor(52, 73, 94, 255) end

		surface.DrawRect(0, 0, w, h)
	end
	self.LocalOffers.SetPoints.UpdateColours = self.UpdateButtonColours
	self.LocalOffers.SetPoints:SetText( "Set Points" )

	self.LocalOffers.ScrollPanel = vgui.Create("DScrollPanel", self.LocalOffers)
	self.LocalOffers.ScrollPanel:Dock(FILL)
	self.LocalOffers.ScrollPanel:DockMargin(8, 48, 8, 8)

	self.LocalOffers.ScrollPanel.Paint = function(pnl, w, h)
		surface.SetDrawColor(40, 40, 40, 255)
		surface.DrawRect(0, 0, w, h)
	end
		
	self.LocalOffers.Inventory = vgui.Create('DIconLayout', self.LocalOffers.ScrollPanel)
	self.LocalOffers.Inventory:SetBorder(8)
	self.LocalOffers.Inventory:SetSpaceX(8)
	self.LocalOffers.Inventory:SetSpaceY(8)
		
	self.LocalOffers.ScrollPanel:AddItem(self.LocalOffers.Inventory)

	self.OtherOffers = vgui.Create("DPanel", self.RightContainer)
	self.OtherOffers:Dock(TOP)
	self.OtherOffers:DockMargin(4, 4, 4, 4)
	self.OtherOffers.Points = 0
	self.OtherOffers.Paint = function(pnl, w, h)
		surface.SetDrawColor(54, 54, 54, 255)
		surface.DrawRect(0, 0, w, h)

		local x = draw.SimpleText(self.Recipient:Nick() .. "'s Offerings:", "PSTradingLarge", 48, 24, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(pnl.Points .. " points", "PSTradingLarge", 48 + x + 4, 24, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	self.OtherOffers.Avatar = vgui.Create("AvatarImage", self.OtherOffers)
	self.OtherOffers.Avatar:SetPos(8, 8)
	self.OtherOffers.Avatar:SetSize(32, 32)

	self.OtherOffers.Ready = vgui.Create("DButton", self.OtherOffers)
	self.OtherOffers.Ready:SetSize(96, 32)
	self.OtherOffers.Ready.Ready = false
	self.OtherOffers.Ready.Paint = function(pnl, w, h)
		local paintFunc = pnl.Ready and self.PaintAcceptButton or self.PaintCancelButton
		paintFunc(pnl, w, h)

		if (pnl.Ready) then pnl:SetText("Ready")
			else pnl:SetText("Not Ready") end
	end
	self.OtherOffers.Ready.UpdateColours = self.UpdateButtonColours

	self.OtherOffers.ScrollPanel = vgui.Create("DScrollPanel", self.OtherOffers)
	self.OtherOffers.ScrollPanel:Dock(FILL)
	self.OtherOffers.ScrollPanel:DockMargin(8, 48, 8, 8)

	self.OtherOffers.ScrollPanel.Paint = function(pnl, w, h)
		surface.SetDrawColor(40, 40, 40, 255)
		surface.DrawRect(0, 0, w, h)
	end
		
	self.OtherOffers.Inventory = vgui.Create('DIconLayout', self.OtherOffers.ScrollPanel)
	self.OtherOffers.Inventory:SetBorder(8)
	self.OtherOffers.Inventory:SetSpaceX(8)
	self.OtherOffers.Inventory:SetSpaceY(8)
		
	self.OtherOffers.ScrollPanel:AddItem(self.OtherOffers.Inventory)

	-- swagggg
	self:PimpMyScrollbar(self.LocalInventory.VBar)
	self:PimpMyScrollbar(self.LocalOffers.ScrollPanel.VBar)
	self:PimpMyScrollbar(self.OtherOffers.ScrollPanel.VBar)

	self:MakePopup()
end

function PANEL:ThemeInit()
	self.btnClose:SetVisible( false )
	self.btnMaxim:SetVisible( false )
	self.btnMinim:SetVisible( false )

	self.lblTitle:SetFont( "PSTradingLarge" )
end

function PANEL:PerformLayout()
	self.lblTitle:SetPos(10, 8) -- LOWER PLS
	self.lblTitle:SetSize( self:GetWide() - 25, 20 )

	self.AcceptButton:SetPos( self:GetWide() - self.CancelButton:GetWide() - 8 - self.AcceptButton:GetWide() - 8, self:GetTall() - self.AcceptButton:GetTall() - 8 )
	self.CancelButton:SetPos( self:GetWide() - self.CancelButton:GetWide() - 8, self:GetTall() - self.CancelButton:GetTall() - 8 )

	self.LocalOffers:SetTall( self:GetTall() / 2 - 40)
	self.OtherOffers:SetTall( self:GetTall() / 2 - 40)

	self.LocalOffers.Inventory:SetWide( self.LocalOffers.ScrollPanel:GetWide() )
	self.OtherOffers.Inventory:SetWide( self.OtherOffers.ScrollPanel:GetWide() )

	self.LocalOffers.Ready:SetPos(self.LocalOffers:GetWide() - self.LocalOffers.Ready:GetWide() - 8, 8)
	self.OtherOffers.Ready:SetPos(self.OtherOffers:GetWide() - self.OtherOffers.Ready:GetWide() - 8, 8)

	self.LocalOffers.SetPoints:SetPos(self.LocalOffers:GetWide() - self.LocalOffers.Ready:GetWide() - 8 - self.LocalOffers.SetPoints:GetWide() - 8, 8)
end

function PANEL:Paint(w, h)
	surface.SetDrawColor(40, 40, 40, 255)
	surface.DrawRect(0, 0, w, h)
end

function PANEL:PaintAcceptButton(w, h)
	if self.Hovered then surface.SetDrawColor(88, 214, 141, 255)
	elseif self.Depressed or self:GetDisabled() then surface.SetDrawColor(39, 173, 96, 255)
	else surface.SetDrawColor(46, 204, 113, 255) end

	surface.DrawRect(0, 0, w, h)
end

function PANEL:PaintCancelButton(w, h)
	if self.Hovered then surface.SetDrawColor(236, 112, 99, 255)
	elseif self.Depressed then surface.SetDrawColor(196, 65, 51, 255)
	else surface.SetDrawColor(231, 76, 60, 255) end

	surface.DrawRect(0, 0, w, h)
end

function PANEL:UpdateButtonColours()
	self:SetTextStyleColor(Color(255, 255, 255, 255 * (self.Depressed and 0.75 or 1)))
end

function PANEL:PimpMyScrollbar(panel)
	panel.Paint = function(pnl, w, h)
		surface.SetDrawColor(85, 85, 85, 255)
		surface.DrawRect(0, 0, w, h)
	end
	panel.btnUp.Paint = function( pnl, w, h )
		surface.SetDrawColor(255, 255, 255, 255)

		local x = w/2 - 3
		local y = h/2 - 2

		-- i didn't want to use a material, SUE ME BITCH.
		surface.DrawRect(x+0, y+3, 1, 3)
		surface.DrawRect(x+1, y+2, 1, 3)
		surface.DrawRect(x+2, y+1, 1, 3)
		surface.DrawRect(x+3, y+0, 1, 3)
		surface.DrawRect(x+4, y+1, 1, 3)
		surface.DrawRect(x+5, y+2, 1, 3)
		surface.DrawRect(x+6, y+3, 1, 3)
	end
	panel.btnDown.Paint = function( pnl, w, h )
		surface.SetDrawColor(255, 255, 255, 255)

		local x = w/2 - 3
		local y = h/2

		-- i didn't want to use a material, SUE ME BITCH.
		surface.DrawRect(x+0, y-3, 1, 3)
		surface.DrawRect(x+1, y-2, 1, 3)
		surface.DrawRect(x+2, y-1, 1, 3)
		surface.DrawRect(x+3, y-0, 1, 3)
		surface.DrawRect(x+4, y-1, 1, 3)
		surface.DrawRect(x+5, y-2, 1, 3)
		surface.DrawRect(x+6, y-3, 1, 3)
	end
	panel.btnGrip.Paint = function( pnl, w, h )
		if pnl.Hovered then surface.SetDrawColor(40, 40, 40, 255)
		else surface.SetDrawColor(51, 51, 51, 255) end

		surface.DrawRect(1, 1, w-2, h-2)
	end
end

function PANEL:Notify(msg)
	surface.PlaySound("UI/buttonclick.wav")
	self.TradeChat.ChatArea.ChatHTML = "<p><span class='timestamp'>" .. os.date("[%H:%M]") .. "</span>" .. msg .. "</p>" .. self.TradeChat.ChatArea.ChatHTML
	self.TradeChat.ChatArea:SetHTML(self.TradeChat.ChatArea.FormatHTML .. self.TradeChat.ChatArea.ChatHTML)
end

function PANEL:SendMessage()
	local msg = self.TradeChat.TextEntry:GetValue()
	if not msg or msg == "" then return end

	net.Start('PS.Trading_SendMessage')
		net.WriteUInt(self.TradeID, 8)
		net.WriteString(msg)
	net.SendToServer()

	self.TradeChat.TextEntry:SetText("")
end

function PANEL:Setup( id )
	self.TradeID = id

	local trade = PS.Trading.ActiveTrades[id]

	for k, v in pairs(trade.traders) do
		if ( v == LocalPlayer() ) then self.LocalKey = k
		else self.RecipientKey = k; self.Recipient = v end
	end

	self.OtherOffers.Avatar:SetPlayer(self.Recipient, 32)

	self:SetTitle("Trade with " .. self.Recipient:Nick())
	self:Notify("Trade with " .. self.Recipient:Nick())
end

function PANEL:AddItem(key, item)
	local pnl = ( (key == self.RecipientKey) and self.OtherOffers ) or self.LocalOffers

	local ITEM = PS.Items[item]

	local model = vgui.Create('DPointShopItem')
	model:SetData(ITEM)
	model:SetSize(96, 96)
	model:SetBackgroundColor(Color(42, 42, 42, 255))

	model.PaintOver = function(pnl, w, h)
		surface.SetDrawColor(0, 0, 0, 125)
		surface.DrawRect(0, h - pnl.InfoHeight, w, pnl.InfoHeight)
	
		draw.SimpleText(pnl.Data.Name, "PSTradingItemText", w / 2, h - (pnl.InfoHeight / 2), Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, w, h)
	end

	model.DoClick = function(pnl)
		if (key == self.RecipientKey) then return end

		net.Start('PS.Trading_RemoveItem')
			net.WriteUInt(self.TradeID, 8)
			net.WriteString(ITEM.ID)
		net.SendToServer()
	end
			
	pnl.Inventory:Add(model)
end

function PANEL:RemoveItem(key, item)
	local pnl = ( (key == self.RecipientKey) and self.OtherOffers ) or self.LocalOffers

	for k, v in pairs ( pnl.Inventory:GetChildren() ) do
		if ( v.Data.ID != item ) then continue end
		v:Remove()
	end

	pnl.Inventory:InvalidateLayout()
end

function PANEL:SetPoints(key, points)
	local pnl = ( (key == self.RecipientKey) and self.OtherOffers ) or self.LocalOffers
	pnl.Points = points
end

function PANEL:ReadyChanged(key, state)
	local pnl = ( (key == self.RecipientKey) and self.OtherOffers ) or self.LocalOffers
	pnl.Ready.Ready = state
end

vgui.Register("DPointShopTradeScreen", PANEL, "DFrame")