do -- includes / resources
    AddCSLuaFile("sh_trading.lua")
    AddCSLuaFile("cl_trading.lua")
    AddCSLuaFile("vgui/DPointShopTradeNotification.lua")
    AddCSLuaFile("vgui/DPointShopTradeScreen.lua")

    include("sh_trading.lua")
end

do -- networked strings sv->cl
    util.AddNetworkString('PS.Trading_StartTrade')
    util.AddNetworkString('PS.Trading_RequestTrade')
    util.AddNetworkString('PS.Trading_EndTrade')
    util.AddNetworkString('PS.Trading_TradeDeclined')
    util.AddNetworkString('PS.Trading_ReadyChanged')
    util.AddNetworkString('PS.Trading_Notify')
    util.AddNetworkString('PS.Trading_ItemAdded')
    util.AddNetworkString('PS.Trading_ItemRemoved')
    util.AddNetworkString('PS.Trading_PointsSet')
end

do -- networked strings cl->sv
    util.AddNetworkString('PS.Trading_AcceptTradeRequest')
    util.AddNetworkString('PS.Trading_DeclineTradeRequest')
    util.AddNetworkString('PS.Trading_AcceptTrade')
    util.AddNetworkString('PS.Trading_CancelTrade')
    util.AddNetworkString('PS.Trading_ToggleReady')
    util.AddNetworkString('PS.Trading_SendMessage')
    util.AddNetworkString('PS.Trading_AddItem')
    util.AddNetworkString('PS.Trading_RemoveItem')
    util.AddNetworkString('PS.Trading_SetPoints')
end

PS.Trading.RequestedTrades = {}
PS.Trading.ActiveTrades = {}

local function htmlize(s)
    s = s:gsub('&', '&amp;')
    s = s:gsub('<', '&lt;')
    s = s:gsub('>', '&gt;')
    return s
end

-- little function that runs through a table & removes any invalid players
local function ValidifyTable(tbl)
    for k, v in pairs(tbl) do if not IsValid(v) then tbl[k] = nil end end
    return tbl
end

function PS.Trading:ValidTrade(trade)
    if trade == nil then return false end
    if not IsValid(trade.sender) then return false end
    if not IsValid(trade.recipient) then return false end
    if (trade.starttime + self.RequestExpiryTime) < CurTime() then return false end
    return true
end

function PS.Trading:InvalidateTrades()
    for k, trade in pairs(self.RequestedTrades) do
        if not self:ValidTrade(trade) then
            self.RequestedTrades[k] = nil
        end
    end

    for k, trade in pairs(self.ActiveTrades) do
        if trade == nil then self.ActiveTrades[k] = nil end
        if not IsValid(trade.traders[1]) then self.ActiveTrades[k] = nil end
        if not IsValid(trade.traders[2]) then self.ActiveTrades[k] = nil end
    end
end

function PS.Trading:RequestTrade(sender, recipient)
    -- call this before anything, if our players disconnect or trade expires, this removes it.
    self:InvalidateTrades()

    -- validity checks, make sure the players aren't being silly or skiddies.
    if not IsValid(sender) or not sender:IsPlayer() then return end
    if not IsValid(recipient) then sender:PS_Notify("Invalid recipient. (Disconnected?)") return end
    if sender == recipient then return end -- let's not trade with ourselves alrighty?

    -- is our sender or recipient allowed to trade
    if not self:CanPlayerTrade(sender) then return sender:PS_Notify("You are not allowed to trade.") end
    if not self:CanPlayerTrade(recipient) then return sender:PS_Notify(recipient:Nick() .. " is not allowed to trade.") end

    -- if the recipient has already sent a request
    -- to the sender, let's not request again, let's accept.
    for _, trade in pairs(self.RequestedTrades) do
    	if trade.sender == recipient and trade.recipient == sender then
    	   self:AcceptTrade(sender, trade.id)
            return
        end
    end

    -- if the sender has already sent a trade request to someone
    -- let's not spam other people with them
    for _, trade in pairs(self.RequestedTrades) do
    	if trade.sender != sender then continue end
    	sender:PS_Notify("You've already requested a trade with another player.")
        return
    end

    local trade = {
        sender = sender,
        recipient = recipient,
        starttime = CurTime()
    }

    -- insert our trade request into the table and then
    -- assign the id as the key.
    local id = table.insert(self.RequestedTrades, trade)
    trade.id = id

    -- send our trade request to both the sender and the recipient
    -- the sender (and recp I guess) can know the start time, so he knows when request expires
    net.Start("PS.Trading_RequestTrade")
    net.WriteTable(trade)
    net.Send({ sender, recipient })
end

function PS.Trading:AcceptTrade(sender, requestid)
    -- call this before anything, if our players disconnect or trade expires, this removes it.
    self:InvalidateTrades()

    -- forced habit, always check your players validity.
    if not IsValid(sender) or not sender:IsPlayer() then return end

    -- maybe they're faking the trade id for some reason.
    local traderequest = self.RequestedTrades[requestid]
    if not self:ValidTrade(traderequest) then sender:PS_Notify("Invalid trade.") return end

    -- we can't trade two people at once
    -- ( this is so they can't put the same item in two trades at once and exploit )
    for k, v in pairs (self.ActiveTrades) do
        if table.HasValue(v.traders, sender) then sender:PS_Notify("You are already in a trade!") return end
        if table.HasValue(v.traders, traderequest.sender) then sender:PS_Notify(traderequest.sender:Nick() .. " is already in a trade!") return end
    end

    if traderequest.recipient != sender then
        sender:PS_Notify("That's not your trade request to accept.")
        return
    end

    -- okay let's start another table entry for AcceptedTrades
    -- this one keeps tracks of items either side of the wall.
    local trade = {
    	traders = {
    		traderequest.sender,
    		traderequest.recipient
        },

		traderitems = {
			{}, -- sender
			{}  -- recipient
		},

        ready = { false, false },
        points = { 0, 0 }
    }

    -- insert our accepted trade into the table and then
    -- assign the id as the key.
    local id = table.insert(self.ActiveTrades, trade)
    trade.id = id

    net.Start("PS.Trading_StartTrade")
    net.WriteTable(trade)
    net.WriteUInt(requestid, 8)
    net.Send(ValidifyTable(trade.traders))

    -- and let's remove the trade request, since they've now accepted
    self.RequestedTrades[requestid] = nil
end

function PS.Trading:DeclineTrade(sender, requestid)
    -- call this before anything, if our players disconnect or trade expires, this removes it.
    self:InvalidateTrades()

    -- forced habit, always check your players validity.
    if not IsValid(sender) or not sender:IsPlayer() then return end

    -- maybe they're faking the trade id for some reason.
    local traderequest = self.RequestedTrades[requestid]
    if not self:ValidTrade(traderequest) then sender:PS_Notify("Invalid trade.") return end

    net.Start("PS.Trading_TradeDeclined")
    net.WriteUInt(requestid, 8)
    net.Send(traderequest.sender)

    self.RequestedTrades[requestid] = nil
end

function PS.Trading:NotifyTrade(id, message, sender)
    local trade = self.ActiveTrades[id]
    if not trade then return end

    message = message or "No message?"

    net.Start("PS.Trading_Notify")
    net.WriteUInt(id, 8)
    net.WriteString(message)
    net.Send(sender or ValidifyTable(trade.traders))
end

function PS.Trading:NotifyTradeError(id, message, sender, dontescape)
    local trade = self.ActiveTrades[id]
    if not trade then return end

    message = message or "No message?"
    message = dontescape and message or htmlize(message)
    message = "<span class='error'>" .. message .. "</span>"

    net.Start("PS.Trading_Notify")
    net.WriteUInt(id, 8)
    net.WriteString(message)
    net.Send(sender or ValidifyTable(trade.traders))
end

function PS.Trading:EndTrade(id, reason)
    local trade = self.ActiveTrades[id]
    if not trade then return end

    reason = reason or "No reason specified."

    net.Start("PS.Trading_EndTrade")
    net.WriteUInt(id, 8)
    net.WriteString(reason)
    net.Send(ValidifyTable(trade.traders))

    self.ActiveTrades[id] = nil
end

function PS.Trading:AddItem(sender, id, item)
    local trade = self.ActiveTrades[id]
    if not trade then return end

    -- check if our sender is valid, the item exists and theat they have the item.
    -- else we'll end the trade or notify them.
    if not IsValid(sender) then self:EndTrade(id, "Invalid sender.") return end
    if not PS.Items[item] then self:NotifyTradeError(id, "That item doesn't exist.", sender) return end
    if not sender:PS_HasItem(item) then self:NotifyTradeError(id, "You don't own that item.", sender) return end

    -- check if this player is even in this trade.
    local cancel = true
    for _, v in pairs(trade.traders) do if (v == sender) then cancel = false end end
    if cancel then return end

    -- a little hacky, but we need to get the keys of the sender/recipient.
    local recipient, senderkey, recipientkey
    for k, v in pairs(trade.traders) do if (v != sender) then recipient = v; recipientkey = k else senderkey = k end end
    
    -- check if our recipient is valid, has the item already or if it's already on the table.
    -- else we'll end or notify them.
    if not IsValid(recipient) then return self:EndTrade(id, "Invalid recipient.") end 
    if recipient:PS_HasItem(item) then self:NotifyTradeError(id, "Recipient already has that item.", sender) return end
    if ( trade.ready[senderkey] ) then
        return self:NotifyTradeError(id, "You can't add items whilst 'ready'.", sender)
    end
    if table.HasValue(trade.traderitems[1], item) or table.HasValue(trade.traderitems[2], item) then
        return self:NotifyTradeError(id, "That item is already in trade.", sender)
    end

    -- check if our recipient is even allowed that item

    local ITEM = PS.Items[item]
    local cat_name = ITEM.Category
    local CATEGORY = PS:FindCategoryByName(cat_name)

    if ( CATEGORY.AllowedUserGroups and #CATEGORY.AllowedUserGroups > 0 ) and ( not table.HasValue(CATEGORY.AllowedUserGroups, recipient:PS_GetUsergroup()) ) then
        return self:NotifyTradeError(id, "Recipient isn't in the right usergroup for that item.", sender) end
    if CATEGORY.CanPlayerSee and not CATEGORY:CanPlayerSee(recipient) then
        return self:NotifyTradeError(id, "Recipient isn't allowed items in the <span class='highlight'>" .. htmlize(CATEGORY.Name) .. "</span> category.", sender, true) end
    if ITEM.CanPlayerBuy then
        local allowed, message
        if ( type(ITEM.CanPlayerBuy) == "function" ) then allowed, message = ITEM:CanPlayerBuy(self)
        elseif ( type(ITEM.CanPlayerBuy) == "boolean" ) then allowed = ITEM.CanPlayerBuy
        end

        if not allowed then return self:NotifyTradeError(id, "Recipient isn't allowed that item.", sender) end
    end

    -- finally add the item to the list.
    table.insert(trade.traderitems[senderkey], item)

    -- and notify our users.
    net.Start("PS.Trading_ItemAdded")
    net.WriteUInt(id, 8)
    net.WriteUInt(senderkey, 8)
    net.WriteString(item)
    net.Send(ValidifyTable(trade.traders))

    -- how about a nice message too
    local message = "added '" .. htmlize(PS.Items[item].Name) .. "'"
    message = "<span class='sender'>" .. htmlize(sender:Nick()) .. "</span> " .. message
    self:NotifyTrade(id, message)
end

function PS.Trading:SetPoints(sender, id, points)
    points = math.Clamp( points or 0, 0, 100000 )

    local trade = self.ActiveTrades[id]
    if not trade then return end

    -- check if our sender is valid, the item exists and theat they have the item.
    -- else we'll end the trade or notify them.
    if not IsValid(sender) then self:EndTrade(id, "Invalid sender.") return end
    
    -- check if this player is even in this trade.
    local cancel = true
    for _, v in pairs(trade.traders) do if (v == sender) then cancel = false end end
    if cancel then return end

    -- a little hacky, but we need to get the keys of the sender/recipient.
    local recipient, senderkey, recipientkey
    for k, v in pairs(trade.traders) do if (v != sender) then recipient = v; recipientkey = k else senderkey = k end end
    
    -- check if our recipient is valid, has the item already or if it's already on the table.
    -- else we'll end or notify them.
    if not IsValid(recipient) then return self:EndTrade(id, "Invalid recipient.") end 

    if ( trade.ready[senderkey] ) then
        return self:NotifyTradeError(id, "You can't change points whilst 'ready'.", sender)
    end

    if not sender:PS_HasPoints(points) then self:NotifyTradeError(id, "You don't have that many points.", sender) return end

    trade.points[senderkey] = points

    -- and notify our users.
    net.Start("PS.Trading_PointsSet")
    net.WriteUInt(id, 8)
    net.WriteUInt(senderkey, 8)
    net.WriteUInt(points, 32)
    net.Send(ValidifyTable(trade.traders))

    -- how about a nice message too
    local message = "sets " .. points .. " points"
    message = "<span class='sender'>" .. htmlize(sender:Nick()) .. "</span> " .. message
    self:NotifyTrade(id, message)
end

function PS.Trading:RemoveItem(sender, id, item)
    local trade = self.ActiveTrades[id]
    if not trade then return end

    -- check if our sender is valid, the item exists.
    -- else we'll end the trade or notify them.
    if not IsValid(sender) then self:EndTrade(id, "Invalid sender.") return end
    if not PS.Items[item] then self:NotifyTradeError(id, "That item doesn't exist.", sender) return end
    
    -- check if this player is even in this trade.
    local cancel = true
    for _, v in pairs(trade.traders) do if (v == sender) then cancel = false end end
    if cancel then return end

    -- a little hacky, but we need to get the keys of the sender/recipient.
    local recipient, senderkey, recipientkey
    for k, v in pairs(trade.traders) do if (v != sender) then recipient = v; recipientkey = k else senderkey = k end end
    
    -- check if our recipient is valid, and that the sender is actually offering the item.
    if not IsValid(recipient) then return self:EndTrade(id, "Invalid recipient.") end

    if not table.HasValue(trade.traderitems[senderkey], item) then
        return self:NotifyTradeError(id, "You haven't offered that item to remove it.", sender)
    end

    if ( trade.ready[senderkey] ) then
        return self:NotifyTradeError(id, "You can't remove items whilst 'ready'.", sender)
    end

    -- finally add the item to the list.
    table.RemoveByValue(trade.traderitems[senderkey], item)

    -- and notify our users.
    net.Start("PS.Trading_ItemRemoved")
    net.WriteUInt(id, 8)
    net.WriteUInt(senderkey, 8)
    net.WriteString(item)
    net.Send(ValidifyTable(trade.traders))

    -- how about a nice message too
    local message = "removed '" .. htmlize(PS.Items[item].Name) .. "'"
    message = "<span class='sender'>" .. htmlize(sender:Nick()) .. "</span> " .. message
    self:NotifyTrade(id, message)
end

function PS.Trading:ToggleReady(sender, id)
    local trade = self.ActiveTrades[id]
    if not trade then return end

    -- check if our sender is valid
    if not IsValid(sender) then self:EndTrade(id, "Invalid sender.") return end
    
    -- check if this player is even in this trade.
    local cancel = true
    for _, v in pairs(trade.traders) do if (v == sender) then cancel = false end end
    if cancel then return end

    -- get our hacky shit
    local recipient, senderkey, recipientkey
    for k, v in pairs(trade.traders) do if (v != sender) then recipient = v; recipientkey = k else senderkey = k end end

    local ready = !trade.ready[senderkey]
    trade.ready[senderkey] = ready

    -- and notify our users.
    net.Start("PS.Trading_ReadyChanged")
    net.WriteUInt(id, 8)
    net.WriteUInt(senderkey, 8)
    net.WriteBit(ready)
    net.Send(ValidifyTable(trade.traders))

    message = "<span class='sender'>" .. htmlize(sender:Nick()) .. "</span> " .. ( ready and "is now ready" or "is no longer ready" )
    self:NotifyTrade(id, message)
end

function PS.Trading:MakeTrade(id, sender)
    local trade = self.ActiveTrades[id]
    if not trade then return end

    -- basic validity checks, you know the drill by now.
    if not IsValid(trade.traders[1]) or not IsValid(trade.traders[2]) then self:EndTrade(id, "Someone is invalid.") end

    if ( table.HasValue(trade.ready, false) ) then
        return self:NotifyTradeError(id, "Both players aren't ready.", sender)
    end

    -- okay we need to check if the player's still own all the items they're talking about
    -- otherwise raise hell.
    -- imagine if they throw a ton of items in the trade and then sell them all before accepting.
    for i = 1, 2 do
        local j = i == 1 and 2 or 1 
        for k, v in pairs(trade.traderitems[i]) do
            if not trade.traders[i]:PS_HasItem(v) then
                return self:NotifyTradeError(id, trade.traders[i]:Nick() .. " no longer owns an item they were going to trade.")
            end
            if trade.traders[j]:PS_HasItem(v) then
                return self:NotifyTradeError(id, trade.traders[j]:Nick() .. " owns an item they were going to be traded.")
            end
        end
    end

    -- check if they've spent any of their points whilst they've been ready
    for i = 1, 2 do
        if ( not trade.traders[i]:PS_HasPoints(trade.points[i]) ) then
            -- you cheeky turd, fuck off.
            return self:NotifyTradeError(id, trade.traders[i]:Nick() .. " no longer has the points they were going to trade.")
        end
    end

    -- alrighty, I can't think of any other checks that need to be made.
    -- let's give the trader 1 trader 2's offerings and
    -- give trader 2 trader 1's offerings.
    for i = 1, 2 do
        local j = i == 1 and 2 or 1
        for k, v in pairs(trade.traderitems[i]) do
            trade.traders[i]:PS_TakeItem(v)
            trade.traders[j]:PS_GiveItem(v)
        end
        trade.traders[i]:PS_TakePoints(trade.points[i])
        trade.traders[j]:PS_GivePoints(trade.points[i])
    end

    self:EndTrade(id, "Trade done.")
end

do -- networked hooks
    net.Receive('PS.Trading_AcceptTradeRequest', function(length, ply)
        local id = net.ReadUInt(8)
        PS.Trading:AcceptTrade(ply, id)
    end)

    net.Receive('PS.Trading_DeclineTradeRequest', function(length, ply)
        local id = net.ReadUInt(8)
        PS.Trading:DeclineTrade(ply, id)
    end)

    net.Receive('PS.Trading_AcceptTrade', function(length, ply)
        local id = net.ReadUInt(8)

        local trade = PS.Trading.ActiveTrades[id]
        if not trade then return end

        -- check if this player is even in this trade.
        local cancel = true
        for _, v in pairs(trade.traders) do if (v == ply) then cancel = false end end
        if cancel then return end

        PS.Trading:MakeTrade(id, ply)
    end)

    net.Receive('PS.Trading_CancelTrade', function(length, ply)
        local id = net.ReadUInt(8)

        local trade = PS.Trading.ActiveTrades[id]
        if not trade then return end

        -- check if this player is even in this trade.
        local cancel = true
        for _, v in pairs(trade.traders) do if (v == ply) then cancel = false end end
        if cancel then return end

        PS.Trading:EndTrade(id, ply:Nick() .. " cancelled.")
    end)
    net.Receive('PS.Trading_SendMessage', function(length, ply)
        local id = net.ReadUInt(8)

        local trade = PS.Trading.ActiveTrades[id]
        if not trade then return end

        -- check if this player is even in this trade.
        local cancel = true
        for _, v in pairs(trade.traders) do if (v == ply) then cancel = false end end
        if cancel then return end

        local message = htmlize(net.ReadString())
        message = "<span class='sender'>" .. htmlize(ply:Nick()) .. ":</span> " .. message

        PS.Trading:NotifyTrade(id, message)
    end)
    net.Receive('PS.Trading_ToggleReady', function(length, ply)
        local id = net.ReadUInt(8)

        local trade = PS.Trading.ActiveTrades[id]
        if not trade then return end

        PS.Trading:ToggleReady(ply, id)
    end)

    net.Receive('PS.Trading_AddItem', function(length, ply)
        local id = net.ReadUInt(8)

        local trade = PS.Trading.ActiveTrades[id]
        if not trade then return end

        local item = net.ReadString()

        PS.Trading:AddItem(ply, id, item)
    end)

    net.Receive('PS.Trading_RemoveItem', function(length, ply)
        local id = net.ReadUInt(8)

        local trade = PS.Trading.ActiveTrades[id]
        if not trade then return end

        local item = net.ReadString()

        PS.Trading:RemoveItem(ply, id, item)
    end)

    net.Receive('PS.Trading_SetPoints', function(length, ply)
        local id = net.ReadUInt(8)

        local trade = PS.Trading.ActiveTrades[id]
        if not trade then return end

        local points = net.ReadUInt(32)

        PS.Trading:SetPoints(ply, id, points)
    end)
end

do -- chat command
    local function FindPlayer( name )
        for _, ply in ipairs( player.GetAll() ) do
            if ( string.lower( ply:Nick() ) == string.lower( name ) or string.find( string.lower( ply:Nick() ), string.lower( name ), nil, true ) ) then
                return ply
            end
        end
    end

    hook.Add("PlayerSay", "PSTrading_ChatCommand", function(ply, text)
        local chat_string = string.Explode(" ", text)
        if chat_string[1] == PS.Trading.TradeChatCommand then
            table.remove(chat_string, 1)
            local ply_name = table.concat( chat_string, " " )
            local endply = FindPlayer(ply_name)

            if endply then
                PS.Trading:RequestTrade(ply, endply)
                return ""
            end
        end
    end)
end