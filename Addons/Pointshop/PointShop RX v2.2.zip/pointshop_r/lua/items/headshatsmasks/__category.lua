CATEGORY.Name = 'Hats, Heads and Masks'
CATEGORY.Icon = 'emoticon_smile'
CATEGORY.AllowedEquipped = 2
