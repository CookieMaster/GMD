CATEGORY.Name = 'Trails'
CATEGORY.Icon = 'rainbow'
