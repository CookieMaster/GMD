CATEGORY.Name = 'Accessories'
CATEGORY.Icon = 'add'
