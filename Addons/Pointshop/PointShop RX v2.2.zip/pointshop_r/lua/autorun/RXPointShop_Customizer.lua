RXPointShopConfig = {}

RXPointShopConfig.Col = {}
/* ───────────────────────────────────
	Color Part ( Blue & Black )
─────────────────────────────────── */

	-- BG Color ( 3D Player Preview ) --
	
		-- 3D Virtual World
		RXPointShopConfig.Col.BGCol_Ground = Color(0,150,255,255)
		RXPointShopConfig.Col.BGCol_Boarder = Color(0,150,510,255)
		RXPointShopConfig.Col.BGCol_Grid = Color(0,45,62,255)
	
		-- Some Information HUD
		RXPointShopConfig.Col.Info_Text = Color(0,150,255,255)
		RXPointShopConfig.Col.Info_Line = Color(0,255,255,255)
	-- Main Color
	
		-- Some Texts
		RXPointShopConfig.Col.Main_TitleText = Color(200,200,255,255)
		RXPointShopConfig.Col.Main_CategoryText = Color(0,255,255,255)
		
		-- Outline
		RXPointShopConfig.Col.Main_OutLine = Color(0,150,255,255)
		RXPointShopConfig.Col.Main_ScrollBarOutLine = Color(0,150,255,255)
		
		--DSWButtons ( Shop Filters , "Give Points" or "Admin Menu" button etc.. )
		RXPointShopConfig.Col.Main_DSWButton_OutLine = Color(0,150,255,255)
		RXPointShopConfig.Col.Main_DSWButton_Text = Color(255,255,255,255)
		RXPointShopConfig.Col.Main_DSWButton_ClickFX = Color(0,0,255,255)
		
		-- Item Button ( with included item icon , name , price )
		RXPointShopConfig.Col.Main_ItemIcon_Line = Color(0,200,255,50)
		RXPointShopConfig.Col.Main_ItemIcon_Name = Color(100,180,255,255)
		RXPointShopConfig.Col.Main_ItemIcon_Price = Color(150,100,255,255)
		RXPointShopConfig.Col.Main_ItemIcon_ModelBackGround = Color(100,120,255,20)
		
		-- Hovered Item Info panel
		RXPointShopConfig.Col.Main_HIIP_OutLine = Color(0,200,255,255)
		RXPointShopConfig.Col.Main_HIIP_Name = Color(0,255,255,255)
		
		RXPointShopConfig.Col.Main_HIIP_InfoText_Positive = Color(0,255,255,255)
		RXPointShopConfig.Col.Main_HIIP_InfoText_Negative = Color(255,0,0,255)