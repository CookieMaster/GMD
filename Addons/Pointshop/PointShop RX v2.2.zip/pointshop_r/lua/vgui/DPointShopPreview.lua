local PANEL = {}

timer.Simple(0.1,function()
	RXPS_StationBGModel = {
		GroundBasic = { Model = "models/props_trainstation/trainstation_clock001.mdl", Material = "models/props_combine/CombineThumper002",Size = Vector(0.1,100,100),Color = RXPointShopConfig.Col.BGCol_Ground,Angle = Angle(270,0,0),RTAngle = Angle(0,0,0),Pos = Vector(0,0,-15) },
		ShowCaseGroundOL = { Model = "models/hunter/tubes/circle2x2.mdl", Material = "models/debug/debugwhite",Size = Vector(4,4,0.1),Color = RXPointShopConfig.Col.BGCol_Boarder,Angle = Angle(0,0,0),RTAngle = Angle(0,0,0),Pos = Vector(0,0,-5) },
		ShowCaseGround = { Model = "models/hunter/tubes/circle2x2.mdl", Material = "",Size = Vector(3.7,3.7,1),Color = RXPointShopConfig.Col.BGCol_Grid,Angle = Angle(0,0,0),RTAngle = Angle(0,0,0),Pos = Vector(0,0,-4) },
	}
end)
function PANEL:RemoveProp()
	for k,v in pairs(self.StationModelEnts) do
		v:Remove()
	end
end

function PANEL:Init()
	self:SetModel(LocalPlayer():GetModel())
	
	self.Zoom = 100
	self.Height = 50
	
	self.CamPos = Vector(self.Zoom,0,self.Height)
	self.ViewPos = Vector(0,0,self.Height)
	
	self.CamAngle = (self.ViewPos - self.CamPos):Angle()
	self:SetAnimated(false)
	
	
	self.StationModelEnts = {}
	for k,v in pairs(RXPS_StationBGModel) do
		local Models = ClientsideModel( v.Model, RENDER_GROUP_VIEW_MODEL_OPAQUE )
		Models:SetPos(v.Pos)
		Models:SetAngles(v.Angle)
		if v.Material then
			Models:SetMaterial(v.Material)
		end
		Models:SetNoDraw( true )
		Models.Col = v.Color
		
		local mat = Matrix()
		mat:Scale(v.Size)
		Models:EnableMatrix("RenderMultiply", mat)
		table.insert(self.StationModelEnts,Models)
	end
end

function PANEL:OnCursorEntered()
	self.Hovering = true
end

function PANEL:OnCursorExited()
	self.Hovering = false
end

function PANEL:OnMouseWheeled(mc)
	self.Zoom = self.Zoom - mc *5
	self.Zoom = math.min(self.Zoom,500)
	self.Zoom = math.max(self.Zoom,40)
	
	self.CamPos = Vector(math.sin(self.CamAngle.y)*self.Zoom,math.cos(self.CamAngle.y)*self.Zoom,self.Height)
end

function PANEL:Think()
	if !self.Hovering then return end
	
		if input.IsMouseDown(MOUSE_LEFT) then
			if !self.LM then
				self.LM = true
				local MX,MY = gui.MousePos()
				self.LastMousePos_X = MX
				self.LastMousePos_Y = MY
			else
				local CX,CY = gui.MousePos()
				local DX,DY = self.LastMousePos_X-CX,self.LastMousePos_Y-CY
				
				self.CamAngle.y = self.CamAngle.y - DX/150
				
				self.Height = self.Height - DY/30
				self.Height = math.min(self.Height,80)
				self.Height = math.max(self.Height,20)
	
				self.CamPos = Vector(self.Zoom,0,self.Height)
				self.ViewPos = Vector(0,0,self.Height)
				
				self.LastMousePos_X = CX
				self.LastMousePos_Y = CY
				
				self.CamPos = Vector(math.sin(self.CamAngle.y)*self.Zoom,math.cos(self.CamAngle.y)*self.Zoom,self.Height)
			end
		else
			if self.LM then
				self.LM = false
			end
		end
end

function PANEL:Paint()
	if ( !IsValid( self.Entity ) ) then return end

	surface.SetDrawColor( Color(0,0,0,255) )
	surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
	

	local x, y = self:LocalToScreen( 0, 0 )

	self:LayoutEntity( self.Entity )

	local w, h = self:GetSize()
	cam.Start3D( self.CamPos, (self.ViewPos - self.CamPos):Angle(), self.fFOV, x, y, w, h, 5, 4096 )

	render.SuppressEngineLighting( true )
	render.SetLightingOrigin( self.Entity:GetPos() )
	render.ResetModelLighting( self.colAmbientLight.r/255, self.colAmbientLight.g/255, self.colAmbientLight.b/255 )
	render.SetColorModulation( self.colColor.r/255, self.colColor.g/255, self.colColor.b/255 )
	render.SetBlend( math.min(self:GetAlpha()/255,self.colColor.a/255) )

	for i=0, 6 do
		local col = self.DirectionalLight[ i ]
		if ( col ) then
			render.SetModelLighting( i, col.r/255, col.g/255, col.b/255 )
		end
	end
	
		for k,v in pairs(self.StationModelEnts) do
			render.SetColorModulation( v.Col.r/255,v.Col.g/255,v.Col.b/255 )
			v:DrawModel()
			render.SetColorModulation( 1,1,1 )
		end

	self.Entity:DrawModel()

	self:DrawOtherModels()
	
	render.SetBlend(1)
	render.SuppressEngineLighting( false )
	cam.End3D()

	self.LastPaint = RealTime()
	--
	-- Control Helper
	surface.SetDrawColor( RXPointShopConfig.Col.Info_Line )
	surface.DrawRect( 20, 95, 150, 1 )
	surface.DrawRect( 95, 20, 1, 150 )
	
	draw.SimpleText("Yaw Angle", "RXF_TrebOut_S20", 125,92, RXPointShopConfig.Col.Info_Text)
	draw.SimpleText("Camera Height", "RXF_TrebOut_S20", 95,5, RXPointShopConfig.Col.Info_Text,TEXT_ALIGN_CENTER)
	
	draw.SimpleText("Zooming : " .. math.Round(self.Zoom), "RXF_TrebOut_S20", 10,self:GetTall()-25, RXPointShopConfig.Col.Info_Text)
	-- Control Helper
end



function PANEL:DrawOtherModels()
	local ply = LocalPlayer()
	
	if PS.ClientsideModels[ply] then
		for item_id, model in pairs(PS.ClientsideModels[ply]) do
			local ITEM = PS.Items[item_id]
			
			if not ITEM.Attachment and not ITEM.Bone then PS.ClientsideModel[ply][item_id] = nil continue end
			
			local pos = Vector()
			local ang = Angle()
			
			if ITEM.Attachment then
				local attach_id = self.Entity:LookupAttachment(ITEM.Attachment)
				if not attach_id then return end
				
				local attach = self.Entity:GetAttachment(attach_id)
				
				if not attach then return end
				
				pos = attach.Pos
				ang = attach.Ang
			else
				local bone_id = self.Entity:LookupBone(ITEM.Bone)
				if not bone_id then return end
				
				pos, ang = self.Entity:GetBonePosition(bone_id)
			end
			
			model, pos, ang = ITEM:ModifyClientsideModel(ply, model, pos, ang)
			
			model:SetPos(pos)
			model:SetAngles(ang)
			
			model:DrawModel()
		end
	end
	
	if PS.HoverModel then
		local ITEM = PS.Items[PS.HoverModel]
		
		if ITEM.NoPreview then return end -- don't show
		if ITEM.WeaponClass then return end -- hack for weapons
		
		if not ITEM.Attachment and not ITEM.Bone then -- must be a playermodel?
			self:SetModel(ITEM.Model)
		else
			local model = PS.HoverModelClientsideModel
			
			local pos = Vector()
			local ang = Angle()
			
			if ITEM.Attachment then
				local attach_id = self.Entity:LookupAttachment(ITEM.Attachment)
				if not attach_id then return end
				
				local attach = self.Entity:GetAttachment(attach_id)
				
				if not attach then return end
				
				pos = attach.Pos
				ang = attach.Ang
			else
				local bone_id = self.Entity:LookupBone(ITEM.Bone)
				if not bone_id then return end
				
				pos, ang = self.Entity:GetBonePosition(bone_id)
			end
			
			model, pos, ang = ITEM:ModifyClientsideModel(ply, model, pos, ang)
			
			model:SetPos(pos)
			model:SetAngles(ang)
			
			model:DrawModel()
		end
	else
		self:SetModel(LocalPlayer():GetModel())
	end
end

vgui.Register('DPointShopPreview', PANEL, 'DModelPanel')
