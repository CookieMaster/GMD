surface.CreateFont('PS_Heading', { font = 'coolvetica', size = 64 })
surface.CreateFont('PS_Heading2', { font = 'coolvetica', size = 24 })
surface.CreateFont('PS_Heading3', { font = 'coolvetica', size = 19 })

-- RocketMania's
local Fonts = {}
	Fonts["RXF_CoolV"] = "coolvetica"
	Fonts["RXF_Treb"] = "Trebuchet MS"
	
	
for a,b in pairs(Fonts) do
	for k=10,40 do
		surface.CreateFont( a .. "_S"..k,{font = b,size = k,weight = 700})
		surface.CreateFont( a .. "Out_S"..k,{font = b,size = k,weight = 700,outline = true})
	end
end

local ALL_ITEMS = 1
local OWNED_ITEMS = 2
local UNOWNED_ITEMS = 3

local function BuildItemMenu(menu, ply, itemstype, callback)
	local plyitems = ply:PS_GetItems()
	
	for category_id, CATEGORY in pairs(PS.Categories) do
		
		local catmenu = menu:AddSubMenu(CATEGORY.Name)
		
		table.SortByMember(PS.Items, PS.Config.SortItemsBy, function(a, b) return a > b end)
		
		for item_id, ITEM in pairs(PS.Items) do
			if ITEM.Category == CATEGORY.Name then
				if itemstype == ALL_ITEMS or (itemstype == OWNED_ITEMS and plyitems[item_id]) or (itemstype == UNOWNED_ITEMS and not plyitems[item_id]) then
					catmenu:AddOption(ITEM.Name, function() callback(item_id) end)
				end
			end
		end
	end
end

hook.Add("PS_ItemAdjusted","PS_Item_Adjusted",function()
	if PS.ShopMenu and PS.ShopMenu:IsValid() then
		PS.ShopMenu:UpdateMyInventory()
		PS.ShopMenu:UpdateMyEquippedItem()
		PS.ShopMenu:UpdateCurrentShopList()
	end
end)

local PANEL = {}

function PANEL:UpdateMyInventory()
	self.InventoryListP:Clear()
	
			local items = {}
			for _, i in pairs(PS.Items) do
				table.insert(items, i)
			end
			table.SortByMember(items, "Name", function(a, b) return a > b end)
			
				local Count = 0
				for _, ITEM in pairs(items) do
					if LocalPlayer():PS_HasItem(ITEM.ID) and !LocalPlayer():PS_HasItemEquipped(ITEM.ID) then
						Count = Count + 1
						local Refund = PS.Config.CalculateSellPrice(LocalPlayer(), ITEM)
						
						local BGP = vgui.Create("RPS_DSWButton")
						BGP.BoarderCol = Color(0,0,0,0)
						BGP.TextCol = Color(0,0,150,255)
						BGP:SetSize(self.ShopListP:GetWide(), 45)
						BGP:SetTexts("")
						BGP.Count = Count%2
						BGP.PaintOverlay = function(slf)
							draw.SimpleText(ITEM.Name, 'RXF_Treb_S22', slf:GetTall()+5, 2, RXPointShopConfig.Col.Main_ItemIcon_Name)
							draw.SimpleText("Refund : " .. string.Comma(Refund), 'RXF_Treb_S22', slf:GetWide()-5, 25, RXPointShopConfig.Col.Main_ItemIcon_Price,TEXT_ALIGN_RIGHT)
						end
						BGP.PaintBackGround = function(slf)
							surface.SetDrawColor( Color(0,10,slf.Count*10+30,120) )
							surface.DrawRect( 1, 1, slf:GetWide()-2, slf:GetTall()-2 )
							
							surface.SetDrawColor( RXPointShopConfig.Col.Main_ItemIcon_Line )
							surface.DrawRect( 1, slf:GetTall()-1, slf:GetWide()-2, 1 )
						end
						
						local model = vgui.Create('DPointShopItem',BGP)
						model:SetData(ITEM)
						model:SetPos(1,1)
						model:SetSize(BGP:GetTall()-2, BGP:GetTall()-2)
						
						BGP.Click = function(slf)
							model:DoClick()
						end
							
						self.InventoryListP:AddItem(BGP)
					end
				end
end

function PANEL:UpdateCurrentShopList(Name)
	self.CurrentShopFilterName = Name or self.CurrentShopFilterName or "Weapons"
	
	self.ShopListP:Clear()
	
		local items = {}
		for _, i in pairs(PS.Items) do
			table.insert(items, i)
		end
		table.SortByMember(items, "Name", function(a, b) return a > b end)
			
		local Count = 0
		for _, ITEM in pairs(items) do
			if ITEM.Category == self.CurrentShopFilterName and !LocalPlayer():PS_HasItem(ITEM.ID) then
				Count = Count + 1
				
				local Price = PS.Config.CalculateBuyPrice(LocalPlayer(), ITEM)
				
				local BGP = vgui.Create("RPS_DSWButton")
				BGP.BoarderCol = Color(0,0,0,0)
				BGP.TextCol = Color(0,0,150,255)
				BGP:SetSize(self.ShopListP:GetWide(), 45)
				BGP:SetTexts("")
				BGP.Count = Count%2
				BGP.PaintOverlay = function(slf)
					draw.SimpleText(ITEM.Name, 'RXF_Treb_S22', slf:GetTall()+5, 2, RXPointShopConfig.Col.Main_ItemIcon_Name)
					draw.SimpleText("Price : " .. string.Comma(Price), 'RXF_Treb_S22', slf:GetWide()-5, 25, RXPointShopConfig.Col.Main_ItemIcon_Price,TEXT_ALIGN_RIGHT)
				end
				BGP.PaintBackGround = function(slf)
					surface.SetDrawColor( Color(0,10,slf.Count*10+30,120) )
					surface.DrawRect( 1, 1, slf:GetWide()-2, slf:GetTall()-2 )
					
					surface.SetDrawColor( RXPointShopConfig.Col.Main_ItemIcon_Line )
					surface.DrawRect( 1, slf:GetTall()-1, slf:GetWide()-2, 1 )
				end
				
				local model = vgui.Create('DPointShopItem',BGP)
				model:SetData(ITEM)
				model:SetPos(1,1)
				model:SetSize(BGP:GetTall()-2, BGP:GetTall()-2)
						
						BGP.Click = function(slf)
							model:DoClick()
						end
						
				self.ShopListP:AddItem(BGP)
			end
		end
end


function PANEL:UpdateMyEquippedItem()
	self.EquipListP:Clear()
	
			local items = {}
			for _, i in pairs(PS.Items) do
				table.insert(items, i)
			end
			table.SortByMember(items, "Name", function(a, b) return a > b end)
			
				local Count = 0
				for _, ITEM in pairs(items) do
					if LocalPlayer():PS_HasItemEquipped(ITEM.ID) then
						Count = Count + 1
						local Refund = PS.Config.CalculateSellPrice(LocalPlayer(), ITEM)
						
						local BGP = vgui.Create("RPS_DSWButton")
						BGP.BoarderCol = Color(0,0,0,0)
						BGP.TextCol = Color(0,0,150,255)
						BGP:SetSize(self.ShopListP:GetWide(), 45)
						BGP:SetTexts("")
						BGP.Count = Count%2
						BGP.PaintOverlay = function(slf)
							draw.SimpleText(ITEM.Name, 'RXF_Treb_S22', slf:GetTall()+5, 2, RXPointShopConfig.Col.Main_ItemIcon_Name)
							draw.SimpleText("Refund : " .. string.Comma(Refund), 'RXF_Treb_S22', slf:GetWide()-5, 25, RXPointShopConfig.Col.Main_ItemIcon_Price,TEXT_ALIGN_RIGHT)
						end
						BGP.PaintBackGround = function(slf)
							surface.SetDrawColor( Color(0,10,slf.Count*10+30,120) )
							surface.DrawRect( 1, 1, slf:GetWide()-2, slf:GetTall()-2 )
							
							surface.SetDrawColor( RXPointShopConfig.Col.Main_ItemIcon_Line )
							surface.DrawRect( 1, slf:GetTall()-1, slf:GetWide()-2, 1 )
						end
						
						local model = vgui.Create('DPointShopItem',BGP)
						model:SetData(ITEM)
						model:SetPos(1,1)
						model:SetSize(BGP:GetTall()-2, BGP:GetTall()-2)
								
						BGP.Click = function(slf)
							model:DoClick()
						end
								
						self.EquipListP:AddItem(BGP)
					end
				end
end


function PANEL:OpenAdminTAB()
		-- admin tab
		local AdminTab = vgui.Create('DFrame',self)
		AdminTab:SetSize(ScrW()/5*4,ScrH()/5*4)
		AdminTab:Center()
		
		AdminTab:SetDeleteOnClose(true)
		AdminTab:SetBackgroundBlur(true)
		AdminTab:SetDrawOnTop(true)
		
		local ClientsList = vgui.Create('DListView', AdminTab)
		ClientsList:DockMargin(10, 10, 10, 10)
		ClientsList:Dock(FILL)
		
		ClientsList:SetMultiSelect(false)
		ClientsList:AddColumn('Name')
		ClientsList:AddColumn('Points'):SetFixedWidth(60)
		ClientsList:AddColumn('Items'):SetFixedWidth(60)
		
		ClientsList.OnClickLine = function(parent, line, selected)
			local ply = line.Player
			
			local menu = DermaMenu()
			
			menu:AddOption('Set '..PS.Config.PointsName..'...', function()
				Derma_StringRequest(
					"Set "..PS.Config.PointsName.." for " .. ply:GetName(),
					"Set "..PS.Config.PointsName.." to...",
					"",
					function(str)
						if not str or not tonumber(str) then return end
						
						net.Start('PS_SetPoints')
							net.WriteEntity(ply)
							net.WriteInt(tonumber(str), 32)
						net.SendToServer()
					end
				)
			end)
			
			menu:AddOption('Give '..PS.Config.PointsName..'...', function()
				Derma_StringRequest(
					"Give "..PS.Config.PointsName.." to " .. ply:GetName(),
					"Give "..PS.Config.PointsName.."...",
					"",
					function(str)
						if not str or not tonumber(str) then return end
						
						net.Start('PS_GivePoints')
							net.WriteEntity(ply)
							net.WriteInt(tonumber(str), 32)
						net.SendToServer()
					end
				)
			end)
			
			menu:AddOption('Take '..PS.Config.PointsName..'...', function()
				Derma_StringRequest(
					"Take "..PS.Config.PointsName.." from " .. ply:GetName(),
					"Take "..PS.Config.PointsName.."...",
					"",
					function(str)
						if not str or not tonumber(str) then return end
						
						net.Start('PS_TakePoints')
							net.WriteEntity(ply)
							net.WriteInt(tonumber(str), 32)
						net.SendToServer()
					end
				)
			end)
			
			menu:AddSpacer()
			
			BuildItemMenu(menu:AddSubMenu('Give Item'), ply, UNOWNED_ITEMS, function(item_id)
				net.Start('PS_GiveItem')
					net.WriteEntity(ply)
					net.WriteString(item_id)
				net.SendToServer()
			end)
			
			BuildItemMenu(menu:AddSubMenu('Take Item'), ply, OWNED_ITEMS, function(item_id)
				net.Start('PS_TakeItem')
					net.WriteEntity(ply)
					net.WriteString(item_id)
				net.SendToServer()
			end)
			
			menu:Open()
		end
		
		self.ClientsList = ClientsList
end



function PANEL:Init()
local MotherPanel = self
	self:SetSize( ScrW(),ScrH() )
	
			-- sorting
			local categories = {}
			
			for _, i in pairs(PS.Categories) do
				table.insert(categories, i)
			end
			
			table.sort(categories, function(a, b) 
				if a.Order == b.Order then 
					return a.Name < b.Name
				else
					return a.Order < b.Order
				end
			end)
			
			local items = {}
			
			for _, i in pairs(PS.Items) do
				table.insert(items, i)
			end
			
			table.SortByMember(items, "Name", function(a, b) return a > b end)
	
	
	
			local TopBar = vgui.Create("DPanel",self)
			TopBar:SetSize(ScrW(),25)
			TopBar:SetPos(0,0)
			TopBar.Paint = function(slf)
				surface.SetDrawColor( 12,17,21,255 )
				surface.DrawRect(0, 0, slf:GetWide(), slf:GetTall())
				surface.SetDrawColor( RXPointShopConfig.Col.Main_OutLine )
				surface.DrawRect(0, slf:GetTall()-1, slf:GetWide(), 1)
				draw.SimpleText("PointShop By _Undefined.  Reskined By RocketMania", 'RXF_Treb_S22', 20, 2, RXPointShopConfig.Col.Main_TitleText)
			end
	
				local Button = vgui.Create("RPS_DSWButton",TopBar)
				Button:SetSize(100,24)
				Button:SetPos(TopBar:GetWide()-100,0)
				Button.BoarderCol = Color(0,0,0,0)
				Button:SetTexts("Close")
				Button.Click = function(slf)
					PS:ToggleMenu()
				end
	
	-- preview panel

	local ListSize = math.min(self:GetWide()/2,250)
	
	local preview
	if PS.Config.DisplayPreviewInMenu then
		preview = vgui.Create('DPanel', self)
		preview:SetPos(ListSize,25)
		preview:SetSize(self:GetWide()-ListSize*2,self:GetTall()-25)
		
		local previewpanel = vgui.Create('DPointShopPreview', preview)
		previewpanel:SetSize(preview:GetSize())
	end
	
	
	-- Right List
	
	local RightList = vgui.Create("DPanel",self) self.RightListP = RightList
	RightList:SetPos(self:GetWide()-ListSize,25)
	RightList:SetSize(ListSize,self:GetTall()-25)
	RightList.Paint = function(slf)
		surface.SetDrawColor( 12,17,21,255 )
		surface.DrawRect(0, 0, slf:GetWide(), slf:GetTall())
		surface.SetDrawColor( RXPointShopConfig.Col.Main_OutLine )
		surface.DrawRect(0, 0, 1, slf:GetTall())
	end
	
		local BG_ShopList = vgui.Create("DPanel",RightList)
		BG_ShopList:SetPos(2,2)
		BG_ShopList:SetSize(RightList:GetWide()-6,(RightList:GetTall()-35) -5)
		BG_ShopList.Paint = function(slf)
			draw.SimpleText("Shop Filters", 'RXF_Treb_S22', 10, 2, RXPointShopConfig.Col.Main_CategoryText)
			draw.SimpleText("Shop Items", 'RXF_Treb_S22', 10, 125, RXPointShopConfig.Col.Main_CategoryText)
		end
			
			-- Filter Lister
			
			local List = vgui.Create("DPanelList", BG_ShopList) self.FilterLister = List
			List:SetPos(10,30);
			List:SetSize(BG_ShopList:GetWide()-20, 90);
			List:SetSpacing(0);
			List:SetPadding(0);
			List:EnableVerticalScrollbar(true);
			List:EnableHorizontal(false);
			List:RPS_PaintListBarC()
			List.Paint = function(slf) --
				draw.RoundedBox(2, 0, 0, slf:GetWide(), slf:GetTall(), RXPointShopConfig.Col.Main_OutLine)
				draw.RoundedBox(2, 1, 1, slf:GetWide()-2, slf:GetTall()-2, Color(0,0,0,255))
			end
			function List:UpdateCategoryList()
					for _, CATEGORY in pairs(categories) do
						if CATEGORY.AllowedUserGroups and #CATEGORY.AllowedUserGroups > 0 then
							if not table.HasValue(CATEGORY.AllowedUserGroups, LocalPlayer():PS_GetUsergroup()) then
								continue
							end
						end
						
						if CATEGORY.CanPlayerSee then
							if not CATEGORY:CanPlayerSee(LocalPlayer()) then
								continue
							end
						end
						
						if !MotherPanel.CurrentShopFilterName then
							MotherPanel:UpdateCurrentShopList(CATEGORY.Name)
						end
						
						local Button = vgui.Create("RPS_DSWButton")
						Button:SetSize(self:GetWide()-5,20)
						Button:SetTexts(CATEGORY.Name) -- 'icon16/' .. CATEGORY.Icon .. '.png'
						Button.Font = "RXF_Treb_S20"
						Button:SetToolTip(CATEGORY.Name)
						Button.BoarderCol = Color(0,0,0,0)
						Button.TextCol = RXPointShopConfig.Col.Main_DSWButton_Text
						Button.Click = function(slf)
							MotherPanel:UpdateCurrentShopList(CATEGORY.Name)
						end
						Button.PaintBackGround = function(slf)
							if MotherPanel.CurrentShopFilterName and MotherPanel.CurrentShopFilterName == CATEGORY.Name then
								local COL = RXPointShopConfig.Col.Main_DSWButton_ClickFX
								COL.a = 50
								surface.SetDrawColor( COL )
								surface.DrawRect(1, 1, slf:GetWide()-2, slf:GetTall()-2)
							end
						end
						self:AddItem(Button)
					end
			end
			
			local List = vgui.Create("DPanelList", BG_ShopList) self.ShopListP = List
			List:SetPos(10,150);
			List:SetSize(BG_ShopList:GetWide()-20, BG_ShopList:GetTall()-160);
			List:SetSpacing(0);
			List:SetPadding(0);
			List:EnableVerticalScrollbar(true);
			List:EnableHorizontal(false);
			List:RPS_PaintListBarC()
			List.Paint = function(slf) --
				draw.RoundedBox(2, 0, 0, slf:GetWide(), slf:GetTall(), RXPointShopConfig.Col.Main_OutLine)
				draw.RoundedBox(2, 1, 1, slf:GetWide()-2, slf:GetTall()-2, Color(0,0,0,255))
			end

			
		if ((PS.Config.AdminCanAccessAdminTab and LocalPlayer():IsAdmin()) or (PS.Config.SuperAdminCanAccessAdminTab and LocalPlayer():IsSuperAdmin())) then
			local givebutton = vgui.Create('RPS_DSWButton', RightList)
			givebutton:SetPos(10,RightList:GetTall()-35)
			givebutton:SetSize(RightList:GetWide()-20,30)
			givebutton:SetTexts("Admin Menu")
			givebutton.Click = function(slf)
				self:OpenAdminTAB()
			end
		else
			BG_ShopList:SetSize(RightList:GetWide()-6,RightList:GetTall() -5)
			self.ShopListP:SetSize(BG_ShopList:GetWide()-20, BG_ShopList:GetTall()-160);
		end
	
	-- Left List
	
	local LeftList = vgui.Create("DPanel",self) self.LeftListP = LeftList
	LeftList:SetPos(0,25)
	LeftList:SetSize(ListSize,self:GetTall()-25)
	LeftList.Paint = function(slf)
		surface.SetDrawColor( 12,17,21,255 )
		surface.DrawRect(0, 0, slf:GetWide(), slf:GetTall())
		surface.SetDrawColor( RXPointShopConfig.Col.Main_OutLine )
		surface.DrawRect(slf:GetWide()-1, 0, 1, slf:GetTall())
	end
	
		local BG_EqiupList = vgui.Create("DPanel",LeftList)
		BG_EqiupList:SetPos(2,2)
		BG_EqiupList:SetSize(LeftList:GetWide()-6,(LeftList:GetTall()-85)/5*2 -5)
		BG_EqiupList.Paint = function(slf)
			draw.SimpleText("Equipped Items", 'RXF_Treb_S22', 10, 2, RXPointShopConfig.Col.Main_CategoryText)
		end
		
			local List = vgui.Create("DPanelList", BG_EqiupList) self.EquipListP = List
			List:SetPos(10, 30);
			List:SetSize(BG_EqiupList:GetWide()-20, BG_EqiupList:GetTall()-35);
			List:SetSpacing(5);
			List:SetPadding(5);
			List:EnableVerticalScrollbar(true);
			List:EnableHorizontal(false);
			List:RPS_PaintListBarC()
			List.Paint = function(slf) --
				draw.RoundedBox(2, 0, 0, slf:GetWide(), slf:GetTall(), RXPointShopConfig.Col.Main_OutLine)
				draw.RoundedBox(2, 1, 1, slf:GetWide()-2, slf:GetTall()-2, Color(0,0,0,255))
			end
		
		local BG_InventoryList = vgui.Create("DPanel",LeftList) 
		BG_InventoryList:SetPos(2,(LeftList:GetTall()-80)/5*2)
		BG_InventoryList:SetSize(LeftList:GetWide()-6,(LeftList:GetTall()-85)/5*3 -5)
		BG_InventoryList.Paint = function(slf)
			draw.SimpleText("Inventory Items", 'RXF_Treb_S22', 10, 2, RXPointShopConfig.Col.Main_CategoryText)
		end
		
			local List = vgui.Create("DPanelList", BG_InventoryList) self.InventoryListP = List
			List:SetPos(10, 30);
			List:SetSize(BG_InventoryList:GetWide()-20, BG_InventoryList:GetTall()-35);
			List:SetSpacing(5);
			List:SetPadding(5);
			List:EnableVerticalScrollbar(true);
			List:EnableHorizontal(false);
			List:RPS_PaintListBarC()
			List.Paint = function(slf) --
				draw.RoundedBox(2, 0, 0, slf:GetWide(), slf:GetTall(), RXPointShopConfig.Col.Main_OutLine)
				draw.RoundedBox(2, 1, 1, slf:GetWide()-2, slf:GetTall()-2, Color(0,0,0,255))
			end
	
		local MyINFO = vgui.Create("DPanel",LeftList)
		MyINFO:SetPos(10,LeftList:GetTall()-85)
		MyINFO:SetSize(LeftList:GetWide()-20,40)
		MyINFO.Paint = function(slf)
			surface.SetDrawColor( 20,20,20,255 )
			surface.DrawRect(0, 0, slf:GetWide(), slf:GetTall())
			surface.SetDrawColor( RXPointShopConfig.Col.Main_OutLine )
			surface.DrawRect(0, 0, slf:GetWide(), 1)
			surface.DrawRect(0, slf:GetTall()-1, slf:GetWide(), 1)
			draw.SimpleText("Current Points" , 'RXF_Treb_S20', slf:GetWide()/2, 2, RXPointShopConfig.Col.Main_CategoryText,TEXT_ALIGN_CENTER)
			draw.SimpleText(string.Comma(LocalPlayer():PS_GetPoints()), 'RXF_Treb_S20', slf:GetWide()/2, 20, RXPointShopConfig.Col.Main_CategoryText,TEXT_ALIGN_CENTER)
		end
		
		-- give points button
		
		if PS.Config.CanPlayersGivePoints then
			local givebutton = vgui.Create('RPS_DSWButton', LeftList)
			givebutton:SetPos(10,LeftList:GetTall()-35)
			givebutton:SetSize(LeftList:GetWide()-20,30)
			givebutton:SetTexts("Give "..PS.Config.PointsName)
			givebutton.Click = function()
				vgui.Create('DPointShopGivePoints')
			end
		end
	
	
	
	self.FilterLister:UpdateCategoryList()
	self:UpdateMyInventory()
	self:UpdateMyEquippedItem()

end

function PANEL:Think()
	if self.ClientsList and self.ClientsList:IsValid() then
		local lines = self.ClientsList:GetLines()
		
		for _, ply in pairs(player.GetAll()) do
			local found = false
			
			for _, line in pairs(lines) do
				if line.Player == ply then
					found = true
				end
			end
			
			if not found then
				self.ClientsList:AddLine(ply:GetName(), ply:PS_GetPoints(), table.Count(ply:PS_GetItems())).Player = ply
			end
		end
		
		for i, line in pairs(lines) do
			if IsValid(line.Player) then
				local ply = line.Player
				
				line:SetValue(1, ply:GetName())
				line:SetValue(2, ply:PS_GetPoints())
				line:SetValue(3, table.Count(ply:PS_GetItems()))
			else
				self.ClientsList:RemoveLine(i)
			end
		end
	end
end

function PANEL:Paint()
	surface.SetDrawColor( 0,0,0,255 )
	surface.DrawRect(0, 0, ScrW(), ScrH())
end

vgui.Register('DPointShopMenu', PANEL)
