	-- Made by Phoenixf129, hosted on Coderhire
	-- See license.txt for more info

	PSDrops = PSDrops or {}

	-- Are the below commands enabled?
	-- Due to the nature of the system, you may have to spam these commands before anyone gets anything :)
	-- I suggest you change the below commands to something unique.
	PSDrops.DebugEnabled 		 = true
	PSDrops.DebugCommand  	 	 = "ps_debugdrop"
	PSDrops.DebugCommand2 		 = "ps_debugdropme"

	PSDrops.DefaultItemColor  		 = Color(0,255,0)

	-- Global sounds played to players when an item is found.
	PSDrops.AnnounceSound 		 = "ambient/levels/canals/windchime2.wav"
	-- Sound that plays when the menu opens.
	PSDrops.MenuSound	  		 = "ambient/levels/canals/windchime2.wav"

	-- Theme Stuff
	PSDrops.WindowColor  		 = Color(26, 30, 38, 100) --Main window color
	PSDrops.BannerColor 		 = Color(26, 30, 38, 180) --Banner color, default is white
	PSDrops.CanvasColor  		 = Color(255, 255, 255, 180) --Canvas color, default is white
	PSDrops.CanvasBorderColor	 = Color(0, 0, 0, 180) --Canvas color, default is white

	-- In minutes.
	-- The system will randomise a time between these to do initiate a drop sequence.
	PSDrops.DropTimeMin 		 = 1
	PSDrops.DropTimeMax			 = 15

	-- Highest price to lowest price due to how the Color scan works.
	-- price, color. 
	PSDrops.PColors = {
		[1000]    = Color(255,255,0),
		[2000]    = Color(255,150,0),
		[5000] 	  = Color(255,0,0),
		[10000]   = Color(150,50,255),
	}

	-- Lower the number, higher the droprate. 
	-- I prefer to keep them the same, but here's a free feature for you guys that want infinite drops for owner...
	PSDrops.DefaultDropRate = 30
	PSDrops.DropRate = {
		["owner"]  		  = 30,
		["devsuper"]      = 30,
		["superadmin"]    = 30,
		["admin"] 		  = 30,
		["moderator"] 	  = 30,
		["donator"]  	  = 30,
		["user"]   		  = 30,
	}
	
	-- The way pointshop works, is the ID of the item, is it's lua filename. So if it's called craphat.lua, it's ID is craphat.
	-- Placing item ID's in here, will stop the system from dropping those item's at all.
	-- Ignore the true, it's only to fill the table so I can utilise keyvalues to check the tables faster.
	PSDrops.ItemBlackList = {
		["craphat"]	 = true,
		["craphat2"]	 = true,
	}
	
	-- Category blacklist. Check inside _category.lua and copy it's Name into here to blacklist any item's inside the category!
	-- Example: CATEGORY.Name = 'Hats'
	-- Add ["Hats"] = true, below. Enjoy!
	PSDrops.CatBlackList = {
		["crapcat"] = true,
		["crapcat2"] = true,
	}

	-- Don't edit below here unless you know what you are doing.
	if SERVER then

		AddCSLuaFile()
		
		util.AddNetworkString( "net_PSDropMenu" )
		util.AddNetworkString( "net_PSDropChat" )

		local nextCheck = 0
		
		function PSDrops:ChooseItem()
			local safeTable = table.Copy(PS.Items)
			
			-- This should remove blacklisted entities from the table...
			for k, item in pairs(safeTable) do
				if PSDrops.CatBlackList[item.Category] then table.RemoveByValue( safeTable, k ) end
				if PSDrops.ItemBlackList[item.ID] then table.RemoveByValue( safeTable, k ) end
			end
			
			return table.Random(safeTable)
		end
		
		function PSDrops:DoThink(cmd, itemid, caller)
			local item = PS.Items[itemid]
			
			if !cmd then
				if nextCheck > CurTime() then return end
			end
			
			for _, ply in pairs(player.GetAll()) do
				
				-- Nothing for spectators.
				if caller and caller:IsValid() then
					if ply != caller then continue end
				end
				
				if !caller then
					local dnum = PSDrops.DefaultDropRate
					for rank, rate in pairs(PSDrops.DropRate) do
						if ply:IsUserGroup(rank) then
							dnum = rate
							break
						end
					end
					if math.random(1, dnum) != math.Round(dnum/2) then continue end
				end
						
				if !item then item = PSDrops:ChooseItem() end
				
				-- Paranoia check!
				if PSDrops.ItemBlackList[item.ID] then continue end
				
				net.Start("net_PSDropMenu")
					net.WriteString(item.ID)
				net.Send(ply)
					
				net.Start("net_PSDropChat")
					net.WriteEntity(ply)
					net.WriteString(item.ID)
				net.Broadcast()
				
				print(ply:Nick().." found "..item.Name)
				
				if not ply:PS_HasItem(item.ID) then 
					ply:PS_GiveItem(item.ID)
				end
			end
			nextCheck = CurTime() + math.random( PSDrops.DropTimeMin * 60, PSDrops.DropTimeMax * 60 )
		end
		hook.Add("Think", "PSDrops:DoThink", PSDrops.DoThink)

		-- A simple hacky method to make sure the debug command works, because i'm lazy.
		concommand.Add(PSDrops.DebugCommand, function(ply, cmd, args)
			if !PSDrops.DebugEnabled then return end
			
			PSDrops:DoThink(true, args[1])
		end)
		
		concommand.Add(PSDrops.DebugCommand2, function(ply, cmd, args)
			if !PSDrops.DebugEnabled then return end
			
			PSDrops:DoThink(true, args[1], ply)
		end)
		
	else

		surface.CreateFont("PSDropsFont70", {font = "Bebas Neue", size= 70, weight = 400, antialias = true } ) --Font used for titles
		surface.CreateFont("PSDropsFont32", {font = "Bebas Neue", size= 32, weight = 400, antialias = true } ) --Font used for titles
		surface.CreateFont("PSDropsFont24", {font = "Bebas Neue", size= 24, weight = 400, antialias = true } ) --Font used for titles
		surface.CreateFont("PSDropsFont18", {font = "Bebas Neue", size= 18, weight = 400, antialias = true } ) --Font used for titles
		surface.CreateFont("PSDropsFont14", {font = "Bebas Neue", size= 14, weight = 400, antialias = true } ) --Font used for titles

		function PSDrops:Coloring(item) 
			local itemColor = PSDrops.DefaultItemColor
			
			for pri, col in pairs(PSDrops.PColors) do
				if item.Price > pri then
					itemColor = col
					break
				end
			end
			
			return itemColor
		end
		
		net.Receive("net_PSDropMenu", function()
			local item_id = net.ReadString()
			
			PSDrops:Menu(item_id)
		end)

		net.Receive("net_PSDropChat", function()
			local ply = net.ReadEntity()
			local item_id = net.ReadString()
			
			PSDrops:Chat(ply, item_id)
		end)
		
		function PSDrops:Chat(ply, item_id)

			local item = PS.Items[item_id]
			local itemColor = PSDrops:Coloring(item)

			if ply:GetNWBool("NoAccount") then
				chat.AddText(
					Color(0,255,0), "[PSDrops] ",
					Color(255,255,255), ply:Nick().." would have found ",
					itemColor, item.Name,
					Color(255,255,255), " but he has no linked forum account!"
				)
			else
				chat.AddText(
					Color(0,255,0), '[PSDrops] ',
					Color(255,255,255), ply:Nick().." has just found ",
					itemColor, item.Name,
					Color(255,255,255), "!"
				)
				surface.PlaySound( PSDrops.AnnounceSound )
			end
		end
		
		function PSDrops:Menu(item_id)
		
			local item = PS.Items[item_id]
			local itemColor = PSDrops:Coloring(item)

			if not LocalPlayer() then return end
			if LocalPlayer():GetNWBool("NoAccount") then return end
			
			surface.PlaySound( PSDrops.MenuSound )
			
			if IsValid(PSDropsMainWindow) then
				PSDropsMainWindow:Close()
			end
			
			PSDropsMainWindow = vgui.Create( "DFrame" )
			PSDropsMainWindow:SetSize( ScrW(), ScrH() )
			PSDropsMainWindow:Center()
			PSDropsMainWindow:SetDraggable( false )
			PSDropsMainWindow:ShowCloseButton( true )
			PSDropsMainWindow.btnMaxim:SetVisible( false )
			PSDropsMainWindow.btnMinim:SetVisible( false )

			PSDropsMainWindow:SetTitle( "" )
			PSDropsMainWindow:SetBackgroundBlur( true )
			PSDropsMainWindow.Paint = PSDrops.PaintMainWindow
							
			PSDropsMainWindow:MakePopup()

			PSDropsCanvasBorder = vgui.Create('DPanel', PSDropsMainWindow)
			PSDropsCanvasBorder:SetPos(ScrW()/2-210, ScrH()/2-160)
			PSDropsCanvasBorder:SetSize(420,320)
			function PSDropsCanvasBorder:Paint(w,h)
				draw.RoundedBox(6,0,0,w,h,PSDrops.CanvasBorderColor)
			end
			
			PSDropsCanvas = vgui.Create('DPanel', PSDropsMainWindow)
			PSDropsCanvas:SetPos(ScrW()/2-200, ScrH()/2-150)
			PSDropsCanvas:SetSize(400,300)
			function PSDropsCanvas:Paint(w,h)
				draw.RoundedBox(6,0,0,w,h,PSDrops.CanvasColor)
			end
			
			PSDropCategory = vgui.Create("DLabel", PSDropsMainWindow)
			PSDropCategory:SetText("Category: "..item.Category)
			PSDropCategory:SetFont("PSDropsFont32")
			PSDropCategory:SizeToContents()
			PSDropCategory:Center()
			PSDropCategory:SetPos(ScrW()/2-(PSDropCategory:GetWide()/2), ScrH()/2+(PSDropsCanvas:GetTall()/2))
			PSDropCategory:SetColor(color_white)
			
			PSDropItem = vgui.Create("DLabel", PSDropsMainWindow)
			PSDropItem:SetText(item.Name)
			PSDropItem:SetFont("PSDropsFont70")
			PSDropItem:SizeToContents()
			PSDropItem:Center()
			PSDropItem:SetPos(ScrW()/2-(PSDropItem:GetWide()/2), ScrH()/2-((PSDropItem:GetTall()/2)+110))
			PSDropItem:SetColor(itemColor)
			
			if item.AdminOnly then
				PSDropAdminOnly = vgui.Create("DLabel", PSDropsMainWindow)
				PSDropAdminOnly:SetText("This Item is Admin Equippable only!")
				PSDropAdminOnly:SetFont("PSDropsFont70")
				PSDropAdminOnly:SizeToContents()
				PSDropAdminOnly:Center()
				PSDropAdminOnly:SetPos(ScrW()/2-(PSDropAdminOnly:GetWide()/2), ScrH()/2+(PSDropsCanvas:GetTall()/2)+80)
				PSDropAdminOnly:SetColor(color_white)
			end
			
			PSDropsItemBorder = vgui.Create('DPanel', PSDropsMainWindow)
			PSDropsItemBorder:SetPos(ScrW()/2-105, ScrH()/2-85)
			PSDropsItemBorder:SetSize(210,210)
			function PSDropsItemBorder:Paint(w,h)
				draw.RoundedBox(6,0,0,w,h,PSDrops.CanvasBorderColor)
			end
			
			local itemPanel = vgui.Create( 'DPointShopItem', PSDropsMainWindow )
			itemPanel:SetData( item )
			itemPanel:SetSize( 200, 200 )
			itemPanel:SetPos( (ScrW()/2)-100, (ScrH()/2)-80 )
			
			-- Let's overwrite this so we can add our own functionality. ALSO, when using original, it allows people to equip donator/Admin items for some stupid reason.
			itemPanel.DoClick = function()
				local points = PS.Config.CalculateBuyPrice(LocalPlayer(), item)
				
				if not LocalPlayer():PS_HasItem(item.ID) and not LocalPlayer():PS_HasPoints(points) then
					notification.AddLegacy("You don't have enough points for this!", NOTIFY_GENERIC, 5)
				end

				local menu = DermaMenu(item)
						
				if LocalPlayer():PS_HasItem(item.ID) then
					menu:AddOption('Sell', function()
						Derma_Query('Are you sure you want to sell ' .. item.Name .. '?', 'Sell Item',
							'Yes', function() LocalPlayer():PS_SellItem(item.ID) end,
							'No', function() end
						)
					end)
			
					menu:AddSpacer()
					
					if LocalPlayer():PS_HasItemEquipped(item.ID) then
						menu:AddOption('Holster', function()
							LocalPlayer():PS_HolsterItem(item.ID)
						end)
					else
						if not item.AdminOnly or (item.AdminOnly and LocalPlayer():IsAdmin()) then
							menu:AddOption('Equip', function()
								LocalPlayer():PS_EquipItem(item.ID)
							end)
						else
							menu:AddOption('Equip', function()
								notification.AddLegacy("This Item is Admin Equippable only!", NOTIFY_GENERIC, 5)
							end)
						end
					end
					
					if LocalPlayer():PS_HasItemEquipped(item.ID) and item.Modify then
						menu:AddSpacer()
						
						menu:AddOption('Modify...', function()
							PS.Items[item.ID]:Modify(LocalPlayer().PS_Items[item.ID].Modifiers)
						end)
					end

				end
							
				menu:Open()
			end
		end

		function PSDrops.PaintMainWindow()
			
			//Paint window itself
			Derma_DrawBackgroundBlur(PSDropsMainWindow)
			surface.SetDrawColor(PSDrops.WindowColor)
			
			PSDrops.CurrentHeight = ScrH()
			surface.DrawRect(0, 50, ScrW(), PSDrops.CurrentHeight)
			
			//Banner heading
			surface.SetDrawColor( PSDrops.BannerColor );
			surface.DrawRect( 0, 0, ScrW(), 75 );	
			draw.DrawText("Congratulations! You have found:", "PSDropsFont70", 10, 7, color_white, TEXT_ALIGN_LEFT)
				
		end

	end

	print("PSDrops:System Loaded (By Phoenixf129)!")