ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = ""
ENT.Author = "Loures"
ENT.Spawnable = false
ENT.AdminSpawnable = false
