include("shared.lua")

hook.Add("CalcView", "BASSCANNON", function(ply, orig, ang, fov) --Credits to Willox
	local r = GetConVar("ttt_basscannon_radius")
	local cvar = GetConVar("ttt_basscannon_shakescreen")
	if cvar and r then
		if cvar:GetBool() and ply:Alive() then
			local cannons = ents.FindByClass("ttt_bass_cannon")

			for k, v in pairs(cannons) do
				if v.StartedRaving then
					local dist = ply:GetPos() - v:GetPos()
					dist = dist:Dot(dist)          
			
					if dist <= r:GetInt() ^ 2 then
						local mul = 1.4

						if ply:GetRole() == ROLE_TRAITOR then
								mul = 0.2
						end

						ang:RotateAroundAxis(ang:Right(), (math.cos(RealTime() * 14 * mul)) * 7)
						ang:RotateAroundAxis(ang:Forward(), (math.cos(RealTime() * 4 * mul)) * 3)

						return {
							origin = orig,
							angles = ang,
							fov = fov
						}
					end
				end
			end
		end
	end
end)

function ENT:Initialize()
	timer.Simple(1.70, function() self.StartedRaving = true end)
end

surface.CreateFont("BASSFontWorld", {
	font = "Verdana",
	size = 19,
	weight = 600,
	antialias = true
})

function ENT:Draw()
	self:DrawModel()
	local pos, ang = self:GetPos(), self:GetAngles()
	ang:RotateAroundAxis(ang:Up(), 90)
	ang:RotateAroundAxis(ang:Forward(), 90)
	cam.Start3D2D(pos + ang:Up() * 2.29 + ang:Right() * -6.5, ang, 0.05)
		surface.SetDrawColor(color_black)
		surface.DrawRect(0, -1, 145, 55)
		surface.SetFont("BASSFontWorld")
		local w, h = surface.GetTextSize("BASS CANNON")
		surface.SetTextPos(71 - w / 2, 16)		
		if math.floor(CurTime() * 2 % 2) == 0 then surface.SetTextColor(Color(0, 0, 255)) else surface.SetTextColor(Color(255, 255, 0)) end
		surface.DrawText("BASS ")			
		surface.SetTextPos(w / 2 - 5, 16)
		if math.floor(CurTime() * 2 % 2) == 0 then surface.SetTextColor(Color(255, 255, 0)) else surface.SetTextColor(Color(0, 0, 255)) end
		surface.DrawText("CANNON")
	cam.End3D2D()
	ang:RotateAroundAxis(ang:Forward(), -180)
	ang:RotateAroundAxis(ang:Up(), 180)
	cam.Start3D2D(pos + ang:Up() * 2.29 + ang:Right() * -6.5 + ang:Forward() * -7.2, ang, 0.05)
		surface.SetDrawColor(color_black)
		surface.DrawRect(0, -1, 145, 55)
		surface.SetFont("BASSFontWorld")
		local w, h = surface.GetTextSize("BASS CANNON")
		surface.SetTextPos(71 - w / 2, 16)		
		if math.floor(CurTime() * 2 % 2) == 0 then surface.SetTextColor(Color(0, 0, 255)) else surface.SetTextColor(Color(255, 255, 0)) end
		surface.DrawText("BASS ")			
		surface.SetTextPos(w / 2 - 5, 16)
		if math.floor(CurTime() * 2 % 2) == 0 then surface.SetTextColor(Color(255, 255, 0)) else surface.SetTextColor(Color(0, 0, 255)) end
		surface.DrawText("CANNON")
	cam.End3D2D()
end