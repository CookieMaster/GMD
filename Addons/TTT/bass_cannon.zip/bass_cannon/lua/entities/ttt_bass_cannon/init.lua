AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/props/cs_office/radio.mdl")
	
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	
	local phys = self:GetPhysicsObject()
	if phys:IsValid() then
		phys:Wake()
	end
	self.Trigger = false
	self:EmitSound(self.Song, 125, 100)
	timer.Simple(29, function() if IsValid(self) then self:Remove() end end)
	timer.Simple(1.70, function() self.Trigger = true end)
end

function ENT:SetRadius(rad)
	self.radius = rad
	self.r = rad^2
end

function ENT:SetForce(force)
	self.force = force
end

function ENT:SetSong(song)
	self.Song = song
end

function ENT:Think()
	if self.Trigger then
		for _, prop in ipairs(ents.GetAll()) do
			if prop:GetClass() == "prop_physics" or prop:GetClass() == "prop_physics_multiplayer" and prop:GetSolid() == SOLID_VPHYSICS and !prop:IsPlayer() and prop:GetClass() ~= "prop_ragdoll" and prop:GetClass() ~= "ttt_bass_cannon" then
				if math.ceil(prop:BoundingRadius()) >= 12 then
					local dist = prop:GetPos() - self:GetPos()
					dist = dist:Dot(dist)
					if dist < self.r then
						dist = dist^.5
						local phys = prop:GetPhysicsObject()
						if phys:IsValid() then
							if phys:GetVelocity():LengthSqr() < 100 then
								phys:SetVelocity((prop:GetAngles():Forward() * -1 + Vector(math.random(0, 50), math.random(0, 50), math.random(0, 50)):GetNormalized()) * 800) --start moving it
							end
							if !prop.BassCannonEnt then
								prop.BassCannonEnt = self
								prop:AddCallback("PhysicsCollide", function(ent, cdata)
									if IsValid(ent.BassCannonEnt) then
										local phys = ent:GetPhysicsObject()
										local dist = (ent:GetPos() - ent.BassCannonEnt:GetPos()):LengthSqr()
										if cdata.OurOldVelocity:LengthSqr() > 1000 and dist < ent.BassCannonEnt.r then
											phys:SetVelocity((phys:GetAngles():Forward() * 0.7 - Vector(math.random(-100, 100), math.random(-100, 100), math.random(-100, 100))):GetNormalized() * ent.BassCannonEnt.force)
										end
									end
								end)
							end
						end
					end
				end
			end
		end
	end
end

hook.Add("EntityTakeDamage", "BASSCANNON", function(ent, dmginfo)
	if dmginfo:GetAttacker().BassCannonEnt then
		dmginfo:SetAttacker(IsValid(dmginfo:GetAttacker().BassCannonEnt.Owner) and dmginfo:GetAttacker().BassCannonEnt.Owner or dmginfo:GetAttacker())
		dmginfo:SetDamage(dmginfo:GetDamage() * 1.15) --make props more deadlier
	end
end)

function ENT:OnRemove()
	local effect = EffectData()
    effect:SetOrigin(self:GetPos())
    util.Effect("cball_explode", effect)
	for _, v in ipairs(ents.GetAll()) do
		v.BassCannonEnt = nil
	end
end
