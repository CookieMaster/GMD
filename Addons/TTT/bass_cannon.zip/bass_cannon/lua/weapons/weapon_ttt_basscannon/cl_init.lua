include("shared.lua")

SWEP.PrintName = "Bass Cannon"
SWEP.Slot      = 7 

--SWEP.ViewModelFOV  = 10
SWEP.ViewModelFlip = false
SWEP.Icon = "vgui/ttt/icon_loures_basscannon"

SWEP.EquipMenuData = {
  type = "item_weapon",
  name = "Bass Cannon",
  desc = "LET THE BASS CANNON KICK!\nPress MOUSE1 to deploy it.\nMOUSE2 to switch between the songs."
}

surface.CreateFont("BASSFont", {
	font = "Verdana",
	size = 30,
	weight = 600,
	antialias = true
})

surface.CreateFont("BASSFontSmall", {
	font = "Verdana",
	size = 18,
	weight = 600,
	antialias = true
})

local function DrawScrollingText(txt, y, wide, swep )
	local w = surface.GetTextSize(txt)
	w = w + 40
	local x = math.fmod(swep.songx, w) * -1
	while x < wide do
		surface.SetTextColor(color_white)
		surface.SetTextPos(x, y)
		surface.DrawText(txt)
		x = x + w
	end
end

function SWEP:Initialize()
	self.BaseClass.Initialize(self)
	self.CurrentSong = 1
	self.radiomdl = ClientsideModel("models/props/cs_office/radio.mdl")
	self.radiowmdl = ClientsideModel("models/props/cs_office/radio.mdl")
	self.radiomdl:SetNoDraw(true)
	self.radiowmdl:SetNoDraw(true)
	local m = Matrix()
	m:Scale(Vector(0.6, 1, 1))
	self.radiomdl:EnableMatrix("RenderMultiply", m)
	m:Scale(Vector(1, .75, .75))
	self.radiowmdl:EnableMatrix("RenderMultiply", m)
	self.songx = 0
	self.snd = CreateSound(self.Owner, self.SongList[1][1])
end

function SWEP:ViewModelDrawn(vm)
	local c4 = vm:LookupBone("v_weapon.c4")
	local rhand = vm:LookupBone("v_weapon.Right_Arm")
	self.songx = self.songx + 100 * FrameTime()
	local pos, ang2 = vm:GetBonePosition(c4)
	vm:ManipulateBoneScale(c4, Vector(0.01, 0.01, 0,01))
	for i = 0, 9 do
		local id = vm:LookupBone("v_weapon.button" .. tostring(i))
		vm:ManipulateBoneScale(id, Vector(0.01, 0.01, 0.01))
	end
	local ang = EyeAngles()
	ang:RotateAroundAxis(ang:Right(), -30)
	vm:ManipulateBonePosition(rhand, Vector(3, 2, -2))
	self.radiomdl:SetPos(pos + ang:Up() * -3 + ang:Right() * -1)
	self.radiomdl:SetAngles(ang)
	self.radiomdl:DrawModel()
	ang:RotateAroundAxis(ang:Forward(), 90)
	ang:RotateAroundAxis(ang:Right(), -270)
	ang:RotateAroundAxis(ang:Up(), -.3)
	cam.Start3D2D(self.radiomdl:GetPos() + ang:Up() * 1.5 + ang:Forward() * -7.11 + ang:Right() * -6.45, ang, 0.025)
		--render.SuppressEngineLighting(true)
		render.PushFilterMag(TEXFILTER.LINEAR)
		render.PushFilterMin(TEXFILTER.LINEAR)
		render.ClearStencil(); 
		render.SetStencilEnable(true);
		render.SetStencilFailOperation(STENCILOPERATION_KEEP);
		render.SetStencilZFailOperation(STENCILOPERATION_REPLACE);
		render.SetStencilPassOperation(STENCILOPERATION_REPLACE);
		render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_ALWAYS);
		render.SetStencilReferenceValue(1)
		
		surface.SetDrawColor(color_black)
		surface.DrawRect(0, 0, 285, 110)
		
		render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_EQUAL)
		render.SetStencilPassOperation(STENCILOPERATION_REPLACE )
		
		surface.SetDrawColor(Color(60, 97, 208))
		surface.DrawRect(0, 84, 285, 27)
		surface.SetFont("BASSFont")
		
		DrawScrollingText(self.SongList[self.CurrentSong][2], 82, 285, self)
		local w, h = surface.GetTextSize("BASS CANNON")
		surface.SetTextPos(142 - w / 2, 0)
		
		if math.floor(CurTime() * 2 % 2) == 0 then surface.SetTextColor(Color(0, 0, 255)) else surface.SetTextColor(Color(255, 255, 0)) end
		surface.DrawText("BASS ")			
		surface.SetTextPos(w / 2 + 30, 0)
		if math.floor(CurTime() * 2 % 2) == 0 then surface.SetTextColor(Color(255, 255, 0)) else surface.SetTextColor(Color(0, 0, 255)) end
		surface.DrawText("CANNON")
		
		surface.SetFont("BASSFontSmall")
		w = surface.GetTextSize("Switch songs with MOUSE2")
		surface.SetTextPos(142 - w / 2, 60 - 21)
		surface.SetTextColor(color_white)
		surface.DrawText("Switch songs with MOUSE2")
		
		render.PopFilterMag()
		render.PopFilterMin()
		render.SetStencilEnable(false);
		--render.SuppressEngineLighting(false)
	cam.End3D2D()
end

function SWEP:Holster()
	if !IsValid(self.Owner) then return end
	local vm = self.Owner:GetViewModel()
	if !IsValid(vm) then return end
	local c4 = vm:LookupBone("v_weapon.c4")
	local rhand = vm:LookupBone("v_weapon.Right_Arm")
	if c4 and rhand then
		vm:ManipulateBoneScale(c4, Vector(1, 1, 1))
		vm:ManipulateBonePosition(rhand, Vector(0, 0, 0))
	end
	for i = 0, 9 do
		local id = vm:LookupBone("v_weapon.button" .. tostring(i))
		if id then vm:ManipulateBoneScale(id, Vector(1, 1, 1)) end
	end
	if self.snd and self.snd:IsPlaying() then
		self.snd:Stop()
		self.snd = nil
	end
end

SWEP.OnRemove = SWEP.Holster

function SWEP:SecondaryAttack()
	if !IsFirstTimePredicted() then return end
	if self.CurrentSong == #self.SongList then
		self.CurrentSong = 1
	else
		self.CurrentSong = self.CurrentSong + 1
	end
	print(self.CurrentSong)
	self.songx = -20
	if self.snd and self.snd:IsPlaying() then
		self.snd:Stop()
		self.snd = nil
	end
	self.snd = CreateSound(self.Owner, self.SongList[self.CurrentSong][1])
	self.snd:PlayEx(0.5, 100)
end

function SWEP:DrawWorldModel()
	if IsValid(self.Owner) then
		local cr = self.Owner:LookupBone("ValveBiped.Bip01_R_Hand")
		--self:ManipulateBoneScale(cr, Vector(0.01, 0.01, 0.01))
		local pos, ang = self.Owner:GetBonePosition(cr)
		ang:RotateAroundAxis(ang:Up(), 33)
		ang:RotateAroundAxis(ang:Right(), 20)
		ang:RotateAroundAxis(ang:Forward(), 100)
		self.radiowmdl:SetRenderOrigin(pos + ang:Up() * 3 + ang:Forward())
		self.radiowmdl:SetRenderAngles(ang)
		self.radiowmdl:DrawModel()
	else
		self:DrawModel()
	end
end