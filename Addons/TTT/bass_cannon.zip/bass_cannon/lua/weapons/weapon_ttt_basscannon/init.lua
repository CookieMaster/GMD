AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

resource.AddFile("materials/vgui/ttt/icon_loures_basscannon.vmt")

for _, v in ipairs(SWEP.SongList) do
	resource.AddFile("sound/" .. v[1])
end

CreateConVar("ttt_basscannon_force", 800, FCVAR_ARCHIVE)

function SWEP:Initialize()
	self.BaseClass.Initialize(self)
	self.CurrentSong = 1
end

function SWEP:SecondaryAttack()
	if self.CurrentSong == #self.SongList then
		self.CurrentSong = 1
	else
		self.CurrentSong = self.CurrentSong + 1
	end
end



function SWEP:PrimaryAttack()
	local cannon = ents.Create("ttt_bass_cannon")
	cannon:SetPos(self.Owner:EyePos() + self.Owner:EyeAngles():Forward() * 10)
	cannon:SetRadius(GetConVar("ttt_basscannon_radius"):GetInt())
	cannon:SetForce(GetConVar("ttt_basscannon_force"):GetInt())
	cannon:SetSong(self.SongList[self.CurrentSong][1])
	cannon.Owner = self.Owner
	cannon.fingerprints = self.fingerprints
	cannon:Spawn()
	cannon:SetVelocity(self.Owner:EyeAngles():Forward() * 300 - Vector(0, 0, 150))
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	self:Remove()
end