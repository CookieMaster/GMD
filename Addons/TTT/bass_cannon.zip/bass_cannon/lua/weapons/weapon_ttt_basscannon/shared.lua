SWEP.Base = "weapon_tttbase"

SWEP.HoldType = "slam"

SWEP.ViewModel  = "models/weapons/v_c4.mdl"
SWEP.WorldModel = "models/props/cs_office/Cardboard_box02.mdl"

SWEP.Kind = WEAPON_EQUIP2
SWEP.AutoSpawnable = false
SWEP.CanBuy = { ROLE_TRAITOR }
SWEP.LimitedStock = true

SWEP.SongList = { --put your songs in here + title
	{"basscannon/bass1.mp3", "Knife Party - Centipede"},
	{"basscannon/bass2.mp3", "Krewella - One Minute (DotEXE Remix)"},
	{"basscannon/bass3.mp3", "Au5 - The Seahorse VIP"},
	{"basscannon/bass4.mp3", "Flux Pavilion - Bass Cannon"},
	{"basscannon/bass5.mp3", "Zomboy - Pump It Up"},
	{"basscannon/bass6.mp3", "Ajapai - Brain"}
}

CreateConVar("ttt_basscannon_shakescreen", 0, FCVAR_REPLICATED)
CreateConVar("ttt_basscannon_radius", 600, {FCVAR_ARCHIVE, FCVAR_REPLICATED})
