1. Extract to garrysmod/addons
2. Extract the sounds (https://dl.dropboxusercontent.com/u/8845827/Lua%20Files/basscannon_sounds.zip) to garrysmod/sound REMEMBER TO KEEP THE FOLDER TREE INTACT
3. REMEMBER TO SYNC FASTDL ASWELL
3. To choose whether the player's screen must shake use the cvar ttt_basscannon_shakescreen (defaults to 0)