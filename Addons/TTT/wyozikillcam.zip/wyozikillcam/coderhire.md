Wyozi Killcam adds a familiar killcam effect from Team Fortress 2 to Garry's Mod gamemodes. 

##Features

---

**Works for all gamemodes** 

**TTT integration** Automatically colors name based on attacker's role

**Freeze Cam** Familiar "Freeze Cam" screen, that freezes the screen to allow you to capture moments.

**Easily customizable** Includes convars to customize most things.

## Installation

---

Just unzip the addon to your addons folder and you're good to go!
