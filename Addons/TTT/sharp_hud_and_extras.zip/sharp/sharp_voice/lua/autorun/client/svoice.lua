local PANEL = {}
local PlayerVoicePanels = {}

function surface.DrawTrapezoid( x, y, w, h, col, a)
	local t = {
		{ x = x, y = y, u = 0, v = 0},
		{ x = x+w, y = y, u = 1, v = 0},
		{ x = x+w+a, y = y+h, u = 0, v = 1},
		{ x = x+a, y = y+h, u = 1, v = 1}
	}
	
	surface.SetMaterial(Material("vgui/white"))
	surface.SetDrawColor(col)
	surface.DrawPoly(t)
end

function PANEL:Init()
	self.LabelName = vgui.Create( "DLabel", self )
	self.LabelName:SetFont( "GModNotify" )
	self.LabelName:Dock( FILL )
	self.LabelName:DockMargin( 8, 0, 20, 0 )
	self.LabelName:SetTextColor( Color( 255, 255, 255, 255 ) )

	self.Avatar = vgui.Create( "AvatarImage", self )
	self.Avatar:SetSize( 32, 32 )
	self.Avatar:Dock( LEFT )
	self.Avatar:DockMargin( 25, 0, 0, 0 )

	self.Color = color_transparent

	self:SetSize( 250, 40 )
	self:DockPadding( 4, 4, 4, 4 )
	self:DockMargin( 2, 2, 2, 2 )
	self:Dock( BOTTOM )
end

function PANEL:Setup( ply )
	self.ply = ply
	self.LabelName:SetText( ply:Nick() )
	self.Avatar:SetPlayer( ply )
	self.Color = team.GetColor( ply:Team() )
	self:InvalidateLayout()
end

function PANEL:VoicePaint( w, h )
	surface.DrawTrapezoid( 0, 0, w-30, h, self.Color, 30)
	surface.DrawTrapezoid( 3, 1, w-34, h-2, Color(0, 0, 0, 150), 28)
end

function PANEL:Think()
	self.Paint = self.VoicePaint
	if ( self.fadeAnim ) then
		self.fadeAnim:Run()
	end
end

function PANEL:FadeOut( anim, delta, data )
	if ( anim.Finished ) then
		if ( IsValid( PlayerVoicePanels[ self.ply ] ) ) then
			PlayerVoicePanels[ self.ply ]:Remove()
			PlayerVoicePanels[ self.ply ] = nil
			return
		end
	return end		
	self:SetAlpha( 255 - (255 * delta) )
end
derma.DefineControl( "VoiceNotify", "", PANEL, "DPanel" )

local function PlayerEndVoice( ply )	
	if ( IsValid( PlayerVoicePanels[ ply ] ) ) then
		if ( PlayerVoicePanels[ ply ].fadeAnim ) then return end
		PlayerVoicePanels[ ply ].fadeAnim = Derma_Anim( "FadeOut", PlayerVoicePanels[ ply ], PlayerVoicePanels[ ply ].FadeOut )
		PlayerVoicePanels[ ply ].fadeAnim:Start( 2 )
	end
end

local function VoiceClean()
	for k, v in pairs( PlayerVoicePanels ) do
		if ( !IsValid( k ) ) then
			PlayerEndVoice( k )
		end
	end
end
timer.Create( "VoiceClean", 10, 0, VoiceClean )

hook.Add("Think", "ConstantlyOverrideSize", function()
	if !IsValid(g_VoicePanelList) then return end
	g_VoicePanelList:SetSize( 250, ScrH() - 200 )
end)
