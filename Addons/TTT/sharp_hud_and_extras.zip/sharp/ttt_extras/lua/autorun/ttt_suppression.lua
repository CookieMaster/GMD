if CLIENT then
	local is_sup = false
	local mult = 10
	usermessage.Hook("SUPPRESS", function()
		is_sup = true
		mult = 20
		timer.Simple(1.7, function()   
			hook.Add("Think", "_sup_fade", function()
				mult = mult - 0.1
				if mult <= 0 then
					hook.Remove("Think", "_sup_fade")
					is_sup = false
				end
			end)
		end)
	end)
	hook.Add("RenderScreenspaceEffects", "_Suppression", function()
		if is_sup then
			DrawToyTown( mult, ScrH()/2+100 )
		end
	end)
end

if SERVER then
	hook.Add("PlayerHurt", "_Suppress", function(ply, attacker)
		if IsValid(attacker) and attacker:IsPlayer() then
			umsg.Start( "SUPPRESS", ply )
			umsg.End()
		end
	end)
end