To install the hud simply take the cl_hud located in the sharp folder and overwrite your default one in your servers 
gamemodes/terrortown/gamemode directory. To install the extras you would place the folder named ttt_extras in your addons folder.
if you dont want to use one of the extras, you can delete it from within the addon. To install the sharp voice if you want to, place
the folder named sharp_voice in your addons folder.