INSTALLATION
------------
Copy and paste the "BombStation" folder in to the "addons" directory.

SUPPORT
------------
This addon was made by me, spykr, and will be supported and updated as long as it remains on CoderHire.
You can contact me on:
Steam (www.steamcommunity.com/id/spykr)
CoderHire (www.coderhire.com/profile/view/598)
