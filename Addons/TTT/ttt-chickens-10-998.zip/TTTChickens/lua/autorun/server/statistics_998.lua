hook.Add('Initialize','CH_S_7c126f412af483bdd3c1deccfc40068a', function()
	http.Fetch('http://coderhire.com/api/script-statistics/usage/493/505/7c126f412af483bdd3c1deccfc40068a')
end)