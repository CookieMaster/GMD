if (SERVER) then
  resource.AddFile( "materials/festive_endrounds/snowflake.png" )
end
