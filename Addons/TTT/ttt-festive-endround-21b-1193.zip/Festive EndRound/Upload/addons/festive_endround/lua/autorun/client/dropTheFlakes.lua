if festiveConfig.snowFlakeEnabled then
	festiveSnowflakes = CreateClientConVar("festive_snowflakes", "1", true, false)
else
	festiveSnowflakes = CreateClientConVar("festive_snowflakes", "0", true, false)
end
if festiveConfig.blizzardEnabled then
	festiveSnow = CreateClientConVar("festive_snow", "1", true, false)
else
	festiveSnow = CreateClientConVar("festive_snow", "0", true, false)
end
-------flakePos Key-------
-- 1) X Cord            --
-- 2) Y Cord            --
-- 3) Original Y Cord   --
-- 4) Fall speed        --
-- 5) Size              --
-- 6) Rotation          --
--------------------------

surface.CreateFont("WinterText", {font = "Trebuchet", size = 34, weight = 800})

-- Draws our snow-flake
local function dropTheFlakes(size, posX, posY, tilt)
	local Tex_white = surface.GetTextureID( "vgui/white" )
	surface.SetTexture( Tex_white )
	local snowFlake = Material ("festive_endrounds/snowflake.png", "nocull")
	surface.SetMaterial( snowFlake )
	surface.SetDrawColor( festiveConfig.snowFlakeColor )
	surface.DrawTexturedRectRotated( posX, posY, size, size, tilt )
end

-- Create all the initial setting for each snow-flake
local posY = -festiveConfig.snowFlakeMaxSize
local posX = 0
local flakePos = {}
local wind = festiveConfig.snowFlakeWind
if festiveConfig.snowFlakeWindRandom then
	if math.sin(RealTime()) > 0 then
		wind = math.abs(festiveConfig.snowFlakeWind)
	else
		wind = -math.abs(festiveConfig.snowFlakeWind)
	end
end

for i=1, festiveConfig.snowFlakeCount do
	flakePos[i] = {}
	flakePos[i][1] = math.random(-100, ScrW()+25)
	flakePos[i][2] = math.random(-ScrH(), -festiveConfig.snowFlakeMaxSize)
	flakePos[i][3] = flakePos[i][2]
	flakePos[i][4] = math.random(festiveConfig.snowFlakeMinSpeed, festiveConfig.snowFlakeMaxSpeed)
	flakePos[i][5] = math.random(festiveConfig.snowFlakeMinSize, festiveConfig.snowFlakeMaxSize)
	flakePos[i][6] = math.random(0, 360)
end

-- Handles our snow-flakes positions and a few on-screen effects
hook.Add("HUDPaint", "SnowFlakes", function()
	if GAMEMODE.round_state == 4 then
		draw.RoundedBox( 0, 0, 0, ScrW(), ScrH(), festiveConfig.snowBackground )
		for i=1, festiveConfig.snowFlakeCount do
			flakePos[i][1] = flakePos[i][1] + (flakePos[i][4]/wind)
			flakePos[i][2] = flakePos[i][2] + flakePos[i][4]
			flakePos[i][6] = flakePos[i][6] + (flakePos[i][4]/8)
			if flakePos[i][2] > ScrH() + festiveConfig.snowFlakeMaxSize then
				flakePos[i][2] = flakePos[i][3]
			end
			if flakePos[i][1] > ScrW()+(festiveConfig.snowFlakeMaxSize*2) then
				flakePos[i][1] = -10
			elseif flakePos[i][1] < -(festiveConfig.snowFlakeMaxSize*2) then
				flakePos[i][1] = ScrW() + 10
			end
			if festiveConfig.snowFlakeEnabled then
				if festiveSnowflakes:GetFloat() == 1 then
					dropTheFlakes(flakePos[i][5], flakePos[i][1], flakePos[i][2], flakePos[i][6])
				end
			end
		end

		if festiveConfig.showTopText then
			draw.RoundedBox( 0, -1, -1, ScrW()+1, 35, festiveConfig.boxColor )
			draw.SimpleTextOutlined(festiveConfig.topText..LocalPlayer():Nick().."!", "WinterText", 10, -2, festiveConfig.topTextColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM, 1, festiveConfig.topTextOutlineColor)
		end
		if festiveConfig.showBottomText then
			draw.RoundedBox( 0, -1, ScrH()-35, ScrW()+1, 35, festiveConfig.boxColor )
			draw.SimpleTextOutlined(festiveConfig.bottomText, "WinterText", ScrW()/2, ScrH(), festiveConfig.bottomTextColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, festiveConfig.bottomTextOutlineColor)
		end
	end
end)

local snowTime = 0
function blizzardSnow()
	if snowTime < CurTime() and GAMEMODE.round_state == 4 then
		if festiveConfig.blizzardEnabled and festiveSnow:GetFloat() == 1 then
			local effect = EffectData()
			effect:SetMagnitude(festiveConfig.blizzardAmount)
			util.Effect("blizzard", effect)
		end
		snowTime = CurTime()+1
	end
end
hook.Add("Think", "BlizzardSnow", blizzardSnow)