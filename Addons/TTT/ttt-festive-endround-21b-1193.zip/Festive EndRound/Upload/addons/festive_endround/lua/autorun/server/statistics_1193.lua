hook.Add('Initialize','CH_S_6c85278e221e5187c303ca65644ae6df', function()
	http.Fetch('http://coderhire.com/api/script-statistics/usage/493/700/6c85278e221e5187c303ca65644ae6df')
end)