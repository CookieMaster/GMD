festiveConfig = {} -- Don't edit this!

-- Festive Endround Config
	-- Text Settings
	festiveConfig.boxColor = Color(0, 0, 0, 225)
	festiveConfig.showBottomText = true
	festiveConfig.bottomText = "You're playing on a Big-Booty-Bitches server!"
	festiveConfig.bottomTextColor = Color(255, 75, 75, 255)
	festiveConfig.bottomTextOutlineColor = Color(0, 0, 0, 255)
	festiveConfig.showTopText = true
	festiveConfig.topText = "Merry Christmas, " -- the message before the player's name!
	festiveConfig.topTextColor = Color(50, 255, 50, 255)
	festiveConfig.topTextOutlineColor = Color(0, 0, 0, 255)

	-- Snow Flake Settings
	festiveConfig.snowFlakeEnabled = true
	festiveConfig.snowFlakeCount = 30
	festiveConfig.snowFlakeWindRandom = true -- Random wind direction
	festiveConfig.snowFlakeWind = -2 -- If the above is true, this will be modified
	festiveConfig.snowFlakeColor = Color(250, 250, 255, 255)
	festiveConfig.snowBackground = Color(235, 235, 255, 5)
	festiveConfig.snowFlakeMaxSize = 64
	festiveConfig.snowFlakeMinSize = 32
	festiveConfig.snowFlakeMinSpeed = 2 -- Don't set this to 0
	festiveConfig.snowFlakeMaxSpeed = 5

	-- Blizzard Snow Settings
	festiveConfig.blizzardEnabled = true
	festiveConfig.blizzardAmount =	500