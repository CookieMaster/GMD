=== DESCRIPTION ===
This is a scoreboard made for the gamemode Trouble in Terrorist Town.

=== INSTALLATION ===
Exact the '.zip' file into your 'addons' folder.

=== CUSTOMIZATION ===
Check out the documentation file.