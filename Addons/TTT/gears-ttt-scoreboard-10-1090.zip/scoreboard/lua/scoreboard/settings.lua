---------------------IMPORTANT---------------------
-----READ THE README.TXT FILE FOR INSTRUCTIONS-----

---------------------------------------------------
--------------------MAIN COLORS--------------------
---------------------------------------------------
Scoreboard.cPrimary 	= Color( 32, 95, 132, 150 )
Scoreboard.cSecondary 	= Color( 40, 40, 40, 250 )
Scoreboard.cTertiary 	= Color( 40, 40, 40, 250 )

Scoreboard.cText 	= Color( 236, 236, 236 )
Scoreboard.cDivider = Color( 65, 65, 65 )

Scoreboard.cTerrorists 	= Color( 7, 171, 7 )
Scoreboard.cFound 		= Color( 126, 14, 4 )
Scoreboard.cMissing 	= Color( 155, 155, 54 )
Scoreboard.cSpectators 	= Color( 96, 96, 96 )

Scoreboard.cInnocent 	= Color( 55, 55, 55 )
Scoreboard.cTraitor 	= Color( 155, 55, 55 )
Scoreboard.cDetective 	= Color( 55, 85, 155 )

Scoreboard.cTagFriend 		= Color( 0, 255, 0 )
Scoreboard.cTagSuspicious 	= Color( 255, 255, 0 )
Scoreboard.cTagAvoid 		= Color( 255, 150, 0 )
Scoreboard.cTagKill 		= Color( 255, 0, 0 )
Scoreboard.cTagMissing 		= Color( 130, 190, 130 )

---------------------------------------------------
--------------------PARAMETERS---------------------
---------------------------------------------------
Scoreboard.AutoDetect = true
Scoreboard.MapTimer = true

Scoreboard.Width = 1024
Scoreboard.ColumnSpacing = 96
Scoreboard.PlayerHeight = 28

Scoreboard.BannerText = "Gears Gaming"

Scoreboard.PingColors = true
	Scoreboard.PingLo = 50
	Scoreboard.PingHi = 400
	Scoreboard.PingLoColor = Color( 0, 255, 0 )
	Scoreboard.PingHiColor = Color( 255, 0, 0 )
	Scoreboard.PingGetColor = nil

Scoreboard.DeathColors = false
	Scoreboard.DeathLo = 0
	Scoreboard.DeathHi = 10
	Scoreboard.DeathLoColor = Color( 0, 255, 0 )
	Scoreboard.DeathHiColor = Color( 255, 0, 0 )
	Scoreboard.DeathGetColor = nil

Scoreboard.ScoreColors = false
	Scoreboard.ScoreLo = 0
	Scoreboard.ScoreHi = 100
	Scoreboard.ScoreLoColor = Color( 255, 0, 0 )
	Scoreboard.ScoreHiColor = Color( 0, 255, 0 )
	Scoreboard.ScoreGetColor = nil

Scoreboard.KarmaColors = false
	Scoreboard.KarmaLo = 500
	Scoreboard.KarmaHi = 1000
	Scoreboard.KarmaLoColor = Color( 255, 0, 0 )
	Scoreboard.KarmaHiColor = Color( 0, 255, 0 )
	Scoreboard.KarmaGetColor = nil

Scoreboard.Ranks = false
	Scoreboard.RankGetName = nil
	Scoreboard.RankGetColor = nil
	Scoreboard.RankAliases = nil
	Scoreboard.RankColors = nil

Scoreboard.NameColors = false
	Scoreboard.NameGetColor = nil
	Scoreboard.UseRankColor = false

Scoreboard.AdminMenu = true
	Scoreboard.AdminMenuBuild = nil
	Scoreboard.AdminMenuRanks = nil

---------------------------------------------------
-----------------------FONTS-----------------------
---------------------------------------------------
surface.CreateFont( "Scoreboard_Title", {
	font = "default",
	size = 80,
	weight = 500,
} )

surface.CreateFont( "Scoreboard_Header", {
	font = "default",
	size = 20,
	weight = 500,
} )

surface.CreateFont( "Scoreboard_Player", {
	font = "default",
	size = 18,
	weight = 500,
} )

surface.CreateFont( "Scoreboard_PlayerTag", {
	font = "default",
	size = 14,
	weight = 500,
} )