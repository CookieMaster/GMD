
-- ULX - http://ulyssesmod.net/
if ulx then
	Scoreboard.RankGetName = Scoreboard.RankGetName or function( ply )
		return ply:GetNWString( "usergroup" )
	end

	Scoreboard.AdminMenuBuild = Scoreboard.AdminMenuBuild or function( pnl, ply )
		pnl:AddSpacer()

		local menu, proxy = pnl:AddSubMenu( "Admin" )
		proxy:SetImage( "icon16/application.png" )

		local name = ply:Nick()

		local gag, proxy = menu:AddSubMenu( "Gag" )
		proxy:SetImage( "icon16/asterisk_yellow.png" )

			gag:AddOption( "Enable", function()
				RunConsoleCommand( "ulx", "gag", name )
			end ):SetImage( "icon16/accept.png" )

			gag:AddOption( "Disable", function()
				RunConsoleCommand( "ulx", "ungag", name )
			end ):SetImage( "icon16/cross.png" )

		local gag, proxy = menu:AddSubMenu( "Mute" )
		proxy:SetImage( "icon16/asterisk_orange.png" )

			gag:AddOption( "Enable", function()
				RunConsoleCommand( "ulx", "mute", name )
			end ):SetImage( "icon16/accept.png" )

			gag:AddOption( "Disable", function()
				RunConsoleCommand( "ulx", "unmute", name )
			end ):SetImage( "icon16/cross.png" )

		menu:AddSpacer()

		menu:AddOption( "Slay", function()
			RunConsoleCommand( "ulx", "slay", name )
		end ):SetImage( "icon16/gun.png" )

		menu:AddOption( "Slap", function()
			Derma_StringRequest( "Slap", "Enter damage", "", function( damage )
				RunConsoleCommand( "ulx", "slap", name, damage )
			end )
		end ):SetImage( "icon16/cut_red.png" )

		menu:AddSpacer()

		local teleport, proxy = menu:AddSubMenu( "Teleport" )
		proxy:SetImage( "icon16/magnifier.png" )

			teleport:AddOption( "Goto", function()
				RunConsoleCommand( "ulx", "goto", name )
			end ):SetImage( "icon16/arrow_right.png" )

			teleport:AddOption( "Bring", function()
				RunConsoleCommand( "ulx", "bring", name )
			end ):SetImage( "icon16/arrow_left.png" )

			teleport:AddOption( "Teleport", function()
				RunConsoleCommand( "ulx", "teleport", name )
			end ):SetImage( "icon16/arrow_down.png" )

			local send, proxy = teleport:AddSubMenu( "Send" )
			proxy:SetImage( "icon16/arrow_merge.png" )

				for _, ply in pairs( player.GetAll() ) do
					send:AddOption( ply:GetName(), function()
						RunConsoleCommand( "ulx", "send", name, ply:Nick() )
					end ):SetImage( "icon16/user.png" )
				end

		menu:AddSpacer()

		menu:AddOption( "Kick", function()
			Derma_StringRequest( "Kick", "Enter reason", "", function( reason )
				RunConsoleCommand( "ulx", "kick", name, reason )
			end )
		end ):SetImage( "icon16/door_out.png" )

		menu:AddOption( "Ban", function()
			Derma_StringRequest( "Ban", "Enter reason", "", function( reason )
				Derma_StringRequest( "Ban", "Enter time", "", function( time )
					RunConsoleCommand( "ulx", "ban", name, time, reason )
				end )
			end )
		end ):SetImage( "icon16/delete.png" )
	end
end

-- Exsto - http://facepunch.com/threads/937056/
if exsto then
	Scoreboard.RankGetName = Scoreboard.RankGetName or function( ply )
		return ply:GetRank()
	end

	Scoreboard.AdminMenuBuild = Scoreboard.AdminMenuBuild or function( pnl, ply )
		pnl:AddSpacer()

		local menu, proxy = pnl:AddSubMenu( "Admin" )
		proxy:SetImage( "icon16/application.png" )

		local name = ply:Nick()

		local gag, proxy = menu:AddSubMenu( "Gag" )
		proxy:SetImage( "icon16/asterisk_yellow.png" )

			gag:AddOption( "Enable", function()
				RunConsoleCommand( "ex", "gag", name )
			end ):SetImage( "icon16/accept.png" )

			gag:AddOption( "Disable", function()
				RunConsoleCommand( "ex", "ungag", name )
			end ):SetImage( "icon16/cross.png" )

		local gag, proxy = menu:AddSubMenu( "Mute" )
		proxy:SetImage( "icon16/asterisk_orange.png" )

			gag:AddOption( "Enable", function()
				RunConsoleCommand( "ex", "mute", name )
			end ):SetImage( "icon16/accept.png" )

			gag:AddOption( "Disable", function()
				RunConsoleCommand( "ex", "unmute", name )
			end ):SetImage( "icon16/cross.png" )

		menu:AddSpacer()

		menu:AddOption( "Slay", function()
			RunConsoleCommand( "ex", "slay", name )
		end ):SetImage( "icon16/gun.png" )

		menu:AddOption( "Slap", function()
			Derma_StringRequest( "Slap", "Enter damage", "", function( damage )
				RunConsoleCommand( "ex", "slap", name, damage )
			end )
		end ):SetImage( "icon16/cut_red.png" )

		menu:AddSpacer()

		local teleport, proxy = menu:AddSubMenu( "Teleport" )
		proxy:SetImage( "icon16/magnifier.png" )

			teleport:AddOption( "Goto", function()
				RunConsoleCommand( "ex", "goto", name )
			end ):SetImage( "icon16/arrow_right.png" )

			teleport:AddOption( "Bring", function()
				RunConsoleCommand( "ex", "bring", name )
			end ):SetImage( "icon16/arrow_left.png" )

			teleport:AddOption( "Teleport", function()
				RunConsoleCommand( "ex", "teleport", name )
			end ):SetImage( "icon16/arrow_down.png" )

			local send, proxy = teleport:AddSubMenu( "Send" )
			proxy:SetImage( "icon16/arrow_merge.png" )

				for _, ply in pairs( player.GetAll() ) do
					send:AddOption( ply:GetName(), function()
						RunConsoleCommand( "ex", "send", name, ply:Nick() )
					end ):SetImage( "icon16/user.png" )
				end

		menu:AddSpacer()

		menu:AddOption( "Kick", function()
			Derma_StringRequest( "Kick", "Enter reason", "", function( reason )
				RunConsoleCommand( "ex", "kick", name, reason )
			end )
		end ):SetImage( "icon16/door_out.png" )

		menu:AddOption( "Ban", function()
			Derma_StringRequest( "Ban", "Enter reason", "", function( reason )
				Derma_StringRequest( "Ban", "Enter time", "", function( time )
					RunConsoleCommand( "ex", "ban", name, time, reason )
				end )
			end )
		end ):SetImage( "icon16/delete.png" )
	end
end
