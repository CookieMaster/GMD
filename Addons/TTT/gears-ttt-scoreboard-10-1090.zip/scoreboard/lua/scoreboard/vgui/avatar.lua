local PANEL = {}

function PANEL:Init()
	self:DockPadding( 1, 1, 1, 1 )
	self:SetMouseInputEnabled( false )
	
	self.Avatar = vgui.Create( "AvatarImage", self )
	self.Avatar:Dock( FILL )
end

function PANEL:PerformLayout( w, h )
	self:SetWide( self:GetTall() )
end

function PANEL:Paint( w, h )
	surface.SetDrawColor( Scoreboard.cPrimary )
	surface.DrawRect( 0, 0, w, h )
end

function PANEL:SetPlayer( ply )
	self.Avatar:SetPlayer( ply )
end

vgui.Register( "Scoreboard_Avatar", PANEL, "DPanel" )