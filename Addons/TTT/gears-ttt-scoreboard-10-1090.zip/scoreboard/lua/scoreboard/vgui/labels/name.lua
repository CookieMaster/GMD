local PANEL = {}

local COLORS = Scoreboard.NameColors
local GETCOLOR = Scoreboard.NameGetColor
local USERANKCOLOR = Scoreboard.UseRankColor

function PANEL:Init()
	self:SetWide( 256 )
	self:SetFont( "Scoreboard_Player" )
	self:SetColor( Scoreboard.cText )
	self:SetTextInset( 8, 0 )
	self:SetContentAlignment( 4 )
end

function PANEL:Think()
	local ply = self.Player

	if not IsValid( ply ) then
		return
	end

	self:SetText( ply:Nick() )

	if not COLORS then
		return
	end

	if GETCOLOR then
		self:SetColor( GETCOLOR( ply ) )
	else
		self:SetColor( self:GetParent().Rank:GetTextColor() )
	end
end

vgui.Register( "Scoreboard_Name", PANEL, "Scoreboard_Utility" )