local PANEL = {}

local SPACING = Scoreboard.ColumnSpacing

local COLORS = Scoreboard.DeathColors
local LO = Scoreboard.DeathLo
local HI = Scoreboard.DeathHi
local LOCOLOR = Scoreboard.DeathLoColor
local HICOLOR = Scoreboard.DeathHiColor
local GETCOLOR = Scoreboard.DeathGetColor

function PANEL:Init()
	self:SetWide( SPACING )
	self:SetFont( "Scoreboard_Player" )
	self:SetColor( Scoreboard.cText )
	self:SetContentAlignment( 5 )
end

function PANEL:Think()
	local ply = self.Player

	if not IsValid( ply ) then
		return
	end

	self:SetText( ply:Deaths() )

	if COLORS then
		if GETCOLOR then
			self:SetColor( GETCOLOR( ply ) )
			return
		end

		local frac = ( ply:Deaths() - LO ) / ( HI - LO )
		self:LerpColor( frac, LOCOLOR, HICOLOR )
	end
end

vgui.Register( "Scoreboard_Deaths", PANEL, "Scoreboard_Utility" )