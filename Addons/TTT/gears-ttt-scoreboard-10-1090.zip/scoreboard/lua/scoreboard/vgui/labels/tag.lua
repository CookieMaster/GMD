local PANEL = {}

function PANEL:Init()
	self:SetWide( 128 )
	self:SetFont( "Scoreboard_PlayerTag" )
	self:SetContentAlignment( 5 )
end

function PANEL:Think()
	local ply = self.Player

	if not IsValid( ply ) then
		return
	end

	local tag = ply.sb_tag

	if not tag then
		self:SetVisible( false )
		return
	end

	self:SetColor( tag.color )
	self:SetText( LANG.GetTranslation( tag.txt ) )
end

vgui.Register( "Scoreboard_Tag", PANEL, "Scoreboard_Utility" )