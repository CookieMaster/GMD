local PANEL = {}

local SPACING = Scoreboard.ColumnSpacing

local COLORS = Scoreboard.ScoreColors
local LO = Scoreboard.ScoreLo
local HI = Scoreboard.ScoreHi
local LOCOLOR = Scoreboard.ScoreLoColor
local HICOLOR = Scoreboard.ScoreHiColor
local GETCOLOR = Scoreboard.ScoreGetColor

function PANEL:Init()
	self:SetWide( SPACING )
	self:SetFont( "Scoreboard_Player" )
	self:SetColor( Scoreboard.cText )
	self:SetContentAlignment( 5 )
end

function PANEL:Think()
	local ply = self.Player

	if not IsValid( ply ) then
		return
	end

	self:SetText( ply:Frags() )

	if COLORS then
		if GETCOLOR then
			self:SetColor( GETCOLOR( ply ) )
			return
		end

		local frac = ( ply:Frags() - LO ) / ( HI - LO )
		self:LerpColor( frac, LOCOLOR, HICOLOR )
	end
end

vgui.Register( "Scoreboard_Score", PANEL, "Scoreboard_Utility" )