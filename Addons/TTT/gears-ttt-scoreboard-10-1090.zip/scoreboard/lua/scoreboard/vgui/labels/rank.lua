local PANEL = {}

local SPACING = Scoreboard.ColumnSpacing

local GETNAME = Scoreboard.RankGetName
local GETCOLOR = Scoreboard.RankGetColor
local ALIASES = Scoreboard.RankAliases
local COLORS = Scoreboard.RankColors

local function getAlias( rank )
	local alias

	if ALIASES then
		alias = ALIASES[ rank ]
	end

	return alias or rank
end

function PANEL:Init()
	self:SetWide( SPACING )
	self:SetFont( "Scoreboard_Player" )
	self:SetContentAlignment( 5 )
end

function PANEL:Think()
	local ply = self.Player

	if not IsValid( ply ) then
		return
	end

	local rank = GETNAME( ply )
	self:SetText( getAlias( rank ) )

	if COLORS then
		local colors = COLORS[ rank ]

		if colors then
			local time = math.floor( CurTime() )
			local frac = CurTime() % 1
			local a = colors[ time % #colors + 1 ]
			local b = colors[ ( time - 1 ) % #colors + 1 ]

			self:LerpColor( frac, a, b )
			return
		end
	end

	if GETCOLOR then
		local color = GETCOLOR( ply, rank )

		if color then
			self:SetColor( color )
			return
		end
	end

	self:SetColor( Scoreboard.cText )
end

vgui.Register( "Scoreboard_Rank", PANEL, "Scoreboard_Utility" )