local PANEL = {}

local SPACING = Scoreboard.ColumnSpacing

local COLORS = Scoreboard.PingColors
local LO = Scoreboard.PingLo
local HI = Scoreboard.PingHi
local LOCOLOR = Scoreboard.PingLoColor
local HICOLOR = Scoreboard.PingHiColor
local GETCOLOR = Scoreboard.PingGetColor

function PANEL:Init()
	self:SetWide( SPACING )
	self:SetFont( "Scoreboard_Player" )
	self:SetColor( Scoreboard.cText )
	self:SetContentAlignment( 5 )
end

function PANEL:Think()
	local ply = self.Player

	if not IsValid( ply ) then
		return
	end

	self:SetText( ply:Ping() )

	if COLORS then
		if GETCOLOR then
			self:SetColor( GETCOLOR( ply ) )
			return
		end

		local frac = ( ply:Ping() - LO ) / ( HI - LO )
		self:LerpColor( frac, LOCOLOR, HICOLOR )
	end
end

vgui.Register( "Scoreboard_Ping", PANEL, "Scoreboard_Utility" )