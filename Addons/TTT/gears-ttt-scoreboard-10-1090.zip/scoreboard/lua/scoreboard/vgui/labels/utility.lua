local PANEL = {}

function PANEL:Init()
	
end

function PANEL:Paint( w, h )

end

function PANEL:SetPlayer( ply )
	self.Player = ply
end

function PANEL:LerpColor( t, a, b )
	local h1, s1, v1 = ColorToHSV( a )
	local h2, s2, v2 = ColorToHSV( b )

	local h = Lerp( t, h1, h2 )
	local s = Lerp( t, s1, s2 )
	local v = Lerp( t, v1, v2 )

	self:SetColor( HSVToColor( h, s, v ) )
end

vgui.Register( "Scoreboard_Utility", PANEL, "DLabel" )