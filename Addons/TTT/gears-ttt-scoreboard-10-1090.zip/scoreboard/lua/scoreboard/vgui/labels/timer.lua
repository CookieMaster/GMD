local PANEL = {}

local function timeLeft()
	local rounds = math.max( 0, GetGlobalInt( "ttt_rounds_left", 6 ) )
	local time = math.floor( math.max( 0, ( ( GetGlobalInt( "ttt_time_limit_minutes" ) or 60 ) * 60 ) - CurTime() ) )

	local h = math.floor( time / 3600 )
	time = time - math.floor( h * 3600 )
	local m = math.floor( time / 60 )
	time = time - math.floor( m * 60 )
	local s = math.floor( time )

	return rounds, string.format( "%02i:%02i:%02i", h, m, s )
end

function PANEL:Init()
	self.LastThink = 0

	self:SetFont( "Scoreboard_Header" )
	self:SetColor( Scoreboard.cText )
	self:SetContentAlignment( 7 )
end

function PANEL:Paint( w, h )

end

function PANEL:Think()
	if CurTime() < self.LastThink + 1 then
		return
	end

	local r, t = timeLeft()
	local text = LANG.GetPTranslation( "sb_mapchange", { num = r, time = t } )

	self:SetText( text )
	self:SizeToContentsX()
	self.LastThink = CurTime()
end

vgui.Register( "Scoreboard_Timer", PANEL, "DLabel" )