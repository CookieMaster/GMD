local PANEL = {}

local PADDING = 128

function PANEL:Init()
	self:DockPadding( 2, 2, 2, 2 )
	self:SetWide( Scoreboard.Width )
	self:CenterHorizontal()

	self.Banner = vgui.Create( "Scoreboard_Banner", self )
	self.Banner:Dock( TOP )

	self.Header = vgui.Create( "Scoreboard_Header", self )
	self.Header:Dock( TOP )

	self.Canvas = vgui.Create( "Scoreboard_Canvas", self )
	self.Canvas:Dock( FILL )
end

function PANEL:Paint( w, h )
	surface.SetDrawColor( Scoreboard.cPrimary )
	surface.DrawRect( 0, 0, w, h )
end

function PANEL:PerformLayout( w, h )
	w, h = self.Canvas:ChildrenSize()
	h = h + self.Banner:GetTall() + self.Header:GetTall() + 2

	if h > ScrH() - 256 then
		local x, y = self:GetPos()
		y = 128 - ( h - ScrH() + 256 )

		if y < 64 then
			self.y = 64
			self:SetTall( math.min( h, ScrH() - 128 ) )
			self.Canvas:SetEnableScroll( true )
		else
			self.y = y
			self:SetTall( h )
			self.Canvas:SetEnableScroll( false )
		end

		return
	end

	self.y = 128
	self:SetTall( h )
	self.Canvas:SetEnableScroll( false )
end

vgui.Register( "Scoreboard", PANEL, "DPanel" )