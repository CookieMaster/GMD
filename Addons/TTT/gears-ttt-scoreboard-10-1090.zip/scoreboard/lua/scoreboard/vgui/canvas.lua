local PANEL = {}

function PANEL:Init()
	self:DockPadding( 2, 2, 2, 2 )
	self.Scroll = 0

	self.Terrorists = vgui.Create( "Scoreboard_Group", self )
	self.Terrorists:SetGroup( GROUP_TERROR )
	self.Terrorists:Dock( TOP )

	self.Found = vgui.Create( "Scoreboard_Group", self )
	self.Found:SetGroup( GROUP_FOUND )
	self.Found:Dock( TOP )

	self.Missing = vgui.Create( "Scoreboard_Group", self )
	self.Missing:SetGroup( GROUP_NOTFOUND )
	self.Missing:Dock( TOP )

	self.Spectators = vgui.Create( "Scoreboard_Group", self )
	self.Spectators:SetGroup( GROUP_SPEC )
	self.Spectators:Dock( TOP )
end

function PANEL:Paint( w, h )
	surface.SetDrawColor( Scoreboard.cSecondary )
	surface.DrawRect( 0, 0, w, h )
end

function PANEL:PerformLayout( w, h )
	self:InvalidateParent( true )
end

function PANEL:OnMouseWheeled( d )
	if not self.EnableScroll then
		return
	end

	local h = self.Terrorists:GetTall() + self.Found:GetTall() + self.Missing:GetTall() + self.Spectators:GetTall()
	local max = h - self:GetTall()

	self.Scroll = math.Clamp( self.Scroll - d * 16, 0, max )
	self:DockPadding( 2, 2 - self.Scroll, 2, 2 )
	self:InvalidateLayout( true )
end

function PANEL:SetEnableScroll( bool )
	if self.EnableScroll == bool then
		return
	end

	self.EnableScroll = bool

	if bool == false then
		self.Scroll = 0
		self:DockPadding( 2, 2, 2, 2 )
		self:InvalidateLayout( true )
	end
end

vgui.Register( "Scoreboard_Canvas", PANEL, "DPanel" )