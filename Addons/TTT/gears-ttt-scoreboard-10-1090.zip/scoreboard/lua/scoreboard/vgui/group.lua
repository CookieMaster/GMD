local PANEL = {}

local TEXT = {
	[ GROUP_TERROR ] = "terrorists",
	[ GROUP_FOUND ] = "sb_confirmed",
	[ GROUP_NOTFOUND ] = "sb_mia",
	[ GROUP_SPEC ] = "spectators",
}

local COLORS = {
	[ GROUP_TERROR ] = Scoreboard.cTerrorists,
	[ GROUP_FOUND ] = Scoreboard.cFound,
	[ GROUP_NOTFOUND ] = Scoreboard.cMissing,
	[ GROUP_SPEC ] = Scoreboard.cSpectators,
}

local function sort( a, b )
	return a:Frags() > b:Frags()
end

function PANEL:Init()
	self:DockPadding( 0, 0, 0, 2 )
	self.Players = {}

	self.Header = vgui.Create( "Scoreboard_GroupHeader", self )
	self.Header:Dock( TOP )
end

function PANEL:Paint( w, h )

end

function PANEL:Think()
	for _, ply in pairs( player.GetAll() ) do
		local pnl = self.Players[ ply ]

		if ScoreGroup( ply ) == self.Group then
			if IsValid( pnl ) then
				continue
			end

			self:AddPlayer( ply )
			continue
		end

		if IsValid( pnl ) then
			self:RemovePlayer( ply )
		end
	end

	self.Header:SetText( self.HeaderText .. " (" .. table.Count( self.Players ) .. ")" )
end

function PANEL:PerformLayout( w, h )

	local empty = true
	for ply, pnl in pairs( self.Players ) do
		if IsValid( pnl ) and IsValid( ply ) then
			empty = false
			break
		end
	end

	if empty then
		self:SetTall( 0 )
	else
		self:SizeToChildren( false, true )
	end
end

function PANEL:AddPlayer( ply )
	local pnl = vgui.Create( "Scoreboard_Player", self )
	pnl:SetPlayer( ply )
	pnl:Dock( TOP )

	self.Players[ ply ] = pnl
end

function PANEL:RemovePlayer( ply )
	self.Players[ ply ]:Remove()
	self.Players[ ply ] = nil
end

function PANEL:OnChildRemoved( pnl )
	self.Players[ pnl.Player ] = nil
	self:InvalidateLayout( true )
end

function PANEL:SetGroup( group )
	self.Group = group
	self.HeaderText = LANG.GetTranslation( TEXT[ group ] )
	self.Header:SetColor( COLORS[ group ] )
end

vgui.Register( "Scoreboard_Group", PANEL, "DPanel" )