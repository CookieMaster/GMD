local PANEL = {}

function PANEL:Init()
	self:SetTall( 88 )

	self.Title = vgui.Create( "DLabel", self )
	self.Title:SetText( Scoreboard.BannerText )
	self.Title:SetFont( "Scoreboard_Title" )
	self.Title:SetColor( Scoreboard.cText )
	self.Title:SetContentAlignment( 8 )
	self.Title:Dock( FILL )
end

function PANEL:Paint( w, h )
	surface.SetDrawColor( Scoreboard.cSecondary )
	surface.DrawRect( 0, 0, w, h )
end

vgui.Register( "Scoreboard_Banner", PANEL, "DPanel" )