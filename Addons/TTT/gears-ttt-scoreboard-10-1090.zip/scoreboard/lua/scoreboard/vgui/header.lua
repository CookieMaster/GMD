local PANEL = {}

local SPACING = Scoreboard.ColumnSpacing

function PANEL:Init()
	self:DockPadding( 2, 0, 2, 0 )
	self:SetTall( 22 )

	if Scoreboard.MapTimer then
		self.Timer = vgui.Create( "Scoreboard_Timer", self )
		self.Timer:Dock( LEFT )
	end

	self.Ping = vgui.Create( "DLabel", self )
	self.Ping:SetText( LANG.GetTranslation( "sb_ping" ) )
	self.Ping:SetFont( "Scoreboard_Header" )
	self.Ping:SetColor( Scoreboard.cText )
	self.Ping:SetWide( SPACING )
	self.Ping:SetContentAlignment( 8 )
	self.Ping:Dock( RIGHT )

	self.Deaths = vgui.Create( "DLabel", self )
	self.Deaths:SetText( LANG.GetTranslation( "sb_deaths" ) )
	self.Deaths:SetFont( "Scoreboard_Header" )
	self.Deaths:SetColor( Scoreboard.cText )
	self.Deaths:SetWide( SPACING )
	self.Deaths:SetContentAlignment( 8 )
	self.Deaths:Dock( RIGHT )

	self.Score = vgui.Create( "DLabel", self )
	self.Score:SetText( LANG.GetTranslation( "sb_score" ) )
	self.Score:SetFont( "Scoreboard_Header" )
	self.Score:SetColor( Scoreboard.cText )
	self.Score:SetWide( SPACING )
	self.Score:SetContentAlignment( 8 )
	self.Score:Dock( RIGHT )

	if KARMA.IsEnabled() then
		self.Karma = vgui.Create( "DLabel", self )
		self.Karma:SetText( LANG.GetTranslation( "sb_karma" ) )
		self.Karma:SetFont( "Scoreboard_Header" )
		self.Karma:SetColor( Scoreboard.cText )
		self.Karma:SetWide( SPACING )
		self.Karma:SetContentAlignment( 8 )
		self.Karma:Dock( RIGHT )
	end

	if Scoreboard.Ranks then
		self.Rank = vgui.Create( "DLabel", self )
		self.Rank:SetText( LANG.GetTranslation( "sb_rank" ) )
		self.Rank:SetFont( "Scoreboard_Header" )
		self.Rank:SetColor( Scoreboard.cText )
		self.Rank:SetWide( SPACING )
		self.Rank:SetContentAlignment( 8 )
		self.Rank:Dock( RIGHT )
	end
end

function PANEL:Paint( w, h )

end

vgui.Register( "Scoreboard_Header", PANEL, "DPanel" )