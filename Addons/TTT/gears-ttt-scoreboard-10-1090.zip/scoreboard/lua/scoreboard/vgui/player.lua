local PANEL = {}

local HEIGHT = Scoreboard.PlayerHeight

local COLORS = {
	[ ROLE_TRAITOR ] = Scoreboard.cTraitor,
	[ ROLE_DETECTIVE ] = Scoreboard.cDetective,
	[ ROLE_INNOCENT ] = Scoreboard.cInnocent,
}

local TAGS = {
	[ "FRIEND" ] = { txt = "sb_tag_friend", color = Scoreboard.cTagFriend },
	[ "SUSPICIOUS" ] = { txt = "sb_tag_susp", color = Scoreboard.cTagSuspicious },
	[ "AVOID" ] = { txt = "sb_tag_avoid", color = Scoreboard.cTagAvoid },
	[ "KILL" ] = { txt = "sb_tag_kill", color = Scoreboard.cTagKill },
	[ "MISSING" ] = { txt = "sb_tag_miss", color = Scoreboard.cTagMissing },
}

function PANEL:Init()
	self:SetTall( HEIGHT )
	self:DockPadding( 1, 1, 1, 1 )
	self:DockMargin( 16, 2, 0, 0 )
	self:SetCursor( "hand" )

	self.Expanded = false
	self.LastThink = 0

	self.Avatar = vgui.Create( "Scoreboard_Avatar", self )
	self.Avatar:Dock( LEFT )

	self.Name = vgui.Create( "Scoreboard_Name", self )
	self.Name:Dock( LEFT )

	self.Tag = vgui.Create( "Scoreboard_Tag", self )
	self.Tag:Dock( LEFT )
	self.Tag:SetVisible( false )

	self.Mute = vgui.Create( "Scoreboard_Mute", self )
	self.Mute:Dock( RIGHT )

	self.Ping = vgui.Create( "Scoreboard_Ping", self )
	self.Ping:Dock( RIGHT )

	local divider = vgui.Create( "Scoreboard_Divider", self )
	divider:Dock( RIGHT )

	self.Deaths = vgui.Create( "Scoreboard_Deaths", self )
	self.Deaths:Dock( RIGHT )

	local divider = vgui.Create( "Scoreboard_Divider", self )
	divider:Dock( RIGHT )

	self.Score = vgui.Create( "Scoreboard_Score", self )
	self.Score:Dock( RIGHT )

	if KARMA.IsEnabled() then
		local divider = vgui.Create( "Scoreboard_Divider", self )
		divider:Dock( RIGHT )

		self.Karma = vgui.Create( "Scoreboard_Karma", self )
		self.Karma:Dock( RIGHT )
	end

	if Scoreboard.Ranks then
		local divider = vgui.Create( "Scoreboard_Divider", self )
		divider:Dock( RIGHT )

		self.Rank = vgui.Create( "Scoreboard_Rank", self )
		self.Rank:Dock( RIGHT )
	end

	self.TagFriend = vgui.Create( "Scoreboard_TagButton", self )
	self.TagFriend:SetPos( HEIGHT * 2 + 64, HEIGHT * 2 - 22 )
	self.TagFriend:SetTag( TAGS[ "FRIEND" ] )
	self.TagFriend:SetVisible( false )

	self.TagSuspicious = vgui.Create( "Scoreboard_TagButton", self )
	self.TagSuspicious:SetPos( HEIGHT * 2 + 141, HEIGHT * 2 - 22 )
	self.TagSuspicious:SetTag( TAGS[ "SUSPICIOUS" ] )
	self.TagSuspicious:SetVisible( false )

	self.TagAvoid = vgui.Create( "Scoreboard_TagButton", self )
	self.TagAvoid:SetPos( HEIGHT * 2 + 216, HEIGHT * 2 - 22 )
	self.TagAvoid:SetTag( TAGS[ "AVOID" ] )
	self.TagAvoid:SetVisible( false )

	self.TagKill = vgui.Create( "Scoreboard_TagButton", self )
	self.TagKill:SetPos( HEIGHT * 2 + 277, HEIGHT * 2 - 22 )
	self.TagKill:SetTag( TAGS[ "KILL" ] )
	self.TagKill:SetVisible( false )

	self.TagMissing = vgui.Create( "Scoreboard_TagButton", self )
	self.TagMissing:SetPos( HEIGHT * 2 + 343, HEIGHT * 2 - 22 )
	self.TagMissing:SetTag( TAGS[ "MISSING" ] )
	self.TagMissing:SetVisible( false )
end

function PANEL:Paint( w, h )
	local ply = self.Player

	if not IsValid( ply ) then
		self:Remove()
		return
	end

	local color = COLORS[ ply:GetRole() or ROLE_INNOCENT ]

	surface.SetDrawColor( color )
	surface.DrawRect( 0, 0, w, h )
end

function PANEL:ShowTags( bool )
	self.TagFriend:SetVisible( bool )
	self.TagSuspicious:SetVisible( bool )
	self.TagAvoid:SetVisible( bool )
	self.TagKill:SetVisible( bool )
	self.TagMissing:SetVisible( bool )
end

function PANEL:Toggle()
	local group = ScoreGroup( self.Player )

	if self.Expanded then
		self:SizeTo( self:GetWide(), HEIGHT, 0.1, 0, 1, function()
			self.Expanded = false
			self:ShowTags( false )

			if self.Player.sb_tag then
				self.Tag:SetVisible( group == GROUP_TERROR )
			end
		end )

		surface.PlaySound( "ui/buttonclickrelease.wav" )
		return
	end

	if group == GROUP_SPEC then
		return
	end

	surface.PlaySound( "ui/buttonclick.wav" )
	self:SizeTo( self:GetWide(), HEIGHT * 2, 0.1, 0, 1 )
	self.Tag:SetVisible( false )
	self.Expanded = true

	if group == GROUP_TERROR then
		self:ShowTags( true )
		return
	end

	-- death info
	self:ShowTags( false )
end

function PANEL:DoClick()
	if LocalPlayer() == self.Player then
		return
	end

	self:Toggle()
end

function PANEL:DoRightClick()
	local menu = DermaMenu( self )

	menu:AddOption( "Copy SteamID", function()
		SetClipboardText( self.Player:SteamID() )
	end ):SetImage( "icon16/book_go.png" )

	menu:AddOption( "Copy Name", function()
		SetClipboardText( self.Player:Nick() )
	end ):SetImage( "icon16/user_go.png" )

	menu:AddSpacer()

	menu:AddOption( "View Profile", function()
		self.Player:ShowProfile()
	end ):SetImage( "icon16/information.png" )

	if not Scoreboard.AdminMenu then
		menu:Open()
		return
	end

	if Scoreboard.AdminMenuRanks then
		local rank = Scoreboard.RankGetName( self.Player )

		if Scoreboard.AdminMenuRanks[ rank ] then
			Scoreboard.AdminMenuBuild( menu, self.Player )
		end
	end

	menu:Open()
end

function PANEL:OnMousePressed( key )
	self:MouseCapture( true )
end

function PANEL:OnMouseReleased( key )
	self:MouseCapture( false )

	if self:IsHovered() then
		if key == MOUSE_LEFT then
			self:DoClick()
		elseif key == MOUSE_RIGHT then
			self:DoRightClick()
		end
	end
end

function PANEL:SetPlayer( ply )
	self.Player = ply

	self.Avatar:SetPlayer( ply )
	self.Name:SetPlayer( ply )
	self.Tag:SetPlayer( ply )

	self.Mute:SetPlayer( ply )
	self.Ping:SetPlayer( ply )
	self.Deaths:SetPlayer( ply )
	self.Score:SetPlayer( ply )

	if self.Karma then
		self.Karma:SetPlayer( ply )
	end

	if self.Rank then
		self.Rank:SetPlayer( ply )
	end

	self.TagFriend:SetPlayer( ply )
	self.TagSuspicious:SetPlayer( ply )
	self.TagAvoid:SetPlayer( ply )
	self.TagKill:SetPlayer( ply )
	self.TagMissing:SetPlayer( ply )
end

function PANEL:SetTag( tag )
	self:Toggle()

	if self.Player.sb_tag == tag then
		self.Player.sb_tag = nil
		self.Tag:SetVisible( false )
	else
		self.Player.sb_tag = tag
		self.Tag:SetVisible( true )
	end
end

vgui.Register( "Scoreboard_Player", PANEL, "DPanel" )