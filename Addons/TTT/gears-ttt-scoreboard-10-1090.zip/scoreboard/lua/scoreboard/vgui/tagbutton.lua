local PANEL = {}

function PANEL:Init()
	self:SetSize( 60, 18 )
	self:SetCursor( "arrow" )

	self.Label = vgui.Create( "DLabel", self )
	self.Label:SetFont( "Scoreboard_PlayerTag" )
	self.Label:Dock( FILL )
	self.Label:SetContentAlignment( 5 )
end

function PANEL:Paint( w, h )
	local ply = self.Player

	if not IsValid( ply ) then
		return
	end

	if self:IsHovered() or self.Tag == ply.sb_tag then
		surface.SetDrawColor( self.Tag.color )
		surface.DrawOutlinedRect( 0, 0, w, h )
	end
end

function PANEL:SetTag( tag )
	self.Tag = tag

	self.Label:SetColor( tag.color )
	self.Label:SetText( LANG.GetTranslation( tag.txt ) )
end

function PANEL:SetPlayer( ply )
	self.Player = ply
end

function PANEL:DoClick( key )
	self:GetParent():SetTag( self.Tag )
end

function PANEL:OnMousePressed( key )
	self:MouseCapture( true )
end

function PANEL:OnMouseReleased( key )
	self:MouseCapture( false )

	if self:IsHovered() then
		if key == MOUSE_LEFT then
			self:DoClick()
		end
	end
end

vgui.Register( "Scoreboard_TagButton", PANEL, "DPanel" )