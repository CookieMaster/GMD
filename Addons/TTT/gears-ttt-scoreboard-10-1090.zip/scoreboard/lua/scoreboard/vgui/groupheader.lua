local PANEL = {}

function PANEL:Init()
	self:SetTall( 22 )
	self:SetFont( "Scoreboard_Header" )
	self:SetColor( Scoreboard.cText )
	self:SetTextInset( 4, 0 )
	self:SetContentAlignment( 7 )
end

function PANEL:Paint( w, h )
	surface.SetDrawColor( self.Color )
	surface.DrawRect( 0, 0, 152, h )
end

function PANEL:SetColor( color )
	self.Color = color
end

vgui.Register( "Scoreboard_GroupHeader", PANEL, "DLabel" )