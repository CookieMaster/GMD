local PANEL = {}

function PANEL:Init()
	self:SetWide( 1 )
	self:DockMargin( 0, 1, 0, 1 )
	self:SetMouseInputEnabled( false )
end

function PANEL:Paint( w, h )
	surface.SetDrawColor( Scoreboard.cDivider )
	surface.DrawLine( 0, 0, 0, h )
end

vgui.Register( "Scoreboard_Divider", PANEL, "DPanel" )