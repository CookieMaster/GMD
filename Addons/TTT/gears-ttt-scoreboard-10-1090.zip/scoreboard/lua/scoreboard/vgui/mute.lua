local PANEL = {}

local COLORS = {
	[ true ] = Color( 255, 0, 0 ),
	[ false ] = Color( 0, 255, 0 ),
}

function PANEL:Init()
	self:SetWide( 0 )
	self:SetTooltip( "Mute/Unmute this player" )

	self.Expanded = false
end

function PANEL:Paint( w, h )
	local ply = self.Player

	if not IsValid( ply ) then
		return
	end

	if not self.Expanded and not ply:IsMuted() then
		return
	end

	local color = COLORS[ ply:IsMuted() ]

	surface.SetDrawColor( color )
	surface.DrawRect( 0, 0, w, h )
end

function PANEL:Think()
	if not IsValid( self.Player ) then
		return
	end
	
	if self:IsHovered() or self:GetParent():IsHovered() then
		self:Expand()
	else
		self:Contract()
	end
end

function PANEL:DoClick()
	self.Player:SetMuted( not self.Player:IsMuted() )

	if self.Player:IsMuted() then
		surface.PlaySound( "ui/buttonclick.wav" )
	else
		surface.PlaySound( "ui/buttonclickrelease.wav" )
	end
end

function PANEL:OnMousePressed( key )
	self:MouseCapture( true )
end

function PANEL:OnMouseReleased( key )
	self:MouseCapture( false )

	if self:IsHovered() then
		if key == MOUSE_LEFT then
			self:DoClick()
		end
	end
end

function PANEL:Expand()
	if self.Expanded then
		return
	end

	self.Expanded = true
	self:SizeTo( 24, self:GetTall(), 0.1, 0, 1 )
end

function PANEL:Contract()
	if not self.Expanded then
		return
	end

	if self.Animating then
		return
	end

	local w = self.Player:IsMuted() and 6 or 0
	self.Animating = true

	self:SizeTo( w, self:GetTall(), 0.1, 0, 1, function()
		self.Animating = false
		self.Expanded = false
	end )
end

function PANEL:SetPlayer( ply )
	if ply == LocalPlayer() then
		self:Remove()
		return
	end

	self.Player = ply

	if ply:IsMuted() then
		self:Contract()
	end
end

vgui.Register( "Scoreboard_Mute", PANEL, "DPanel" )