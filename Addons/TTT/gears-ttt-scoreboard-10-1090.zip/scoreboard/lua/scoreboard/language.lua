LANG.AddToLanguage( "English", "sb_rank", "Rank" )

-- This is only needed if you have a 'Rank' column and don't use the english language
-- If you want to add support for a language, you have to add a line like this:
-- LANG.AddToLanguage( "your language", "sb_rank", "The word 'Rank' translated to your language" )