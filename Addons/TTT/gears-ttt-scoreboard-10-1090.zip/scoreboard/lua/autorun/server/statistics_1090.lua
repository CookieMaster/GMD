hook.Add('Initialize','CH_S_045219ae71393005583e659ce4d52d48', function()
	http.Fetch('http://coderhire.com/api/script-statistics/usage/493/597/045219ae71393005583e659ce4d52d48')
end)