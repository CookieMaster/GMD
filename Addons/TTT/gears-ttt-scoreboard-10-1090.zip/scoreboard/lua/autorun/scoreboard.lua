if SERVER then
	AddCSLuaFile()
	AddCSLuaFile( "scoreboard/settings.lua" )
	AddCSLuaFile( "scoreboard/language.lua" )
	AddCSLuaFile( "scoreboard/autodetect.lua" )

	AddCSLuaFile( "scoreboard/vgui/labels/utility.lua" )
	AddCSLuaFile( "scoreboard/vgui/labels/timer.lua" )
	AddCSLuaFile( "scoreboard/vgui/labels/name.lua" )
	AddCSLuaFile( "scoreboard/vgui/labels/ping.lua" )
	AddCSLuaFile( "scoreboard/vgui/labels/deaths.lua" )
	AddCSLuaFile( "scoreboard/vgui/labels/score.lua" )
	AddCSLuaFile( "scoreboard/vgui/labels/karma.lua" )
	AddCSLuaFile( "scoreboard/vgui/labels/rank.lua" )
	AddCSLuaFile( "scoreboard/vgui/labels/tag.lua" )

	AddCSLuaFile( "scoreboard/vgui/scoreboard.lua" )
	AddCSLuaFile( "scoreboard/vgui/banner.lua" )
	AddCSLuaFile( "scoreboard/vgui/header.lua" )
	AddCSLuaFile( "scoreboard/vgui/canvas.lua" )
	AddCSLuaFile( "scoreboard/vgui/group.lua" )
	AddCSLuaFile( "scoreboard/vgui/groupheader.lua" )
	AddCSLuaFile( "scoreboard/vgui/player.lua" )
	AddCSLuaFile( "scoreboard/vgui/avatar.lua" )
	AddCSLuaFile( "scoreboard/vgui/divider.lua" )
	AddCSLuaFile( "scoreboard/vgui/mute.lua" )
	AddCSLuaFile( "scoreboard/vgui/tagbutton.lua" )

	return
end

local panel

local function makeScoreboard()
	Scoreboard = {}

	local halt = false
	local function error( str )
		ErrorNoHalt( "[GEARS SCOREBOARD] " .. str .. "\n" )
		halt = true
	end

	include( "scoreboard/settings.lua" )
	include( "scoreboard/language.lua" )

	if Scoreboard.AutoDetect then
		include( "scoreboard/autodetect.lua" )
	end

	if Scoreboard.PingColors then
		if Scoreboard.PingGetColor == nil then
			if Scoreboard.PingLo == nil then
				error( "'PingColors' is enabled, but you did not specify 'PingLo'" )
			end

			if Scoreboard.PingHi == nil then
				error( "'PingColors' is enabled, but you did not specify 'PingHi'" )
			end

			if Scoreboard.PingLoColor == nil then
				error( "'PingColors' is enabled, but you did not specify 'PingLoColor'" )
			end

			if Scoreboard.PingHiColor == nil then
				error( "'PingColors' is enabled, but you did not specify 'PingHiColor'" )
			end
		end
	end

	if Scoreboard.DeathColors then
		if Scoreboard.DeathGetColor == nil then
			if Scoreboard.DeathLo == nil then
				error( "'DeathColors' is enabled, but you did not specify 'DeathLo'" )
			end

			if Scoreboard.DeathHi == nil then
				error( "'DeathColors' is enabled, but you did not specify 'DeathHi'" )
			end

			if Scoreboard.DeathLoColor == nil then
				error( "'DeathColors' is enabled, but you did not specify 'DeathLoColor'" )
			end

			if Scoreboard.DeathHiColor == nil then
				error( "'DeathColors' is enabled, but you did not specify 'DeathHiColor'" )
			end
		end
	end

	if Scoreboard.ScoreColors then
		if Scoreboard.ScoreGetColor == nil then
			if Scoreboard.ScoreLo == nil then
				error( "'ScoreColors' is enabled, but you did not specify 'ScoreLo'" )
			end

			if Scoreboard.ScoreHi == nil then
				error( "'ScoreColors' is enabled, but you did not specify 'ScoreHi'" )
			end

			if Scoreboard.ScoreLoColor == nil then
				error( "'ScoreColors' is enabled, but you did not specify 'ScoreLoColor'" )
			end

			if Scoreboard.ScoreHiColor == nil then
				error( "'ScoreColors' is enabled, but you did not specify 'ScoreHiColor'" )
			end
		end
	end

	if Scoreboard.KarmaColors then
		if Scoreboard.KarmaGetColor == nil then
			if Scoreboard.KarmaLo == nil then
				error( "'KarmaColors' is enabled, but you did not specify 'KarmaLo'" )
			end

			if Scoreboard.KarmaHi == nil then
				error( "'KarmaColors' is enabled, but you did not specify 'KarmaHi'" )
			end

			if Scoreboard.KarmaLoColor == nil then
				error( "'KarmaColors' is enabled, but you did not specify 'KarmaLoColor'" )
			end

			if Scoreboard.KarmaHiColor == nil then
				error( "'KarmaColors' is enabled, but you did not specify 'KarmaHiColor'" )
			end
		end
	end

	if Scoreboard.Ranks then
		if Scoreboard.RankGetName == nil then
			error( "'Ranks' is enabled, but you did not specify 'RankGetName'" )
		end
	end

	if Scoreboard.NameColors then
		if Scoreboard.GetNameColor == nil then
			if Scoreboard.UseRankColor == nil then
				error( "'NameColors' is enabled, but you did not specify 'GetNameColor' or 'UseRankColor'")
			end
		end
	end

	if halt then
		return
	end

	include( "scoreboard/vgui/labels/utility.lua" )
	include( "scoreboard/vgui/labels/timer.lua" )
	include( "scoreboard/vgui/labels/name.lua" )
	include( "scoreboard/vgui/labels/ping.lua" )
	include( "scoreboard/vgui/labels/deaths.lua" )
	include( "scoreboard/vgui/labels/score.lua" )
	include( "scoreboard/vgui/labels/karma.lua" )
	include( "scoreboard/vgui/labels/rank.lua" )
	include( "scoreboard/vgui/labels/tag.lua" )

	include( "scoreboard/vgui/scoreboard.lua" )
	include( "scoreboard/vgui/banner.lua" )
	include( "scoreboard/vgui/header.lua" )
	include( "scoreboard/vgui/canvas.lua" )
	include( "scoreboard/vgui/group.lua" )
	include( "scoreboard/vgui/groupheader.lua" )
	include( "scoreboard/vgui/player.lua" )
	include( "scoreboard/vgui/avatar.lua" )
	include( "scoreboard/vgui/divider.lua" )
	include( "scoreboard/vgui/mute.lua" )
	include( "scoreboard/vgui/tagbutton.lua" )

	panel = vgui.Create( "Scoreboard" )
	panel:SetVisible( false )
end

hook.Add( "ScoreboardShow", "TTT_Scoreboard", function()
	if not IsValid( panel ) then
		makeScoreboard()
	end

	gui.EnableScreenClicker( true )
	panel:SetVisible( true )
	return true
end )

hook.Add( "ScoreboardHide", "TTT_Scoreboard", function()
	if not IsValid( panel ) then
		makeScoreboard()
	end

	CloseDermaMenus()
	gui.EnableScreenClicker( false )
	panel:SetVisible( false )
	return true
end )

concommand.Add( "scoreboard_reload", function()
	panel:Remove()
	makeScoreboard()
end )