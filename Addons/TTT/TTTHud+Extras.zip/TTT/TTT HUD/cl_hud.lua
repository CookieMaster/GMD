-- HUD HUD HUD

local table = table
local surface = surface
local draw = draw
local math = math
local string = string

local GetTranslation = LANG.GetTranslation
local GetPTranslation = LANG.GetParamTranslation
local GetLang = LANG.GetUnsafeLanguageTable
local interp = string.Interp

-- Fonts
surface.CreateFont("TraitorState", {font = "Trebuchet24",
                                    size = 28,
                                    weight = 1000})
surface.CreateFont("TimeLeft",     {font = "Trebuchet24",
                                    size = 24,
                                    weight = 800})
surface.CreateFont("HealthAmmo",   {font = "Trebuchet24",
                                    size = 24,
                                    weight = 750})
-- Color presets
local bg_colors = {
   background_main = Color(0, 0, 10, 200),

   noround = Color(100,100,100,200),
   traitor = Color(232, 100, 100, 200),
   innocent = Color(100, 232, 162, 200),
   detective = Color(100, 142, 232, 200)
};

local health_colors = {
   border = COLOR_WHITE,
   background = Color(100, 25, 25, 222),
   fill = Color(200, 50, 50, 250)
};

local ammo_colors = {
   border = COLOR_WHITE,
   background = Color(20, 20, 5, 222),
   fill = Color(205, 155, 0, 255)
};


-- Modified RoundedBox
local Tex_Corner8 = surface.GetTextureID( "gui/corner8" )
local function RoundedMeter( bs, x, y, w, h, color)
   surface.SetDrawColor(clr(color))

   surface.DrawRect( x+bs, y, w-bs*2, h )
   surface.DrawRect( x, y+bs, bs, h-bs*2 )

   surface.SetTexture( Tex_Corner8 )
   surface.DrawTexturedRectRotated( x + bs/2 , y + bs/2, bs, bs, 0 )
   surface.DrawTexturedRectRotated( x + bs/2 , y + h -bs/2, bs, bs, 90 )

   if w > 14 then
      surface.DrawRect( x+w-bs, y+bs, bs, h-bs*2 )
      surface.DrawTexturedRectRotated( x + w - bs/2 , y + bs/2, bs, bs, 270 )
      surface.DrawTexturedRectRotated( x + w - bs/2 , y + h - bs/2, bs, bs, 180 )
   else
      surface.DrawRect( x + math.max(w-bs, bs), y, bs/2, h )
   end

end

---- The bar painting is loosely based on:
---- http://wiki.garrysmod.com/?title=Creating_a_HUD

-- Paints a graphical meter bar
local function PaintBar(x, y, w, h, colors, value)
   -- Background
   -- slightly enlarged to make a subtle border
   draw.RoundedBox(8, x-1, y-1, w+2, h+2, colors.background)

   -- Fill
   local width = w * math.Clamp(value, 0, 1)

   if width > 0 then
      RoundedMeter(8, x, y, width, h, colors.fill)
   end
end

local roundstate_string = {
   [ROUND_WAIT]   = "round_wait",
   [ROUND_PREP]   = "round_prep",
   [ROUND_ACTIVE] = "round_active",
   [ROUND_POST]   = "round_post"
};

-- Returns player's ammo information
local function GetAmmo(ply)
   local weap = ply:GetActiveWeapon()
   if not weap or not ply:Alive() then return -1 end

   local ammo_inv = weap:Ammo1()
   local ammo_clip = weap:Clip1()
   local ammo_max = weap.Primary.ClipSize

   return ammo_clip, ammo_max, ammo_inv
end

local function DrawBg(x, y, width, height, client)
   -- Traitor area sizes
   local th = 30
   local tw = 170

   -- Adjust for these
   y = y - th
   height = height + th

   -- main bg area, invariant
   -- encompasses entire area
   draw.RoundedBox(8, x, y, width, height, bg_colors.background_main)

   -- main border, traitor based
   local col = bg_colors.innocent
   if GAMEMODE.round_state != ROUND_ACTIVE then
      col = bg_colors.noround
   elseif client:GetTraitor() then
      col = bg_colors.traitor
   elseif client:GetDetective() then
      col = bg_colors.detective
   end

   draw.RoundedBox(8, x, y, tw, th, col)
end

local sf = surface
local dr = draw

local function ShadowedText(text, font, x, y, color, xalign, yalign)

   dr.SimpleText(text, font, x+2, y+2, COLOR_BLACK, xalign, yalign)

   dr.SimpleText(text, font, x, y, color, xalign, yalign)
end

local margin = 10

-- Paint punch-o-meter
local function PunchPaint(client)
   local L = GetLang()
   local punch = client:GetNWFloat("specpunches", 0)

   local width, height = 200, 25
   local x = ScrW() / 2 - width/2
   local y = margin/2 + height

   PaintBar(x, y, width, height, ammo_colors, punch)

   local color = bg_colors.background_main

   dr.SimpleText(L.punch_title, "HealthAmmo", ScrW() / 2, y, color, TEXT_ALIGN_CENTER)

   dr.SimpleText(L.punch_help, "TabLarge", ScrW() / 2, margin, COLOR_WHITE, TEXT_ALIGN_CENTER)

   local bonus = client:GetNWInt("bonuspunches", 0)
   if bonus != 0 then
      local text
      if bonus < 0 then
         text = interp(L.punch_bonus, {num = bonus})
      else
         text = interp(L.punch_malus, {num = bonus})
      end

      dr.SimpleText(text, "TabLarge", ScrW() / 2, y * 2, COLOR_WHITE, TEXT_ALIGN_CENTER)
   end
end

local clamp, cos, sin, deg2rad = math.Clamp, math.cos, math.sin, math.pi/180
function DrawPartialCircle( x, y, radius, linewidth, startangle, endangle, aa )
    aa = aa or 1;
    startangle = clamp( startangle or 0, 0, 360 );
    endangle = clamp( endangle or 360, 0, 360 );
     
    if endangle < startangle then
        local temp = endangle;
        endangle = startangle;
        startangle = temp;
    end

    for i=startangle, endangle, aa do
        local _i = i * deg2rad;         
        surface.DrawTexturedRectRotated(cos( _i ) * (radius - linewidth) + x,sin( _i ) * (radius - linewidth) + y, linewidth, aa*2, -i );
    end
end

local key_params = { usekey = Key("+use", "USE") }

local function SpecHUDPaint(client)
   local L = GetLang() -- for fast direct table lookups 
 
   -- Draw round state
   local x       = margin
   local height  = 32
   local width   = 250
   local round_y = ScrH() - height - margin

   -- move up a little on low resolutions to allow space for spectator hints
   if ScrW() < 1000 then round_y = round_y - 15 end

   local time_x = x + 170
   local time_y = round_y + 4
   
	draw.RoundedBox(0, x, round_y, width, height, bg_colors.background_main)
   draw.RoundedBox(0, x, round_y, time_x - x, height, bg_colors.noround)

   local text = L[ roundstate_string[GAMEMODE.round_state] ]
   ShadowedText(text, "TraitorState", x + margin, round_y, COLOR_WHITE)

   -- Draw round/prep/post time remaining
   local text = util.SimpleTime(math.max(0, GetGlobalFloat("ttt_round_end", 0) - CurTime()), "%02i:%02i")
   ShadowedText(text, "TimeLeft", time_x + margin, time_y, COLOR_WHITE)

   local tgt = client:GetObserverTarget()
   if IsValid(tgt) and tgt:IsPlayer() then
      ShadowedText(tgt:Nick(), "TimeLeft", ScrW() / 2, margin, COLOR_WHITE, TEXT_ALIGN_CENTER)

   elseif IsValid(tgt) and tgt:GetNWEntity("spec_owner", nil) == client then
      PunchPaint(client)
   else
      ShadowedText(interp(L.spec_help, key_params), "TabLarge", ScrW() / 2, margin, COLOR_WHITE, TEXT_ALIGN_CENTER)
   end

end

local ttt_health_label = CreateClientConVar("ttt_health_label", "0", true)

 local cx = 42+27
 local cy = ScrH()-130
 local poly_tbl = {{ },{ },{ }}
 
poly_tbl[1]["x"] = cx -10
poly_tbl[1]["y"] = cy
poly_tbl[1]["u"] = 0 
poly_tbl[1]["v"] = 0
 
poly_tbl[2]["x"] = cx + 10
poly_tbl[2]["y"] = cy
poly_tbl[2]["u"] = 1 
poly_tbl[2]["v"] = 0
 
poly_tbl[3]["x"] = cx
poly_tbl[3]["y"] = cy + 10
poly_tbl[3]["u"] = 0 
poly_tbl[3]["v"] = 1

surface.CreateFont( "ROLE_TEXT", {font = "Arial",size = 25,weight = 800} )
surface.CreateFont( "CLIP_TEXT", {font = "Arial",size = 35,weight = 800} )
surface.CreateFont( "AMMO_TEXT", {font = "Arial",size = 20,weight = 800} )
surface.CreateFont( "RUND_TEXT", {font = "Arial",size = 15,weight = 500} )

local TTTHUDILYA = {}

function TTTHUDILYA:Paint()
	local ply = LocalPlayer()
	if not ply:IsValid() then return end
	if (not ply:Alive()) or ply:Team() == TEAM_SPEC then return end
	
	local round_state = GAMEMODE.round_state
	local endtime = GetGlobalFloat("ttt_round_end", 0) - CurTime()
	local SWEP = ply:GetActiveWeapon()
	local is_haste = HasteMode() and round_state == ROUND_ACTIVE
	local is_traitor = ply:IsActiveTraitor()
	local swepname = ""
	
	if SWEP:IsValid() then
		clip1type = SWEP:GetPrimaryAmmoType() or ""
		clip1 = tonumber(SWEP:Clip1()) or 0
		clip1left = ply:GetAmmoCount(clip1type)
		swepname = string.upper(SWEP:GetPrintName())
	else
		clip1 = 0
		clip1left = 0
		swepname = "NOTHING"
	end
	if clip1 == -1 then clip1 = 0 end
	
	if SWEP:IsValid() then
		if SWEP:GetClass() == "weapon_zm_improvised" then 
			swepname = "Crowbar" end
		if SWEP:GetClass() == "weapon_zm_carry" then 
			swepname = "Magneto-Stick" end
		if SWEP:GetClass() == "weapon_ttt_unarmed" then 
			swepname = "Holster" end
		if SWEP:GetClass() == "weapon_ttt_ak47" then 
			swepname = "AK-47" end
		if SWEP:GetClass() == "weapon_ttt_aug" then 
			swepname = "AUG" end
		if SWEP:GetClass() == "weapon_zm_mac10" then 
			swepname = "Mac10" end
		if SWEP:GetClass() == "weapon_ttt_44mag" then 
			swepname = ".44 Magnum" end
		if SWEP:GetClass() == "weapon_ttt_beacon" then 
			swepname = "Beacon" end
		if SWEP:GetClass() == "weapon_zm_revolver" then 
			swepname = "Deagle" end
		if SWEP:GetClass() == "weapon_ttt_l96aw" then 
			swepname = "L96A1" end
		if SWEP:GetClass() == "weapon_ttt_m16" then 
			swepname = "M16" end
		if SWEP:GetClass() == "weapon_ttt_g3sg1" then 
			swepname = "G3SG1" end
		if SWEP:GetClass() == "weapon_ttt_ump" then 
			swepname = "UMP" end
		if SWEP:GetClass() == "weapon_zm_rifle" then 
			swepname = "Rifle" end
		if SWEP:GetClass() == "weapon_ttt_870" then 
			swepname = "Remington 870" end
		if SWEP:GetClass() == "weapon_ttt_p90" then 
			swepname = "P90" end
		if SWEP:GetClass() == "weapon_zm_sledge" then 
			swepname = "HUGE-249" end
		if SWEP:GetClass() == "weapon_ttt_mp5" then 
			swepname = "MP5" end
		if SWEP:GetClass() == "weapon_ttt_galil" then 
			swepname = "Galil" end
		if SWEP:GetClass() == "weapon_ttt_sg550" then 
			swepname = "SG550" end
		if SWEP:GetClass() == "weapon_zm_shotgun" then 
			swepname = "Shotgun" end
		if SWEP:GetClass() == "weapon_zm_pistol" then 
			swepname = "Pistol" end	
		if SWEP:GetClass() == "weapon_ttt_glock" then 
			swepname = "Glock" end
		if SWEP:GetClass() == "weapon_ttt_smokegrenade" then 
			swepname = "Smoke Grenade" end
		if SWEP:GetClass() == "weapon_zm_molotov" then 
			swepname = "Incendiary Grenade"  end
		if SWEP:GetClass() == "weapon_ttt_confgrenade" then 
			swepname = "Discombobulator" end
	end
	
	surface.SetDrawColor( Color( 0, 0, 0, 150 ) )
    surface.DrawPoly( poly_tbl )
	
	for i = 1, 8 do
		if ply:GetRole() == ROLE_TRAITOR then
			surface.SetDrawColor(bg_colors.traitor)
		elseif ply:GetRole() == ROLE_DETECTIVE then
			surface.SetDrawColor(bg_colors.detective)
		else
			surface.SetDrawColor(bg_colors.innocent)
		end
		DrawPartialCircle( 70, ScrH()-70, 50, 12, 0, Lerp(ply:Health()/100,0,360), i )
	end
	
	for i = 1, 7 do
		surface.SetDrawColor(255,255,255,255)
		DrawPartialCircle( 70, ScrH()-70, 55, 8, 0, Lerp(1-(CurTime()/GetGlobalFloat("ttt_round_end", 0)), 0, 360), i )
	end
	
	-- Draw Role
	local rl = "nil"
	if round_state == ROUND_PREP then
		rl = "PREPARING"
	elseif round_state == ROUND_ACTIVE then
		if ply:GetRole() == ROLE_TRAITOR then
			rl = "TRAITOR"
		elseif ply:GetRole() == ROLE_DETECTIVE then
			rl = "DETECTIVE"
		else
			rl = "INNOCENT"
		end
	else
		rl = "WAITING"
	end
	
	local health = "[" .. ply:Health() .. "]"
	surface.SetFont("ROLE_TEXT")
	local Width, Height = surface.GetTextSize(rl)
	surface.SetFont("RUND_TEXT")
	local Wd, Ht = surface.GetTextSize(health)
	draw.RoundedBox( 0, 120, ScrH()-120, Width+Wd+5, 23, Color( 0, 0, 0, 150 ) )
	
	draw.SimpleText(rl, "ROLE_TEXT", 122, ScrH()-120, Color(255,255,255,200), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	draw.SimpleText(health, "RUND_TEXT", 123+Width, ScrH()-117, Color(255,255,255,200), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	
	-- Draw Ammo
	draw.RoundedBox( 0, 130, ScrH()-90, 95, 43, Color( 0, 0, 0, 150 ) )
	
	draw.SimpleText(clip1, "CLIP_TEXT", 187, ScrH()-85, Color(255,255,255,200), TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT)
	draw.SimpleText("000", "CLIP_TEXT", 187, ScrH()-85, Color(255,255,255,30), TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT)
	
	draw.SimpleText(clip1left, "AMMO_TEXT", 215, ScrH()-73, Color(255,255,255,200), TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT)
	draw.SimpleText("000", "AMMO_TEXT", 215, ScrH()-73, Color(255,255,255,30), TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT)
	
	-- Draw Weapon
	surface.SetFont("ROLE_TEXT")
	local Width, Height = surface.GetTextSize(string.upper(swepname))
	draw.RoundedBox( 0, 120, ScrH()-40, Width+4, 23, Color( 0, 0, 0, 150 ) )
	draw.SimpleText(string.upper(swepname), "ROLE_TEXT", 122, ScrH()-40, Color(255,255,255,200), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
	
	-- Draw Time Box
	local qfix = 0
	local COL = Color(255,255,255)
	local text = ""
	if is_haste then
		local hastetime = GetGlobalFloat("ttt_haste_end", 0) - CurTime()
		if hastetime < 0 then
			if (not is_traitor) or (math.ceil(CurTime()) % 7 <= 2) then
				text = "OVERTIME"
				qfix = 6
			else
				text = string.ToMinutesSecondsMilliseconds(math.Round(endtime, 2))
				COL = Color(255,100,100)
			end
		else
			local t = hastetime
			if is_traitor and math.ceil(CurTime()) % 6 < 2 then
				t = endtime
				COL = Color(255,100,100)
			end
			text = string.ToMinutesSecondsMilliseconds(math.Round(t, 2))
		end
	else
		text = string.ToMinutesSecondsMilliseconds(math.Round(endtime, 2))
	end
	surface.SetFont("RUND_TEXT")
	local Width, Height = surface.GetTextSize(text)
	draw.RoundedBox( 0, 42, ScrH()-147, Width+4, 17, Color( 0, 0, 0, 150 ) )
	
	draw.SimpleText( text, "RUND_TEXT", 68+qfix, ScrH()-140, COL, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) -- string.ToMinutesSecondsMilliseconds(math.Round(endtime, 2))
end
vgui.Register("ttt_hud_ilya", TTTHUDILYA)

local ttt_hud_ilya = vgui.Create("ttt_hud_ilya")
ttt_hud_ilya:SetSize( ScrW(), ScrH() )

local PCalcT = {}
PCalcT.VS 	 = 0
PCalcT.WT 	 = 0
PCalcT.Air	 = 0

-- Paints player status HUD element in the bottom left
function GM:HUDPaint()
   local client = LocalPlayer()

   GAMEMODE:HUDDrawTargetID()

   MSTACK:Draw(client)

   if (not client:Alive()) or client:Team() == TEAM_SPEC then
      SpecHUDPaint(client)
      return
   end


   RADAR:Draw(client)
   TBHUD:Draw(client)
   WSWITCH:Draw(client)

   VOICE.Draw(client)
   DISGUISE.Draw(client)

   GAMEMODE:HUDDrawPickupHistory()
	
	--print(lel) 
	
   -- Draw bottom left info panel
   -- iHUD(client)
end

-- Hide the standard HUD stuff
local hud = {"CHudHealth", "CHudBattery", "CHudAmmo", "CHudSecondaryAmmo"}
function GM:HUDShouldDraw(name)
   for k, v in pairs(hud) do
      if name == v then return false end
   end

   return true
end

