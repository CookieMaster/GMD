If all you want to do is use the HUD then replace the cl_hud.lua in gamemodes/terrortown/gamemode. If you want to use the 
the hit markers and/or colored damage and death log then place the folder named IlyaTTTextras in your addons folder.
Now your done. 