hook.Add( "PlayerInitialSpawn", "AddSlayData", function( ply ) 
	if ( ply:GetPData( "As_ramount" ) == nil ) then
		ply:SetPData( "As_ramount", 0 )
	end
	if ( ply:GetPData( "As_by" ) == nil ) then
		ply:SetPData( "As_by", "" )
	end
	if ( ply:GetPData( "As_ramount" ) == 0 ) then
		ply:SetPData( "As_by", "" )
	end
	if ( tonumber(ply:GetPData( "As_ramount" )) > 0) then
		ply.snr = true
		ply.totalas = ply:GetPData( "As_ramount" )
		timer.Simple(15, function() 
			ply:SendLua("notification.AddLegacy(\"[Auto Slay] Your "..ply:GetPData( "As_ramount" ).." slay(s) have been readded.\", NOTIFY_ERROR, 10)")
			ply:SendLua("surface.PlaySound(\"buttons/button15.wav\")")
		end)

	end
	if ( ply:GetPData( "As_reason" ) == nil ) then
		ply:SetPData( "As_reason", "" )
	end
end )

hook.Add("TTTBeginRound", "AS", function()
	for k, v in pairs(player.GetAll()) do
			reason = v:GetPData( "As_reason" )
			if reason == nil then
				reason = ""
				ply:SetPData( "As_reason", "" )
			end
			if tonumber(v:GetPData( "As_ramount", 0 )) == 1 then
				timer.Simple(0, function() -- So it shows up in damagelog menu
					v:Kill()
					local corpse = corpse_find(v)
					if corpse then
						corpse_identify(corpse)
					end
				end)
				v:SetPData( "As_ramount", 0 )
				v:SetPData( "As_by", "" )
				if reason == "" then
					v:SendLua("notification.AddLegacy(\"[Auto Slay] You have been automatically slain, no slays are pending against you now.\", NOTIFY_ERROR, 10)")
					v:SendLua("notification.AddLegacy(\"[Auto Slay] It is now safe for you to leave.\", NOTIFY_ERROR, 10)")
					quote1 = ""
					quote2 = ""
				else
					v:SendLua("notification.AddLegacy(\"[Auto Slay] You have been automatically slain for '"..reason.."', no slays are pending against you now.\", NOTIFY_ERROR, 10)")
					v:SendLua("notification.AddLegacy(\"[Auto Slay] It is now safe for you to leave.\", NOTIFY_ERROR, 10)")
					quote1 = " for '"
					quote2 = "'"
				end
				v:SendLua("surface.PlaySound(\"buttons/button15.wav\")")
			elseif tonumber(v:GetPData( "As_ramount", 0 )) > 1 then
				timer.Simple(0, function() -- So it shows up in damagelog menu
					v:Kill()
					local corpse = corpse_find(v)
					if corpse then
						corpse_identify(corpse)
					end
				end)
				v:SetPData( "As_ramount", v:GetPData( "As_ramount", 0 ) - 1 )
				if v.totalas == 1 then
					grammar = "s"
				else
					grammar = ""
				end
				if reason == "" then
					v:SendLua("notification.AddLegacy(\"[Auto Slay] You have been automatically slain, ".. v:GetPData( "As_ramount", 0 ) .." slay"..grammar.." are pending against you now.\", NOTIFY_ERROR, 10)")
					v:SendLua("notification.AddLegacy(\"[Auto Slay] It is NOT safe for you to leave, leaving will still result in a ban for each slay pending against you.\", NOTIFY_ERROR, 10)")
				else
					v:SendLua("notification.AddLegacy(\"[Auto Slay] You have been automatically slain for '"..reason.."', ".. v:GetPData( "As_ramount", 0 ) .." slay"..grammar.." are pending against you now.\", NOTIFY_ERROR, 10)")
					v:SendLua("notification.AddLegacy(\"[Auto Slay] It is NOT safe for you to leave, leaving will still result in a ban for each slay pending against you.\", NOTIFY_ERROR, 10)")
				end
				v:SendLua("surface.PlaySound(\"buttons/button15.wav\")")
				--ulx.logString( v:Nick().." was autoslain, with "..v.totalas.." rounds remaining. This was done by"..calling_ply:Nick().."("..reason..")" )
			else
				v:SetPData( "As_ramount", 0 )
				v:SetPData( "As_reason", "" )
				v:SetPData( "As_by", "" )
			end --if target_plys
		end
		end)

function Disconnect(ply)
    if tonumber(ply:GetPData( "As_ramount", 0 )) > 0 then
		local bantime = 1440*tonumber(ply:GetPData( "As_ramount", 0 ))
		ulx.fancyLog( "#T has been banned for evading "..ply:GetPData( "As_ramount", 0 ).." autoslay(s), if this was done in error you can unban them.", ply )
		ply:SetPData( "As_ramount", 0 )
		ply:SetPData( "As_reason", "" )
		ply:SetPData( "As_by", "" )
        ULib.ban(ply, bantime, "[Auto Slay] RDM and evade. If this was done in error you can unban this.")
	end
end
hook.Add( "PlayerDisconnected", "ASDisconnect", Disconnect )
-- Corpse function that isn't mine
function corpse_find(v)
	for _, ent in pairs( ents.FindByClass( "prop_ragdoll" )) do
		if ent.uqid == v:UniqueID() and IsValid(ent) then
			return ent or false
		end
	end
end

function corpse_remove(corpse)
	CORPSE.SetFound(corpse, false)
	if string.find(corpse:GetModel(), "zm_", 6, true) then
		corpse:Remove()
	elseif corpse.player_ragdoll then
		corpse:Remove()
	end
end

function corpse_identify(corpse)
	if corpse then
		local ply = player.GetByUniqueID(corpse.uqid)
		ply:SetNWBool("body_found", true)
		CORPSE.SetFound(corpse, true)
	end
end