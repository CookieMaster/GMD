--[[
----------------------------------------
|||||||	TTT	Multiround Autoslay	||||||||
|||||||			By:				||||||||
|||||||		TheAndroid1			||||||||
----------------------------------------
]]--
local CATEGORY_NAME = "TTT"

function ulx.autoslay(calling_ply, target_plys, ramount, reason, should_revoke)

	if should_revoke then
		if ( tonumber(target_plys:GetPData( "As_ramount" )) == 0) then
			ULib.tsayError( calling_ply, target_plys:Nick() .. " doesn't have any slays pending against them. ", true )
			return
		end
		target_plys:SetPData( "As_ramount", 0 )
		target_plys:SetPData( "As_reason", "" )
		target_plys:SetPData( "As_by", "" )
		ulx.fancyLogAdmin( calling_ply, "#A removed all pending slays from #T", target_plys )
		target_plys:SendLua("notification.AddLegacy(\"[Auto Slay] All autoslays against you have been removed. This was done by "..calling_ply:Nick().."\", NOTIFY_ERROR, 10)")
		target_plys:SendLua("surface.PlaySound(\"buttons/button15.wav\")")
		target_plys.snrby = nil
		return
	end
	
	if ( tonumber(target_plys:GetPData( "As_ramount" )) > 0) then
		ULib.tsayError( calling_ply, target_plys:Nick() .. " is already being slain by " .. target_plys:GetPData( "As_by" ), true )
	elseif ramount == 1 then
		if reason == "" then 
		ulx.fancyLogAdmin( calling_ply, "#A set #T to be slain for the next round", target_plys ) 
		quote1 = ""
		quote2 = ""
		else
		ulx.fancyLogAdmin( calling_ply, "#A set #T to be slain for the next round for #3s", target_plys, reason )
		quote1 = " for '"
		quote2 = "'"
		end
		target_plys:SetPData( "As_ramount", ramount )
		target_plys:SetPData( "As_reason", reason )
		target_plys:SetPData( "As_by", calling_ply:Nick() )
		target_plys:SendLua("notification.AddLegacy(\"[Auto Slay] You will be slain in the next round. This was done by "..calling_ply:Nick()..""..quote1..""..reason..""..quote2.."\", NOTIFY_ERROR, 10)")
		target_plys:SendLua("notification.AddLegacy(\"[Auto Slay] Attempting to leave while being autoslain will result in a day ban for each slay which will then be extended by staff.\", NOTIFY_ERROR, 10)")
		target_plys:SendLua("surface.PlaySound(\"buttons/button15.wav\")")
	elseif ramount > 1 then
		if reason == "" then 
				ulx.fancyLogAdmin( calling_ply, "#A set #T to be slain for the next#2i rounds", target_plys, ramount ) 
				quote1 = ""
				quote2 = ""
			else
				ulx.fancyLogAdmin( calling_ply, "#A set #T to be slain for the next#2i rounds for #3s", target_plys, ramount, reason )
				quote1 = " for '"
				quote2 = "'"
		end
		target_plys:SetPData( "As_ramount", ramount )
		target_plys:SetPData( "As_reason", reason )
		target_plys:SetPData( "As_by", calling_ply:Nick() )
		target_plys:SendLua("notification.AddLegacy(\"[Auto Slay] You will be slain for the next "..ramount.." rounds. This was done by ".. calling_ply:Nick() ..""..quote1..""..reason..""..quote2.."\", NOTIFY_ERROR, 10)")
		target_plys:SendLua("notification.AddLegacy(\"[Auto Slay] Attempting to leave while being autoslain will result in a day ban for each slay which will then be extended by staff.\", NOTIFY_ERROR, 10)")
		target_plys:SendLua("surface.PlaySound(\"buttons/button15.wav\")")
	end
end
local _andas = ulx.command( CATEGORY_NAME, "ulx autoslay", ulx.autoslay, "!as" )
_andas:addParam{ type=ULib.cmds.PlayerArg }
_andas:addParam{ type=ULib.cmds.NumArg, min=1, max=10, default=1, hint="round amount", ULib.cmds.optional }
_andas:addParam{ type=ULib.cmds.StringArg, hint="reason", ULib.cmds.optional, ULib.cmds.takeRestOfLine }
_andas:addParam{ type=ULib.cmds.BoolArg, hint="should unautoslay", invisible=true }
_andas:defaultAccess( ULib.ACCESS_ADMIN )
_andas:help( "Slays target the following round(s) for RDM with a reason." )
_andas:setOpposite( "ulx unautoslay", {_, _, _, _, true}, "!unas" )

function ulx.pslays( calling_ply )
	ULib.console( calling_ply, "Name			           Slay Amount	  Reason		       By" )

	local players = player.GetAll()
	for _, v in ipairs( player.GetAll() ) do
	if v:IsValid() then
		local nick = v:Nick()

		text = nick..string.rep( " ", 35 - nick:len() )..tonumber(v:GetPData( "As_ramount" ))..string.rep( " ", 15 - 1 )..v:GetPData( "As_reason" )..string.rep( " ", 29 - v:GetPData( "As_reason" ):len() )..v:GetPData( "As_by" )

		ULib.console( calling_ply, text )
	end
	end
end
local pslays = ulx.command( CATEGORY_NAME, "ulx printslays", ulx.pslays, "!ps" )
pslays:defaultAccess( ULib.ACCESS_ADMIN )
pslays:help( "See autoslay information about currently online users." )