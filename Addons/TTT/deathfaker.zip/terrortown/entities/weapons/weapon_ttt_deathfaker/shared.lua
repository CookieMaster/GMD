 CreateConVar("ttt_deathfaker_enablebulletdamage",0,{FCVAR_SERVER_CAN_EXECUTE},"Allows traitors to choose their death reason")


if SERVER then
   AddCSLuaFile( "shared.lua" )

end

SWEP.HoldType        = "slam"

if CLIENT then
   SWEP.PrintName       = "Death Faker"
   SWEP.Slot            = 6

   SWEP.EquipMenuData = {
      type  = "item_weapon",
      name  = "Death Faker ",
      desc  = "This equipment will allow you fake your own death"
   };

   SWEP.Icon = "VGUI/ttt/icon_fall"
end

SWEP.Base = "weapon_tttbase"

SWEP.Kind = WEAPON_EQUIP
SWEP.CanBuy = {ROLE_TRAITOR} -- only traitors can buy
SWEP.WeaponID = WEAPON_DEATHFAKE

SWEP.UseHands        = true
SWEP.ViewModelFlip      = true
SWEP.ViewModelFOV    = 54
SWEP.ViewModel  = Model("models/weapons/cstrike/c_c4.mdl")
SWEP.WorldModel = Model("models/weapons/w_c4.mdl")

SWEP.DrawCrosshair      = false
SWEP.ViewModelFlip      = false
SWEP.Primary.ClipSize       = -1
SWEP.Primary.DefaultClip    = -1
SWEP.Primary.Automatic      = true
SWEP.Primary.Ammo       = "none"
SWEP.Primary.Delay = 10.0

SWEP.Secondary.ClipSize     = -1
SWEP.Secondary.DefaultClip  = -1
SWEP.Secondary.Automatic    = true
SWEP.Secondary.Ammo     = "none"
SWEP.Secondary.Delay = 10.0
SWEP.LimitedStock = true
SWEP.NoSights = true
SWEP.AllowDrop = false
local DeathReason = DMG_FALL


function SWEP:OnDrop()
   self:Remove()
end

local throwsound = Sound( "physics/body/body_medium_impact_soft2.wav" )
local weapons = {"weapon_zm_pistol","weapon_ttt_m16","weapon_zm_revolver"}
function SWEP:PrimaryAttack()
   self.Weapon:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
   self:BodyDrop()
end

function SWEP:SecondaryAttack()
   self.Weapon:SetNextSecondaryFire( CurTime() + self.Secondary.Delay )
   self:BodyDrop()
end

function SWEP:BodyDrop()
   if SERVER then
      
      local ply = self.Owner
      if not IsValid(ply) then return end

      if self.Planted then return end

      local vsrc = ply:GetShootPos()
      local vang = ply:GetAimVector()
      local vvel = ply:GetVelocity()
      
      local vthrow = vvel + vang * 300

      local dmginfo = DamageInfo()  
      dmginfo:SetDamage( math.random(10,100) )
      dmginfo:SetDamageType( DeathReason ) 
      local rag = CORPSE.Create(ply,nil,dmginfo)
      CORPSE.SetCredits(rag,0)
      if DeathReason == DMG_BULLET then
         rag.dmgwep  = table.Random(weapons)
      end
      ply:SetNWBool("is_pretending", true)
      rag:SetNWString("nick", ply:Nick())
      rag.uqid = ply:UniqueID()
      ply:SetAnimation( PLAYER_ATTACK1 )
      self.Planted = true
      self:Remove()
   end

   self.Weapon:EmitSound(throwsound)
   self.Weapon:SendWeaponAnim(ACT_VM_SECONDARYATTACK)
end


function SWEP:OnRemove()
   if CLIENT and IsValid(self.Owner) and self.Owner == LocalPlayer() and self.Owner:Alive() then
      RunConsoleCommand("lastinv")
   end
end


function SWEP:Reload()
   if cooldown then return false end
   if (ConVarExists("ttt_deathfaker_enablebulletdamage")) then
      if !GetConVar("ttt_deathfaker_enablebulletdamage"):GetBool() then return false end
   end
   local ply = self.Owner
   if DeathReason == DMG_BULLET then
      DeathReason = DMG_FALL
      ply:PrintMessage(HUD_PRINTCENTER, "Fall Damage Selected" )
   elseif DeathReason == DMG_FALL then
      DeathReason = DMG_BULLET
      ply:PrintMessage(HUD_PRINTCENTER,"Bullet Damage Selected")
   end
   cooldown = true
   timer.Simple(0.5, function() cooldown = false end)

   return false
end

function ResetDeathFaker (result)
for k, v in pairs(player.GetAll()) do
   v:SetNWBool("is_pretending", false)
end
end

hook.Add("TTTEndRound", "ttt_deathfaker_reset_hook", ResetDeathFaker)

