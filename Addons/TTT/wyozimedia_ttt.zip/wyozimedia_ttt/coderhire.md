WMC TTT adds Trouble in Terrorist Town related functions to the Wyozi Media Center.

##Features

---

**Easy round end music management**

**Can set per-player round end musics (as a donation perk or etc)**

**Comprehensive F1 menu settings**

**TTT Triggers** Allow you to make specific songs play on conditions you decide. _WIP: Not added to the addon yet._ 


## Installation

---

Just unzip the addon to your addons folder and you're good to go! Note: you also need the base Media Center installed for the addon to work properly.

https://dl.dropboxusercontent.com/u/18458187/wmctttsettings.png
https://dl.dropboxusercontent.com/u/18458187/wmctttmenu.jpg