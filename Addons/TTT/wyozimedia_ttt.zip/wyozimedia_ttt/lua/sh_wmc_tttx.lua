
function wyozimc.IsTTT()
	return ROLE_TRAITOR ~= nil -- Hah
end

wyozimc.FLAG_IS_ENDROUND = 256