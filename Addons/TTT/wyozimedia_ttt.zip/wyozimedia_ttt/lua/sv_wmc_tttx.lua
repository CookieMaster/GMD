
util.AddNetworkString("wyozimc_ttt")
net.Receive("wyozimc_ttt", function(le, cl)
	if not wyozimc.HasPermission(cl, "Edit") then cl:ChatPrint("No permission!") return end

	local id = net.ReadString()

	local media = wyozimc.GetMediaByLink(id)
	if not media then
		cl:ChatPrint("Not in media list?")
		return
	end

	local ttype = net.ReadString()
	if ttype == "traitor" then
		media.TTTOpts = media.TTTOpts or {}
		media.TTTOpts[ROLE_TRAITOR] = true
	elseif ttype == "inno" then
		media.TTTOpts = media.TTTOpts or {}
		media.TTTOpts[ROLE_INNOCENT] = true
	elseif ttype == "timelimit" then
		media.TTTOpts = media.TTTOpts or {}
		media.TTTOpts[WIN_TIMELIMIT] = true
	--[[elseif ttype == "specific" then
		local plyent = net.ReadEntity()
		if not IsValid(plyent) or not plyent:IsPlayer() then return end

		media.TTTOpts = media.TTTOpts or {}
		media.TTTOpts[plyent:SteamID()] = true]]
	elseif ttype == "specificsid" then
		local sid = net.ReadString()
		if sid == "" then return end
		local seton = net.ReadBit() == 1
		media.TTTOpts = media.TTTOpts or {}
		media.TTTOpts[sid] = seton and true or nil
	elseif ttype == "clear" then
		media.TTTOpts = nil
	end

	wyozimc.ServerMediaList:Save()
	wyozimc.UpdateGuis()
end)

wyozimc.TTT_NextRoundChoices = {}

local function GetRandomSong(for_traitors, time_limit)
	local possibilities = {}
	for _, media in pairs(wyozimc.MediaList) do
		if media.TTTOpts and media.TTTOpts[ROLE_TRAITOR] and for_traitors then
			table.insert(possibilities, media.Link)
		end
		if media.TTTOpts and ( (media.TTTOpts[ROLE_INNOCENT] and not for_traitors) or (media.TTTOpts[WIN_TIMELIMIT] and time_limit) ) then
			table.insert(possibilities, media.Link)
		end
	end

	return #possibilities > 0 and table.Random(possibilities) or nil
end

local function GetRoundEndPlys()
	local fi = {}

	for _,ply in pairs(player.GetAll()) do
		if ply:GetInfoNum("wyozimc_noroundend", 0) == 0 then
			table.insert(fi, ply)
		end
	end

	return fi
end

local function GetSpecialSong()
	local aliveplys = {}
	for _,ply in pairs(player.GetAll()) do
		if ply:Alive() and ply:Team() ~= TEAM_SPEC then
			table.insert(aliveplys, ply)
		end
	end
	if #aliveplys == 1 then
		wyozimc.Debug("Special song condition set! Only ", aliveplys[1], " alive.")

		local sid = aliveplys[1]:SteamID()
		local available_links = {}
		for _,media in pairs(wyozimc.MediaList) do
			if media.TTTOpts and media.TTTOpts[sid] then
				wyozimc.Debug("Found special media link for ", sid, ": ", media.Link)
				table.insert(available_links, media.Link)
			end
		end

		if #available_links > 0 then
			local rnd_link = table.Random(available_links)
			wyozimc.Debug("Picked random media link ", rnd_link)
			return rnd_link
		end
	end
end

hook.Add("TTTEndRound", "WyoziMCPlayRoundEnds", function(winner)
	if not wyozimc.MediaList then return end

	local playsong = GetSpecialSong()
	local traitorswon = winner == WIN_TRAITOR
	local dontcache = false

	if playsong then
		-- We already have a playsong as a special player song
		dontcache = true
	elseif wyozimc.TTT_NextRoundChoices[tostring(traitorswon)] then
		playsong = wyozimc.TTT_NextRoundChoices[tostring(traitorswon)]
	else
		playsong = GetRandomSong(traitorswon, winner == WIN_TIMELIMIT)
	end

	if playsong then
		wyozimc.PlayFor(GetRoundEndPlys(), playsong, wyozimc.FLAG_IS_ENDROUND)
		wyozimc.PlayingRoundEnd = playsong

		if not dontcache then
			local tobecached = GetRandomSong(traitorswon, winner == WIN_TIMELIMIT)

			local provider, udata = wyozimc.FindProvider(tobecached)
			if not provider then
				ErrorNoHalt("Trying to cache something with no provider: " .. tostring(tobecached))
				return
			end

			if provider.UseGmodPlayer then
				wyozimc.TTT_NextRoundChoices[tostring(traitorswon)] = tobecached
				timer.Simple(5, function()
					wyozimc.CacheFor(GetRoundEndPlys(), tobecached)
				end)
			end
		end
	end
end)