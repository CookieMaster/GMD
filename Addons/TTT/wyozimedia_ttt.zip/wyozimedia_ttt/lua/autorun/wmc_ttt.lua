
-- Stupid? Yes. Required? Yes.
wyozimc = wyozimc or {}

local function AddClient(fil)
	if SERVER then AddCSLuaFile(fil) end
	if CLIENT then include(fil) end
end

local function AddServer(fil)
	if SERVER then include(fil) end
end

local function AddShared(fil)
	include(fil)
	AddCSLuaFile(fil)
end 

AddShared("sh_wmc_tttx.lua")
AddClient("cl_wmc_tttx.lua")
AddServer("sv_wmc_tttx.lua")

AddClient("cl_wmc_ttt_triggers.lua")
AddServer("sv_wmc_ttt_triggers.lua")