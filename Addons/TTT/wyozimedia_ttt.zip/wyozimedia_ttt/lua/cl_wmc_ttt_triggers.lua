
hook.Add("WyoziMCTabs_DISABLED", "WyoziMCTTTTriggers", function(dtabs)

	if not wyozimc.IsTTT() then return end

	if not wyozimc.HasPermission(LocalPlayer(), "Edit") then return end

	local tpane = vgui.Create("DPanel")

	local listscrl = tpane:Add("DScrollPanel")
	listscrl:Dock(FILL)
	listscrl.pnlCanvas:Dock(FILL) -- Hack hack hack, makes content pane fill the scrollpane

	local list = vgui.Create("DListView", listscrl)
	list:AddColumn("Trigger"):SetMaxWidth(256)
	list:AddColumn("Play Link")
	list:Dock(FILL)
	list:SetMultiSelect(false)
	list.OnRowRightClick = function(panel, line)

		local menu = DermaMenu()

		menu:AddOption("Delete", function()
			--net.Start("wyozimc_edit") net.WriteString("del") net.WriteString(theurl) net.SendToServer() 
		end):SetIcon( "icon16/delete.png" )
		
		menu:Open()
	end

	local btnspane = tpane:Add("DPanel")
	btnspane:Dock(BOTTOM)

	local triggercombo = btnspane:Add("DComboBox")
	triggercombo:SetSize(256, 23)
	triggercombo:Dock(LEFT)
	triggercombo:SetValue( "triggers" )
	triggercombo:AddChoice( "OnRoundStart" )
	triggercombo:AddChoice( "OnRoundEnd" )
	triggercombo:AddChoice( "OnFirstRoundStart" )
	triggercombo:AddChoice( "OnLastRoundStart" )

	local linkcombo = btnspane:Add("DComboBox")
	linkcombo:SetPos(256, 0)
	linkcombo:Dock(FILL)
	linkcombo:SetValue( "links" )

	table.foreach(wyozimc.AllLines, function(k, v)
		linkcombo:AddChoice(v.Title)
	end)

	local addbtn = btnspane:Add("DButton")
	addbtn:Dock(RIGHT)
	addbtn:SetText("Add")

	wyozimc.TTTLinkCombo = linkcombo
 
	dtabs:AddSheet( "TTT Triggers", tpane, "icon16/asterisk_orange.png", false, false, "" )

end)

hook.Add("WyoziMCListUpdated", "WyoziMCTTTTriggers", function(list)
	if IsValid(wyozimc.TTTLinkCombo) then
		wyozimc.TTTLinkCombo.Choices = {}
		table.foreach(list, function(k, v)
			wyozimc.TTTLinkCombo:AddChoice(v.Title)
		end)
	end
end)