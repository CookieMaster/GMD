
function wyozimc.LoadTTTTriggerList()
	local txt = file.Read("wyozi_ttttriggers.txt", "DATA")
	wyozimc.TTT_TriggerList = util.JSONToTable(txt or "{}")

	wyozimc.Debug("Trigger list loaded: " .. tostring(#wyozimc.TTT_TriggerList))
end

function wyozimc.SaveTTTTriggerList()
	if not wyozimc.TTT_TriggerList then return end
	file.Write("wyozi_ttttriggers.txt", util.TableToJSON(wyozimc.TTT_TriggerList))

	wyozimc.Debug("Trigger list saved: " .. tostring(#wyozimc.TTT_TriggerList))
end

--wyozimc.LoadTTTTriggerList()