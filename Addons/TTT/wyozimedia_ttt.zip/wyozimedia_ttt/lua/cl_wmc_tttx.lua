
CreateClientConVar("wyozimc_noroundend", "0", true, true)
CreateClientConVar("wyozimc_noroundendifmusic", "0")
CreateClientConVar("wyozimc_noroundendifunfocused", "1")
CreateClientConVar("wyozimc_contmusicafterroundend", "1")

hook.Add("WyoziMCMenu", "WMCAddTTTOptions", function(menu, url, tmedia)
	MsgN(wyozimc.IsTTT())
	if not wyozimc.IsTTT() then return end

	if not wyozimc.HasPermission(LocalPlayer(), "Edit") then return end
	
	menu:AddSpacer()

	local submenu, smpnl = menu:AddSubMenu("TTT", function() end)

	smpnl:SetIcon( "VGUI/ttt/sprite_traitor" )
	smpnl.m_Image:SetSize(16, 16)

	submenu:AddOption("Clear round end music", function()
		net.Start("wyozimc_ttt") net.WriteString(url) net.WriteString("clear") net.SendToServer()
	end):SetIcon( "icon16/shading.png" )

	submenu:AddSpacer()

	submenu:AddOption("Set as Innocent round end music", function()
		net.Start("wyozimc_ttt") net.WriteString(url) net.WriteString("inno") net.SendToServer()
	end):SetIcon( "icon16/user_green.png" )
	submenu:AddOption("Set as Time limit reached round end music", function()
		net.Start("wyozimc_ttt") net.WriteString(url) net.WriteString("timelimit") net.SendToServer()
	end):SetIcon( "icon16/time.png" )
	submenu:AddOption("Set as Traitor round end music", function()
		net.Start("wyozimc_ttt") net.WriteString(url) net.WriteString("traitor") net.SendToServer()
	end):SetIcon( "icon16/user_red.png" )

	submenu:AddSpacer()

	do
		local csubmenu, csmpnl = submenu:AddSubMenu("Player specific", function() end)
		csmpnl:SetIcon( "icon16/user_comment.png" )

		for _,ply in pairs(player.GetAll()) do
			local checked = tmedia and tmedia.TTTOpts and tmedia.TTTOpts[ply:SteamID()]

			local opt = csubmenu:AddOption(ply:Nick(), function()
				net.Start("wyozimc_ttt")
					net.WriteString(url)
					net.WriteString("specificsid")
					net.WriteString(ply:SteamID())
					net.WriteBit(not checked)
				net.SendToServer()
			end)
			opt:SetChecked(checked)

		end

		csubmenu:AddSpacer()

		csubmenu:AddOption("By SteamID", function()
			Derma_StringRequest( 
				"Steam ID", 
				"Please input the steam id whose specific round end song to set",
				"",
				function( text ) 
					net.Start("wyozimc_ttt")
						net.WriteString(url)
						net.WriteString("specificsid")
						net.WriteString(text)
						net.WriteBit(true)
					net.SendToServer()
				end,
				function( text ) end
			)
		end):SetIcon( "icon16/script_edit.png" )
	end
end)

local function AddToSettings(dsettings, add_to_f9)

	local prefix = add_to_f9 and "TTT: " or ""

	if not add_to_f9 then
		local dgui = vgui.Create("DForm", dsettings)
		dgui:SetName((prefix or "") .. "General settings")

		local cb = nil

		cb = dgui:NumSlider("Music volume", "wyozimc_volume", 0, 1, 2)
		if cb.Label then
			cb.Label:SetWrap(true)
		end

		dgui:CheckBox("Play music even if game is unfocused", "wyozimc_playwhenalttabbed")

		dgui:CheckBox("Enable debug mode", "wyozimc_debug")

		dgui:Button("Open WMC GUI", "wyozimc_open")
		dgui:Button("Stop music", "wyozimc_stop")

		dsettings:AddItem(dgui)

	end

	do
		local dgui = vgui.Create("DForm", dsettings)
		dgui:SetName((prefix or "") .. "Round end settings")

		local cb = nil

		dgui:CheckBox("Disable round end music", "wyozimc_noroundend")

		dgui:CheckBox("Don't play round end music, if some other music is playing", "wyozimc_noroundendifmusic")

		dgui:CheckBox("Don't play round end music, if game is unfocused (alt tabbed)", "wyozimc_noroundendifunfocused")

		dgui:CheckBox("Continue previously playing music after round end music ends", "wyozimc_contmusicafterroundend")

		dsettings:AddItem(dgui)

	end
end

hook.Add("WyoziMCAddToSettings", "WyoziMCTTTSettings", function(dsettings)
	AddToSettings(dsettings, "TTT: ")
end)

hook.Add("TTTSettingsTabs", "WyoziMCTTTSettings", function(dtabs)

	local padding = dtabs:GetPadding()

	padding = padding * 2

	local dsettings = vgui.Create("DPanelList", dtabs)
	dsettings:StretchToParent(0,0,padding,0)
	dsettings:EnableVerticalScrollbar(true)
	dsettings:SetPadding(10)
	dsettings:SetSpacing(10)

	do
		AddToSettings(dsettings)
	end

	dtabs:AddSheet("Media Player Settings", dsettings, "icon16/wrench_orange.png", false, false, "Wyozi Media Center related settings")
end)

hook.Add("WyoziMCGutter", "WMCAddTTTGutter", function(data, panel)
	if not wyozimc.IsTTT() then return end
	
	if data.TTTOpts then
		if data.TTTOpts[ROLE_TRAITOR] then
			local img = vgui.Create("DImage")
			img:SetImage( "icon16/user_red.png" )
			img:SetSize(16, 16)
			img:SetTooltip("This media will play if traitors win the round.")
			panel:AddItem(img)
			panel.GutterStr = panel.GutterStr .. "T"
		end
		if data.TTTOpts[ROLE_INNOCENT] then
			local img = vgui.Create("DImage")
			img:SetImage( "icon16/user_green.png" )
			img:SetSize(16, 16)
			img:SetTooltip("This media will play if innocents win the round.")
			panel:AddItem(img)
			panel.GutterStr = panel.GutterStr .. "I"
		end
		if data.TTTOpts[WIN_TIMELIMIT] then
			local img = vgui.Create("DImage")
			img:SetImage( "icon16/time.png" )
			img:SetSize(16, 16)
			img:SetTooltip("This media will play if time limit is reached (and innocents win).")
			panel:AddItem(img)
			panel.GutterStr = panel.GutterStr .. "T"
		end
		local allowed_sids = {}
		for k,v in pairs(data.TTTOpts) do
			if type(k) == "string" and v then
				table.insert(allowed_sids, k)
			end
		end
		if #allowed_sids > 0 then
			local img = vgui.Create("DImage")
			img:SetImage( "icon16/user_comment.png" )
			img:SetSize(16, 16)
			img:SetTooltip("This media will play for: " .. table.concat(allowed_sids, ","))
			panel:AddItem(img)
			panel.GutterStr = panel.GutterStr .. "C"
		end
	end
end)

hook.Add("WyoziMCPrePlay", "WyoziMCTTTSavePlayingMusic", function(provider, url, udata, flags)
	wyozimc.Debug("TTT Hook: ", flags, flags and bit.tohex(flags))
	if flags and bit.band(flags, wyozimc.FLAG_IS_ENDROUND) == wyozimc.FLAG_IS_ENDROUND then -- Is endround & We had something playing
		if GetConVar("wyozimc_noroundendifunfocused"):GetBool() and not system.HasFocus() then
			wyozimc.Debug("Prevented playing ", (udata and tostring(udata.Title) or ""), " due to noroundendifunfocused")
			return true
		end

		local mc = wyozimc.MainContainer 

		if mc:is_playing() then
			if GetConVar("wyozimc_noroundendifmusic"):GetBool() then
				wyozimc.Debug("Prevented playing due to noroundendifmusic")
				return true
			end
			if GetConVar("wyozimc_contmusicafterroundend"):GetBool() then
				mc.TTT_PauseData = table.Copy(mc.play_data)
				mc.TTT_PauseData.TTT_PausedAt = CurTime()
			end
		end
		-- omg what a hak
		timer.Simple(0.1, function()
			wyozimc.PlayingRoundEndMusic = true
			wyozimc.Debug("Set playing round end music to on")
		end)
	end
end)

hook.Add("WyoziMCPostStop", "WyoziMCTTTSavePlayingMusic", function()
	wyozimc.PlayingRoundEndMusic = false
	wyozimc.Debug("Set playing round end music to off")
end)

hook.Add("TTTPrepareRound", "WyoziMCTTTStopRoundEnds", function()
	if wyozimc.PlayingRoundEndMusic then
		wyozimc.PlayingRoundEnd = nil
		wyozimc.Stop()

		local mc = wyozimc.MainContainer 
		if mc.TTT_PauseData and GetConVar("wyozimc_contmusicafterroundend"):GetBool() then
			wyozimc.Debug("attempting to play last playing song ", mc.TTT_PauseData.url, " @ ", (mc.TTT_PauseData.TTT_PausedAt - mc.TTT_PauseData.started))
			mc:play_url(mc.TTT_PauseData.url, mc.TTT_PauseData.TTT_PausedAt - mc.TTT_PauseData.started)
			mc.TTT_PauseData = nil
		end
	end
end)