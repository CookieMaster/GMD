local CreateConVar = CreateConVar

local varSVHalo = CreateConVar("true_sv_halo", "1", FCVAR_REPLICATED, "Enable or disable every one of the addon's halo features.")
local varSVHaloFoV = CreateConVar("true_sv_halo_fov", "5", FCVAR_REPLICATED, "Angle distance limit from which a player will have a halo drawn around them. Set to 75 for any in default Field of View. Setting to 0 disables FoV checks, although unrecommended.")
local varSVHaloDistance = CreateConVar("true_sv_halo_distance", "200", FCVAR_REPLICATED, "Distance from a player(in ingame units) to disregard the FoV checks. Set to 0 to not override FoV checks.")
local varSVHaloDetectives = CreateConVar("true_sv_halo_detectives", "1", FCVAR_REPLICATED, "Enable or disable the feature of halos around visible detectives.")
local varSVHaloTags = CreateConVar("true_sv_halo_tags", "1", FCVAR_REPLICATED, "Enable or disable the feature of halos around tagged players who are visible.")
local varSVHaloTraitors = CreateConVar("true_sv_halo_traitors", "1", FCVAR_REPLICATED, "Enable or disable the feature of halos around traitors through walls when you're a traitor.")

if (SERVER) then return end

local CreateClientConVar = CreateClientConVar
local pairs = pairs
local player = player
local halo = halo
local math = math

local varCVHalo = CreateClientConVar( "true_cl_halo", 1, true, false )
local varCVHaloDetectives = CreateClientConVar( "true_cl_halo_detectives", 1, true, false )
local varCVHaloTags = CreateClientConVar( "true_cl_halo_tags", 1, true, false )
local varCVHaloTraitors = CreateClientConVar( "true_cl_halo_traitors", 1, true, false )

local function trueGetColor(ply)
	if (ply.sb_tag) then return ply.sb_tag.color end
	return nil
end

local function trueDetective(ply)
	if (ply["IsDetective"]) and (ply:IsDetective()) then return true else return false end
end

local function trueTraitor(ply)
	if (LocalPlayer()["IsTraitor"]) and (LocalPlayer():IsTraitor()) then
		if (ply["IsTraitor"]) and (ply:IsTraitor()) then return true else return false end
	else return false end
end

local function trueGetAngleDistance(originply, pos)
	local a = originply:GetShootPos()
	local b = a + (originply:GetAimVector() * 8192)
	local c = pos
	local sc = a:Distance(b)
	local sb = a:Distance(c)
	local sa = b:Distance(c)
	local aa = math.acos((sa * sa - sb * sb - sc * sc) / (-2 * sb * sc))
	return math.deg(aa)
end

local function truePlayerHalos()
	local bSVHalo = varSVHalo:GetBool()
	local bCVHalo = varCVHalo:GetBool()
	local iSVHaloFoV = varSVHaloFoV:GetFloat()
	local iSVHaloDist = varSVHaloDistance:GetFloat()
	local bSVHaloTraitors = varSVHaloTraitors:GetBool()
	local bCVHaloTraitors = varCVHaloTraitors:GetBool()
	local bSVHaloDetectives = varSVHaloDetectives:GetBool()
	local bCVHaloDetectives = varCVHaloDetectives:GetBool()
	local bSVHaloTags = varSVHaloTags:GetBool()
	local bCVHaloTags = varCVHaloTags:GetBool()
	if (bSVHalo == false) or (bCVHalo == false) then return end
	for k,v in pairs(player.GetAll()) do
		local bbmin,bbmax = v:WorldSpaceAABB()
		local bbmid = (bbmin+bbmax)*0.5
		local vgetpos = v:GetPos()
		local lpgetpos = LocalPlayer():GetPos()
		if ((iSVHaloFoV == 0) or (trueGetAngleDistance(LocalPlayer(), bbmid) <= iSVHaloFoV)) or ((iSVHaloDist != 0) and (lpgetpos:Distance(vgetpos) <= iSVHaloDist)) then
			if (v != LocalPlayer()) and (v:Alive() == true) and (v:Team() != TEAM_SPEC) then
				if ((bSVHaloTraitors == true) and (bCVHaloTraitors == true)) and (trueTraitor(v) == true) then
					halo.Add({v},Color(255,0,0,255),1,1,1,true,true)
				elseif ((bSVHaloDetectives == true) and (bCVHaloDetectives == true)) and (trueDetective(v) == true) then
					halo.Add({v},Color(0,0,255,255),1,1,1,true,false)
				else
					local disguised = v:GetNWBool("disguised",false)
					if ((bSVHaloTags == true) and (bCVHaloTags == true)) and !(disguised) then
						local tagcolor = trueGetColor(v)
						if (tagcolor != nil) then
							halo.Add({v},tagcolor,1,1,1,true,false)
						end
					end
				end
			end
		end
	end
end
hook.Add("PreDrawHalos","TrueTTTHalo",truePlayerHalos)