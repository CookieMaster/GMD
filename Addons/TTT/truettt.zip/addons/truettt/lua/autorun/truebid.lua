truettt = {}

local CreateConVar = CreateConVar
local util = util
local pairs = pairs
local weapons = weapons
local type = type
local table = table
local net = net
local chat = chat
local hook = hook
local Derma_StringRequest = Derma_StringRequest
local tonumber = tonumber
local math = math

local varAdvert = CreateConVar("true_sv_advert", "1", FCVAR_REPLICATED, "Enable or disable addon's advert to inform players of it's own features.")
local varAdvertRate = CreateConVar("true_sv_advert_rate", "3", FCVAR_REPLICATED, "The chance that adverts will show on clients, i.e. if this cvar is set to 3, there'd be a 1/3 chance.")
local varBidEnabled = CreateConVar("true_sv_bid", "1", FCVAR_REPLICATED, "Enable or disable bidding of the extra traitor/detective, before/after a round.")
local varBidKarmaKick = CreateConVar("true_sv_bid_karmakick", "450", FCVAR_REPLICATED, "This should be set to the karma kick amount, just in case the addon can't grab normal karma kick var.")
local varBidSafetyNet = CreateConVar("true_sv_bid_safetynet", "550", FCVAR_REPLICATED, "Least amount of karma left after bidding before the amount set for karma kick.")
local varBidDCredits = CreateConVar("true_sv_bid_credits_detective", "3", FCVAR_REPLICATED, "Amount of credits the extra detective gets on spawn.")
local varBidTCredits = CreateConVar("true_sv_bid_credits_traitor", "3", FCVAR_REPLICATED, "Amount of credits the extra traitor gets on spawn.")
local varKarmaKick = GetConVar("ttt_karma_low_amount")

local curbidt = 0 
local curbidd = 0

if (SERVER) then
	util.AddNetworkString("true_currentbidt")
	util.AddNetworkString("true_currentbidd")
	util.AddNetworkString("true_outbidt")
	util.AddNetworkString("true_outbidd")
	util.AddNetworkString("true_showteam")
	util.AddNetworkString("true_showspare2")
	util.AddNetworkString("true_sendbidtable")
	local tbid = 0
	local tbidder = nil
	local dbid = 0
	local dbidder = nil

	--local function from ttt, remade for use in TrueTTT's ForceRole function
	local ttt_loadout = nil
	local function GetLoadout(role)
		if (ttt_loadout) == nil then
		ttt_loadout = {
			[ROLE_INNOCENT] = {},
			[ROLE_TRAITOR]  = {},
			[ROLE_DETECTIVE]= {}
		}
			for k, v in pairs(weapons.GetList()) do
				if (v) and (type(v.InLoadoutFor) == "table") then
					for _, wrole in pairs(v.InLoadoutFor) do
						table.insert(ttt_loadout[wrole], WEPS.GetClass(v))
					end
				end
			end
		end
		return ttt_loadout[role]
	end
	--only call this function once the round is started, if you want to be sure, only call it in a hook for "TTTBeginRound"
	function truettt.ForceRole(ply, role, credits) --not local, so other plugins can use this if they check if it exists once
		--roles = ROLE_INNOCENT = 0, ROLE_TRAITOR = 1, ROLE_DETECTIVE = 2, ROLE_NONE = ROLE_INNOCENT
		if ply["SetRole"] then ply:SetRole(role) end
		if ply["AddCredits"] then ply:AddCredits(credits) end
		if _G["SendFullStateUpdate"] then SendFullStateUpdate() end --used in ttt, may be needed in the long run
		local defaultweaps = nil
		if ply["GetRole"] then defaultweaps = GetLoadout(ply:GetRole()) end
		if (defaultweaps == nil) then return end --failsafe in case 
		for k,v in pairs(defaultweaps) do
			if !(ply:HasWeapon(v)) then
				ply:Give(v)
			end
		end
	end
	--function that runs when a player bids for traitor
	net.Receive("true_currentbidt", 
	function(len,ply)
		local recbid = net.ReadInt(32) --4byte int
		local karmakick = (varKarmaKick and varKarmaKick:GetInt()) or (varBidKarmaKick and varBidKarmaKick:GetInt())
		local livekarma = ply:GetLiveKarma()
		local safetynet = varBidSafetyNet:GetInt()
		--by default, you'll be able to bid any karma you have over the default karma kick amount(450) + the default safety net(550)
		--meaning, by default, this addon should never make anybody's karma lower than 1000 in a vanilla ttt setting
		if ((livekarma-recbid) > (karmakick+safetynet)) then 
			if (dbidder == ply) then return chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": Cannot have winning bid for both choices at once.") end 
			if (recbid > tbid) then 
				if (tbidder != nil) and (tbidder != ply) then 
					net.Start("true_outbidt") 
					net.WriteInt(recbid,32) 
					net.Send(tbidder) 
				end
				tbid = recbid
				tbidder = ply
			end
		end
	end)
	net.Receive("true_currentbidd", 
	function(len,ply)
		local recbid = net.ReadInt(32)
		local karmakick = (varKarmaKick and varKarmaKick:GetInt()) or (varBidKarmaKick and varBidKarmaKick:GetInt())
		local livekarma = ply:GetLiveKarma()
		local safetynet = varBidSafetyNet:GetInt()
		if ((livekarma-recbid) > (karmakick+safetynet)) then
			if (tbidder == ply) then return chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": Cannot have winning bid for both choices at once.") end
			if (recbid > dbid) then 
				if (dbidder != nil) and (dbidder != ply) then
					net.Start("true_outbidd")
					net.WriteInt(recbid,32)
					net.Send(dbidder)
				end
				dbid = recbid
				dbidder = ply
			end
		end
	end)
	local function trueTTTBeginRound()
		if (tbidder != nil) then 
			truettt.ForceRole(tbidder, ROLE_TRAITOR,varBidTCredits:GetInt()) 
			tbidder:SetLiveKarma(tbidder:GetLiveKarma() - tbid)
			tbidder:SendLua("chat.AddText(Color(0,0,255), 'True', Color(255,0,0), 'TTT', Color(255,255,255), ': You have won the bid to become the extra ', Color(255,0,0), 'Traitor',Color(255,255,255), '.')")
			tbid = 0
			tbidder = nil
		end
		
		if (dbidder != nil) then 
			truettt.ForceRole(dbidder, ROLE_DETECTIVE,varBidDCredits:GetInt()) 
			dbidder:SetLiveKarma(dbidder:GetLiveKarma() - dbid)
			dbidder:SendLua("chat.AddText(Color(0,0,255), 'True', Color(255,0,0), 'TTT', Color(255,255,255), ': You have won the bid to become the extra ', Color(0,0,255), 'Detective',Color(255,255,255), '.')")
			dbid = 0
			dbidder = nil
		end
	end
	hook.Add("TTTBeginRound", "trueTTTBeginRound", trueTTTBeginRound)
	hook.Add("ShowTeam", "trueShowTeam",
	function(ply)
		net.Start("true_showteam")
		net.Send(ply)
	end)
	hook.Add("ShowSpare2", "trueShowSpare2",
	function(ply)
		net.Start("true_showspare2")
		net.Send(ply)
	end)
	hook.Add("Think", "trueThink",
	function()
		local trueBids = {}
		trueBids.traitorbid = tbid
		trueBids.detectivebid = dbid
		net.Start("true_sendbidtable")
		net.WriteTable(trueBids)
		net.Send(player.GetAll())
	end)
end

if (CLIENT) then
	net.Receive("true_outbidt", 
	function() 
		local outbid = net.ReadInt(32)
		chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": You have been outbid on ", Color(255,0,0), "Traitor", Color(255,255,255), " for "..outbid.." karma.")
	end)
	net.Receive("true_outbidd", 
	function() 
		local outbid = net.ReadInt(32)
		chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": You have been outbid on ", Color(0,0,255), "Detective", Color(255,255,255), " for "..outbid.." karma.")
	end)
	net.Receive("true_sendbidtable",
	function()
		local recvtable = net.ReadTable()
		curbidd = recvtable.detectivebid
		curbidt = recvtable.traitorbid
	end)
	net.Receive("true_showteam",
	function()
		local karmakick = (varKarmaKick and varKarmaKick:GetInt()) or (varBidKarmaKick and varBidKarmaKick:GetInt())
		local basekarma = (LocalPlayer()["GetBaseKarma"] and LocalPlayer():GetBaseKarma())
		local safetynet = varBidSafetyNet:GetInt()
		if (varBidEnabled:GetBool() != true) then return chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": Bidding is disabled.") end
		if (LocalPlayer():Team() == TEAM_SPEC) then return chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": You cannot bid in spectate.") end
		if (GAMEMODE.round_state == ROUND_ACTIVE) then return chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": Must bid during pre/post roundstart.") end
		Derma_StringRequest(
		"Bid for Traitor",
		"Current highest bid is: "..curbidt..", what will you bid?",
		"",
		function(text)
			local bid = tonumber(text)
			if (bid == nil) or (bid == "") or (bid <= 0) then return chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": Please input an amount of karma to bid.") end
			if ((basekarma-bid) < (karmakick+safetynet)) then return chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": Bid denied, as bidding this low will put you under 1000 karma.") end
			if (bid <= curbidt) then return chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": Bid denied, as your bid must be higher than the current bid: "..curbidt) end
			net.Start("true_currentbidt")
			net.WriteInt(bid,32)
			chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": You've just bid on ", Color(255,0,0), "Traitor", Color(255,255,255), " for "..bid.." karma.")
			net.SendToServer()
		end,
		function()
		
		end)
	end)
	net.Receive("true_showspare2",
	function()
		local karmakick = (varKarmaKick and varKarmaKick:GetInt()) or (varBidKarmaKick and varBidKarmaKick:GetInt())
		local basekarma = (LocalPlayer()["GetBaseKarma"] and LocalPlayer():GetBaseKarma())
		local safetynet = varBidSafetyNet:GetInt()
		if (varBidEnabled:GetBool() != true) then return chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": Bidding is disabled.") end
		if (LocalPlayer():Team() == TEAM_SPEC) then return chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": You cannot bid in spectate.") end
		if (GAMEMODE.round_state == ROUND_ACTIVE) then return chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": Must bid during pre/post roundstart.") end
		Derma_StringRequest(
		"Bid for Detective",
		"Current highest bid is: "..curbidd..", what will you bid?",
		"",
		function(text)
			local bid = tonumber(text)
			if (bid == nil) or (bid == "") or (bid <= 0) then return chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": Please input an amount of karma to bid.") end
			if ((basekarma-bid) < (karmakick+safetynet)) then return chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": Bid denied, as bidding this low will put you under 1000 karma.") end
			if (bid <= curbidt) then return chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": Bid denied, as your bid must be higher than the current bid: "..curbidd) end
			net.Start("true_currentbidd")
			net.WriteInt(bid,32)
			chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": You've just bid on ", Color(0,0,255), "Detective", Color(255,255,255), " for "..bid.." karma.")
			net.SendToServer()
		end,
		function()
		
		end)
	end)
	hook.Add("TTTEndRound", "trueTTTEndRound", function() 
		if (varAdvert:GetBool() == true) then
			local chance = math.random(varAdvertRate:GetInt())
			if (chance == 1) then 
				chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": Use f2/f4 or bind a key to gm_showteam/gm_showspare2 to bid on the extra detective/traitor of next round during pre/post round.")
			end
		end
	end)
	hook.Add("TTTBeginRound", "trueTTTBeginRoundClientside", function()
		if (varAdvert:GetBool() == true) then
			local chance = math.random(varAdvertRate:GetInt())
			if (chance == 1) then
				chat.AddText(Color(0,0,255), "True", Color(255,0,0), "TTT", Color(255,255,255), ": Tagging people in the scoreboard gives them a visible glow.")
			end
		end
	end)
end