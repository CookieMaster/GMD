util.AddNetworkString("UpdateTraitorKills")

local TraitorKills = {}

local function SendTraitorKills(plys)
	net.Start("UpdateTraitorKills")
		net.WriteTable(TraitorKills)
	net.Send(plys)
end

local function GetTraitors()
	local traitors = {}
	for _,v in pairs(player.GetAll()) do
		if v:IsTraitor() then table.insert(traitors, v) end
	end
	return traitors
end

hook.Add("PlayerDeath", "CountTraitorKill", function(vic, inf, killer)
	if GetRoundState() != ROUND_ACTIVE then return end
	
	if vic:IsPlayer() and killer:IsPlayer() and not vic:IsTraitor() and killer:IsTraitor() then
		local kills = TraitorKills[killer:SteamID()]
		kills = (kills != nil) and (kills + 1) or (1)
		TraitorKills[killer:SteamID()] = kills
		
		SendTraitorKills(GetTraitors())
	end
end)

hook.Add("TTTEndRound", "BroadcastTraitorKills", function()
	if TRAITORKILLS_BROADCASTONROUNDEND then
		SendTraitorKills(player.GetAll())
	end
	table.Empty(TraitorKills)
end)