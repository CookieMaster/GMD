if SERVER then
	AddCSLuaFile()
	
	--Send the traitor kills to all players on round end? (default: true)
	TRAITORKILLS_BROADCASTONROUNDEND = true
else
	--The colour of the kills text on the scoreboard (default: Color(255,255,255,150))
	TRAITORKILLS_COLOR = Color(255,255,255,150)
	
	--The format of the text, where %i is kills (default: "[Kills: %i]")
	TRAITORKILLS_FORMAT = "[Kills: %i]"
	
	--The font used for the kills label (default: font = DefaultBold, size = 12, weight = 750)
	surface.CreateFont("Kills", 
								{ font = "DefaultBold",
								size = 12,
								weight = 750})
end