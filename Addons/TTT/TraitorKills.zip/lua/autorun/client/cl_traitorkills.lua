TraitorKills = {}

net.Receive("UpdateTraitorKills", function()
	TraitorKills = net.ReadTable()
end)

hook.Add("TTTPrepareRound", "ClearTraitorKills", function()
	table.Empty(TraitorKills)
end)