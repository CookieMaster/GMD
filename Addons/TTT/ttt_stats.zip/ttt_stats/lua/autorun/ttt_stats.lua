TTTStats = {}
TTTStats.ChatTime = 0

--CONFIG SETTINGS--

TTTStats.StatsKey = "F2" -- Use whatever key you please (Best to use F1-F4) or none to assign a key for triggering the Stats Menu
TTTStats.ChatReminder = true -- Use false/true to toggle the chat reminder for the chat function (every X minutes it will say in the chat that you can use !stats to trigger it)
TTTStats.ChatReminderTime = 3 -- Minutes for each chat reminder

--CONFIG SETTINGS--


if SERVER then

	AddCSLuaFile()
	
	util.AddNetworkString("tttstats")
	
	local ply = FindMetaTable("Player")
	
	local testtab = {}
	testtab["Name"] = ""
	testtab["FirstJoin"] = ""
	testtab["Kills"] = 0
	testtab["Deaths"] = 0
	testtab["Rounds"] = 0
	testtab["Karma"] = 1000
	testtab["Innocent"] = 0
	testtab["Traitor"] = 0
	testtab["Detective"] = 0
	testtab["TKilled"] = 0
	testtab["DKilled"] = 0
	testtab["IKilled"] = 0
	testtab["TRound"] = 0

	function ply:UpdateStats( kill, dead, round, karma, inno, traitor, det, tkill, dkill, ikill, tround )	
		local tab = self:GetStats()
		
		tab["Name"] = self:GetName()
		tab["Kills"] = tab["Kills"] + (kill or 0)
		tab["Deaths"] = tab["Deaths"] + (dead or 0)
		tab["Rounds"] = tab["Rounds"] + (round or 0)
		tab["Karma"] = tab["Karma"] + (karma or 0)
		tab["Innocent"] = tab["Innocent"] + (inno or 0)
		tab["Traitor"] = tab["Traitor"] + (traitor or 0)
		tab["Detective"] = tab["Detective"] + (det or 0)
		tab["TKilled"] = tab["TKilled"] + (tkill or 0)
		tab["DKilled"] = tab["DKilled"] + (dkill or 0)
		tab["IKilled"] = tab["IKilled"] + (ikill or 0)
		if tround then tab["TRound"] = tround end

		self:SetStats(tab)
	end

	function ply:SetStats( tab )
		
		//FOLDER CHECK
		local there = file.Exists("tttstats", "DATA")
		if !there then file.CreateDir( "tttstats" )  end
		
		file.Write("tttstats/"..self:UniqueID()..".txt", util.TableToJSON(tab) )
		
	end

	function ply:GetStats()
		local read = file.Read("tttstats/"..self:UniqueID()..".txt","DATA")
		
		if read == nil or read == "" then 
			
			testtab["FirstJoin"] = os.date()
			testtab["Name"] = self:GetName()
			self:SetStats( testtab )
			
			return testtab 
		end
		
		return util.JSONToTable( read )
		
	end

	hook.Add("TTTEndRound", "ttt_stats", function( win )
		for k, v in pairs(player.GetAll()) do
			if !v:IsBot() then
				
				local inno, tr, det, tround, bestround
				
				if v:GetRole() == 0 then
					inno = 1
				elseif v:GetRole() == 1 then
					tr = 1
				elseif v:GetRole() == 2 then
					det = 1
				end
				
				local tround = v:GetStats()["TRound"] or 0
				local bestround = v:GetNWInt("TraitorKills")
				local dead = v:GetNWInt("STATS_Death")
				local kill = v:GetNWInt("STATS_Kills")
				local tkill = v:GetNWInt("STATS_TKilled")
				local dkill = v:GetNWInt("STATS_DKilled")
				local ikill = v:GetNWInt("STATS_IKilled")
				
				if bestround > tround then
					tround = bestround
				end
				
				v:UpdateStats( kill, dead, 1, v:GetBaseKarma(), inno, tr, det, tkill, dkill, ikill, tround )
				v:SetNWInt("TraitorKills", 0)
				v:SetNWInt("STATS_Death", 0)
				v:SetNWInt("STATS_Kills", 0)
				v:SetNWInt("STATS_TKilled", 0)
				v:SetNWInt("STATS_DKilled", 0)
				v:SetNWInt("STATS_IKilled", 0)
			end
		end
	end)
	
	hook.Add("PlayerDeath", "ttt_stats_death", function( vic, wep, kil )
		
		if vic:IsPlayer() and !vic:IsBot() then
			vic:SetNWInt("STATS_DEATH", vic:GetNWInt("STATS_DEATH") + 1)
		end
		
		if kil:IsPlayer() and !kil:IsBot() then
			if kil:GetRole() == ROLE_TRAITOR and vic:GetRole() == ROLE_DETECTIVE then
				kil:SetNWInt("TraitorKills", kil:GetNWInt("TraitorKills") + 1)
				kil:SetNWInt("STATS_DKilled", kil:GetNWInt("STATS_DKilled") + 1)
			elseif kil:GetRole() == ROLE_TRAITOR and vic:GetRole() == ROLE_INNOCENT then
				kil:SetNWInt("TraitorKills", kil:GetNWInt("TraitorKills") + 1)
				kil:SetNWInt("STATS_IKilled", kil:GetNWInt("STATS_IKilled") + 1)
			elseif (kil:GetRole() == ROLE_INNOCENT or kil:GetRole() == ROLE_DETECTIVE) and vic:GetRole() == ROLE_TRAITOR then
				kil:SetNWInt("STATS_TKilled", kil:GetNWInt("STATS_TKilled") + 1)
			end
			kil:SetNWInt("STATS_Kills", kil:GetNWInt("STATS_Kills") + 1)
		end
	end)
	
	hook.Add("PlayerInitialSpawn", "ttt_stats_init", function( ply )
		ply:GetStats()
	end)
	
	local cc = 200
	local TimerDelay = 0.5
	
	local TriggerFunc = "ShowSpare2"
	
	local TF = {}
	TF["F1"] = "ShowHelp"
	TF["F2"] = "ShowTeam"
	TF["F3"] = "ShowSpare1"
	TF["F4"] = "ShowSpare2"
	
	if TTTStats and TTTStats.StatsKey and TF and TF[TTTStats.StatsKey] then TriggerFunc = TF[TTTStats.StatsKey] end
	
	function OpenMenu( ply, ply2 )
		if ply.StatCheck == nil or CurTime() > ply.StatCheck then
			
			local files = file.Find( "tttstats/*", "DATA")
			local count = table.Count(files)		
			
			for k, v in pairs(player.GetAll()) do
				v:GetStats()
			end
			
			net.Start( "tttstats" )
				net.WriteString("STARTDATA;"..math.ceil(count/cc))
				net.WriteString( tostring(ply2 and ply2:EntIndex() or 0) )
			net.Send( ply )
			
			timer.Create( "TTTStats_"..ply:SteamID(), TimerDelay, math.ceil(count/cc), function ()
				
				local i = 0
				local tab = {}
				
				for k, v in pairs(files) do
					if i >= cc then break end
					i = i + 1
					
					local f = file.Read("tttstats/"..v, "DATA")
					tab[string.Left( v, string.len(v)-4 )] = f != nil and f != "" and util.JSONToTable(f) or testtab
					files[k] = nil
				end
					
				net.Start( "tttstats" )
					net.WriteString("")
					net.WriteTable(tab)
				net.Send( ply )
					
				count = count - cc
			end)
			ply.StatCheck = CurTime() + math.min( (math.ceil(count/cc) * TimerDelay), 2 )
		end
	end
	
	hook.Add("PlayerSay", "ttt_stats_say", function( ply, text, public )
		local exp = string.Explode(" ", string.Trim(text))
		if exp[1] == "!stats" then
		
			exp[1] = ""
			
			local name = string.Trim(string.Implode(" ", exp))
			local ply2 = nil
			
			if name != nil and name != "" then
				for k, v in pairs(player.GetAll()) do
					if v:GetName() == name then
						ply2 = v
						break
					end
				end
			end
			
			if name != nil and name != "" and ply2 == nil then
				for k, v in pairs(player.GetAll()) do
					if string.find(string.lower(v:GetName()), string.lower(name)) then
						ply2 = v
						break
					end
				end
			end
			
			OpenMenu(ply, ply2)	
			return ""
		end
	end)
	
	net.Receive("tttstats", function( len, ply )
		timer.Destroy("TTTStats_"..ply:SteamID())
		OpenMenu(ply)
	end)
	
else
	
	TTTRankList = {}
	TTTStatsMenu = nil
	
	local tcol, icol, dcol, txcol, bcol = Color( 175, 20, 20, 255 ), Color( 20, 175, 20, 255 ), Color( 20, 20, 175, 255 ), Color( 240, 240, 240, 200 ), Color( 0, 0, 0, 240 )
	
	surface.CreateFont( "CloseCaption_Bold", { font = "Tahoma", size = 16, weight = 600 } )
	surface.CreateFont( "CloseCaption_Bold2", { font = "Tahoma", size = 36, weight = 600 } )
	surface.CreateFont( "CloseCaption_Bold3", { font = "Tahoma", size = 24, weight = 600 } )
	
	
	function BuildStatsMenu( ply )
		TTTStatsMenu = vgui.Create( "DFrame" )
		TTTStatsMenu:SetSize( 400, 640 )
		TTTStatsMenu:Center()
		TTTStatsMenu:SetTitle( "TTT Player Stats" )
		TTTStatsMenu:SetVisible( true )
		TTTStatsMenu:SetDraggable( false )
		TTTStatsMenu:ShowCloseButton( true )
		TTTStatsMenu:MakePopup()
		TTTStatsMenu.Paint = function()
			draw.RoundedBox(0, 0, 0, 400, 23, bcol) 
		end
		
		TTTStatsMenu.MyInfoPanel = vgui.Create( "DPanel", TTTStatsMenu )
		TTTStatsMenu.MyInfoPanel:SetPos(0,28)
		TTTStatsMenu.MyInfoPanel:SetSize(400, 615)
		TTTStatsMenu.MyInfoPanel.Info = {}
		TTTStatsMenu.MyInfoPanel.Update = function( s )
			local bestT = {0, "Nobody"}
			local bestD = {0, "Nobody"}
			
			for k, v in pairs(TTTRankList) do
				
				if (v.IKilled + v.DKilled) > bestT[1] then bestT = {(v.IKilled + v.DKilled), v.Name} end
				if v.TKilled > bestD[1] then bestD = {v.TKilled, v.Name} end
				
			end
			
			TTTStatsMenu.Best = {bestT, bestD}
			
			for k, v in pairs(TTTStatsMenu.Pages.Items) do
				v:Remove()
			end
			
			for i = 1, math.ceil(table.Count(TTTRankList)/20) do
				local but = vgui.Create("DButton")
				but:SetSize(30, 30)
				but:SetText( i )
				but.DoClick = function( s )
					TTTStatsMenu.Leaderboard:BuildPage(i)
				end
				TTTStatsMenu.Pages:AddItem(but)
			end
			
			TTTStatsMenu.Leaderboard:Resort("Kills")
			
		end
		TTTStatsMenu.MyInfoPanel.Paint = function() end
		
		local NamePanel = vgui.Create( "DPanel", TTTStatsMenu.MyInfoPanel )
		NamePanel:SetPos(0,0)
		NamePanel:SetSize(400, 84)
		NamePanel.Paint = function(s, w, h)
			draw.RoundedBox(0, 0, 0, w, h, bcol)
			local name = TTTStatsMenu.MyInfoPanel.Info.Name or ""
			if !TTTStatsMenu.GotInfo then name = "GETTING INFO..." end
			draw.SimpleText(name, "CloseCaption_Bold2", 84, 10, txcol, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
			draw.SimpleText(TTTStatsMenu.MyInfoPanel.Info.FirstJoin and "First joined: "..TTTStatsMenu.MyInfoPanel.Info.FirstJoin or "", "CloseCaption_Bold", 84, 64, txcol, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) 
		end
		
		local Avatar = vgui.Create( "AvatarImage", NamePanel )
		Avatar:SetSize( 64, 64 )
		Avatar:SetPos( 10, 10 )
		Avatar:SetPlayer( ply, 64 )
		
		local KarmaPanel = vgui.Create( "DPanel", TTTStatsMenu.MyInfoPanel )
		KarmaPanel:SetPos(0,89)
		KarmaPanel:SetSize(400, 155)
		KarmaPanel.Paint = function(s, w, h)
			draw.RoundedBox(0, 0, 0, w, h, bcol)
			draw.RoundedBoxEx(0, 10, 10, 50, 20, icol, true, true, false, false)
			draw.RoundedBoxEx(0, 10, 125, 50, 20, tcol, false, false, true, true)
			
			local pan = TTTStatsMenu.MyInfoPanel.Info
			
			for i = 1, 9 do
				local wid = i % 2
				local col = Color( icol.r * (9-i)/9 + tcol.r * i/9, icol.g * (9-i)/9 + tcol.g * i/9, icol.b * (9-i)/9 + tcol.b * i/9, icol.a * (9-i)/9 + tcol.a * i/9 )
				draw.RoundedBoxEx(0, 20 - 10 * wid, 35 + (i-1) * 10, 30 + 20 * wid, 5, col)
			end
			
			local karma = math.Clamp((pan.Karma and pan.Rounds and pan.Karma/pan.Rounds or 1000), 0, 1000)
			draw.RoundedBox(0, 65, 125 - karma/10, 50, 5, txcol)
			draw.SimpleText("Average Karma: ", "CloseCaption_Bold", 70, 10-4, txcol, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
			draw.SimpleText(math.Round(karma), "CloseCaption_Bold", 120, 125 - karma/10 + 2, txcol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			
			local rounds = pan.Rounds or 0
			draw.SimpleText("Number of Rounds: "..rounds, "CloseCaption_Bold", w - 10, 10-4, txcol, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM)
			
			local isize = 64
			
			draw.RoundedBox(0, w - (10 + isize), 40, isize, isize, icol)
			draw.RoundedBox(0, w - (10 + isize) * 2, 40, isize, isize, tcol)
			draw.RoundedBox(0, w - (10 + isize) * 3, 40, isize, isize, dcol)
			
			draw.SimpleText("I", "CloseCaption_Bold2", w - (10 + isize) + isize/2, 40 + isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("T", "CloseCaption_Bold2", w - (10 + isize)*2 + isize/2, 40 + isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("D", "CloseCaption_Bold2", w - (10 + isize)*3 + isize/2, 40 + isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			local i, t, d = pan.Innocent or 0, pan.Traitor or 0, pan.Detective or 0
			
			if rounds == 0 then rounds = 1 end
			
			draw.SimpleText(string.Left( (i/rounds) * 100, 5 ).."%", "CloseCaption_Bold", w - (10 + isize) + isize/2, 50 + isize, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
			draw.SimpleText(string.Left( (t/rounds) * 100, 5 ).."%", "CloseCaption_Bold", w - (10 + isize)*2 + isize/2, 50 + isize, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
			draw.SimpleText(string.Left( (d/rounds) * 100, 5 ).."%", "CloseCaption_Bold", w - (10 + isize)*3 + isize/2, 50 + isize, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
		end
		
		local KillPanel = vgui.Create( "DPanel", TTTStatsMenu.MyInfoPanel )
		KillPanel:SetPos(0,250)
		KillPanel:SetSize(400, 363)
		KillPanel.Paint = function(s, w, h)
			draw.RoundedBox(0, 0, 0, w, h, bcol)
			
			local pan = TTTStatsMenu.MyInfoPanel.Info
			local isize = 64
			
			draw.RoundedBox(0, w/4 - isize/2, 40, isize, isize, tcol)
			draw.RoundedBox(0, w * 3/4 - 69, 40, isize, isize, icol)
			draw.RoundedBox(0, w * 3/4 + 5, 40, isize, isize, dcol)
			
			draw.RoundedBox(0, w/4 - 2, 104, 4, 13, txcol)
			draw.RoundedBox(0, w/4 - 39, 117, 78, 4, txcol)
			draw.RoundedBox(0, w/4 - 39, 121, 4, 13, txcol)
			draw.RoundedBox(0, w/4 + 35, 121, 4, 13, txcol)
			
			draw.SimpleText("T", "CloseCaption_Bold2", w/4, 40 + isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("I", "CloseCaption_Bold2", w * 3/4 - 5 - 32, 40 + isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("D", "CloseCaption_Bold2", w * 3/4 + 5 + 32, 40 + isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			draw.RoundedBox(0, w * 3/4 - isize/2, 134, isize, isize, tcol)
			draw.RoundedBox(0, w * 1/4 - 69, 134, isize, isize, icol)
			draw.RoundedBox(0, w * 1/4 + 5, 134, isize, isize, dcol)
			
			draw.RoundedBox(0, w * 3/4 - 2, 121, 4, 13, txcol)
			draw.RoundedBox(0, w * 3/4 - 39, 117, 78, 4, txcol)
			draw.RoundedBox(0, w * 3/4 - 39, 104, 4, 13, txcol)
			draw.RoundedBox(0, w * 3/4 + 35, 104, 4, 13, txcol)
			
			draw.SimpleText("T", "CloseCaption_Bold2", w * 3/4, 134 + isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("I", "CloseCaption_Bold2", w * 1/4 - 5 - 32, 134 + isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("D", "CloseCaption_Bold2", w * 1/4 + 5 + 32, 134 + isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			local i, t, d, best, kill, dead = pan.IKilled or 0, pan.TKilled or 0, pan.DKilled or 0, pan.TRound or 0, pan.Kills or 0, pan.Deaths or 0
			
			draw.SimpleText("Kills as Traitor:", "CloseCaption_Bold", w/4, 30, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
			draw.SimpleText("Kills as Innocent/Detective:", "CloseCaption_Bold", w * 3/4, 30, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
			draw.SimpleText(i, "CloseCaption_Bold", w/4 - isize/2 - 5, 203, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
			draw.SimpleText(d, "CloseCaption_Bold", w/4 + isize/2 + 5, 203, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
			draw.SimpleText(t, "CloseCaption_Bold", w * 3/4, 203, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
			
			local dead2 = dead
			
			if dead2 == 0 then dead2 = 1 end
			
			draw.SimpleText("Best round as Traitor:", "CloseCaption_Bold", w/4, 243, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("K/D Ratio: "..string.Left( (kill/dead2), 5 ), "CloseCaption_Bold", w * 3/4, 243, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			draw.RoundedBox(0, w * 1/4 - isize/2, h-40-isize, isize, isize, tcol)
			draw.RoundedBox(0, w * 3/4 - 69, h-40-isize, isize, isize, icol)
			draw.RoundedBox(0, w * 3/4 + 5, h-40-isize, isize, isize, dcol)
			
			draw.SimpleText(best, "CloseCaption_Bold2", w/4, h-40-isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(dead, "CloseCaption_Bold2", w * 3/4 + 37, h-40-isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(kill, "CloseCaption_Bold2", w * 3/4 - 37, h-40-isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			draw.SimpleText("Kills", "CloseCaption_Bold", w/4,  h-35, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
			draw.SimpleText("Kills", "CloseCaption_Bold", w * 3/4 - isize/2 - 5,  h-35, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
			draw.SimpleText("Deaths", "CloseCaption_Bold", w * 3/4 + isize/2 + 5,  h-35, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
		end
		
		TTTStatsMenu.PlayerInfoPanel = vgui.Create( "DPanel", TTTStatsMenu )
		TTTStatsMenu.PlayerInfoPanel:SetPos(0,28)
		TTTStatsMenu.PlayerInfoPanel:SetSize(400, 615)
		TTTStatsMenu.PlayerInfoPanel.Paint = function() end
		
		local Best = vgui.Create( "DPanel", TTTStatsMenu.PlayerInfoPanel )
		Best:SetPos(0,0)
		Best:SetSize(400, 164)
		Best.Paint = function(s, w, h)
			draw.RoundedBox(0, 0, 0, w, h, bcol)
			
			if TTTStatsMenu.Best then
			
				local isize = 64
				draw.RoundedBox(0, 10, 10, isize, isize, tcol)
				draw.SimpleText("T", "CloseCaption_Bold2", 10 + isize/2, 10 + isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				
				draw.SimpleText(TTTStatsMenu.GotInfo and (TTTStatsMenu.Best[1][2] or "") or "GETTING INFO...", "CloseCaption_Bold2", 84, 10, txcol, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
				draw.SimpleText("Best Traitor, standing at: "..TTTStatsMenu.Best[1][1].." kills.", "CloseCaption_Bold", 84, 64, txcol, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) 
				
				draw.RoundedBoxEx(0, 10, 90, isize/2, isize, icol,true,false,true,false)
				draw.RoundedBoxEx(0, 10+isize/2, 90, isize/2, isize, dcol,false,true,false,true)
				draw.SimpleText("I", "CloseCaption_Bold2", 10 + isize/4, 90 + isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
				draw.SimpleText("D", "CloseCaption_Bold2", 10 + isize * 3/4, 90 + isize/2, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
				draw.SimpleText(TTTStatsMenu.GotInfo and (TTTStatsMenu.Best[2][2] or "") or "GETTING INFO...", "CloseCaption_Bold2", 84, 90, txcol, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
				draw.SimpleText("Best investigator, standing at: "..TTTStatsMenu.Best[2][1].." kills.", "CloseCaption_Bold", 84, 144, txcol, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP) 
			
			end
		end
		
		TTTStatsMenu.Leaderboard = vgui.Create( "DListView", TTTStatsMenu.PlayerInfoPanel )
		TTTStatsMenu.Leaderboard:SetPos( 0, 94 + 84 + 78)
		TTTStatsMenu.Leaderboard:SetSize( 400, 356 )
		TTTStatsMenu.Leaderboard.Rank = 0
		TTTStatsMenu.Leaderboard.SortBy = "Kills"
		TTTStatsMenu.Leaderboard.WorkTab = {}
		TTTStatsMenu.Leaderboard.RankIt = function( s )
			s.Rank = 0
			
			for k, v in pairs(s.WorkTab) do
				if v.UniqueID == ply:UniqueID() then s.Rank = k break end
			end
		end
		TTTStatsMenu.Leaderboard.BuildPage = function( s, page )
			TTTStatsMenu.Leaderboard:Clear()
			local i = 0
			for k, v in pairs(s.WorkTab) do
				i = i + 1
				if i <= (page-1) * 20 then continue end
				if i > page * 20 then break end
				TTTStatsMenu.Leaderboard:AddLine( i, v.Name, v.Kills, v.Deaths, v.TKilled, v.IDKilled, v.Traitor, v.Detective, v.Innocent )
			end
		end
		TTTStatsMenu.Leaderboard.Resort = function(s, name, des)
			local tab = {}
			
			s.Rank = 0
			
			for k, v in pairs(TTTRankList) do
				v["UniqueID"] = k
				v["IDKilled"] = v["IKilled"] + v["DKilled"]
				table.insert(tab, v)
			end
			
			if name != "Name" then
				table.SortByMember(tab, name)
			else
				table.SortByMember(tab, name, function(a, b) if des then return a < b end return a > b end)
			end
			
			s.WorkTab = tab
			
			s:RankIt()
			s:BuildPage(1)
		end
		TTTStatsMenu.Leaderboard:SetMultiSelect( false )
		
		local RankTab = TTTStatsMenu.Leaderboard:AddColumn( "Rank" )
		local NameTab = TTTStatsMenu.Leaderboard:AddColumn( "Name" )
		local KillTab = TTTStatsMenu.Leaderboard:AddColumn( "Kills" )
		local DeadTab = TTTStatsMenu.Leaderboard:AddColumn( "Deaths" )
		local TKTab = TTTStatsMenu.Leaderboard:AddColumn( "T Kills" )
		local IDTab = TTTStatsMenu.Leaderboard:AddColumn( "I/D Kills" )
		local TTab = TTTStatsMenu.Leaderboard:AddColumn( "T" )
		local DTab = TTTStatsMenu.Leaderboard:AddColumn( "D" )
		local ITab = TTTStatsMenu.Leaderboard:AddColumn( "I" )
		
		RankTab:SetWidth(30)
		RankTab.DoClick = function(s) end
		NameTab:SetWidth(90)
		NameTab.DoClick = function(s) end
		KillTab:SetWidth(40)
		KillTab.DoClick = function(s) TTTStatsMenu.Leaderboard:Resort("Kills", true) TTTStatsMenu.Leaderboard.SortBy = "Kills" end
		DeadTab:SetWidth(40)
		DeadTab.DoClick = function(s) TTTStatsMenu.Leaderboard:Resort("Deaths", true) TTTStatsMenu.Leaderboard.SortBy = "Deaths" end
		TKTab:SetWidth(40)
		TKTab.DoClick = function(s) TTTStatsMenu.Leaderboard:Resort("TKilled", true) TTTStatsMenu.Leaderboard.SortBy = "T Killed" end
		IDTab:SetWidth(40)
		IDTab.DoClick = function(s) TTTStatsMenu.Leaderboard:Resort("IDKilled", true) TTTStatsMenu.Leaderboard.SortBy = "I/D Killed" end
		TTab:SetWidth(40)
		TTab.DoClick = function(s) TTTStatsMenu.Leaderboard:Resort("Traitor", true) TTTStatsMenu.Leaderboard.SortBy = "Traitor" end
		DTab:SetWidth(40)
		DTab.DoClick = function(s) TTTStatsMenu.Leaderboard:Resort("Detective", true) TTTStatsMenu.Leaderboard.SortBy = "Detective" end
		ITab:SetWidth(40)
		ITab.DoClick = function(s) TTTStatsMenu.Leaderboard:Resort("Innocent", true) TTTStatsMenu.Leaderboard.SortBy = "Innocent" end
		
		local Sort = vgui.Create( "DPanel", TTTStatsMenu.PlayerInfoPanel )
		Sort:SetPos(0,168)
		Sort:SetSize(400, 90)
		Sort.Paint = function(s, w, h)
			draw.RoundedBoxEx(0, 0, 0, w, h, bcol,true,true,false,false)
			
			draw.SimpleText("Sorted by:", "CloseCaption_Bold3", 100, 15, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(TTTStatsMenu.Leaderboard.SortBy, "CloseCaption_Bold3", 100, 45, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			
			draw.SimpleText("Your rank:", "CloseCaption_Bold3", 300, 15, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("#"..TTTStatsMenu.Leaderboard.Rank, "CloseCaption_Bold3", 300, 45, txcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		
		TTTStatsMenu.Pages = vgui.Create("DPanelList", Sort)
		TTTStatsMenu.Pages:SetSize( 300, 30 )
		TTTStatsMenu.Pages:SetPos( 50, 60 )
		TTTStatsMenu.Pages:EnableHorizontal(true)
		TTTStatsMenu.Pages:EnableVerticalScrollbar(true)
		TTTStatsMenu.Pages.PerformLayout = function(self)

			local Wide = self:GetWide()
			local YPos = 0
			
			if ( !self.Rebuild ) then
				debug.Trace()
			end
			
			self:Rebuild()
			
			if ( self.VBar && !m_bSizeToContents ) then

				self.VBar:SetPos( self:GetWide(), 0 )
				self.VBar:SetSize( 10, self:GetTall() )
				self.VBar:SetUp( self:GetTall(), self.pnlCanvas:GetTall() )
				YPos = self.VBar:GetOffset()
				
				if ( self.VBar.Enabled ) then Wide = Wide end

			end

			self.pnlCanvas:SetPos( 0, YPos )
			self.pnlCanvas:SetWide( Wide )
			
			self:Rebuild()
			
			if ( self:GetAutoSize() ) then
			
				self:SetTall( self.pnlCanvas:GetTall() )
				self.pnlCanvas:SetPos( 0, 0 )
			
			end	

		end
		TTTStatsMenu.Pages.VBar.AddScroll = function( s, dlta )

			local OldScroll = s:GetScroll()

			dlta = dlta * 15
			s:SetScroll( s:GetScroll() + dlta )
			
			return OldScroll == s:GetScroll()
			
		end
		
		local ButLeft = vgui.Create("DButton", Sort)
		ButLeft:SetSize(40, 30)
		ButLeft:SetPos(0, 60)
		ButLeft:SetText("<")
		ButLeft.DoClick = function( s )
			TTTStatsMenu.Pages.VBar:AddScroll( -2 )
		end
		
		local ButRight = vgui.Create("DButton", Sort)
		ButRight:SetSize(40, 30)
		ButRight:SetPos(360, 60)
		ButRight:SetText(">")
		ButRight.DoClick = function( s )
			TTTStatsMenu.Pages.VBar:AddScroll( 2 )
		end
		
		
		for i = 1, math.ceil(table.Count(TTTRankList)/20) do
			local but = vgui.Create("DButton")
			but:SetSize(30, 30)
			but:SetText( i )
			but.DoClick = function( s )
				TTTStatsMenu.Leaderboard:BuildPage(i)
			end
			TTTStatsMenu.Pages:AddItem(but)
		end
		
		TTTStatsMenu.PlayerInfoPanel:SetVisible(false)
		
		local Switch = vgui.Create( "DButton", TTTStatsMenu )
		Switch:SetPos( 100, 2 )
		Switch:SetText( "Leaderboards" )
		Switch:SetSize( 120, 20 )
		Switch.State = 0
		Switch.States = 2
		Switch.DoClick = function(s)
			s.State = (s.State + 1) % s.States
			if s.State == 0 then
				TTTStatsMenu.MyInfoPanel:SetVisible(true)
				TTTStatsMenu.PlayerInfoPanel:SetVisible(false)
				s:SetText( "Leaderboards" )
			elseif s.State == 1 then
				TTTStatsMenu.MyInfoPanel:SetVisible(false)
				TTTStatsMenu.PlayerInfoPanel:SetVisible(true)
				
				local bestT = {0, "Nobody"}
				local bestD = {0, "Nobody"}
				
				for k, v in pairs(TTTRankList) do
					
					if (v.IKilled + v.DKilled) > bestT[1] then bestT = {(v.IKilled + v.DKilled), v.Name} end
					if v.TKilled > bestD[1] then bestD = {v.TKilled, v.Name} end
					
				end
				
				TTTStatsMenu.Best = {bestT, bestD}
				
				TTTStatsMenu.Leaderboard:Resort("Kills")
				
				s:SetText( "My Info" )
			end
		end
		
	end
	
	local function UpdateStatsMenu(tab)
		local info = TTTRankList[Entity(tab):UniqueID()] or {}
		if IsValid(TTTStatsMenu) then
			TTTStatsMenu.MyInfoPanel.Info = info
			TTTStatsMenu.MyInfoPanel:Update()
		end
	end
	
	local function ResetList()
		TTTRankList = {}
	end
	
	local curloop = 0
	local targetloop = 0
	local tab = {}
	local id = 0
	
	net.Receive( "tttstats", function(len)
		
		local exp = string.Explode(";", net.ReadString())
		
		if exp[1] == "STARTDATA" then
			targetloop = tonumber(exp[2])
			curloop = 0
			ResetList()
			tab = {}
			id = tonumber(net.ReadString()) or 1
			if id == 0 then id = LocalPlayer():EntIndex() end
			BuildStatsMenu(Entity(id))
			print("CREATE")
			return
		else
			if !IsValid(TTTStatsMenu) then return end
			curloop = curloop + 1
			print("ADD STUFF", curloop, targetloop)
			
			local t = net.ReadTable()
			
			table.Merge(tab, t)
			TTTRankList = tab
			UpdateStatsMenu(id)
			
			if curloop >= targetloop then
				TTTStatsMenu.GotInfo = true
			end
		end
		
	end)
	
	local pressed = false
	
	hook.Add("Think", "ttt_stats_think", function()
		if !pressed and input.IsKeyDown(_G["KEY_"..TTTStats.StatsKey]) and IsValid(TTTStatsMenu) == false then
			pressed = true
			net.Start( "tttstats" )
			net.SendToServer()
		elseif pressed and !input.IsKeyDown(_G["KEY_"..TTTStats.StatsKey]) then
			pressed = false
		end
		
		if TTTStats.ChatReminder then
			if CurTime() > TTTStats.ChatTime then
				LocalPlayer():ChatPrint("Press "..TTTStats.StatsKey.." or type !stats [name] to open up the TTT Stats menu.")
				TTTStats.ChatTime = CurTime() + TTTStats.ChatReminderTime * 60
			end
		end
		
	end)
	
end