--How long, in seconds, in to a round a traitor will be slain for having no kills
TRAITOR_INACTIVITY_SLAY = 180

--How long, in seconds, in to a round a traitor will be warned for having no kills
TRAITOR_INACTIVITY_WARNING = 120

--The format for the warning, where the first %s is how long in to the round it is and the second %s is how many seconds the traitor has left
TRAITOR_INACTIVITY_WARNING_STRING = "WARNING: You haven't killed an innocent in the first %s seconds of the round, kill an innocent in the next %s seconds to avoid being slain!"

--The format for the message sent when the player is slain, where the %s is the slay time
TRAITOR_INACTIVITY_SLAY_STRING = "You were slain after %s seconds for inactivity as a traitor!"

--Should a countdown on the player's HUD be shown between the warning and the slay?
TRAITOR_INACTIVITY_SHOW_COUNTDOWN = true

--The countdown warning shown on the player's HUD
TRAITOR_INACTIVITY_COUNTDOWN_STRING = "YOU HAVE %s SECONDS TO KILL AN INNOCENT..."

if CLIENT then
	--Countdown font
	surface.CreateFont("InactivityWarning",
						{ font = "Arial",
						size = 14,
						weight = 700,
						shadow = true })
end