local TraitorKills = {}

util.AddNetworkString("WarnTraitor")

util.AddNetworkString("InactivityCountdown")
util.AddNetworkString("StopInactivityCountdown")

local TRAITOR_INACTIVITY_GAP = TRAITOR_INACTIVITY_SLAY - TRAITOR_INACTIVITY_WARNING

local function InactivitySlay( ply )
	if ply == nil or not IsValid(ply) or TraitorKills[ ply:UserID() ] or ply:IsSpec() then return end
	
	net.Start("WarnTraitor")
		net.WriteString(Format(TRAITOR_INACTIVITY_SLAY_STRING, TRAITOR_INACTIVITY_SLAY))
	net.Send(ply)
	
	net.Start("StopInactivityCountdown")
	net.Send(ply)
	
	ply.inactivity = true
	ply:Kill()
	
	--Detailed Events support
	if DMG_LOG then
		AddToDamageLog({DMG_LOG.SLAY_TRAITOR, ply:Nick(), {ply:SteamID()}})
	end
end

local function InactivityWarning( ply )
	if ply == nil or not IsValid(ply) or TraitorKills[ ply:UserID() ] or ply:IsSpec() then return end
	
	net.Start("WarnTraitor")
		net.WriteString(Format(TRAITOR_INACTIVITY_WARNING_STRING, TRAITOR_INACTIVITY_WARNING, TRAITOR_INACTIVITY_GAP))
	net.Send(ply)
	
	if TRAITOR_INACTIVITY_SHOW_COUNTDOWN then
		net.Start("InactivityCountdown")
			net.WriteInt(CurTime(), 16)
		net.Send(ply)
	end
	
	timer.Create("InactivityWarning" .. ply:UserID(), TRAITOR_INACTIVITY_GAP, 1, function()
		InactivitySlay( ply )
	end)
end

hook.Add("PlayerDeath", "CountTKill", function(vic, inf, killer)
	if GetRoundState() != ROUND_ACTIVE then return end
	if vic:IsPlayer() and killer:IsPlayer() and not vic:IsTraitor() and killer:IsTraitor() then
		if TraitorKills[ killer:UserID() ] == nil then
			TraitorKills[ killer:UserID() ] = true
			net.Start("StopInactivityCountdown")
			net.Send(killer)
		end
	end
end)

hook.Add("TTTBeginRound", "StartCheckingKills", function()
	for _,v in pairs(player.GetAll()) do
		if v:IsActiveTraitor() then
			timer.Create("InactivityWarning" .. v:UserID(), TRAITOR_INACTIVITY_WARNING, 1, function()
				InactivityWarning( v )
			end)
		end
	end
end)

hook.Add("TTTEndRound", "EndCheckingKills", function()
	table.Empty(TraitorKills)
	for _,v in pairs(player.GetAll()) do
		if v:IsTraitor() then
			timer.Destroy("InactivityWarning" .. v:UserID())
			net.Start("StopInactivityCountdown")
			net.Send(v)
		end
	end
end)