local WarningTime
local TRAITOR_INACTIVITY_GAP = TRAITOR_INACTIVITY_SLAY - TRAITOR_INACTIVITY_WARNING

net.Receive("WarnTraitor", function()
	chat.AddText(Color(255,36,6), net.ReadString())
end)

net.Receive("InactivityCountdown", function()
	WarningTime = net.ReadInt(16)
end)

net.Receive("StopInactivityCountdown", function()
	WarningTime = nil
end)

hook.Add("HUDPaint", "InactivityCountdown", function()
	if WarningTime != nil then
		local time = math.max(math.Round((WarningTime+TRAITOR_INACTIVITY_GAP) - CurTime(), 1), 0)
		draw.SimpleTextOutlined(Format(TRAITOR_INACTIVITY_COUNTDOWN_STRING, time .. (time % 1 == 0 and ".0" or "")), "InactivityWarning", ScrW() / 2, 10, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, Color(0,0,0,255))
	end
end)

hook.Add("Initialize", "AddLang", function()
	LANG.AddToLanguage("english", "body_tslay", "{victim} was slain for inactivity as a traitor.")
end)