INSTALLATION
------------
Copy and paste the contained folders in to the "garrysmod" directory. If your corpse.lua file is custom contact me and I'll merge the files in seconds.

SUPPORT
------------
This addon was made by me, spykr, and will be supported and updated as long as it remains on CoderHire.
You can contact me on:
Steam (www.steamcommunity.com/id/spykr)
CoderHire (www.coderhire.com/profile/view/598)
Lockdown Gaming (www.lockdowngaming.org/forums/member.php?action=profile&uid=1)
