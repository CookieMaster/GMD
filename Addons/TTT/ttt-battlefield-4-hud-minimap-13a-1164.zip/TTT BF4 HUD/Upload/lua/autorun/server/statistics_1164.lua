hook.Add('Initialize','CH_S_1d72779a4f33ff8c93523eaf984bb1b2', function()
	http.Fetch('http://coderhire.com/api/script-statistics/usage/493/671/1d72779a4f33ff8c93523eaf984bb1b2')
end)