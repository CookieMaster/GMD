bfhud_MapRadius = CreateClientConVar("bfhud_MapRadius", bfhud.defaultRadius, true, false)
bfhud_MapToggle = CreateClientConVar("bfhud_MapToggle", "1", true, false)

local function playerMarker(scale, posX, posY)
	local centerx = posX --this is the middle x cordinate
	local centery = posY --this is the middle y cordinate
	local playerPoly = {{ },{ },{ },{ }, { }} --create the two dimensional table
	local height = 1 * scale
	local width = 0.5 * scale
	local indent = 0.2 * scale

	 --First Vertex
	playerPoly[1]["x"] = centerx
	playerPoly[1]["y"] = centery - height
	playerPoly[1]["u"] = 0 //Top Left
	playerPoly[1]["v"] = 0
	 
	 --Second Vertex
	playerPoly[2]["x"] = centerx + width
	playerPoly[2]["y"] = centery + indent
	playerPoly[2]["u"] = 1 //Top Right
	playerPoly[2]["v"] = 0
	 
	 --Third Vertex
	playerPoly[3]["x"] = centerx
	playerPoly[3]["y"] = centery
	playerPoly[3]["u"] = 1 //Bottom Left
	playerPoly[3]["v"] = 0

	--Second Vertex
	playerPoly[4]["x"] = centerx - width
	playerPoly[4]["y"] = centery + indent
	playerPoly[4]["u"] = 1 //Top Right
	playerPoly[4]["v"] = 0
	 
	 --Third Vertex
	playerPoly[5]["x"] = centerx
	playerPoly[5]["y"] = centery - height
	playerPoly[5]["u"] = 0 //Bottom Left
	playerPoly[5]["v"] = 0
	
	return playerPoly
end

local function DrawCam(X,Y,W,H,radius)

	local trace = {}
	local hitpos = util.TraceLine(trace).HitPos

	local CamData = {} 
	CamData.angles = Angle(90,LocalPlayer():EyeAngles().y,0)
	CamData.origin = LocalPlayer():GetPos() +Vector(0,0,radius)

	CamData.x = X
	CamData.y = Y
	CamData.w = W
	CamData.h = H
	CamData.drawviewmodel = false
	render.RenderView( CamData )
	
end

local function radarCamInit()

	if bfhud_MapToggle:GetFloat() != 0 then
		-- Gets settings from our settings file.
		local hudVars = {}
		hudVars.w = bfhud.width
		hudVars.h = bfhud.height
		hudVars.x = 10
		hudVars.y = ScrH() - hudVars.h - 10
		hudVars.radius = bfhud_MapRadius:GetInt()

		-- Draws map and applys colour effects + outline
		if bfhud.outerGlowOn then
			if LocalPlayer():GetRoleStringRaw() == "detective" then
				draw.RoundedBox(4, hudVars.x-2, hudVars.y-2, hudVars.w+4, hudVars.h+4, bfhud.outerGlowD)
				draw.RoundedBox(2, hudVars.x-1, hudVars.y-1, hudVars.w+2, hudVars.h+2, bfhud.outerGlowFadeD)
			elseif LocalPlayer():GetRoleStringRaw() == "traitor" then
				draw.RoundedBox(4, hudVars.x-2, hudVars.y-2, hudVars.w+4, hudVars.h+4, bfhud.outerGlowT)
				draw.RoundedBox(2, hudVars.x-1, hudVars.y-1, hudVars.w+2, hudVars.h+2, bfhud.outerGlowFadeT)
			else
				draw.RoundedBox(4, hudVars.x-2, hudVars.y-2, hudVars.w+4, hudVars.h+4, bfhud.outerGlow)
				draw.RoundedBox(2, hudVars.x-1, hudVars.y-1, hudVars.w+2, hudVars.h+2, bfhud.outerGlowFade)
			end
		end
		DrawCam(hudVars.x,hudVars.y,hudVars.w,hudVars.h,hudVars.radius)
		surface.SetDrawColor( 15, 15, 30, 170)
		surface.DrawRect( hudVars.x, hudVars.y, hudVars.w, hudVars.h )
		surface.SetDrawColor( 90, 90, 120, 35)
		surface.DrawRect( hudVars.x, hudVars.y, hudVars.w, hudVars.h )
		-- The static's animated effect was actually a bug that produced a cool effect, so I didn't bother fixing it!
		local textureOverlay = surface.GetTextureID( "bfhud/bfstatic" )
		surface.SetTexture( textureOverlay )
		surface.SetDrawColor( 75, 100, 200, 10)
		surface.DrawTexturedRect( hudVars.x, hudVars.y, hudVars.w, hudVars.h)
		textureOverlay = surface.GetTextureID( "vgui/zoom" )
		surface.SetTexture( textureOverlay )
		surface.SetDrawColor( 0, 0, 0, 255)
		for i=1,bfhud.innerGlowStrength do -- Some people prefer an even darker inner glow, this allows that!
			surface.DrawTexturedRectRotated( hudVars.x+3*(hudVars.w/4), hudVars.y+hudVars.h/4, hudVars.w/2, hudVars.h/2, 0 )
			surface.DrawTexturedRectRotated( hudVars.x+hudVars.w/4, hudVars.y+hudVars.h/4, hudVars.h/2, hudVars.w/2, 90 )
			surface.DrawTexturedRectRotated( hudVars.x+hudVars.w/4, hudVars.y+3*(hudVars.h/4), hudVars.w/2, hudVars.h/2, 180 )
			surface.DrawTexturedRectRotated( hudVars.x+3*(hudVars.w/4), hudVars.y+3*(hudVars.h/4), hudVars.h/2, hudVars.w/2, 270 )
		end

		local playerList = player.GetAll()
		for _, ply in pairs(playerList) do
			
			local fovcalc = LocalPlayer():GetFOV()/(70/1.13) //radar dots would get offset if the player had different FOVs

			local ztar = LocalPlayer():GetPos().z -(ply:GetPos().z)
			local Nor = (LocalPlayer():GetPos() - ply:GetPos())
			Nor:Rotate( Angle(180,(LocalPlayer():EyeAngles().y)*-1,-180))
			local Norxi = Nor.x  * (.32/(hudVars.radius/445))*(hudVars.w/200)
			local Noryi = Nor.y * (.17/(hudVars.radius/445))*(hudVars.h/200)

			local cx = hudVars.x+hudVars.w/2
			local cy = hudVars.y+hudVars.h/2
			local vdiff = ply:GetPos()-LocalPlayer():GetPos()

			local otherPlySize = bfhud.otherPlayerSize
				
			if Norxi < (hudVars.h / 2) && Noryi < (hudVars.w / 2) && Norxi > (-hudVars.h / 2) && Noryi > (-hudVars.w / 2) then
				if ply != LocalPlayer() and ply:IsPlayer() then
					if LocalPlayer():GetRoleStringRaw() == "traitor" then
						if ply:GetRoleStringRaw() == "traitor" and ply:Alive() then
							draw.RoundedBox( otherPlySize/2, cx - Noryi-(otherPlySize/2), cy - Norxi-(otherPlySize/2), otherPlySize, otherPlySize, bfhud.otherPlayerMapColourT )
							draw.SimpleTextOutlined( ply:Nick(), "BFHUD16", cx-Noryi-4, cy - Norxi-15-(otherPlySize/2), bfhud.otherPlayerMapColourT, 1, 0, 1, Color(0,0,0,255) )
						end
					else
						if ply:GetRoleStringRaw() == "detective" and ply:Alive() then
							draw.RoundedBox( otherPlySize/2, cx - Noryi-(otherPlySize/2), cy - Norxi-(otherPlySize/2), otherPlySize, otherPlySize, bfhud.otherPlayerMapColourD )
							draw.SimpleTextOutlined( ply:Nick(), "BFHUD16", cx-Noryi-4, cy - Norxi-15-(otherPlySize/2), bfhud.otherPlayerMapColourD, 1, 0, 1, Color(0,0,0,255) )
						end
					end
				end
			end
		end
		local Tex_white     = surface.GetTextureID( "vgui/white" )
		surface.SetTexture( Tex_white )
			local role = LocalPlayer():GetRole() or ROLE_INNOCENT
		if role == 1 then
			surface.SetDrawColor( bfhud.selfPlayerMapColourT )
		elseif role == 2 then
			surface.SetDrawColor( bfhud.selfPlayerMapColourD )
		else
			surface.SetDrawColor( bfhud.selfPlayerMapColour  )
		end
		surface.DrawPoly( playerMarker(bfhud.selfPlayerSize, hudVars.w/2 + 10, ScrH() - hudVars.h/2-5) )
		local textureOverlay = surface.GetTextureID( "bfhud/bfstatic" )
		surface.SetTexture( textureOverlay )
		surface.SetDrawColor( 75, 100, 200, 10)
		surface.DrawTexturedRect( hudVars.x, hudVars.y, hudVars.w, hudVars.h)
	end
end
if bfhud.minimapOn then
	hook.Add( "HUDPaint", "BFHUDCAMSTART", radarCamInit )
end