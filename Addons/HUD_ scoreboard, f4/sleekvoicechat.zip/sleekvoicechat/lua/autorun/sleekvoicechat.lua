if SERVER then
	AddCSLuaFile()
	AddCSLuaFile("cl_sleekvoice.lua")
end

if CLIENT then
	include("cl_sleekvoice.lua")
end