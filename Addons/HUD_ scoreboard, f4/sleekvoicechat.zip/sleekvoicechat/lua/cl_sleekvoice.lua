// Made by: CrashLemon

local PANEL = {}
local SleekVoicePanels = {}

SVC = {}

SVC.IsTTT = false;
SVC.IsDarkRP = false;

// Not yet implemented.
SVC.DrawWaveMeter = false;
SVC.WaveMeterTime = 0.5;

SVC.XPos = 56;
SVC.BackgroundColor = Color( 20, 20, 20, 255 )
SVC.OutlineColor = Color( 100, 100, 100, 255 )
SVC.DefaultGradientColor =  Color( 20, 150, 20, 100 )

function IsTTTActive()
	
	if SVC.IsTTT or gmod.GetGamemode().Name == "Trouble in Terrorist Town" then 
		return true 
	end
	
	return false
	
end

function IsDarkRPActive()

	if SVC.IsDarkRP or gmod.GetGamemode().Name == "DarkRP" then 
		return true 
	end
	
	return false

end

function PANEL:Init()

	self.LabelName = vgui.Create( "DLabel", self )
	self.LabelName:SetFont( "TargetID" )
	self.LabelName:Dock( FILL )
	self.LabelName:DockMargin( SVC.XPos - 5, 0, 1, 2 )
	self.LabelName:SetTextColor( Color( 200, 200, 200, 255 ) )
	self.LabelName:SetExpensiveShadow( 1, Color( 0, 0, 0, 190 ) )
	
	self.Avatar = vgui.Create( "AvatarImage", self )
	self.Avatar:Dock( RIGHT );
	self.Avatar:SetSize( 32, 32 )
	
	self.Color = color_transparent

	self:SetSize( 250, 32 + 8 )
	self:DockPadding( 4, 4, 4, 4 )
	self:DockMargin( 2, 2, 2, 2 )
	self:Dock( BOTTOM )
	self:GetParent():SetSize( 240, ScrH() - 200 )
	
	self.PlyModel = vgui.Create( "DModelPanel", self )
	self.PlyModel:SetSize( self:GetTall() + 4, self:GetTall() + 4 )
	self.PlyModel:SetPos( 4, -5 )
	self.PlyModel:SetLookAt( Vector( 0, 0, 65 ) )
	self.PlyModel:SetCamPos( Vector( 14, -6, 65 ) )
	self.PlyModel:SetAmbientLight( Vector( 00, 00, 00 ))
	function self.PlyModel:LayoutEntity( Entity )
	 
		if ( self.bAnimated ) then -- Make it animate normally
			self:RunAnimation()
			
		end
	 
	end

end

function PANEL:Setup( ply )

	self.ply = ply
	self.LabelName:SetText( ply:Nick() )
	self.Avatar:SetPlayer( ply )
	self.PlyModel:SetModel( ply:GetModel() )
	
	self.Color = team.GetColor( ply:Team() )
	
	self:InvalidateLayout()
	
	self.RealPaint = self.Paint

end

function PANEL:Paint( w, h )

	if ( !IsValid( self.ply ) ) then return end
	
	local gradientColor = SVC.DefaultGradientColor
	local outlineColor = SVC.OutlineColor
	
	if ( IsTTTActive() ) then
	
		outlineColor = Color( 20, 150, 20, 255 )
		gradientColor =  Color( 20, 150, 20, 100 )
	
		if self.ply:IsActiveTraitor() and not self.ply.traitor_gvoice then
			gradientColor = Color( 150, 20, 20, 100 )
			outlineColor = Color( 150, 20, 20, 255 )
		elseif self.ply:IsActiveDetective() then
			gradientColor = Color( 20, 20, 150, 100 )
			outlineColor = Color( 20, 20, 150, 255 )
		end
		
		if self.ply:IsSpec() then
			gradientColor = Color( 60, 60, 60, 230 )
			outlineColor = Color( 100, 100, 100, 255 )
		end
		
	elseif ( IsDarkRPActive() ) then
	
		local jobColor = team.GetColor( self.ply:Team() )
		jobColor = Color( jobColor.r / 255, jobColor.g / 255, jobColor.b / 255, 255 )
		
		gradientColor = Color( jobColor.r * 120, jobColor.g * 120, jobColor.b * 120, 230 )
		outlineColor = Color( jobColor.r * 180, jobColor.g * 180, jobColor.b * 180, 255 )
	
	end
	
	draw.RoundedBox( 0, 0, 0, w, h, SVC.OutlineColor )
	draw.TexturedQuad
	{
		texture = surface.GetTextureID "gui/gradient",
		color = outlineColor,
		x = 0,
		y = 0,
		w = SVC.XPos * 3,
		h = self:GetTall()
	}
	
	// Draw wave meter.
	if ( SVC.DrawWaveMeter ) then
	
	end
	
	draw.RoundedBox( 0, 1, 1, w - 2, h - 2, SVC.BackgroundColor )
	draw.TexturedQuad
	{
		texture = surface.GetTextureID "gui/gradient",
		color = gradientColor,
		x = 1,
		y = 1,
		w = SVC.XPos * 3,
		h = self:GetTall() - 2
	}
	
	if ( not SVC.DrawWaveMeter ) then
		draw.RoundedBox( 0, SVC.XPos, 29, 136,  2, Color( 0, 0, 0, 230 ))
		
		if self.ply:VoiceVolume() > 0.01 then
			draw.RoundedBox( 0, SVC.XPos, 29, 136 * self.ply:VoiceVolume(), 1, Color( self.ply:VoiceVolume() * 150, 150 - ( self.ply:VoiceVolume() * 150 ), 0, 255 ))
			draw.RoundedBox( 0, SVC.XPos, 30, 136 * self.ply:VoiceVolume(), 1, Color( self.ply:VoiceVolume() * 200, 200 - ( self.ply:VoiceVolume() * 200 ), 0, 255 ))
		end
		
	end
	
end

function PANEL:Think( )

	if self.Paint != self.RealPaint then
		self.Paint = self.RealPaint
	end
	
end

function PANEL:FadeOut( anim, delta, data )
	
	if ( anim.Finished ) then
	
		if ( IsValid( SleekVoicePanels[ self.ply ] ) ) then
			SleekVoicePanels[ self.ply ]:Remove()
			SleekVoicePanels[ self.ply ] = nil
			return
		end
		
	return end
			
	self:SetAlpha( 255 - (255 * delta) )

end

derma.DefineControl( "VoiceNotify", "", PANEL, "DPanel" )

hook.Add( "PlayerStartVoice", "SleekStartVoice", function( ply )

	if ( !IsTTTActive() ) then
	
		if ( !IsValid( g_VoicePanelList ) ) then return end

		-- There'd be an exta one if voice_loopback is on, so remove it.
		SleekEndVoice( ply )

		if ( !IsValid( ply ) ) then return end

		local pnl = g_VoicePanelList:Add( "VoiceNotify" )
		pnl:Setup( ply )

		SleekVoicePanels[ ply ] = pnl
		
		if ( !IsDarkRPActive() ) then
			return false
		end
		
	end
	
end)

function SleekEndVoice( ply )
	
	if ( !IsTTTActive() ) then
	
		if ( IsValid( SleekVoicePanels[ ply ] ) ) then
		
			SleekVoicePanels[ ply ]:Remove()
			SleekVoicePanels[ ply ] = nil

		end
	
	if ( !IsDarkRPActive() ) then
		return false
	end
	
	end
	
end

hook.Add( "PlayerEndVoice", "SleekEndVoice", SleekEndVoice )