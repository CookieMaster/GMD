// client side apple

function ChatTags(ply, Text, Team, PlayerIsDead)
if Team then
			local nickteamcolor = team.GetColor(ply:Team())
			local nickteam = team.GetName(ply:Team())
			if ply:Alive() then
			chat.AddText(Color(255, 0, 0, 255), "{TEAM} ", nickteamcolor, nickteam, Color(50, 50, 50, 255), "| ", nickteamcolor, ply:Nick(), color_white, ": ", Color(255, 255, 255, 255), Text)
			else
			chat.AddText(Color(255, 0, 0, 255), "*DEAD* {TEAM} ", nickteamcolor, nickteam, Color(50, 50, 50, 255), "| ", nickteamcolor, ply:Nick(), color_white, ": ", Color(255, 255, 255, 255), Text)
			end
			return true
end
if ply:IsPlayer() then
if ply:Alive() then
			local nickteamcolor = team.GetColor(ply:Team())
			local nickteam = team.GetName(ply:Team())
			chat.AddText(Color(150, 150, 150, 255), "", nickteamcolor, nickteam, Color(50, 50, 50, 255), "| ", nickteamcolor, ply:Nick(), color_white, ": ", Color(255, 255, 255, 255), Text)
			return true
elseif !ply:Alive() then
			local nickteamcolor = team.GetColor(ply:Team())
			local nickteam = team.GetName(ply:Team())
			chat.AddText(Color(255, 0, 0, 255), "*DEAD* ", nickteamcolor, nickteam, Color(50, 50, 50, 255), "| ", nickteamcolor, ply:Nick(), color_white, ": ", Color(255, 255, 255, 255), Text)
			return true
end
end
end
hook.Add("OnPlayerChat", "Tags", ChatTags)