// Made by Tomasas http://steamcommunity.com/id/tomasas/
concommand.Add("c_rpname", function(ply, cmd, args)

	print(args[1], args[2])
	DB.RetrieveRPNames(ply, args[1], function(taken)
		if taken and ply:IsValid() then
			umsg.Start("_Notify", ply)
				umsg.String("This name is already being used!")
				umsg.Short(1)
				umsg.Long(10)
			umsg.End()
			umsg.Start("openRPNameMenu", ply)
			umsg.End()
		else
			DB.StoreRPName(ply, args[1])
		end
	end)
end)


hook.Add("PlayerAuthed", "RPNameChecking", function(ply)
	timer.Simple(6, function() //let darkrp load their name before checking
		if !ply:IsValid() then return end
		if ply.DarkRPVars and (!ply.DarkRPVars.rpname or ply.DarkRPVars.rpname == ply:SteamName() or ply.DarkRPVars.rpname == "NULL") then
			umsg.Start("openRPNameMenu", ply)
			umsg.End()
		end
	end) 
end)
//�Tomasas 2013