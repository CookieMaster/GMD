local function RXF4VIPCheck(ply)
	local JobCheck = false
	for k,v in pairs(RXF4_Adjust.VIPGroup or {}) do
		if ply:GetNWString("usergroup") == v then
			JobCheck = true
		end
	end
			
	if JobCheck == false then
		return false
	else
		return true
	end
end