if CLIENT then
local PANEL = {}


local function MayorOptns()
	local MayCat = vgui.Create("DCollapsibleCategory")
	function MayCat:Paint()
	end
	MayCat:SetLabel("Mayor options")
		local maypanel = vgui.Create("DListLayout")
		maypanel:SetSize(740,170)
			local SearchWarrant = maypanel:Add("RXF4_DSWButton")
			SearchWarrant.TextCol = Color(0,255,0,255)
			SearchWarrant:SetSize(700,30)
			SearchWarrant:SetTexts(DarkRP.getPhrase("searchwarrantbutton"))
			SearchWarrant.DoClick = function()
				local menu = DermaMenu()
				for _,ply in pairs(player.GetAll()) do
					if not ply:getDarkRPVar("warrant") and ply ~= LocalPlayer() then
						menu:AddOption(ply:Nick(), function()
							Derma_StringRequest("Warrant", "Why would you warrant "..ply:Nick().."?", nil,
								function(a)
									RunConsoleCommand("darkrp", "/warrant", ply:SteamID(), a)
								end,
							function() end )
						end)
					end
				end
				menu:Open()
			end

			local Warrant = maypanel:Add("RXF4_DSWButton")
			Warrant.TextCol = Color(0,255,0,255)
			Warrant:SetSize(700,30)
			Warrant:SetTexts(DarkRP.getPhrase("make_wanted"))
			Warrant.DoClick = function()
				local menu = DermaMenu()
				for _,ply in pairs(player.GetAll()) do
					if not ply:getDarkRPVar("wanted") and ply ~= LocalPlayer() then
						menu:AddOption(ply:Nick(), function() Derma_StringRequest("wanted", "Why would you make "..ply:Nick().." wanted?", nil,
								function(a)
									RunConsoleCommand("darkrp", "/wanted", ply:SteamID(), a)
								end,
							function() end )
						end)
					end
				end
				menu:Open()
			end

			local UnWarrant = maypanel:Add("RXF4_DSWButton")
			UnWarrant.TextCol = Color(0,255,0,255)
			UnWarrant:SetSize(700,30)
			UnWarrant:SetTexts(DarkRP.getPhrase("make_unwanted"))
			UnWarrant.DoClick = function()
				local menu = DermaMenu()
				for _,ply in pairs(player.GetAll()) do
					if ply:getDarkRPVar("wanted") and ply ~= LocalPlayer() then
						menu:AddOption(ply:Nick(), function() LocalPlayer():ConCommand("darkrp /unwanted \"" .. ply:SteamID() .. "\"") end)
					end
				end
				menu:Open()
			end

			local Lockdown = maypanel:Add("RXF4_DSWButton")
			Lockdown.TextCol = Color(0,255,0,255)
			Lockdown:SetSize(700,30)
			Lockdown:SetTexts(DarkRP.getPhrase("initiate_lockdown"))
			Lockdown.DoClick = function()
				LocalPlayer():ConCommand("darkrp /lockdown")
			end


			local UnLockdown = maypanel:Add("RXF4_DSWButton")
			UnLockdown.TextCol = Color(0,255,0,255)
			UnLockdown:SetSize(700,30)
			UnLockdown:SetTexts(DarkRP.getPhrase("stop_lockdown"))
			UnLockdown.DoClick = function()
				LocalPlayer():ConCommand("darkrp /unlockdown")
			end

			local Lottery = maypanel:Add("RXF4_DSWButton")
			Lottery.TextCol = Color(0,255,0,255)
			Lottery:SetSize(700,30)
			Lottery:SetTexts(DarkRP.getPhrase("start_lottery"))
			Lottery.DoClick = function()
				LocalPlayer():ConCommand("darkrp /lottery")
			end

			local GiveLicense = maypanel:Add("RXF4_DSWButton")
			GiveLicense.TextCol = Color(0,255,0,255)
			GiveLicense:SetSize(700,30)
			GiveLicense:SetTexts(DarkRP.getPhrase("give_license_lookingat"))
			GiveLicense.DoClick = function()
				LocalPlayer():ConCommand("darkrp /givelicense")
			end

			local PlaceLaws = maypanel:Add("RXF4_DSWButton")
			PlaceLaws.TextCol = Color(0,255,0,255)
			PlaceLaws:SetSize(700,30)
			PlaceLaws:SetTexts("Place a screen containing the laws.")
			PlaceLaws.DoClick = function()
				LocalPlayer():ConCommand("darkrp /placelaws")
			end

			local AddLaws = maypanel:Add("RXF4_DSWButton")
			AddLaws.TextCol = Color(0,255,0,255)
			AddLaws:SetSize(700,30)
			AddLaws:SetTexts("Add a law.")
			AddLaws.DoClick = function()
				Derma_StringRequest("Add a law", "Type the law you would like to add here.", "", function(law)
					RunConsoleCommand("darkrp", "/addlaw", law)
				end)
			end

			local RemLaws = maypanel:Add("RXF4_DSWButton")
			RemLaws.TextCol = Color(0,255,0,255)
			RemLaws:SetSize(700,30)
			RemLaws:SetTexts("Remove a law.")
			RemLaws.DoClick = function()
				Derma_StringRequest("Remove a law", "Enter the number of the law you would like to remove here.", "", function(num)
					LocalPlayer():ConCommand("darkrp /removelaw " .. num)
				end)
			end
	MayCat:SetContents(maypanel)
	MayCat:SetSkin(GAMEMODE.Config.DarkRPSkin)
	return MayCat
end

local function CPOptns()
	local CPCat = vgui.Create("DCollapsibleCategory")
	function CPCat:Paint()
	end
	CPCat:SetLabel("Police options")
		local CPpanel = vgui.Create("DListLayout")
		CPpanel:SetSize(740,170)
			local SearchWarrant = CPpanel:Add("RXF4_DSWButton")
			SearchWarrant.TextCol = Color(0,150,255,255)
			SearchWarrant:SetSize(740,30)
			SearchWarrant:SetTexts(DarkRP.getPhrase("request_warrant"))
			SearchWarrant.DoClick = function()
				local menu = DermaMenu()
				for _,ply in pairs(player.GetAll()) do
					if not ply:getDarkRPVar("warrant") and ply ~= LocalPlayer() then
						menu:AddOption(ply:Nick(), function()
							Derma_StringRequest("Warrant", "Why would you warrant "..ply:Nick().."?", nil,
								function(a)
									RunConsoleCommand("darkrp", "/warrant", ply:SteamID(), a)
								end,
							function() end )
						end)
					end
				end
				menu:Open()
			end

			local Warrant = CPpanel:Add("RXF4_DSWButton")
			Warrant.TextCol = Color(0,150,255,255)
			Warrant:SetSize(740,30)
			Warrant:SetTexts(DarkRP.getPhrase("searchwarrantbutton"))
			Warrant.DoClick = function()
				local menu = DermaMenu()
				for _,ply in pairs(player.GetAll()) do
					if not ply:getDarkRPVar("wanted") and ply ~= LocalPlayer() then
						menu:AddOption(ply:Nick(), function()
							Derma_StringRequest("wanted", "Why would you make "..ply:Nick().." wanted?", nil,
								function(a)
									if not IsValid(ply) then return end
									RunConsoleCommand("darkrp", "/wanted", ply:SteamID(), a)
								end,
							function() end )
						end)
					end
				end
				menu:Open()
			end

			local UnWarrant = CPpanel:Add("RXF4_DSWButton")
			UnWarrant.TextCol = Color(0,150,255,255)
			UnWarrant:SetSize(740,30)
			UnWarrant:SetTexts(DarkRP.getPhrase("unwarrantbutton"))
			UnWarrant.DoClick = function()
				local menu = DermaMenu()
				for _,ply in pairs(player.GetAll()) do
					if ply:getDarkRPVar("wanted") and ply ~= LocalPlayer() then
						menu:AddOption(ply:Nick(), function() LocalPlayer():ConCommand("darkrp /unwanted \"" .. ply:SteamID() .. "\"") end)
					end
				end
				menu:Open()
			end

			if LocalPlayer():Team() == TEAM_CHIEF and GAMEMODE.Config.chiefjailpos or LocalPlayer():IsAdmin() then
				local SetJailPos = CPpanel:Add("RXF4_DSWButton")
				SetJailPos.TextCol = Color(0,150,255,255)
				SetJailPos:SetSize(740,30)
				SetJailPos:SetTexts(DarkRP.getPhrase("set_jailpos"))
				SetJailPos.DoClick = function() LocalPlayer():ConCommand("darkrp /jailpos") end

				local AddJailPos = CPpanel:Add("RXF4_DSWButton")
				AddJailPos.TextCol = Color(0,150,255,255)
				AddJailPos:SetSize(740,30)
				AddJailPos:SetTexts(DarkRP.getPhrase("add_jailpos"))
				AddJailPos.DoClick = function() LocalPlayer():ConCommand("darkrp /addjailpos") end
			end

			local ismayor -- Firstly look if there's a mayor
			local ischief -- Then if there's a chief
			for k,v in pairs(player.GetAll()) do
				if v:Team() == TEAM_MAYOR then
					ismayor = true
					break
				end
			end

			if not ismayor then
				for k,v in pairs(player.GetAll()) do
					if v:Team() == TEAM_CHIEF then
						ischief = true
						break
					end
				end
			end

			local Team = LocalPlayer():Team()
			if not ismayor and (Team == TEAM_CHIEF or (not ischief and Team == TEAM_POLICE)) then
				local GiveLicense = CPpanel:Add("RXF4_DSWButton")
				GiveLicense.TextCol = Color(0,150,255,255)
				GiveLicense:SetSize(740,30)
				GiveLicense:SetTexts(DarkRP.getPhrase("give_license_lookingat"))
				GiveLicense.DoClick = function()
					LocalPlayer():ConCommand("darkrp /givelicense")
				end
			end
	CPCat:SetContents(CPpanel)
	CPCat:SetSkin(GAMEMODE.Config.DarkRPSkin)
	return CPCat
end


local function CitOptns()
	local CitCat = vgui.Create("DCollapsibleCategory")
	function CitCat:Paint()
	end
	CitCat:SetLabel("Citizen options")
		local Citpanel = vgui.Create("DListLayout")
		Citpanel:SetSize(740,110)

		local joblabel = Citpanel:Add("DLabel")
		joblabel:SetText(DarkRP.getPhrase("set_custom_job"))

		local jobentry = Citpanel:Add("DTextEntry")
		jobentry:SetAllowNonAsciiCharacters(true)
		jobentry:SetValue(LocalPlayer():getDarkRPVar("job") or "")
		jobentry.OnEnter = function()
			RunConsoleCommand("DarkRP", "/job", tostring(jobentry:GetValue()))
		end

	CitCat:SetContents(Citpanel)
	CitCat:SetSkin(GAMEMODE.Config.DarkRPSkin)
	return CitCat
end


local function MobOptns()
	local MobCat = vgui.Create("DCollapsibleCategory")
	function MobCat:Paint()
		self:SetBGColor(team.GetColor(LocalPlayer():Team()))
	end
	MobCat:SetLabel("Mobboss options")
		local Mobpanel = vgui.Create("DListLayout")
		Mobpanel:SetSize(740,110)

		local agendalabel = Mobpanel:Add("DLabel")
		agendalabel:SetText(DarkRP.getPhrase("set_agenda"))

		local agendaentry = Mobpanel:Add("DTextEntry")
		agendaentry:SetAllowNonAsciiCharacters(true)
		agendaentry:SetValue(LocalPlayer():getDarkRPVar("agenda") or "")
		agendaentry.OnEnter = function()
			RunConsoleCommand("darkrp", "/agenda", tostring(agendaentry:GetValue()))
		end

	MobCat:SetContents(Mobpanel)
	MobCat:SetSkin(GAMEMODE.Config.DarkRPSkin)
	return MobCat
end



function RXF4_Open_MoneyCommand(Parent)
	GAMEMODE.ConnectedPlayersPanel = vgui.Create("RXF4_M_MoneyCommand",Parent)
	GAMEMODE.ConnectedPlayersPanel:SetSize(Parent:GetWide(),Parent:GetTall())
	return GAMEMODE.ConnectedPlayersPanel
end
function PANEL:Init()

end
function PANEL:Paint()
	surface.SetDrawColor( 0,0,0,100 )
	surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
	self:DrawBoarder()
end
function PANEL:Install()
	self:SetDraggable(false)
	self:ShowCloseButton(false)
	self:SetTitle(" ")

	self.HasParent = HasParent
	self.TopLabel = vgui.Create( "DPanel" , self)
	self.TopLabel:SetPos(2,2)
	self.TopLabel:SetSize( self:GetWide(),40 )
	self.TopLabel.Paint = function(slf)
			surface.SetDrawColor( 255,255,255,20 )
			surface.DrawRect( 1, 39, slf:GetWide()-2, 1 )
		draw.SimpleText("Money and Commands", "SansationOut_S40", 20,20, Color(0,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	self.ItemList = vgui.Create("DPanelList", self)
		self.ItemList:SetPos(10,50)
		self.ItemList:SetSize(self:GetWide()-20,self:GetTall() - 60)
		self.ItemList:SetSpacing(5);
		self.ItemList:SetPadding(0);
		self.ItemList:EnableVerticalScrollbar(true);
		self.ItemList:EnableHorizontal(false);
		self.ItemList:PaintListBarC()
		self.ItemList.Paint = function(slf)
			surface.SetDrawColor( 0,0,0,50 )
			surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		end
		
	self:UpdateList()
end

function PANEL:UpdateList()
	self.ItemList:Clear()
	local FirstTabPanel = self.ItemList
		function FirstTabPanel:Update()
			self:Clear(true)
			local MoneyCat = vgui.Create("DCollapsibleCategory")
			MoneyCat.Paint = function(slf) end
			MoneyCat:SetLabel("Money")
				local MoneyPanel = vgui.Create("DListLayout")
				
				
				
				local GiveMoneyButton = MoneyPanel:Add("RXF4_DSWButton")
				GiveMoneyButton.TextCol = Color(255,255,0,255)
				GiveMoneyButton:SetSize(100,30)
				GiveMoneyButton:SetTexts(DarkRP.getPhrase("give_money"))
				GiveMoneyButton.DoClick = function()
					Derma_StringRequest("Amount of money", "How much money do you want to give?", "", function(a) LocalPlayer():ConCommand("darkrp /give " .. tostring(a)) end)
				end

				local SpawnMoneyButton = MoneyPanel:Add("RXF4_DSWButton")
				SpawnMoneyButton.TextCol = Color(255,255,0,255)
				SpawnMoneyButton:SetSize(100,30)
				SpawnMoneyButton:SetTexts(DarkRP.getPhrase("drop_money"))
				SpawnMoneyButton.DoClick = function()
					Derma_StringRequest("Amount of money", "How much money do you want to drop?", "", function(a) LocalPlayer():ConCommand("darkrp /dropmoney " .. tostring(a)) end)
				end
				
					if GAMEMODE.Config.enablebuyhealth then
						local health = MoneyPanel:Add("RXF4_DSWButton")
						health.TextCol = Color(255,255,0,255)
						health:SetSize(100,30)
						health:SetTexts(DarkRP.getPhrase("buy_health", tostring(GAMEMODE.Config.healthcost)))
						health.DoClick = function() LocalPlayer():ConCommand("darkrp /Buyhealth") end
					end
				
			MoneyCat:SetContents(MoneyPanel)


			local Commands = vgui.Create("DCollapsibleCategory")
			Commands.Paint = function(slf) end
			Commands:SetLabel("Actions")
				local ActionsPanel = vgui.Create("DListLayout")
				ActionsPanel:SetSize(740,210)
					local rpnamelabel = ActionsPanel:Add("DLabel")
					rpnamelabel:SetText(DarkRP.getPhrase("change_name"))

					local rpnameTextbox = ActionsPanel:Add("DTextEntry")
					--/rpname does not support non-ASCII characters
					rpnameTextbox:SetText(LocalPlayer():Nick())
					rpnameTextbox.OnEnter = function() RunConsoleCommand("darkrp", "/rpname", tostring(rpnameTextbox:GetValue())) end

					local sleep = ActionsPanel:Add("RXF4_DSWButton")
					sleep:SetSize(100,30)
					sleep:SetTexts(DarkRP.getPhrase("go_to_sleep"))
					sleep.DoClick = function()
						LocalPlayer():ConCommand("darkrp /sleep")
					end
					local Drop = ActionsPanel:Add("RXF4_DSWButton")
					Drop:SetSize(100,30)
					Drop:SetTexts(DarkRP.getPhrase("drop_weapon"))
					Drop.DoClick = function() LocalPlayer():ConCommand("darkrp /drop") end

				if LocalPlayer():Team() ~= TEAM_MAYOR then
					local RequestLicense = ActionsPanel:Add("RXF4_DSWButton")
						RequestLicense:SetSize(100,30)
						RequestLicense:SetTexts(DarkRP.getPhrase("request_gunlicense"))
						RequestLicense.DoClick = function() LocalPlayer():ConCommand("darkrp /requestlicense") end
				end

				local Demote = ActionsPanel:Add("RXF4_DSWButton")
				Demote:SetSize(100,30)
				Demote:SetTexts(DarkRP.getPhrase("demote_player_menu"))
				Demote.DoClick = function()
					local menu = DermaMenu()
					for _,ply in pairs(player.GetAll()) do
						if ply ~= LocalPlayer() and IsValid(ply) then
							menu:AddOption(ply:Nick(), function()
								Derma_StringRequest("Demote reason", "Why would you demote "..ply:Nick().."?", nil,
									function(a)
										RunConsoleCommand("darkrp", "/demote", ply:SteamID(), a)
									end,
								function() end )
							end)
						end
					end
					menu:Open()
				end

				local UnOwnAllDoors = ActionsPanel:Add("RXF4_DSWButton")
						UnOwnAllDoors:SetSize(100,30)
						UnOwnAllDoors:SetTexts("Sell all of your doors")
						UnOwnAllDoors.DoClick = function() LocalPlayer():ConCommand("darkrp /unownalldoors") end
			Commands:SetContents(ActionsPanel)
		FirstTabPanel:AddItem(MoneyCat)
		Commands:SetSkin(GAMEMODE.Config.DarkRPSkin)
		FirstTabPanel:AddItem(Commands)

		if LocalPlayer():Team() == TEAM_MAYOR then
			FirstTabPanel:AddItem(MayorOptns())
		elseif LocalPlayer():Team() == TEAM_CITIZEN then
			FirstTabPanel:AddItem(CitOptns())
		elseif LocalPlayer():IsCP() then
			FirstTabPanel:AddItem(CPOptns())
		elseif LocalPlayer():Team() == TEAM_MOB then
			FirstTabPanel:AddItem(MobOptns())
		end
	end
	FirstTabPanel:Update()
	return FirstTabPanel
end
vgui.Register("RXF4_M_MoneyCommand",PANEL,"DFrame")

end