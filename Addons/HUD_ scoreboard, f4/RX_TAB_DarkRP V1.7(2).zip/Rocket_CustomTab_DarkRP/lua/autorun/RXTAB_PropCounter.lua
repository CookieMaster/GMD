PropCounts = PropCounts or {}
if SERVER then	
	util.AddNetworkString( "RXT_RequestPCount_C2S" )
	util.AddNetworkString( "RXT_PCount_S2C" )
	net.Receive( "RXT_RequestPCount_C2S", function( len,ply )
	
		local TB2Send = {}
			local Class = "prop_physics"
			for k,v in pairs(ents.FindByClass(Class)) do
				local PropOwnerID = v.FPPOwnerID or 1

					TB2Send[PropOwnerID] = TB2Send[PropOwnerID] or {}
					TB2Send[PropOwnerID][Class] = TB2Send[PropOwnerID][Class] or {}
					table.insert(TB2Send[PropOwnerID][Class],v)
				
			end
		
		net.Start( "RXT_PCount_S2C" )
			net.WriteTable(TB2Send)
		net.Send(ply)
	end)
end
if CLIENT then
	function RXTPC_RequestPCount_2S()
		net.Start( "RXT_RequestPCount_C2S" )
		net.SendToServer()
	end
	net.Receive( "RXT_PCount_S2C", function( len )
		local DATA = net.ReadTable()
		PropCounts.Data = DATA
		PropCounts.UpdateTime = CurTime() + 30
	end)
	function RXTPC_NeedUpdate()
		if !PropCounts.Data or PropCounts.UpdateTime < CurTime() then
			return true
		else
			return false
		end
	end
	function RXTPC_GetPropCount(target,class)
		local SID = target:SteamID()
		if !PropCounts.Data then return 0 end
		if !PropCounts.Data[SID] then return 0 end
		if !PropCounts.Data[SID][class] then return 0 end

			return #PropCounts.Data[SID][class]
	end
end
