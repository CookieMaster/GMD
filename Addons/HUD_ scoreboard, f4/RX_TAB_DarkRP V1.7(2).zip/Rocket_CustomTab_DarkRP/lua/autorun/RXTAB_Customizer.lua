RXTAB_Adjust = {}
-- ^ Dont Touch
			
	-- Appearance
		-- Main Screen Size
			RXTAB_Adjust.Main_Size_X = 1 -- 1 Mean 100% fit to your screen. screen will cover your screen. if you want half size. set this to 0.5
			RXTAB_Adjust.Main_Size_Y = 1 -- 1 Mean 100% fit to your screen. screen will cover your screen. if you want half size. set this to 0.5
		-- Main Screen Main Text.
			RXTAB_Adjust.Main_MainText = "TAB Menu"
			RXTAB_Adjust.Site_URL = "www.google.com"
			
		-- Group Replacement
			RXTAB_Adjust.GroupReplacement = {}
			RXTAB_Adjust.GroupReplacement["admin"] = "AdMiN"
			RXTAB_Adjust.GroupReplacement["superadmin"] = "Superman"