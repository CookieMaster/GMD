if CLIENT then
local PANEL = {}

function RXTAB_Open_JobSelector(Parent)
	GAMEMODE.ConnectedPlayersPanel = vgui.Create("RXTAB_M_Players",Parent)
	GAMEMODE.ConnectedPlayersPanel:SetSize(Parent:GetWide(),Parent:GetTall())
	return GAMEMODE.ConnectedPlayersPanel
end
function PANEL:Init()

end
function PANEL:Paint()
	surface.SetDrawColor( 0,0,0,100 )
	surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
	self:DrawBoarder()
end

function PANEL:Install()
	self:SetDraggable(false)
	self:ShowCloseButton(false)
	self:SetTitle(" ")
	self.HasParent = HasParent
	self.TopLabel = vgui.Create( "DPanel" , self)
	self.TopLabel:SetPos(2,2)
	self.TopLabel:SetSize( self:GetWide(),40 )
	self.TopLabel.Paint = function(slf)
			surface.SetDrawColor( 255,255,255,20 )
			surface.DrawRect( 1, 39, slf:GetWide()-2, 1 )
		draw.SimpleText("Players", "SansationOut_S40", 20,20, Color(0,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	self.ItemList = vgui.Create("DPanelList", self)
		self.ItemList:SetPos(10,50)
		self.ItemList:SetSize(self:GetWide()-20,self:GetTall() - 60)
		self.ItemList:SetSpacing(3);
		self.ItemList:SetPadding(0);
		self.ItemList:EnableVerticalScrollbar(true);
		self.ItemList:EnableHorizontal(false);
		self.ItemList:PaintListBarC()
		self.ItemList.Paint = function(slf)
			surface.SetDrawColor( 0,0,0,50 )
			surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		end
	
	if RXTPC_NeedUpdate() then 
		RXTPC_RequestPCount_2S() 
	end
	self:UpdateList()
end

function PANEL:PlayerClick(target)
	self.ItemList:Clear()
	local Nick = target:Nick()
	self.TopLabel.Paint = function(slf)
		surface.SetDrawColor( 255,255,255,20 )
		surface.DrawRect( 1, 39, slf:GetWide()-2, 1 )
		draw.SimpleText("Manage Player : " .. Nick, "SansationOut_S40", 20,20, Color(0,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end


	local function CreateLabel(text)
		local Labels = vgui.Create("DPanel")
			Labels:SetSize(self.ItemList:GetWide()-20,30)
			Labels.Paint = function(slf)
				surface.SetDrawColor( 0,0,0,180 )
				surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
				draw.SimpleText(text, "SansationOut_S20", 10,5, Color(255,255,255,255))

				surface.SetDrawColor( 255,255,255,180 )
				surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
			end
		self.ItemList:AddItem(Labels)
		return Labels
	end
	
	local function CreateDarkRPBasicFunc()
		
		local Count = 0
		for k,v in pairs(FAdmin.ScoreBoard.Player.ActionButtons) do
			if v.Visible == true or (type(v.Visible) == "function" and v.Visible(target) == true) then
				Count = Count + 1
			end
		end
		
		local BGP = vgui.Create("DPanel")
		BGP:SetSize( self.ItemList:GetWide(), math.ceil(Count/4)*55 )
		BGP.Paint = function() end

			local Count = 0
			for k,v in pairs(FAdmin.ScoreBoard.Player.ActionButtons) do
				if v.Visible == true or (type(v.Visible) == "function" and v.Visible(target) == true) then
					Count = Count + 1
					local ActionButton = vgui.Create("RXTAB_DSWButton",BGP)
					local name = v.Name
					if type(name) == "function" then name = name(target) end
					ActionButton:SetSize( self.ItemList:GetWide()/4-5, 50 )
					ActionButton:SetPos((Count-1)%4 * (ActionButton:GetWide()+5),math.ceil(Count/4)*55 -50)
					ActionButton:SetTexts(name)
					ActionButton:PanelAnim_Fade({Speed=0.5,Fade=1,Delay=math.Rand(0,0.2)})
					
					ActionButton.m_Image = vgui.Create("DImage", ActionButton)
					ActionButton.m_Image:SetPos(2,2)
					ActionButton.m_Image:SetSize(36,36)
					ActionButton.SetImage = function(self,Mat, bckp)
						self.m_Image:SetImage(Mat, bckp)
					end

					ActionButton.m_Image2 = vgui.Create("DImage", ActionButton)
					ActionButton.m_Image2:SetPos(2,2)
					ActionButton.m_Image2:SetSize(36,36)
					ActionButton.SetImage2 = function(self,Mat, bckp)
						self.m_Image2:SetImage(Mat, bckp)
					end
					
					if type(v.Image) == "string" then
						ActionButton:SetImage(v.Image or "icon16/exclamation")
					elseif type(v.Image) == "table" then
						ActionButton:SetImage(v.Image[1])
						if v.Image[2] then ActionButton:SetImage2(v.Image[2]) end
					elseif type(v.Image) == "function" then
						local img1, img2 = v.Image(LocalPlayer())
						ActionButton:SetImage(img1)
						if img2 then ActionButton:SetImage2(img2) end
					else
						ActionButton:SetImage("icon16/exclamation")
					end
					
					ActionButton.SetText = function(self,text)
						self:SetTexts(text)
					end
					ActionButton.Click = function(self)
						return v.Action(target, self)
					end
					if v.OnButtonCreated then
						v.OnButtonCreated(target, ActionButton)
					end
				end

			
			end
		self.ItemList:AddItem(BGP)
	end
	
	CreateLabel("DarkRP Basic")
	CreateDarkRPBasicFunc()
	
	/*
	for k,v in pairs(FAdmin.ScoreBoard.Player.ActionButtons) do
			
		if v.Visible == true or (type(v.Visible) == "function" and v.Visible(target) == true) then
			local ActionButton = vgui.Create("RXTAB_DSWButton")
			local name = v.Name
			if type(name) == "function" then name = name(target) end
			ActionButton:SetSize(200,40)	
			ActionButton:SetTexts(name)
			ActionButton:SetBoarderColor(v.color or Color(255,255,255,255))

			ActionButton.m_Image = vgui.Create("DImage", ActionButton)
			ActionButton.m_Image:SetPos(2,2)
			ActionButton.m_Image:SetSize(36,36)
			ActionButton.SetImage = function(self,Mat, bckp)
				self.m_Image:SetImage(Mat, bckp)
			end

			ActionButton.m_Image2 = vgui.Create("DImage", ActionButton)
			ActionButton.m_Image2:SetPos(2,2)
			ActionButton.m_Image2:SetSize(36,36)
			ActionButton.SetImage2 = function(self,Mat, bckp)
				self.m_Image2:SetImage(Mat, bckp)
			end
			
			if type(v.Image) == "string" then
				ActionButton:SetImage(v.Image or "icon16/exclamation")
			elseif type(v.Image) == "table" then
				ActionButton:SetImage(v.Image[1])
				if v.Image[2] then ActionButton:SetImage2(v.Image[2]) end
			elseif type(v.Image) == "function" then
				local img1, img2 = v.Image(LocalPlayer())
				ActionButton:SetImage(img1)
				if img2 then ActionButton:SetImage2(img2) end
			else
				ActionButton:SetImage("icon16/exclamation")
			end
			
			ActionButton.SetText = function(self,text)
				self:SetTexts(text)
			end
			ActionButton.Click = function(self)
				return v.Action(target, self)
			end
			self.ItemList:AddItem(ActionButton)
			if v.OnButtonCreated then
				v.OnButtonCreated(target, ActionButton)
			end
		end


	end
	*/
end

function PANEL:UpdateList()
	self.ItemList:Clear()
	local List = self.ItemList
		local function AddPlayer(target,count)
			local TNick = target:Nick()
			local BGP = vgui.Create("RXTAB_DSWButton")
			BGP:SetSize(List:GetWide(),50)
			BGP:SetBoarderColor(Color(0,0,0,0))
			BGP.PaintOverlay = function(slf)
				surface.SetDrawColor( 0,180,255,10 )
				surface.DrawRect( 1, slf:GetTall()-1, slf:GetWide()-2, 1 )
				if target:IsValid() then
					draw.SimpleText(TNick, "SansationOut_S30", 80,-3, Color(0,200,255,255))
					local UG = target:GetNWString("usergroup")
					if RXTAB_Adjust.GroupReplacement[UG] then
						UG = RXTAB_Adjust.GroupReplacement[UG]
					end
					draw.SimpleText(team.GetName(target:Team()) .. " , " .. UG, "SansationOut_S25", 80,20, Color(0,200,255,255))
					draw.SimpleText(target:Frags() .. " Kills", "SansationOut_S20", slf:GetWide()-10,5, Color(0,200,255,255),TEXT_ALIGN_RIGHT)
					draw.SimpleText(target:Deaths() .. " Deaths", "SansationOut_S20", slf:GetWide()-10,25, Color(0,200,255,255),TEXT_ALIGN_RIGHT)
					draw.SimpleText("Ping", "SansationOut_S20", slf:GetWide()-180,5, Color(0,200,255,255),TEXT_ALIGN_RIGHT)
					draw.SimpleText(target:Ping(), "SansationOut_S20", slf:GetWide()-180,25, Color(0,200,255,255),TEXT_ALIGN_RIGHT)
					draw.SimpleText("Props", "SansationOut_S20", slf:GetWide()-300,5, Color(0,200,255,255),TEXT_ALIGN_RIGHT)
					draw.SimpleText(RXTPC_GetPropCount(target,"prop_physics"), "SansationOut_S20", slf:GetWide()-300,25, Color(0,200,255,255),TEXT_ALIGN_RIGHT)
				end
			end
			BGP.Click = function(slf)
				self:PlayerClick(target)
			end
			BGP:PanelAnim_Fade({Speed=0.5,Fade=1,Delay=count/30})
			
			local icon = vgui.Create("ModelImage",BGP)
			icon:SetSize(BGP:GetTall(),BGP:GetTall())
			local IconModel = target:GetModel()
			icon:SetModel(IconModel)
					icon.OnCursorEntered = function(slf) 
						slf.Hover = true 
						local IP = slf:RXTAB_CreateHoverInfoPanel()
						IP:SetSize(550,270)
						IP.Paint = function(slf)
							surface.SetDrawColor( 0,0,0,200 )
							surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
							slf:DrawBoarder()
								
						local UG = target:GetNWString("usergroup")
						if RXTAB_Adjust.GroupReplacement[UG] then
							UG = RXTAB_Adjust.GroupReplacement[UG]
						end
							
							draw.SimpleText(TNick, "SansationOut_S30", 140,20, Color(0,200,255,255))
							draw.SimpleText("Steam ID : " .. target:SteamID(), "SansationOut_S20", 148,60, Color(0,200,255,255))
							draw.SimpleText("Rank : " .. UG, "SansationOut_S20", 148,80, Color(0,200,255,255))
							draw.SimpleText("Job : " .. team.GetName(target:Team()), "SansationOut_S20", 148,100, Color(0,200,255,255))
							draw.SimpleText("Props : " .. RXTPC_GetPropCount(target,"prop_physics"), "SansationOut_S20", 148,150, Color(0,200,255,255))
							local LUG = LocalPlayer():GetNWString("usergroup")
							if LUG == "owner" or LUG == "superadmin" or LUG == "admin" then
								local TargetMoney = target:getDarkRPVar("money")
								draw.SimpleText("Money : " .. string.Comma(TargetMoney), "SansationOut_S20", 148,170, Color(0,200,255,255))
							end
						end

						local AIG = vgui.Create("AvatarImage",IP)
						AIG:SetPos(25,25)
						AIG:SetSize(100,100)
						AIG:SetPlayer(target,64)
						
						local PMD = vgui.Create( "RXTAB_PlayerModelDrawer", IP )
							PMD:SetPos( IP:GetWide() - IP:GetTall()/1.3, 0)
							PMD:SetSize( IP:GetTall()/1.2, IP:GetTall()*1.15 )
							PMD:SetUp()
							PMD.PMEntity:SetModel(IconModel)
					end
			self.ItemList:AddItem(BGP)
		end
	
		local TBIns = {}
		for k,v in pairs(player.GetAll()) do
			table.insert(TBIns,{P=v,T=v:Team()})
		end
		table.SortByMember(TBIns, T, function(a, b) return a > b end)
		
		for k,v in pairs(TBIns) do
			AddPlayer(v.P,k)
		end
	
end
vgui.Register("RXTAB_M_Players",PANEL,"DFrame")

end