if CLIENT then
local PANEL = {}

function RXTAB_Open_ServerSetting(Parent)
	GAMEMODE.ConnectedPlayersPanel = vgui.Create("RXTAB_M_Serversetting",Parent)
	GAMEMODE.ConnectedPlayersPanel:SetSize(Parent:GetWide(),Parent:GetTall())
	return GAMEMODE.ConnectedPlayersPanel
end
function PANEL:Init()

end
function PANEL:Paint()
	surface.SetDrawColor( 0,0,0,100 )
	surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
	self:DrawBoarder()
end

function PANEL:Install()
	self:SetDraggable(false)
	self:ShowCloseButton(false)
	self:SetTitle(" ")
	self.HasParent = HasParent
	self.TopLabel = vgui.Create( "DPanel" , self)
	self.TopLabel:SetPos(2,2)
	self.TopLabel:SetSize( self:GetWide(),40 )
	self.TopLabel.Paint = function(slf)
			surface.SetDrawColor( 255,255,255,20 )
			surface.DrawRect( 1, 39, slf:GetWide()-2, 1 )
		draw.SimpleText("Server Setting", "SansationOut_S40", 20,20, Color(0,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	self.ItemList = vgui.Create("DPanelList", self)
		self.ItemList:SetPos(10,50)
		self.ItemList:SetSize(self:GetWide()-20,self:GetTall() - 60)
		self.ItemList:SetSpacing(3);
		self.ItemList:SetPadding(0);
		self.ItemList:EnableVerticalScrollbar(true);
		self.ItemList:EnableHorizontal(false);
		self.ItemList:PaintListBarC()
		self.ItemList.Paint = function(slf)
			surface.SetDrawColor( 0,0,0,50 )
			surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		end
		
	self:UpdateList()
end

function PANEL:UpdateList()
	self.ItemList:Clear()
	local List = self.ItemList

	local function CreateLabel(text)
		local Labels = vgui.Create("DPanel")
			Labels:SetSize(self.ItemList:GetWide()-20,30)
			Labels.Paint = function(slf)
				surface.SetDrawColor( 0,0,0,180 )
				surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
				draw.SimpleText(text, "SansationOut_S20", 10,5, Color(255,255,255,255))

				surface.SetDrawColor( 255,255,255,180 )
				surface.DrawRect( 0, slf:GetTall()-1, slf:GetWide(), 1 )
			end
		self.ItemList:AddItem(Labels)
		return Labels
	end
	
	local function CreateOptionBox(DATA,Type)
	
		local Count = 0
		for k,v in pairs(DATA) do
			if v.TYPE == Type then
				if v.TYPE == Type and v.Visible == true or (type(v.Visible) == "function" and v.Visible() == true) then
					Count = Count + 1
				end
			end
		end
	
		local BGP = vgui.Create("DPanel")
		BGP:SetSize( self.ItemList:GetWide(), math.ceil(Count/3)*75 )
		BGP.Paint = function() end
		
			local Count = 0
			for k,v in pairs(DATA) do
				if v.TYPE == Type then
				if v.Visible == true or (type(v.Visible) == "function" and v.Visible() == true) then
				Count = Count + 1
					local name = v.Name
					if type(name) == "function" then name = name() end
				
						local ActionButton = vgui.Create( "RXTAB_DSWButton",BGP )
							ActionButton:SetSize( self.ItemList:GetWide()/3-10, 70 )
							ActionButton:SetPos((Count-1)%3 * (ActionButton:GetWide()+5),math.ceil(Count/3)*75 -70)
							ActionButton:SetTexts( name )
							ActionButton.SetText = function(slf,txt) slf:SetTexts(txt) end
							ActionButton.Click = function(slf)
								return v.Action(slf)
							end
							ActionButton:PanelAnim_Fade({Speed=0.5,Fade=1,Delay=math.Rand(0,0.2)})
							
							ActionButton.m_Image1 = vgui.Create("DImage", ActionButton)
							ActionButton.m_Image1:SetPos(10,15)
							ActionButton.m_Image1:SetSize(40,40)
							ActionButton.SetImage = function(self,Mat, bckp)
								self.m_Image1:SetImage(Mat, bckp)
							end

							ActionButton.m_Image2 = vgui.Create("DImage", ActionButton)
							ActionButton.m_Image2:SetPos(10,15)
							ActionButton.m_Image2:SetSize(40,40)
							ActionButton.SetImage2 = function(self,Mat, bckp)
								self.m_Image2:SetImage(Mat, bckp)
							end
							
							if type(v.Image) == "string" then
								ActionButton:SetImage(v.Image or "icon16/exclamation")
							elseif type(v.Image) == "table" then
								ActionButton:SetImage(v.Image[1])
								if v.Image[2] then ActionButton:SetImage2(v.Image[2]) end
							elseif type(v.Image) == "function" then
								local img1, img2 = v.Image(LocalPlayer())
								ActionButton:SetImage(img1)
								if img2 then ActionButton:SetImage2(img2) end
							else
								ActionButton:SetImage("icon16/exclamation")
							end
				end
				end
			end
				self.ItemList:AddItem(BGP)
	end
	
	CreateLabel("Server Setting")
	CreateOptionBox(FAdmin.ScoreBoard.Server.ActionButtons,"ServerSettings")

	CreateLabel("Server Actions")
	CreateOptionBox(FAdmin.ScoreBoard.Server.ActionButtons,"ServerActions")

	CreateLabel("Player Actions")
	CreateOptionBox(FAdmin.ScoreBoard.Server.ActionButtons,"PlayerActions")

	
end
vgui.Register("RXTAB_M_Serversetting",PANEL,"DFrame")

end