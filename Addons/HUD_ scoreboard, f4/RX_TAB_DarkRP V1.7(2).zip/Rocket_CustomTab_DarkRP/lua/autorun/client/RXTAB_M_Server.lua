if CLIENT then
local PANEL = {}

function RXTAB_Open_Server(Parent)
	GAMEMODE.ConnectedPlayersPanel = vgui.Create("RXTAB_M_Server",Parent)
	GAMEMODE.ConnectedPlayersPanel:SetSize(Parent:GetWide(),Parent:GetTall())
	return GAMEMODE.ConnectedPlayersPanel
end
function PANEL:Init()

end
function PANEL:Paint()
	surface.SetDrawColor( 0,0,0,100 )
	surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
	self:DrawBoarder()
end

function PANEL:Install()
	self:SetDraggable(false)
	self:ShowCloseButton(false)
	self:SetTitle(" ")
	self.HasParent = HasParent
	self.TopLabel = vgui.Create( "DPanel" , self)
	self.TopLabel:SetPos(2,2)
	self.TopLabel:SetSize( self:GetWide(),40 )
	self.TopLabel.Paint = function(slf)
			surface.SetDrawColor( 255,255,255,20 )
			surface.DrawRect( 1, 39, slf:GetWide()-2, 1 )
		draw.SimpleText(GetHostName(), "SansationOut_S40", 20,20, Color(0,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	
	self.ItemList = vgui.Create("DPanelList", self)
		self.ItemList:SetPos(10,50)
		self.ItemList:SetSize(self:GetWide()-20,self:GetTall() - 60)
		self.ItemList:SetSpacing(3);
		self.ItemList:SetPadding(0);
		self.ItemList:EnableVerticalScrollbar(true);
		self.ItemList:EnableHorizontal(false);
		self.ItemList:PaintListBarC()
		self.ItemList.Paint = function(slf)
			surface.SetDrawColor( 0,0,0,50 )
			surface.DrawRect( 0, 0, slf:GetWide(), slf:GetTall() )
		end
		
	self:UpdateList()
end

function PANEL:UpdateList()
	self.ItemList:Clear()
	local List = self.ItemList

	local BGP = vgui.Create("DPanel")
		BGP:SetSize(self.ItemList:GetWide(),500)
		BGP.Paint = function(slf)

		end
			self.ItemList:AddItem(BGP)

	
end
vgui.Register("RXTAB_M_Server",PANEL,"DFrame")

end