local function RXTAB_Open()
	
	if !RXTAB or !RXTAB:IsValid() then
		RXTAB = vgui.Create("RXTAB_Main")
		RXTAB:SetSize(ScrW()*RXTAB_Adjust.Main_Size_X, ScrH()*RXTAB_Adjust.Main_Size_Y)
		RXTAB:Center()
		RXTAB:MakePopup()
	else
		RXTAB:Remove()
	end
end
local function RXTAB_Close()
	if RXTAB or RXTAB:IsValid() then
		RXTAB:Remove()
	end
end


// =============================================== Inventory Main ==============================================================================================
local PANEL = {}

function PANEL:Paint()
	surface.SetDrawColor( 0,0,0,245 )
	surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
	self:DrawBoarder(2)
	
	draw.SimpleText(RXTAB_Adjust.Main_MainText, "SansationOut_S55", 50,15, Color(255,255,255,255))
	surface.SetDrawColor( 255,255,255,180 )
	surface.DrawRect( 50, 70, self:GetWide()-100, 1 )
	
	draw.SimpleText(GetHostName(), "SansationOut_S35", self:GetWide()-60,15, Color(255,255,255,255),TEXT_ALIGN_RIGHT)
	draw.SimpleText(#player.GetAll().." / "..GetConVarString("maxplayers") .. " Players on " .. game.GetMap(), "SansationOut_S25", self:GetWide()-60,48, Color(255,255,255,255),TEXT_ALIGN_RIGHT)
end

function PANEL:Initialize()

end
function PANEL:Init()
local MainPanel = self
	self:SetTitle(" ")
	self:ShowCloseButton(false)
	self:SetDraggable(false)
			
	local MenuList = vgui.Create( "DPanelList" , self)
	MenuList:SetPos( 20,90 )
	MenuList:SetSize( 220,ScrH()-150)
	MenuList:SetSpacing(10);
	MenuList:SetPadding(2);
	MenuList:EnableVerticalScrollbar(true);
	MenuList:EnableHorizontal(false);
	MenuList.Paint = function(slf)
	end
	MenuList:PaintListBar("WhiteLine")
	local Menus = {}
		table.insert(Menus,{M="RolePlay",Title = true})
		table.insert(Menus,{M="Players",P= function(PN) return RXTAB_Open_JobSelector(PN) end})

		table.insert(Menus,{M="Server",Title = true})
		table.insert(Menus,{M="Settings",P= function(PN) return RXTAB_Open_ServerSetting(PN) end})
		table.insert(Menus,{M="Site",P= function(PN) return RXTAB_Open_HTML(PN) end})
		local Widths = 10
		for k,v in pairs(Menus) do
			if v.Blank then
				local Blank = vgui.Create("DPanel")
				Blank:SetSize(MenuList:GetWide(),40)
				Blank.Paint = function(slf) end
				MenuList:AddItem(Blank)
				continue
			end
			if v.Title then
				local Title = vgui.Create("DPanel")
				Title:SetSize(MenuList:GetWide(),25)
				Title.Paint = function(slf) 
					draw.SimpleText(v.M, "SansationOut_S25", 0,0, Color(0,255,255,255))
				end
				Title:PanelAnim_Fade({Dir="FromLeft",Speed=0.5,Fade=1,Delay=k/10})
				MenuList:AddItem(Title)
				continue
			end
			local SButton = vgui.Create( "RXTAB_DSWButton" )
				SButton:SetSize( MenuList:GetWide() , 40 )
				SButton:SetTexts( v.M )
				SButton:SetHoverAnim(1)
				SButton:SetExitAnim(1)
				SButton:SetClickAnim(1)
				SButton.Click = function(slf)
					MainPanel:UpdateMenu(v.M,v.P)
				end
				SButton.PaintBackGround = function(slf)
					if (self.Menus or "d") == v.M then
						surface.SetDrawColor( 0,150,255,50 )
						surface.DrawRect( 0, 0, self:GetWide(), self:GetTall() )
					end
				end
				SButton:PanelAnim_Fade({Dir="FromLeft",Speed=0.5,Fade=1,Delay=k/10})
			MenuList:AddItem(SButton)
		end
	timer.Simple(0.1,function(slf)
		if self and self:IsValid() then
			self:UpdateMenu(Menus[2].M,Menus[2].P)
		end
	end)
end

function PANEL:Install()

end

function PANEL:UpdateMenu(ModeName,ExecuteD)
	self.Menus = ModeName
	if self.MenuPanel then
		self.MenuPanel:Remove()
	end
	local P = ExecuteD(self)
		P:SetPos(250,90)
		P:SetSize(self:GetWide()-260,self:GetTall()-110)
		P:Install(true)
		P.ModeName = ModeName
	self.MenuPanel = P
end

vgui.Register("RXTAB_Main",PANEL,"DFrame")

function RXTAB_Override()
	CreateClientConVar("FAdmin_IsScoreboard", 0, false, false) -- Set if it's a scoreboard or not
	hook.Remove("ScoreboardShow", "FAdmin_scoreboard")
	hook.Remove("ScoreboardHide", "FAdmin_scoreboard")
	GAMEMODE.ScoreboardShow = RXTAB_Open
	GAMEMODE.ScoreboardHide = RXTAB_Close
end
hook.Add( "InitPostEntity", "RXTAB Load", function(w)
	MsgN("RX >> RocketMania's TAB Menu for DarkRP has been installed")
	
	-- sometime, some people said ' i can't see new tab menu! ' so i decided to do this
	-- this code looks sucks but i think this code will be kill darkrp basic menu ( i hope :P )
	for k=1,15 do
		timer.Simple(k,function() RXTAB_Override() end)
	end
end)