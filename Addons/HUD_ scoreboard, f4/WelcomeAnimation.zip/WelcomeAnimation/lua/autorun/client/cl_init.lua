include("autorun/config.lua")
--[[---------------------------------------------------------
    Name: Welcome Animation by Hillzy
    Desc: Cool way to introduce a player to your server
-----------------------------------------------------------]]

surface.CreateFont( "superlarge", {
 font = "BEBAS__",
 size = 98,
 weight = 5000,
 blursize = 1,
 scanlines = 0,
 antialias = true,
 underline = false,
 italic = false,
 strikeout = false,
 symbol = false,
 rotary = false,
 shadow = false,
 additive = false,
 outline = false
} )

surface.CreateFont( "medium", {
 font = "BEBAS__",
 size = 32,
 weight = 5000,
 blursize = 1,
 scanlines = 0,
 antialias = true,
 underline = false,
 italic = false,
 strikeout = false,
 symbol = false,
 rotary = false,
 shadow = false,
 additive = false,
 outline = false
} )

local pressed = input.IsMouseDown( MOUSE_LEFT )
local pressedright = input.IsMouseDown( MOUSE_RIGHT )
function WelcomeAnimation()
	WAx = ScrW()
	WAy = ScrH()
	--[ HB =  Welcome Base ]--
	HB = vgui.Create("DPanel")
	HB:SetSize(WAx/1.3, 220)
	HB:SetPos(WAx + 1000, WAy/2 )
	HB:SetVisible(true)
	HB.Paint = function()
	surface.SetDrawColor(glow)
	surface.SetMaterial(Material("rightglow.png"))
	surface.DrawTexturedRect(3, 2.5, HB:GetWide() - 5,HB:GetTall() - 5)
	surface.SetDrawColor(255,255,255)
	surface.SetMaterial(Material("rightA.png"))
	surface.DrawTexturedRect(0, 0, HB:GetWide(),HB:GetTall())
	draw.SimpleText(ServerName, "superlarge", ServerNamePos,105, ServerNameColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	if DisplayServerName2 == true then
	draw.SimpleText(ServerName2, "superlarge", ServerName2Pos,105, ServerName2Color, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	end
	--[ WB =  HyperVenom Base ]--
	WB = vgui.Create("DPanel")
	WB:SetSize(WAx/1.3, 220)
	WB:SetPos(-1250, WAy/2 - 300)
	WB:MoveTo( 0, WAy/2 - 300, 2, 0, 3)
	WB:SetVisible(true)
	WB.Paint = function()
	surface.SetDrawColor(glow)
	surface.SetMaterial(Material("leftglow.png"))
	surface.DrawTexturedRect(4, 2.5, WB:GetWide() - 5, WB:GetTall() - 5 ) 
	surface.SetDrawColor(255,255,255)
	surface.SetMaterial(Material("leftA.png"))
	surface.DrawTexturedRect(0, 0, WB:GetWide(), WB:GetTall()) 
	draw.SimpleText(WelcomeText, "superlarge", 335,105, WelcomeTextColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	
	if Default == true then
		timer.Simple(5, function()
			HB:MoveTo( ScrW() + 1000, WAy/2, 2, 0, 3)
			WB:MoveTo( - 1100, WAy/2 - 300, 1.7, 0, 3)
			timer.Simple(3, function()
					HB:SetVisible(false)
					WB:SetVisible(false)
			end)
		end)
	elseif ButtonMethod == true then
	timer.Simple(4, function()
		--[CB = Continue Button]--
		CB = vgui.Create("DButton")
		CB:SetPos( ScrW()/2 - 75, ScrH()/2 - 65)
		CB:SetText( "" )
		CB:SetSize( 150, 50 )
		CB:MakePopup()
		CB.Paint = function()
			draw.RoundedBox(4, 0,0, CB:GetWide(), CB:GetTall(), Color(56, 56, 56))
			draw.SimpleText("Continue", "medium", 15,7,Color(189,189,189))
		end
		function CB:OnCursorEntered()
				function self:Paint()
					draw.RoundedBox(4,0,0,self:GetWide(), self:GetTall(),glow)
					draw.SimpleText("Continue", "medium", 15,7,Color(189,189,189))
				end
		end
		function CB:OnCursorExited()
			function self:Paint()
				draw.RoundedBox(4, 0,0, CB:GetWide(), CB:GetTall(), Color(56, 56, 56))
				draw.SimpleText("Continue", "medium", 15,7,Color(189,189,189))
			end
	
		end
		CB.DoClick = function()
		surface.PlaySound("/buttons/button14.wav")
		CB:SetVisible(false)
			timer.Simple(1, function()
				surface.PlaySound("swoosh.mp3")
				HB:MoveTo( WAx + 1000, WAy/2, 2, 0, 3)
				WB:MoveTo( -1100, WAy/2 - 300, 1.7, 0, 3)
				timer.Simple(3, function()
					HB:SetVisible(false)
					WB:SetVisible(false)
				end)
			end)
		end 
	end)
	end
	
	
	
	timer.Simple(1, function()
		HB:MoveTo( WAx/2 - 360, WAy/2, 2, 0, 3)
		
	end)	
	timer.Simple(1.5, function()
		surface.PlaySound("swoosh.mp3")
	end)	
	timer.Simple(0.5, function()
		surface.PlaySound("swoosh.mp3")
	end)
	
end
usermessage.Hook("WAS", WelcomeAnimation)
