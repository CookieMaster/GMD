AddCSLuaFile( "autorun/client/cl_init.lua" )
AddCSLuaFile( "autorun/config.lua" )

include("autorun/config.lua")


--[Send files to the client for download]--
resource.AddFile("materials/rightA.png")
resource.AddFile("materials/leftA.png")
resource.AddFile("materials/rightglow.png")
resource.AddFile("materials/leftglow.png")
resource.AddFile("sound/swoosh.mp3")
resource.AddFile("resource/fonts/BEBAS__.TTF")

util.PrecacheSound("swoosh.mp3")

function WelcomeAnimation( ply )
	timer.Simple(Delay, function()
	umsg.Start("WAS",ply)
	umsg.End()
	end)
end
hook.Add( "PlayerInitialSpawn", "WelcomeAnimation", WelcomeAnimation )


concommand.Add("WA_preview", WelcomeAnimation)