--[[---------------------------------------------------------
    Name: Welcome Animation by Hillzy
    Desc: Cool way to introduce a player to your server
-----------------------------------------------------------]]
--[[
Customization
To customize this HUD all you need to do is open hud.lua and look to the top of the file. You will see a bunch of variables, each with is own colour value. 
E.g. 
local ServerTag = Color(0,0,0). 
The three 0's represent the RGB colour values, R being red, G being green and B being blue. 
To pick my colours I like to use this tool: http://www.rgbtool.com/
Simply select a colour then look the right of colour picker and you will see the RGB, you only need the first column.
Place those numbers into  "Color(0,0,0) "
E.g. 
local ServerTag = Color(255,0,0)
This would give you red.
DO NOT CHANGE THE BLACK TEXT ("VARIABLE") only change the values after the = sign.
]]--

glow = Color(30, 144, 255) --The colour of the glow.
WelcomeTextColor = Color(189,189,189) --The colour the the text "welcome to"
ServerNameColor = Color(189,189,189) --The colour of the first part of the server name
ServerName2Color = glow --The colour of the second part of the server name, I suggest you keep it at the glow colour


WelcomeText = "WELCOME TO" 
ServerName = "๖ۣۜX|" --Servername Part 1
ServerName2 = "GAMERS" --Server Name Part 2 (Optional)

ServerNamePos = 380 --Making the number lower will move the text left, making it higher will move the text right. Use this if the text overlaps.
ServerName2Pos = 670 --Making the number lower will move the text left, making it higher will move the text right. Use this if the text overlaps.

DisplayServerName2 = true --Wether you want the servername2 to be displayed or not

Delay = 7 --The amount of time the welcome animation should wait until it plays when a player joins the server. I suggest leaving it at 7



--[Which method/s do you want]--

//ONLY ONE OF THESE MUST BE TRUE. IF YOU MAKE A CHANGE RESTART THE SERVER OR CHANGE MAP

Default = false --Will close the message after a certain amound of time, (5 seconds) 
ButtonMethod = true--Will display a "continue" button which the player has to click in order for the Welcome Message to close



