--Copyright Phoenixf129 2013.

print("[SSC] Loading Config...")

SSC = SSC or {} -- For my sanity.

--Scorpys Simple Chatbox Configuration
SSC.LabelText = "YOUR TITLE HERE"
SSC.WebUrl = "http://google.com"
SSC.DonateUrl = "http://google.com"

-- Images can be found here: 
-- http://www.glua.me/bin/?path=/materials/icon16

SSC.InfoIcon = "icon16/information.png" -- The Icon for Information messages.
SSC.ConsoleIcon = "icon16/application_xp_terminal.png" -- The Icon for Server Console messages.

-- True/False. False to see Avatar icons, True to see Rank icons.
SSC.RanksOverAvatars = true

-- True/False. False to disable PM system (/p name msg)
SSC.PMFunctionality = true

-- True/False. False to disable animated dropdown menu bar.
SSC.EnableDropDown = true

-- Fonts
SSC.Font_Message 	 = "ChatFont"
SSC.Font_ChatLabel	 = "DefaultBold"
SSC.Font_URL		 = "Default"


-- rank, icon. 
-- Should work with ALL Admin mods. Fallbacks to Player:IsAdmin() and Player:IsSuperAdmin() if no admin mod installed.
SSC.Ranks = {
	["root_user"]   = "icon16/shield_go.png",
	["superadmin"]  = "icon16/shield.png",
	["admin"]		= "icon16/star.png",
	["moderator"]	= "icon16/rainbow.png",
	["vip"] 		= "icon16/coins.png",
	["user"] 		= "icon16/user.png"
}
-- If you don't have an admin mod, OR one of your groups isn't set above, it will default to these listed below.
SSC.DefaultSuperAdminRankIcon = "icon16/shield.png"
SSC.DefaultAdminRankIcon = "icon16/star.png"
SSC.DefaultRankIcon = "icon16/user.png"

-- SKIN options
-- Only edit these if you know what you're doing!
SSC.BGColor = Color(0, 0, 0, 255)
SSC.OutlineColor = Color(0, 160, 255, 255)
SSC.FGColor = Color(255, 255, 255, 255)

SSC.OutlineGlow = 100

SSC.TextEntryTextColor = Color( 0, 0, 0, 255 )
SSC.TextEntryHighlightColor = Color( 0, 180, 255, 255 )
SSC.TextEntryCursorColor = Color( 0, 0, 0, 255 )

SSC.ChatTypeBGColor = Color(0,0,0,0)
SSC.ChatTypeColor = Color(255,0,0,0)

-- Button Configuration
SSC.Buttons = {}

-- name = The tooltip's title (mouseover to see tooltip)
-- icon = The icon you want to display
-- desc  = The tooltip's description (mouseover to see tooltip)
-- cmd   = The command to run when the button is clicked
-- To change these, just follow the format below.

-- Example Website button
SSC.Buttons[1] = {
   ["name"] = "Website",
   ["icon"] = "icon16/world_go.png",
   ["desc"]  = "Our website",
   ["cmd"]   = "ssc_loadsite",
}

--Example Donate button
SSC.Buttons[2] = {
	["name"] = "Donate",
	["icon"] = "icon16/coins.png",
	["desc"] = "Opens our Donate page in the Steam Overlay",
	["cmd"]  = "ssc_loaddonate",
}

--Example Pointshop button
SSC.Buttons[3] = {
	["name"] = "Shop",
	["icon"] = "icon16/emoticon_smile.png",
	["desc"] = "Opens Pointshop!",
	["cmd"]  = "ps_shop",
}

-- Commands for buttons

-- These are examples. You can add new/remove old if you wish, but remove the buttons too!
concommand.Add("ssc_loadsite", function()
	gui.OpenURL(SSC.WebUrl)
end)

concommand.Add("ssc_loaddonate", function()
	gui.OpenURL(SSC.DonateUrl)
end)
print("[SSC] Loading Complete!") --Debug for Auto-Refresh, which is now working.