--Copyright Phoenixf129 2013

-- All we need to do is call the init file for the chatbox.
include("scorpy_chatbox/sh_init.lua")