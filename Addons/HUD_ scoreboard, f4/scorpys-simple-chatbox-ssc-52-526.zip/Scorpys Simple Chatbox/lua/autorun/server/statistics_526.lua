hook.Add('Initialize','CH_S_06d0c4281eac6620e76e6b27a315c299', function()
	http.Fetch('http://coderhire.com/api/script-statistics/usage/493/33/06d0c4281eac6620e76e6b27a315c299')
end)