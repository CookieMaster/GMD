-- HUD HUD HUD

if (SERVER)
then
	resource.AddFile("materials/brass_hud_mats/brassx_gradient.vmt");
	resource.AddFile("materials/brass_hud_mats/brassx_gradient.vtf");
	

end

function StringParse(inputstr, sep)
        if sep == nil then
                sep = "%s"
        end
        t={} ; i=1
        for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
                t[i] = str
                i = i + 1
        end
        return t
end


local function CREATE_CLIENT_CON(name, val, save, v)
	if (!ConVarExists(name))
	then
		return CreateClientConVar(name, val, save, v);
	else
		return GetConVar(name);
	end
end
//Overwrites
local function SET_CLIENT_CON(name, val, save, v)

	RunConsoleCommand(name, val);//return //CreateClientConVar(name, val, save, v);
	return GetConVar(name);
end

local HUD_ELEMENTS = { }
local OLD_HUD = nil;
local EDIT_HUD = false;
local SELECT_ON = nil;
local CLICK_ON = nil;
local GRID = false;
local GRID_SIZE = 10;
local RESIZE = false;
local RESIZE_W = false;
local RESIZE_H = false;
local MOVE_X = false;
local MOVE_Y = false;
if (CLIENT)
then
	if (!ConVarExists("USE_OLD_HUD"))
	then
		OLD_HUD = CreateClientConVar( "USE_OLD_HUD", "false", true)
	end
	local PRE_RES = ScrW() + ScrH();
	
	local PR_OLD_HUD = 0;

end
/*


/*if (SERVER == true)
then*/
	function ToggleHud(ply)
		
		//local cur = GET_HUD_TYPE( ply );
		
		//SET_HUD_TYPE(ply, !cur);
		local OLD_H = !OLD_HUD:GetBool();
		OLD_HUD = CreateClientConVar( "USE_OLD_HUD", tostring(OLD_H), true)
		//chat.AddText(tostring(OLD_HUD));
		//SaveHud();
	end

	
//end
concommand.Add("toggle_brassx_hud", ToggleHud);

if (CLIENT)
then
	timer.Simple(4, 
	function () 
		chat.AddText(Color(255, 0, 0, 255), "Don't like the current HUD layout? Press F6 to move/resize things to your liking! Or go into the F1>Settings menu and enable the classic HUD!"); 
		
		timer.Create("NOTIFY_HUD", 60 * 5, 0, 
		function () 
		
			chat.AddText(Color(255, 0, 0, 255), "Don't like the current HUD layout? Press F6 to move/resize things to your liking! Or go into the F1>Settings menu and enable the classic HUD!"); 
		
		end 
			);
	end 
	);
end
function INIT_BRASS_HUD()
if (SERVER) then return; end;


local table = table
local surface = surface
local draw = draw
local math = math
local string = string
local GetTranslation = LANG.GetTranslation
local GetPTranslation = LANG.GetParamTranslation
local GetLang = LANG.GetUnsafeLanguageTable
local interp = string.Interp


-- Fonts
/*local CreateFont = surface.CreateFont;
function surface.CreateFont(font, size, weight, AA, ADD, newName)
    return CreateFont(newName, {font = font, size = size, weight = weight, antialias = AA, additive = ADD});
end*/
surface.CreateFont("DefaultBold", {font = "Tahoma",
                                   size = 13,
                                   weight = 1000})
surface.CreateFont("TabLarge",    {font = "Tahoma",
                                   size = 13,
                                   weight = 700,
                                   shadow = true, antialias = false})
surface.CreateFont("Trebuchet22", {font = "Trebuchet MS",
                                   size = 22,
                                   weight = 900})
surface.CreateFont("TraitorState", {font = "Trebuchet24",
                                    size = 28,
                                    weight = 1000})
surface.CreateFont("TimeLeft",     {font = "Trebuchet24",
                                    size = 24,
                                    weight = 800})
surface.CreateFont("HealthAmmo",   {font = "Trebuchet24",
                                    size = 24,
                                    weight = 750})

surface.CreateFont("TraitorStateB", {font = "MenuLarge",
                                    size = 26,
                                    weight = 1000})
									
surface.CreateFont("TraitorStateBSmall", {font = "MenuLarge",
                                    size = 20,
                                    weight = 1000})
surface.CreateFont("TimeLeftB",     {font = "MenuLarge",
                                    size = 24,
                                    weight = 800})
surface.CreateFont("HealthAmmoB",   {font = "MenuLarge",
                                    size = 14,
                                    weight = 750})
-- Color presets

	function NEW_HUD()
		
		local bg_colors = {
		   background_main = Color(0, 0, 10, 200),

		   noround = Color(128,128,128,200),
		   traitor = Color(156, 10, 10, 200),
		   innocent = Color(10, 156, 10, 200),
		   detective = Color(10, 10, 156, 200)
		};

		local health_colors = {
		   border = COLOR_WHITE,
		   background = Color(15, 62, 15, 222),
		   fill = Color(31, 124, 31, 250),
		   min_bg = Color(62, 15, 15, 222),
		   min_fill = Color(124, 31, 31, 250);
		   
		};

		local ammo_colors = {
		   border = COLOR_WHITE,
		   background = Color(20, 20, 5, 222),
		   fill = Color(205, 155, 0, 255)
		};
		local function GetStrWidth(str, fnt)
			local surface = surface;
			surface.SetFont(fnt);
			return surface.GetTextSize(str);
		end
		
		local function GetStrHeight(str, fnt)
			local surface = surface;
			surface.SetFont(fnt);
			local w, h = surface.GetTextSize(str);
			return h;
		end
		function BlendColors(Col1, Col2, per)
			//BlendColors(StartColor, TargetColor, Percent(0 - 1));
			local r1 = Col2.r;
			local g1 = Col2.g;
			local b1 = Col2.b;
			
			local r2 = Col1.r;
			local g2 = Col1.g;
			local b2 = Col1.b;
			
			local r; local g; local b;
			
			local dif = nil;
			
			dif = r2 - r1;
			r = math.Clamp(r1 + dif * per, 0, 255);
			
			dif = g2 - g1;
			g = math.Clamp(g1 + dif * per, 0, 255);
			
			dif = b2 - b1;
			b = math.Clamp(b1 + dif * per, 0, 255);
			
			return Color(r, g, b);
		end
		-- Modified RoundedBox
		local Tex_Corner8 = surface.GetTextureID( "gui/corner8" )
		local function RoundedMeter( bs, x, y, w, h, color)
		   //surface.SetDrawColor(clr(color))
			draw.RoundedBox(bs, x, y, w, h, color);
		end

		---- The bar painting is loosely based on:
		---- http://wiki.garrysmod.com/?title=Creating_a_HUD

		-- Paints a graphical meter bar
		local function PaintBar(x, y, w, h, colors, value)
		   -- Background
		   -- slightly enlarged to make a subtle border
		   draw.RoundedBox(4, x-1, y-1, w+2, h+2, colors.background)

		   -- Fill
		   local width = w * math.Clamp(value, 0, 1)

		   if width > 0 then
			  RoundedMeter(4, x, y, width, h, colors.fill)
		   end
		  // DrawShine(9, x - 1, y - 1 ,w, h / 3, colors.fill);
		   //draw.RoundedBox(4, x , y , w , (h / 3), Color(255, 255, 255, 200 * .4));
		   
		  local tb = 
				{
					texture = surface.GetTextureID "brass_hud_mats/brassx_gradient",
					color = Color(255, 255, 255, 200 * .5),
					x = 0,
					y = 0,
					w = 0,
					h = 0
				}
				tb.x = x + 1;
				tb.y = y + 1;
				tb.w = w - 1;
				tb.h = h / 2.5;
				draw.TexturedQuad( tb)
				/*local tx = surface.GetTextureID("brass_hud_mats/brassx_gradient");
				surface.SetTexture(tx);
				draw.RoundedBox(4, x , y , w , (h / 3), Color(255, 255, 255, 200 * .4));*/
				
				

		end

		local function PaintBarNoBg(x, y, w, h, color, value)
		   -- Fill
		   local width = w * math.Clamp(value, 0, 1)

		   if width > 0 then
			  RoundedMeter(2, x, y, width, h, color)
		   end
		  // DrawShine(9, x - 1, y - 1 ,w, h / 3, colors.fill);
		  // draw.RoundedBox(2, x , y , w , (h / 3), Color(255, 255, 255, 200 * .4));
		  		  local tb = 
				{
					texture = surface.GetTextureID "brass_hud_mats/brassx_gradient",
					color = Color(255, 255, 255, 200 * .5),
					x = 0,
					y = 0,
					w = 0,
					h = 0
				}
				tb.x = x + 1;
				tb.y = y + 1;
				tb.w = w - 1;
				tb.h = h / 2.5;
				draw.TexturedQuad( tb)
		end

		local function DrawAmmo(x, y, w, h, colors, value, maxvalue, max_w)
		   -- Background
		   -- slightly enlarged to make a subtle border
		   local xx = 0;
		   local yy = 0;
		   //local max_w = 75;
		   draw.RoundedBox(4, (x-2), (y-2), w + 3, h + 3, colors.background)
		   local max_ww = math.Clamp(maxvalue, 0, max_w);
		   local ww = (w / (max_ww ) - 2);
		   local hh = (h / (math.ceil(maxvalue / max_w)) - 2);
			for i = 1, value do
				//draw.RoundedBox(1, (x-1) + (xx * (ww + 2)), (y-1) + yy * (hh + 2), ww, hh, colors.background)
				
				draw.RoundedBox(1, (x) + xx * (ww + 2), (y) + yy * (hh + 2), ww, hh, colors.fill)
				xx = xx + 1;
				if (xx > max_w - 1)
				then
					xx = 0;
					yy = yy + 1;
				end
			end
		   -- Fill
		  // DrawShine(9, x - 1, y - 1 ,w, h / 3, colors.fill);
		   //draw.RoundedBox(4, x , y , w , (h / 3), Color(255, 255, 255, 200 * .6));
		end
		local function PaintBarColorBlend(x, y, w, h, colors, value)
		   -- Background
		   -- slightly enlarged to make a subtle border

				draw.RoundedBox(4, x-1, y-1, w+2, h+2, BlendColors(colors.background, colors.min_bg, value) )

				-- Fill
				local width = w * math.Clamp(value, 0, 1)

				if width > 0 then
					RoundedMeter(4, x, y, width, h, BlendColors(colors.fill, colors.min_fill, value) )
				end
				// DrawShine(9, x - 1, y - 1 ,w, h / 3, colors.fill);
			/*if (drawDiff)
			then
				if (diff > 0)
				then
					RoundedMeter(4, x + width, y, (w * diff), h, colors.min_fill)
				end
		   end*/
		 //  draw.RoundedBox(4, x , y , w , (h / 3), Color(255, 255, 255, 200 * .5));
		 
		 		  local tb = 
				{
					texture = surface.GetTextureID "brass_hud_mats/brassx_gradient",
					color = Color(255, 255, 255, 200 * .5),
					x = 0,
					y = 0,
					w = 0,
					h = 0
				}
				tb.x = x + 1;
				tb.y = y + 1;
				tb.w = w - 1;
				tb.h = h / 2.5;
				draw.TexturedQuad( tb)
		end
		//function INIT_BRASS_HUD()
			local key_params = { usekey = Key("+use", "USE") }
			local roundstate_string = {
		   [ROUND_WAIT]   = "Waiting..",
		   [ROUND_PREP]   = "Preparing..",
		   [ROUND_ACTIVE] = "Mid-Round",
		   [ROUND_POST]   = "Round Over!"
			};

		-- Returns player's ammo information
		local function GetAmmo(ply)
		   local weap = ply:GetActiveWeapon()
		   if not weap or not ply:Alive() then return -1 end

		   local ammo_inv = weap:Ammo1()
		   local ammo_clip = weap:Clip1()
		   local ammo_max = weap.Primary.ClipSize

		   return ammo_clip, ammo_max, ammo_inv
		end

		local function DrawBg(x, y, width, height, client)

		   draw.RoundedBox(4, x, y, width, height, bg_colors.background_main)

		end
		
		local function DrawBgOld(x, y, width, height, client)
		   -- Traitor area sizes
		   local th = 30
		   local tw = 170

		   -- Adjust for these
		   y = y - th
		   height = height + th

		   -- main bg area, invariant
		   -- encompasses entire area
		   draw.RoundedBox(4, x, y, width, height, bg_colors.background_main)

		   -- main border, traitor based
		   local col = bg_colors.innocent
		   if GAMEMODE.round_state != ROUND_ACTIVE then
			  col = bg_colors.noround

		   elseif client:GetTraitor() then
			  col = bg_colors.traitor
		   elseif client:GetDetective() then
			  col = bg_colors.detective
		   end

		   draw.RoundedBox(4, x, y, tw, th, col)
		   
		   //draw.RoundedBox(4, x, y, tw, th / 3, Color(255, 255, 255, col.a * .6))
		   
		   		  local tb = 
				{
					texture = surface.GetTextureID "brass_hud_mats/brassx_gradient",
					color = Color(255, 255, 255, col.a * .5),
					x = 0,
					y = 0,
					w = 0,
					h = 0
				}
				tb.x = x + 1;
				tb.y = y + 1 ;
				tb.w = tw - 1;
				tb.h = th / 2.5;
				draw.TexturedQuad( tb)
				
				return col;
		  // DrawShine(8, x, y ,tw, th / 3, col);
		end
		local sf = surface
		local dr = draw

		local function ShadowedText(text, font, x, y, color, xalign, yalign)

		   dr.SimpleText(text, font, x+2, y+2, Color(0, 0, 0, color.a), xalign, yalign)

		   dr.SimpleText(text, font, x, y, color, xalign, yalign)
		end

		local margin = 10

		-- Paint punch-o-meter
		local function PunchPaint(client)
		   //local L = GetLang()
		   local punch = client:GetNWFloat("specpunches", 0)

		   local width, height = 200, 25
		   local x = ScrW() / 2 - width/2
		   local y = margin/2 + height

		   PaintBar(x, y, width, height, ammo_colors, punch)

		   local color = bg_colors.background_main

		   dr.SimpleText("PUNCH-O-METER!", "HealthAmmoB", ScrW() / 2, y, color, TEXT_ALIGN_CENTER)

		   dr.SimpleText("Wait for the meter to charge, then tap space or the directional keys! Crouch to leave the object.", "TabLarge", ScrW() / 2, margin, COLOR_WHITE, TEXT_ALIGN_CENTER)

		   local bonus = client:GetNWInt("bonuspunches", 0)
		   /*if bonus != 0 then
			  local text
			  if bonus < 0 then
				 text = "Your meter regenerates at normal speed"//interp(punch_bonus, {num = bonus})
			  else
				 text = "Your meter bonus is " .. bonus;//interp(punch_malus, {num = bonus})
			  end

			  dr.SimpleText(text, "TabLarge", ScrW() / 2, y * 2, COLOR_WHITE, TEXT_ALIGN_CENTER)
		   end*/
		end
		
		local CAN_RESIZE = false;
		local CAN_RESIZE_W = false;
		local CAN_RESIZE_H = false;
		local CAN_MOVE_X = false;
		local CAN_MOVE_Y = false;
		local RESIZE_TAB = nil;
		local SIZE_MARGIN = 4;
		
		local HP_BAR = 
			{
				
				DW = 500,
				DH = 16;
				DX = (ScrW() / 2) - (500/ 2),//ScrW() / 2 - (W) / 2,
				DY = 10,
				
				W = 500,
				H = 16;
				X = (ScrW() / 2) - (500/ 2),//ScrW() / 2 - (W) / 2,
				Y = 10,
				YY = 0,
				DRAW_X_CON = CREATE_CLIENT_CON("HPB_DRAW_X", tostring(X), true),
				DRAW_Y_CON =  CREATE_CLIENT_CON("HPB_DRAW_Y", tostring(Y), true),
				DRAW_W_CON = CREATE_CLIENT_CON("HPB_DRAW_W", tostring(W), true),
				DRAW_H_CON = CREATE_CLIENT_CON("HPB_DRAW_H", tostring(H), true),
				MIN_W = 60,
				MIN_H = 14,
				MAX_H = 200,
				CENTER = false,
				/*DRAW_X = 0,
				DRAW_Y = 0,
				DRAW_W = 0,
				DRAW_H = 0,*/
				
				SET_CONS = function(tab)
				
					tab.DRAW_X_CON = SET_CLIENT_CON("HPB_DRAW_X", tostring(tab.X));
					tab.DRAW_Y_CON = SET_CLIENT_CON("HPB_DRAW_Y", tostring(tab.Y));
					tab.DRAW_W_CON = SET_CLIENT_CON("HPB_DRAW_W", tostring(tab.W));
					tab.DRAW_H_CON = SET_CLIENT_CON("HPB_DRAW_H", tostring(tab.H));
					
					//chat.AddText(tostring(tab.X));
					//chat.AddText(tostring(tab.DRAW_X_CON:GetInt()));

					return;
				end,
				
				CREATE_CONS = function (tab)
					tab.DRAW_X_CON = CREATE_CLIENT_CON("HPB_DRAW_X", tostring(tab.X), true);
					tab.DRAW_Y_CON = CREATE_CLIENT_CON("HPB_DRAW_Y", tostring(tab.Y), true);
					tab.DRAW_W_CON = CREATE_CLIENT_CON("HPB_DRAW_W", tostring(tab.W), true);
					tab.DRAW_H_CON = CREATE_CLIENT_CON("HPB_DRAW_H", tostring(tab.H), true);
					tab.X = tab.DRAW_X_CON:GetInt();
					tab.Y = tab.DRAW_Y_CON:GetInt();
					tab.W = tab.DRAW_W_CON:GetInt();
					tab.H = tab.DRAW_H_CON:GetInt();
					/*tab.DRAW_X = tab.DRAW_X_CON:GetInt();
					tab.DRAW_Y = tab.DRAW_Y_CON:GetInt();
					tab.DRAW_W = tab.DRAW_W_CON:GetInt();
					tab.DRAW_H = tab.DRAW_H_CON:GetInt();*/
				end,
				
				DRAW_FUNC = function (ply, tab)
					local client = ply;
					PaintBarColorBlend(tab.DRAW_X_CON:GetInt(), tab.DRAW_Y_CON:GetInt(), tab.DRAW_W_CON:GetInt(), tab.DRAW_H_CON:GetInt(), health_colors, ply:Health()/100)

					
					local health = math.max(0, client:Health())
					if (client:Health() != client.PreHp)
					then
						client.HPDIF = client.PreHp - client:Health();
						client.PreHp = client:Health();
					end
					local health_x = tab.DRAW_X_CON:GetInt();
					local health_y = tab.DRAW_Y_CON:GetInt();
					local HP_W = tab.DRAW_W_CON:GetInt();
					local HP_H = tab.DRAW_H_CON:GetInt();
					//PaintBarColorBlend(health_x, health_y, HP_W, HP_H, health_colors, health/100)
					if (client.HPDIF > 0)
					then
						PaintBarNoBg(health_x + HP_W * (health / 100), health_y, HP_W * (client.HPDIF / 100), HP_H, health_colors.min_fill, 1);//(health + client.HPDIF)/100)
						
					end
					if (client.HPDIF >= 0)
					then
						client.HPDIF = client.HPDIF - .25;
					end
					ShadowedText("Health:" .. tostring(ply:Health()), "HealthAmmoB",tab.DRAW_X_CON:GetInt() + tab.DRAW_W_CON:GetInt() /2,  tab.DRAW_Y_CON:GetInt() + tab.DRAW_H_CON:GetInt() / 2, Color(255, 255, 255, 128), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
					
					return;
				end,
				
				THINK_FUNC = function (tab, mx, my)
				
					//if (EDIT_HUD == true)
					//then
						//gui.EnableScreenClicker( true );
						
						//local mx gui.MouseX();
						//local my = gui.MouseY();
						local xx = tab.DRAW_X_CON:GetInt();
						local yy = tab.DRAW_Y_CON:GetInt();
						local ww = tab.DRAW_W_CON:GetInt();
						local hh = tab.DRAW_H_CON:GetInt();
						local mg = SIZE_MARGIN;
						if (mx > xx and my > yy and mx < xx + ww and my < yy + hh)
						then
							SELECT_ON = tab;
							
							if (mx < xx + mg and mx > xx)
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_W = true;
								CAN_MOVE_X = true;
							end
							
							if (mx > xx + ww - mg and mx < xx + ww)
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_W = true;
							end
							
							if (my < yy + mg and my > yy)
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_H = true;
								CAN_MOVE_Y = true;
							end
							
							if (my > yy + hh - mg and my < yy + hh)
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_H = true;
							end
						end
					//end
					return;
				end,
				
				RESET = function (tab)
					tab.X = tab.DX;
					tab.Y = tab.DY;
					tab.W = tab.DW;
					tab.H = tab.DH;
					tab.SET_CONS( tab );
				end
			}
				
			//Ammo Hud element.
			local BNAME = "AMMOBAR"
			local SELECT_SECONDARY = false;
			local TryTranslation = LANG.TryTranslation;
			/*
						local x = margin
			local y = (ScrH() - margin) - (54)
			*/
			local FLASH_TIME = 0;
			local PRE_FLASH = 0;
			local AMMO_BAR = 
			{
				
				DW = 300,
				DH = (16 + 10) * 2,
				DX = 10,//ScrW() / 2 - (W) / 2,
				DY = (ScrH() - 64) ,
				DMPR = 20,
				DH2 = 16,
				W = 300,
				H = (16 + 10) * 2,
				X = 10,//ScrW() / 2 - (W) / 2,
				Y = (ScrH() - 64),
				
				X2 = 0,
				Y2 = 0,
				W2 = 0,
				H2 = 16,
				D_H2 = 16,
				CMPR = 20,
				NAME = BNAME,
				
				DRAW_X_CON = CREATE_CLIENT_CON(BNAME.."_DRAW_X", tostring(X), true),
				DRAW_Y_CON =  CREATE_CLIENT_CON(BNAME.."_DRAW_Y", tostring(Y), true),
				DRAW_W_CON = CREATE_CLIENT_CON(BNAME.."_DRAW_W", tostring(W), true),
				DRAW_H_CON = CREATE_CLIENT_CON(BNAME.."_DRAW_H", tostring(H), true),
				DRAW_H_CON2 = CREATE_CLIENT_CON(BNAME.."_DRAW_H2", tostring(16), true),
				MPR = CREATE_CLIENT_CON(BNAME.."_MPR", tostring(CMPR), true),
				MIN_W = 100,
				MIN_H = 38,
				MAX_H = 300,
				MIN_H2 = 4,
				MAX_H2 = 64,
				RESIZE_W = true,
				RESIZE_H = true,
				MOVE_X = true,
				MOVE_Y = true,
				RESIZE_W2 = false,
				RESIZE_H2 = true,
				MOVE_X2 = false,
				MOVE_Y2 = false,
				YY = 0,
				CENTER = false,
				/*DRAW_X = 0,
				DRAW_Y = 0,
				DRAW_W = 0,
				DRAW_H = 0,*/
				
				SET_CONS = function(tab)
				
					tab.DRAW_X_CON = SET_CLIENT_CON(tab.NAME.."_DRAW_X", tostring(tab.X));
					tab.DRAW_Y_CON = SET_CLIENT_CON(tab.NAME.."_DRAW_Y", tostring(tab.Y));
					tab.DRAW_W_CON = SET_CLIENT_CON(tab.NAME.."_DRAW_W", tostring(tab.W));
					tab.DRAW_H_CON = SET_CLIENT_CON(tab.NAME.."_DRAW_H", tostring(tab.H));
					tab.DRAW_H_CON2 = SET_CLIENT_CON(tab.NAME.."_DRAW_H2", tostring(tab.D_H2));
					tab.MPR = SET_CLIENT_CON(tab.NAME.."_MPR", tostring(tab.CMPR));
					//chat.AddText(tostring(tab.X));
					//chat.AddText(tostring(tab.DRAW_X_CON:GetInt()));

					return;
				end,
				
				CREATE_CONS = function (tab)
					tab.DRAW_X_CON = CREATE_CLIENT_CON(tab.NAME.."_DRAW_X", tostring(tab.X), true);
					tab.DRAW_Y_CON = CREATE_CLIENT_CON(tab.NAME.."_DRAW_Y", tostring(tab.Y), true);
					tab.DRAW_W_CON = CREATE_CLIENT_CON(tab.NAME.."_DRAW_W", tostring(tab.W), true);
					tab.DRAW_H_CON = CREATE_CLIENT_CON(tab.NAME.."_DRAW_H", tostring(tab.H), true);
					tab.DRAW_H_CON2 = CREATE_CLIENT_CON(tab.NAME.."_DRAW_H2", tostring(tab.D_H2), true);
					tab.MPR = CREATE_CLIENT_CON(tab.NAME.."_MPR", tostring(tab.CMPR), true);
					tab.X = tab.DRAW_X_CON:GetInt();
					tab.Y = tab.DRAW_Y_CON:GetInt();
					tab.W = tab.DRAW_W_CON:GetInt();
					tab.H = tab.DRAW_H_CON:GetInt();
					tab.D_H2 = tab.DRAW_H_CON2:GetInt();
					
					tab.CMPR = tab.MPR:GetInt();
					tab.X2 = 0;
					tab.Y2 = 0;
					/*tab.DRAW_X = tab.DRAW_X_CON:GetInt();
					tab.DRAW_Y = tab.DRAW_Y_CON:GetInt();
					tab.DRAW_W = tab.DRAW_W_CON:GetInt();
					tab.DRAW_H = tab.DRAW_H_CON:GetInt();*/
				end,

				DRAW_FUNC = function (ply, tab)
						local client = ply;
											   -- Draw ammo
					   local BGW = tab.DRAW_W_CON:GetInt();
					   local margin = 10;
					   local bar_width = BGW - (10 * 3);
					   local bar_height = tab.DRAW_H_CON:GetInt();
					   local x = tab.DRAW_X_CON:GetInt();
					   local y = tab.DRAW_Y_CON:GetInt();
					   local wep = client:GetActiveWeapon();
					   local max_per_row = tab.MPR:GetInt();
					   if (ScrW() < 1000 and BGW == tab.DW)
					   then
							max_per_row = 15;
							BGW = BGW - 100;
							bar_width = bar_width - 100;
					   end
					   if client:GetActiveWeapon().Primary 
					   then
							local name = TryTranslation(client:GetActiveWeapon():GetPrintName() or client:GetActiveWeapon().PrintName or "...")
							local ammo_clip, ammo_max, ammo_inv = GetAmmo(client)
							local yy = 0;
							
							if (ammo_max != -1) 
							then
								
								if (ammo_max > max_per_row)
								then
									yy = (math.ceil(max_per_row / ammo_max) + 1) *  tab.DRAW_H_CON2:GetInt();
									
								end
							end
							tab.YY = yy;
							local by = bar_height;//(bar_height +margin);
							
							/*if (by + yy < 0)
							then
								yy = - yy;
							end*/
							
							DrawBg(x, y - yy, BGW, ( by + yy) + 2, client) // 92;
							FNT = "TraitorStateB";
							if (GetStrWidth(name, FNT) > BGW - margin * 2)
							then
									FNT = "TraitorStateBSmall"
									if (GetStrWidth(name, FNT) > BGW - margin * 2)
									then
										FNT = "HealthAmmoB";
									end
							end
						local AMMO_BAR_H = tab.DRAW_H_CON2:GetInt();//math.Clamp((bar_height + margin * 2) / 2, 8, 16);
						local CO = COLOR_WHITE;
						if (wep.NAME_COLOR)
						then
							CO = wep.NAME_COLOR;
						end
						
						if (wep.NAME_FLASH)
						then
							if (FLASH_TIME < CurTime())
							then
								FLASH_TIME = CurTime() + .1;
								CO = Color(math.Rand(0, 255), math.Rand(0, 255), math.Rand(0, 255));
								PRE_FLASH = CO;
							else
								CO = PRE_FLASH;
							end
						end
							//if wep.GLOW_NAME = true)
							if (wep.GLOW_NAME == true)
							then
								DrawGlowingText(name, FNT, x + (margin), (y - yy) + 1, CO, nil, nil);
								draw.SimpleText(name, FNT,  x + (margin), (y - yy) + 1, CO, nil, nil);
							else
								ShadowedText(name, FNT, x + (margin), (y - yy) + 1, CO, nil, nil);
							end
					   
								local ammo_clip, ammo_max, ammo_inv = GetAmmo(client)
								if ammo_clip != -1 
								then
									local ammo_y = y + (24) + margin - (yy);
									tab.Y2 = ammo_y;
									tab.X2 = x + margin;
									tab.W2 = bar_width + margin;
									tab.H2 = AMMO_BAR_H + yy;
									//PaintBar(x+margin, ammo_y, bar_width, bar_height, ammo_colors, ammo_clip/ammo_max)
									 DrawAmmo(x + margin , ammo_y, math.Round(bar_width + margin), AMMO_BAR_H + yy, ammo_colors, ammo_clip, ammo_max, max_per_row);
									 local text = string.format("%i / %02i", ammo_clip, ammo_inv)
									 
									 ShadowedText(text, "HealthAmmoB", x + (margin) + (bar_width + margin) / 2, ammo_y + (AMMO_BAR_H + yy) / 2, Color(255, 255, 255, 128), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
								  end
					   end
					   
					return;
				end,
				
				THINK_FUNC = function (tab, mx, my)
				
					//if (EDIT_HUD == true)
					//then
						//gui.EnableScreenClicker( true );
						
						//local mx gui.MouseX();
						//local my = gui.MouseY();
						local xx = tab.DRAW_X_CON:GetInt();
						local yy = tab.DRAW_Y_CON:GetInt();
						local YY = tab.YY;
						local ww = tab.DRAW_W_CON:GetInt();
						local hh = tab.DRAW_H_CON:GetInt();
						local mg = SIZE_MARGIN;
						if (mx > xx and my > yy - YY and mx < xx + ww and my < (yy - YY) + (hh + YY))
						then
							SELECT_ON = tab;
							
							if (mx < xx + mg and mx > xx)
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_W = true;
								CAN_MOVE_X = true;
							end
							
							if (mx > xx + ww - mg and mx < xx + ww)
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_W = true;
							end
							
							if (my < (yy - YY) + mg and my > (yy - YY))
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_H = true;
								CAN_MOVE_Y = true;
							end
							
							if (my > (yy - YY) + (hh + YY) - mg and my < (yy - YY) + (hh + YY))
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_H = true;
							end
							
							if (mx > tab.X2 and my > tab.Y2 and mx < tab.X2 + (tab.W2) and my < tab.Y2 + tab.H2)
							then
								SELECT_SECONDARY = true;
								SECOND_TAB = tab;
								if (my > tab.Y2 + tab.H2 - mg and my < tab.Y2 + tab.H2)
								then
									RESIZE_TAB = tab;
									CAN_RESIZE = true;
									
									CAN_MOVE_X = false;
									CAN_MOVE_Y = false;
									CAN_RESIZE_W = false;
									CAN_RESIZE_H = true;
								end
							end
						end
					//end
					return;
				end,
				
				RESET = function (tab)
					tab.X = tab.DX;
					tab.Y = tab.DY;
					tab.W = tab.DW;
					tab.H = tab.DH;
					tab.D_H2 = tab.DH2;
					tab.CMPR = tab.DMPR;
					tab.SET_CONS( tab );
				end
			}
			function change_mpr(ply, com, arg)
			local tab = AMMO_BAR;
			MsgN("ADD");
				arg[1] = tonumber(arg[1]);
				if (!arg[1]) then return; end;
				tab.CMPR = math.Clamp(arg[1], 15, 40);
				tab.MPR = SET_CLIENT_CON(tab.NAME.."_MPR", tostring(tab.CMPR));
			end
			;
				concommand.Add("ammo_per_row", change_mpr)
				BNAME = "Role";
			local ROLE_BAR = 
			{
				
				DW = 300,
				DH = 26,
				DX = ScrW() / 2 - (300) / 2,
				DY = (ScrH() - 36) ,
				W = 300,
				H = 26,
				X = ScrW() / 2 - (300) / 2,//ScrW() / 2 - (W) / 2,
				Y = (ScrH() - 36),
				NAME = BNAME,
				
				DRAW_X_CON = CREATE_CLIENT_CON(BNAME.."_DRAW_X", tostring(X), true),
				DRAW_Y_CON =  CREATE_CLIENT_CON(BNAME.."_DRAW_Y", tostring(Y), true),
				DRAW_W_CON = CREATE_CLIENT_CON(BNAME.."_DRAW_W", tostring(W), true),
				DRAW_H_CON = CREATE_CLIENT_CON(BNAME.."_DRAW_H", tostring(H), true),
				MIN_W = 100,
				MIN_H = 18,
				MAX_H = 64,
				YY = 0,
				CENTER = false,
				
				SET_CONS = function(tab)
				
					tab.DRAW_X_CON = SET_CLIENT_CON(tab.NAME.."_DRAW_X", tostring(tab.X));
					tab.DRAW_Y_CON = SET_CLIENT_CON(tab.NAME.."_DRAW_Y", tostring(tab.Y));
					tab.DRAW_W_CON = SET_CLIENT_CON(tab.NAME.."_DRAW_W", tostring(tab.W));
					tab.DRAW_H_CON = SET_CLIENT_CON(tab.NAME.."_DRAW_H", tostring(tab.H));


					return;
				end,
				
				CREATE_CONS = function (tab)
					tab.DRAW_X_CON = CREATE_CLIENT_CON(tab.NAME.."_DRAW_X", tostring(tab.X), true);
					tab.DRAW_Y_CON = CREATE_CLIENT_CON(tab.NAME.."_DRAW_Y", tostring(tab.Y), true);
					tab.DRAW_W_CON = CREATE_CLIENT_CON(tab.NAME.."_DRAW_W", tostring(tab.W), true);
					tab.DRAW_H_CON = CREATE_CLIENT_CON(tab.NAME.."_DRAW_H", tostring(tab.H), true);
					tab.X = tab.DRAW_X_CON:GetInt();
					tab.Y = tab.DRAW_Y_CON:GetInt();
					tab.W = tab.DRAW_W_CON:GetInt();
					tab.H = tab.DRAW_H_CON:GetInt();

				end,
				
				DRAW_FUNC = function (ply, tab)
						local client = ply;
											   -- Draw ammo
					 	local base = bg_colors.innocent;
						local inno_colors = {
							border = COLOR_WHITE,
							background = Color(base.r / 2, base.g / 2, base.b / 2, 222),
							fill = base;
						};
						
						base = bg_colors.traitor;
						local trait_colors = {
							border = COLOR_WHITE,
							background = Color(base.r / 2, base.g / 2, base.b / 2, 222),
							fill = base;
						};
						
						local base = bg_colors.detective;
						local detective_colors = {
							border = COLOR_WHITE,
							background = Color(base.r / 2, base.g / 2, base.b / 2, 222),
							fill = base;
						};
						
						base = bg_colors.noround;
						local no_colors = {
							border = COLOR_WHITE,
							background = Color(base.r / 2, base.g / 2, base.b / 2, 222),
							fill = base;
						};
					   local col = inno_colors;
					   local round_state = GAMEMODE.round_state
					   
						if GAMEMODE.round_state != ROUND_ACTIVE then
						  col = no_colors;//bg_colors.noround
					  elseif client:GetTraitor() then
						  col = trait_colors;//bg_colors.traitor
					   elseif client:GetDetective() then
						  col = detective_colors;// bg_colors.detective
					   end
					   
					   
					   local text = nil
					   if round_state == ROUND_ACTIVE then
						  text = client:GetRoleStringRaw()
					   else
						  text = roundstate_string[round_state] 
					   end
					   local t_w = tab.DRAW_W_CON:GetInt(); //300
					   local t_h = tab.DRAW_H_CON:GetInt(); //26;
					   
					   local traitor_y = tab.DRAW_Y_CON:GetInt(); //ScrH() - (t_h + margin);
					   t_x = tab.DRAW_X_CON:GetInt(); //(ScrW() / 2) - (t_w / 2)
					   
					   if (ScrW() < 1000)
					   then
							if (t_w == tab.DW)
							then
								t_w = t_w - 50;
							end
							if (t_x == tab.DX) then t_x = t_x - 35; end;
					   end
						//draw.RoundedBox(4, t_x, traitor_y, t_w, t_h, col)
						PaintBar(t_x, traitor_y, t_w, t_h, col, 1)
						//draw.RoundedBox(4, t_x, traitor_y, t_w, t_h / 3, Color(255, 255, 255, 255 * .6))
					   ShadowedText(string.upper(text), "TraitorStateB",t_x + t_w / 2 , (traitor_y ) + t_h / 2, COLOR_WHITE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

								   
					return;
				end,
				
				THINK_FUNC = function (tab, mx, my)
				
					//if (EDIT_HUD == true)
					//then
						//gui.EnableScreenClicker( true );
						
						//local mx gui.MouseX();
						//local my = gui.MouseY();
						local xx = tab.DRAW_X_CON:GetInt();
						local yy = tab.DRAW_Y_CON:GetInt();
						local YY = tab.YY;
						local ww = tab.DRAW_W_CON:GetInt();
						local hh = tab.DRAW_H_CON:GetInt();
						local mg = SIZE_MARGIN;
						if (mx > xx and my > yy - YY and mx < xx + ww and my < (yy - YY) + (hh + YY))
						then
							SELECT_ON = tab;
							
							if (mx < xx + mg and mx > xx)
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_W = true;
								CAN_MOVE_X = true;
							end
							
							if (mx > xx + ww - mg and mx < xx + ww)
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_W = true;
							end
							
							if (my < (yy - YY) + mg and my > (yy - YY))
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_H = true;
								CAN_MOVE_Y = true;
							end
							
							if (my > (yy - YY) + (hh + YY) - mg and my < (yy - YY) + (hh + YY))
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_H = true;
							end
							
						end
					//end
					return;
				end,
				
				RESET = function (tab)
					tab.X = tab.DX;
					tab.Y = tab.DY;
					tab.W = tab.DW;
					tab.H = tab.DH;
					tab.SET_CONS( tab );
				end
			}
				
				
				
			BNAME = "Timer";
			local TIMER_BAR = 
			{
				
				DW = GetStrWidth("00:00","TimeLeft"),
				DH = 18,
				DX = ScrW() / 2,
				DY = ((ScrH() - 36) -3) - GetStrHeight("00:00", "TimeLeft") / 2 ,
				W = GetStrWidth("00:00","TimeLeft"),
				H = 18,
				X = ScrW() / 2 - (300) / 2,//ScrW() / 2 - (W) / 2,
				Y =((ScrH() - 36) -3) - GetStrHeight("00:00", "TimeLeft") / 2 ,
				NAME = BNAME,
				
				DRAW_X_CON = CREATE_CLIENT_CON(BNAME.."_DRAW_X", tostring(X), true),
				DRAW_Y_CON =  CREATE_CLIENT_CON(BNAME.."_DRAW_Y", tostring(Y), true),
				DRAW_W_CON = CREATE_CLIENT_CON(BNAME.."_DRAW_W", tostring(W), true),
				DRAW_H_CON = CREATE_CLIENT_CON(BNAME.."_DRAW_H", tostring(H), true),
				MIN_W = 100,
				MIN_H = 18,
				MAX_H = 64,
				YY = 0,
				CENTER = true,
				
				SET_CONS = function(tab)
				
					tab.DRAW_X_CON = SET_CLIENT_CON(tab.NAME.."_DRAW_X", tostring(tab.X));
					tab.DRAW_Y_CON = SET_CLIENT_CON(tab.NAME.."_DRAW_Y", tostring(tab.Y));
					tab.DRAW_W_CON = SET_CLIENT_CON(tab.NAME.."_DRAW_W", tostring(tab.W));
					tab.DRAW_H_CON = SET_CLIENT_CON(tab.NAME.."_DRAW_H", tostring(tab.H));


					return;
				end,
				
				CREATE_CONS = function (tab)
					tab.DRAW_X_CON = CREATE_CLIENT_CON(tab.NAME.."_DRAW_X", tostring(tab.X), true);
					tab.DRAW_Y_CON = CREATE_CLIENT_CON(tab.NAME.."_DRAW_Y", tostring(tab.Y), true);
					tab.DRAW_W_CON = CREATE_CLIENT_CON(tab.NAME.."_DRAW_W", tostring(tab.W), true);
					tab.DRAW_H_CON = CREATE_CLIENT_CON(tab.NAME.."_DRAW_H", tostring(tab.H), true);
					tab.X = tab.DRAW_X_CON:GetInt();
					tab.Y = tab.DRAW_Y_CON:GetInt();
					tab.W = tab.DRAW_W_CON:GetInt();
					tab.H = tab.DRAW_H_CON:GetInt();

				end,
				
				DRAW_FUNC = function (ply, tab)
					local round_state = GAMEMODE.round_state
					local client = ply;
					local is_haste = HasteMode() and round_state == ROUND_ACTIVE
					local is_traitor = client:IsActiveTraitor()
					local endtime = GetGlobalFloat("ttt_round_end", 0) - CurTime()
					
					local text
					local font = "TimeLeft"
					local color = COLOR_WHITE
					local rx = tab.DRAW_X_CON:GetInt(); //ScrW() / 2
					local ry = tab.DRAW_Y_CON:GetInt(); //(ScrH() - (26 + margin)) - 3;
					if (ScrW() < 1000)
					then
						if (rx == tab.DX)
						then
							rx = rx - 35;
						end
					end

					   if is_haste then
						  local hastetime = GetGlobalFloat("ttt_haste_end", 0) - CurTime()
						  if hastetime < 0 then
							 if (not is_traitor) or (math.ceil(CurTime()) % 7 <= 2) then
								-- innocent or blinking "overtime"
								text = "Overtime"//L.overtime
								font = "Trebuchet18"

								-- need to hack the position a little because of the font switch
								ry = ry + 5
								rx = rx - 3
							 else
								-- traitor and not blinking "overtime" right now, so standard endtime display
								text  = util.SimpleTime(math.max(0, endtime), "%02i:%02i")
								color = COLOR_RED
							 end
						  else
							 -- still in starting period
							 local t = hastetime
							 if is_traitor and math.ceil(CurTime()) % 6 < 2 then
								t = endtime
								color = COLOR_RED
							 end
							 text = util.SimpleTime(math.max(0, t), "%02i:%02i")
						  end
					   else
						  -- bog standard time when haste mode is off (or round not active)
						  text = util.SimpleTime(math.max(0, endtime), "%02i:%02i")
					   end

					   ShadowedText(text, font, rx, ry, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

					   if is_haste then
						 dr.SimpleText(tostring("Haste mode"), "TabLarge", rx - (GetStrWidth(text, font) / 2), ry - 24)
					   end
					   
					return;
				end,
				
				THINK_FUNC = function (tab, mx, my)
				
					//if (EDIT_HUD == true)
					//then
						//gui.EnableScreenClicker( true );
						
						//local mx gui.MouseX();
						//local my = gui.MouseY();						
						local ww = tab.DRAW_W_CON:GetInt();
						local hh = tab.DRAW_H_CON:GetInt() ;
						local xx = tab.DRAW_X_CON:GetInt() - ww / 2;
						local yy = tab.DRAW_Y_CON:GetInt() - hh / 2;
						local YY = tab.YY;

						local mg = SIZE_MARGIN;
						if (mx > xx and my > yy - YY and mx < xx + ww and my < (yy - YY) + (hh + YY))
						then
							SELECT_ON = tab;
							
							/*if (mx < xx + mg and mx > xx)
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_W = true;
								CAN_MOVE_X = true;
							end
							
							if (mx > xx + ww - mg and mx < xx + ww)
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_W = true;
							end
							
							if (my < (yy - YY) + mg and my > (yy - YY))
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_H = true;
								CAN_MOVE_Y = true;
							end
							
							if (my > (yy - YY) + (hh + YY) - mg and my < (yy - YY) + (hh + YY))
							then
								RESIZE_TAB = tab;
								CAN_RESIZE = true;
								CAN_RESIZE_H = true;
							end*/
							
						end
					//end
					return;
				end,
				
				RESET = function (tab)
					tab.X = tab.DX;
					tab.Y = tab.DY;
					tab.W = tab.DW;
					tab.H = tab.DH;
					tab.SET_CONS( tab );
				end
			}
				if (ScrH() < 768)
				then
					if (HP_BAR.Y == HP_BAR.DY)
					then
						HP_BAR.Y = HP_BAR.Y - 2;
					end
				end
				if (ScrW() < 1000)
				then
					if (HP_BAR.W >= 500)
					then
						HP_BAR.W = HP_BAR.W - 125;
						//health_x = (ScrW() / 2) - HP_W / 2;
						if (HP_BAR.X == HP_BAR.DX)
						then
							HP_BAR.X = 10;
						end
					end
				end
				
				
		HP_BAR.CREATE_CONS(HP_BAR);
		AMMO_BAR.CREATE_CONS(AMMO_BAR);
		ROLE_BAR.CREATE_CONS(ROLE_BAR);
		TIMER_BAR.CREATE_CONS(ROLE_BAR);
		table.insert(HUD_ELEMENTS, AMMO_BAR);
		table.insert(HUD_ELEMENTS, ROLE_BAR);
		table.insert(HUD_ELEMENTS, TIMER_BAR);
		table.insert(HUD_ELEMENTS, HP_BAR);
		function RESET_HUD()
			for k, tb in ipairs(HUD_ELEMENTS)
			do
				if (tb != nil)
				then
					tb.RESET( tb );
				end
			end
		end
		concommand.Add("reset_brassx_hud", RESET_HUD);
		if (!file.Exists("BRASS_HUD_C.txt", "DATA"))
		then
			file.Write("BRASS_HUD_C.txt", "DATA");
			RESET_HUD();
			chat.AddText("Reset Hud!");
		end

		EDIT_HUD = false;
		local CLICK_X = 0;
		local CLICK_Y = 0;
		local EXACT_CX = 0;
		local EXACT_CY = 0;
		local FIRST = true;
		local SHOW_CURS = false;
		local CLICK_2 = false;
		local CL = true;
		local CL2 = true;
		local SNAP = false;
		local function HUD_THINK()
			SNAP = input.IsKeyDown(KEY_LCONTROL);
			if (input.IsKeyDown(KEY_F4))
			then
				if (CL2 == true)
				then
					GRID = !GRID;
					CL2 = false;
				end
				
				
			elseif (CL2 == false)
			then
				CL2 = true;
			end
			
			if (input.IsKeyDown(KEY_F6))
			then
				if (CL == true)
				then
					EDIT_HUD = !EDIT_HUD;
				
					if (EDIT_HUD == false)
					then
						EDIT_HUD = false;
						if (SHOW_CURS == true)
						then
							gui.EnableScreenClicker( false);
							SHOW_CURS = false;
						end
					end
					CL = false;
				end
			else
				CL = true;
			end
			if (OLD_HUD:GetBool() == true) then return; end
			if (EDIT_HUD == true)
			then
				gui.EnableScreenClicker( true );
				SHOW_CURS = true;
				SELECT_ON = nil;
				SELECT_SECONDARY = false;
				SECOND_TAB = nil;
				CAN_RESIZE_W = false;
				CAN_RESIZE_H = false;
				CAN_MOVE_X = false;
				CAN_MOVE_Y = false;
				CAN_RESIZE = false;
				RESIZE_TAB = nil;
				
				local mx = gui.MouseX();
				local my = gui.MouseY();
				for k , tb in ipairs(HUD_ELEMENTS)
				do
					if (tb != nil)
					then
						tb.THINK_FUNC( tb, mx, my );
						/*tb.DRAW_X = tb.DRAW_X_CON:GetInt();
						tb.DRAW_Y = tb.DRAW_Y_CON:GetInt();
						tb.DRAW_W = tb.DRAW_W_CON:GetInt();
						tb.DRAW_H = tb.DRAW_H_CON:GetInt();*/
					end
				end
				if (input.IsMouseDown(MOUSE_LEFT))
				then
				
					if (SELECT_ON != nil and CLICK_ON == nil and FIRST == true)
					then
						//FIRST = false;
						CLICK_X = SELECT_ON.DRAW_X_CON:GetInt() - mx;
						CLICK_Y = SELECT_ON.DRAW_Y_CON:GetInt() - my;
						EXACT_CX = mx;
						EXACT_CY = my;
						CLICK_ON = SELECT_ON;
						if (SELECT_SECONDARY == true and SECOND_TAB == SELECT_ON)
						then
							CLICK_2 = true;
						end
						if (CAN_RESIZE == true and SELECT_ON == RESIZE_TAB)
						then
							RESIZE = true;
						end
						if (RESIZE == true)
						then
							if (CAN_RESIZE_W == true) then RESIZE_W = true; end
							if (CAN_RESIZE_H == true) then RESIZE_H = true; end
							if (CAN_MOVE_X == true) then MOVE_X = true; end
							if (CAN_MOVE_Y == true) then MOVE_Y = true; end
						end
						//chat.AddText(tostring(CLICK_ON));
					end
					
					FIRST = false;
				else
					FIRST = true;						
					RESIZE = false;
					RESIZE_W = false;
					RESIZE_H = false;
					MOVE_X = false;
					MOVE_Y = false;
					if (CLICK_ON != nil)
					then
						CLICK_2 = false;
						CLICK_ON = nil;
					end
				end
				
				if (CLICK_ON != nil)
				then
					//chat.AddText(tostring(CLICK_ON));
					if (SNAP == true)
					then
						mx = math.Round(mx / GRID_SIZE) * GRID_SIZE;
						my = math.Round(my / GRID_SIZE) * GRID_SIZE;
					end
					if (RESIZE == false)
					then
						CLICK_ON.X = math.Clamp(mx + CLICK_X, 0, ScrW() - CLICK_ON.DRAW_W_CON:GetInt());
						CLICK_ON.Y = math.Clamp(my + CLICK_Y, 0, ScrH() - CLICK_ON.DRAW_H_CON:GetInt());
					else
					
						if (CLICK_2 == false)
						then
							if (RESIZE_W == true)
							then
								
								
								if (MOVE_X == true)
								then
									CLICK_ON.W = math.Clamp(CLICK_ON.W - ((mx + CLICK_X)- CLICK_ON.X), CLICK_ON.MIN_W, ScrW());
									
									if (CLICK_ON.W != CLICK_ON.MIN_W)
									then
										CLICK_ON.X = mx + CLICK_X;
									end
								else
									
									CLICK_ON.W = math.Clamp(CLICK_ON.W + (mx - EXACT_CX), CLICK_ON.MIN_W, ScrW());
									EXACT_CX = mx;
								end
							end
							
							if (RESIZE_H == true)
							then
								if (MOVE_Y == true)
								then
									CLICK_ON.H = math.Clamp(CLICK_ON.H - ((my + CLICK_Y)- CLICK_ON.Y), CLICK_ON.MIN_H, CLICK_ON.MAX_H);
									if (CLICK_ON.H != CLICK_ON.MIN_H and CLICK_ON.H != CLICK_ON.MAX_H)
									then
										CLICK_ON.Y = my + CLICK_Y;
									end
								else
									CLICK_ON.H = math.Clamp(CLICK_ON.H + (my - EXACT_CY), CLICK_ON.MIN_H, CLICK_ON.MAX_H);
									EXACT_CY = my;
								end
							end
						else
						//CLICK_2 == true
							if (RESIZE_W == true)
							then
								
								if (MOVE_X == true)
								then
									CLICK_ON.W = math.Clamp(CLICK_ON.W - ((mx + CLICK_X)- CLICK_ON.X), CLICK_ON.MIN_W, ScrW());
									if (CLICK_ON.W != CLICK_ON.MIN_W)
									then
										CLICK_ON.X = mx + CLICK_X;
									end
								else
									
									CLICK_ON.W = math.Clamp(CLICK_ON.W + (mx - EXACT_CX), CLICK_ON.MIN_W, ScrW());
									EXACT_CX = mx;
								end
							end
							
							if (RESIZE_H == true)
							then
								if (MOVE_Y == true)
								then
									CLICK_ON.H = math.Clamp(CLICK_ON.H - ((my + CLICK_Y)- CLICK_ON.Y), CLICK_ON.MIN_H, CLICK_ON.MAX_H);
									if (CLICK_ON.H != CLICK_ON.MIN_H and CLICK_ON.H != CLICK_ON.MAX_H)
									then
										CLICK_ON.Y = my + CLICK_Y;
									end
								else
									CLICK_ON.D_H2 = math.Clamp(CLICK_ON.D_H2 + (my - EXACT_CY), CLICK_ON.MIN_H2, CLICK_ON.MAX_H2);
									EXACT_CY = my;
								end
							end
						end
					end
					CLICK_ON.SET_CONS(CLICK_ON);
				end
			end
		end
		
		hook.Add("Think", "HUD_THINK_BRASS", HUD_THINK);
		local function SpecHUDPaintBrass(client)
		   //local L = GetLang() -- for fast direct table lookups

		   -- Draw round state
		   local x       = ScrW() / 2
		   local height  = 26;
		   local width   = 300;
		   x = x - width / 2;
		   local round_y = ScrH() -( height + margin);

		   -- move up a little on low resolutions to allow space for spectator hints
		   if ScrW() < 1000 then round_y = round_y - 15 end
			
		  // local traitor_y = ScrH() - (t_h + margin);
		   local time_x = ScrW() / 2
		   local time_y = round_y - 3;
			/*
			   local rx = ScrW() / 2
		   local ry = traitor_y - 3;
			*/
		   //draw.RoundedBox(4, x, round_y, width, height, bg_colors.background_main)
		   draw.RoundedBox(4, x, round_y, width, height, bg_colors.noround)

		   local text = roundstate_string[GAMEMODE.round_state]
		   ShadowedText(text, "TraitorStateB", x + width / 2, round_y + height / 2, COLOR_WHITE, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		   -- Draw round/prep/post time remaining
		   local text = util.SimpleTime(math.max(0, GetGlobalFloat("ttt_round_end", 0) - CurTime()), "%02i:%02i")
		   ShadowedText(text, "TimeLeftB", time_x, time_y, COLOR_WHITE,  TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

		   local tgt = client:GetObserverTarget()
		   if IsValid(tgt) and tgt:IsPlayer() then
			  ShadowedText(tgt:Nick(), "TimeLeft", ScrW() / 2, margin, COLOR_WHITE, TEXT_ALIGN_CENTER)

		   elseif IsValid(tgt) and tgt:GetNWEntity("spec_owner", nil) == client then
			  PunchPaint(client)
		   else
			  ShadowedText("Press E on a physics object to possess it!", "TabLarge", ScrW() / 2, margin, COLOR_WHITE, TEXT_ALIGN_CENTER)
		   end
		   
		   //draw.RoundedBox(4, x, round_y, width, height / 3, Color(255, 255, 255, 200 * .6))
		   //DrawShine(9, x - 1, y - 1 ,w, h / 3, bg_colors.noround);
		   		  local tb = 
				{
					texture = surface.GetTextureID "brass_hud_mats/brassx_gradient",
					color = Color(255, 255, 255, 200 * .5),
					x = 0,
					y = 0,
					w = 0,
					h = 0
				}
				tb.x = x + 1;
				tb.y = round_y + 1;
				tb.w = width - 1;
				tb.h = height / 2.5;
				draw.TexturedQuad( tb)
		end

		local ttt_health_label = CreateClientConVar("ttt_health_label", "0", true)
		//LocalPlayer().PreHp = LocalPlayer():Health();
		//LocalPlayer().HPDIF = 0;
		local function InitPLY()
			LocalPlayer().PreHp = LocalPlayer():Health();
			LocalPlayer().HPDIF = 0;
		end
		hook.Add( "InitPostEntity", "LoadHPStuff", InitPLY )


		
		
		

		local function InfoPaintBrass(client)
		  // local L = GetLang()
			//client.PreHP = client:Health();
			
			local width = 300 - (margin * 2)
			local height = 90

			local x = margin
			local y = (ScrH() - margin) - (54)


			local bar_height = 16;//60
			local bar_width = width - (margin)
			-- Draw health
			surface.SetDrawColor(Color(255, 255, 255, 75));
			if (GRID == true and EDIT_HUD == true)
			then
				for xx = 1, ScrW() / GRID_SIZE
				do
					surface.DrawLine(xx * GRID_SIZE, 0, xx * GRID_SIZE, ScrH());
				end					
				
				for yy = 1, ScrH() / GRID_SIZE
				do
					surface.DrawLine(0, yy * GRID_SIZE, ScrW(), yy * GRID_SIZE);
				end
			end
			surface.SetDrawColor(Color(255, 255, 255, 255));
			for k, h in ipairs(HUD_ELEMENTS)
			do
				h.DRAW_FUNC( client, h );
			end
			
			if (SELECT_ON != nil and EDIT_HUD == true)
			then
				surface.SetDrawColor(Color(0, 255, 0, 128));
					if (SELECT_SECONDARY == false)
					then
						local YOFF = 0;
						if (SELECT_ON.YY != 0)
						then
							YOFF = SELECT_ON.YY;
						end
						
						if (SELECT_ON.CENTER == true)
						then
							surface.DrawRect(SELECT_ON.DRAW_X_CON:GetInt() - SELECT_ON.DRAW_W_CON:GetInt() / 2, (SELECT_ON.DRAW_Y_CON:GetInt() - SELECT_ON.DRAW_H_CON:GetInt() / 2) - YOFF, 
											SELECT_ON.DRAW_W_CON:GetInt(), (SELECT_ON.DRAW_H_CON:GetInt()) + YOFF);
						else
							surface.DrawRect(SELECT_ON.DRAW_X_CON:GetInt(), (SELECT_ON.DRAW_Y_CON:GetInt()) - YOFF, SELECT_ON.DRAW_W_CON:GetInt(), SELECT_ON.DRAW_H_CON:GetInt() + YOFF);
						end
					elseif (SECOND_TAB == SELECT_ON)
					then
						surface.DrawRect(SELECT_ON.X2, SELECT_ON.Y2, SELECT_ON.W2, SELECT_ON.H2);
					end
					surface.SetDrawColor(Color(180, 28, 28, 255));
					if (CAN_RESIZE == true)
					then
						local len = 15;
						local mx, my = gui.MousePos();
						if (CAN_RESIZE_W == true)
						then
							surface.DrawLine(mx + len, my - 3, mx - len, my - 3);							
						end
						
						if (CAN_RESIZE_H == true)
						then
							surface.DrawLine(mx - 3, my - len, mx - 3, my + len);							
						end
					end
				
				surface.SetDrawColor(Color(255, 255, 255, 255));
				//surface.DrawLine(SELECT_ON.DRAW_X, SELECT_ON.DRAW_Y, SELECT_ON.DRAW_X + SELECT_ON.DRAW_W, SELECT_ON.DRAW_Y);
			end
			if (EDIT_HUD == true)
			then
			local xx = 5;
			local yy = 75;
				ShadowedText("HUD Edit mode (BETA)", "HealthAmmoB", xx,  yy, Color(255, 255, 255, 128))
				ShadowedText("Type 'reset_brassx_hud' into the console", "HealthAmmoB", xx,  yy + 12, Color(255, 255, 255, 128))
				ShadowedText("to reset everything. Press F6 to exit edit mode.", "HealthAmmoB", xx,  yy + 24, Color(255, 255, 255, 128))
				
				ShadowedText("Press F4 to toggle the GRID display, and Hold CTRL To snap to grid.", "HealthAmmoB", xx,  yy + 36, Color(255, 255, 255, 128))
				
				ShadowedText("Type 'ammo_per_row' in the console, followed by a number to change the amount of ammo drawn per row.", "HealthAmmoB", xx,  yy + 48, Color(255, 255, 255, 128))
			end
			
			local health = math.max(0, client:Health())
			/*if (client:Health() != client.PreHp)
			then
				client.HPDIF = client.PreHp - client:Health();
				client.PreHp = client:Health();
			end
			local health_x = HP_BAR.DRAW_X_CON:GetInt();
			local health_y = HP_BAR.DRAW_Y_CON:GetInt();
			local HP_W = HP_BAR.DRAW_W_CON:GetInt();
			local HP_H = HP_BAR.DRAW_H_CON:GetInt();
			//PaintBarColorBlend(health_x, health_y, HP_W, HP_H, health_colors, health/100)
			if (client.HPDIF > 0)
			then
				PaintBarNoBg(health_x + HP_W * (health / 100), health_y, HP_W * (client.HPDIF / 100), HP_H, health_colors.min_fill, 1);//(health + client.HPDIF)/100)
				
			end
			if (client.HPDIF >= 0)
			then
				client.HPDIF = client.HPDIF - .25;
			end*/
			//ShadowedText("Health:" .. tostring(health), "HealthAmmoB",health_x + HP_W /2,  health_y + HP_H / 2, Color(255, 255, 255, 128), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

			//ShadowedText(tostring(client.FLIP_HUD), "HealthAmmoB",health_x + HP_W /2,  health_y + 32, Color(255, 255, 255, 128), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		   if ttt_health_label:GetBool() then
			  local health_status = util.HealthToString(health)
			  //draw.SimpleText(health_status, "TabLarge", health_x, health_y + HP_H/2, COLOR_WHITE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		   end
			client.PreHP = client:Health();

			
			

		   -- Draw traitor state

		   -- Draw round time
		  

		end
		local function SpecHUDPaint(client)
		   local L = GetLang() -- for fast direct table lookups

		   -- Draw round state
		   local x       = margin
		   local height  = 32
		   local width   = 250
		   local round_y = ScrH() - height - margin

		   -- move up a little on low resolutions to allow space for spectator hints
		   if ScrW() < 1000 then round_y = round_y - 15 end

		   local time_x = x + 170
		   local time_y = round_y + 4

		   draw.RoundedBox(4, x, round_y, width, height, bg_colors.background_main)
		   draw.RoundedBox(4, x, round_y, time_x - x, height, bg_colors.noround)

		   local text = roundstate_string[GAMEMODE.round_state]
		   ShadowedText(text, "TraitorState", x + margin, round_y, COLOR_WHITE)

		   -- Draw round/prep/post time remaining
		   local text = util.SimpleTime(math.max(0, GetGlobalFloat("ttt_round_end", 0) - CurTime()), "%02i:%02i")
		   ShadowedText(text, "TimeLeft", time_x + margin, time_y, COLOR_WHITE)

		   local tgt = client:GetObserverTarget()
		   if IsValid(tgt) and tgt:IsPlayer() then
			  ShadowedText(tgt:Nick(), "TimeLeft", ScrW() / 2, margin, COLOR_WHITE, TEXT_ALIGN_CENTER)

		   elseif IsValid(tgt) and tgt:GetNWEntity("spec_owner", nil) == client then
			  PunchPaint(client)
		   else
			  ShadowedText("Press E on a physics object to Possess it!", "TabLarge", ScrW() / 2, margin, COLOR_WHITE, TEXT_ALIGN_CENTER)
		   end
		   
		   //draw.RoundedBox(4, x, round_y, width, height / 3, Color(255, 255, 255, 200 * .6))
		   		  local tb = 
				{
					texture = surface.GetTextureID "brass_hud_mats/brassx_gradient",
					color = Color(255, 255, 255, 200 * .5),
					x = 0,
					y = 0,
					w = 0,
					h = 0
				}
				tb.x = x + 1;
				tb.y = round_y + 1;
				tb.w = width - 1;
				tb.h = height / 2.5;
				draw.TexturedQuad( tb)
		   //DrawShine(9, x - 1, y - 1 ,w, h / 3, bg_colors.noround);
		end

		local ttt_health_label = CreateClientConVar("ttt_health_label", "0", true)
		
		local function InfoPaint(client)
		   local L = GetLang()

		   local width = 250
		   local height = 90

		   local x = margin
		   local y = ScrH() - margin - height

		   local COL = DrawBgOld(x, y, width, height, client)

		   local bar_height = 25
		   local bar_width = width - (margin*2)

		   -- Draw health
		   local health = math.max(0, client:Health())
		   local health_y = y + margin

			local _colors = {
		   border = COLOR_WHITE,
		   background = Color(15, 62, 15, 222),
		   fill = Color(31, 124, 31, 250),
		   min_bg = Color(62, 15, 15, 222),
		   min_fill = Color(124, 31, 31, 250);
		   
			};
			local o = 20;
			if (COL != bg_colors.noround)
			then
				_colors.fill = Color(COL.r - o, COL.g - o, COL.b - o, 255);
				_colors.background = Color((COL.r - o) / 2, (COL.g - o) / 2, (COL.b - o) / 2, 222);
			end
		   PaintBar(x + margin, health_y, bar_width, bar_height, _colors, health/100)
		   
			if (client:Health() != client.PreHp)
			then
				client.HPDIF = client.PreHp - client:Health();
				client.PreHp = client:Health();
			end
			//PaintBarColorBlend(health_x, health_y, HP_W, HP_H, health_colors, health/100)
			if (client.HPDIF > 0)
			then
				PaintBarNoBg(x + margin + bar_width * (health / 100), health_y, bar_width * (client.HPDIF / 100), bar_height, health_colors.min_fill, 1);//(health + client.HPDIF)/100)
				
			end
			if (client.HPDIF >= 0)
			then
				client.HPDIF = client.HPDIF - .25;
			end
			
		   ShadowedText(tostring(health), "HealthAmmo", bar_width, health_y, COLOR_WHITE, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT)

		   if ttt_health_label:GetBool() then
			  local health_status = util.HealthToString(health)
			  draw.SimpleText(health_status, "TabLarge", x + margin*2, health_y + bar_height/2, COLOR_WHITE, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		   end

		   -- Draw ammo
		   if client:GetActiveWeapon().Primary then
			  local ammo_clip, ammo_max, ammo_inv = GetAmmo(client)
			  if ammo_clip != -1 then
				 local ammo_y = health_y + bar_height + margin
				 PaintBar(x+margin, ammo_y, bar_width, bar_height, ammo_colors, ammo_clip/ammo_max)
				 local text = string.format("%i + %02i", ammo_clip, ammo_inv)

				 ShadowedText(text, "HealthAmmo", bar_width, ammo_y, COLOR_WHITE, TEXT_ALIGN_RIGHT, TEXT_ALIGN_RIGHT)
			  end
		   end

		   -- Draw traitor state
		   local round_state = GAMEMODE.round_state

		   local traitor_y = y - 30
		   local text = nil
		   if round_state == ROUND_ACTIVE then
			  text = string.upper(client:GetRoleStringRaw())
		   else
			  text = roundstate_string[round_state]
		   end

		   ShadowedText(text, "TraitorState", x + margin + 73, traitor_y, COLOR_WHITE, TEXT_ALIGN_CENTER)

		   -- Draw round time
		   local is_haste = HasteMode() and round_state == ROUND_ACTIVE
		   local is_traitor = client:IsActiveTraitor()

		   local endtime = GetGlobalFloat("ttt_round_end", 0) - CurTime()

		   local text
		   local font = "TimeLeft"
		   local color = COLOR_WHITE
		   local rx = x + margin + 170
		   local ry = traitor_y + 3

		   -- Time displays differently depending on whether haste mode is on,
		   -- whether the player is traitor or not, and whether it is overtime.
		   if is_haste then
			  local hastetime = GetGlobalFloat("ttt_haste_end", 0) - CurTime()
			  if hastetime < 0 then
				 if (not is_traitor) or (math.ceil(CurTime()) % 7 <= 2) then
					-- innocent or blinking "overtime"
					text = "Overtime"//L.overtime
					font = "Trebuchet18"

					-- need to hack the position a little because of the font switch
					ry = ry + 5
					rx = rx - 3
				 else
					-- traitor and not blinking "overtime" right now, so standard endtime display
					text  = util.SimpleTime(math.max(0, endtime), "%02i:%02i")
					color = COLOR_RED
				 end
			  else
				 -- still in starting period
				 local t = hastetime
				 if is_traitor and math.ceil(CurTime()) % 6 < 2 then
					t = endtime
					color = COLOR_RED
				 end
				 text = util.SimpleTime(math.max(0, t), "%02i:%02i")
			  end
		   else
			  -- bog standard time when haste mode is off (or round not active)
			  text = util.SimpleTime(math.max(0, endtime), "%02i:%02i")
		   end

		   ShadowedText(text, font, rx, ry, color)

		   if is_haste then
			  dr.SimpleText("Haste mode", "TabLarge", x + margin + 165, traitor_y - 8)
		   end

		end
		
		-- Paints player status HUD element in the bottom left
		function GAMEMODE:HUDPaint()
		   local client = LocalPlayer()

		   GAMEMODE:HUDDrawTargetID()

		   MSTACK:Draw(client)
		   if (not client:Alive()) or client:Team() == TEAM_SPEC then
			if (OLD_HUD:GetBool() == false)
			then
			  SpecHUDPaintBrass(client)
			else
				SpecHUDPaint(client);
			end
			  return
		   end


			RADAR:Draw(client)
			TBHUD:Draw(client)
			WSWITCH:Draw(client)

			VOICE.Draw(client)
			DISGUISE.Draw(client)

			GAMEMODE:HUDDrawPickupHistory()

		   -- Draw bottom left info panel
		   
		   if (OLD_HUD:GetBool()  == false)
		   then
				InfoPaintBrass(client);
		   else
				InfoPaint(client);
		   end
		   //hook.Call("HUDPaint", GAMEMODE, client);
		end

		-- Hide the standard HUD stuff
		/*local hud = {"CHudHealth", "CHudBattery", "CHudAmmo", "CHudSecondaryAmmo"}
		function GM:HUDShouldDraw(name)
		   for k, v in pairs(hud) do
			  if name == v then return false end
		   end

		   return true
		end*/
	end
	
	


	//end

		NEW_HUD();
		

		/*if (!ConVarExists("HUD_INITBb"))
		then
			conv = CreateClientConVar("HUD_INITBb", "true", true);
			RESET_HUD();
			chat.AddText("Reset Hud!");
		end*/
end
/*
if (CLIENT)
then
	local function FlipHud( data)
		LocalPlayer().FLIP_HUD = data:ReadShort();
	end
	usermessage.Hook("BRASS_HUD_FLIP", FlipHud);
end

if (SERVER)
then
function SEND_FLIP(ply)
	local fl = ply:GetPData("BRASS_HUD_FLIP", 0);
	umsg.Start("BRASS_HUD_FLIP", ply);
	umsg.Short(fl);
	umsg.End();
end

function FlipHud(ply)
	local fl = ply:GetPData("BRASS_HUD_FLIP", 0);
	ply:SetPData("BRASS_HUD_FLIP", !fl);
	umsg.Start("BRASS_HUD_FLIP", ply);
	umsg.Short(!fl);
	umsg.End();
end

	hook.Add("PlayerInitialSpawn", "INIT_FLIP", SEND_FLIP);
	concommand.Add("brassx_hud_flip", FlipHud);
end*/

if (CLIENT)
then
	hook.Add( "Initialize", "InitBrassHud", INIT_BRASS_HUD);
	
	usermessage.Hook("REFRESH_HUD", INIT_BRASS_HUD);
end

local function RefreshHUD( ply )
	if (SERVER)
	then
		umsg.Start("REFRESH_HUD");
		umsg.End();
	else
		INIT_BRASS_HUD();
	end
	
end
concommand.Add("refresh_brass_hud", RefreshHUD);
local function CHECK_RES()
	if (PRE_RES != ScrW() + ScrH())
	then
		INIT_BRASS_HUD();
	end
	PRE_RES = ScrW() + ScrH();
end

if (CLIENT)
then
	
	timer.Create("CHECK_RES", 3, 0, CHECK_RES);
end
