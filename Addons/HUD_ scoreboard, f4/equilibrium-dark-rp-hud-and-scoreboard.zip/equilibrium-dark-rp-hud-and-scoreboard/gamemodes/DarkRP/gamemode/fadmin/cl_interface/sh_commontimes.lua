/*---------------------------------------------------------------------------
Common times for several punishment actions
---------------------------------------------------------------------------*/
FAdmin.PlayerActions.commonTimes = {}
FAdmin.PlayerActions.commonTimes[0] = "Indefinitely"
FAdmin.PlayerActions.commonTimes[10] = "10 seconds"
FAdmin.PlayerActions.commonTimes[30] = "30 seconds"
FAdmin.PlayerActions.commonTimes[60] = "1 minute"
FAdmin.PlayerActions.commonTimes[300] = "5 minutes"
FAdmin.PlayerActions.commonTimes[600] = "10 minutes"

ply = localplayer or client
function FAdmin.PlayerActions.addTimeSubmenu(menu, submenuText, submenuClick, submenuItemClick)
	local SubMenu = menu:AddSubMenu(submenuText, submenuClick)

	local SubMenuTitle = vgui.Create("DLabel")
	SubMenuTitle:SetText("Time:\n")
	SubMenuTitle:SetFont("UiBold")
	SubMenuTitle:SizeToContents()
	SubMenuTitle:SetTextColor(color_black)

	SubMenu:AddPanel(SubMenuTitle)

	for secs, Time in SortedPairs(FAdmin.PlayerActions.commonTimes) do
		SubMenu:AddOption(Time, function() submenuItemClick(secs) end)
	end
end

function FAdmin.PlayerActions.addTimeMenu(ItemClick)
	local menu = DermaMenu()
	local Title = vgui.Create("DLabel")
	Title:SetText("Time:\n")
	Title:SetFont("UiBold")
	Title:SizeToContents()
	Title:SetTextColor(color_black)

	for secs, Time in SortedPairs(FAdmin.PlayerActions.commonTimes) do
		menu:AddOption(Time, function() ItemClick(secs) end)
	end
	menu:Open()
end
