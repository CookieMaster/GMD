CreateClientConVar("FAdmin_IsScoreboard", 1, true, false) -- Set if it's a scoreboard or not

function FAdmin.ScoreBoard.ChangeView(newView, ...)
	if FAdmin.ScoreBoard.CurrentView == newView then return end
	for k,v in pairs(FAdmin.ScoreBoard[FAdmin.ScoreBoard.CurrentView].Controls) do
		v:SetVisible(false)
	end

	FAdmin.ScoreBoard.CurrentView = newView
	FAdmin.ScoreBoard[newView].Show(...)
	FAdmin.ScoreBoard.ChangeGmodLogo(FAdmin.ScoreBoard[newView].Logo)	

end

local GmodLogo, TempGmodLogo, GmodLogoColor = surface.GetTextureID("scoreboard/scoreboard"), surface.GetTextureID("scoreboard/scoreboard"), Color(255,255,255,255)//"FAdmin/back", gui/gmod_tool
function FAdmin.ScoreBoard.ChangeGmodLogo(new)
	if surface.GetTextureID(new) == TempGmodLogo then return end
	TempGmodLogo = surface.GetTextureID(new)
	for i = 0, 0.5, 0.01 do
		timer.Simple(i, function() GmodLogoColor = Color(255,255,255,GmodLogoColor.a-5.1) end)
	end
	timer.Simple(0.5, function() GmodLogo = surface.GetTextureID(new) end)
	for i = 0.5, 1, 0.01 do
		timer.Simple(i, function() GmodLogoColor = Color(255,255,255,GmodLogoColor.a+5.1) end)	
	end
end
	
---------------------------------------------Background----------------------------------------------
function FAdmin.ScoreBoard.Background()
	local ScreenWidth, ScreenHeight = ScrW(), ScrH()
	local scoreboardbackground = surface.GetTextureID("scoreboard/scoreboardbackground")
	local scoreboardtextbackground = surface.GetTextureID("hud/newbackground")
	draw.RoundedBox(6, ScrW() / 2, ScrH() / ScrH() + 10, ScrW() / 2 - 10, ScrH() - 300, Color(0,0,0,240))
	draw.RoundedBox(6, ScrW() / 2 +5, ScrH() / ScrH() + 15, 118, 118,	Color(255,255,255,200))
	surface.SetTexture(GmodLogo)
	surface.SetDrawColor(255,255,255,GmodLogoColor.a)
	surface.DrawTexturedRect( ScrW() / 2, ScrH() / ScrH() + 10, 128, 128)
		surface.SetTexture(scoreboardbackground)
		surface.SetDrawColor(255,255,255,255) // Makes sure the image draws with all colors
		surface.DrawTexturedRect(ScrW() / 2, ScrH() / ScrH() + 168, ScrW() / 2 - 10, ScrH() - 460)
	local scoreboardtextbackground = surface.GetTextureID("hud/newbackground")
	if input.IsButtonDown(KEY_TAB) == true then
	
		surface.SetTexture(scoreboardtextbackground)
		
		
	
	surface.DrawTexturedRect( ScrW() - 620,143, 120, 20)
	draw.SimpleText("Player Name:", "HudSelectionText", ScrW() - 560,152, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	
	
	surface.DrawTexturedRect( ScrW() - 429, 143, 50, 20)
	draw.SimpleText("Job:", "HudSelectionText", ScrW() - 403,152, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)	
	
	surface.DrawTexturedRect( ScrW() - 288, 143, 65, 20)
	draw.SimpleText("Money:", "HudSelectionText", ScrW() - 255, 152, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		
	surface.DrawTexturedRect( ScrW() - 150,143, 45, 20)
	draw.SimpleText("Kills:", "HudSelectionText", ScrW() -128,152, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	
	surface.DrawTexturedRect( ScrW() - 78,143, 43, 20)
	draw.SimpleText("Ping:", "HudSelectionText", ScrW() - 57,152, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	end


function FAdmin.ScoreBoard.DrawScoreBoard()
	if (input.IsMouseDown(MOUSE_4) or input.IsKeyDown(KEY_BACKSPACE)) and not FAdmin.ScoreBoard.DontGoBack then
		FAdmin.ScoreBoard.ChangeView("Main")
	elseif FAdmin.ScoreBoard.DontGoBack then
		FAdmin.ScoreBoard.DontGoBack = input.IsMouseDown(MOUSE_4) or input.IsKeyDown(KEY_BACKSPACE)
	end
	FAdmin.ScoreBoard.Background()
end

function FAdmin.ScoreBoard.ShowScoreBoard()
	FAdmin.ScoreBoard.Visible = true
	FAdmin.ScoreBoard.DontGoBack = input.IsMouseDown(MOUSE_4) or input.IsKeyDown(KEY_BACKSPACE)
	---- REDO REDO REDO!!!!-----
	FAdmin.ScoreBoard.Controls.Hostname = FAdmin.ScoreBoard.Controls.Hostname or vgui.Create("DLabel", self )
	FAdmin.ScoreBoard.Controls.Hostname:SetText(GetHostName())
	FAdmin.ScoreBoard.Controls.Hostname:SetFont("ScoreboardHeader")
	FAdmin.ScoreBoard.Controls.Hostname:SetColor(Color(200,200,200,200))
	FAdmin.ScoreBoard.Controls.Hostname:SetPos(ScrW() / 2 + 133, ScrH() / ScrH() + 35)
	FAdmin.ScoreBoard.Controls.Hostname:SizeToContents()
	FAdmin.ScoreBoard.Controls.Hostname:SetVisible(true)

	FAdmin.ScoreBoard[FAdmin.ScoreBoard.CurrentView].Show()
	hook.Add("HUDPaint", "FAdmin_ScoreBoard", FAdmin.ScoreBoard.DrawScoreBoard)
	return true
end
concommand.Add("+FAdmin_menu", FAdmin.ScoreBoard.ShowScoreBoard)

hook.Add("ScoreboardShow", "FAdmin_scoreboard", function()
	if GAMEMODE and tobool(GetConVarNumber("FAdmin_IsScoreboard")) and FAdmin.GlobalSetting.FAdmin then -- Don't show scoreboard when FAdmin is not installed on server
		return FAdmin.ScoreBoard.ShowScoreBoard()
	end
end)

function FAdmin.ScoreBoard.HideScoreBoard()
	if not FAdmin.GlobalSetting.FAdmin then return end
	FAdmin.ScoreBoard.Visible = false
	CloseDermaMenus()

	gui.EnableScreenClicker(false)
	hook.Remove("HUDPaint", "FAdmin_ScoreBoard")

	for k,v in pairs(FAdmin.ScoreBoard[FAdmin.ScoreBoard.CurrentView].Controls) do
		v:SetVisible(false)
	end

	for k,v in pairs(FAdmin.ScoreBoard.Controls) do
		v:SetVisible(false)
	end
	return true
end
concommand.Add("-FAdmin_menu", FAdmin.ScoreBoard.HideScoreBoard)

hook.Add("ScoreboardHide", "FAdmin_scoreboard", function()
	if tobool(GetConVarNumber("FAdmin_IsScoreboard")) and FAdmin.GlobalSetting.FAdmin then -- Don't show scoreboard when FAdmin is not installed on server
		return FAdmin.ScoreBoard.HideScoreBoard()
	end
end)
