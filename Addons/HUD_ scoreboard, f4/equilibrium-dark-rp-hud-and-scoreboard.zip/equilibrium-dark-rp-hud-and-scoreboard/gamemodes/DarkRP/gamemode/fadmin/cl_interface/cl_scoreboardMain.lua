local Sorted, SortDown = CreateClientConVar("FAdmin_SortPlayerList", "Team", true), CreateClientConVar("FAdmin_SortPlayerListDown", 1, true)
local allowedSorts = {
	["Name"] = false,
	["Team"] = true,
	["Frags"] = false,
	["Deaths"] = false,
	["Ping"] = false
}

function FAdmin.ScoreBoard.Main.Show()
	local Sort = {}
	local ScreenWidth, ScreenHeight = ScrW(), ScrH()

	FAdmin.ScoreBoard.X = ScreenWidth*0.05
	FAdmin.ScoreBoard.Y = ScreenHeight*0.025
	FAdmin.ScoreBoard.Width = ScreenWidth*0.9
	FAdmin.ScoreBoard.Height = ScreenHeight*0.95

	FAdmin.ScoreBoard.ChangeView("Main")

	FAdmin.ScoreBoard.Main.Controls.FAdminPanelList = FAdmin.ScoreBoard.Main.Controls.FAdminPanelList or vgui.Create("DPanelList")
	FAdmin.ScoreBoard.Main.Controls.FAdminPanelList:SetVisible(true)
	FAdmin.ScoreBoard.Main.Controls.FAdminPanelList:Clear(true)
	FAdmin.ScoreBoard.Main.Controls.FAdminPanelList.Padding = 3
	FAdmin.ScoreBoard.Main.Controls.FAdminPanelList:EnableVerticalScrollbar(true)


	FAdmin.ScoreBoard.Main.Controls.FAdminPanelList:Clear(true)

	FAdmin.ScoreBoard.Main.Controls.FAdminPanelList:SetPos(ScrW() / 2 + 5, ScrH() / ScrH() + 168 )
	FAdmin.ScoreBoard.Main.Controls.FAdminPanelList:SetSize(ScrW() / 2 - 20, ScrH() /2)
	

	local sortBy = Sorted:GetString()
	sortBy = allowedSorts[sortBy] and sortBy or "Team"

	FAdmin.ScoreBoard.Main.PlayerListView(sortBy, SortDown:GetBool())

	for k,v in pairs(Sort) do
		v:SetFont("Trebuchet20")
		v:SizeToContents()

		local X, Y = v:GetPos()

		v.BtnSort = vgui.Create("DButton")
		v.BtnSort:SetText("")
		v.BtnSort.Type = "Down"
		v.BtnSort.Paint = function( panel, w, h ) derma.SkinHook("Paint", "ButtonDown", panel, w, h ) end
		v.BtnSort:SetSkin(GAMEMODE.Config.DarkRPSkin)
		if Sorted:GetString() == v.Type then
			v.BtnSort.Depressed = true
			v.BtnSort.Type = (SortDown:GetBool() and "Down") or "Up"
		end
		v.BtnSort:SetSize(16, 16)
		v.BtnSort:SetPos(X + v:GetWide() + 5, Y + 4)
		function v.BtnSort.DoClick()
			for a,b in pairs(Sort) do
				b.BtnSort.Depressed = (b.BtnSort == v.BtnSort)
			end
						FAdmin.ScoreBoard.Main.Controls.FAdminPanelList:Clear(true)
			FAdmin.ScoreBoard.Main.PlayerListView(v.Type, v.BtnSort.Type == "Down")
		end
		table.insert(FAdmin.ScoreBoard.Main.Controls, v) -- Add them to the table so they get removed when you close the scoreboard
		table.insert(FAdmin.ScoreBoard.Main.Controls, v.BtnSort)
		
	end
end

function FAdmin.ScoreBoard.Main.AddPlayerRightClick(Name, func)
	FAdmin.PlayerIcon.RightClickOptions[Name] = func
end