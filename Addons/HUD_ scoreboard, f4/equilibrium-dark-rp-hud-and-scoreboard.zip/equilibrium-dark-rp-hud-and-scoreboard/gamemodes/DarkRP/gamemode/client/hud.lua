/*---------------------------------------------------------------------------
HUD ConVars
---------------------------------------------------------------------------*/
local ConVars = {}
local HUDWidth
local HUDHeight

local Color = Color
local cvars = cvars
local draw = draw
local GetConVar = GetConVar
local Lerp = Lerp
local localplayer
local pairs = pairs
local SortedPairs = SortedPairs
local string = string
local surface = surface
local table = table
local tostring = tostring
local ply

CreateClientConVar("weaponhud", 0, true, false)

local function ReloadConVars()
	ConVars = {
		background = {0,0,0,100},
		Healthbackground = {0,0,0,200},
		Healthforeground = {140,0,0,180},
		HealthText = {255,255,255,200},
		Job1 = {0,0,150,200},
		Job2 = {0,0,0,255},
		salary1 = {0,150,0,200},
		salary2 = {0,0,0,255}
	}
	
	
	for name, Colour in pairs(ConVars) do
		ConVars[name] = {}
		for num, rgb in SortedPairs(Colour) do
			local CVar = GetConVar(name..num) or CreateClientConVar(name..num, rgb, true, false)
			table.insert(ConVars[name], CVar:GetInt())

			if not cvars.GetConVarCallbacks(name..num, false) then
				cvars.AddChangeCallback(name..num, function() timer.Simple(0,ReloadConVars) end)
			end
		end
		ConVars[name] = Color(unpack(ConVars[name]))
	end


	HUDWidth = (GetConVar("HudW") or  CreateClientConVar("HudW", 240, true, false)):GetInt()
	HUDHeight = (GetConVar("HudH") or CreateClientConVar("HudH", 115, true, false)):GetInt()

	if not cvars.GetConVarCallbacks("HudW", false) and not cvars.GetConVarCallbacks("HudH", false) then
		cvars.AddChangeCallback("HudW", function() timer.Simple(0,ReloadConVars) end)
		cvars.AddChangeCallback("HudH", function() timer.Simple(0,ReloadConVars) end)
	end
end
function hidehud(name)
	for k, v in pairs({"CHudHealth", "CHudBattery", "CHudAmmo", "CHudSecondaryAmmo"}) do
		if name == v then return false end
	end
end
hook.Add("HUDShouldDraw", "HideOurHud:D", hidehud)


ReloadConVars()

local function formatNumber(n)
	if not n then return "" end
	if n >= 1e14 then return tostring(n) end
    n = tostring(n)
    local sep = sep or ","
    local dp = string.find(n, "%.") or #n+1
	for i=dp-4, 1, -3 do
		n = n:sub(1, i) .. sep .. n:sub(i+1)
    end
    return n
end


local Scrw, Scrh, RelativeX, RelativeY
/*---------------------------------------------------------------------------
HUD Seperate Elements
---------------------------------------------------------------------------*/
local function DrawInfo()

	local wep = localplayer:GetActiveWeapon()

	if IsValid(wep) then
	draw.RoundedBox(6, ScrW() - 220, ScrH() - 110, 215, 40, Color(0,0,0,200))
	draw.RoundedBox(6, ScrW() - 215, ScrH() - 105, 205, 30, Color(0,0,0,255))
	
		local hudbackground = surface.GetTextureID("hud/newbackground")
		surface.SetTexture(hudbackground)
		surface.SetDrawColor(255,255,255,255) // Makes sure the image draws with all colors
		surface.DrawTexturedRect(ScrW() - 215, ScrH() - 105, 205, 30)
	
        local name = wep:GetPrintName();
		draw.DrawText("Weapon: "..name, "UiBold", ScrW() - 112,ScrH() - 100, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end

local Page = Material("icon16/page_white_text.png")
local function GunLicense()
	if localplayer:getDarkRPVar("HasGunlicense") then
		surface.SetMaterial(Page)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawTexturedRect(RelativeX + HUDWidth, ScrH() - 34, 32, 32)
	end
end

local function Agenda()
	local DrawAgenda, AgendaManager = DarkRPAgendas[localplayer:Team()], localplayer:Team()
	if not DrawAgenda then
		for k,v in pairs(DarkRPAgendas) do
			if table.HasValue(v.Listeners or {}, localplayer:Team()) then
				DrawAgenda, AgendaManager = DarkRPAgendas[k], k
				break
			end
		end
	end
	if DrawAgenda then
		draw.RoundedBox(10, 10, 10, 420, 110, Color(0, 0, 0, 155))
		draw.RoundedBox(10, 12, 12, 416, 106, Color(51, 58, 51,100))
		draw.RoundedBox(10, 12, 12, 416, 20, Color(0, 0, 0, 255))

		draw.DrawText(DrawAgenda.Title, "DarkRPHUD1", 208, 12, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		local AgendaText = {}
		for k,v in pairs(team.GetPlayers(AgendaManager)) do
			if not v.DarkRPVars then continue end
			table.insert(AgendaText, v:getDarkRPVar("agenda"))
		end

		local text = table.concat(AgendaText, "\n")
		text = text:gsub("//", "\n"):gsub("\\n", "\n")
		text = GAMEMODE:TextWrap(text, "DarkRPHUD1", 440)
		draw.DrawText(text, "DarkRPHUD1", 218, 35, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end

local VoiceChatTexture = surface.GetTextureID("voice/icntlk_pl")
local function DrawVoiceChat()
	if localplayer.DRPIsTalking then
		local chbxX, chboxY = chat.GetChatBoxPos()

		local Rotating = math.sin(CurTime()*3)
		local backwards = 0
		if Rotating < 0 then
			Rotating = 1-(1+Rotating)
			backwards = 180
		end
		surface.SetTexture(VoiceChatTexture)
		surface.SetDrawColor(ConVars.Healthforeground)
		surface.DrawTexturedRectRotated(ScrW() - 300, chboxY, Rotating*96, 96, backwards)
	end
end

local function LockDown()
	local chbxX, chboxY = chat.GetChatBoxPos()
	if util.tobool(GetConVarNumber("DarkRP_LockDown")) then
		local cin = (math.sin(CurTime()) + 1) / 2
		local chatBoxSize = math.floor(ScrH() / 4)
		draw.DrawText(DarkRP.getPhrase("lockdown_started"), "ScoreboardSubtitle", chbxX, chboxY + chatBoxSize, Color(cin * 255, 0, 255 - (cin * 255), 255), TEXT_ALIGN_LEFT)
	end
end

local Arrested = function() end

usermessage.Hook("GotArrested", function(msg)
	local StartArrested = CurTime()
	local ArrestedUntil = msg:ReadFloat()

	Arrested = function()
		if CurTime() - StartArrested <= ArrestedUntil and localplayer:getDarkRPVar("Arrested") then
		draw.DrawText(DarkRP.getPhrase("youre_arrested", math.ceil(ArrestedUntil - (CurTime() - StartArrested))), "DarkRPHUD1", ScrW()/2, ScrH() - ScrH()/12, Color(255,255,255,255), 1)
		elseif not localplayer:getDarkRPVar("Arrested") then
			Arrested = function() end
		end
	end
end)

local AdminTell = function() end

usermessage.Hook("AdminTell", function(msg)
	local Message = msg:ReadString()

	AdminTell = function()
		draw.RoundedBox(4, 10, 10, ScrW() - 20, 100, Color(0, 0, 0, 200))
		draw.DrawText(DarkRP.getPhrase("listen_up"), "GModToolName", ScrW() / 2 + 10, 10, Color(255, 255, 255, 255), 1)
		draw.DrawText(Message, "ChatFont", ScrW() / 2 + 10, 80, Color(200, 30, 30, 255), 1)
	end

	timer.Simple(10, function()
		AdminTell = function() end
	end)
end)
local function Dafuq()

	localplayer = localplayer and IsValid(localplayer) and localplayer or LocalPlayer()
	if not IsValid(localplayer) then return end
	local shouldDraw = hook.Call("HUDShouldDraw", GAMEMODE, "DarkRP_HUD")
	if shouldDraw == false then return else 
		local hudbackground = surface.GetTextureID("hud/newbackground")
	draw.RoundedBox(6, ScrW() - 220, ScrH() - 65, 215, 60, Color(0,0,0,200))
		draw.RoundedBox(6,ScrW() - 215, ScrH() - 60, 205, 50, Color(0,0,0,220))
		surface.SetTexture(hudbackground)
		surface.SetDrawColor(255,255,255,255) // Makes sure the image draws with all colors
		surface.DrawTexturedRect(ScrW() - 215, ScrH() - 60, 205, 50)
	
	draw.SimpleText("Clip                Spare", "HudSelectionText", ScrW() - 115, ScrH() - 50, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	 if IsValid(localplayer:GetActiveWeapon()) then 
	local mag_extra = localplayer:GetAmmoCount(localplayer:GetActiveWeapon():GetPrimaryAmmoType())
	local ammo = (math.max((localplayer:GetActiveWeapon():Clip1()), 0)) .. "        /        " .. mag_extra
	--Ammo

	draw.SimpleText(ammo, "DarkRPHUD2", ScrW() - 112, ScrH() - 25, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) else return
	end
	end
	end
hook.Add( "HUDPaint", "Dafuq", Dafuq )

/*---------------------------------------------------------------------------
Drawing the HUD elements such as Health etc.
---------------------------------------------------------------------------*/
Health = 0
local function DrawHUD()
	localplayer = localplayer and IsValid(localplayer) and localplayer or LocalPlayer()
	if not IsValid(localplayer) then return end

	local shouldDraw = hook.Call("HUDShouldDraw", GAMEMODE, "DarkRP_HUD")
	if shouldDraw == false then return else 

	
	Scrw, Scrh = ScrW(), ScrH()
	RelativeX, RelativeY = 0, Scrh

	local Salary = 	"Salary: " .. GAMEMODE.Config.currency .. (localplayer:getDarkRPVar("salary") or 0)
	local Job = localplayer:getDarkRPVar("job") or ""
	local Wallet = GAMEMODE.Config.currency .. (formatNumber(localplayer:getDarkRPVar("money") or 0) or 0)
	local Name = "Rp Name: " .. LocalPlayer():Nick() or 0
	local longName = LocalPlayer():Nick() or 0

	local hudbackground = surface.GetTextureID("hud/newbackground")
	

	
	--Background left box							      \/ box width
	draw.RoundedBox(6, ScrW() / ScrW() + 5, ScrH() - 125, 205, 120, Color(0,0,0,200))
	--														    ^ heighth starts from top
	-- Job
	draw.RoundedBox(6, ScrW() / ScrW() + 10, ScrH() - 60, 195, 25, team.GetColor(LocalPlayer():Team()))
	draw.SimpleText(Job, "DarkRPHUD2", ScrW() / ScrW() + 105, ScrH() - 47, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	-- Salary
	draw.RoundedBox(6, ScrW() / ScrW() + 10, ScrH() - 30, 100, 20, Color(0,0,0,255))
		surface.SetTexture(hudbackground)
		surface.SetDrawColor(255,255,255,255) // Makes sure the image draws with all colors
		surface.DrawTexturedRect(ScrW() / ScrW() + 10, ScrH() - 30, 100, 20)
	draw.SimpleText(Salary, "HudSelectionText", ScrW() / ScrW() + 60,ScrH() - 20, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)	

	-- Wallet
	draw.RoundedBox(6, ScrW() / ScrW() + 115, ScrH() - 30, 90, 20, Color(0,0,0,255))
		surface.SetTexture(hudbackground)
		surface.SetDrawColor(255,255,255,255) // Makes sure the image draws with all colors
		surface.DrawTexturedRect(ScrW() / ScrW() + 115, ScrH() - 30, 90, 20)
	draw.SimpleText(Wallet, "HudSelectionText", ScrW() / ScrW() + 160,ScrH() - 20, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	-- Name
	draw.RoundedBox(6, ScrW() / ScrW() + 10, ScrH() - 90, 195, 25, Color(0,0,0,255))
		surface.SetTexture(hudbackground)
		surface.SetDrawColor(255,255,255,255) // Makes sure the image draws with all colors
		surface.DrawTexturedRect(ScrW() / ScrW() + 10, ScrH() - 90, 195, 25)
	local hiwidth, height = surface.GetTextSize("Rp Name: " .. LocalPlayer():Nick())
	local lowwidth, height = surface.GetTextSize(LocalPlayer():Nick())
	if hiwidth < 185 then
		draw.SimpleText(Name,"HudSelectionText", ScrW() / ScrW() + 105, ScrH() - 77, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)		 else
		if hiwidth > 185 and lowwidth < 185 then
		draw.SimpleText(longName,"HudSelectionText", ScrW() / ScrW() + 105, ScrH() - 77, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) else 
		if lowwidth > 185 then
		draw.SimpleText(longName,"DebugFixed", ScrW() / ScrW() + 105, ScrH() - 77, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER) 
		end
		end
	end
 
	
	
	--Color shit
Health = math.min(100, (Health == localplayer:Health() and Health) or Lerp(0.1, Health, localplayer:Health()))
Armor = math.Min(100, localplayer:Armor())
local DrawHealth = math.Min(Health / GAMEMODE.Config.startinghealth, 1)
local Drawarmor = math.Min(Armor / 100)
local Drawarmor2 = math.Min(Armor / 100)
local redphase = math.Min(255 - 255 * DrawHealth)
local redphasein = math.Min(255 - 155 * Drawarmor)
local redphasein2 = math.Min(255 - 255 * Drawarmor)
local hpextracolor = Color(0 + redphase,255 * DrawHealth,0,200) -- the health bar color
local armorcolor = Color(0 + redphasein,145* Drawarmor,255 * Drawarmor, 255)
local armorcolor2 = Color(0 + redphasein2,0,255 * Drawarmor, 255)
	-- Armor
			draw.RoundedBox(6,ScrW() / ScrW() + 95, ScrH() - 120, 110, 25, Color(0,0,0,220))
			surface.SetTexture(hudbackground)
			surface.SetDrawColor(255,255,255,255)
			surface.DrawTexturedRect(ScrW() / ScrW() + 95, ScrH() - 120, 110, 25)
		draw.SimpleText("Armor: " .. math.Max(0, math.Round(LocalPlayer():Armor())),"HudSelectionText", ScrW() / ScrW() + 145, ScrH() - 109, armorcolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

		draw.RoundedBox(6, ScrW() / ScrW() + 46,ScrH() - 340, 36, 210, Color(0,0,0,200))
		draw.RoundedBox(6, ScrW() / ScrW() + 51,ScrH() - 335 , 26 ,200 , Color(0,0,0,220))
		surface.SetTexture(hudbackground)
		surface.SetDrawColor(255,255,255,255)
		surface.DrawTexturedRect(ScrW() / ScrW() + 51,ScrH() - 335 , 26 ,200 )
		
		if Armor > 1 then
		draw.RoundedBox(6, ScrW() / ScrW() + 51,ScrH() - 135 - Armor * 2, 26 ,(200 * Drawarmor2) * 1 , armorcolor2)
	else end

	-- Health
	draw.RoundedBox(6, ScrW() / ScrW() + 5,ScrH() - 340, 36, 210, Color(0,0,0,200))	
	draw.RoundedBox(6, ScrW() / ScrW() + 10,ScrH() - 335 , 26 ,200 , Color(0,0,0,220))
		surface.SetTexture(hudbackground)
		surface.SetDrawColor(255,255,255,255) // Makes sure the image draws with all colors
		surface.DrawTexturedRect( ScrW() / ScrW() + 10,ScrH() - 335 , 26 ,200)


	if Health > 0 then 
		draw.RoundedBox(6, ScrW() / ScrW() + 10,ScrH() - 135 - Health * 2, 26 ,(200 * DrawHealth) * 1 , hpextracolor)
	else end	

	------------------ Health Number Crap -----------------
	
	draw.RoundedBox(6, ScrW() / ScrW() + 10, ScrH() - 120, 80, 25, Color(0,0,0,255))
		surface.SetTexture(hudbackground)
		surface.SetDrawColor(255,255,255,255) // Makes sure the image draws with all colors
		surface.DrawTexturedRect(ScrW() / ScrW() + 10, ScrH() - 120, 80, 25)
	draw.SimpleText("HP: " .. math.Max(0, math.Round(LocalPlayer():Health())),"HudSelectionText", ScrW() / ScrW() + 50, ScrH() - 109, hpextracolor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)	

	DrawInfo()
	GunLicense()
	Agenda()
	DrawVoiceChat()
	LockDown()

	Arrested()
	AdminTell()
end
end


/*---------------------------------------------------------------------------
Entity HUDPaint things
---------------------------------------------------------------------------*/
local function DrawPlayerInfo(ply)
	local pos = ply:EyePos()

	pos.z = pos.z + 10 -- The position we want is a bit above the position of the eyes
	pos = pos:ToScreen()
	pos.y = pos.y - 50 -- Move the text up a few pixels to compensate for the height of the text

	if GAMEMODE.Config.showname and not ply:getDarkRPVar("wanted") then
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x + 1, pos.y + 1, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x, pos.y, team.GetColor(ply:Team()), 1)
		draw.DrawText("Health: "..ply:Health(), "DarkRPHUD2", pos.x + 1, pos.y + 21, Color(0, 0, 0, 255), 1)
		draw.DrawText("Health: "..ply:Health(), "DarkRPHUD2", pos.x, pos.y + 20, Color(255,255,255,200), 1)
	end

	if GAMEMODE.Config.showjob then
		local teamname = team.GetName(ply:Team())
		draw.DrawText(ply:getDarkRPVar("job") or teamname, "DarkRPHUD2", pos.x + 1, pos.y + 41, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply:getDarkRPVar("job") or teamname, "DarkRPHUD2", pos.x, pos.y + 40, Color(255, 255, 255, 200), 1)
	end

	if ply:getDarkRPVar("HasGunlicense") then
		surface.SetMaterial(Page)
		surface.SetDrawColor(255,255,255,255)
		surface.DrawTexturedRect(pos.x-16, pos.y + 60, 32, 32)
	end
end

local function DrawWantedInfo(ply)
	if not ply:Alive() then return end

	local pos = ply:EyePos()
	if not pos:RPIsInSight({localplayer, ply}) then return end

	pos.z = pos.z + 14
	pos = pos:ToScreen()

	if GAMEMODE.Config.showname then
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x + 1, pos.y + 1, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x, pos.y, team.GetColor(ply:Team()), 1)
	end

	local wantedText = string.format("%s\nReason: %s", LANGUAGE.wanted, tostring(ply.DarkRPVars["wantedReason"]))

	draw.DrawText(wantedText, "DarkRPHUD2", pos.x, pos.y - 40, Color(255, 255, 255, 200), 1)
	draw.DrawText(wantedText, "DarkRPHUD2", pos.x + 1, pos.y - 41, Color(255, 0, 0, 255), 1)
end

/*---------------------------------------------------------------------------
The Entity display: draw HUD information about entities
---------------------------------------------------------------------------*/
local function DrawEntityDisplay()
	local shouldDraw = hook.Call("HUDShouldDraw", GAMEMODE, "DarkRP_EntityDisplay")
	if shouldDraw == false then return end

	local shootPos = localplayer:GetShootPos()
	local aimVec = localplayer:GetAimVector()

	for k, ply in pairs(player.GetAll()) do
		if not ply:Alive() then continue end
		local hisPos = ply:GetShootPos()
		if ply:getDarkRPVar("wanted") then DrawWantedInfo(ply) end

		if GAMEMODE.Config.globalshow and ply ~= localplayer then
			DrawPlayerInfo(ply)
		-- Draw when you're (almost) looking at him
		elseif not GAMEMODE.Config.globalshow and hisPos:Distance(shootPos) < 400 then
			local pos = hisPos - shootPos
			local unitPos = pos:GetNormalized()
			if unitPos:Dot(aimVec) > 0.95 then
				local trace = util.QuickTrace(shootPos, pos, localplayer)
				if trace.Hit and trace.Entity ~= ply then return end
				DrawPlayerInfo(ply)
			end
		end
	end

	local tr = localplayer:GetEyeTrace()

	if IsValid(tr.Entity) and tr.Entity:IsOwnable() and tr.Entity:GetPos():Distance(localplayer:GetPos()) < 200 then
		tr.Entity:DrawOwnableInfo()
	end
end

/*---------------------------------------------------------------------------
Zombie display
---------------------------------------------------------------------------*/
local function DrawZombieInfo()
	if not localplayer:getDarkRPVar("zombieToggle") then return end
	local shouldDraw = hook.Call("HUDShouldDraw", GAMEMODE, "DarkRP_ZombieInfo")
	if shouldDraw == false then return end

	for x=1, localplayer:getDarkRPVar("numPoints"), 1 do
		local zPoint = localplayer.DarkRPVars["zPoints".. x]
		if zPoint then
			zPoint = zPoint:ToScreen()
			draw.DrawText("Zombie Spawn (" .. x .. ")", "DarkRPHUD2", zPoint.x, zPoint.y - 20, Color(255, 255, 255, 200), 1)
			draw.DrawText("Zombie Spawn (" .. x .. ")", "DarkRPHUD2", zPoint.x + 1, zPoint.y - 21, Color(255, 0, 0, 255), 1)
		end
	end
end
 
/*---------------------------------------------------------------------------
Actual HUDPaint hook
---------------------------------------------------------------------------*/
function GM:HUDPaint()
	DrawHUD()
	DrawZombieInfo()
	DrawEntityDisplay()

	self.BaseClass:HUDPaint()
end