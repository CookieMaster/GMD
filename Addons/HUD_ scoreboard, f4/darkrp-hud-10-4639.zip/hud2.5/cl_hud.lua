/*---------------------------------------------------------------------------
HUD ConVars
---------------------------------------------------------------------------*/
local ConVars = {}
local HUDWidth
local HUDHeight

local Color = Color
local cvars = cvars
local draw = draw
local GetConVar = GetConVar
local Lerp = Lerp
local localplayer
local pairs = pairs
local SortedPairs = SortedPairs
local string = string
local surface = surface
local table = table
local tostring = tostring

CreateClientConVar("weaponhud", 0, true, false)

local function ReloadConVars()
	ConVars = {
		background = {0,0,0,100},
		Healthbackground = {0,0,0,200},
		Healthforeground = {140,0,0,180},
		HealthText = {255,255,255,200},
		Job1 = {0,0,150,200},
		Job2 = {0,0,0,255},
		salary1 = {0,150,0,200},
		salary2 = {0,0,0,255}
	}

	for name, Colour in pairs(ConVars) do
		ConVars[name] = {}
		for num, rgb in SortedPairs(Colour) do
			local CVar = GetConVar(name..num) or CreateClientConVar(name..num, rgb, true, false)
			table.insert(ConVars[name], CVar:GetInt())

			if not cvars.GetConVarCallbacks(name..num, false) then
				cvars.AddChangeCallback(name..num, function() timer.Simple(0,ReloadConVars) end)
			end
		end
		ConVars[name] = Color(unpack(ConVars[name]))
	end


	HUDWidth = (GetConVar("HudW") or  CreateClientConVar("HudW", 240, true, false)):GetInt()
	HUDHeight = (GetConVar("HudH") or CreateClientConVar("HudH", 115, true, false)):GetInt()

	if not cvars.GetConVarCallbacks("HudW", false) and not cvars.GetConVarCallbacks("HudH", false) then
		cvars.AddChangeCallback("HudW", function() timer.Simple(0,ReloadConVars) end)
		cvars.AddChangeCallback("HudH", function() timer.Simple(0,ReloadConVars) end)
	end
end
ReloadConVars()

local function formatNumber(n)
	if not n then return "" end
	if n >= 1e14 then return tostring(n) end
    n = tostring(n)
    local sep = sep or ","
    local dp = string.find(n, "%.") or #n+1
	for i=dp-4, 1, -3 do
		n = n:sub(1, i) .. sep .. n:sub(i+1)
    end
    return n
end


local Scrw, Scrh, RelativeX, RelativeY
/*---------------------------------------------------------------------------
HUD Seperate Elements
---------------------------------------------------------------------------*/
surface.CreateFont( "SBPName", {
	font = "Arial",
	size = 20,
	weight = 700,
	antialias = true,
	shadow = true,
} )

surface.CreateFont( "SBPName2", {
	font = "Arial",
	size = 20,
	weight = 700,
	antialias = true,
	shadow = true,
} )

/*---------------------------------------------------------------------------
Change HUD Colours 
---------------------------------------------------------------------------*/
local x = 0
local x1 = 0
local y = 0

if ScrW() == 1280 and ScrH() == 720 then x = 30 end
if ScrW() == 1680 and ScrH() == 1050 then x = -150 end
if ScrW() == 1600 and ScrH() == 1024 then x = -130 end
if ScrW() == 1440 and ScrH() == 900 then x = -50 end
if ScrW() == 1280 and ScrH() == 800 then x = 30 end
if ScrW() == 1280 and ScrH() == 768 then x = 30 end
if ScrW() == 1152 and ScrH() == 864 then x = 95 end
if ScrW() == 1024 and ScrH() == 768 then x = -150 y = -80 x1 = -55 end

local function GetAmmo(ply)
   local weap = ply:GetActiveWeapon()
   if not weap or not ply:Alive() then return -1 end

   local ammo_inv = weap:Ammo1()
   local ammo_clip = weap:Clip1()
   local ammo_max = weap.Primary.ClipSize

   return ammo_clip, ammo_max, ammo_inv
end

elements = surface.GetTextureID( "boowman/gradient" )
grad = Material("gui/gradient.png")
grad_d = Material("gui/gradient_down.png")
grad_u = Material("gui/gradient_up.png")

heart = Material("icon16/heart.png")
shield = Material("icon16/shield.png")
money = Material("icon16/money_dollar.png")
salary = Material("icon16/money.png")

local function custompoly(name,x,x2,w,h,z,q,color)
	
name = {{},{},{},{}}
	name[1]["x"] = x
	name[1]["y"] = ScrH()-z
	
	name[2]["x"] = w
	name[2]["y"] = ScrH()-z
	
	name[3]["x"] = h
	name[3]["y"] = ScrH()-q
	
	name[4]["x"] = x2
	name[4]["y"] = ScrH()-q
	
	surface.SetDrawColor(color)
	surface.SetTexture( elements )
    surface.DrawPoly( name )	
end

local function DrawHealth()
	LocalPlayer().DarkRPVars = LocalPlayer().DarkRPVars or {}
	local ply = LocalPlayer()
	local hp,ar = ply:Health(),ply:Armor()
	local slujba = ply:getDarkRPVar("job") or "Unemployed"
	local salar = formatNumber(ply:getDarkRPVar("salary") or 0)
	local bani = formatNumber(ply:getDarkRPVar("money") or 0)
	local name = ply:Nick()
	local group = ply:GetNWString("usergroup")
	local hplenght = math.Clamp(hp,0,100)*2.18
	local arlenght = math.Clamp(ar,0,100)*2.42
	
		// Bottom Bar
	draw.RoundedBox(0,0,ScrH()-20,ScrW(),20,Color(19,37,37,255))
	draw.RoundedBox(0,0,ScrH()-20,ScrW(),4,Color(37,104,134,255))
	
		// Elements Background
	custompoly(polyelbg,0,0,300,360,80,20,Color(37,104,134,255))
	custompoly(polyel,0,0,296,356,76,16,Color(19,37,37,255))
	
		// Model
	surface.SetDrawColor(128,128,128,255)
	surface.DrawRect( 5, ScrH()-70, 70, 70 )
	
		// Health
	custompoly(polyhpbg,75,75,296,316,70,50,Color(128,128,128,255))	
	custompoly(polyhp,95,95,hplenght+75,hplenght+92,68,52,Color(127,0,0,255))	
	draw.DrawText("Health: "..hp.."%","TargetID",100,ScrH()-68,color_white,TEXT_ALIGN_LEFT)
	
	surface.SetMaterial(heart)
	surface.SetDrawColor(255,255,255,255)
	surface.DrawTexturedRect(80,ScrH()-66,13,13)
		
		// Armor
	custompoly(polyhpbg,75,75,320,340,45,25,Color(128,128,128,255))
	custompoly(polyar,95,95,arlenght+75,arlenght+92,43,27,Color(0,74,130,255))
	draw.DrawText("Armor: "..ar.."%","TargetID",100,ScrH()-43,color_white,TEXT_ALIGN_LEFT)
	
	surface.SetMaterial(shield)
	surface.SetDrawColor(255,255,255,255)
	surface.DrawTexturedRect(80,ScrH()-42,13,13)
		
		// Money	
	custompoly(polymonbg,75,75,343,363,20,0,Color(128,128,128,255))
	
	custompoly(polymonbg,95,95,247,264,18,2,Color(37,127,0,255)) // Wallet
	custompoly(polymonbg,280,290,340,357,18,2,Color(37,127,0,255)) // Sallary
	draw.DrawText(bani,"TargetID",100,ScrH()-17,color_white,TEXT_ALIGN_LEFT)
	draw.DrawText("$"..salar,"TargetID",295,ScrH()-17,color_white,TEXT_ALIGN_LEFT)
	
	surface.SetMaterial(money)
	surface.SetDrawColor(255,255,255,255)
	surface.DrawTexturedRect(80,ScrH()-16,13,13)	
	
	surface.SetMaterial(salary)
	surface.SetDrawColor(255,255,255,255)
	surface.DrawTexturedRect(267,ScrH()-16,13,13)

		// Job,Name,Rank	
	draw.DrawText("Job: "..slujba,"TargetID",ScrW()/2-300+x+x1,ScrH()-15+y,color_white,TEXT_ALIGN_LEFT)
	draw.DrawText(name,"TargetID",ScrW()/2,ScrH()-15,color_white,TEXT_ALIGN_CENTER)
	draw.DrawText("Rank: "..group,"TargetID",ScrW()/2+360-x,ScrH()-15+y,color_white,TEXT_ALIGN_RIGHT)
		
		// Community name
	draw.DrawText("Community Name","TargetID",ScrW()-5,ScrH()-15,color_white,TEXT_ALIGN_RIGHT)
				
		// Ammo Background
	if !IsValid(ply:GetActiveWeapon()) then return end
	if (ply:GetActiveWeapon():Clip1() == NULL or ply:GetActiveWeapon() == "Camera") then return end
	local mag_left = LocalPlayer():GetActiveWeapon():Clip1()
	local mag_extra = LocalPlayer():GetAmmoCount(ply:GetActiveWeapon():GetPrimaryAmmoType()) // Current Ammunition outside the mag

	if ply:GetActiveWeapon().Primary then
		if mag_left == -1 then return end
			
	custompoly(polyambg,ScrW()-250,ScrW()-310,ScrW(),ScrW(),80,20,Color(19,104,134,255))
	custompoly(polyam,ScrW()-246,ScrW()-306,ScrW(),ScrW(),76,16,Color(19,37,37,255))
	
	custompoly(polywepname,ScrW()-290,ScrW()-309,ScrW(),ScrW(),20,0,Color(128,128,128,255))
	custompoly(polyweaponmag,ScrW()-266,ScrW()-286,ScrW(),ScrW(),45,25,Color(128,128,128,255))
	custompoly(polymagbg,ScrW()-242,ScrW()-262,ScrW(),ScrW(),70,50,Color(128,128,128,255))
	
	local ammo_clip, ammo_max, ammo_inv = GetAmmo(ply)
	custompoly(polymagbg,ScrW()-ammo_clip/ammo_max*240,ScrW()-ammo_clip/ammo_max*256,ScrW(),ScrW(),68,52,Color(32,32,32,255))
	
	local wep = ply:GetActiveWeapon()
	local name = wep:GetPrintName()
	draw.DrawText(name.." :Weapon", "TargetID", ScrW()-5,ScrH()-17,Color(255,255,255,255),TEXT_ALIGN_RIGHT)
	draw.DrawText(mag_left.." + "..mag_extra,"TargetID",ScrW()-5,ScrH()-43,Color(255,255,255,255),TEXT_ALIGN_RIGHT)		
	end
	
end
	
hook.Add("InitPostEntity", "DrawPlayerModel", function()
	iconmodel = vgui.Create("DModelPanel")
	iconmodel:SetModel( LocalPlayer():GetModel())
function iconmodel:LayoutEntity( Entity ) return end
	iconmodel:SetPos(0, ScrH()-85)
	iconmodel:SetAnimated(false)
	iconmodel:SetSize(85,85)
	iconmodel:SetCamPos( Vector( 20, -5, 65))
	iconmodel:SetLookAt( Vector( 0, 0, 66.5 ) )
	
	timer.Create("RefreshAvatar", 0.1, 0, function()
		if LocalPlayer():GetModel() ~= iconmodel.Entity:GetModel() then
			iconmodel:Remove()		
			iconmodel = vgui.Create("DModelPanel")
			iconmodel:SetPos(0, ScrH()-85)
			iconmodel:SetModel( LocalPlayer():GetModel())
			function iconmodel:LayoutEntity( Entity ) return end
			iconmodel:SetAnimated(false)
			iconmodel:SetSize(85,85)
			iconmodel:SetCamPos( Vector( 20, -5, 65))
			iconmodel:SetLookAt( Vector( 0, 0, 66.5 ) )
		end
	end)
end)

local function DrawInfo()
	local Salary = DarkRP.getPhrase("salary", GAMEMODE.Config.currency, (localplayer:getDarkRPVar("salary") or 0))

	local JobWallet = {
		DarkRP.getPhrase("job", localplayer:getDarkRPVar("job") or ""), "\n",
		DarkRP.getPhrase("wallet", GAMEMODE.Config.currency, formatNumber(localplayer:getDarkRPVar("money") or 0))
	}
	JobWallet = table.concat(JobWallet)

	local wep = localplayer:GetActiveWeapon()

	if IsValid(wep) and GAMEMODE.Config.weaponhud then
        local name = wep:GetPrintName();
		draw.DrawText(DarkRP.getPhrase("weapon", name), "UiBold", RelativeX + 5, RelativeY - HUDHeight - 18, Color(255, 255, 255, 255), 0)
	end

	surface.SetFont("DarkRPHUD2")
	local w, h = surface.GetTextSize(Salary)

end

local licence = Material("icon16/page_white_text.png")
local function GunLicense()
	if localplayer:getDarkRPVar("HasGunlicense") then
		surface.SetMaterial(licence)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawTexturedRect(ScrW()/2-325,ScrH() - 55,32,32)
	end
end

local function Agenda()
	local shouldDraw = hook.Call("HUDShouldDraw", GAMEMODE, "DarkRP_Agenda")
	if shouldDraw == false then return end
	local DrawAgenda, AgendaManager = DarkRPAgendas[localplayer:Team()], localplayer:Team()
	if not DrawAgenda then
		for k,v in pairs(DarkRPAgendas) do
			if table.HasValue(v.Listeners or {}, localplayer:Team()) then
				DrawAgenda, AgendaManager = DarkRPAgendas[k], k
				break
			end
		end
	end
	if DrawAgenda then
		draw.RoundedBox(10, 10, 10, 460, 110, Color(0, 0, 0, 155))
		draw.RoundedBox(10, 12, 12, 456, 106, Color(51, 58, 51,100))
		draw.RoundedBox(10, 12, 12, 456, 20, Color(0, 0, 70, 100))

		draw.DrawText(DrawAgenda.Title, "DarkRPHUD1", 30, 12, Color(255,0,0,255),0)

		local AgendaText = {}
		for k,v in pairs(team.GetPlayers(AgendaManager)) do
			if not v.DarkRPVars then continue end
			table.insert(AgendaText, v:getDarkRPVar("agenda"))
		end

		local text = table.concat(AgendaText, "\n")
		text = text:gsub("//", "\n"):gsub("\\n", "\n")
		text = DarkRP.textWrap(text, "DarkRPHUD1", 440)
		draw.DrawText(text, "DarkRPHUD1", 30, 35, Color(255,255,255,255),0)
	end
end

local VoiceChatTexture = surface.GetTextureID("voice/icntlk_pl")
local function DrawVoiceChat()
	if localplayer.DRPIsTalking then
		local chbxX, chboxY = chat.GetChatBoxPos()

		local Rotating = math.sin(CurTime()*3)
		local backwards = 0
		if Rotating < 0 then
			Rotating = 1-(1+Rotating)
			backwards = 180
		end
		surface.SetTexture(VoiceChatTexture)
		surface.SetDrawColor(ConVars.Healthforeground)
		surface.DrawTexturedRectRotated(ScrW() - 100, chboxY, Rotating*96, 96, backwards)
	end
end

CreateConVar("DarkRP_LockDown", 0, {FCVAR_REPLICATED, FCVAR_SERVER_CAN_EXECUTE})
local function LockDown()
	local chbxX, chboxY = chat.GetChatBoxPos()
	if util.tobool(GetConVarNumber("DarkRP_LockDown")) then
		local cin = (math.sin(CurTime()) + 1) / 2
		local chatBoxSize = math.floor(ScrH() / 4)
		draw.DrawText(DarkRP.getPhrase("lockdown_started"), "ScoreboardSubtitle", chbxX, chboxY + chatBoxSize, Color(cin * 255, 0, 255 - (cin * 255), 255), TEXT_ALIGN_LEFT)
	end
end

local Arrested = function() end

usermessage.Hook("GotArrested", function(msg)
	local StartArrested = CurTime()
	local ArrestedUntil = msg:ReadFloat()

	Arrested = function()
		if CurTime() - StartArrested <= ArrestedUntil and localplayer:getDarkRPVar("Arrested") then
		draw.DrawText(DarkRP.getPhrase("youre_arrested", math.ceil(ArrestedUntil - (CurTime() - StartArrested))), "DarkRPHUD1", ScrW()/2, ScrH() - ScrH()/12, Color(255,255,255,255), 1)
		elseif not localplayer:getDarkRPVar("Arrested") then
			Arrested = function() end
		end
	end
end)

local AdminTell = function() end

usermessage.Hook("AdminTell", function(msg)
	timer.Destroy("DarkRP_AdminTell")
	local Message = msg:ReadString()

	AdminTell = function()
		draw.RoundedBox(4, 10, 10, ScrW() - 20, 100, Color(0, 0, 0, 200))
		draw.DrawText(DarkRP.getPhrase("listen_up"), "GModToolName", ScrW() / 2 + 10, 10, Color(255, 255, 255, 255), 1)
		draw.DrawText(Message, "ChatFont", ScrW() / 2 + 10, 80, Color(200, 30, 30, 255), 1)
	end

	timer.Create("DarkRP_AdminTell", 10, 1, function()
		AdminTell = function() end
	end)
end)

/*---------------------------------------------------------------------------
Drawing the HUD elements such as Health etc.
---------------------------------------------------------------------------*/
local function DrawHUD()
	localplayer = localplayer and IsValid(localplayer) and localplayer or LocalPlayer()
	if not IsValid(localplayer) then return end

	local shouldDraw = hook.Call("HUDShouldDraw", GAMEMODE, "DarkRP_HUD")
	if shouldDraw == false then return end

	Scrw, Scrh = ScrW(), ScrH()
	RelativeX, RelativeY = 0, Scrh

	shouldDraw = hook.Call("HUDShouldDraw", GAMEMODE, "DarkRP_LocalPlayerHUD")
	if shouldDraw ~= false then
		DrawHealth()
		DrawInfo()
		GunLicense()
	end
	Agenda()
	DrawVoiceChat()
	LockDown()

	Arrested()
	AdminTell()
end

/*---------------------------------------------------------------------------
Entity HUDPaint things
---------------------------------------------------------------------------*/
local function DrawPlayerInfo(ply)
	local pos = ply:EyePos()

	pos.z = pos.z + 10 -- The position we want is a bit above the position of the eyes
	pos = pos:ToScreen()
	pos.y = pos.y - 50 -- Move the text up a few pixels to compensate for the height of the text

	if GAMEMODE.Config.showname and not ply:getDarkRPVar("wanted") then
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x + 1, pos.y + 1, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x, pos.y, team.GetColor(ply:Team()), 1)
		draw.DrawText(DarkRP.getPhrase("health", ply:Health()), "DarkRPHUD2", pos.x + 1, pos.y + 21, Color(0, 0, 0, 255), 1)
		draw.DrawText(DarkRP.getPhrase("health", ply:Health()), "DarkRPHUD2", pos.x, pos.y + 20, Color(255,255,255,200), 1)
	end

	if GAMEMODE.Config.showjob then
		local teamname = team.GetName(ply:Team())
		draw.DrawText(ply:getDarkRPVar("job") or teamname, "DarkRPHUD2", pos.x + 1, pos.y + 41, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply:getDarkRPVar("job") or teamname, "DarkRPHUD2", pos.x, pos.y + 40, Color(255, 255, 255, 200), 1)
	end

	if ply:getDarkRPVar("HasGunlicense") then
		surface.SetMaterial(licence)
		surface.SetDrawColor(255,255,255,255)
		surface.DrawTexturedRect(pos.x-16, pos.y + 60, 32, 32)
	end
end

local function DrawWantedInfo(ply)
	if not ply:Alive() then return end

	local pos = ply:EyePos()
	if not pos:isInSight({localplayer, ply}) then return end

	pos.z = pos.z + 14
	pos = pos:ToScreen()

	if GAMEMODE.Config.showname then
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x + 1, pos.y + 1, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x, pos.y, team.GetColor(ply:Team()), 1)
	end

	local wantedText = DarkRP.getPhrase("wanted", tostring(ply:getDarkRPVar("wantedReason")))

	draw.DrawText(wantedText, "DarkRPHUD2", pos.x, pos.y - 40, Color(255, 255, 255, 200), 1)
	draw.DrawText(wantedText, "DarkRPHUD2", pos.x + 1, pos.y - 41, Color(255, 0, 0, 255), 1)
end

/*---------------------------------------------------------------------------
The Entity display: draw HUD information about entities
---------------------------------------------------------------------------*/
local function DrawEntityDisplay()
	local shouldDraw = hook.Call("HUDShouldDraw", GAMEMODE, "DarkRP_EntityDisplay")
	if shouldDraw == false then return end

	local shootPos = localplayer:GetShootPos()
	local aimVec = localplayer:GetAimVector()

	for k, ply in pairs(player.GetAll()) do
		if not ply:Alive() then continue end
		local hisPos = ply:GetShootPos()
		if ply:getDarkRPVar("wanted") then DrawWantedInfo(ply) end

		if GAMEMODE.Config.globalshow and ply ~= localplayer then
			DrawPlayerInfo(ply)
		-- Draw when you're (almost) looking at him
		elseif not GAMEMODE.Config.globalshow and hisPos:Distance(shootPos) < 400 then
			local pos = hisPos - shootPos
			local unitPos = pos:GetNormalized()
			if unitPos:Dot(aimVec) > 0.95 then
				local trace = util.QuickTrace(shootPos, pos, localplayer)
				if trace.Hit and trace.Entity ~= ply then return end
				DrawPlayerInfo(ply)
			end
		end
	end

	local tr = localplayer:GetEyeTrace()

	if IsValid(tr.Entity) and tr.Entity:isKeysOwnable() and tr.Entity:GetPos():Distance(localplayer:GetPos()) < 200 then
		tr.Entity:drawOwnableInfo()
	end
end

/*---------------------------------------------------------------------------
Drawing death notices
---------------------------------------------------------------------------*/
function GM:DrawDeathNotice(x, y)
	if not GAMEMODE.Config.showdeaths then return end
	self.BaseClass:DrawDeathNotice(x, y)
end

/*---------------------------------------------------------------------------
Display notifications
---------------------------------------------------------------------------*/
local function DisplayNotify(msg)
	local txt = msg:ReadString()
	GAMEMODE:AddNotify(txt, msg:ReadShort(), msg:ReadLong())
	surface.PlaySound("buttons/lightswitch2.wav")

	-- Log to client console
	print(txt)
end
usermessage.Hook("_Notify", DisplayNotify)

/*---------------------------------------------------------------------------
Remove some elements from the HUD in favour of the DarkRP HUD
---------------------------------------------------------------------------*/
function GM:HUDShouldDraw(name)
	if name == "CHudHealth" or
		name == "CHudBattery" or
		name == "CHudSuitPower" or
		(HelpToggled and name == "CHudChat") then
			return false
	else
		return true
	end
end

/*---------------------------------------------------------------------------
Disable players' names popping up when looking at them
---------------------------------------------------------------------------*/
function GM:HUDDrawTargetID()
    return false
end

/*---------------------------------------------------------------------------
Actual HUDPaint hook
---------------------------------------------------------------------------*/
function GM:HUDPaint()
	DrawHUD()
	DrawEntityDisplay()

	self.BaseClass:HUDPaint()
end
