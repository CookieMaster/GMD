1. If you are using darkrp 2.5 use the files from the folder called hud2.5 else use hud2.4.3
	Install
1.Paste boowman folder in darkrp/content/materials also paste it in garrysmod/materials/
2.If you use hud2.4.3 then paste the hud.lua file in darkrp/gamemode/client/
3.If you use hud2.5 then paste the cl_hud.lua file in darkrp/gamemode/modules/hud/