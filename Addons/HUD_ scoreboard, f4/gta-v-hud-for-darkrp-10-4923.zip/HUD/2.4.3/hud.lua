/*---------------------------------------------------------------------------
HUD ConVars
---------------------------------------------------------------------------*/
local ConVars = {}
local HUDWidth
local HUDHeight

local Color = Color
local cvars = cvars
local draw = draw
local GetConVar = GetConVar
local Lerp = Lerp
local localplayer
local pairs = pairs
local SortedPairs = SortedPairs
local string = string
local surface = surface
local table = table
local tostring = tostring

CreateClientConVar("weaponhud", 0, true, false)

local function ReloadConVars()
	ConVars = {
		background = {0,0,0,100},
		Healthbackground = {0,0,0,200},
		Healthforeground = {140,0,0,180},
		HealthText = {255,255,255,200},
		Job1 = {0,0,150,200},
		Job2 = {0,0,0,255},
		salary1 = {0,150,0,200},
		salary2 = {0,0,0,255}
	}

	for name, Colour in pairs(ConVars) do
		ConVars[name] = {}
		for num, rgb in SortedPairs(Colour) do
			local CVar = GetConVar(name..num) or CreateClientConVar(name..num, rgb, true, false)
			table.insert(ConVars[name], CVar:GetInt())

			if not cvars.GetConVarCallbacks(name..num, false) then
				cvars.AddChangeCallback(name..num, function() timer.Simple(0,ReloadConVars) end)
			end
		end
		ConVars[name] = Color(unpack(ConVars[name]))
	end


	HUDWidth = (GetConVar("HudW") or  CreateClientConVar("HudW", 240, true, false)):GetInt()
	HUDHeight = (GetConVar("HudH") or CreateClientConVar("HudH", 115, true, false)):GetInt()

	if not cvars.GetConVarCallbacks("HudW", false) and not cvars.GetConVarCallbacks("HudH", false) then
		cvars.AddChangeCallback("HudW", function() timer.Simple(0,ReloadConVars) end)
		cvars.AddChangeCallback("HudH", function() timer.Simple(0,ReloadConVars) end)
	end
end
ReloadConVars()

local function formatNumber(n)
	if not n then return "" end
	if n >= 1e14 then return tostring(n) end
    n = tostring(n)
    local sep = sep or ","
    local dp = string.find(n, "%.") or #n+1
	for i=dp-4, 1, -3 do
		n = n:sub(1, i) .. sep .. n:sub(i+1)
    end
    return n
end


local Scrw, Scrh, RelativeX, RelativeY

/*---------------------------------------------------------------------------
GTA V HUD
---------------------------------------------------------------------------*/

surface.CreateFont( "MoneyFont", {
 font = "PriceDownBl-Regular",
 size = 65,
 weight = 750,
 blursize = 0,
 scanlines = 0,
 antialias = true,
 outline = true
} )


local HUD = {}

HUD.width = 250 // don't mess with these 
HUD.height = 175 
HUD.scrwidth = ScrW()
HUD.scrheight = ScrH()
HUD.mdata = ""
HUD.sdata = ""
HUD.jdata = ""

hook.Add("Think", "GetHUDVars", function() // workaround because of :getDarkRPVar returns nil at first
  HUD.mdata = LocalPlayer():getDarkRPVar("money")
  if not HUD.mdata then HUD.mdata = "" end
  
  HUD.sdata = LocalPlayer():getDarkRPVar("salary")
  if not HUD.sdata then HUD.sdata = "" end
  
  HUD.jdata = LocalPlayer():getDarkRPVar("job")
  if not HUD.jdata then HUD.jdata = "" end
  
  if (HUD.mdata ~= "" and HUD.sdata ~= "" and HUD.jdata ~= "") then
    hook.Remove("Think", "GetHUDVars")
  end
end)

hook.Add("HUDShouldDraw", "HideAmmo", function(name)
  if (name == "CHudSecondaryAmmo" or name == "CHudAmmo") then
    return false
  end
  
  return true
end)

hook.Add("DarkRPVarChanged", "UpdateHUDVars", function(ply, var, oldvar, newvalue)
  if ply == LocalPlayer() then
    if var == "money" then
      HUD.mdata = newvalue
    elseif var == "salary" then
      HUD.sdata = newvalue
    elseif var == "job" then
      HUD.jdata = newvalue
    end
  end
end)

local function RTS(font, text, XorY)
  surface.SetFont(font)
  local w, h = surface.GetTextSize(text)

  if XorY == true then
    return w
  else
    return h
  end
end

local function StartHUD()
  hook.Remove("HUDPaint", "DrawGTAHUD")

  local hud = vgui.Create("DPanel")
  hud:SetSize(HUD.width, HUD.height)
  hud:SetPos(25, HUD.scrheight - HUD.height - 10)
  hud:ParentToHUD()
  hud.Paint = function()
    surface.SetDrawColor(0, 0, 0, 245)
    surface.DrawRect(0, 0, HUD.width, HUD.height)
  end
  
  local health = vgui.Create("DPanel", hud)
  health:SetSize(119, 15)
  health:SetPos(5, HUD.height - 20)
  health.Paint = function()
    if LocalPlayer() ~= NULL and LocalPlayer():Health() ~= nil then
      local health = math.Clamp(LocalPlayer():Health(), 0, 100) * 1.19
      
      surface.SetDrawColor(80, 88, 63)
      surface.DrawRect(0, 0, 119, 15)
        
      surface.SetDrawColor(78, 119, 85)
      surface.DrawRect(0, 0, health, 15)
    end
  end
  
  local armor = vgui.Create("DPanel", hud)
  armor:SetSize(119, 15)
  armor:SetPos(126, HUD.height - 20)
  armor.Paint = function()
    if LocalPlayer() ~= NULL and LocalPlayer():Armor() ~= nil then
      local armor = math.Clamp(LocalPlayer():Armor(), 0, 100) * 1.19
      
      surface.SetDrawColor(21, 53, 66)
      surface.DrawRect(0, 0, 119, 15)
        
      surface.SetDrawColor(77, 146, 185)
      surface.DrawRect(0, 0, armor, 15)
    end
  end
  
  local overhead = vgui.Create("DPanel", hud)
  overhead:SetSize(240, 150)
  overhead:SetPos(5, 5)
  overhead.Paint = function()
    if LocalPlayer() ~= NULL and LocalPlayer():GetWeaponColor() ~= nil then
      local radius = 750
      local weaponcolor = LocalPlayer():GetWeaponColor()
        
      if !util.TraceLine(util.GetPlayerTrace(LocalPlayer(), Vector(0, 0, 90))).HitSky then
        radius = 100
      end

      local HeadCam = {} 
        
      if LocalPlayer() != nil then
        HeadCam.angles = Angle(90, LocalPlayer():EyeAngles().y, 0)
        HeadCam.origin = LocalPlayer():GetPos() + Vector(0, 0, radius)
      else
        HeadCam.angles = Angle(90, LocalPlayer():EyeAngles().y, 0)
        HeadCam.origin = LocalPlayer():GetPos() + Vector(0, 0, radius)
      end
            
      HeadCam.x = 30
      HeadCam.y = HUD.scrheight - HUD.height - 5
      HeadCam.w = 240
      HeadCam.h = 145
      
      local thingstohide = {}
        
      LocalPlayer():GetViewModel():SetNoDraw(true)
        
      LocalPlayer():SetWeaponColor(Vector(0, 0, 0))
      
      for k,v in pairs(ents.GetAll()) do
        if (v ~= LocalPlayer() and !v:IsVehicle() and !v:IsPlayer() and v:GetClass() ~= "prop_physics" and v ~= LocalPlayer():GetViewModel()) then
          table.insert(thingstohide, v)
          v:SetNoDraw(true)
        end
      end
        
        render.RenderView(HeadCam)
        
      for k,v in pairs(thingstohide) do
        v:SetNoDraw(false)
      end
          
      LocalPlayer():GetViewModel():SetNoDraw(false)
        
      LocalPlayer():SetWeaponColor(weaponcolor)
    end
  end
  
  local blip = vgui.Create("DImage", overhead)
  blip:SetSize(16, 16)
  blip:SetImage("materials/gtavhud/blip.png")
  blip:SetPos(115, 65)
  
  local money = vgui.Create("DLabel")
  money:SetPos(ScrW() - (RTS("MoneyFont", "$ " .. HUD.mdata, true) + 15), 0)
  money:SetFont("MoneyFont")
  money:SetTextColor(Color(121, 147, 122))
  money:SetText("$ " .. HUD.mdata)
  money:SizeToContents()
  money.PerformLayout = function()
    money:SetPos(ScrW() - (RTS("MoneyFont", "$ " .. HUD.mdata, true) + 15), 0)
    money:SetText("$ " .. HUD.mdata)
    money:SizeToContents()
  end
  money:ParentToHUD()
  
  local salary = vgui.Create("DLabel")
  salary:SetPos(ScrW() - (RTS("MoneyFont", "$ " .. HUD.sdata, true) + 15), 50)
  salary:SetFont("MoneyFont")
  salary:SetTextColor(Color(121, 147, 122))
  salary:SetText("$ " .. HUD.sdata)
  salary:SizeToContents()
  salary.PerformLayout = function()
    salary:SetPos(ScrW() - (RTS("MoneyFont", "$ " .. HUD.sdata, true) + 15), 50)
    salary:SetText("$ " .. HUD.sdata)
    salary:SizeToContents()
  end
  salary:ParentToHUD()
  
  local job = vgui.Create("DLabel")
  job:SetPos(ScrW() - (RTS("MoneyFont", HUD.jdata, true) + 15), 100)
  job:SetFont("MoneyFont")
  job:SetText(HUD.jdata)
  job:SizeToContents()
  job.PerformLayout = function()
    job:SetPos(ScrW() - (RTS("MoneyFont", HUD.jdata, true) + 15), 100)
    job:SetText("")
    job:SetText(HUD.jdata)
    job:SizeToContents()
  end
  job:ParentToHUD()
  
  local ammocount = vgui.Create("DLabel")
  ammocount:SetFont("MoneyFont")
  ammocount:SizeToContents()
  ammocount:SetText(LocalPlayer():GetActiveWeapon():Clip1() .. " / " .. LocalPlayer():GetAmmoCount(LocalPlayer():GetActiveWeapon():GetPrimaryAmmoType()))
  ammocount:SetPos(0, -200)
  ammocount.Think = function()
    if LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() then 
      local curmagazine = LocalPlayer():GetActiveWeapon():Clip1()
      local remmagazine = LocalPlayer():GetAmmoCount(LocalPlayer():GetActiveWeapon():GetPrimaryAmmoType())
        
      if LocalPlayer():GetActiveWeapon():Clip1() >= 0 then
        ammocount:SetPos(ScrW() - (RTS("MoneyFont", curmagazine .. " / " .. remmagazine, true) + 15), 150)
        ammocount:SetText(curmagazine .. " / " .. remmagazine)
        ammocount:SizeToContents()
      elseif LocalPlayer():GetActiveWeapon():Clip1() == -1 then
        ammocount:SetText("")
      end
    end
  end
  ammocount:ParentToHUD()
end

hook.Add("HUDPaint", "DrawGTAHUD", function()
  StartHUD()
end)

/*---------------------------------------------------------------------------
HUD Seperate Elements
---------------------------------------------------------------------------*/


local Page = Material("icon16/page_white_text.png")
local function GunLicense()
	if localplayer:getDarkRPVar("HasGunlicense") then
		surface.SetMaterial(Page)
		surface.SetDrawColor(255, 255, 255, 255)
		surface.DrawTexturedRect(RelativeX + HUDWidth, ScrH() - 34, 32, 32)
	end
end

local function Agenda()
	local DrawAgenda, AgendaManager = DarkRPAgendas[localplayer:Team()], localplayer:Team()
	if not DrawAgenda then
		for k,v in pairs(DarkRPAgendas) do
			if table.HasValue(v.Listeners or {}, localplayer:Team()) then
				DrawAgenda, AgendaManager = DarkRPAgendas[k], k
				break
			end
		end
	end
	if DrawAgenda then
		draw.RoundedBox(10, 10, 10, 460, 110, Color(0, 0, 0, 155))
		draw.RoundedBox(10, 12, 12, 456, 106, Color(51, 58, 51,100))
		draw.RoundedBox(10, 12, 12, 456, 20, Color(0, 0, 70, 100))

		draw.DrawText(DrawAgenda.Title, "DarkRPHUD1", 30, 12, Color(255,0,0,255),0)

		local AgendaText = {}
		for k,v in pairs(team.GetPlayers(AgendaManager)) do
			if not v.DarkRPVars then continue end
			table.insert(AgendaText, v:getDarkRPVar("agenda"))
		end

		local text = table.concat(AgendaText, "\n")
		text = text:gsub("//", "\n"):gsub("\\n", "\n")
		text = GAMEMODE:TextWrap(text, "DarkRPHUD1", 440)
		draw.DrawText(text, "DarkRPHUD1", 30, 35, Color(255,255,255,255),0)
	end
end

local VoiceChatTexture = surface.GetTextureID("voice/icntlk_pl")
local function DrawVoiceChat()
	if localplayer.DRPIsTalking then
		local chbxX, chboxY = chat.GetChatBoxPos()

		local Rotating = math.sin(CurTime()*3)
		local backwards = 0
		if Rotating < 0 then
			Rotating = 1-(1+Rotating)
			backwards = 180
		end
		surface.SetTexture(VoiceChatTexture)
		surface.SetDrawColor(ConVars.Healthforeground)
		surface.DrawTexturedRectRotated(ScrW() - 100, chboxY, Rotating*96, 96, backwards)
	end
end

local function LockDown()
	local chbxX, chboxY = chat.GetChatBoxPos()
	if util.tobool(GetConVarNumber("DarkRP_LockDown")) then
		local cin = (math.sin(CurTime()) + 1) / 2
		local chatBoxSize = math.floor(ScrH() / 4)
		draw.DrawText(DarkRP.getPhrase("lockdown_started"), "ScoreboardSubtitle", chbxX, chboxY + chatBoxSize, Color(cin * 255, 0, 255 - (cin * 255), 255), TEXT_ALIGN_LEFT)
	end
end

local Arrested = function() end

usermessage.Hook("GotArrested", function(msg)
	local StartArrested = CurTime()
	local ArrestedUntil = msg:ReadFloat()

	Arrested = function()
		if CurTime() - StartArrested <= ArrestedUntil and localplayer:getDarkRPVar("Arrested") then
		draw.DrawText(DarkRP.getPhrase("youre_arrested", math.ceil(ArrestedUntil - (CurTime() - StartArrested))), "DarkRPHUD1", ScrW()/2, ScrH() - ScrH()/12, Color(255,255,255,255), 1)
		elseif not localplayer:getDarkRPVar("Arrested") then
			Arrested = function() end
		end
	end
end)

local AdminTell = function() end

usermessage.Hook("AdminTell", function(msg)
	local Message = msg:ReadString()

	AdminTell = function()
		draw.RoundedBox(4, 10, 10, ScrW() - 20, 100, Color(0, 0, 0, 200))
		draw.DrawText(DarkRP.getPhrase("listen_up"), "GModToolName", ScrW() / 2 + 10, 10, Color(255, 255, 255, 255), 1)
		draw.DrawText(Message, "ChatFont", ScrW() / 2 + 10, 80, Color(200, 30, 30, 255), 1)
	end

	timer.Simple(10, function()
		AdminTell = function() end
	end)
end)

/*---------------------------------------------------------------------------
Drawing the HUD elements such as Health etc.
---------------------------------------------------------------------------*/
local function DrawHUD()
	GunLicense()
	Agenda()
	DrawVoiceChat()
	LockDown()

	Arrested()
	AdminTell()
end

/*---------------------------------------------------------------------------
Entity HUDPaint things
---------------------------------------------------------------------------*/
local function DrawPlayerInfo(ply)
	local pos = ply:EyePos()

	pos.z = pos.z + 10 -- The position we want is a bit above the position of the eyes
	pos = pos:ToScreen()
	pos.y = pos.y - 50 -- Move the text up a few pixels to compensate for the height of the text

	if GAMEMODE.Config.showname and not ply:getDarkRPVar("wanted") then
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x + 1, pos.y + 1, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x, pos.y, team.GetColor(ply:Team()), 1)
		draw.DrawText(DarkRP.getPhrase("health", ply:Health()), "DarkRPHUD2", pos.x + 1, pos.y + 21, Color(0, 0, 0, 255), 1)
		draw.DrawText(DarkRP.getPhrase("health", ply:Health()), "DarkRPHUD2", pos.x, pos.y + 20, Color(255,255,255,200), 1)
	end

	if GAMEMODE.Config.showjob then
		local teamname = team.GetName(ply:Team())
		draw.DrawText(ply:getDarkRPVar("job") or teamname, "DarkRPHUD2", pos.x + 1, pos.y + 41, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply:getDarkRPVar("job") or teamname, "DarkRPHUD2", pos.x, pos.y + 40, Color(255, 255, 255, 200), 1)
	end

	if ply:getDarkRPVar("HasGunlicense") then
		surface.SetMaterial(Page)
		surface.SetDrawColor(255,255,255,255)
		surface.DrawTexturedRect(pos.x-16, pos.y + 60, 32, 32)
	end
end

local function DrawWantedInfo(ply)
	if not ply:Alive() then return end

	local pos = ply:EyePos()
	if not pos:RPIsInSight({localplayer, ply}) then return end

	pos.z = pos.z + 14
	pos = pos:ToScreen()

	if GAMEMODE.Config.showname then
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x + 1, pos.y + 1, Color(0, 0, 0, 255), 1)
		draw.DrawText(ply:Nick(), "DarkRPHUD2", pos.x, pos.y, team.GetColor(ply:Team()), 1)
	end

	local wantedText = DarkRP.getPhrase("wanted", tostring(ply:getDarkRPVar("wantedReason")))

	draw.DrawText(wantedText, "DarkRPHUD2", pos.x, pos.y - 40, Color(255, 255, 255, 200), 1)
	draw.DrawText(wantedText, "DarkRPHUD2", pos.x + 1, pos.y - 41, Color(255, 0, 0, 255), 1)
end

/*---------------------------------------------------------------------------
The Entity display: draw HUD information about entities
---------------------------------------------------------------------------*/
local function DrawEntityDisplay()
	local shouldDraw = hook.Call("HUDShouldDraw", GAMEMODE, "DarkRP_EntityDisplay")
	if shouldDraw == false then return end

	local shootPos = LocalPlayer():GetShootPos()
	local aimVec = LocalPlayer():GetAimVector()

	for k, ply in pairs(player.GetAll()) do
		if not ply:Alive() then continue end
		local hisPos = ply:GetShootPos()
		if ply:getDarkRPVar("wanted") then DrawWantedInfo(ply) end

		if GAMEMODE.Config.globalshow and ply ~= LocalPlayer() then
			DrawPlayerInfo(ply)
		-- Draw when you're (almost) looking at him
		elseif not GAMEMODE.Config.globalshow and hisPos:Distance(shootPos) < 400 then
			local pos = hisPos - shootPos
			local unitPos = pos:GetNormalized()
			if unitPos:Dot(aimVec) > 0.95 then
				local trace = util.QuickTrace(shootPos, pos, LocalPlayer())
				if trace.Hit and trace.Entity ~= ply then return end
				DrawPlayerInfo(ply)
			end
		end
	end

	local tr = LocalPlayer():GetEyeTrace()

	if IsValid(tr.Entity) and tr.Entity:IsOwnable() and tr.Entity:GetPos():Distance(LocalPlayer():GetPos()) < 200 then
		tr.Entity:DrawOwnableInfo()
	end
end

/*---------------------------------------------------------------------------
Actual HUDPaint hook
---------------------------------------------------------------------------*/
function GM:HUDPaint()
	DrawEntityDisplay()

	self.BaseClass:HUDPaint()
end
