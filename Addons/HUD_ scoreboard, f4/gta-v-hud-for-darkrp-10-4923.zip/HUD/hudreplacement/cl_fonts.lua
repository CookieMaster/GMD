surface.CreateFont( "MoneyFont", {
 font = "PriceDownBl-Regular",
 size = 65,
 weight = 750,
 blursize = 0,
 scanlines = 0,
 antialias = true,
 outline = true
} )
