if SERVER then
	AddCSLuaFile("autorun/scorpy_chatbox.lua")
	AddCSLuaFile("scorpy_chatbox/ssc_config.lua")
	AddCSLuaFile("scorpy_chatbox/sh_init.lua")
	AddCSLuaFile("scorpy_chatbox/skin.lua")
	AddCSLuaFile("scorpy_chatbox/vgui/rich_label.lua")
	AddCSLuaFile("scorpy_chatbox/vgui/scorpy_chatbox_panels.lua")

	gameevent.Listen( "player_connect" )
	hook.Add( "player_connect", "SSC_PrintConnect", function( data )
		for k,v in pairs( player.GetAll() ) do
			v:PrintMessage( HUD_PRINTTALK, data.name .. " has connected to the server." )
		end
	end )
	
	gameevent.Listen( "player_disconnect" )
	hook.Add( "player_disconnect", "SSC_PrintLeave", function( data )
		for k,v in pairs( player.GetAll() ) do
			v:PrintMessage( HUD_PRINTTALK, data.name .. " has left the server." )
		end
	end )
	
	hook.Add("PlayerSay", "SSC - PM", function(ply, msg)
		local name, text = string.match(msg, "^@(%S+)%s+(.+)$")
		if name and text then
			if ply:IsAdmin() then
				local target = SSC.GetPlayerByName(name) -- This is deprecated, and my own function... Will fix in future release!
				if target and target != ply then
					local rp = RecipientFilter()
					rp:AddPlayer(ply)
					rp:AddPlayer(target)
					
					umsg.Start("SSC - PM", rp)
						umsg.Entity(ply)
						umsg.Entity(target)
						umsg.String(text)
					umsg.End()
					
					return ""
				end
			else
				ply:PrintMessage(HUD_PRINTTALK, "You're not an admin therefore do not have authorization to use PMs!")
				return ""
			end
		end
	end)
	
	local meta = FindMetaTable("Player")
	util.AddNetworkString("PrintDatMessage")

	function meta:ChatPrint( Text )
		--MsgN( Text ) -- Send Standard Message
		if Text then
			net.Start("PrintDatMessage")
				net.WriteString(Text)
			net.Send(self)
		end
	end
	
	meta.oPrintMessage = meta.PrintMessage
	function meta:PrintMessage( Type, Text )
		if Type == HUD_PRINTTALK then 
			net.Start("PrintDatMessage")
			net.WriteString(Text)
			net.Send(self)
		else 
			self:oPrintMessage(Type, Text)
		end 
	end

	function meta:ScreenText( Text )
		--MsgN( Text ) -- Send Standard Message
		if Text then
			net.Start("PrintDatMessage")
				net.WriteString(Text)
			net.Send(self)
		end
	end

	
	return
end

--Start Clientside

include("scorpy_chatbox/ssc_config.lua")
include("scorpy_chatbox/skin.lua")
include("scorpy_chatbox/vgui/rich_label.lua")
include("scorpy_chatbox/vgui/scorpy_chatbox_panels.lua")

local Chatbox

SSC = SSC or {};

local meta = FindMetaTable( "Player" ) function meta:ChatPrint( str) return self:PrintMessage( HUD_PRINTTALK, str ) end

SSC.Chatbox = Chatbox

surface.CreateFont( "DefaultBold", { -- Fix for DefaultBold missing font. 
        font = "Tahoma",
        size = 16,
        weight = 1000,
        antialias = true,
        additive = false
} )

hook.Add("InitPostEntity", "Scorpy's Simple Chatbox - Init", function() 
	Chatbox = vgui.Create("ScorpyChatbox")
end)

local oldChatAddText = chat.AddText
function chat.AddText(...)
	oldChatAddText(...)
	
	Chatbox = Chatbox or vgui.Create("ScorpyChatbox")
	Chatbox:AddMessage({...})
end

net.Receive("PrintDatMessage", function( len )
	local stuff = net.ReadString()
	chat.AddText( stuff )
end)

-- local oldHookCall = hook.Call
-- function hook.Call(name, gm, ...)
	-- local ret = oldHookCall(name, gm, ...)
	
	-- if name == "ChatText" and not ret then
		-- local arg = {...}
		-- local text, message_type = arg[3], arg[4]
		-- if message_type == "chat" then return end
		-- local icon
		-- local tab = {}
		
		-- if message_type == "joinleave" then
			-- icon = "icon16/world.png"
			-- table.insert(tab, Color(0, 255, 120))
		-- end
		
		-- table.insert(tab, text)
		
		-- Chatbox = Chatbox or vgui.Create("ScorpyChatbox")
		-- Chatbox:AddMessage(tab, icon)
	-- end
	
	-- return ret
-- end

hook.Add("HUDShouldDraw", "Scorpy's Simple Chatbox - Hide Default", function(name)
	if name=="CHudChat" then
		return false
	end
end)

hook.Add("PlayerBindPress", "Scorpy's Simple Chatbox - Open", function(ply, bind, pressed)
	if string.find(bind, "messagemode2") then
		Chatbox:Open(true)
		return true
	elseif string.find(bind, "messagemode") then
		Chatbox:Open(false)
		return true
	end
end)

usermessage.Hook("SSC - PM", function(um)
	local ply = um:ReadEntity()
	local target = um:ReadEntity()
	local text = um:ReadString()
	local tab = {}
	
	table.insert( tab, Color( 0, 200, 200 ) )
	table.insert( tab, "(PRIVATE" )
	if target != LocalPlayer() then
		table.insert( tab, " to "..target:Name() )
	end
	table.insert( tab, ") " )
	
	table.insert( tab, ply )
	
	table.insert( tab, Color( 255, 255, 255 ) )
	table.insert( tab, ": "..text )
	
	chat.AddText( unpack(tab) )
end)