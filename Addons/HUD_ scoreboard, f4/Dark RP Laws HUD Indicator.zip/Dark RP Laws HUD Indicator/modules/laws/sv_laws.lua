-- These are the default laws, they're unchangeable in-game.
local Laws = {
	"Do not attack other citizens except in self-defence.",
	"Do not steal or break in to peoples homes.",
	"Money printers/drugs are illegal.",
}

local FixedLaws = table.Copy( Laws )

local function AddLaw( ply, args )

	if ply:Team() ~= TEAM_MAYOR then
		
		GAMEMODE:Notify( ply, 1, 4, "You must be the mayor to set laws!")
		return ""
	end

	if string.len( args ) < 3 then

		GAMEMODE:Notify( ply, 1, 4, "Law too short.")
		return ""
	end

	table.insert( Laws, args )

	umsg.Start("DRP_AddLaw")

		umsg.String( args )

	umsg.End()

	return ""
end
AddChatCommand("/addlaw", AddLaw )

local function RemoveLaw( ply, args )

	if ply:Team() ~= TEAM_MAYOR then

		GAMEMODE:Notify( ply, 1, 4, "You must be the mayor to remove laws!")
		return ""
	end

	if not tonumber( args ) then
	
		GAMEMODE:Notify( ply, 1, 4, "Invalid arguments.")
		return ""
	end

	if not Laws[ tonumber( args ) ] then
		
		GAMEMODE:Notify( ply, 1, 4, "Invalid law.")
		return ""
	end

	table.remove( Laws, tonumber( args ) )

	umsg.Start("DRP_RemoveLaw")

		umsg.Char( tonumber( args ) )

	umsg.End()

	return ""
end
AddChatCommand("/removelaw", RemoveLaw )

function LawsPanel( ply )
ply:ConCommand("LawMenu")
end
AddChatCommand("/laws", LawsPanel)

hook.Add("PlayerInitialSpawn", "SendLaws", function( ply )

	for i, law in pairs( Laws ) do

		if FixedLaws[ i ] then continue end

		umsg.Start("DRP_AddLaw", ply )

			umsg.String( law )

		umsg.End()

	end

end )

hook.Add("PlayerDeath","DemoteMayor",function(ply)
if (ply:Team() == TEAM_MAYOR) then
ply:ChangeTeam(TEAM_CITIZEN,true);
for k, v in ipairs(player.GetAll()) do
v:PrintMessage(HUD_PRINTCENTER,"The current Mayor of the city has been Assassinated!");
		umsg.Start("DRP_ResetLaws", v )
		umsg.String()
		umsg.End()
end;
end;
end);