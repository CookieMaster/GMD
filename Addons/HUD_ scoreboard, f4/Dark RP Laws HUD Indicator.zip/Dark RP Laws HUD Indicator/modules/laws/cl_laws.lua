
-- These are the default laws
local Laws = {
	"Do not attack other citizens except in self-defence.",
	"Do not steal or break in to peoples homes.",
	"Money printers/drugs are illegal.",
}

function DrawLaws()
	
	local X = ScrW()-420
	local Y = 50
	local W = 420
	local H = 200

	surface.SetDrawColor( 0, 0, 0, 100 )
	surface.DrawRect( X, Y, W, 35+(#Laws*14) )
	surface.SetDrawColor( Color( 255, 255, 255, 200 ) )
	surface.DrawOutlinedRect( X, Y, W, 35+(#Laws*14) )
	
	surface.SetDrawColor( Color( 255, 255, 255, 200 ) )
	surface.DrawOutlinedRect(X, Y, W, 22)

	draw.DrawText("Police Laws", "UiBold", X+W/11, Y+4, Color( 0, 255, 0, 200 ), TEXT_ALIGN_CENTER )
	
	local y = 85
	for i, law in pairs( Laws ) do
	
		draw.DrawText( i .. ": " .. law, "UiBold", X+5, y-10, Color( 255, 255, 255, 200 ) )
		
		y = y + 15
		
	end

end
hook.Add("HUDPaint", "DrawLaws", DrawLaws)


local function AddLaw( um )

	print("Added to the laws.")
	table.insert( Laws, um:ReadString() )

end
usermessage.Hook("DRP_AddLaw", AddLaw )

local function MayorDeathRemoveLaws( um )
print("Mayors laws removed, default ones added")

for i=1,#Laws do
table.remove(Laws)
end

table.insert(Laws, "Do not attack other citizens except in self-defence.")
table.insert(Laws, "Do not steal or break in to peoples homes.")
table.insert(Laws, "Money printers/drugs are illegal.")
table.insert(Laws, "You may keep a handgun for Self Defence.")
table.insert(Laws, "No advertising on Other peoples Homes.")
end
usermessage.Hook("DRP_ResetLaws", MayorDeathRemoveLaws)

local function RemoveLaw( um )

	table.remove( Laws, um:ReadChar() )
	
end
usermessage.Hook("DRP_RemoveLaw", RemoveLaw )

function LawsPanel()

if LocalPlayer():Team() != TEAM_MAYOR then
return print("You are not the Mayor!")

end

       if frame and frame:IsValid() then return end
        local h = 160 + (#Laws * 40) + ((#Laws - 1) * 5)
        local frame = vgui.Create("DFrame")
        frame:SetSize(500, h)
        frame:Center()
        frame:SetTitle("")
        frame:MakePopup()
        frame:ShowCloseButton(false)
        frame:SetDraggable(false)
        frame:SetSkin("DevulDefault")
        
        local closebtn = frame:Add("DImageButton")
        closebtn:SetPos(frame:GetWide() - 20, 5)
        closebtn:SetImage("icon16/cancel.png")
        closebtn:SizeToContents()
        closebtn.DoClick = function()
                frame:Close()
        end
        
        local title = frame:Add("DLabel")
        title:SetPos(20, 10)
        title:SetFont("HUDNumber")
        title:SetText("Edit Laws")
        title:SizeToContents()
        
        local scroll = frame:Add("DScrollPanel")
        scroll:SetPos(20, 80)
        scroll:SetSize(frame:GetWide() - 40, frame:GetTall() - 150)
        
        local lay = scroll:Add("DIconLayout")
        lay:SetSize(scroll:GetWide(), scroll:GetTall())
        lay:SetSpaceY(5)
        
        local function lawsList()
                if lay and lay:IsValid() then lay:Remove() end
                
                local lay = scroll:Add("DIconLayout")
                lay:SetSize(scroll:GetWide(), scroll:GetTall())
                lay:SetSpaceY(5)
                
                Laws = Laws or {}
                for i = 1, #Laws do
                        local law = Laws[i]
                        local pnl = lay:Add("DPanel")
                        pnl:SetSize(lay:GetWide(), 40)
						pnl.Paint = function()
							surface.SetDrawColor( 0, 100, 255, 255 )
							surface.DrawRect( 0, 0, pnl:GetWide(), pnl:GetTall() )
						end
                                
                        local txt = pnl:Add("DLabel")
                        txt:SetFont("TargetIDSmall")
                        txt:SetTextColor(Color(180, 180, 180, 255))
                        txt:SetText(law)
                        txt:SizeToContents()
                        txt:SetPos(10, (pnl:GetTall() - txt:GetTall()) /2)
                                
                        local x = pnl:GetWide() - 20
                        if i > 3 then
                                local remove = pnl:Add("DImageButton")          
                                remove:SetImage("icon16/delete.png")
                                remove:SizeToContents()
                                x = x - remove:GetWide()
                                remove:SetPos(x, (pnl:GetTall() - remove:GetTall()) /2)
                                remove.DoClick = function()
                                        RunConsoleCommand("darkrp", "/removelaw", i)
                                        frame:Close()
                                end
                        end
                                
                        end             
                end
        lawsList()
        
        local pnl = frame:Add("DPanel")
        pnl:SetSize(140, 40)
        pnl:SetPos(20, frame:GetTall() - 20 - 40)
		pnl.Paint = function()
		surface.SetDrawColor( 0, 100, 255, 255 )
		surface.DrawRect( 0, 0, pnl:GetWide(), pnl:GetTall() )
						end
        
        local a = 10
        local add = pnl:Add("DImageButton")
        add:SetImage("icon16/add.png")
        add:SizeToContents()
        add:SetPos(a, (pnl:GetTall() - add:GetTall()) /2)
        add.DoClick = function()
                Derma_StringRequest("Add Law", "", "", function(txt)
                        RunConsoleCommand("darkrp", "/addlaw", txt)
                        h = 160 + (#Laws * 40) + ((#Laws - 1) * 5)
                        timer.Simple(0.5, function() lawsList() end)
                end)
        end
        
        a = a + add:GetWide() + 5
        local lbl = pnl:Add("DLabel")
        lbl:SetFont("TargetIDSmall")
        lbl:SetText("Add Law")
        lbl:SizeToContents()
        lbl:SetPos(a, (pnl:GetTall() - lbl:GetTall()) /2)
        lbl.DoClick = function()
                Derma_StringRequest("Add Law", "", "", function(txt)
                        RunConsoleCommand("darkrp", "/addlaw", txt)
                        h = 160 + (#Laws * 40) + ((#Laws - 1) * 5)
                        timer.Simple(0.5, function() lawsList() end)
                end)
        end
		
end
concommand.Add("LawMenu", LawsPanel)