local SKIN = {}

SKIN.PrintName          = "Devul's Derma Skin"
SKIN.Author             = "Devul"
SKIN.DermaVersion       = 1

SKIN.colOutline = Color( 0, 0, 0, 20 )

SKIN.bg_color                                   = Color( 55, 55, 55, 255 )

/*
SKIN.tex = {}
SKIN.tex.Button						= Color( 158, 158, 158, 255 )
SKIN.tex.Button_Hovered				= Color( 194, 194, 194, 255 )
SKIN.tex.Button_Dead				= Color( 120, 120, 120, 255 )
SKIN.colButtonText				= Color( 255, 255, 255, 255 )
SKIN.colButtonTextDisabled		= Color( 255, 255, 255, 55 )
SKIN.colButtonTextHovered		= Color( 255, 255, 255, 255 )
*/

function SKIN:DrawSquaredBox( x, y, w, h, color )

    surface.SetDrawColor( color )
    surface.DrawRect( x, y, w, h )
        
    surface.SetDrawColor( self.colOutline )
    surface.DrawOutlinedRect( x, y, w, h )
end

function SKIN:PaintFrame( panel, w, h )

    self:DrawSquaredBox( 0, 0, panel:GetWide(), panel:GetTall(), self.bg_color )
end

function SKIN:PaintButton( button, w, h )
    local x, y = 0,0
        
    if button.m_bBackground then
        local color = Color( 158, 158, 158, 255 )                
        if button:GetDisabled() then
            color = Color(color.r + 40, color.g + 40, color.b + 40, color.a + 40)     
        elseif button.Depressed or button:IsSelected() then
            x, y = w*0.15, h*0.15
            w = w *0.7
            h = h * 0.7
        elseif button.Hovered then
			color = Color(color.r + 40, color.g + 40, color.b + 40, color.a + 40)                  
        end
        self:DrawSquaredBox(x, y, w, h, color) 
		button:SetFont("UiBold")
		button:SetTextColor(Color(255, 255, 255, 255))
    end
end

derma.DefineSkin( "DevulDefault", "Devul's Skin", SKIN )