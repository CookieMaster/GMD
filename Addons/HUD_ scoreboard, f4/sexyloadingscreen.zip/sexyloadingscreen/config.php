<?php 

/*
Sexy Loading Screen v1.0
by Rocky Breslow (c1yd3i)
http://c1yd3i.com/

Configuration

*/

$cfg_pagetitle = "TTT for Sexy and Intelligent People"; //HTML Page Title

$cfg_background = "images/bgi.jpg"; //URL to Background Image -- Recommended Image Size: 1920x1080

$cfg_logo = "images/logo.png"; //Server Logo -- PSD Included

$cfg_servername = "TTT for Sexy and Intelligent People"; //Server Name -- Recommended to not include tags such as "[FastDL]" for astetic reasons.