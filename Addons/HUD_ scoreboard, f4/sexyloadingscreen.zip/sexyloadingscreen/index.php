<?php

/*
Sexy Loading Screen v1.0
by Rocky Breslow (c1yd3i)
http://c1yd3i.com/

DO NOT MODIFY THIS DOCUMENT

*/


ini_set('display_errors',0); 
error_reporting(E_ALL);
require_once("lib/steam-condenser.php");
$communityid = $_GET["steamid"];
$mapname = $_GET["mapname"];
$steamUser = new SteamId($communityid);
$avatarurl = $steamUser->getFullAvatarUrl();
$nickname = $steamUser->getNickname();
include("config.php");	

/*SteamID getting from _get data*/
//Get the steamid (really the community id)
$communityid = $_GET["steamid"];
//See if the second number in the steamid (the auth server) is 0 or 1. Odd is 1, even is 0
$authserver = bcsub($communityid, '76561197960265728') & 1;
//Get the third number of the steamid
$authid = (bcsub($communityid, '76561197960265728')-$authserver)/2;
//Concatenate the STEAM_ prefix and the first number, which is always 0, as well as colons with the other two numbers
$steamid = "STEAM_0:$authserver:$authid";
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title><?php echo $cfg_pagetitle; ?></title>
			<style type="text/css">
			@font-face {
			    font-family: 'BebasNeueRegular';
			    src: url('BebasNeue-webfont.eot');
			    src: url('BebasNeue-webfont.eot?#iefix') format('embedded-opentype'),
			         url('BebasNeue-webfont.woff') format('woff'),
			         url('BebasNeue-webfont.ttf') format('truetype'),
			         url('BebasNeue-webfont.svg#BebasNeueRegular') format('svg');
			    font-weight: normal;
			    font-style: normal;
			}
			body
			{
				background-image: url("<?php echo $cfg_background; ?>");
				width: 100%;
				height: 100%;
				padding: 0;
				margin: 0;
				background-size: cover;
				background-clip: border-box;
				background-attachment: fixed;
				text-align: center;
			}
			h1
			{
				font-family: 'BebasNeueRegular', 'Impact', 'Arial', 'Helvetica', 'sans-serif';
				font-size: 24pt;
				color: white;
				text-align: left;
				margin: 0;
				padding: 0;
				/*margin-left: 114px;*/
				font-weight: normal;
				float: left;
				margin-top: 15px;
				margin-left: 17px;
			}
			#header
			{
				margin: 0;
				width: 100%;
				text-align: left;
				height: 65px;
				background-color: rgba(32,32,32,.75)
				padding-bottom: 100px;
			}
			#footer
			{
				height: 118px;
				width: 100%;
				text-align: left;
				background-color: rgba(32,32,32,.75);
				position: absolute;
				bottom: 0;
			}
			#logo
			{
				width: 31px;
				height: 31px;
				margin: 0;
				padding: 0;
				background-image: url("<?php echo $cfg_logo; ?>");
				background-repeat: no-repeat;
				opacity: .5;
				float: left;
				margin-top: 17px;
				margin-left: 17px;
			}
			#footer h2
			{
				font-family: 'BebasNeueRegular', 'Impact', 'Arial', 'Helvetica', 'sans-serif';
				font-size: 32pt;
				color: #ef962c;
				text-align: left;
				margin: 0;
				padding: 0;
				/*margin-left: 114px;*/
				font-weight: normal;
				margin-top: 15px;
				margin-left: 17px;
			}
			#footer h3
			{
				font-family: 'BebasNeueRegular', 'Impact', 'Arial', 'Helvetica', 'sans-serif';
				font-size: 20pt;
				color: white;
				text-align: left;
				margin: 0;
				padding: 0;
				font-weight: normal;
				margin-left: 17px;
			}
			#footerimg
			{
				width:100px; 
				float:left; 
				margin-left:17px; 
				margin-right:17px; 
				margin-top:9px; 
				display:inline-block; 
				vertical-align:middle;
			}
		</style>
	</head>
	<body>
		<div id="header">
			<div id="logo"></div>
			<h1><?php echo $cfg_servername; ?></h1>
		</div>
		<div id="footer">
		    <img id="footerimg" src="<?php echo $avatarurl; ?>" alt="">
			<h2>Greetings <?php echo $nickname; ?>!</h2>
			<h3>You are on your way to: <?php echo $mapname; ?>.</h3>
		</div>
	</body>
</html>