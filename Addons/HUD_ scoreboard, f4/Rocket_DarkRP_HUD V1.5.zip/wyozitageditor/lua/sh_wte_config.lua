
-- Use ULX rank as the default tag if no custom tag was found
wyozite.MakeRanksDefaultTags = true

-- Dont show any tag for normal users. Helps people pick out people with power from the scoreboard
wyozite.DontShowUserRank = true

-- Disables right clicking scoreboard menu. This makes ulx commands the only way to set tags.
wyozite.DontUseContextMenu = false

-- If ranks are used as tags, we can set custom rank colors here

wyozite.RankColors = {
	superadmin = Color(108, 108, 252),
	admin = Color(252, 104, 104),
	operator = Color(180, 104, 252)
}