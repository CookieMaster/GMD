How to Install

Download the latest DarkRP as a ZIP from
https://github.com/FPtje/DarkRP
Open the DarkRP-Master.zip and extract the gamemode to your gamemodes folder.
Download the Latest HUD ZIP and open it.
Put the hud.lua file into gamemodes/darkrp/gamemode/client/ and overwrite.
(IF YOU'RE ON AN OLDER DARKRP PLEASE USE THE hud.lua FILE FROM THE "FOR THE OLDER DARKRP" FOLDER!)
Place the sv_huddownload.lua in your gamemodes/darkrp/gamemode/modules/
Place the folder named "darkrphud" into your materials folder garrysmod/materials. (This would be located in for Steam/SteamApps/GarrysMod/garrysmod/materials. If there is no materials folder, create one and add it in there. This would apply in srcds, it would be in orangebox/garrysmod/materials and if that doesn't exist create a materials folder.)
Enjoy! (There is also installation instructions in the ZIP file aswell)