/* ==============================================

RDM REPORT SYSTEM
by Remscar

Hooks:
RDM_Report {attacker, victim}

=================================================*/


if !RRS then
	RRS = {}
end

RRS.Reports = {}
/* Entry Structure:
Attacker - ply
Victim - ply
Attacker_Report = string
Victim_Report = string
Evaluated = bool
Ready = bool
*/

RRS.Reporting = false
RRS.ReportWindow = nil

RRS.ReportListWindow = nil

function RRS.Report()
	local attacker = tobool(net.ReadBit())
	local id = net.ReadFloat()
	local otherparty = net.ReadEntity()
	RRS.ShowReportWindow(attacker,otherparty,id)
	RRS.Reporting = true
	timer.Create("timeout",45,1,function() if !RRS.Reporting then return end RRS.SendReport(attacker,otherparty,id,"TIME LIMIT") end)
end
net.Receive("RRS_Report_Request",RRS.Report)




function RRS.ShowReportWindow(is_atk,other,id)

	local pnl = vgui.Create("DFrame")
	pnl:SetSize(440,260)
	pnl:Center()
	pnl:MakePopup()
	pnl:ShowCloseButton(false)
	pnl:SetTitle("RDM REPORTER")

	local lbl = vgui.Create("DLabel", pnl)
	if is_atk then
		lbl:SetText("You seemed to have RDMed "..other:Nick())
	else
		lbl:SetText("You seemed to have been RDMed by "..other:Nick())
	end
	lbl:SizeToContents()
	lbl:SetPos(4,24)

	local lbl2 = vgui.Create("DLabel", pnl)
	lbl2:SetText("Please explain what happened below. You have 45 seconds.")
	lbl2:SizeToContents()
	lbl2:SetPos(4,38)

	local tentry = vgui.Create("DTextEntry" , pnl)
	tentry:SetSize(432,180)
	tentry:SetPos(4,54)
	tentry:SetMultiline(true)
	tentry:SetText("Put only the truth or you will be banned.")

	local btn = vgui.Create("DButton", pnl)
	btn:SetSize(432,20)
	btn:SetPos(4,236)
	btn:SetText("Submit")
	btn.DoClick = function()
		RRS.SendReport(is_atk,other,id,tentry:GetValue())
	end

	RRS.ReportWindow = pnl
end

concommand.Add("frw",function() RRS.ShowReportWindow(LocalPlayer(),LocalPlayer(),1) end)

function RRS.SendReport(is_atk,other,id,txt)
	RRS.Reporting = false
	RRS.ReportWindow:Remove()
	timer.Stop("timeout")

	net.Start("RRS_Report_Receive")
	net.WriteBit(is_atk)
	net.WriteFloat(id)
	net.WriteString(txt)
	net.SendToServer()
end

surface.CreateFont( "RRS_TOP", {
 font = "Tahoma",
 size = 21,
 weight = 1200,
 antialias = true,
} )

surface.CreateFont( "RRS_MED", {
 font = "Arial",
 size = 16,
 weight = 600,
 antialias = true,
} )

function RRS.ShowReportList()

	local pnl = vgui.Create("DFrame")
	pnl:SetSize(800,800)
	pnl:Center()
	pnl:SetDraggable(false)
	pnl:SetTitle("RDM Report List")
	pnl:MakePopup()

	local r_btn = vgui.Create("DButton",pnl)
	r_btn:SetSize(400,20)
	r_btn:SetPos(200,2)
	r_btn:SetText("Refresh")
	r_btn.DoClick = function()
		RunConsoleCommand("RRS_Report_List")
	end

	local scr = vgui.Create("DScrollPanel",pnl)
	scr:SetSize(794,766)
	scr:SetPos(3,30)

	pnl.List = vgui.Create("DIconLayout",scr)
	pnl.List:SetSize(774,766)
	pnl.List:SetPos(2,0)
	pnl.List:SetSpaceY(6)

	pnl.UpdateList = function()
		pnl.List:Clear()
		for k,v in pairs(RRS.Reports) do
			if v.Ready == true then
				local rpt = pnl.List:Add("DPanel")
				rpt:SetSize(778,170)

				local bp = vgui.Create("Panel",rpt)
				bp:SetSize(778,28)
				bp:SetPos(0,0)
				bp.Color = Color(250,20,20,220)
				bp.Paint = function()
					draw.RoundedBox(0,0,0,bp:GetWide(),bp:GetTall(),bp.Color)
				end

				if v.Evaluated then
					bp.Color = Color(20,250,20,220)
				end

				local lbl = vgui.Create("DLabel",rpt)
				lbl:SetText("RDM REPORT: "..v.Attacker_Name.." killed "..v.Victim_Name)
				lbl:SetFont("RRS_TOP")
				lbl:SizeToContents()
				lbl:SetColor(Color(0,0,0,255))
				lbl:SetPos(4,4)

				if !v.Evaluated then

					local eval = vgui.Create("DButton",rpt)
					eval:SetText("Evaluated")
					eval:SetPos(778-108,4)
					eval:SetSize(100,20)
					eval.DoClick = function()
						RunConsoleCommand("RRS_Report_Eval",k)
						RunConsoleCommand("RRS_Report_List")
					end

				end

				local albl = vgui.Create("DLabel",rpt)
				albl:SetPos(3,30)
				albl:SetText("ATTACKER: "..v.Attacker_Name.."'s story")
				albl:SetFont("RRS_MED")
				albl:SizeToContents()
				albl:SetColor(Color(100,0,0,255))

				local a_t = vgui.Create("DTextEntry",rpt)
				a_t:SetPos(3,46)
				a_t:SetSize(768/2,120)
				a_t:SetMultiline(true)
				a_t:SetText(v.Attacker_Report)
				--a_t:SetEditable(false)

				local vlbl = vgui.Create("DLabel",rpt)
				vlbl:SetPos(770/2 + 8,30)
				vlbl:SetText("VICTIM: "..v.Victim_Name.."'s story")
				vlbl:SetFont("RRS_MED")
				vlbl:SizeToContents()
				vlbl:SetColor(Color(0,100,0,255))

				local v_t = vgui.Create("DTextEntry",rpt)
				v_t:SetPos(5 + 770/2,46)
				v_t:SetSize(768/2 - 4,120)
				v_t:SetMultiline(true)
				v_t:SetText(v.Victim_Report)
				--v_t:SetEditable(false)

				rpt:SetBackgroundColor(Color(230,230,230,230))
				
			end
		end
	end
	RunConsoleCommand("RRS_Report_List")
	RRS.ReportListWindow = pnl


end
concommand.Add("RRS_Menu",RRS.ShowReportList)

function RRS.GetReportList()
	RRS.Reports = net.ReadTable()
	if RRS.ReportListWindow then
		RRS.ReportListWindow.UpdateList()
	end
end
net.Receive("RRS_Report_List",RRS.GetReportList)
