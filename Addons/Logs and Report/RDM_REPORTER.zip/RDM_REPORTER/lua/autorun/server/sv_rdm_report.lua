/* ==============================================

RDM REPORT SYSTEM
by Remscar

Hooks:
RDM_Report {attacker, victim}

=================================================*/

if !RRS then
	RRS = {}
end

RRS.Reports = {}
/* Entry Structure:
Attacker - ply
Victim - ply
Attacker_Report = string
Victim_Report = string
Evaluated = bool
Ready = bool
*/

local function PlayerDeathHook(ply, attacker, dmginfo)
	if GetRoundState() != ROUND_ACTIVE then return end
	if (IsValid(attacker) and attacker:IsPlayer()) and attacker != ply and ply:IsActive() then
      if (attacker:IsActiveTraitor()) then
         if ply:GetTraitor() then
            hook.Call("RDM_Report",nil,attacker,ply)
         end
      end
      if !attacker:IsActiveDetective() and !attacker:IsActiveTraitor() then
         if !ply:IsTraitor() then
			hook.Call("RDM_Report",nil,attacker,ply)
         end
      end
      if attacker:IsActiveDetective() then
      	if !ply:IsTraitor() then
      		hook.Call("RDM_Report",nil,attacker,ply)
      	end
      end
	end
end
hook.Add("PlayerDeath","RDM_REPORT_PlayerDeath",PlayerDeathHook)


-- local function FakeReport()
-- 	local tab = {}
-- 	tab.Attacker = ents.GetByIndex(1)
-- 	tab.Attacker_Name = "Test1"
-- 	tab.Victim = ents.GetByIndex(1)
-- 	tab.Victim_Name = "Test2"
-- 	tab.Attacker_Report = "He looked at me strange"
-- 	tab.Victim_Report = "He had a bug on his face and it really scared me so i was watching him to make sure that the bug didn't fly over and land on me because i really hate bugs. But then he shot me and it was really mean."
-- 	tab.Evaluated = false
-- 	tab.Ready = true
-- 	tab.ID = #RRS.Reports + 1

-- 	RRS.Reports[#RRS.Reports + 1] = tab
-- end
-- concommand.Add("fr",FakeReport)

util.AddNetworkString("RRS_Report_Request")
util.AddNetworkString("RRS_Report_Receive")
util.AddNetworkString("RRS_Report_List")

function RRS.CatchRDM(atk,ply)
	if !IsValid(atk) || !IsValid(ply) then return end
	if (atk == ply) then return end

	RRS.NewReport(atk,ply)

	RRS.ReportAttacker(atk,ply,#RRS.Reports)
	RRS.ReportVictim(ply,atk,#RRS.Reports)

	local id = #RRS.Reports

	timer.Simple(60,function() RRS.Reports[id].Ready = true end)

	MsgN("[RDM REPORTER] "..atk:Nick().." seemed to RDM "..ply:Nick().."! Creating a report case!")

	
end
hook.Add("RDM_Report","RRS_RDM_REPORT",RRS.CatchRDM)

function RRS.NewReport(atk,ply)
	local tab = {}
	tab.Attacker = atk
	tab.Attacker_Name = atk:Nick()
	tab.Victim = ply
	tab.Victim_Name = ply:Nick()
	tab.Attacker_Report = false -- false
	tab.Victim_Report = false
	tab.Evaluated = false
	tab.Ready = false
	tab.ID = #RRS.Reports + 1

	RRS.Reports[#RRS.Reports + 1] = tab
end



function RRS.ReportAttacker(ply,victim,id)
	ply:SetNoDraw(true)
	ply:Freeze(true)
	ply:GodEnable()

	net.Start("RRS_Report_Request")
	net.WriteBit(true) --IsAttacker
	net.WriteFloat(id)
	net.WriteEntity(victim)
	net.Send(ply)
end

function RRS.ReportVictim(ply,attacker,id)
	net.Start("RRS_Report_Request")
	net.WriteBit(false) --IsAttacker
	net.WriteFloat(id)
	net.WriteEntity(attacker)
	net.Send(ply)
end

function RRS.ReceiveReport(len,ply)
	local isAttacker = tobool(net.ReadBit())
	local id = net.ReadFloat()
	local text = net.ReadString()

	if !RRS.Reports[id] then return end
	if isAttacker then
		ply:SetNoDraw(false)
		ply:SendLua("chat.AddText(Color(255,55,55), \"You will be unfrozen and ungodded in 3 seconds\")")
		timer.Simple(3,function() if IsValid(ply) then ply:Freeze(false) ply:GodDisable() end end)
		RRS.Reports[id].Attacker_Report = text
	else
		RRS.Reports[id].Victim_Report = text
	end

	MsgN("[RDM REPORTER] "..ply:Nick().." reported on an RDM case!")

	if RRS.Reports[id].Victim_Report != false and RRS.Reports[id].Attacker_Report != false then
		RRS.Reports[id].Ready = true
		RRS.NotifyAdmins()
	end

	
end
net.Receive("RRS_Report_Receive",RRS.ReceiveReport)

function RRS.NotifyAdmins()
	for k,v in pairs(player.GetAll()) do
		if v:IsUserGroup("owner") ||v:IsUserGroup("admin") || v:IsUserGroup("superadmin") || v:IsUserGroup("moderator") || v:IsAdmin() then
			v:SendLua("chat.AddText(Color(255,55,55), \"A new RDM report has been filed!\")")
		end
	end
end

function RRS.GetReportList(ply)
	if ply:IsUserGroup("owner") || ply:IsUserGroup("admin") || ply:IsUserGroup("superadmin") || ply:IsUserGroup("moderator") || ply:IsAdmin() then
		net.Start("RRS_Report_List")
		net.WriteTable(RRS.Reports)
		net.Send(ply)
	end
end
concommand.Add("RRS_Report_List",RRS.GetReportList)

function RRS.ReportEvaluated(ply,cmd,args)
	if !IsValid(ply) then return end

	if ply:IsUserGroup("owner") || ply:IsUserGroup("admin") || ply:IsUserGroup("superadmin") || ply:IsUserGroup("moderator") || ply:IsAdmin() then

		if !args[1] then return end
		local id = tonumber(args[1])
		RRS.Reports[id].Evaluated = true
	end
end
concommand.Add("RRS_Report_Eval",RRS.ReportEvaluated)

function RRS.OpenMenu(ply,text)
	if ( string.sub( text, 1, 5 ) == "!rdms" ) then
		ply:ConCommand("RRS_Menu")
		return ""
	end
end
hook.Add("PlayerSay","RRS_PlayerSay",RRS.OpenMenu)


-- function TestRRS(ply)
-- 	hook.Call("RDM_Report",nil,ents.GetByIndex(2),ents.GetByIndex(1))
-- end
-- concommand.Add("tr",TestRRS)