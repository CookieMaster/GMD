INSTALLATION
------------
Copy and paste the contained folders in to the "garrysmod" directory. If there are any conflicts with your addons contact me and I will merge the files in seconds.

SUPPORT
------------
This addon was made by me, spykr, and will be supported and updated as long as it remains on CoderHire.
You can contact me on:
Steam (www.steamcommunity.com/id/spykr)
CoderHire (www.coderhire.com/profile/view/598)
Lockdown Gaming (www.lockdowngaming.org/forums/member.php?action=profile&uid=1)
