--[[What Groups are allowed to use the screenshot grabber.]]
GRAB_ALLOWEDGROUPS =
{
"admin",
"superadmin",
"moderator",
"headadmin",
"Developer" -- Note Last item in list does not have an "," after it
}
--[[Command to open ScreenShot Menu (type bind key "say /sg" to open it via key)]]--
GRAB_COMMAND = "/sg"

if CLIENT then
GRAB_QUALITY = 0.1 -- Quality of the photo, Consider 1 to be 100%, 0.8 to be 80%, 0.5 to be 50% etc SHOULD ALWAYS BE AT 0.1 BECAUSE IM A LAZY FUCK
GRAB_FORMAT = "jpeg" -- Format of the Photo, I recommend making it jpeg.




surface.CreateFont( "GrabTitleFont", {
 font = "Arial",
 size = 54,
 weight = 800,
 blursize = 0,
 scanlines = 0,
 antialias = true,
 underline = false,
 italic = false,
 strikeout = false,
 symbol = false,
 rotary = false,
 shadow = true,
 additive = false,
 outline = false
} )

function DScreenList(w, h, col)
	--BackGround
		surface.SetDrawColor(col)
		surface.DrawRect(0, 0 , w, h)
	--BackGround

	--Bottom BAR
		surface.SetDrawColor(255,128,0,255)
		surface.DrawRect(0, h-5 , w, 5)
	--BOTTOM BAR

	--TOP BAR
		surface.SetDrawColor(255,128,0,255)
		surface.DrawRect(0, 0 , w, 5)
	--TOP BAR

	-- OUTLINE/RIGHT BAR
		surface.SetDrawColor(255,128,0,255)
		surface.DrawOutlinedRect(0, 0, w, h)
	-- OUTLINE/RIGHT BAR
	end
function DScreenFrame(w, h, col)
	--BackGround
		surface.SetDrawColor(col)
		surface.DrawRect(0, 0 , w, h)
	--BackGround

	--Bottom BAR
		surface.SetDrawColor(255,128,0,255)
		surface.DrawRect(0, h-10 , w, 10)
	--BOTTOM BAR

	--TOP BAR
		surface.SetDrawColor(255,128,0,255)
		surface.DrawRect(0, 0 , w, 10)
	--TOP BAR

	-- OUTLINE/RIGHT BAR
		surface.SetDrawColor(255,128,0,255)
		surface.DrawOutlinedRect(0, 0, w, h)
	-- OUTLINE/RIGHT BAR
	end

end