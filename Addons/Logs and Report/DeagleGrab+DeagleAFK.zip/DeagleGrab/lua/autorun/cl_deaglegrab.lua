include("deaglegrab_config.lua")
local temp = {}

if CLIENT then


net.Receive("OpenSimple", function()
	local hacker =LocalPlayer()
	table.Empty(temp)
  	local ScreenFrame = vgui.Create("DFrame")
			ScreenFrame:SetSize(400, 500)
			ScreenFrame:MakePopup()
			ScreenFrame:SetTitle("")
			ScreenFrame:ShowCloseButton(false)
			ScreenFrame:Center()
			ScreenFrame.Paint = function()
				DScreenFrame(ScreenFrame:GetWide(), ScreenFrame:GetTall(), Color(30,30,30,255))
						surface.SetFont("GrabTitleFont")
				-- Edit this colour for the Title Colour!
				surface.SetTextColor( 255, 128, 0, 255 )
				surface.SetTextPos( ScreenFrame:GetWide()/4-25, 20 ) 
				surface.DrawText( "SimpleGrab" )
			end

			local SButton = vgui.Create("DButton",ScreenFrame)
			SButton:SetPos(50,ScreenFrame:GetTall()-70)
			SButton:SetSize(100,35)
			SButton:SetVisible(true)
			SButton:SetText("Screenshot")
			SButton:SetDisabled(true)
			SButton.DoClick = function()
			chat.AddText(Color(255,128,0,255),"[SimpleGrab] Attempting to retrieve "..hacker:Name().."'s screen.")
		
				net.Start("SRequest")
					net.WriteEntity(hacker)
				net.SendToServer()
		
			ScreenFrame:Close()
			end

			local PlayerList = vgui.Create("DListView",ScreenFrame)
			PlayerList:SetPos(50,100)
			PlayerList:SetSize(300, 300)
			PlayerList:SetMultiSelect(false)
			PlayerList:AddColumn("Players")
			PlayerList.OnRowSelected = function(parent,line)
				SButton:SetDisabled(false)
				hacker = temp[PlayerList:GetSelectedLine()]
			end
			PlayerList.Paint = function()
			DScreenList(PlayerList:GetWide(), PlayerList:GetTall(), Color(30,30,30,255))
			end 		

			for k,v in pairs(player.GetAll()) do
			
				table.insert(temp,v)
				local theline = PlayerList:AddLine(v:Name())
				
				for i=0,#PlayerList:GetLines() do
					function theline:PaintOver() 
						for k,v in pairs (theline.Columns) do
							v:SetTextColor(Color(255,200,0,255))
						end
							surface.SetDrawColor(255,128,0,255)
						surface.DrawRect(0, PlayerList:GetLine(i):GetTall()-1, PlayerList:GetLine(i):GetWide(),1)
					end

			end
				
			end


		
		
			local CButton = vgui.Create("DButton",ScreenFrame)
			CButton:SetPos(250,ScreenFrame:GetTall()-70)
			CButton:SetSize(100,35)
			CButton:SetVisible(true)
			CButton:SetText("Exit")
			CButton.DoClick = function()
			ScreenFrame:Close()
		end
			


end)


net.Receive("GScreen", function()
		local specs = {}
		specs.format = GRAB_FORMAT
		specs.h = ScrH()
		specs.w = ScrW()
		specs.quality = GRAB_QUALITY
		specs.x = 0
		specs.y = 0

		local screen = render.Capture( specs )
		local admin = net.ReadEntity()
		

		net.Start("SScreen")
			net.WriteEntity(admin)
			net.WriteString( util.Base64Encode(screen) )
		net.SendToServer()
	end)
net.Receive("InformPlayer2", function()
		chat.AddText(Color(255,128,0,255),"[SimpleGrab] We are legally obliged to inform you that an administrator has requested a screenshot of your screen.")
end)
net.Receive("SAdmin", function()
		local hacker = net.ReadEntity()
		local screen = net.ReadString()

		local ScreenShot = vgui.Create("DFrame")
		ScreenShot:SetSize(ScrW() * 0.8, ScrH() * 0.8)
		ScreenShot:Center()
		ScreenShot:MakePopup()
		ScreenShot:ShowCloseButton(false)
		ScreenShot:SetTitle("")
		ScreenShot.Paint = function()
				DScreenFrame(ScreenShot:GetWide(), ScreenShot:GetTall(), Color(30,30,30,255))
				surface.SetDrawColor(Color(255,128,0,255))
				surface.DrawRect(0, 180, ScreenShot:GetWide(), ScreenShot:GetTall())
			end

		local ScreenPanel = vgui.Create("DPanel",ScreenShot)
		ScreenPanel:SetSize(ScreenShot:GetWide()-200,ScreenShot:GetTall()-20)
		ScreenPanel:SetPos(2,10)
	local ss = ScreenPanel:Add("HTML")
			ss:SetHTML([[
			<style type="text/css">
				body {
					margin: 0;	
					padding: 0;
					overflow: hidden;
				}
				img {
					width: 100%;
					height: 100%;
				}
			</style>
			<img src="data:image/jpg;base64,]] .. screen .. [[">]])
	ss:Dock( FILL )

	local ScreenLabel = vgui.Create("DLabel",ScreenShot)
	ScreenLabel:SetPos(ScreenShot:GetWide()-160,30)
	ScreenLabel:SetText("Screenshot of "..hacker:Name())
	ScreenLabel:SetTextColor(Color(255,128,0,255))
	ScreenLabel:SizeToContents()

	local ScreenLabel2 = vgui.Create("DLabel",ScreenShot)
	ScreenLabel2:SetPos(ScreenShot:GetWide()-180,60)
	ScreenLabel2:SetText("SteamID: "..hacker:SteamID())
	ScreenLabel2:SetTextColor(Color(255,128,0,255))
	ScreenLabel2:SizeToContents()
	

	ScreenButton = vgui.Create("DButton",ScreenShot)
	ScreenButton:SetPos(ScreenShot:GetWide()-180,120)
	ScreenButton:SetSize(165,20)
	ScreenButton:SetText("Steam Profile")
	ScreenButton.DoClick = function()
	gui.OpenURL("http://steamcommunity.com/profiles/"..hacker:SteamID64())
	end

	ScreenButton2 = vgui.Create("DButton",ScreenShot)
	ScreenButton2:SetPos(ScreenShot:GetWide()-180,150)
	ScreenButton2:SetSize(165,20)
	ScreenButton2:SetText("Exit")
	ScreenButton2.DoClick = function()
	ScreenShot:Close()
	end

	ScreenButton3 = vgui.Create("DButton",ScreenShot)
	ScreenButton3:SetPos(ScreenShot:GetWide()-180,90)
	ScreenButton3:SetSize(165,20)
	ScreenButton3:SetText("Copy SteamID")
	ScreenButton3.DoClick = function()
	SetClipboardText(hacker:SteamID())
	chat.AddText(Color(255,128,0,255),"[SimpleGrab] Players SteamID Copied.")
	end

		net.Start("InformPlayer")
		net.WriteEntity(hacker)
		net.SendToServer()
	end)
end