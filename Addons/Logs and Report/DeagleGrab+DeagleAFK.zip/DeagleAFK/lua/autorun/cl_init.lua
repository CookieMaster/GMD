include("afk_config.lua")
if CLIENT then
local firstint = 0
local secondint = 0
local answer = 0
local countdown = AFK_TIMEFORANSWER
local fpos = 0
local fang = 0
if AFK_GLOBAL == 0 then

timer.Create("CheckAFKTimerCL",AFK_DELAY*60,0, function()
	MsgC(Color(255,128,0,255),"AFK Check was run on you!\n")
	if fpos == nil then
		SetDefault()
	elseif (fpos==LocalPlayer():GetPos()) or (fang == LocalPlayer():GetAngles()) then
CreateGUI()
SetDefault()
elseif (fpos!=LocalPlayer():GetPos()) or (fang != LocalPlayer():GetAngles()) then
SetDefault()
end
end)

end

function SetDefault()
	fpos = LocalPlayer():GetPos()
	fang = LocalPlayer():GetAngles()
end
function CreateGUI()
	local AFKFrame = vgui.Create("DFrame")
			AFKFrame:SetSize(120, 150)
			AFKFrame:SetPos(-200,ScrH()/2-150)
			AFKFrame:MoveTo(-1,ScrH()/2-150,1,0,.5)
			AFKFrame:SetDraggable(false)
			AFKFrame:SetTitle("")
			AFKFrame:ShowCloseButton(false)
			AFKFrame.Paint = function()
				DAFKFrame(AFKFrame:GetWide(), AFKFrame:GetTall(), Color(30,30,30,255))

			surface.SetFont("AFKFont1")
				--Edit this colour for the Title Colour!
			end
			local AFKLabel = vgui.Create("DLabel", AFKFrame)
			AFKLabel:SetPos(27,17) 
			AFKLabel:SetColor(Color(255,128,0,255)) 
			AFKLabel:SetFont("AFKFont1")
			AFKLabel:SetText(AFK_TITLETEXT) 
			AFKLabel:SizeToContents() 

			local QLabel = vgui.Create("DLabel", AFKFrame)
			QLabel:SetPos(35,50) 
			QLabel:SetColor(Color(255,128,0,255)) 
			QLabel:SetFont("AFKFont1")
			if AFK_MATH>=1 then
				firstint=math.random(1,10)
				secondint=math.random(1,10)
				QLabel:SetText(firstint.."+"..secondint.."=") 

			end
			QLabel:SizeToContents() 

			local CLabel = vgui.Create("DLabel", AFKFrame)
			CLabel:SetPos(95,15) 
			CLabel:SetColor(Color(255,128,0,255)) 
			CLabel:SetFont("AFKFont2")
			CLabel:SetText(tostring(countdown))
			CLabel:SizeToContents() 

timer.Create( "ClientSideTimer",1,AFK_TIMEFORANSWER, function() 
				countdown=countdown-1
				CLabel:SetText(tostring(countdown))
				if countdown<=0 then
chat.AddText(Color(255,128,0,255),"Get Rekt")
	timer.Remove("ClientSideTimer")
		AFKFrame:Close()
net.Start("KickMe")
net.SendToServer()
	countdown=AFK_TIMEFORANSWER


end
				end )


		local AFKText = vgui.Create( "DTextEntry", AFKFrame )

			AFKText:SetPos( 10,90 )
			AFKText.OnMousePressed = function()
			AFKFrame:MakePopup()
			AFKText:RequestFocus()
		end
			AFKText:SetSize(100,20)
			AFKText:SetEnterAllowed( true )
			AFKText:SetEditable(true)
			AFKText.OnEnter = function()
					timer.Remove("ClientSideTimer")
    			
countdown=AFK_TIMEFORANSWER

    			if AFK_MATH >= 1 then
    			answer= firstint+secondint
    			local tanswer= string.find(tostring(AFKText:GetValue()), answer)
    		

    	if  AFKText:GetValue() != "" then
    		if tanswer ==nil  then
    				if AFK_TRYAGAIN ==1 then
    				chat.AddText(Color(255,128,0,255),"Try Again, You got the answer wrong!")
    				AFKText:RequestFocus()
    			else
    				chat.AddText(Color(255,128,0,255),"You got the answer wrong, The answer was "..answer.." but you can keep playing!")
    				AFKFrame:Close()
    			end

    		else
   					chat.AddText(Color(255,128,0,255),"Good work, You got the answer right! You can continue playing!")
    				AFKFrame:Close()
    		end


	
    end
    	end
				if AFKText:GetValue() == "" then
			chat.AddText(Color(255,128,0,255),"You must enter something in the field!")

end
		
		
end
			local AFKSubmit = vgui.Create("DButton",AFKFrame)
			AFKSubmit:SetSize(40,20)
			AFKSubmit:SetPos(38,115)
			AFKSubmit:SetText("Submit")
			AFKSubmit.DoClick = function() 
					timer.Remove("ClientSideTimer")
    			
countdown=AFK_TIMEFORANSWER

    			if AFK_MATH >= 1 then
    			answer= firstint+secondint
    			local tanswer= string.find(tostring(AFKText:GetValue()), answer)
    		

    	if  AFKText:GetValue() != "" then
    		if tanswer ==nil  then
    				if AFK_TRYAGAIN ==1 then
    				chat.AddText(Color(255,128,0,255),"Try Again, You got the answer wrong!")
    				AFKText:RequestFocus()
    			else
    				chat.AddText(Color(255,128,0,255),"You got the answer wrong, The answer was "..answer.." but you can keep playing!")
    				AFKFrame:Close()
    			end

    		else
   					chat.AddText(Color(255,128,0,255),"Good work, You got the answer right! You can continue playing!")
    				AFKFrame:Close()
    		end


	
    end
    	end
				if AFKText:GetValue() == "" then
			chat.AddText(Color(255,128,0,255),"You must enter something in the field!")

end
		


		end


end
net.Receive("CheckAFK", function()

		CreateGUI()


end)
end