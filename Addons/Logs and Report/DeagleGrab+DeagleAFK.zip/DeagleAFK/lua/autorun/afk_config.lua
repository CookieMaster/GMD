--[[How many minutes between each AFK Check]]
AFK_DELAY = 5 -- 10 Minutes || Change this for how long between each AFK Check.

AFK_TIMEFORANSWER = 60 -- 45 Seconds || Change this for how long they have to type the answer
AFK_GLOBAL = 0 -- Set this to 1 if you want it to do an AFK check every 10 minutes globally or set to 0 if you want an AFK Check whenever a player has been idle for AFK_DELAY
AFK_TITLETEXT = "AFK Check"
AFK_MATH = 1 -- 1= Simple Math Questions, 0= Custom Questions
AFK_TRYAGAIN = 0 -- If they get the answer wrong do they have to try again? 1= Yes 0= No, They can continue playing

AFK_CANCALL = { -- Groups that can use /callafk (GLOBAL CHECK ON EVERYONE)w
"superadmin",
"headadmin",
"Developer",
"admin"	
}


 if CLIENT then 



--[[The Derma Theme of AFKCheckType 1]]
function DAFKFrame(w, h, col)
	--BackGround
		surface.SetDrawColor(col)
		surface.DrawRect(0, 0 , w, h)
	--BackGround

	--Bottom BAR
		surface.SetDrawColor(255,128,0,255)
		surface.DrawRect(0, h-10 , w, 10)
	--BOTTOM BAR

	--TOP BAR
		surface.SetDrawColor(255,128,0,255)
		surface.DrawRect(0, 0 , w, 10)
	--TOP BAR

	-- OUTLINE/RIGHT BAR
		surface.SetDrawColor(255,128,0,255)
		surface.DrawOutlinedRect(0, 0, w, h)
	-- OUTLINE/RIGHT BAR
	end

surface.CreateFont( "AFKFont1", {
 font = "Collegier",
 size = 16,
 weight = 1,
 blursize = 0,
 scanlines = 0,
 antialias = true,
 underline = false,
 italic = false,
 strikeout = false,
 symbol = false,
 rotary = false,
 shadow = false,
 additive = false,
 outline = false
} )

surface.CreateFont( "AFKFont2", {
 font = "Arial",
 size = 19,
 weight = 800,
 blursize = 0,
 scanlines = 0,
 antialias = true,
 underline = false,
 italic = false,
 strikeout = false,
 symbol = false,
 rotary = false,
 shadow = true,
 additive = false,
 outline = false
} )



 end