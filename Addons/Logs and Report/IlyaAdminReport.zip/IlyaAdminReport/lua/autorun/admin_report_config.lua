--[[ v1.2 - Ilya ]]--

admin_report = {}

-- Add commands as you want here, if a player types it in, it will open the menu
admin_report.Commands = {
	"!report",
	"/report",
	":report",
}

-- Cool down time for players between sending reports, in seconds
admin_report.CoolDownTime = 200

-- Prefix for when the report UI gets an error
admin_report.ReportPrefix = "[REPORT]"

-- Sound played when it gets an error
admin_report.ErrorSound = "common/bugreporter_failed.wav"

-- Sound played when your action is accepted
admin_report.AcceptSound = "common/bugreporter_succeeded.wav"

-- Should admins be notified when a new report is posted?
admin_report.NotifyAdmins = true

-- Advanced option that controls how wide the admin report should be. Increase to make it bigger. 
-- 1 = full screen
admin_report.WidthAspect = 0.7

-- Advanced option that controls how tall the admin report should be. Increase to make it bigger. 
-- 1 = full screen
admin_report.HeightAspect = 0.6

-- Paragraph on the main page to help people understand the reporter
admin_report.HelpPara = "When making a report keep in mind if you abuse the system or make false reports, there will be consequences. If the player you want to report is not in the game please manually input their steam ID and their username, the username is just used to know what the persons name was when they did what they did. When inputting a steam ID make sure that is the correct steam ID of the player. When also inputting a reason for your report try to explain as much as you can to what the player did and why he should be banned or punished. Finally when you are up to adding proof please add links to images of what the player has done, this will greatly help with your story and allow for a better assumption of what happened. Voting up a report on the lit will show how import a report is to the admins, the more votes it has, the more of a priority it should be for an admin to look at."

-- Here you can add what players or groups can Accept and Deny reports
function CanAccpetAndDenyReports(ply)

	if ply:IsAdmin() then
		return true
		
	else
		return false
		
	end
	
end

-- Here you can add what groups can delete reports, NOTE: do not keep all your reports after they have been accepted or denied. 
-- Having ALOT can cause lag when retrieving the list of reports. Its best to delete one you no longer need.
function CanDeleteReports(ply)

	if ply:IsSuperAdmin() then
		return true
		
	else
		return false
		
	end
	
end

-- Here if you want to you can change the icons in the admin report UI, keep in mind they will be resized to 16x16
admin_report.icons = {
	accept = "icon16/tick.png",
	deny = "icon16/cross.png",
	delete = "icon16/delete.png",
	copy = "icon16/paste_plain.png",
	pending = "icon16/information.png",
	voteup = "icon16/thumb_up.png"
}