if CLIENT then return end

util.AddNetworkString("CREATE_REPORT")
util.AddNetworkString("SEND_REPORTS")
util.AddNetworkString("DELETE_REPORT")
util.AddNetworkString("EDIT_REPORT")
util.AddNetworkString("VOTE_REPORT")

local function CreateReportList()
	admin_report.reports = {}
	--print("REFRESH")
	local report_list = file.Find("data/admin_reports/*.txt", "GAME") or {}
	for _, report in pairs(report_list)do
		local r_content = file.Read("admin_reports/"..report)
		local r_explode = string.Explode("////", r_content)
		admin_report.reports[report] = {
			ID = report,
			REPORTER = r_explode[1],
			REPORTERID = r_explode[2],
			FAGGOT = r_explode[3],
			FAGGOTID = r_explode[4],
			INFO = r_explode[5],
			PROOF = util.JSONToTable(r_explode[6]),
			DATE = r_explode[7],
			STATUS = r_explode[8],
			VOTES = util.JSONToTable(r_explode[9])
		}
	end
	--PrintTable(admin_report.reports)
	BroadcastLua("RESET_REPORT_TABLE()")
	for k, v in pairs(admin_report.reports)do
		net.Start("SEND_REPORTS")
		net.WriteString(v.ID)
		net.WriteTable(v)
		net.Broadcast()
	end
end

concommand.Add("report_refresh", function(ply, cmd, arg)
	CreateReportList()
end)

hook.Add("Initialize", "Init Report System", function()
	admin_report.reports = {}
	CreateReportList()
end)

hook.Add("PlayerInitialSpawn", "SendInitReports", function(ply)
	BroadcastLua("RESET_REPORT_TABLE()")
	for k, v in pairs(admin_report.reports)do
		net.Start("SEND_REPORTS")
		net.WriteString(v.ID)
		net.WriteTable(v)
		net.Send(ply)
	end
end)

hook.Add("PlayerSay", "Report Command", function( ply, text )
	if table.HasValue( admin_report.Commands, text ) then
		ply:SendLua("Toggle_admin_report()")
		return ""
	end
end)

net.Receive("VOTE_REPORT", function()
	local id = net.ReadString()
	local ply = player.GetByID(net.ReadFloat())
	local ri = admin_report.reports[id]
	table.insert(ri.VOTES, ply:SteamID())
	local strng = ri.REPORTER .. "////" .. ri.REPORTERID .. "////" .. ri.FAGGOT .. "////" .. ri.FAGGOTID .. "////" .. ri.INFO .. "////" .. util.TableToJSON(ri.PROOF) .. "////" .. ri.DATE .. "////" .. ri.STATUS .. "////" .. util.TableToJSON(ri.VOTES)
	file.Write("admin_reports/" .. id, strng)
	timer.Simple(1, CreateReportList)
end)

net.Receive("EDIT_REPORT", function()
	local id = net.ReadString()
	local new_stat = net.ReadFloat()
	local ri = admin_report.reports[id]
	ri.STATUS = new_stat
	local strng = ri.REPORTER .. "////" .. ri.REPORTERID .. "////" .. ri.FAGGOT .. "////" .. ri.FAGGOTID .. "////" .. ri.INFO .. "////" .. util.TableToJSON(ri.PROOF) .. "////" .. ri.DATE .. "////" .. ri.STATUS .. "////" .. util.TableToJSON(ri.VOTES)
	file.Write("admin_reports/" .. id, strng)
	timer.Simple(1, CreateReportList)
end)

net.Receive("DELETE_REPORT", function()
	local id = net.ReadString()
	file.Delete("admin_reports/" .. id)
	timer.Simple(1, CreateReportList)
end)

net.Receive("CREATE_REPORT", function()
	local ri = net.ReadTable()
	local strng = ri.REPORTER .. "////" .. ri.REPORTERID .. "////" .. ri.FAGGOT .. "////" .. ri.FAGGOTID .. "////" .. ri.INFO .. "////" .. ri.PROOF .. "////" .. tostring(os.date([[%m/%d/%y]])) .. "////" .. 0 .. "////" .. util.TableToJSON({})
	file.Write("admin_reports/" .. os.time() .. ".txt", strng)
	timer.Simple(1, CreateReportList)
	for _, ply in pairs(player.GetAll())do
		if admin_report.NotifyAdmins then
			if CanAccpetAndDenyReports(ply) then
				ply:SendLua("chat.AddText(Color(255,255,255), \"A new admin report has been posted!\")")
			end
		end
	end
end)