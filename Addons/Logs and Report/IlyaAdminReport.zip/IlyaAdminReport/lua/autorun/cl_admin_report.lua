if SERVER then return end

local NextReportTime = 0
local ReportOpen = false
local report_table = {}
local report_mode = 0
local report_main_bg = 0
local combo_box_val = ""
local selected_report = 1
local ScaleX, ScaleY = 0,0

local Got_Report_Data = false

-- Quick Colors
local COL_WHITE            = Color(210,210,210)
local COL_WHITE_L          = Color(240,240,240)
local COL_DGREY            = Color(60,60,60)
local COL_DGREY_L          = Color(50,50,50)
local COL_grey             = Color(70,70,70)

local report_proof = {}
local Saved_Proof_Btn = {}
local Saved_Proof_Remove_Btn = {}
local Saved_Proof_Box = {}
local d_frame = 0

timer.Simple(0.2, function()
	ScaleX, ScaleY = ScrW()*admin_report.WidthAspect, ScrH()*admin_report.HeightAspect
end)

-- Quick create functions
local function c_box(t, x, y, w, h, c, p)
	t[#t+1] = VGUIRect( x, y, w, h )
	t[#t]:SetColor(c)
	t[#t]:SetParent(p)
end
local function c_btn(t, x, y, w, h, p)
	t[#t+1] = vgui.Create( "DButton", p)
	t[#t]:SetPos( x, y )
	t[#t]:SetSize( w, h )
	t[#t]:SetText("")
end
local function c_pnl(t, x, y, w, h, c, p)
	t[#t+1] = vgui.Create( "DPanel", p)
	t[#t]:SetPos( x, y )
	t[#t]:SetSize( w, h )
	t[#t]:SetBackgroundColor(c)
end
local function c_txt(t, x, y, w, h, tt, f, c, p)
	t[#t+1] = vgui.Create( "DLabel", p)
	t[#t]:SetPos( x, y )
	t[#t]:SetSize( w, h )
	t[#t]:SetText(tt)
	t[#t]:SetFont(f)
	t[#t]:SetColor(c)
end
local function c_grd(t, x, y, c, w, h, p)
	t[#t+1] = vgui.Create( "DGrid", p)
    t[#t]:SetPos( x, y )
    t[#t]:SetCols( c )
    t[#t]:SetColWide( w )
    t[#t]:SetRowHeight(h)
end
local function c_html(t, x, y, w, h, u, p)
	t[#t+1] = vgui.Create( "HTML", p)
    t[#t]:SetPos( x, y )
    t[#t]:SetSize( w, h )
    t[#t]:OpenURL(u)
end 
local function c_img(t, x, y, w, h, i, p)
	t[#t+1] = vgui.Create( "DImage", p)
	t[#t]:SetPos( x, y )
	t[#t]:SetSize( w, h )
	t[#t]:SetMaterial(i)
end
------------------------------------------

surface.CreateFont( "REPORT_TITLE", { font = "Default", size = 14, weight = 1000, antialias = true } )
surface.CreateFont( "REPORT_LOWER", { font = "Default", size = 12, weight = 100, antialias = true } )
surface.CreateFont( "REPORT_LOWERR", { font = "Default", size = 10, weight = 1, antialias = true } )
surface.CreateFont( "REPORT_T", { font = "Default", size = 30, weight = 1000, antialias = true } )
surface.CreateFont( "REPORT_TT", { font = "Default", size = 13, weight = 1, antialias = true } )
surface.CreateFont( "REPORT_TTT", { font = "Default", size = 16, weight = 1, antialias = true } )
surface.CreateFont( "REPORT_TTTT", { font = "Default", size = 23, weight = 1, antialias = true } )

function RESET_REPORT_TABLE()
	report_table = {}
end

net.Receive("SEND_REPORTS", function()
	local id = net.ReadString()
	table.insert(report_table, net.ReadTable() )
	table.sort(report_table, function(a, b) return tonumber(a.STATUS) < tonumber(b.STATUS) end)
	--report_table[id] = net.ReadTable()
	Got_Report_Data = true
end)

local function CloseReportUI()
	for _, elem in pairs(admin_report.VGUI)do
		elem:Remove()
	end
end

local function SendReport(name, steam, info, proof)
	local tab = {
		REPORTER = LocalPlayer():Nick(), 
		REPORTERID = LocalPlayer():SteamID(),
		FAGGOT = name,
		FAGGOTID = steam,
		INFO = info,
		PROOF = proof
	}
	net.Start("CREATE_REPORT")
	net.WriteTable(tab)
	net.SendToServer()
end

local function PlyGetByName(n)
	for k, v in pairs(player.GetAll())do
		if n == v:Nick() then return v end
	end
end

local function CreateProofTable()
	for k, v in pairs(Saved_Proof_Box)do admin_report.VGUI[v]:Remove() end
	Saved_Proof_Btn = {}
	Saved_Proof_Remove_Btn = {}
	Saved_Proof_Box = {}
	for k, v in pairs(report_proof)do
		c_box(admin_report.VGUI, 5+(k-1)*91, 382, 90, 150, Color(0,0,0,60), admin_report.VGUI[d_frame])
		table.insert(Saved_Proof_Box, #admin_report.VGUI)
		local last_proof_box = #admin_report.VGUI
		
		c_html(admin_report.VGUI, -(720/2), -(480/2), 720, 480, v, admin_report.VGUI[last_proof_box])
		
		c_btn(admin_report.VGUI, 0, 0, 90, 150, admin_report.VGUI[last_proof_box])
		table.insert(Saved_Proof_Btn, #admin_report.VGUI)
		admin_report.VGUI[#admin_report.VGUI]:SetDrawBackground(false)
		
		c_btn(admin_report.VGUI, 0, 130, 90, 20, admin_report.VGUI[last_proof_box])
		table.insert(Saved_Proof_Remove_Btn, #admin_report.VGUI)
		admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
			draw.RoundedBox( 0, 0, 0, w, h, Color(250,67,67))
			draw.SimpleText("REMOVE", "REPORT_LOWER", w/2, h/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	for _, url in pairs(Saved_Proof_Btn)do
		admin_report.VGUI[url].DoClick = function()
			if !string.find(report_proof[_], "http") then
				gui.OpenURL("http://" .. report_proof[_])
			else
				gui.OpenURL(report_proof[_])
			end
		end
	end
	
	for _, elem in pairs(Saved_Proof_Remove_Btn)do
		admin_report.VGUI[elem].DoClick = function()
			table.RemoveByValue( report_proof, report_proof[_] )
			CreateProofTable()
		end
	end
end

local function OpenReportWrite() 
	report_proof = {}
	Saved_Proof_Btn = {}
	Saved_Proof_Remove_Btn = {}
	Saved_Proof_Box = {}
	
	c_txt(admin_report.VGUI, 5, 0, 300, 40, "NEW REPORT", "REPORT_T", Color(0,0,0,120), admin_report.VGUI[report_main_bg])
	c_txt(admin_report.VGUI, 5, 32, 300, 20, "NAME:", "REPORT_TT", Color(0,0,0,120), admin_report.VGUI[report_main_bg])
	c_txt(admin_report.VGUI, 5, 72, 300, 20, "STEAMID:", "REPORT_TT", Color(0,0,0,120), admin_report.VGUI[report_main_bg])
	c_txt(admin_report.VGUI, 5, 112, 300, 20, "REASON:", "REPORT_TT", Color(0,0,0,120), admin_report.VGUI[report_main_bg])
	c_txt(admin_report.VGUI, 5, 332, 300, 20, "PROOF: (link)", "REPORT_TT", Color(0,0,0,120), admin_report.VGUI[report_main_bg])
	c_txt(admin_report.VGUI, ScaleX-210, 72, 200, 50, "* If the player is in the game please use the combo-box above, if not, then use the manual entry to the left.", "REPORT_LOWER", Color(0,0,0,120), admin_report.VGUI[report_main_bg])
	admin_report.VGUI[#admin_report.VGUI]:SetWrap(true)
	
	admin_report.VGUI[#admin_report.VGUI+1] = vgui.Create("DFrame", admin_report.VGUI[report_main_bg])
	admin_report.VGUI[#admin_report.VGUI]:SetSize(ScaleX, ScaleY)
	admin_report.VGUI[#admin_report.VGUI]:SetPos(ScrW()/2-ScaleX/2+2, ScrH()/2-ScaleY/2+7+2)
	admin_report.VGUI[#admin_report.VGUI]:MakePopup()
	admin_report.VGUI[#admin_report.VGUI]:SetDraggable(false)
	admin_report.VGUI[#admin_report.VGUI]:SetTitle("")
	admin_report.VGUI[#admin_report.VGUI]:ShowCloseButton(false)
	admin_report.VGUI[#admin_report.VGUI].Paint = function() end
	d_frame = #admin_report.VGUI
	
	admin_report.VGUI[#admin_report.VGUI+1] = vgui.Create( "DComboBox", admin_report.VGUI[d_frame] )
	admin_report.VGUI[#admin_report.VGUI]:SetValue( "Player" )
	admin_report.VGUI[#admin_report.VGUI]:SetPos(ScaleX-210,50)
	admin_report.VGUI[#admin_report.VGUI]:SetSize( 200, 20 )
	for k, v in pairs(player.GetAll())do
		admin_report.VGUI[#admin_report.VGUI]:AddChoice( v:Nick() )
	end
	local combo_box = #admin_report.VGUI
	
	admin_report.VGUI[#admin_report.VGUI+1] = vgui.Create( "DTextEntry", admin_report.VGUI[d_frame] )
	admin_report.VGUI[#admin_report.VGUI]:SetText("")
	admin_report.VGUI[#admin_report.VGUI]:SetSize(300, 20)
	admin_report.VGUI[#admin_report.VGUI]:SetPos(5, 50)
	admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(230,230,230))
		draw.RoundedBox( 0, 1, 1, w-2, h-2, Color(255,255,255))
		s:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
	end
	admin_report.VGUI[#admin_report.VGUI].OnLoseFocus = function(t)
		admin_report.VGUI[d_frame]:KillFocus()
	end
	local name_entry = #admin_report.VGUI
	
	admin_report.VGUI[#admin_report.VGUI+1] = vgui.Create( "DTextEntry", admin_report.VGUI[d_frame] )
	admin_report.VGUI[#admin_report.VGUI]:SetText("")
	admin_report.VGUI[#admin_report.VGUI]:SetSize(300, 20)
	admin_report.VGUI[#admin_report.VGUI]:SetPos(5, 90)
	admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(230,230,230))
		draw.RoundedBox( 0, 1, 1, w-2, h-2, Color(255,255,255))
		s:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
	end
	admin_report.VGUI[#admin_report.VGUI].OnLoseFocus = function(t)
		admin_report.VGUI[d_frame]:KillFocus()
	end
	local steam_entry = #admin_report.VGUI
	
	admin_report.VGUI[#admin_report.VGUI+1] = vgui.Create( "DTextEntry", admin_report.VGUI[d_frame] )
	admin_report.VGUI[#admin_report.VGUI]:SetText("")
	admin_report.VGUI[#admin_report.VGUI]:SetSize(ScaleX-15, 200)
	admin_report.VGUI[#admin_report.VGUI]:SetPos(5, 130)
	admin_report.VGUI[#admin_report.VGUI]:SetMultiline(true)
	admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(230,230,230))
		draw.RoundedBox( 0, 1, 1, w-2, h-2, Color(255,255,255))
		s:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
	end
	admin_report.VGUI[#admin_report.VGUI].OnLoseFocus = function(t)
		admin_report.VGUI[d_frame]:KillFocus()
	end
	local info_entry = #admin_report.VGUI
	
	admin_report.VGUI[#admin_report.VGUI+1] = vgui.Create( "DTextEntry", admin_report.VGUI[d_frame] )
	admin_report.VGUI[#admin_report.VGUI]:SetText("")
	admin_report.VGUI[#admin_report.VGUI]:SetSize(200, 20)
	admin_report.VGUI[#admin_report.VGUI]:SetPos(5, 352)
	admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(230,230,230))
		draw.RoundedBox( 0, 1, 1, w-2, h-2, Color(255,255,255))
		s:DrawTextEntryText(Color(30, 30, 30), Color(149, 240, 193), Color(0, 0, 0))
	end
	admin_report.VGUI[#admin_report.VGUI].OnLoseFocus = function(t)
		admin_report.VGUI[d_frame]:KillFocus()
	end
	local Proof_Input_Box = #admin_report.VGUI
	
	c_btn(admin_report.VGUI, 210, 352, 40, 20, admin_report.VGUI[d_frame])
	admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
		draw.SimpleText("+ADD", "REPORT_TTT", w/2, h/2, Color(0,0,0,90), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	admin_report.VGUI[#admin_report.VGUI].DoClick = function()
		if #report_proof >= 6 then return end
		table.insert(report_proof, admin_report.VGUI[Proof_Input_Box]:GetValue())
		CreateProofTable()
	end
	
	c_btn(admin_report.VGUI, ScaleX-130, 5, 120, 40, admin_report.VGUI[d_frame])
	admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
		if NextReportTime <= CurTime() then
			draw.RoundedBox( 0, 0, 0, w, h, Color(125,209,145))
			draw.RoundedBox( 0, 1, 1, w-2, h-2, Color(144,245,168))
			draw.SimpleText("Send Report", "REPORT_TTT", w/2, h/2, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		else
			draw.RoundedBox( 0, 0, 0, w, h, Color(227,138,138))
			draw.RoundedBox( 0, 1, 1, w-2, h-2, Color(252,149,149))
			draw.SimpleText(string.ToMinutesSecondsMilliseconds(math.Round(NextReportTime-CurTime(), 2)), "REPORT_TTT", w/2, h/2+6, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText("Next Report Time", "REPORT_TTT", w/2, h/2-8, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
	admin_report.VGUI[#admin_report.VGUI].DoClick = function()
		if admin_report.VGUI[info_entry]:GetValue() == "" then
			chat.AddText(Color(255,255,255), admin_report.ReportPrefix .. " You must input a reason for your report.")
			return
		end
		if admin_report.VGUI[name_entry]:GetValue() == "" or admin_report.VGUI[steam_entry]:GetValue() == "" then
			chat.AddText(Color(255,255,255), admin_report.ReportPrefix .. " You must input a name and steam ID for your report.")
			return
		end
		if NextReportTime <= CurTime() then
			NextReportTime = CurTime()+admin_report.CoolDownTime
			local ply_name = " "
			local ply_steam = " "
			ply_name = admin_report.VGUI[name_entry]:GetValue()
			ply_steam = admin_report.VGUI[steam_entry]:GetValue()
			SendReport(ply_name, ply_steam, admin_report.VGUI[info_entry]:GetValue(), util.TableToJSON(report_proof))
		end
	end
	
	admin_report.VGUI[combo_box].OnSelect = function( panel, index, value, data )
		combo_box_val = value
		admin_report.VGUI[name_entry]:SetText(PlyGetByName(value):Nick())
		admin_report.VGUI[steam_entry]:SetText(PlyGetByName(value):SteamID())
	end
end

local function GetReportStatusCount(n)
	local count = 0
	for k, v in pairs(report_table)do
		if tonumber(v.STATUS) == n then 
			count = count + 1
		end
	end
	return count
end

local function OpenMainPage()
	surface.SetFont("REPORT_T")
	local w, h = surface.GetTextSize("ADMIN REPORT SYSTEM")
	c_txt(admin_report.VGUI, ScaleX/2-w/2, 10, w, 30, "ADMIN REPORT SYSTEM", "REPORT_T", Color(0,0,0,120), admin_report.VGUI[report_main_bg])
	
	c_txt(admin_report.VGUI, 5, 50, 200, 30, "HELP", "REPORT_TTT", Color(0,0,0,120), admin_report.VGUI[report_main_bg])
	for i = 1, ScaleX-40, 4 do
		c_box(admin_report.VGUI, 40+i, 65, 2, 1, Color(0,0,0,80), admin_report.VGUI[report_main_bg])
	end
	c_img(admin_report.VGUI, 5, 80, 16, 16, admin_report.icons.accept, admin_report.VGUI[report_main_bg])
	c_img(admin_report.VGUI, 5, 110, 16, 16, admin_report.icons.deny, admin_report.VGUI[report_main_bg])
	c_img(admin_report.VGUI, 5, 140, 16, 16, admin_report.icons.pending, admin_report.VGUI[report_main_bg])
	c_img(admin_report.VGUI, 5, 170, 16, 16, admin_report.icons.delete, admin_report.VGUI[report_main_bg])
	c_img(admin_report.VGUI, 5, 200, 16, 16, admin_report.icons.voteup, admin_report.VGUI[report_main_bg])
	
	c_txt(admin_report.VGUI, 25, 75, 200, 30, "- Report has been accepted.", "REPORT_TTT", Color(0,0,0,100), admin_report.VGUI[report_main_bg])
	c_txt(admin_report.VGUI, 25, 105, 200, 30, "- Report has been denied.", "REPORT_TTT", Color(0,0,0,100), admin_report.VGUI[report_main_bg])
	c_txt(admin_report.VGUI, 25, 135, 200, 30, "- Report is pending a decision.", "REPORT_TTT", Color(0,0,0,100), admin_report.VGUI[report_main_bg])
	c_txt(admin_report.VGUI, 25, 165, 200, 30, "- Remove this report.", "REPORT_TTT", Color(0,0,0,100), admin_report.VGUI[report_main_bg])
	c_txt(admin_report.VGUI, 25, 195, 200, 30, "- vote up a report on the list.", "REPORT_TTT", Color(0,0,0,100), admin_report.VGUI[report_main_bg])
	
	c_txt(admin_report.VGUI, 5, 220, 200, 30, "INFO", "REPORT_TTT", Color(0,0,0,120), admin_report.VGUI[report_main_bg])
	for i = 1, ScaleX-40, 4 do
		c_box(admin_report.VGUI, 40+i, 235, 2, 1, Color(0,0,0,80), admin_report.VGUI[report_main_bg])
	end
	c_txt(admin_report.VGUI, 10, 245, ScaleX-15, 30, admin_report.HelpPara, "REPORT_TTT", Color(0,0,0,100), admin_report.VGUI[report_main_bg])
	admin_report.VGUI[#admin_report.VGUI]:SetWrap(true)
	admin_report.VGUI[#admin_report.VGUI]:SetAutoStretchVertical(true)
	
	local whole_pi = table.Count(report_table)
	local pi_accepted = GetReportStatusCount(2)
	local pi_pending = GetReportStatusCount(0)
	local pi_denied = GetReportStatusCount(1)
	
	admin_report.VGUI[#admin_report.VGUI+1] = vgui.Create("DSemiCircle", admin_report.VGUI[report_main_bg])
	admin_report.VGUI[#admin_report.VGUI]:SetPos(ScaleX-400, 50)
	admin_report.VGUI[#admin_report.VGUI]:SetSize(200, 200)
	admin_report.VGUI[#admin_report.VGUI]:SetStartAng(0)
	admin_report.VGUI[#admin_report.VGUI]:SetEndAng(Lerp(pi_accepted/whole_pi, 0, 360))
	admin_report.VGUI[#admin_report.VGUI]:SetColor(Color(92,224,154))
	
	admin_report.VGUI[#admin_report.VGUI+1] = vgui.Create("DSemiCircle", admin_report.VGUI[report_main_bg])
	admin_report.VGUI[#admin_report.VGUI]:SetPos(ScaleX-400, 50)
	admin_report.VGUI[#admin_report.VGUI]:SetSize(200, 200)
	admin_report.VGUI[#admin_report.VGUI]:SetStartAng(admin_report.VGUI[#admin_report.VGUI-1]:GetEndAng())
	admin_report.VGUI[#admin_report.VGUI]:SetEndAng(Lerp(pi_pending/whole_pi, 0, 360)+admin_report.VGUI[#admin_report.VGUI-1]:GetEndAng())
	admin_report.VGUI[#admin_report.VGUI]:SetColor(Color(92,171,224))
	
	admin_report.VGUI[#admin_report.VGUI+1] = vgui.Create("DSemiCircle", admin_report.VGUI[report_main_bg])
	admin_report.VGUI[#admin_report.VGUI]:SetPos(ScaleX-400, 50)
	admin_report.VGUI[#admin_report.VGUI]:SetSize(200, 200)
	admin_report.VGUI[#admin_report.VGUI]:SetStartAng(admin_report.VGUI[#admin_report.VGUI-1]:GetEndAng())
	admin_report.VGUI[#admin_report.VGUI]:SetEndAng(360)
	admin_report.VGUI[#admin_report.VGUI]:SetColor(Color(250,140,140))
	
	c_img(admin_report.VGUI, ScaleX-200, 110, 16, 16, admin_report.icons.accept, admin_report.VGUI[report_main_bg])
	c_img(admin_report.VGUI, ScaleX-200, 140, 16, 16, admin_report.icons.deny, admin_report.VGUI[report_main_bg])
	c_img(admin_report.VGUI, ScaleX-200, 170, 16, 16, admin_report.icons.pending, admin_report.VGUI[report_main_bg])
	
	c_txt(admin_report.VGUI, ScaleX-180, 102, 200, 30, math.floor((pi_accepted/whole_pi)*100) .. "% Accepted Reports.", "REPORT_TTT", Color(0,0,0,100), admin_report.VGUI[report_main_bg])
	c_txt(admin_report.VGUI, ScaleX-180, 132, 200, 30, math.floor((pi_denied/whole_pi)*100) .. "% Denied Reports.", "REPORT_TTT", Color(0,0,0,100), admin_report.VGUI[report_main_bg])
	c_txt(admin_report.VGUI, ScaleX-180, 162, 200, 30, math.floor((pi_pending/whole_pi)*100) .. "% Pending Reports.", "REPORT_TTT", Color(0,0,0,100), admin_report.VGUI[report_main_bg])
end

local function UpdateAReport(id, stat)
	net.Start("EDIT_REPORT")
	net.WriteString(id)
	net.WriteFloat(stat)
	net.SendToServer()
end

local function VoteUpAReport(id)
	net.Start("VOTE_REPORT")
	net.WriteString(id)
	net.WriteFloat(LocalPlayer():EntIndex())
	net.SendToServer()
end

local function OpenAReport(r) 
	local r = report_table[r]
	c_txt(admin_report.VGUI, 5, 5, 200, 30, "REPORTED BY", "REPORT_T", Color(0,0,0,120), admin_report.VGUI[report_main_bg])
	c_txt(admin_report.VGUI, 5, 22, 200, 30, r.REPORTER, "REPORT_TT", Color(0,0,0,90), admin_report.VGUI[report_main_bg])
	surface.SetFont("REPORT_TT")
	local w, h = surface.GetTextSize(r.REPORTER)
	c_txt(admin_report.VGUI, 8+w, 22, 200, 30, "(" .. r.REPORTERID .. ")", "REPORT_TT", Color(0,0,0,70), admin_report.VGUI[report_main_bg])
	
	c_box(admin_report.VGUI, 5, 48, ScaleX-15, 1, Color(0,0,0,60), admin_report.VGUI[report_main_bg])
	
	c_txt(admin_report.VGUI, 5, 46, 200, 30, "OFFENDER", "REPORT_TT", Color(0,0,0,120), admin_report.VGUI[report_main_bg])
	c_txt(admin_report.VGUI, 5, 62, 400, 30, string.upper(r.FAGGOT), "REPORT_TTTT", Color(0,0,0,70), admin_report.VGUI[report_main_bg])
	surface.SetFont("REPORT_TTTT")
	local w, h = surface.GetTextSize(string.upper(r.FAGGOT))
	c_txt(admin_report.VGUI, 8+w, 62, 400, 30, "("..r.FAGGOTID..")", "REPORT_TTTT", Color(0,0,0,50), admin_report.VGUI[report_main_bg])
	
	c_txt(admin_report.VGUI, 5, 106, 200, 30, "REASON", "REPORT_TT", Color(0,0,0,120), admin_report.VGUI[report_main_bg])
	
	admin_report.VGUI[#admin_report.VGUI+1] = vgui.Create( "DScrollPanel", admin_report.VGUI[report_main_bg])
    admin_report.VGUI[#admin_report.VGUI]:SetSize(ScaleX-15, 200)
    admin_report.VGUI[#admin_report.VGUI]:SetPos(5,125)
	local ScrollPan = #admin_report.VGUI
	admin_report.VGUI[#admin_report.VGUI].VBar.Paint = function( s, w, h )
		draw.RoundedBox( 4, 3, 13, 8, h-24, Color(0,0,0,70))
	end
	admin_report.VGUI[#admin_report.VGUI].VBar.btnUp.Paint = function( s, w, h ) end
	admin_report.VGUI[#admin_report.VGUI].VBar.btnDown.Paint = function( s, w, h ) end
	admin_report.VGUI[#admin_report.VGUI].VBar.btnGrip.Paint = function( s, w, h )
		draw.RoundedBox( 4, 5, 0, 4, h+22, Color(0,0,0,70))
	end
	local text_scroll_info = #admin_report.VGUI
	
	c_txt(admin_report.VGUI, 0, 0, ScaleX-45, 300, r.INFO, "REPORT_TT", Color(0,0,0,120), admin_report.VGUI[report_main_bg])
	admin_report.VGUI[#admin_report.VGUI]:SetWrap(true)
	admin_report.VGUI[#admin_report.VGUI]:SetAutoStretchVertical(true)
	admin_report.VGUI[text_scroll_info]:AddItem(admin_report.VGUI[#admin_report.VGUI])
	
	c_txt(admin_report.VGUI, 5, 330, 100, 20, "PROOF", "REPORT_TT", Color(0,0,0,120), admin_report.VGUI[report_main_bg])
	for _, proof in pairs(r.PROOF)do
		c_box(admin_report.VGUI, 4+(_-1)*95, 348, 94, 192, Color(0,0,0,60), admin_report.VGUI[report_main_bg])
		c_box(admin_report.VGUI, 6+(_-1)*95, 350, 90, 190, Color(0,0,0,60), admin_report.VGUI[report_main_bg])
		local proof_prev_box = #admin_report.VGUI
		c_html(admin_report.VGUI, -(720/2), -(480/2), 720, 480, proof, admin_report.VGUI[proof_prev_box])
		c_btn(admin_report.VGUI, 0, 0, 90, 190, admin_report.VGUI[proof_prev_box])
		admin_report.VGUI[#admin_report.VGUI]:SetDrawBackground(false)
		admin_report.VGUI[#admin_report.VGUI].DoClick = function()
			if !string.find(proof, "http") then
				gui.OpenURL("http://" .. proof)
			else
				gui.OpenURL(proof)
			end
		end
	end
	
	if CanAccpetAndDenyReports(LocalPlayer()) then
		c_btn(admin_report.VGUI, ScaleX-30, 17, 16, 16, admin_report.VGUI[report_main_bg])
		admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
			surface.SetDrawColor( 255, 255, 255, 255 ) 
			surface.SetMaterial( Material( admin_report.icons.deny ) )
			surface.DrawTexturedRect( 0, 0, 16, 16 )
		end
		admin_report.VGUI[#admin_report.VGUI]:SetToolTip("Deny this report.")
		admin_report.VGUI[#admin_report.VGUI].DoClick = function()
			if LocalPlayer():SteamID() == r.FAGGOTID and !CanDeleteReports(LocalPlayer()) then
				surface.PlaySound(admin_report.ErrorSound)
				chat.AddText(Color(255,255,255), admin_report.ReportPrefix .. " You cannot accept/deny a report placed on you.")
				return
			end
			if tonumber(r.STATUS) != 0 then 
				surface.PlaySound(admin_report.ErrorSound)
				chat.AddText(Color(255,255,255), admin_report.ReportPrefix .. " This report has already been dealt with.")
				return 
			end
			UpdateAReport(report_table[selected_report].ID, 1)
			timer.Simple(1.5, function()
				Toggle_admin_report()
				Toggle_admin_report()
			end)
			surface.PlaySound(admin_report.AcceptSound)
		end
		
		c_btn(admin_report.VGUI, ScaleX-60, 17, 16, 16, admin_report.VGUI[report_main_bg])
		admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
			surface.SetDrawColor( 255, 255, 255, 255 ) 
			surface.SetMaterial( Material( admin_report.icons.accept ) )
			surface.DrawTexturedRect( 0, 0, 16, 16 )
		end
		admin_report.VGUI[#admin_report.VGUI]:SetToolTip("Accept this report.")
		admin_report.VGUI[#admin_report.VGUI].DoClick = function()
			if LocalPlayer():SteamID() == r.FAGGOTID and !CanDeleteReports(LocalPlayer()) then
				surface.PlaySound(admin_report.ErrorSound)
				chat.AddText(Color(255,255,255), admin_report.ReportPrefix .. " You cannot accept/deny a report placed on you.")
				return
			end
			if tonumber(r.STATUS) != 0 then 
				surface.PlaySound(admin_report.ErrorSound)
				chat.AddText(Color(255,255,255), admin_report.ReportPrefix .. " This report has already been dealt with.")
				return 
			end
			UpdateAReport(report_table[selected_report].ID, 2)
			timer.Simple(1.5, function()
				Toggle_admin_report()
				Toggle_admin_report()
			end)
			surface.PlaySound(admin_report.AcceptSound)
		end
		
		c_btn(admin_report.VGUI, ScaleX-30, 57, 16, 16, admin_report.VGUI[report_main_bg])
		admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
			surface.SetDrawColor( 255, 255, 255, 255 ) 
			surface.SetMaterial( Material( admin_report.icons.copy ) )
			surface.DrawTexturedRect( 0, 0, 16, 16 )
		end
		admin_report.VGUI[#admin_report.VGUI]:SetToolTip("Copy player's Steam ID.")
		admin_report.VGUI[#admin_report.VGUI].DoClick = function()
			SetClipboardText(report_table[selected_report].FAGGOTID)
			surface.PlaySound(admin_report.AcceptSound)
		end
	end
	if CanDeleteReports(LocalPlayer()) then
		c_btn(admin_report.VGUI, ScaleX-90, 17, 16, 16, admin_report.VGUI[report_main_bg])
		admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
			surface.SetDrawColor( 255, 255, 255, 255 ) 
			surface.SetMaterial( Material( admin_report.icons.delete ) )
			surface.DrawTexturedRect( 0, 0, 16, 16 )
		end
		admin_report.VGUI[#admin_report.VGUI]:SetToolTip("Delete this report.")
		admin_report.VGUI[#admin_report.VGUI].DoClick = function()
			net.Start("DELETE_REPORT")
			net.WriteString(report_table[selected_report].ID)
			net.SendToServer()
			report_mode = 0
			timer.Simple(1.5, function()
				Toggle_admin_report()
				Toggle_admin_report()
			end)
			surface.PlaySound(admin_report.AcceptSound)
		end
	end
end

local function OpenReportUI()
	admin_report.VGUI = {}
	local SavedReportButtons = {}
	
	surface.SetFont("REPORT_LOWER")
	local ww1, hh1 = surface.GetTextSize("CLOSE")
	c_btn(admin_report.VGUI, ScrW()/2-ScaleX/2-ww1-20+ScaleX, ScrH()/2-ScaleY/2-28, ww1+20, 30)
	admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(250,67,67))
		draw.RoundedBox( 0, 1, 1, w-2, h-2, Color(240,86,86))
		draw.SimpleText("CLOSE", "REPORT_LOWER", w/2, h/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	admin_report.VGUI[#admin_report.VGUI].DoClick = function()
		Toggle_admin_report()
	end
	
	surface.SetFont("REPORT_LOWER")
	local ww2, hh2 = surface.GetTextSize("WRITE REPORT")
	c_btn(admin_report.VGUI, ScrW()/2-ScaleX/2-ww2-20+ScaleX-ww1-22, ScrH()/2-ScaleY/2-28, ww2+20, 30)
	admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(40,40,40))
		draw.RoundedBox( 0, 1, 1, w-2, h-2, Color(60,60,60))
		draw.SimpleText("WRITE REPORT", "REPORT_LOWER", w/2, h/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	admin_report.VGUI[#admin_report.VGUI].DoClick = function()
		report_mode = 1
		CloseReportUI()
		OpenReportUI()
	end
	
	surface.SetFont("REPORT_LOWER")
	local ww3, hh3 = surface.GetTextSize("MAIN")
	c_btn(admin_report.VGUI, ScrW()/2-ScaleX/2-ww2-20+ScaleX-ww1-22-ww3-22, ScrH()/2-ScaleY/2-28, ww3+20, 30)
	admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
		draw.RoundedBox( 0, 0, 0, w, h, Color(40,40,40))
		draw.RoundedBox( 0, 1, 1, w-2, h-2, Color(60,60,60))
		draw.SimpleText("MAIN", "REPORT_LOWER", w/2, h/2, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
	admin_report.VGUI[#admin_report.VGUI].DoClick = function()
		report_mode = 0
		CloseReportUI()
		OpenReportUI()
	end
	
	-- Sidebar
	c_box(admin_report.VGUI, ScrW()/2-ScaleX/2-180-1, ScrH()/2-ScaleY/2-1, ScaleX+189, ScaleY+16, COL_DGREY_L)
	c_box(admin_report.VGUI, ScrW()/2-ScaleX/2-180, ScrH()/2-ScaleY/2, ScaleX+187, ScaleY+14, COL_DGREY)
	local SideBox = #admin_report.VGUI
	
	admin_report.VGUI[#admin_report.VGUI+1] = vgui.Create( "DScrollPanel", admin_report.VGUI[SideBox])
    admin_report.VGUI[#admin_report.VGUI]:SetSize(180, ScaleY)
    admin_report.VGUI[#admin_report.VGUI]:SetPos(0,7)
	local ScrollPan = #admin_report.VGUI
	
	admin_report.VGUI[#admin_report.VGUI].VBar.Paint = function( s, w, h )
		draw.RoundedBox( 4, 3, 13, 8, h-24, Color(0,0,0,70))
	end
	
	admin_report.VGUI[#admin_report.VGUI].VBar.btnUp.Paint = function( s, w, h ) end
	admin_report.VGUI[#admin_report.VGUI].VBar.btnDown.Paint = function( s, w, h ) end
	
	admin_report.VGUI[#admin_report.VGUI].VBar.btnGrip.Paint = function( s, w, h )
		draw.RoundedBox( 4, 5, 0, 4, h+22, Color(0,0,0,70))
	end
	
	-- Mainbg
	c_box(admin_report.VGUI, ScrW()/2-ScaleX/2, ScrH()/2-ScaleY/2+7, ScaleX, ScaleY, COL_WHITE)
	c_box(admin_report.VGUI, ScrW()/2-ScaleX/2+2, ScrH()/2-ScaleY/2+7+2, ScaleX-4, ScaleY-4, COL_WHITE_L)
	report_main_bg = #admin_report.VGUI

	-- Side Buttons
	local x_pos_plus = 0
	if table.Count(report_table) >= 9 then
		x_pos_plus = 15
	end
	local i = 0
	for _, report in pairs(report_table)do
		i = i + 1
		c_btn(admin_report.VGUI, 0, 7+61*(i-1), 180, 60, admin_report.VGUI[SideBox])
		admin_report.VGUI[#admin_report.VGUI].col = 70
		admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
			if report_mode == 2 and selected_report == _ then
				draw.RoundedBox( 0, 0, 0, w-2, h-2, Color(s.col,s.col,s.col))
			end
			draw.SimpleText(string.upper(report.FAGGOT), "REPORT_TITLE", 10, 19, Color(255,255,255,100), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(string.upper(report.FAGGOTID), "REPORT_LOWER", 10, 30, Color(255,255,255,100), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(string.upper(report.DATE), "REPORT_LOWER", 10, 40, Color(255,255,255,100), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			for i = 1, w, 4 do
				draw.RoundedBox( 0, i, h-1, 2, 1, Color(40,40,40))
			end
			surface.SetDrawColor( 255, 255, 255, 255 ) 
			if tonumber(report.STATUS) == 0 then
				surface.SetMaterial( Material( admin_report.icons.pending ) )
			elseif tonumber(report.STATUS) == 1 then
				surface.SetMaterial( Material( admin_report.icons.deny ) )
			else
				surface.SetMaterial( Material( admin_report.icons.accept ) )
			end
			surface.DrawTexturedRect( w-(17+x_pos_plus), h-17, 16, 16 )
		end
		table.insert(SavedReportButtons, #admin_report.VGUI)
		admin_report.VGUI[ScrollPan]:AddItem(admin_report.VGUI[#admin_report.VGUI])
		admin_report.VGUI[#admin_report.VGUI].DoClick = function()
			report_mode = 2
			selected_report = _
			CloseReportUI()
			OpenReportUI()
		end
		if tonumber(report.STATUS) == 0 then
			c_btn(admin_report.VGUI, 180-(36+30+x_pos_plus), 61*(i-1)+50, 46, 16, admin_report.VGUI[SideBox])
			admin_report.VGUI[#admin_report.VGUI].Paint = function( s, w, h )
				surface.SetDrawColor( 255, 255, 255, 255 )
				surface.SetMaterial( Material( admin_report.icons.voteup ) )
				surface.DrawTexturedRect( 30, 0, 16, 16 )
				draw.SimpleText(#report.VOTES .. "x", "REPORT_LOWER", 30, h/2, Color(255,255,255,100), TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			admin_report.VGUI[#admin_report.VGUI].DoClick = function()
				if !table.HasValue(report.VOTES, LocalPlayer():SteamID()) and tonumber(report.STATUS) == 0 then
					VoteUpAReport(report.ID)
					timer.Simple(1.5, function()
						Toggle_admin_report()
						Toggle_admin_report()
					end)
					surface.PlaySound(admin_report.AcceptSound)
				else
					surface.PlaySound(admin_report.ErrorSound)
					chat.AddText(Color(255,255,255), admin_report.ReportPrefix .. " This report has already been dealt with or you have already voted.")
				end
			end
			admin_report.VGUI[ScrollPan]:AddItem(admin_report.VGUI[#admin_report.VGUI])
		end
	end
	
	if report_mode == 0 then
		OpenMainPage()
	elseif report_mode == 1 then
		OpenReportWrite()
	else
		OpenAReport(selected_report)
	end
end

function Toggle_admin_report()
	if ReportOpen then
		CloseReportUI()
		ReportOpen = false
	else
		OpenReportUI()
		ReportOpen = true
	end
	gui.EnableScreenClicker(ReportOpen)
end
