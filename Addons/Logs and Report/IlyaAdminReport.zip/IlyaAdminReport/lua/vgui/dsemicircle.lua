
local clamp, cos, sin, deg2rad = math.Clamp, math.cos, math.sin, math.pi/180
function DrawPartialCircle( x, y, radius, linewidth, startangle, endangle, aa )
    aa = aa or 1;
    startangle = clamp( startangle or 0, 0, 360 );
    endangle = clamp( endangle or 360, 0, 360 );
     
    if endangle < startangle then
        local temp = endangle;
        endangle = startangle;
        startangle = temp;
    end
	
	if endangle == 0 then return end
    for i=startangle, endangle, aa do
        local _i = i * deg2rad;         
        surface.DrawTexturedRectRotated(cos( _i ) * (radius - linewidth) + x,sin( _i ) * (radius - linewidth) + y, linewidth, aa*2, -i );
    end
end

PANEL = {}

AccessorFunc( PANEL, "m_bAntialias",      "Antialias")
AccessorFunc( PANEL, "m_bRadius",         "Radius")
AccessorFunc( PANEL, "m_bLineW",          "LineW")
AccessorFunc( PANEL, "m_bStartAng",       "StartAng")
AccessorFunc( PANEL, "m_bEndAng",         "EndAng")
AccessorFunc( PANEL, "m_bCol",            "Color")

function PANEL:Init()
	self.anti       = self:GetAntialias()      or 7
	self.radius     = self:GetRadius()         or 70
	self.linew      = self:GetLineW()          or 15
	self.ShouldAnim = true
end

function PANEL:Paint( w, h )
	if self:GetEndAng() != 0 then
		for i = 1, self.anti do
			surface.SetDrawColor(self:GetColor())
			surface.SetMaterial(Material("vgui/white"))
			DrawPartialCircle( w/2, h/2, self.radius, self.linew, self:GetStartAng(), self.NewEnd, i )
		end
	end
end

function PANEL:Think()
	self.NewEnd = self.NewEnd or self:GetStartAng() 
	if self.ShouldAnim then
		self.NewEnd = self.NewEnd+4
		if self.NewEnd >= self:GetEndAng() then
			self.ShouldAnim = false
		end
	end
end

vgui.Register("DSemiCircle", PANEL)
